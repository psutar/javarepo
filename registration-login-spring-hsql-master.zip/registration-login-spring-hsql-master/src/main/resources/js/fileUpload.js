// JavaScript Document
function getFile(testId){
var test = document.getElementById(testId);
document.getElementById(testId).click();
}
function sub(obj){
    var file = obj.value;
    var fileName = file.split("\\");
    //document.getElementById("filetext").value = fileInput.value.replace("C:\\fakepath\\","");
    //document.getElementById("filetext").value=document.getElementById("uploadedFile").files[0].name;
    document.getElementById("filetext").value=file;
    //event.preventDefault();
    //alert(file.lastIndexOf(".txt"));
    //var ext = file.substring(len-4,len);
    var lastslash=file.lastIndexOf("\\")
  //alert(ext);
  //alert(lastslash);
  var originalfilename=file.substring(lastslash+1,file.length);
  //alert("Your file name being uploaded is� \"" + originalfilename +"\"");
  var dot1= originalfilename.indexOf(".");
  var dot2= originalfilename.lastIndexOf(".");
 /* alert(dot1);
  alert(dot2);*/	
    var len=file.length;
    var ext = file.substring(len-4,len);
    ext = ext.toLowerCase();
    if(dot1!=dot2){
    	alert("Incorrect file name");
    	 document.getElementById("filetext").value="select a file to upload";
    	 document.getElementById("fileUploadForm").reset();
    	return false;
    }
    if(ext != ".txt") {
    alert("Please select a .txt file");
        document.getElementById("filetext").value="select a file to upload";
        document.getElementById("fileUploadForm").reset();
        return false;
     }
    else
         return true;
    
}

function fileUploadSubmit() { 
	//alert("remit bb");
	var uploadfield = document.fileUploadForm.uploadedFile.value;
	
	//var originalfilename=document.getElementById("uploadedFile").files[0].filename;
	//alert("originalfilename"+originalfilename);
	
	//document.getElementById("originalfilename").value=originalfilename;
	if( uploadfield=="" || uploadfield==null){
		alert("select file to upload");
		document.fileUploadForm.uploadedFile.focus();
		return false;
	}
	else{
		var r=confirm("Confirm file:"+uploadfield);
		if (r==true)
		{
			document.fileUploadForm.submit();
		}
		else
		{
			document.getElementById("fileUploadForm").reset();
		}

		//document.fileUploadForm.submit();
	}
}

function submitFileUploadStatus(fileNo)
{
	// alert("the chosen file no is:"+fileNo);
	document.getElementById("fileNo").value = fileNo;
	document.imFileUploadForm.submit();
}

function backToViewFileDetails()
{
	document.imFileUploadForm.action="fileviewstatus.htm";
	document.imFileUploadForm.submit();
}

function runScript(e) {
    if (e.keyCode == 13) {
        return false;
    }
}

	

