package com.infosys.auth.model;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	String id;
	String uuid;
	String name;
	String address;
	List<Discount> eligibleDiscounts = new ArrayList<Discount>();
	List<PurchasedProduct> products = new ArrayList<PurchasedProduct>();
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Discount> getEligibleDiscounts() {
		return eligibleDiscounts;
	}
	public void setEligibleDiscounts(List<Discount> eligibleDiscounts) {
		this.eligibleDiscounts = eligibleDiscounts;
	}
	public List<PurchasedProduct> getProducts() {
		return products;
	}
	public void setProducts(List<PurchasedProduct> products) {
		this.products = products;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}
