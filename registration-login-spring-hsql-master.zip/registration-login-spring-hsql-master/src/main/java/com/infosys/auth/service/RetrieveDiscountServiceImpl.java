package com.infosys.auth.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.utils.ApplicationConstants;

@Service
public class RetrieveDiscountServiceImpl implements RetrieveDiscountService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	Hashtable<String, Customer> customer = new Hashtable<String, Customer>();
	List<Discount> eligibleDiscount = new ArrayList<Discount>();
	List<PurchasedProduct> products = new ArrayList<PurchasedProduct>();
	public static Customer custDetails;
	
	ObjectMapper mapper = new ObjectMapper();
	
	

	public List<Discount> getSKUDiscount(String productId, String uuid) {
		List<Discount> discountList = new ArrayList<Discount>();
		System.out.println("custDetails.getAddress()  >>" + custDetails.getAddress());
		Customer customerDetails = custDetails;
		if (productId != null) {
			List<PurchasedProduct> purchasedProductList = customerDetails.getProducts();
			for (PurchasedProduct purchasedProduct : purchasedProductList) {
				if (purchasedProduct.getProductId().equals(productId)) {
					discountList.add(purchasedProduct.getDiscountInformation());
					return discountList;
				}
			}
			if (discountList.size() == 0) {
				return discountList;
			}
		}

		return customerDetails.getEligibleDiscounts();
	}
@Override
	public Customer getCustomerDetails() throws CustomerException {
		RestTemplate restTemplate = new RestTemplate();
		String url = ApplicationConstants.URL;
		try {
			System.out.println("url :"+url);
			custDetails = restTemplate.getForObject(url, Customer.class);
			System.out.println("address: " + custDetails.getAddress());
			return custDetails;
		} catch (Exception e) {
			e.printStackTrace();
			 CustomerException.throwException("ERR0002", "Bad request - user not found in the system");
			return null;
		}

	}
@Override
public List<PurchasedProduct> getProductsDetail() throws CustomerException, FileNotFoundException, IOException, ParseException {
	File file = new File("Customer.JSON");
	logger.info("Json File Path"+file.getAbsolutePath());
	String custJsonString = getJSONString(file);
	List <Customer> custList = mapper.readValue(custJsonString, new TypeReference<List<Customer>>() {});
	List<PurchasedProduct>productList = custList.get(0).getProducts();
	logger.info("productArrayList >>"+productList);
	
	return productList;
}

public String getJSONString(File file) throws FileNotFoundException, IOException, ParseException{
	JSONParser parser = new JSONParser();
	Object obj = parser.parse(new FileReader(file.getAbsolutePath()));
	logger.info("obj  >>"+obj.getClass());
	JSONArray jsonArray = (JSONArray) obj;
	String jsonString = jsonArray.toJSONString();
	return jsonString;
}


@Override
public Map fileUploadProcessor(Map inputParams) throws IllegalStateException, IOException, ParseException {
	Map<String,Object> outputParams = new HashMap<String,Object>();
	String fileName = "";
	if (inputParams != null && inputParams.size() > 0) {
		MultipartFile file = (MultipartFile) inputParams.get("file");
		fileName = (String) inputParams.get("fileName");
		logger.info("fileName in service :"+ fileName);
		fileName = fileName.replace(".txt", "");
		logger.info("fileName in service after extension removal :"+ fileName);
	String newPath = "";
	String newFileName = fileName + ApplicationConstants.DOT + ApplicationConstants.JSON_EXT;
	newPath = ApplicationConstants.FILE_UPLOAD_PATH + newFileName ;
	// file.transferTo(new File(newPath));
	logger.info("Path :::" + newPath);
	logger.info("inparams :" + inputParams);
	File f1 = new File(ApplicationConstants.FILE_UPLOAD_PATH);
	if (f1.exists()) {
			file.transferTo(new File(newPath));
			String addedProdCustomerString = getJSONString(new File(newPath));
			List <Customer> custList = mapper.readValue(addedProdCustomerString, new TypeReference<List<Customer>>() {});
			List<PurchasedProduct>productList = custList.get(0).getProducts();
		}
	outputParams.put("fileName", newFileName);
	}
	
	return outputParams;
}

}
