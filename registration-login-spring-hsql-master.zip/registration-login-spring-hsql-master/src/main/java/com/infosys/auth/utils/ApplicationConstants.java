package com.infosys.auth.utils;

public class ApplicationConstants {
	private ApplicationConstants(){
		
	}
public final static String URL = "http://172.21.115.8:8080/getcustomer/discounts.json";
public static final String DOT = ".";
public static final String FILE_UPLOAD_PATH = "D:/fileUpload/";
public static final String JSON_EXT = "JSON";

}
