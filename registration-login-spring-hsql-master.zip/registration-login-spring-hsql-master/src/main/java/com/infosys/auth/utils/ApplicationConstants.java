package com.infosys.auth.utils;

public class ApplicationConstants {
	private ApplicationConstants(){
		
	}
public final static String URL = "http://172.21.115.8:8080/getcustomer/discounts.json";
}
