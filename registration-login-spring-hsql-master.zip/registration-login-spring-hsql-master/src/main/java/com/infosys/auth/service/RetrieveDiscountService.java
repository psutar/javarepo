package com.infosys.auth.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ParseException;

import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;



public interface RetrieveDiscountService {

	public List<Discount> getSKUDiscount(String productId, String uuid);
	public Customer getCustomerDetails()throws CustomerException;
	public List<PurchasedProduct> getProductsDetail()throws CustomerException, FileNotFoundException, IOException, ParseException ;
	public Map fileUploadProcessor(Map inputParams) throws IllegalStateException, IOException, ParseException;
}
