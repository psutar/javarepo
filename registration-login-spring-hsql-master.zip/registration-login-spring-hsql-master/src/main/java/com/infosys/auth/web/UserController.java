package com.infosys.auth.web;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.model.User;
import com.infosys.auth.service.RetrieveDiscountService;
import com.infosys.auth.service.SecurityService;
import com.infosys.auth.service.UserService;
import com.infosys.auth.validator.UserValidator;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
	RetrieveDiscountService retrieveDiscountService;
    
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping(value = "/registration", method = RequestMethod.GET)
    public String registration(Model model) {
    	logger.info("registration method");
        model.addAttribute("userForm", new User());

        return "registration";
    }

    @RequestMapping(value = "/registration", method = RequestMethod.POST)
    public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
    	logger.info("inside registration");
    	logger.info("userForm >>"+userForm.toString());
    	logger.info("model >>"+model);
        userValidator.validate(userForm, bindingResult);

        logger.info("bindingResult >>"+bindingResult.getAllErrors());
        if (bindingResult.hasErrors()) {
            return "registration";
        }

        userService.save(userForm);

        securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());

        return "redirect:/welcome";
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login(Model model, String error, String logout) {
    	logger.info("login method");
        if (error != null)
            model.addAttribute("error", "Your username and password is invalid.");

        if (logout != null)
            model.addAttribute("message", "You have been logged out successfully.");

        return "login";
    }

    @RequestMapping(value = {"/", "/welcome"}, method = RequestMethod.GET)
    public String welcome(Model model) throws CustomerException, FileNotFoundException, IOException, ParseException {
    	logger.info("welcome method");
    	List<PurchasedProduct> productList= retrieveDiscountService.getProductsDetail();
    	model.addAllAttributes(productList);
        return "welcome";
    }
}
