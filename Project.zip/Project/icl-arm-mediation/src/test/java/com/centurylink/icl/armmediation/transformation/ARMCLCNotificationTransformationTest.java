package com.centurylink.icl.armmediation.transformation;

import java.io.File;
import java.io.IOException;
import java.util.List;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlbeans.XmlException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CustomerAgentBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.UNICircuitBuilder;
import com.centurylink.icl.builder.iclnotification.EventNotificationBuilder;
import com.centurylink.icl.builder.iclnotification.EventNotificationDocumentBuilder;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceNotificationDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TopologicalLink;

public class ARMCLCNotificationTransformationTest {

	private static final Log LOG = LogFactory.getLog(ARMCLCNotificationTransformationTest.class);
	private static final String UNI_DETAILS_RESPONSE_FILE = "src/test/resources/UniDetailsResponse.xml";
	private SearchResourceResponseDocument uniDetailsResponse;
	
	@Before
	public void setUp() throws Exception 
	{
			uniDetailsResponse = SearchResourceResponseDocument.Factory.parse(new File(UNI_DETAILS_RESPONSE_FILE));
	}

	@After
	public void tearDown() 
	{
		uniDetailsResponse = null;
	}
	
	@Test
	public void transformEVCToResourceNotification() throws XmlException, IOException {
		
		/*EventNotificationDocumentBuilder eventNotificationDocumentBuilder = new EventNotificationDocumentBuilder();
		EventNotificationBuilder eventNotificationBuilder = new EventNotificationBuilder();
		eventNotificationBuilder.buildEventNotification("36145", "10/VLGS/622038//CTRN", "SERVICE", "ARM", "ADD");
		eventNotificationDocumentBuilder.buildEventNotificationDocument(eventNotificationBuilder.getEventNotification());
		ResourceNotificationDocument resourceNotificationDocument = ARMCLCNotificationTransformation.transformEVCToResourceNotification(eventNotificationDocumentBuilder.getEventNotificationDocument());
		
		LOG.info(resourceNotificationDocument);
		
		SubNetworkConnection subNetworkConnection = resourceNotificationDocument.getResourceNotification().getResourceNotificationDetailsList().get(0).getCircuitList().get(0);
		
		Assert.assertEquals("36145", subNetworkConnection.getObjectID());
		Assert.assertEquals("10/VLGS/622038//CTRN", subNetworkConnection.getCommonName());
		Assert.assertEquals("SERVICE", subNetworkConnection.getResourceType());
		Assert.assertEquals("ADD", subNetworkConnection.getAction());*/
		
		
	}

	@Test
	public void transformLocationToResourceNotification()
	{
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		americanPropertyAddressBuilder.buildAmericanPropertyAddress("LSVGNVBG-CS-6", "14034", null , "ARM", "PARADISE", "LAS VEGAS", "89109", "3000 PARADISE RD", null, null, "NV");
		americanPropertyAddressBuilder.addRootEntityDescribedBy("LocationFullName", "LAS VEGAS HILTON &amp; CASINO");
		americanPropertyAddressBuilder.addRootEntityDescribedBy("BuildingName", "LAS VEGAS HILTON &amp; CASINO");
		americanPropertyAddressBuilder.setAdditionalInformation("LSVGNVBG", "CS");
		americanPropertyAddressBuilder.addRootEntityDescribedBy("Action", "ADD");
		
		LOG.info(americanPropertyAddressBuilder.getAmericanPropertyAddress());
		
		ResourceNotificationDocument resourceNotificationDocument = ARMCLCNotificationTransformation.transformLocationToResourceNotification(americanPropertyAddressBuilder.getAmericanPropertyAddress(), "ADD");
		
		LOG.info(resourceNotificationDocument);
		
		AmericanPropertyAddress addressDetails = resourceNotificationDocument.getResourceNotification().getResourceNotificationDetailsList().get(0).getAddressDetailsList().get(0);
		List<CharacteristicValue> rootEntityDescribedByList = addressDetails.getRootEntityDescribedByList();
		
		Assert.assertEquals("LSVGNVBG-CS-6", addressDetails.getCommonName());
		Assert.assertEquals("14034", addressDetails.getObjectID());
		Assert.assertEquals("ARM",addressDetails.getSourceSystem());
		
		for (CharacteristicValue characteristicValue : rootEntityDescribedByList) {
			
			if("Action".equalsIgnoreCase(characteristicValue.getCharacteristicName()))
			{
				Assert.assertEquals("ADD", characteristicValue.getCharacteristicValue());
			}
		}
		
	}
	
	@Test
	public void transformUNIToResourceNotification()
	{
		/*SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResponseResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		
		UNICircuitBuilder uniCircuitBuilder = new UNICircuitBuilder();
		uniCircuitBuilder.buildUNICircuit("60/L1XX/598765//CTRL-D-1", "209", null, "ARM", "MEF UNI", "Pending Disconnect", null, "LSVMNVVTH05", "CREATE");
		uniCircuitBuilder.addRootEntityDescribedBy("IsDiverse", "No");
		
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		customerBuilder.buildCustomer("A000061", "328", null, null, "ARM", null);
		
		CustomerAgentBuilder customerAgentBuilder = new CustomerAgentBuilder();
		customerAgentBuilder.buildCustomerAgent("YASHWANTH", "12344");
		
		ownsResourceDetailsBuilder.buildOwnsResourceDetails();
		ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
		ownsResourceDetailsBuilder.addCustomerAgent(customerAgentBuilder.getCustomerAgent());
		
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		AmericanPropertyAddressBuilder accessPointAddressBuilder = new AmericanPropertyAddressBuilder();
		accessPointAddressBuilder.buildAmericanPropertyAddress("LSVMNVVT-ES-1", "10891", null, "CLC", null, "LAS VEGAS", "89118", "S BLVD", null, null, "NV");
		connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
		connectionTerminationPointBuilder.addAccessPointAddress(accessPointAddressBuilder.getAmericanPropertyAddress());
		
		uniCircuitBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
		uniCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
		
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		searchResponseDetailsBuilder.addP2PCircuit(uniCircuitBuilder.getUNICircuit());
		
		searchResponseResponseBuilder.buildSearchResourceResponse(null, null);
		searchResponseResponseBuilder.addSearchResponseDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
		
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResponseResponseBuilder.getSearchResourceResponse());
		
		LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument());
		
		EventNotificationDocumentBuilder eventNotificationDocumentBuilder = new EventNotificationDocumentBuilder();
		EventNotificationBuilder eventNotificationBuilder = new EventNotificationBuilder();
		eventNotificationBuilder.buildEventNotification("209", "60/L1XX/598765//CTRL-D-1", "SERVICE", "ARM", "CREATE");
		eventNotificationDocumentBuilder.buildEventNotificationDocument(eventNotificationBuilder.getEventNotification());
		
		ResourceNotificationDocument resourceNotificationDocument = ARMCLCNotificationTransformation.transformUNIToResourceNotification(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument(), eventNotificationDocumentBuilder.getEventNotificationDocument());
		
		LOG.info(resourceNotificationDocument);
		
		TopologicalLink topologicalLink  = resourceNotificationDocument.getResourceNotification().getResourceNotificationDetailsList().get(0).getP2PCircuitList().get(0);
		
		Assert.assertEquals("60/L1XX/598765//CTRL-D-1", topologicalLink.getCommonName());
		Assert.assertEquals("209", topologicalLink.getObjectID());
		Assert.assertEquals("A000061", topologicalLink.getOwnsResourceDetails().getCustomerList().get(0).getCommonName()); */
		
	}
	
	@Test
	public void transformUNIToResourceNotificationFromFile()
	{
		
	/*	EventNotificationDocumentBuilder eventNotificationDocumentBuilder = new EventNotificationDocumentBuilder();
		EventNotificationBuilder eventNotificationBuilder = new EventNotificationBuilder();
		eventNotificationBuilder.buildEventNotification("209", "60/L1XX/598765//CTRL-D-1", "SERVICE", "ARM", "CREATE");
		eventNotificationDocumentBuilder.buildEventNotificationDocument(eventNotificationBuilder.getEventNotification());
			
		ResourceNotificationDocument resourceNotificationDocument = ARMCLCNotificationTransformation.transformUNIToResourceNotification(uniDetailsResponse, eventNotificationDocumentBuilder.getEventNotificationDocument());
		
		LOG.info(resourceNotificationDocument);
		TopologicalLink topologicalLink  = resourceNotificationDocument.getResourceNotification().getResourceNotificationDetailsList().get(0).getP2PCircuitList().get(0);
		
		Assert.assertEquals("15/KSGS/595641//CTRL", topologicalLink.getCommonName());
		Assert.assertEquals("212", topologicalLink.getObjectID());
		Assert.assertEquals("ATT MOBILITY - FAI", topologicalLink.getOwnsResourceDetails().getCustomerList().get(0).getDescription()); */
		
	}
	
}
