package com.centurylink.icl.armmediation.vo;

import java.io.File;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class SearchServiceVOTest
{
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testSearchServiceVOSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchCircuitVORequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetServiceVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		System.out.println("Response --->  "+response);
		Assert.assertNotNull(response);
	}
	
	@Test
    public void testSearchServiceVOSuccessForEVC() throws Exception
    {
        SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchCircuitEVORequestForEVC.xml"));
        HashMap<String, Object> iHashMap = new HashMap<String, Object>();
        iHashMap.put("methodName", "GetServiceVO");
        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
        Object object = armServiceImpl.call(request, iHashMap);
        SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
        System.out.println("Response --->  "+response);
        Assert.assertNotNull(response);
    }

	
	@Test
    public void testQueryServiceRouteForGPONVO() throws Exception
    {
        SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/ServiceRouteRequestVO.xml"));
        HashMap<String, Object> iHashMap = new HashMap<String, Object>();
        iHashMap.put("methodName", "QueryServiceRouteForGPONVO");
        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
        Object object = armServiceImpl.call(request, iHashMap);
        SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
        System.out.println("Response --->  "+response);
        Assert.assertNotNull(response);
    }
	
	@Test
	public void testSearchServiceVOSuccessForCircuitcircuitSummary() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchCircuitSummaryVORequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetServiceVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		System.out.println("Response --->  "+response);
		Assert.assertNotNull(response);
	}

}
