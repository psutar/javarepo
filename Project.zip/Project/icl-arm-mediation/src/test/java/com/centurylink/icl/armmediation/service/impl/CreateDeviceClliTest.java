package com.centurylink.icl.armmediation.service.impl;

import java.io.File;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.CreateDeviceClliRequest;
import com.centurylink.icl.armmediation.service.CreateDeviceClliResponse;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class CreateDeviceClliTest {
	
	private CreateDeviceClliImpl createDeviceClliImpl;
	
	@Before
	public void setUp()
	{
		createDeviceClliImpl = applicationContext.getBean("createDeviceClliImpl", CreateDeviceClliImpl.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	public void testCreateDeviceClliExistingSequence()
	{
		CreateDeviceClliRequest createDeviceClliRequest = new CreateDeviceClliRequest();
		createDeviceClliRequest.setEquipmentType("testEqTeyp");
		createDeviceClliRequest.setLocationClli("NLVGNVIH");
		
		CreateDeviceClliResponse createDeviceClliResponse =  createDeviceClliImpl.createDeviceClli(createDeviceClliRequest);
		
		System.out.println(createDeviceClliResponse.getDeviceClli());
		System.out.println(createDeviceClliResponse.getEquipmentType());
		System.out.println(createDeviceClliResponse.getServingWireCenter());
		Assert.assertEquals(11, createDeviceClliResponse.getDeviceClli().length());
		Assert.assertEquals("testEqTeyp", createDeviceClliResponse.getEquipmentType());
		Assert.assertEquals("NLVGNVXG", createDeviceClliResponse.getServingWireCenter());
	}
	
	@Test
	public void testCreateDeviceClliNewSequence()
	{
		CreateDeviceClliRequest createDeviceClliRequest = new CreateDeviceClliRequest();
		createDeviceClliRequest.setEquipmentType("testEqTeyp");
		createDeviceClliRequest.setLocationClli("NLVGNVMI");
		
		CreateDeviceClliResponse createDeviceClliResponse =  createDeviceClliImpl.createDeviceClli(createDeviceClliRequest);
		
		System.out.println(createDeviceClliResponse.getDeviceClli());
		System.out.println(createDeviceClliResponse.getEquipmentType());
		System.out.println(createDeviceClliResponse.getServingWireCenter());
		
		Assert.assertEquals(11, createDeviceClliResponse.getDeviceClli().length());
		Assert.assertEquals("testEqTeyp", createDeviceClliResponse.getEquipmentType());
		Assert.assertEquals("NLVGNVXF", createDeviceClliResponse.getServingWireCenter());
	}
}


