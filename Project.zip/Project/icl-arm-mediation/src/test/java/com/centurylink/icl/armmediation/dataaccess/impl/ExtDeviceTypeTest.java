package com.centurylink.icl.armmediation.dataaccess.impl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.dataaccess.ExtDeviceTypeDAO;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })
public class ExtDeviceTypeTest {
	
private ExtDeviceTypeDAO extDeviceTypeDAO;
	
	@Before
	public void setUp()
	{
		extDeviceTypeDAO = applicationContext.getBean("extDeviceTypeDAO", ExtDeviceTypeDAO.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testValidateClliCountTrue() throws Exception
	{
		
		boolean clliCount = extDeviceTypeDAO.doesClliExists("LSVLNV82H00---");
		if(true == clliCount)
		Assert.assertTrue(clliCount);	
		
	}
	

}
