package com.centurylink.icl.armmediation.dataaccess.impl;



import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;



import com.centurylink.icl.armmediation.armaccessobject.LocationBuildingSite;


import com.centurylink.icl.armmediation.dataaccess.ExtLocationBuildingSiteDAO;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class ExtLocationBuildingSiteTest {
	
	private ExtLocationBuildingSiteDAO extLocationBuildingSiteDAO;
	
	
	@Before
	public void setUp()
	{
		extLocationBuildingSiteDAO = applicationContext.getBean("extLocationBuildingSiteDAO", ExtLocationBuildingSiteDAO.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testValidateSwcClliTrue() throws Exception
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("NLVGNVIH");		
		String swc = locationBuildingSite.getPhoneSwithClli();
		Assert.assertTrue(swc.equalsIgnoreCase("NLVGNVXG"));
	}
	
	@Test
	public void testValidateSwcClliData() throws Exception
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("NLVGNVIH");		
		Assert.assertNotNull("SWC value for" + locationBuildingSite.getClliCode(), locationBuildingSite.getPhoneSwithClli());
	}
	
	
	@Test
	public void testValidateSwcClliNoData() throws Exception
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("HNSPNVAC");		
		String swc = locationBuildingSite.getPhoneSwithClli();
		Assert.assertNull("SWC value for" + locationBuildingSite.getClliCode(),swc);
	}
	
	@Test
	public void testValidationLocationData()
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("NLVGNVIH");
		Assert.assertNotNull("locationBuildingSite has data for" + locationBuildingSite.getClliCode(), locationBuildingSite);
	}
	
	@Test
	public void testValidationNoLocationData()
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("NLVGNVXX");
		Assert.assertNull("locationBuildingSite is null for NLVGNVXX", locationBuildingSite);
	}
	
	
	@Test
	public void testValidationAllLocationData()
	{
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli("LSVQNVMI");
		System.out.println("ExtLocationBuildingSite information for ClliCode " + locationBuildingSite.getClliCode());
		System.out.println("LocationId =  "+ locationBuildingSite.getLocationId());
		Assert.assertEquals(2522, locationBuildingSite.getLocationId().longValue());
		System.out.println("LATA =  "+ locationBuildingSite.getLATA());
		Assert.assertEquals(721, locationBuildingSite.getLATA().longValue());
		System.out.println("HCOORDINATE =  "+ locationBuildingSite.getHCoordinate());
		Assert.assertEquals(7415,locationBuildingSite.getHCoordinate().longValue());
		System.out.println("LABEL =  "+ locationBuildingSite.getLabel());
		Assert.assertEquals(0,locationBuildingSite.getLabel());
		System.out.println("NPA =  "+ locationBuildingSite.getNPA());
		Assert.assertEquals(0,locationBuildingSite.getNPA());
		System.out.println("VCOORDINATE =  "+ locationBuildingSite.getVCoordinate());
		Assert.assertEquals(8670,locationBuildingSite.getVCoordinate().longValue());
		System.out.println("PHONESWITCHCLLI =  "+ locationBuildingSite.getPhoneSwithClli());
		Assert.assertEquals("LSVGNVXB",locationBuildingSite.getPhoneSwithClli());
		System.out.println("CREATIONUSER =  "+ locationBuildingSite.getCreationUser());
		Assert.assertEquals("CIRAS",locationBuildingSite.getCreationUser());
		System.out.println("ISVISIBLE =  "+ locationBuildingSite.getIsVisible());
		Assert.assertEquals(1,locationBuildingSite.getIsVisible());
		System.out.println("RPPLANID =  "+ locationBuildingSite.getRPPlanId());
		Assert.assertEquals(0,locationBuildingSite.getRPPlanId());
		System.out.println("NXX =  "+ locationBuildingSite.getNXX());
		Assert.assertEquals(0,locationBuildingSite.getNXX());
		System.out.println("HVP =  "+ locationBuildingSite.getHVP());
		Assert.assertEquals("No",locationBuildingSite.getHVP());
		  
		
	}

	
	
}


