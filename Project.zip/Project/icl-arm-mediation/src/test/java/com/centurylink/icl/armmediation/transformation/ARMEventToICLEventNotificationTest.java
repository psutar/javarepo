package com.centurylink.icl.armmediation.transformation;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import junit.framework.Assert;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import com.centurylink.icl.armmediation.armaccessobject.ARMEvent;
import com.centurylink.icl.iclnotification.EventNotification;
import com.centurylink.icl.iclnotification.Parameter;

public class ARMEventToICLEventNotificationTest {

	private static final Log LOG = LogFactory.getLog(ARMEventToICLEventNotificationTest.class);
	
	
	@Test
	public void transformARMEventToEventNotification() {
		
		ARMEvent event = new ARMEvent();
				
		event.setIclClcSyncId(new BigDecimal(344));
		event.setArmDimName("Service");
		event.setCommonName("34/ASFD/435768//KJ45");
		event.setArmObjectId(new BigDecimal(18209));
		event.setObjectAction("Update");
		event.setOldValue("34/ASFD/435768//KJ45");
		event.setNewValue("34/ASFD/435768//XXXX");
		event.setUpdatedAttribute("NAME");
		event.setResourceSubtype("MEF EVC");
		event.setLastModified(new Timestamp(System.currentTimeMillis()));
		
		
		ARMEventToICLEventNotification armEventToICLEventNotification = new ARMEventToICLEventNotification();
		EventNotification transformARMEventToEventNotification = armEventToICLEventNotification.transformARMEventToEventNotification(event);
		
		LOG.info(transformARMEventToEventNotification);
		
		Assert.assertEquals("Service", transformARMEventToEventNotification.getType());
		Assert.assertEquals("34/ASFD/435768//KJ45", transformARMEventToEventNotification.getCommonName());
		Assert.assertEquals("Update", transformARMEventToEventNotification.getAction());
		
		List<Parameter> parameterList = transformARMEventToEventNotification.getParameterSet().getParameterList();
		for (Parameter parameter : parameterList) {
			
			if("UpdatedAttribute".equalsIgnoreCase(parameter.getName()))
			{
				Assert.assertEquals("NAME", parameter.getValue());
			}
			if("NewValue".equalsIgnoreCase(parameter.getName()))
			{
				Assert.assertEquals("34/ASFD/435768//XXXX", parameter.getValue());
			}
		}
		
	}
	
	@Test
	public void transformARMEventToEventNotificationEVCMember() {
	
		ARMEvent event = new ARMEvent();
		
		event.setIclClcSyncId(new BigDecimal(344));
		event.setArmDimName("Service");
		event.setCommonName("34/ASFD/435768//KJ45");
		event.setArmObjectId(new BigDecimal(18209));
		event.setObjectAction("ASSOCIATE");
		event.setResourceSubtype("MEF UNI");
		event.setAssociatedARMObjectName("34/ASFD/435768//YYYY");
		event.setAssociatedArmDimName("Service");
		event.setLastModified(new Timestamp(System.currentTimeMillis()));
		event.setAssociatedServiceType("MEF EVC");
		
		ARMEventToICLEventNotification armEventToICLEventNotification = new ARMEventToICLEventNotification();
		EventNotification transformARMEventToEventNotification = armEventToICLEventNotification.transformARMEventToEventNotification(event);
		
		LOG.info(transformARMEventToEventNotification);
		
		
		Assert.assertEquals("ASSOCIATE", transformARMEventToEventNotification.getAction());
		Assert.assertEquals("34/ASFD/435768//KJ45", transformARMEventToEventNotification.getCommonName());
		
	}
	

}
