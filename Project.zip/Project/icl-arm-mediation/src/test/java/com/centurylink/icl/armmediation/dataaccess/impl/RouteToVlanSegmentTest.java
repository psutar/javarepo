package com.centurylink.icl.armmediation.dataaccess.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.armaccessobject.RouteToVlanSegment;
import com.centurylink.icl.armmediation.dataaccess.RouteToVlanSegmentDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class RouteToVlanSegmentTest {
	
	private RouteToVlanSegmentDAO routeToVlanSegmentDAO;
	
	@Before
	public void setUp()
	{
		routeToVlanSegmentDAO = applicationContext.getBean("routeToVlanSegmentDAO", RouteToVlanSegmentDAO.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	 
	public void testInsert() throws Exception
	{
		RouteToVlanSegment routeToVlanSegment = new RouteToVlanSegment(); 
		routeToVlanSegment.setRouteHeaderId(new Long(131));
		routeToVlanSegment.setVlanSegments("unitTestVlanSeg");
		
		routeToVlanSegmentDAO.insert(routeToVlanSegment);
	} 
}


