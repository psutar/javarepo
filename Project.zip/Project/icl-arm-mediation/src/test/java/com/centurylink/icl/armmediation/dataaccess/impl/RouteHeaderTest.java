package com.centurylink.icl.armmediation.dataaccess.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;
import com.centurylink.icl.armmediation.dataaccess.RouteDetailDAO;
import com.centurylink.icl.armmediation.dataaccess.RouteHeaderDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class RouteHeaderTest {
	
	private RouteHeaderDAO routeHeaderDAO;
	
	@Before
	public void setUp()
	{
		routeHeaderDAO = applicationContext.getBean("routeHeaderDAO", RouteHeaderDAO.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testGetRouteHeaderId() throws Exception
	{
		Long routeId = routeHeaderDAO.getRouteHeaderId("RTE:LVNV0001-LVNV0002-1");
		Long expectedValue = new Long(1);
		Assert.assertEquals(routeId, expectedValue);
	}
	
	@Test
	public void testGetRouteHeaderIdException() throws Exception
	{
		routeHeaderDAO.getRouteHeaderId("invalid route name");
	}
	
	@Test
	public void testGetLikeRouteNames() throws Exception
	{
		List<String> likeRouteNames = routeHeaderDAO.getLikeRouteNames("RTE:LVNV0001-LVNV0002");
		Assert.assertTrue(likeRouteNames.size() > 0);
	}
	
	@Test
	
	public void testInsert() throws Exception
	{
		RouteHeader routeHeader = new RouteHeader();
		routeHeader.setNidDeviceName("unitTestNidDeviceName");
		routeHeader.setRouteName("RTE:unitTestRouteName");
		
		routeHeaderDAO.insert(routeHeader);
	}
	@Test
	public void testLookupRouteHeaderWithoutDetails() throws Exception
	{
		RouteHeader routeHeader = routeHeaderDAO.lookupRouteHeaderWithoutDetails(new Long(304));
		if(null != routeHeader){
		Assert.assertTrue(routeHeader.getRouteName().equalsIgnoreCase("rte:LVNV0010-LVNV0002-9"));
		Assert.assertTrue(routeHeader.getNidDeviceName().equalsIgnoreCase("lvnv010-nid"));
		}
	}
	
	@Test
	public void testLookupRouteByNidDeviceName() throws Exception
	{
		RouteHeader routeHeader = routeHeaderDAO.lookupRouteByNidDeviceName("LVNV051-NID", applicationContext.getBean("routeDetailDAO", RouteDetailDAO.class));
		if(null != routeHeader){
		Assert.assertTrue(routeHeader.getRouteName().startsWith("RTE:LVNV0051-LVNV0002"));
		Assert.assertTrue(routeHeader.getNidDeviceName().equalsIgnoreCase("lvnv051-nid"));
		
		Assert.assertTrue(routeHeader.getRouteDetailList().size() == 5);
		
		String npeName = routeHeader.getRouteDetailList().get(4).getAssetValue();
		Assert.assertTrue(npeName.equalsIgnoreCase("LVNV002-NPE"));
		}
	}
	
	@Test
	public void testLookupRouteByNidDeviceNameNoData() throws Exception
	{
		RouteHeader routeHeader = routeHeaderDAO.lookupRouteByNidDeviceName("nodata", applicationContext.getBean("routeDetailDAO", RouteDetailDAO.class));
		Assert.assertNull(routeHeader);
	}
}


