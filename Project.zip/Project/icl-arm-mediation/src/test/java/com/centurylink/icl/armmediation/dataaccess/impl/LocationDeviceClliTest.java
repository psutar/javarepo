package com.centurylink.icl.armmediation.dataaccess.impl;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.centurylink.icl.armmediation.dataaccess.LocationDeviceClliDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class LocationDeviceClliTest {
	
private LocationDeviceClliDao locationDeviceClliDao;
	
	@Before
	public void setUp()
	{
		locationDeviceClliDao = applicationContext.getBean("locationDeviceClliDao", LocationDeviceClliDao.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	public void testClliSeq()
	{
		String clliLocation ="NLVGNVIJ";
		locationDeviceClliDao.InsertClliSequence(22, clliLocation);
		locationDeviceClliDao.UpdateClliSequence(25, clliLocation);
		//Assert.assertTrue( locationDeviceClliDao.validateClliAsset(clliLocation));
		int i = locationDeviceClliDao.LookupClliSequence(clliLocation);
		 System.out.println("ClliSeq:  " + i + " ClliLocation:  " + clliLocation);
		 System.out.println("This test ran successfully");
	
	}

}
