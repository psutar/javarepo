package com.centurylink.icl.armmediation.service.impl;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.xmlbeans.XmlException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;

import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class TransportPathServiceTest {
	
	private TransportPathServiceImpl transportPathService;
	private JdbcTemplate jdbcTemplate;
	
	@Before
	public void setUp()
	{
		transportPathService = applicationContext.getBean("transportPathService", TransportPathServiceImpl.class);
		DataSource dataSource = applicationContext.getBean("armDatasource", DataSource.class);
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	public void testCreateRouteName()
	{
		String nidClli = "LVNV0010";
		String npeClli = "LVNV0002";
		
		String routeName = transportPathService.createRouteName(nidClli, npeClli);
		Assert.assertTrue(routeName.startsWith("RTE:LVNV0010-LVNV0002-"));
		String integerEnding = routeName.replaceAll("RTE:LVNV0010-LVNV0002-", "");
		Integer.parseInt(integerEnding);
	}
	
	@Test
	public void testCreateRoute() throws Exception
	{
		CreateCircuitRequestDocument requestDocument = CreateCircuitRequestDocument.Factory.parse(new File("src/test/resources/CreateRouteRequest.xml"));
		int numberOfRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_HEADER");
		transportPathService.createRoute(requestDocument);
		int numberOfRoutesNow = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_HEADER");
		Assert.assertTrue(numberOfRoutesNow == (numberOfRoutes + 1));
		int numberOfFirstDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV010-NID'");
		Assert.assertTrue(1 == numberOfFirstDeviceRoutes);
		int numberOfSecondDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-1-TD'");
		Assert.assertTrue(2 == numberOfSecondDeviceRoutes);
		int numberOfExistingFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/1/2' AND ASSET_TYPE='NMI'");
		Assert.assertTrue(1 == numberOfExistingFirstCircuitRoutes);
		String newRouteName = this.jdbcTemplate.queryForObject("SELECT TOP 1 ROUTE_NAME FROM ROUTE_HEADER ORDER BY ROUTE_HEADER_ID DESC", String.class);
		Assert.assertEquals("RTE:LVNV0010-LVNV0002-1", newRouteName);
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testCreateRouteSameRouteAgain() throws Exception
	{
		CreateCircuitRequestDocument requestDocument = CreateCircuitRequestDocument.Factory.parse(new File("src/test/resources/CreateRouteRequest.xml"));
		transportPathService.createRoute(requestDocument);
		Assert.assertTrue("should never get here", false);
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testCreateRouteExsitingFirstCircuit() throws Exception
	{
		CreateCircuitRequestDocument requestDocument = CreateCircuitRequestDocument.Factory.parse(new File("src/test/resources/CreateRouteRequestExistingFirstCircuit.xml"));
		transportPathService.createRoute(requestDocument);
		Assert.assertTrue("should never get here", false);
	}
	
	@Test
	// This test will only insert a new route when the NMI does not exist in the DB.
	// It will still pass when the NMI exists with a route that has a matching NID and second device
	public void testLinkToTransportPathExistingNMI()
	{
		// run the API call which should be successful, but not make DB changes
		int numberOfRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_HEADER");
		transportPathService.linkToTransportPath("CRK/1/1/1", "NMI", "LVNV001-NID", "LVNV001-1-TD");
		// Confirm DB looks the same
		int numberOfRoutesNow = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_HEADER");
		Assert.assertTrue(numberOfRoutesNow == numberOfRoutes);
		int numberOfFirstDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-NID'");
		Assert.assertTrue(1 == numberOfFirstDeviceRoutes);
		int numberOfSecondDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-1-TD'");
		Assert.assertTrue(2 == numberOfSecondDeviceRoutes);
		int numberOfExistingFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/1/1' AND ASSET_TYPE='NMI'");
		Assert.assertTrue(1 == numberOfExistingFirstCircuitRoutes);
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testLinkToTransportPathExistingFirstCircuitBadAssetType()
	{
		// Existing route, but different Asset Type
		transportPathService.linkToTransportPath("CRK/1/1/1", "LAG", "LVNV001-NID", "LVNV001-1-TD");
	}
	
	@Test
	public void testLinkToTransportPathNewFirstCircuitSameAssetType()
	{
		transportPathService.linkToTransportPath("CRK/1/2/1", "NMI", "LVNV001-NID", "LVNV001-1-TD");
		int numberOfFirstDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-NID'");
		Assert.assertTrue(2 == numberOfFirstDeviceRoutes);
		int numberOfSecondDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-1-TD'");
		// This is expected to be 3 because the testCreateRoute method above adds a route with that device.  If that test is moved or modified, this
		// condition may need to be udpated.  We are investigated how to rest the DB after each test so it will be in a specifically know state at 
		// the beginning of each test
		Assert.assertTrue(3 == numberOfSecondDeviceRoutes);
		
		int numberOfExistingFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/1/1'");
		Assert.assertTrue(1 == numberOfExistingFirstCircuitRoutes);
		
		int numberOfNewFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/2/1' AND ASSET_TYPE='NMI'");
		Assert.assertTrue(1 == numberOfNewFirstCircuitRoutes);
		
		String newRouteName = this.jdbcTemplate.queryForObject("SELECT TOP 1 ROUTE_NAME FROM ROUTE_HEADER ORDER BY ROUTE_HEADER_ID DESC", String.class);
		Assert.assertEquals("RTE:LVNV0001-LVNV0002-2", newRouteName);
	}
	
	@Test
	public void testLinkToTransportPathNewFirstCircuitDifferentAssetType()
	{
		transportPathService.linkToTransportPath("CRK/1/3/1", "LAG", "LVNV001-NID", "LVNV001-1-TD");
		int numberOfFirstDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-NID'");
		Assert.assertTrue(3 == numberOfFirstDeviceRoutes);
		int numberOfSecondDeviceRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'LVNV001-1-TD'");
		// This is expected to be 3 because the testCreateRoute method above adds a route with that device.  If that test is moved or modified, this
		// condition may need to be udpated.  We are investigated how to rest the DB after each test so it will be in a specifically know state at 
		// the beginning of each test
		Assert.assertTrue(4 == numberOfSecondDeviceRoutes);
		
		int numberOfExistingFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/1/1'");
		Assert.assertTrue(1 == numberOfExistingFirstCircuitRoutes);
		
		int numberOfNewFirstCircuitRoutes = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/3/1' AND ASSET_TYPE='LAG'");
		Assert.assertTrue(1 == numberOfNewFirstCircuitRoutes);
		
		int numberOfNewFirstCircuitRoutesNmi = this.jdbcTemplate.queryForInt("SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_VALUE = 'CRK/1/3/1' AND ASSET_TYPE='NMI'");
		Assert.assertTrue(0 == numberOfNewFirstCircuitRoutesNmi);
		
		String newRouteName = this.jdbcTemplate.queryForObject("SELECT TOP 1 ROUTE_NAME FROM ROUTE_HEADER ORDER BY ROUTE_HEADER_ID DESC", String.class);
		Assert.assertEquals("RTE:LVNV0001-LVNV0002-3", newRouteName);
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testLinkToTransportPathBadSecondDevice()
	{
		transportPathService.linkToTransportPath("CKR/5/1/1", "NMI", "LVNV051-NID", "LVNV001-1-TDbad");
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testLinkToTransportPathBadNid()
	{
		transportPathService.linkToTransportPath("CKR/5/1/1", "NMI", "LVNV051-NIDbad", "LVNV001-1-TD");
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testLinkToTransportPathNoExistingRouteForNid()
	{
		transportPathService.linkToTransportPath("nmiNotInDb", "NMI", "LVNV051-NIDbad", "LVNV001-1-TD");
	}
	
	@Test(expected=ICLRequestValidationException.class)
	public void testLinkToTransportPathExistingRouteHasDifferentSecondDevice()
	{
		transportPathService.linkToTransportPath("nmiNotInDb", "NMI", "LVNV051-NID", "LVNV001-1-TDbad");
	}
	
	@Test
	public void testSearchRouteExists() throws Exception
	{
		SearchResourceRequestDocument requestDocument = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchRouteRequestExisting.xml"));
		SearchResourceResponseDocument responseDocument = transportPathService.searchRoute(requestDocument);
		Assert.assertEquals(responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().size(), 1);
		SearchResponseDetails responseDetails = responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
		Assert.assertEquals(responseDetails.getCircuitList().size(), 1);
		SubNetworkConnection circuit = responseDetails.getCircuitList().get(0);
		Assert.assertEquals(circuit.getCommonName(), "RTE:HNSONVVI01W-HNSNNVXF05W-1");
		Assert.assertEquals(circuit.getObjectID(), "749");
		Assert.assertEquals(circuit.getSourceSystem(), "ARM");
	}	
	
	@Test(expected=OSSDataNotFoundException.class)
	public void testSearchRouteOSSDataNotFound() throws Exception
	{
		SearchResourceRequestDocument requestDocument = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchRouteRequestOssNoData.xml"));
		transportPathService.searchRoute(requestDocument);
		Assert.assertTrue("should never get here", false);
	}	
}
