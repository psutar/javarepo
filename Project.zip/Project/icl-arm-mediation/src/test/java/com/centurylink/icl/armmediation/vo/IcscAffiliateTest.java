package com.centurylink.icl.armmediation.vo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.centurylink.icl.armmediation.valueobjects.objects.IcscAffiliate;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class IcscAffiliateTest {
	
	@Test
	public void testIcscAffiliatForAList()
	{
		List<IcscAffiliate> icscAffiliateList = IcscAffiliate.getIcscAffiliateListByQuery("AFFILIATE_NAME='A_NAME'");
		assertNotNull(icscAffiliateList);
		assertEquals(1,icscAffiliateList.size());
		assertEquals("3",icscAffiliateList.get(0).getIcscAffiliateId());
	}
	
	@Test
	public void testIcscAffiliateWithPrimaryKey()
	{
		IcscAffiliate icscAffiliate = new IcscAffiliate("3");
		assertTrue(icscAffiliate.isInstanciated());
		assertEquals("A_NAME",icscAffiliate.getAffiliateName());
		assertEquals("AAAA",icscAffiliate.getIcscCode());
		assertEquals("3",icscAffiliate.getIcscAffiliateId());
	}
		
	@Test
	public void testIcscAffiliateForFailureScenario()
	{
		IcscAffiliate icscAffiliate = new IcscAffiliate("4");
		assertFalse(icscAffiliate.isInstanciated());
	}
	
	@Test
	public void testIcscAffiliateByIcsc()
	{
		List<IcscAffiliate> icscAffiliateList = IcscAffiliate.getIcscAffiliateListByIcsc("AAAA");
		assertNotNull(icscAffiliateList);
		assertEquals(1,icscAffiliateList.size());
		assertEquals("3",icscAffiliateList.get(0).getIcscAffiliateId());
	}
}
