package com.centurylink.icl.armmediation.dataaccess.impl;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;
import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;
import com.centurylink.icl.armmediation.dataaccess.RouteDetailDAO;
import com.centurylink.icl.armmediation.dataaccess.RouteHeaderDAO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringEmbedded-Context.xml" })

public class RouteDetailTest {
	
	private RouteDetailDAO routeDetailDAO;
	
	@Before
	public void setUp()
	{
		routeDetailDAO = applicationContext.getBean("routeDetailDAO", RouteDetailDAO.class);
	}
	
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testValidateRouteAssetTrue() throws Exception
	{
		Assert.assertTrue(routeDetailDAO.validateRouteAsset("NID", "LVNV001-NID"));
	}
	
	@Test
	public void testValidateRouteAssetFalse() throws Exception
	{
		Assert.assertFalse(routeDetailDAO.validateRouteAsset("NID", "LVNV010-NIDxyz"));
	}
	
	@Test	
	public void testInsert() throws Exception
	{
		
		RouteDetail routeDetail = new RouteDetail();		
		routeDetail.setRouteHeaderId(new Long(131));
		routeDetail.setSeqNo(100);
		routeDetail.setAssetObject("DEVICE");
		routeDetail.setAssetType("NID");
		routeDetail.setAssetValue("unitTestNID");
		routeDetailDAO.insert(routeDetail);
		Assert.assertTrue(routeDetailDAO.validateRouteAsset("NID", "unitTestNID"));
		System.out.println("This test ran successfully");
		
	
	}
	
	@Test
	public void testLookupRouteDetailByNmi() throws Exception
	{
		List<RouteDetail> routeDetailList = routeDetailDAO.lookupRouteDetailByFirstCircuitName("CRK/1/1/1");
		Assert.assertTrue(5 == routeDetailList.size());
		
		routeDetailList = routeDetailDAO.lookupRouteDetailByFirstCircuitName("abcde123456");
		Assert.assertTrue(0 == routeDetailList.size());
	}
	
	@Test
	public void testLookupRouteDetailByHeaderId() throws Exception
	{
		List<RouteDetail> routeDetailList = routeDetailDAO.lookupRouteDetailByRouteHeaderId(new Long(363));
		if(routeDetailList.size() == 5)
		Assert.assertTrue(5 == routeDetailList.size());
	}
}


