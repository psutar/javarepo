package com.centutylink.icl.armmediation.test;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;


	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class UpdateProvisionstatusTest
	{
		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testUpdateProvisionstatus() throws Exception
		{
			System.out.println("------- Inside  testUpdateProvisionstatus");
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, "UpdateProvisionStatusFromMDW");
			iHashMap.put(MDWConstants.DIM_OBJECT, "Port");
			iHashMap.put(MDWConstants.OBJECT_ID, "405");
			iHashMap.put(MDWConstants.STATUS_ID, "1900000011");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(null,iHashMap);
			//Assert.assertNull(object);
			System.out.println(object);
		}
		
	}
