package com.centutylink.icl.armmediation.test;

import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;


	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class SetPortDirectionTest
	{
		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testCreateDevice() throws Exception
		{
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.PORT_DIRECTION);
			iHashMap.put(MDWConstants.NODE_ID, "786");
			iHashMap.put(MDWConstants.PORTDIRECTION, "NF");
			iHashMap.put(MDWConstants.META_DATA_REQUIRED, "True");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(null,iHashMap);
			CreateDeviceResponseDocument response = (CreateDeviceResponseDocument) object;
			Assert.assertEquals("SUCCESS", response.getCreateDeviceResponse().getMessageElements().getMessageStatus());
			System.out.println(response);
		}
	
	}
