package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class SearchDeviceTest
{

	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testSearchDeviceSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchDeviceRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetDevice");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
	}
	@Test
	public void testAlarmEnrichmentVO() throws Exception
	{
		 SearchResourceRequestDocument	request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/AlarmEnrichmentRequest.xml"));
		
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetAlarmEnrichmentVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object 	object = armServiceImpl.call(request, iHashMap);
		
		@SuppressWarnings("unchecked")
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		//Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
		System.out.println("Response for GetAlarmEnrichment Operation");
		System.out.println(response.toString());
		
	}
	@Test
	public void testSearchDeviceDetailsSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/NICNtmDeviceDetailRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetDeviceDetails");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
	}
	
	@Test
	public void testSearchDeviceVOSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchDeviceVORequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetDeviceVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertNotNull(response);
	}

        @Test
	public void testPreferredCompatibleONTModelsVOSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchDeviceVORequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "FetchPreferredCompatibleONTModelsVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		System.out.println("response : " + response);
		Assert.assertNotNull(response);
	}
	
}