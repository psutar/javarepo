package com.centutylink.icl.armmediation.test;

import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;


	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class UpdatePortSFPAttributeTest
	{
		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testUpdatePortSFPAttribute() throws Exception
		{
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, "UpdatePortSFPAttributeFromMDW");
			iHashMap.put(MDWConstants.PORT_ID, "327");
			iHashMap.put(MDWConstants.SFP_NAME, "SFP-2");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(null,iHashMap);
			//Assert.assertNull(object);
			System.out.println(object);
		}
	
	}
