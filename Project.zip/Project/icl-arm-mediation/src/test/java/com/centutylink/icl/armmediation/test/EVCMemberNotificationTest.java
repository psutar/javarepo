package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.centurylink.icl.armmediation.service.impl.EvcMemberNotificationService;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })


public class EVCMemberNotificationTest extends TestCase
{
	
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testEvcMemberNotification() throws Exception
	{
		
		EvcMemberNotificationService evcMemberNotificationService=new EvcMemberNotificationService();
		evcMemberNotificationService.getEvcMemberNotification("60/VLFS/625496//CTRL", "60/L1XX/624936//CTRL","ADD");

	}
	
}
