package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class CreateCircuitTest 
	{

		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testCreateCircuit() throws Exception
		{
			CreateCircuitRequestDocument request = CreateCircuitRequestDocument.Factory.parse(new File("src/test/resources/CreateCircuitRequest.xml"));
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, "CreateCircuit");
			iHashMap.put(MDWConstants.CIRCUIT_NAME, "TestSwapna222");
			iHashMap.put(MDWConstants.CIRCUIT_TYPE_ID, "150000054");
			iHashMap.put(MDWConstants.CIRCUIT_START_PORT_ID, "104");
			iHashMap.put(MDWConstants.CIRCUIT_END_PORT_ID, "208");
			iHashMap.put(MDWConstants.KBPS_VALUE, "10240");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(request, iHashMap);
			//Assert.assertNotNull(object);
			System.out.println(object);
		}
	}

	

