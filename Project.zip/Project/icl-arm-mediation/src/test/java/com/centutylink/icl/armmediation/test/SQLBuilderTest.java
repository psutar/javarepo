package com.centutylink.icl.armmediation.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.centurylink.icl.armmediation.helper.SQLBuilder;

public class SQLBuilderTest
{

	private static final String LOCATION = "LOCATION";
	private static final String LOCATIONTYPE = "LOCATIONTYPE";

	private static final String LOCATIONID = "locationid";
	private static final String LOCATION2LOCATIONTYPE = "location2locationtype";

	private static final String LOCATIONTYPEID = "locationtypeid";

	private static final String NAME = "name";

	@Test
	public void testBasic()
	{
		SQLBuilder sql = new SQLBuilder(LOCATION);

		sql.addField(NAME).addField(LOCATIONID).eq(NAME, "USA");

		System.out.println(sql.prettyPrint());

		assertTrue(sql.getStatement().equals("SELECT name, locationid FROM LOCATION WHERE name = 'USA'"));
	}

	@Test
	public void testAlias()
	{
		SQLBuilder sql = new SQLBuilder(LOCATION, "loc");

		sql.addField(NAME, "locname").addField(LOCATIONID, "locid").eq(NAME, "USA");

		System.out.println(sql.prettyPrint());

		assertTrue(sql.getStatement().equals("SELECT name locname, locationid locid FROM LOCATION loc WHERE name = 'USA'"));
	}

	@Test
	public void testJoin()
	{
		SQLBuilder sql = new SQLBuilder(LOCATION);

		sql.addFieldFromTable(LOCATION, NAME).addFieldFromTable(LOCATION, LOCATIONID).addFieldFromTable(LOCATIONTYPE, NAME).addFieldFromTable(LOCATIONTYPE, LOCATIONTYPEID).addTable(LOCATIONTYPE).eq(
				LOCATION, LOCATION2LOCATIONTYPE, LOCATIONTYPE, LOCATIONTYPEID).eq(LOCATION, NAME, "USA");

		System.out.println(sql.prettyPrint());

		assertTrue(sql.getStatement().equals(
				"SELECT LOCATION.name, LOCATION.locationid, LOCATIONTYPE.name, LOCATIONTYPE.locationtypeid FROM LOCATION, LOCATIONTYPE WHERE LOCATION.location2locationtype = LOCATIONTYPE.locationtypeid AND LOCATION.name = 'USA'"));
	}
}
