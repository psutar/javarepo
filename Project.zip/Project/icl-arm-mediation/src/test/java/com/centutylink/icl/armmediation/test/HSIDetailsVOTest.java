package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import junit.framework.Assert;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class HSIDetailsVOTest 
{
	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	public void testHSIDetailsVOSuccess() throws Exception
	{

	HashMap<String, Object> hashMap = new HashMap<String, Object>();
	hashMap.put("VLANNumber", "789");
	hashMap.put("DeviceName", "NID_110403");
	hashMap.put("methodName", "HSIRouteVOService");
	ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
	Object object = armServiceImpl.call(null, hashMap);
	SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
	System.out.println(response);
	Assert.assertNotNull(response);
	
	}
	
	@Test
	public void testHSIServiceVOSuccess() throws Exception
	{
	SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/HSIServiceDetails.xml"));
	HashMap<String, Object> hashMap = new HashMap<String, Object>();
	hashMap.put("methodName", "GetServiceVO");
	ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
	Object object = armServiceImpl.call(request, hashMap);
	SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
	System.out.println(response);
	Assert.assertNotNull(response);
	
	}
	
}
