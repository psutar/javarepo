package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.CreatePartyRequestDocument;
import com.iclnbi.iclnbiV200.CreatePartyResponseDocument;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })

public class CreatePartyTest {
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testCreatePartySuccess() throws Exception
	{
		CreatePartyRequestDocument request = CreatePartyRequestDocument.Factory.parse(new File("src/test/resources/CreatePartyRequest.xml"));
		System.out.println(request);
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, "CreateParty");
		iHashMap.put(MDWConstants.ENTITY, "Party");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		CreatePartyResponseDocument response = (CreatePartyResponseDocument) object;
		//Assert.assertEquals("SUCCESS", response.getCreateLocationResponse().getMessageElements().getMessageStatus());
		System.out.println(object);

	}
}


