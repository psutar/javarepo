package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class SearchCircuitTest
{
	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testSearchCircuitSummarySuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchCircuitRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetCircuitSummary");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
	}
	
	@Test
	public void testSearchCircuitDetailsSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/NICNtmCircuitDetailRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetCircuitDetail");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
	}
	
	@Test
	public void testSearchCircuitVOSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/SearchCircuitVORequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put("methodName", "GetCircuitVO");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		Assert.assertNotNull(response);
	}

}
