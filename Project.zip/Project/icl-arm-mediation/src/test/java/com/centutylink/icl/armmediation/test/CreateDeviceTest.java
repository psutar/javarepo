package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class CreateDeviceTest
	{

		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testCreateDevice() throws Exception
		{
			CreateDeviceRequestDocument request = CreateDeviceRequestDocument.Factory.parse(new File("src/test/resources/CreateDeviceRequest.xml"));
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.CREATE_DEVICE);
			iHashMap.put(MDWConstants.LOCATION_ID, "507");
			iHashMap.put(MDWConstants.DEVICE_DEF_ID, "1610007271");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(request, iHashMap);
			//Assert.assertNotNull(object);
			System.out.println(object);
		}
	}

	
