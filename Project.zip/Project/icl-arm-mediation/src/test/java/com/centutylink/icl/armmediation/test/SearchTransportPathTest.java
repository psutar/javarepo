package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;



	
	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class SearchTransportPathTest extends TestCase
	{
		
		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testTransportPath() throws Exception
		{
			
			SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/TranportPathRequest.xml"));

			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put("methodName", "DiscoverTransportPath");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(request, iHashMap);
			SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
			assertNotNull(response);
			System.out.println("Response for SearchTransportPath Operation");
			System.out.println(response);

		}
	
	
}
