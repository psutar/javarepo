package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.DeleteLocationRequestDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class DeleteLocationTest
{

	@Autowired
	ApplicationContext applicationContext;
	
	@Test
	public void testDeleteLocationSuccess() throws Exception
	{
		DeleteLocationRequestDocument request = DeleteLocationRequestDocument.Factory.parse(new File("src/test/resources/DeleteLocationRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, "DeleteLocation");
		iHashMap.put(MDWConstants.ENTITY, "Location");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		System.out.println("Request  ::::::::::::::::  "+request);
		Object object = armServiceImpl.call(request, iHashMap);
		System.out.println(object);
	}
}


