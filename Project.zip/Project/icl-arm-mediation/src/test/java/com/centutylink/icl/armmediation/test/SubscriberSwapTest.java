package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.List;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.dataaccess.SearchCircuitDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchServiceDAO;
import com.centurylink.icl.armmediation.service.impl.SubscriberSwapService;

import com.centurylink.icl.clc.routinggroup.util.CustomerSwapFailedMessage;

import com.centurylink.icl.iclaction.ICLActionRequestDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })

public class SubscriberSwapTest 
{
	@Autowired
	ApplicationContext applicationContext;

	
	public void printIds(List<Long> ids)
	{
		System.out.println("Ids = " + ids.size());
		for (Long id: ids)
		{
			System.out.println("Id = " + id);
		}
	}
	@Test
	public void testSearchCircuitDAOFail() throws Exception
	{
		final String TEST_SUBSCRIBER = "KIRKS";  // Invalid Subscriber
		
		SearchCircuitDAO searchCircuitDAO = (SearchCircuitDAO) applicationContext.getBean("searchCircuitDAO", SearchCircuitDAO.class);
		List<Long> circuitIds = searchCircuitDAO.getCircuitIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(circuitIds);
		
		Assert.assertEquals(circuitIds.size(), 0);
	}
	
	@Test
	public void testSearchCircuitDAOSuccess() throws Exception
	{
		final String TEST_SUBSCRIBER = "LP8";	// Valid subscriber
		
		SearchCircuitDAO searchCircuitDAO = (SearchCircuitDAO) applicationContext.getBean("searchCircuitDAO", SearchCircuitDAO.class);
		List<Long> circuitIds = searchCircuitDAO.getCircuitIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(circuitIds);
		
		Assert.assertEquals(circuitIds.size(), 1);
		Assert.assertTrue(circuitIds.get(0).equals(165L));
	}

	@Test
	public void testSearchDeviceDAOFail() throws Exception
	{
		final String TEST_SUBSCRIBER = "KIRKS";  // Invalid Subscriber
		
		SearchDeviceDAO searchDeviceDAO = (SearchDeviceDAO) applicationContext.getBean("searchDeviceDAO", SearchDeviceDAO.class);
		List<Long> deviceIds = searchDeviceDAO.getDeviceIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(deviceIds);
		
		Assert.assertEquals(deviceIds.size(), 0);
	}
	
	@Test
	public void testSearchDeviceDAOSuccess() throws Exception
	{
		final String TEST_SUBSCRIBER = "ZTT";	// Valid subscriber
		
		SearchDeviceDAO searchDeviceDAO = (SearchDeviceDAO) applicationContext.getBean("searchDeviceDAO", SearchDeviceDAO.class);
		List<Long> deviceIds = searchDeviceDAO.getDeviceIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(deviceIds);
		
		Assert.assertEquals(deviceIds.size(), 3);
		Assert.assertTrue(deviceIds.contains(6102L));
		Assert.assertTrue(deviceIds.contains(6103L));
		Assert.assertTrue(deviceIds.contains(6104L));
	}

	@Test
	public void testSearchServiceDAOFail() throws Exception
	{
		final String TEST_SUBSCRIBER = "KIRKS";  // Invalid Subscriber
		
		SearchServiceDAO searchServiceDAO = (SearchServiceDAO) applicationContext.getBean("searchServiceDAO", SearchServiceDAO.class);
		List<Long> serviceIds = searchServiceDAO.getServiceIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(serviceIds);
		
		Assert.assertEquals(serviceIds.size(), 0);
	}
	
	@Test
	public void testSearchServiceDAOSuccess() throws Exception
	{
		final String TEST_SUBSCRIBER = "A000100";	// Valid subscriber
		
		SearchServiceDAO searchServiceDAO = (SearchServiceDAO) applicationContext.getBean("searchServiceDAO", SearchServiceDAO.class);
		List<Long> serviceIds = searchServiceDAO.getServiceIdsBySubscriber(TEST_SUBSCRIBER);
		
		printIds(serviceIds);
		
		Assert.assertEquals(serviceIds.size(), 2);
		Assert.assertTrue(serviceIds.contains(715L));
		Assert.assertTrue(serviceIds.contains(3059L));
	}
	
	@Test
	public void testSubscriberSwapServiceSuccess() throws Exception
	{		
		ICLActionRequestDocument request = ICLActionRequestDocument.Factory.parse(new File("src/test/resources/SubscriberSwapRequestSuccess.xml"));
		
		SubscriberSwapService subscriberSwapService = (SubscriberSwapService) applicationContext.getBean("subscriberSwapService", SubscriberSwapService.class);
		List<CustomerSwapFailedMessage> errors = subscriberSwapService.swapSubscriber(request);
		
		Assert.assertEquals(errors.size(), 0);
	}
	
	@Test
	public void testSubscriberSwapServiceFail() throws Exception
	{		
		ICLActionRequestDocument request = ICLActionRequestDocument.Factory.parse(new File("src/test/resources/SubscriberSwapRequestFail.xml"));
		
		SubscriberSwapService subscriberSwapService = (SubscriberSwapService) applicationContext.getBean("subscriberSwapService", SubscriberSwapService.class);
		List<CustomerSwapFailedMessage> errors = subscriberSwapService.swapSubscriber(request);
		
		Assert.assertEquals(errors.size(), 1);
	}
}
