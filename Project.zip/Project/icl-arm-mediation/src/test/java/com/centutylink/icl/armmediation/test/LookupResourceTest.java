package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class LookupResourceTest
{

	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testLookupDeviceSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/LookupDeviceRequest.xml"));

		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, "ArmLookup");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		System.out.println(response);
		Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
		
	}
	
	@Test
	public void testLookupDeviceFromMDWSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME,MDWConstants.ARM_LOOKUP);
        iHashMap.put(MDWConstants.ENTITY, MDWConstants.DEVICE);
        iHashMap.put(MDWConstants.DEVICE_NAME,"MDWconstructedDevicename");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		//Assert.assertNotNull(object);
		System.out.println(object);
	}

	@Test
	public void testLookupCircuitSuccess() throws Exception
	{
		SearchResourceRequestDocument request = SearchResourceRequestDocument.Factory.parse(new File("src/test/resources/LookupCircuitRequest.xml"));

		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, "ArmLookup");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		SearchResourceResponseDocument response = (SearchResourceResponseDocument) object;
		System.out.println(response);
		//Assert.assertEquals("SUCCESS", response.getSearchResourceResponse().getMessageElements().getMessageStatus());
	}

	@Test
	public void testLookupLocationMDWSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		
        iHashMap.put(MDWConstants.ENTITY, MDWConstants.LOCATION);
        iHashMap.put(MDWConstants.LOCATION_CLLI, "223498");

		
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		Assert.assertNotNull(object);
		System.out.println(object);
	}
	
	@Test
	public void testLookupHecigMDWSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.HECIG);
        iHashMap.put(MDWConstants.HESIG_CODE, "CABACDARM");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		Assert.assertNotNull(object);
		System.out.println(object);
	}
	
	@Test
	public void testLookupCiruitNameMDWSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.CIRCUIT);
        iHashMap.put(MDWConstants.CIRCUIT_NAME, "Unrouted Ethernet Bearer_2");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		Assert.assertNotNull(object);
		System.out.println(object);
	}
	
	@Test
	public void testLookupServiceMDWSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.SERVICE);
        iHashMap.put(MDWConstants.SERVICE_NAME, "Service1");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		//Assert.assertNotNull(object);
		System.out.println(object);
	}
	
	@Test
	public void testLookupPortSuccess() throws Exception
	{

		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY,MDWConstants.PORT);
		iHashMap.put(MDWConstants.PORT_ID,"102");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null,iHashMap);
		Assert.assertNotNull(object);
		System.out.println("****************"+object);
	}
	
	@Test
	public void testLookupCircuitTypeSuccess() throws Exception
	{

		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY,MDWConstants.CIRCUIT_TYPE);
		iHashMap.put(MDWConstants.CIRCUIT_TYPE_NAME,"ATM Bearer");
		
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null,iHashMap);
		Assert.assertNotNull(object);
		System.out.println("****************"+object);
	}
	
	@Test
	public void testLookupCircuitOnPortSuccess() throws Exception
	{

		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY,MDWConstants.CIRCUIT_ON_PORT);
		iHashMap.put(MDWConstants.PORT_ID,"111");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null,iHashMap);
		Assert.assertNotNull(object);
		System.out.println("****************"+object);
	}
	
	@Test
	public void testLookupBandwidthSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
        iHashMap.put(MDWConstants.ENTITY, MDWConstants.BANDWIDTH);
        iHashMap.put(MDWConstants.KBPS_VALUE , "3456");

		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		Assert.assertNotNull(object);
		System.out.println(object);
	}
	
	@Test
	public void testLookupServiceTypeSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.SERVICE_TYPE);
        iHashMap.put(MDWConstants.SERVICE_TYPE_NAME, "MEF UNI");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);

		Assert.assertNotNull(object);
		
		Map temp = (HashMap)object;
		Integer errorCode = (Integer)temp.get("errorCode");
		System.out.println("errorCode  :  "+ errorCode);
		Assert.assertEquals(new Integer(0),errorCode);
		
		System.out.println(object);
	}
	
	@Test
	public void testLookupSubscriberSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.SUBSCRIBER);
        iHashMap.put(MDWConstants.SUBSCRIBER_NAME, "Test_Subscriber_1");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		
		Assert.assertNotNull(object);
		
		Map temp = (HashMap)object;
		Integer errorCode = (Integer)temp.get("errorCode");
		System.out.println("errorCode  :  "+ errorCode);
		Assert.assertEquals(new Integer(0),errorCode);
		
		System.out.println(object);
	}
	
	@Test
	public void testLookupStatusSuccess() throws Exception
	{
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		
		iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ARM_LOOKUP);
		iHashMap.put(MDWConstants.ENTITY, MDWConstants.STATUS);
        iHashMap.put(MDWConstants.STATUS_NAME, "Configured");
        iHashMap.put(MDWConstants.DIM_OBJECT, "Port");

        ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(null, iHashMap);
		
		Map temp = (HashMap)object;
		Integer errorCode = (Integer)temp.get("errorCode");
		System.out.println("errorCode  :  "+ errorCode);
		Assert.assertEquals(new Integer(0),errorCode);
		
		System.out.println(object);
	}


}
