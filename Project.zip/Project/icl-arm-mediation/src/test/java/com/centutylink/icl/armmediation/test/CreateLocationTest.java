package com.centutylink.icl.armmediation.test;

import java.io.File;
import java.util.HashMap;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;
import com.iclnbi.iclnbiV200.CreateLocationResponseDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
public class CreateLocationTest
{

	@Autowired
	ApplicationContext applicationContext;

	@Test
	public void testCreateLocationSuccess() throws Exception
	{
		CreateLocationRequestDocument request = CreateLocationRequestDocument.Factory.parse(new File("src/test/resources/CreateLocationRequest.xml"));
		HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(MDWConstants.METHOD_NAME, "CreateLocation");
		iHashMap.put(MDWConstants.ENTITY, "Location");
		ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
		Object object = armServiceImpl.call(request, iHashMap);
		CreateLocationResponseDocument response = (CreateLocationResponseDocument) object;
		//Assert.assertEquals("SUCCESS", response.getCreateLocationResponse().getMessageElements().getMessageStatus());
		System.out.println(object);
	}
}
