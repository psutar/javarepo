package com.centutylink.icl.armmediation.test;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.service.impl.ARMMediationServiceImpl;


	@RunWith(SpringJUnit4ClassRunner.class)
	@ContextConfiguration(locations = { "classpath:/META-INF/spring/SpringTest-Context.xml" })
	public class AddObjectToServiceTest {
		@Autowired
		ApplicationContext applicationContext;

		@Test
		public void testaddObjectToService() throws Exception
		{
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(MDWConstants.METHOD_NAME, MDWConstants.ADD_OBJECT_TO_SERVICE);
			iHashMap.put(MDWConstants.SERVICE_ID, "301");
			iHashMap.put(MDWConstants.OBJECT_ID, "204");
			iHashMap.put(MDWConstants.DIM_OBJECT, "Port");
			iHashMap.put(MDWConstants.RELATIONSHIP_NAME, "MEF UNI - UNI Port");
			ARMMediationServiceImpl armServiceImpl = applicationContext.getBean("service", ARMMediationServiceImpl.class);
			Object object = armServiceImpl.call(null,iHashMap);
			System.out.println(object);
		}
	
	}
