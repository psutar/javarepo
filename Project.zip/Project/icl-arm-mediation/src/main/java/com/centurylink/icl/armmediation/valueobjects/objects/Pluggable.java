package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Pluggable extends AbstractReadOnlyTable {
	
	private static final Log LOG = LogFactory.getLog(Pluggable.class);
	
	private static final String PULUGGABLENAME = "NAME";
	private static final String PLUGGABLEID = "PLUGGABLEID";
	private static final String PLUGGABLE2PLUGGABLETYPE = "PLUGGABLE2PLUGGABLETYPE";
	
	public Pluggable()
	{
		super();
		this.tableName = "PLUGGABLE";
	}

	public Pluggable(String pluggableId)
	{
		this();
		primaryKey.setValue(pluggableId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	@Override
	public void populateModel() {
		fields.put(PLUGGABLEID, new Field(PLUGGABLEID, Field.TYPE_NUMERIC));
		fields.put(PULUGGABLENAME, new Field(PULUGGABLENAME, Field.TYPE_VARCHAR));
		fields.put(PLUGGABLE2PLUGGABLETYPE, new Field(PLUGGABLE2PLUGGABLETYPE, Field.TYPE_NUMERIC));
		primaryKey = new PrimaryKey(fields.get(PLUGGABLEID));
	}

	public void setPluggable2PluggableType(String pluggable2PluggableType)
	{
		setField(PLUGGABLE2PLUGGABLETYPE,pluggable2PluggableType);
	}

	public String getPluggable2PluggableType()
	{
		return getFieldAsString(PLUGGABLE2PLUGGABLETYPE);
	}
	
	public void setPluggablename(String pluggableName)
	{
		setField(PULUGGABLENAME,pluggableName);
	}

	public String getPluggablename()
	{
		return getFieldAsString(PULUGGABLENAME);
	}
	
	public void setPluggableid(String pluggableid)
	{
		setField(PLUGGABLEID,pluggableid);
	}

	public String getPluggableid()
	{
		return getFieldAsString(PLUGGABLEID);
	}

	public String getPluggableByName(String sfpName) 	
	{
		String query = "NAME =  '"+ sfpName + "'";
		Pluggable pluggable = new Pluggable();
		List<Map<String,Object>> pluggableList = pluggable.getFullRecordsByQuery(query);
		String pluggableTypeId = null;
		for (Map<String,Object> pluggableObj : pluggableList)
		{
			if(null != pluggableObj.get(PLUGGABLE2PLUGGABLETYPE)){
				pluggableTypeId = pluggableObj.get(PLUGGABLE2PLUGGABLETYPE).toString();
				return pluggableTypeId;
			}
		}		
		return pluggableTypeId;		
	}
}
