package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class ServiceExtension extends AbstractReadOnlyTable {

	private static final String MAXNUMOVCS = "MAXNUMOVCS";
	private static final String MEFSERVICETYPE = "MEFSERVICETYPE";
	private static final String CONTROLLINGCOMPANY = "CONTROLLINGCOMPANY";
	private static final String CEVLAN = "CEVLAN";
	private static final String CEVLANIDPRESERVATION = "CEVLANIDPRESERVATION";
	private static final String SECNCICODE = "SECNCICODE";
	private static final String MAXNUMOVCENDPOINTSPEROVC = "MAXNUMOVCENDPOINTSPEROVC";
	private static final String UNICASTFRAMEDELIVERY = "UNICASTFRAMEDELIVERY";
	private static final String EVCOVCREFERENCE = "EVCOVCREFERENCE";
	private static final String SITE_ROLE = "SITE_ROLE";
	private static final String NCCODE = "NCCODE";
	private static final String HPC = "HPC";
	private static final String IS_DIVERSE = "IS_DIVERSE";
	private static final String MULTICASTFRAMEDELIVERY = "MULTICASTFRAMEDELIVERY";
	private static final String TYPE = "TYPE";
	private static final String COS_ID = "COS_ID";
	private static final String MAXNUMUNIOVCENDPOINTS = "MAXNUMUNIOVCENDPOINTS";
	private static final String OTC = "OTC";
	private static final String CTLSERVICETYPE = "CTLSERVICETYPE";
	private static final String FRAMEFORMAT = "FRAMEFORMAT";
	private static final String MCO = "MCO";
	private static final String MAXIMUMUNIS = "MAXIMUMUNIS";
	private static final String CEVLANCOSPRESERVATION = "CEVLANCOSPRESERVATION";
	private static final String BUNDLING = "BUNDLING";
	private static final String COS_VALUE = "COS_VALUE";
	private static final String NCICODE = "NCICODE";
	private static final String SERVICESUBTYPE = "SERVICESUBTYPE";
	private static final String STI = "STI";
	private static final String CUSTOMERSERIALNUMBER = "CUSTOMERSERIALNUMBER";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String SPECCODE = "SPECCODE";
	private static final String CIRCUITSERIALNUMBER = "CIRCUITSERIALNUMBER";
	private static final String BW = "BW";
	private static final String EVCOVCNC = "EVCOVCNC";
	private static final String ROLE = "ROLE";
	private static final String SERVICEMUX = "SERVICEMUX";
	private static final String CUSTACCTBAN = "CUSTACCTBAN";
	private static final String BROADCASTFRAMEDELIVERY = "BROADCASTFRAMEDELIVERY";
	private static final String EVCMTU = "EVCMTU";
	private static final String MAXNUMEVCS = "MAXNUMEVCS";
	private static final String RPPLANID = "RPPLANID";
	private static final String TOPOLOGY_TYPE = "TOPOLOGY_TYPE";
	private static final String SVLAN2OVCENDPOINT = "SVLAN2OVCENDPOINT";
	private static final String COLORFORWARDING = "COLORFORWARDING";
	private static final String OVCMTU = "OVCMTU";
	private static final String SVLANIDPRESERVATION = "SVLANIDPRESERVATION";
	private static final String ISMEETPOINTEVC = "ISMEETPOINTEVC";
	private static final String MAXNUMENNIOVCENDPOINTS = "MAXNUMENNIOVCENDPOINTS";
	private static final String DIVERSE_UNI_ID = "DIVERSE_UNI_ID";
	private static final String IP_ROUTING_PROTOCOLNAME = "IP_ROUTING_PROTOCOLNAME";
	private static final String COSNAME = "COSNAME";
	private static final String SERVICEID = "SERVICEID";
	private static final String LABEL = "LABEL";
	private static final String CEVLAN2EVC = "CEVLAN2EVC";
	private static final String LOS_NAME = "LOS_NAME";
	private static final String ICO = "ICO";
	private static final String HPCEXPIRATIONDATE = "HPCEXPIRATIONDATE";
	private static final String ALLTO1BUNDLING = "ALLTO1BUNDLING";
	private static final String SVLANCOSPRESERVATION = "SVLANCOSPRESERVATION";
	private static final String TSP = "TSP";
	private static final String ASN="ASN";
	private static final String VPN_ID="VPNID";
	private static final String FRAMSIZE="FRAMESIZE";
	private static final String RATE_LIMIT_TYPE="RATE_LIMIT_TYPE";
	private static final String MONITORING_TYPE="MONITORING_TYPE";
	private static final String PROBE_TYPE="PROBE_TYPE";
	private static final String IS_PM_FLAG="PMFLAG";
	private static final String SLA_AGREEMENT_TEMPLATE="SLA_AGREEMENT_TEMPLATE";
	private static final String EXCEPTION_HANDLING_INFO="EXCEPTION_HANDLING_INFO";
	private static final String PROTOCOL_TYPE  ="PROTOCOL_TYPE";
	private static final String IPVERSION="IPVERSION";
	private static final String USAGE="USAGE";
	private static final String FID_NAME ="FID_NAME";
	private static final String SERVICE_PROFILE ="SERVICE_PROFILE";
	private static final String UPSTREAM_RATE  ="UPSTREAM_RATE";
	private static final String DOWNSTREAM_RATE ="DOWNSTREAM_RATE";
	private static final String CVOIP_TN ="CVOIP_TN";
	private static final String DTN ="DTN";
	private static String HDStream ="HD_STREAMS";
	private static String PROTECTION ="PROTECTION";
	private static final String PM_TYPE ="PM_TYPE";
	private static final String REQUESTING_AFFILIATE ="REQUESTING_AFFILIATE";
	
	
	
	public ServiceExtension()
	{
		super();
	}

	public ServiceExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	@Override
	public void populateModel()
	{
		fields.put(MAXNUMOVCS, new Field(MAXNUMOVCS, Field.TYPE_NUMERIC));
		fields.put(MEFSERVICETYPE, new Field(MEFSERVICETYPE, Field.TYPE_VARCHAR));
		fields.put(CONTROLLINGCOMPANY, new Field(CONTROLLINGCOMPANY, Field.TYPE_VARCHAR));
		fields.put(CEVLAN, new Field(CEVLAN, Field.TYPE_NUMERIC));
		fields.put(CEVLANIDPRESERVATION, new Field(CEVLANIDPRESERVATION, Field.TYPE_VARCHAR));
		fields.put(SECNCICODE, new Field(SECNCICODE, Field.TYPE_VARCHAR));
		fields.put(MAXNUMOVCENDPOINTSPEROVC, new Field(MAXNUMOVCENDPOINTSPEROVC, Field.TYPE_NUMERIC));
		fields.put(UNICASTFRAMEDELIVERY, new Field(UNICASTFRAMEDELIVERY, Field.TYPE_VARCHAR));
		fields.put(EVCOVCREFERENCE, new Field(EVCOVCREFERENCE, Field.TYPE_VARCHAR));
		fields.put(SITE_ROLE, new Field(SITE_ROLE, Field.TYPE_NUMERIC));
		fields.put(NCCODE, new Field(NCCODE, Field.TYPE_VARCHAR));
		fields.put(HPC, new Field(HPC, Field.TYPE_VARCHAR));
		fields.put(IS_DIVERSE, new Field(IS_DIVERSE, Field.TYPE_VARCHAR));
		fields.put(MULTICASTFRAMEDELIVERY, new Field(MULTICASTFRAMEDELIVERY, Field.TYPE_VARCHAR));
		fields.put(TYPE, new Field(TYPE, Field.TYPE_NUMERIC));
		fields.put(COS_ID, new Field(COS_ID, Field.TYPE_VARCHAR));
		fields.put(MAXNUMUNIOVCENDPOINTS, new Field(MAXNUMUNIOVCENDPOINTS, Field.TYPE_NUMERIC));
		fields.put(OTC, new Field(OTC, Field.TYPE_VARCHAR));
		fields.put(CTLSERVICETYPE, new Field(CTLSERVICETYPE, Field.TYPE_VARCHAR));
		fields.put(FRAMEFORMAT, new Field(FRAMEFORMAT, Field.TYPE_VARCHAR));
		fields.put(MCO, new Field(MCO, Field.TYPE_VARCHAR));
		fields.put(MAXIMUMUNIS, new Field(MAXIMUMUNIS, Field.TYPE_NUMERIC));
		fields.put(CEVLANCOSPRESERVATION, new Field(CEVLANCOSPRESERVATION, Field.TYPE_VARCHAR));
		fields.put(BUNDLING, new Field(BUNDLING, Field.TYPE_VARCHAR));
		fields.put(COS_VALUE, new Field(COS_VALUE, Field.TYPE_NUMERIC));
		fields.put(NCICODE, new Field(NCICODE, Field.TYPE_VARCHAR));
		fields.put(SERVICESUBTYPE, new Field(SERVICESUBTYPE, Field.TYPE_VARCHAR));
		fields.put(STI, new Field(STI, Field.TYPE_VARCHAR));
		fields.put(CUSTOMERSERIALNUMBER, new Field(CUSTOMERSERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(SPECCODE, new Field(SPECCODE, Field.TYPE_VARCHAR));
		fields.put(CIRCUITSERIALNUMBER, new Field(CIRCUITSERIALNUMBER, Field.TYPE_NUMERIC));
		fields.put(BW, new Field(BW, Field.TYPE_VARCHAR));
		fields.put(EVCOVCNC, new Field(EVCOVCNC, Field.TYPE_VARCHAR));
		fields.put(ROLE, new Field(ROLE, Field.TYPE_VARCHAR));
		fields.put(SERVICEMUX, new Field(SERVICEMUX, Field.TYPE_VARCHAR));
		fields.put(CUSTACCTBAN, new Field(CUSTACCTBAN, Field.TYPE_VARCHAR));
		fields.put(BROADCASTFRAMEDELIVERY, new Field(BROADCASTFRAMEDELIVERY, Field.TYPE_VARCHAR));
		fields.put(EVCMTU, new Field(EVCMTU, Field.TYPE_NUMERIC));
		fields.put(MAXNUMEVCS, new Field(MAXNUMEVCS, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(TOPOLOGY_TYPE, new Field(TOPOLOGY_TYPE, Field.TYPE_NUMERIC));
		fields.put(SVLAN2OVCENDPOINT, new Field(SVLAN2OVCENDPOINT, Field.TYPE_VARCHAR));
		fields.put(COLORFORWARDING, new Field(COLORFORWARDING, Field.TYPE_VARCHAR));
		fields.put(OVCMTU, new Field(OVCMTU, Field.TYPE_NUMERIC));
		fields.put(SVLANIDPRESERVATION, new Field(SVLANIDPRESERVATION, Field.TYPE_VARCHAR));
		fields.put(ISMEETPOINTEVC, new Field(ISMEETPOINTEVC, Field.TYPE_VARCHAR));
		fields.put(MAXNUMENNIOVCENDPOINTS, new Field(MAXNUMENNIOVCENDPOINTS, Field.TYPE_NUMERIC));
		fields.put(DIVERSE_UNI_ID, new Field(DIVERSE_UNI_ID, Field.TYPE_VARCHAR));
		fields.put(IP_ROUTING_PROTOCOLNAME, new Field(IP_ROUTING_PROTOCOLNAME, Field.TYPE_NUMERIC));
		fields.put(COSNAME, new Field(COSNAME, Field.TYPE_NUMERIC));
		fields.put(SERVICEID, new Field(SERVICEID, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(CEVLAN2EVC, new Field(CEVLAN2EVC, Field.TYPE_VARCHAR));
		fields.put(LOS_NAME, new Field(LOS_NAME, Field.TYPE_VARCHAR));
		fields.put(ICO, new Field(ICO, Field.TYPE_VARCHAR));
		fields.put(HPCEXPIRATIONDATE, new Field(HPCEXPIRATIONDATE, Field.TYPE_VARCHAR));
		fields.put(ALLTO1BUNDLING, new Field(ALLTO1BUNDLING, Field.TYPE_VARCHAR));
		fields.put(SVLANCOSPRESERVATION, new Field(SVLANCOSPRESERVATION, Field.TYPE_VARCHAR));
		fields.put(TSP, new Field(TSP, Field.TYPE_NUMERIC));
		fields.put(ASN, new Field(ASN, Field.TYPE_VARCHAR));
		fields.put(VPN_ID, new Field(VPN_ID, Field.TYPE_VARCHAR));
		fields.put(FRAMSIZE, new Field(FRAMSIZE, Field.TYPE_VARCHAR));
		fields.put(RATE_LIMIT_TYPE, new Field(RATE_LIMIT_TYPE, Field.TYPE_VARCHAR));
		fields.put(MONITORING_TYPE, new Field(MONITORING_TYPE, Field.TYPE_VARCHAR));
		fields.put(PROBE_TYPE, new Field(PROBE_TYPE, Field.TYPE_VARCHAR));
		fields.put(IS_PM_FLAG, new Field(IS_PM_FLAG, Field.TYPE_VARCHAR));
		fields.put(SLA_AGREEMENT_TEMPLATE, new Field(SLA_AGREEMENT_TEMPLATE, Field.TYPE_VARCHAR));
		fields.put(EXCEPTION_HANDLING_INFO, new Field(EXCEPTION_HANDLING_INFO, Field.TYPE_VARCHAR));
		fields.put(PROTOCOL_TYPE, new Field(PROTOCOL_TYPE, Field.TYPE_VARCHAR));
		fields.put(IPVERSION, new Field(IPVERSION, Field.TYPE_VARCHAR));
		fields.put(USAGE, new Field(USAGE, Field.TYPE_VARCHAR));
		fields.put(FID_NAME, new Field(FID_NAME, Field.TYPE_VARCHAR));
		fields.put(HDStream, new Field(HDStream, Field.TYPE_VARCHAR));
		fields.put(PROTECTION, new Field(PROTECTION, Field.TYPE_VARCHAR));
		
		fields.put(SERVICE_PROFILE, new Field(SERVICE_PROFILE, Field.TYPE_VARCHAR));
		fields.put(UPSTREAM_RATE, new Field(UPSTREAM_RATE, Field.TYPE_NUMERIC));
		fields.put(DOWNSTREAM_RATE, new Field(DOWNSTREAM_RATE, Field.TYPE_NUMERIC));
		fields.put(CVOIP_TN, new Field(CVOIP_TN, Field.TYPE_VARCHAR));
		fields.put(DTN, new Field(DTN, Field.TYPE_VARCHAR));
		fields.put(PM_TYPE, new Field(PM_TYPE, Field.TYPE_VARCHAR));
		fields.put(REQUESTING_AFFILIATE, new Field(REQUESTING_AFFILIATE, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(SERVICEID));
	}

	public void setMaxnumovcs(String maxnumovcs)
	{
		setField(MAXNUMOVCS,maxnumovcs);
	}

	public String getMaxnumovcs()
	{
		return getFieldAsString(MAXNUMOVCS);
	}

	public void setMefservicetype(String mefservicetype)
	{
		setField(MEFSERVICETYPE,mefservicetype);
	}

	public String getMefservicetype()
	{
		return getFieldAsString(MEFSERVICETYPE);
	}

	public void setControllingcompany(String controllingcompany)
	{
		setField(CONTROLLINGCOMPANY,controllingcompany);
	}

	public String getControllingcompany()
	{
		return getFieldAsString(CONTROLLINGCOMPANY);
	}

	public void setCevlan(String cevlan)
	{
		setField(CEVLAN,cevlan);
	}

	public String getCevlan()
	{
		return getFieldAsString(CEVLAN);
	}

	public void setCevlanidpreservation(String cevlanidpreservation)
	{
		setField(CEVLANIDPRESERVATION,cevlanidpreservation);
	}

	public String getCevlanidpreservation()
	{
		return getFieldAsString(CEVLANIDPRESERVATION);
	}

	public void setSecncicode(String secncicode)
	{
		setField(SECNCICODE,secncicode);
	}

	public String getSecncicode()
	{
		return getFieldAsString(SECNCICODE);
	}

	public void setMaxnumovcendpointsperovc(String maxnumovcendpointsperovc)
	{
		setField(MAXNUMOVCENDPOINTSPEROVC,maxnumovcendpointsperovc);
	}

	public String getMaxnumovcendpointsperovc()
	{
		return getFieldAsString(MAXNUMOVCENDPOINTSPEROVC);
	}

	public void setUnicastframedelivery(String unicastframedelivery)
	{
		setField(UNICASTFRAMEDELIVERY,unicastframedelivery);
	}

	public String getUnicastframedelivery()
	{
		return getFieldAsString(UNICASTFRAMEDELIVERY);
	}

	public void setEvcovcreference(String evcovcreference)
	{
		setField(EVCOVCREFERENCE,evcovcreference);
	}

	public String getEvcovcreference()
	{
		return getFieldAsString(EVCOVCREFERENCE);
	}

	public void setSiteRole(String siteRole)
	{
		setField(SITE_ROLE,siteRole);
	}

	public String getSiteRole()
	{
		return getFieldAsString(SITE_ROLE);
	}

	public void setNccode(String nccode)
	{
		setField(NCCODE,nccode);
	}

	public String getNccode()
	{
		return getFieldAsString(NCCODE);
	}

	public void setHpc(String hpc)
	{
		setField(HPC,hpc);
	}

	public String getHpc()
	{
		return getFieldAsString(HPC);
	}

	public void setIsDiverse(String isDiverse)
	{
		setField(IS_DIVERSE,isDiverse);
	}

	public String getIsDiverse()
	{
		return getFieldAsString(IS_DIVERSE);
	}

	public void setMulticastframedelivery(String multicastframedelivery)
	{
		setField(MULTICASTFRAMEDELIVERY,multicastframedelivery);
	}

	public String getMulticastframedelivery()
	{
		return getFieldAsString(MULTICASTFRAMEDELIVERY);
	}

	public void setType(String type)
	{
		setField(TYPE,type);
	}

	public String getType()
	{
		return getFieldAsString(TYPE);
	}

	public void setCosId(String cosId)
	{
		setField(COS_ID,cosId);
	}

	public String getCosId()
	{
		return getFieldAsString(COS_ID);
	}

	public void setMaxnumuniovcendpoints(String maxnumuniovcendpoints)
	{
		setField(MAXNUMUNIOVCENDPOINTS,maxnumuniovcendpoints);
	}

	public String getMaxnumuniovcendpoints()
	{
		return getFieldAsString(MAXNUMUNIOVCENDPOINTS);
	}

	public void setOtc(String otc)
	{
		setField(OTC,otc);
	}

	public String getOtc()
	{
		return getFieldAsString(OTC);
	}

	public void setCtlservicetype(String ctlservicetype)
	{
		setField(CTLSERVICETYPE,ctlservicetype);
	}

	public String getCtlservicetype()
	{
		return getFieldAsString(CTLSERVICETYPE);
	}

	public void setFrameformat(String frameformat)
	{
		setField(FRAMEFORMAT,frameformat);
	}

	public String getFrameformat()
	{
		return getFieldAsString(FRAMEFORMAT);
	}

	public void setMco(String mco)
	{
		setField(MCO,mco);
	}

	public String getMco()
	{
		return getFieldAsString(MCO);
	}

	public void setMaximumunis(String maximumunis)
	{
		setField(MAXIMUMUNIS,maximumunis);
	}

	public String getMaximumunis()
	{
		return getFieldAsString(MAXIMUMUNIS);
	}

	public void setCevlancospreservation(String cevlancospreservation)
	{
		setField(CEVLANCOSPRESERVATION,cevlancospreservation);
	}

	public String getCevlancospreservation()
	{
		return getFieldAsString(CEVLANCOSPRESERVATION);
	}

	public void setBundling(String bundling)
	{
		setField(BUNDLING,bundling);
	}

	public String getBundling()
	{
		return getFieldAsString(BUNDLING);
	}

	public void setCosValue(String cosValue)
	{
		setField(COS_VALUE,cosValue);
	}

	public String getCosValue()
	{
		return getFieldAsString(COS_VALUE);
	}

	public void setNcicode(String ncicode)
	{
		setField(NCICODE,ncicode);
	}

	public String getNcicode()
	{
		return getFieldAsString(NCICODE);
	}

	public void setServicesubtype(String servicesubtype)
	{
		setField(SERVICESUBTYPE,servicesubtype);
	}

	public String getServicesubtype()
	{
		return getFieldAsString(SERVICESUBTYPE);
	}

	public void setSti(String sti)
	{
		setField(STI,sti);
	}

	public String getSti()
	{
		return getFieldAsString(STI);
	}

	public void setCustomerserialnumber(String customerserialnumber)
	{
		setField(CUSTOMERSERIALNUMBER,customerserialnumber);
	}

	public String getCustomerserialnumber()
	{
		return getFieldAsString(CUSTOMERSERIALNUMBER);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setSpeccode(String speccode)
	{
		setField(SPECCODE,speccode);
	}

	public String getSpeccode()
	{
		return getFieldAsString(SPECCODE);
	}

	public void setCircuitserialnumber(String circuitserialnumber)
	{
		setField(CIRCUITSERIALNUMBER,circuitserialnumber);
	}

	public String getCircuitserialnumber()
	{
		return getFieldAsString(CIRCUITSERIALNUMBER);
	}

	public void setBw(String bw)
	{
		setField(BW,bw);
	}

	public String getBw()
	{
		return getFieldAsString(BW);
	}

	public void setEvcovcnc(String evcovcnc)
	{
		setField(EVCOVCNC,evcovcnc);
	}

	public String getEvcovcnc()
	{
		return getFieldAsString(EVCOVCNC);
	}

	public void setRole(String role)
	{
		setField(ROLE,role);
	}

	public String getRole()
	{
		return getFieldAsString(ROLE);
	}

	public void setServicemux(String servicemux)
	{
		setField(SERVICEMUX,servicemux);
	}

	public String getServicemux()
	{
		return getFieldAsString(SERVICEMUX);
	}

	public void setCustacctban(String custacctban)
	{
		setField(CUSTACCTBAN,custacctban);
	}

	public String getCustacctban()
	{
		return getFieldAsString(CUSTACCTBAN);
	}

	public void setBroadcastframedelivery(String broadcastframedelivery)
	{
		setField(BROADCASTFRAMEDELIVERY,broadcastframedelivery);
	}

	public String getBroadcastframedelivery()
	{
		return getFieldAsString(BROADCASTFRAMEDELIVERY);
	}

	public void setEvcmtu(String evcmtu)
	{
		setField(EVCMTU,evcmtu);
	}

	public String getEvcmtu()
	{
		return getFieldAsString(EVCMTU);
	}

	public void setMaxnumevcs(String maxnumevcs)
	{
		setField(MAXNUMEVCS,maxnumevcs);
	}

	public String getMaxnumevcs()
	{
		return getFieldAsString(MAXNUMEVCS);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setTopologyType(String topologyType)
	{
		setField(TOPOLOGY_TYPE,topologyType);
	}

	public String getTopologyType()
	{
		return getFieldAsString(TOPOLOGY_TYPE);
	}

	public void setSvlan2ovcendpoint(String svlan2ovcendpoint)
	{
		setField(SVLAN2OVCENDPOINT,svlan2ovcendpoint);
	}

	public String getSvlan2ovcendpoint()
	{
		return getFieldAsString(SVLAN2OVCENDPOINT);
	}

	public void setColorforwarding(String colorforwarding)
	{
		setField(COLORFORWARDING,colorforwarding);
	}

	public String getColorforwarding()
	{
		return getFieldAsString(COLORFORWARDING);
	}

	public void setOvcmtu(String ovcmtu)
	{
		setField(OVCMTU,ovcmtu);
	}

	public String getOvcmtu()
	{
		return getFieldAsString(OVCMTU);
	}

	public void setSvlanidpreservation(String svlanidpreservation)
	{
		setField(SVLANIDPRESERVATION,svlanidpreservation);
	}

	public String getSvlanidpreservation()
	{
		return getFieldAsString(SVLANIDPRESERVATION);
	}

	public void setIsmeetpointevc(String ismeetpointevc)
	{
		setField(ISMEETPOINTEVC,ismeetpointevc);
	}

	public String getIsmeetpointevc()
	{
		return getFieldAsString(ISMEETPOINTEVC);
	}

	public void setMaxnumenniovcendpoints(String maxnumenniovcendpoints)
	{
		setField(MAXNUMENNIOVCENDPOINTS,maxnumenniovcendpoints);
	}

	public String getMaxnumenniovcendpoints()
	{
		return getFieldAsString(MAXNUMENNIOVCENDPOINTS);
	}

	public void setDiverseUniId(String diverseUniId)
	{
		setField(DIVERSE_UNI_ID,diverseUniId);
	}

	public String getDiverseUniId()
	{
		return getFieldAsString(DIVERSE_UNI_ID);
	}

	public void setIpRoutingProtocolname(String ipRoutingProtocolname)
	{
		setField(IP_ROUTING_PROTOCOLNAME,ipRoutingProtocolname);
	}

	public String getIpRoutingProtocolname()
	{
		return getFieldAsString(IP_ROUTING_PROTOCOLNAME);
	}

	public void setCosname(String cosname)
	{
		setField(COSNAME,cosname);
	}

	public String getCosname()
	{
		return getFieldAsString(COSNAME);
	}

	public void setServiceid(String serviceid)
	{
		setField(SERVICEID,serviceid);
	}

	public String getServiceid()
	{
		return getFieldAsString(SERVICEID);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setCevlan2evc(String cevlan2evc)
	{
		setField(CEVLAN2EVC,cevlan2evc);
	}

	public String getCevlan2evc()
	{
		return getFieldAsString(CEVLAN2EVC);
	}

	public void setLosName(String losName)
	{
		setField(LOS_NAME,losName);
	}

	public String getLosName()
	{
		return getFieldAsString(LOS_NAME);
	}

	public void setIco(String ico)
	{
		setField(ICO,ico);
	}

	public String getIco()
	{
		return getFieldAsString(ICO);
	}

	public void setHpcexpirationdate(String hpcexpirationdate)
	{
		setField(HPCEXPIRATIONDATE,hpcexpirationdate);
	}

	public String getHpcexpirationdate()
	{
		return getFieldAsString(HPCEXPIRATIONDATE);
	}

	public void setAllto1bundling(String allto1bundling)
	{
		setField(ALLTO1BUNDLING,allto1bundling);
	}

	public String getAllto1bundling()
	{
		return getFieldAsString(ALLTO1BUNDLING);
	}

	public void setSvlancospreservation(String svlancospreservation)
	{
		setField(SVLANCOSPRESERVATION,svlancospreservation);
	}

	public String getSvlancospreservation()
	{
		return getFieldAsString(SVLANCOSPRESERVATION);
	}
	
	public void setTsp(String tsp)
	{
		setField(TSP,tsp);
	}
	
	public String getTSP()
	{
		return getFieldAsString(TSP);
	}
	
	public String getAsn() {
		return getFieldAsString(ASN);
	}

	public void setAsn(String asn) {
		setField(ASN,asn);
	}

	public String getVpnId() {
		return getFieldAsString(VPN_ID);
	}

	public void setVpnId(String vpnId) {
		setField(VPN_ID,vpnId);
		
	}
	
	public String getFramesize() {
		return getFieldAsString(FRAMSIZE);
	}

	public void setFramesize(String framesize) {
		setField(FRAMSIZE,framesize);
	}

	public String getRatelimittype() {
		return getFieldAsString(RATE_LIMIT_TYPE);
	}

	public void setRatelimittype(String ratelimittype) {
		setField(RATE_LIMIT_TYPE,ratelimittype);
	}

	public String getMonitoringType() {
		
		return getFieldAsString(MONITORING_TYPE);
	}

	public void setMonitoringType(String monitoringType) {
		setField(MONITORING_TYPE,monitoringType);
	}

	public String getProbeType() {
		
		return getFieldAsString(PROBE_TYPE);
	}

	public void setProbeType(String probeType) {
		setField(PROBE_TYPE,probeType);
	}

	public String getIsPmFlag() {
		
		return getFieldAsString(IS_PM_FLAG);
	}

	public void setIsPmFlag(String isPmFlag) {
		 
		setField(IS_PM_FLAG,isPmFlag);
	}

	public String getSlaAgreementTemplate() {
		return getFieldAsString(SLA_AGREEMENT_TEMPLATE);
	}

	public void setSlaAgreementTemplate(String slaAgreementTemplate) {
		setField(SLA_AGREEMENT_TEMPLATE,slaAgreementTemplate);
	}

	public String getExceptionHandlingInfo() {
		return getFieldAsString(EXCEPTION_HANDLING_INFO);
	}

	public void setExceptionHandlingInfo(String exceptionHandlingInfo) {
		setField(EXCEPTION_HANDLING_INFO,exceptionHandlingInfo);
	}
	public void setProtocolType(String protocolType)
	{
		setField(PROTOCOL_TYPE,protocolType);
	}

	public String getProtocolType()
	{
		return getFieldAsString(PROTOCOL_TYPE);
	}

	public void setIpVersion(String ipVersion)
	{
		setField(IPVERSION,ipVersion);
	}

	public String getIpVersion()
	{
		return getFieldAsString(IPVERSION);
	}
	
	public void setUsage(String usage)
	{
		setField(USAGE,usage);
	}

	public String getUsage()
	{
		return getFieldAsString(USAGE);
	}
	
	public void setFidName(String fidName)
	{
		setField(FID_NAME,fidName);
	}

	public String getFidName()
	{
		return getFieldAsString(FID_NAME);
	}
	public void setServiceProfile(String serviceProfile)
	{
		setField(SERVICE_PROFILE,serviceProfile);
	}
	public String getServiceProfile()
	{
		return getFieldAsString(SERVICE_PROFILE);
	}
	public void setUpstreamRate(String upstreamRate)
	{
		setField(UPSTREAM_RATE,upstreamRate);
	}

	public String getUpstreamRate()
	{
		return getFieldAsString(UPSTREAM_RATE);
	}
	public void setDownStreamRate(String downstreamRate)
	{
		setField(DOWNSTREAM_RATE,downstreamRate);
	}

	public String getDownStreamRate()
	{
		return getFieldAsString(DOWNSTREAM_RATE);
	}
	public void setCvoipTn(String cvoipTn)
	{
		setField(CVOIP_TN,cvoipTn);
	}

	public String getCvoipTn()
	{
		return getFieldAsString(CVOIP_TN);
	}
	
	
	public void setDTN(String dtn)
	{
		setField(DTN,dtn);
	}

	public String getDTN()
	{
		return getFieldAsString(DTN);
	}
	
	public  void setHdstream(String hdstream) {
		setField(HDStream,hdstream);
	}
	
	public  String getHdstream() {
		return getFieldAsString(HDStream);
	}
	
	public void setProtectRouting(String protection)
	{
		setField(PROTECTION,protection);
	}

	public String getProtectRouting()
	{
		return getFieldAsString(PROTECTION);
	}
	
	public void setPMType(String pmType)
	{
		setField(PM_TYPE, pmType);
	}

	public String getPMType()
	{
		return getFieldAsString(PM_TYPE);
	}
	
	public void setRequestingAffiliate(String requestingAffiliate)
	{
		setField(REQUESTING_AFFILIATE, requestingAffiliate);
	}

	public String getRequestingAffiliate()
	{
		return getFieldAsString(REQUESTING_AFFILIATE);
	}
}
