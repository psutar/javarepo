package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Porttype extends AbstractReadOnlyTable {

	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String VENDOR2RMCALLOUT = "VENDOR2RMCALLOUT";
	private static final String RM2VENDORCALLOUT = "RM2VENDORCALLOUT";
	private static final String IGNORESYNC = "IGNORESYNC";
	private static final String DMPCLASS = "DMPCLASS";
	private static final String MAXLOGICALCONNECTIONS = "MAXLOGICALCONNECTIONS";
	private static final String TRANSPARENCYBEHAVIOUR = "TRANSPARENCYBEHAVIOUR";
	private static final String ATTENUATION = "ATTENUATION";
	private static final String MAXCABLECONDUCTORS = "MAXCABLECONDUCTORS";
	private static final String MAXCROSSCONNECTIONS = "MAXCROSSCONNECTIONS";
	private static final String MAXLINKCONNECTIONS = "MAXLINKCONNECTIONS";
	private static final String MAXPHYSICALCONNECTIONS = "MAXPHYSICALCONNECTIONS";
	private static final String DIRECTIONBEHAVIOUR = "DIRECTIONBEHAVIOUR";
	private static final String BEHAVIOUR = "BEHAVIOUR";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String CLASS = "CLASS";
	private static final String TABLENAME = "TABLENAME";
	private static final String PORTTYPE2BROWSERBITMAP = "PORTTYPE2BROWSERBITMAP";
	private static final String PORTTYPE2GRAPHICSBITMAP = "PORTTYPE2GRAPHICSBITMAP";
	private static final String PORTTYPE2BANDWIDTH = "PORTTYPE2BANDWIDTH";
	private static final String NAME = "NAME";
	private static final String PORTTYPEID = "PORTTYPEID";

	public Porttype()
	{
		super();
		this.tableName = "PORTTYPE";
	}

	public Porttype(String portTypeId)
	{
		this();
		primaryKey.setValue(portTypeId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}


	public static List<Porttype> getPorttypeListByQuery(String query)
	{
		Porttype porttype = new Porttype();
		List<Porttype> porttypeList = new ArrayList<Porttype>();
		List<Map<String,Object>> foundPorttypeList = porttype.getRecordsByQuery(query);

		for (Map<String,Object> porttypeMap : foundPorttypeList)
		{
			Porttype workPorttype = new Porttype(porttypeMap.get(PORTTYPEID).toString());
			porttypeList.add(workPorttype);
		}
		return porttypeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(VENDOR2RMCALLOUT, new Field(VENDOR2RMCALLOUT, Field.TYPE_VARCHAR));
		fields.put(RM2VENDORCALLOUT, new Field(RM2VENDORCALLOUT, Field.TYPE_VARCHAR));
		fields.put(IGNORESYNC, new Field(IGNORESYNC, Field.TYPE_NUMERIC));
		fields.put(DMPCLASS, new Field(DMPCLASS, Field.TYPE_VARCHAR));
		fields.put(MAXLOGICALCONNECTIONS, new Field(MAXLOGICALCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(TRANSPARENCYBEHAVIOUR, new Field(TRANSPARENCYBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(ATTENUATION, new Field(ATTENUATION, Field.TYPE_NUMERIC));
		fields.put(MAXCABLECONDUCTORS, new Field(MAXCABLECONDUCTORS, Field.TYPE_NUMERIC));
		fields.put(MAXCROSSCONNECTIONS, new Field(MAXCROSSCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(MAXLINKCONNECTIONS, new Field(MAXLINKCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(MAXPHYSICALCONNECTIONS, new Field(MAXPHYSICALCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(DIRECTIONBEHAVIOUR, new Field(DIRECTIONBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(BEHAVIOUR, new Field(BEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(PORTTYPE2BROWSERBITMAP, new Field(PORTTYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(PORTTYPE2GRAPHICSBITMAP, new Field(PORTTYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(PORTTYPE2BANDWIDTH, new Field(PORTTYPE2BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(PORTTYPEID, new Field(PORTTYPEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PORTTYPEID));
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setVendor2rmcallout(String vendor2rmcallout)
	{
		setField(VENDOR2RMCALLOUT,vendor2rmcallout);
	}

	public String getVendor2rmcallout()
	{
		return getFieldAsString(VENDOR2RMCALLOUT);
	}

	public void setRm2vendorcallout(String rm2vendorcallout)
	{
		setField(RM2VENDORCALLOUT,rm2vendorcallout);
	}

	public String getRm2vendorcallout()
	{
		return getFieldAsString(RM2VENDORCALLOUT);
	}

	public void setIgnoresync(String ignoresync)
	{
		setField(IGNORESYNC,ignoresync);
	}

	public String getIgnoresync()
	{
		return getFieldAsString(IGNORESYNC);
	}

	public void setDmpclass(String dmpclass)
	{
		setField(DMPCLASS,dmpclass);
	}

	public String getDmpclass()
	{
		return getFieldAsString(DMPCLASS);
	}

	public void setMaxlogicalconnections(String maxlogicalconnections)
	{
		setField(MAXLOGICALCONNECTIONS,maxlogicalconnections);
	}

	public String getMaxlogicalconnections()
	{
		return getFieldAsString(MAXLOGICALCONNECTIONS);
	}

	public void setTransparencybehaviour(String transparencybehaviour)
	{
		setField(TRANSPARENCYBEHAVIOUR,transparencybehaviour);
	}

	public String getTransparencybehaviour()
	{
		return getFieldAsString(TRANSPARENCYBEHAVIOUR);
	}

	public void setAttenuation(String attenuation)
	{
		setField(ATTENUATION,attenuation);
	}

	public String getAttenuation()
	{
		return getFieldAsString(ATTENUATION);
	}

	public void setMaxcableconductors(String maxcableconductors)
	{
		setField(MAXCABLECONDUCTORS,maxcableconductors);
	}

	public String getMaxcableconductors()
	{
		return getFieldAsString(MAXCABLECONDUCTORS);
	}

	public void setMaxcrossconnections(String maxcrossconnections)
	{
		setField(MAXCROSSCONNECTIONS,maxcrossconnections);
	}

	public String getMaxcrossconnections()
	{
		return getFieldAsString(MAXCROSSCONNECTIONS);
	}

	public void setMaxlinkconnections(String maxlinkconnections)
	{
		setField(MAXLINKCONNECTIONS,maxlinkconnections);
	}

	public String getMaxlinkconnections()
	{
		return getFieldAsString(MAXLINKCONNECTIONS);
	}

	public void setMaxphysicalconnections(String maxphysicalconnections)
	{
		setField(MAXPHYSICALCONNECTIONS,maxphysicalconnections);
	}

	public String getMaxphysicalconnections()
	{
		return getFieldAsString(MAXPHYSICALCONNECTIONS);
	}

	public void setDirectionbehaviour(String directionbehaviour)
	{
		setField(DIRECTIONBEHAVIOUR,directionbehaviour);
	}

	public String getDirectionbehaviour()
	{
		return getFieldAsString(DIRECTIONBEHAVIOUR);
	}

	public void setBehaviour(String behaviour)
	{
		setField(BEHAVIOUR,behaviour);
	}

	public String getBehaviour()
	{
		return getFieldAsString(BEHAVIOUR);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setPorttype2browserbitmap(String porttype2browserbitmap)
	{
		setField(PORTTYPE2BROWSERBITMAP,porttype2browserbitmap);
	}

	public String getPorttype2browserbitmap()
	{
		return getFieldAsString(PORTTYPE2BROWSERBITMAP);
	}

	public void setPorttype2graphicsbitmap(String porttype2graphicsbitmap)
	{
		setField(PORTTYPE2GRAPHICSBITMAP,porttype2graphicsbitmap);
	}

	public String getPorttype2graphicsbitmap()
	{
		return getFieldAsString(PORTTYPE2GRAPHICSBITMAP);
	}

	public void setPorttype2bandwidth(String porttype2bandwidth)
	{
		setField(PORTTYPE2BANDWIDTH,porttype2bandwidth);
	}

	public String getPorttype2bandwidth()
	{
		return getFieldAsString(PORTTYPE2BANDWIDTH);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setPorttypeid(String porttypeid)
	{
		setField(PORTTYPEID,porttypeid);
	}

	public String getPorttypeid()
	{
		return getFieldAsString(PORTTYPEID);
	}
}