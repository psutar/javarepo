package com.centurylink.icl.armmediation.armaccessobject;

public class NMIBandwidthDetails extends ARMObject
{

	private String	clliCode;
	private String	commonName;
	private String	description;
	private String	sourceSystem;
	private String	objectID;
	private String	resourceType;
	private String bandwidth;
	private String lrStatus;
	private String availableBandwidth;
	
	public final String getAvailableBandwidth()
	{
		return availableBandwidth;
	}
	public final void setAvailableBandwidth(String availableBandwidth)
	{
		this.availableBandwidth = availableBandwidth;
	}
	public String getClliCode()
	{
		return clliCode;
	}
	public void setClliCode(String clliCode)
	{
		this.clliCode = clliCode;
	}
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public String getSourceSystem()
	{
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}
	public String getObjectID()
	{
		return objectID;
	}
	public void setObjectID(String objectID)
	{
		this.objectID = objectID;
	}
	public String getResourceType()
	{
		return resourceType;
	}
	public void setResourceType(String resourceType)
	{
		this.resourceType = resourceType;
	}
	public String getBandwidth()
	{
		return bandwidth;
	}
	public void setBandwidth(String bandwidth)
	{
		this.bandwidth = bandwidth;
	}
	public String getLrStatus() {
		return lrStatus;
	}
	public void setLrStatus(String lrStatus) {
		this.lrStatus = lrStatus;
	}
	
	
}
