package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class NodeInRackShelf extends AbstractReadOnlyTable {

	private static final long serialVersionUID = 1L;
	
	private static final String NIRS2NODE = "NIRS2NODE";
	private static final String NIRS2RACKSHELF = "NIRS2RACKSHELF";
	private static final String SHELFUNITS = "SHELFUNITS";
	private static final String XPOS = "XPOS";
	private static final String YPOS = "YPOS";
	private static final String ZPOS = "ZPOS";
	private static final String FRONTBACK = "FRONTBACK";
	private static final String RPPLANID = "RPPLANID";

	public NodeInRackShelf()
	{
		super();
		this.tableName = "NODEINRACKSHELF";
	}

	public NodeInRackShelf(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<NodeInRackShelf> getNodeInRackShelfListByRackShelf(String shelfId)
	{
		NodeInRackShelf template = new NodeInRackShelf();
		template.setNirs2rackshelf(shelfId);
		
		List<NodeInRackShelf> nodeInRackShelfList = new ArrayList<NodeInRackShelf>();
		
		List<Map<String, Object>> records = template.getRecordsByTemplate();
		System.out.println("Grih --> NodeInRackShelfListByRackShelf Record" + records);
		for (Map<String, Object> map:records)
		{
			NodeInRackShelf nirs = new NodeInRackShelf();
			nirs.instanciated = true;
			nirs.populateFields(map);
			nodeInRackShelfList.add(nirs);
		}
		
		return nodeInRackShelfList;
	}

	public static List<NodeInRackShelf> getNodeInRackShelfList(String nodeId, String shelfId)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(nodeId))
		{
			query = NIRS2NODE + " = '" +  nodeId + "'";
			connector = " AND ";
		}
		
		if (!StringHelper.isEmpty(shelfId))
		{
			query += connector + NIRS2RACKSHELF + " = '" +  shelfId + "'";
		}
		
		return getNodeInRackShelfListByQuery(query);
	}

	@SuppressWarnings("deprecation")
	public static List<NodeInRackShelf> getNodeInRackShelfListByQuery(String query)
	{
		NodeInRackShelf nodeInRackShelf = new NodeInRackShelf();
		List<NodeInRackShelf> nodeInRackShelfList = new ArrayList<NodeInRackShelf>();
		List<Map<String,Object>> foundNodeInRackShelfList = nodeInRackShelf.getRecordsByQuery(query);

		for (Map<String,Object> nodeInRackShelfMap : foundNodeInRackShelfList)
		{
			NodeInRackShelf workNodeInRackShelf = new NodeInRackShelf(nodeInRackShelfMap.get(NIRS2NODE).toString());
			nodeInRackShelfList.add(workNodeInRackShelf);
		}
		return nodeInRackShelfList;
	}

	@Override
	public void populateModel()
	{
		fields.put(NIRS2NODE, new Field(NIRS2NODE, Field.TYPE_NUMERIC));
		fields.put(NIRS2RACKSHELF, new Field(NIRS2RACKSHELF, Field.TYPE_NUMERIC));
		fields.put(SHELFUNITS, new Field(SHELFUNITS, Field.TYPE_NUMERIC));
		fields.put(XPOS, new Field(XPOS, Field.TYPE_NUMERIC));
		fields.put(YPOS, new Field(YPOS, Field.TYPE_NUMERIC));
		fields.put(ZPOS, new Field(ZPOS, Field.TYPE_NUMERIC));
		fields.put(FRONTBACK, new Field(FRONTBACK, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(NIRS2NODE));
	}

	public void setNirs2node(String nirs2node)
	{
		setField(NIRS2NODE,nirs2node);
	}
	
	public String getNirs2node()
	{
		return getFieldAsString(NIRS2NODE);
	}

	public void setNirs2rackshelf(String nirs2rackshelf)
	{
		setField(NIRS2RACKSHELF,nirs2rackshelf);
	}
	
	public String getNirs2rackshelf()
	{
		return getFieldAsString(NIRS2RACKSHELF);
	}

	public void setShelfunits(String shelfunits)
	{
		setField(SHELFUNITS,shelfunits);
	}
	
	public String getShelfunits()
	{
		return getFieldAsString(SHELFUNITS);
	}

	public void setXpos(String xpos)
	{
		setField(XPOS,xpos);
	}
	
	public String getXpos()
	{
		return getFieldAsString(XPOS);
	}

	public void setYpos(String ypos)
	{
		setField(YPOS,ypos);
	}
	
	public String getYpos()
	{
		return getFieldAsString(YPOS);
	}

	public void setZpos(String zpos)
	{
		setField(ZPOS,zpos);
	}
	
	public String getZpos()
	{
		return getFieldAsString(ZPOS);
	}

	public void setFrontback(String frontback)
	{
		setField(FRONTBACK,frontback);
	}
	
	public String getFrontback()
	{
		return getFieldAsString(FRONTBACK);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

}