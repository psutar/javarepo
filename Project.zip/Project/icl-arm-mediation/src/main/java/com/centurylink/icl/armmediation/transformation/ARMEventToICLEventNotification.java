package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMEvent;
import com.centurylink.icl.builder.iclnotification.EventNotificationBuilder;
import com.centurylink.icl.builder.iclnotification.ParameterBuilder;
import com.centurylink.icl.builder.iclnotification.ParameterSetBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.iclnotification.EventNotification;

public class ARMEventToICLEventNotification {
	
	private static final Log LOG = LogFactory.getLog(ARMEventToICLEventNotification.class);
	
	public ARMEventToICLEventNotification()
	{
		
	}
	
	public EventNotification transformARMEventToEventNotification(ARMEvent event)
	{
		LOG.info(" Received from ICL_CLC_SYNC   \n" +event);
		//System.out.println(" Received from ICL_CLC_SYNC   \n" +event);
		EventNotificationBuilder builder = new EventNotificationBuilder();
		
		builder.buildEventNotification(event.getArmObjectId().toString(), event.getCommonName(), event.getArmDimName(), "ARM", event.getObjectAction());
		
		
		ParameterSetBuilder parameterSetBuilder = new ParameterSetBuilder();
		parameterSetBuilder.buildParameterSet();
		
		ParameterBuilder parameterBuilder = new ParameterBuilder();
		parameterBuilder.buildParameter("LastModified",event.getLastModified().toString());
		parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		
		
		if(!StringHelper.isEmpty(event.getUpdatedAttribute()))
		{
			parameterBuilder.buildParameter("UpdatedAttribute", event.getUpdatedAttribute());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		
		}
		if(!StringHelper.isEmpty(event.getOldValue()))
		{
			parameterBuilder.buildParameter("OldValue",event.getOldValue());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		}
		if(!StringHelper.isEmpty(event.getNewValue()))
		{
			parameterBuilder.buildParameter("NewValue", event.getNewValue());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		}
			
		if("SERVICE".equalsIgnoreCase(event.getArmDimName()))
		{
			parameterBuilder.buildParameter("ResourceSubtype", event.getResourceSubtype());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		}
			
		if("SERVICE".equalsIgnoreCase(event.getAssociatedArmDimName()))
		{ 
			parameterBuilder.buildParameter((event.getAssociatedArmObjectId() == null) ? "" : event.getAssociatedArmObjectId()+"","AssociatedService", event.getAssociatedARMObjectName(),event.getAssociatedServiceType());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		}
		else if(event.getAssociatedArmDimName() != null)
		{
			String associated = event.getAssociatedArmDimName().toUpperCase();
			associated = "Associated" + StringHelper.toCamelCase(associated); 
			
			parameterBuilder.buildParameter((event.getAssociatedArmObjectId() == null) ? "" : event.getAssociatedArmObjectId()+"",
					associated, event.getAssociatedARMObjectName(), event.getAssociatedArmDimName());
			parameterSetBuilder.addParameter(parameterBuilder.getParameter());
		}
			
		if(parameterSetBuilder.getParameterSet().getParameterList().size() > 0 )
			builder.addParameterSet(parameterSetBuilder.getParameterSet());
		
		
		LOG.info("Generated event from ICL_CLC_SYNC   \n" + builder.getEventNotification());
		//System.out.println("New Event from ICL_CLC_SYNC   \n" + builder.getEventNotification());
		return builder.getEventNotification();
	}

	
}
