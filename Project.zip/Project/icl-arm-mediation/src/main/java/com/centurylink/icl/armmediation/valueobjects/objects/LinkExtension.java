package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class LinkExtension extends AbstractReadOnlyTable {

	private static final String LABEL = "LABEL";
	private static String RESTRICTEDSTATUS = "RESTRICTEDSTATUS";
	private static final String RESTRICTEDNOTES = "RESTRICTEDNOTES";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LINKID = "LINKID";
	private static final String STRANDID = "STRANDID";
	private static final String SPLITTERGRPNAME = "SPLITTERGRPNAME";
	private static final String CABLEID = "CABLEID";
	private static final String AERIALORBURIED = "AERIALORBURIED";

	public LinkExtension() {
		super();
	}

	public LinkExtension(Field key, String tableName) {
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	@Override
	public void populateModel() {

		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(RESTRICTEDNOTES, new Field(RESTRICTEDNOTES,Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDSTATUS, new Field(RESTRICTEDSTATUS,Field.TYPE_NUMERIC));
		fields.put(LINKID, new Field(LINKID, Field.TYPE_NUMERIC));
		fields.put(STRANDID, new Field(STRANDID, Field.TYPE_NUMERIC));
		fields.put(SPLITTERGRPNAME, new Field(SPLITTERGRPNAME,Field.TYPE_VARCHAR));
		fields.put(CABLEID, new Field(CABLEID, Field.TYPE_VARCHAR));
		fields.put(AERIALORBURIED,new Field(AERIALORBURIED, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(LINKID));
	}

	public void setLabel(String label) {
		setField(LABEL, label);
	}

	public String getLabel() {
		return getFieldAsString(LABEL);
	}

	public void setRpplanid(String rpplanid) {
		setField(RPPLANID, rpplanid);
	}

	public String getRpplanid() {
		return getFieldAsString(RPPLANID);
	}

	public void setIsvisible(String isvisible) {
		setField(ISVISIBLE, isvisible);
	}

	public String getIsvisible() {
		return getFieldAsString(ISVISIBLE);
	}

	public void setRestrictedNotes(String RestrictedNotes) {
		setField(RESTRICTEDNOTES, RestrictedNotes);
	}

	public String getRestrictedNotes() {
		return getFieldAsString(RESTRICTEDNOTES);

	}

	public void setrestrictedStatus(String restrictedStatus) {
		setField(RESTRICTEDSTATUS, restrictedStatus);
	}

	public String getrestrictedStatus() {
		return getFieldAsString(RESTRICTEDSTATUS);
	}

	public void setLinkid(String linkid) {
		setField(LINKID, linkid);
	}

	public String getLinkid() {
		return getFieldAsString(LINKID);
	}

	public void setStrandid(String strandid) {
		setField(STRANDID, strandid);
	}

	public String getStrandid() {
		return getFieldAsString(STRANDID);
	}

	public void setSplitterGrpName(String splitterGrpName) {
		setField(SPLITTERGRPNAME, splitterGrpName);
	}

	public String getSplitterGrpName() {
		return getFieldAsString(SPLITTERGRPNAME);
	}

	public void setCableid(String cableid) {
		setField(CABLEID, cableid);
	}

	public String getCableid() {
		return getFieldAsString(CABLEID);
	}

	public void setAerialorBuried(String aerialorBuried) {
		setField(AERIALORBURIED, aerialorBuried);
	}

	public String getAerialorBuried() {
		return getFieldAsString(AERIALORBURIED);
	}

}
