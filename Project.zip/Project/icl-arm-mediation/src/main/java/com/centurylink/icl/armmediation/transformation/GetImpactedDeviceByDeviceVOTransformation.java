package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class GetImpactedDeviceByDeviceVOTransformation 
{

	private static final Log LOG = LogFactory.getLog(GetImpactedDeviceByDeviceVOTransformation.class);

	public static SearchResourceResponseDocument transformToCIM(HashMap<String,Node> nodes,String Nodename) throws Exception
	{

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		for( Entry<String, Node> nd:nodes.entrySet())
		{
			System.out.println(nd.getKey());
			System.out.println("#ndid"+nd.getValue().getNodeid());
		}
		Node mainNode=null;
		String Query=null;

		if(Nodename!=null)
			Query="NODE.NAME='"+Nodename+"'";

		if(Query!=null)
			mainNode=Node.getNodeListByQuery(Query).get(0);
		if(mainNode!=null){
			PhysicalDevice device = buildDevice(mainNode,nodes);
			searchResponseDetailsBuilder.addDevice(device);
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		System.out.println(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	protected static PhysicalDevice buildDevice(Node node,HashMap<String,Node> nodes) throws Exception
	{

		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		CardOnCardDetailsBuilder tempcardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();		
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();

		boolean applyPortFilter = false;
		boolean nodeHasPorts = false;
		String shelfNumber=null;
		String slotNumber=null;

		String portAdditionalQuery = null;
		physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), node.getDescription(), "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), node.getAlias1(), node.getNodeDef().getManufacturer(), null, null, node.getNodeExtension().getVendorname(), node.getNodeDef().getName(),node.getNodeExtension().getMco(), node.getFunctionalstatus().getName(),node.getNodeExtension().getNetworkname());
		physicalDeviceBuilder.addDetails(node.getNodeDef().getVersion(), null, node.getSoftwareversion(), node.getAlias2(), node.getNodeExtension().getSharedDedicated(), null, null, null, null, node.getNodeExtension().getVendorpartnumber(), null, null, node.getNodeExtension().getNmstype(), node.getNodeExtension().getNmshostname(), null, node.getNodeExtension().getSnmpobjectid(), node.getNodeExtension().getChassisserialnumber());
		if(node.getFullname() !=null)
			physicalDeviceBuilder.addResourceDescribedBy("FullName", node.getFullname());	
		
		if(node.getCreateddate() !=null)
			physicalDeviceBuilder.addResourceDescribedBy("CreatedDate", node.getCreateddate());	
		
		if(node.getLastmodifieddate() !=null)
			physicalDeviceBuilder.addResourceDescribedBy("LastModifiedDate", node.getLastmodifieddate());	
		if (node.getSubscriber() != null)
		{
		physicalDeviceBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(node.getSubscriber()));
		}	

		for (Networkroleobject networkroleobject : node.getNetworkroleobjects())
		{
			physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
			physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
		}

		//physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));

		boolean shelfHasPorts;
		boolean slotHasPorts;
		boolean cardHasPorts;
		boolean cardCardHasPorts;
		List<String> sfpOnDevice = new ArrayList<String>();
		List<String> sfpOnCard = new ArrayList<String>();


		HashSet<String> slots=new HashSet<String>();
		int shelfSize=node.getShelves().size();


		if (shelfSize > 0)
		{
			rackBuilder.buildRack(node.getNodeExtension().getRelayrackid(), null, null, null, null, null, null, null);
			for (Shelf shelf:node.getShelves())
			{ 
				shelfHasPorts = false;
				if(shelf!=null)
				{
					shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, null, null);
				}

				for (Slot slot:shelf.getSlots(slotNumber))
				{				
					slotHasPorts = false;
					if(slot!=null)
					{
						slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber())); 
					}

					for (Card card:slot.getCards(slotNumber)) {
						cardHasPorts = false;
						if(card!=null)
						{
							cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, "ARM", null, null, card.getAlias1(), card.getCard2cardtype(), null);
						}

						for (Port port:card.getCardPorts(portAdditionalQuery,applyPortFilter))
						{
							nodeHasPorts = true;
							shelfHasPorts = true;
							slotHasPorts = true;
							cardHasPorts = true;
							if(port!=null)
							{		
								String networkPortName=null;
								if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
								{
									networkPortName=port.getPortExtension().getIfName();
								}
								physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), null, null, port.getPortExtension().getBandwidth(),null,port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null,networkPortName);

								if(port.getPortExtension().getIfnum()!=null)
								{
									physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
								}
																
								if (port.getPort2porttype().equals("1900000003")) {
									if (port.getPortExtension().getBandwidth() != null
											|| port.getPortExtension().getFormfactor() != null) {
										String transmissionRate="";
										if(port.getPortExtension().getBandwidth() != null)
											transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
										if(port.getPortExtension().getFormfactor()!=null)
											transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();
										
										if(!transmissionRate.isEmpty())
										physicalPortBuilder
												.addResourceDescribedBy(
														"TransmissionRate",
														transmissionRate);
									}
								} else if (port.getBandwidthObject() != null
										&&port.getBandwidthObject()
										.getBandwidthid()!=null && !StringHelper.isEmpty(port.getBandwidthObject()
												.getBandwidthid())) {
									physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port
											.getBandwidthObject().getBandwidthid());
								}
								cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
								String sfpName = port.getSfpName(port.getPortid());											
								if(null != sfpName){											
									sfpOnCard.add(sfpName);
								}								
							}

						}

						if (sfpOnCard != null && !sfpOnCard.isEmpty())
						{
							cardOnCardDetailsBuilder.buildCardOnCardDetails();
							for (String sfpName : sfpOnCard)
							{
								cardOnCardDetailsBuilder.addCard(sfpName);
							}
							cardBuilder.addAllowableCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
						}

						for (Slot cardSlot:card.getCardSlots())
						{
							cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
							for (Card slotCard:cardSlot.getCards())
							{
								cardCardHasPorts = false;
								if(slotCard!=null)
								{		
									embededCardBuilder.buildCard(slotCard.getName(), slotCard.getCardid(), slotCard.getProvisionstatus().getName(), null, "ARM", null, null, slotCard.getAlias1(), slotCard.getCard2cardtype(), null);
								}										
								for (Port port:slotCard.getCardPorts(portAdditionalQuery))
								{

									nodeHasPorts = true;
									shelfHasPorts = true;
									slotHasPorts = true;
									cardHasPorts = true;
									cardCardHasPorts = true;
									if(port!=null)
									{
										String networkPortName=null;
										if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
										{
											networkPortName=port.getPortExtension().getIfName();
										}
										physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), port.getPortExtension().getBandwidth(),port.getPortExtension().getWavelength(),port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null,networkPortName);
										if(null!=port.getPortExtension().getIfnum())
										{
											physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
										}
										if (port.getPort2porttype().equals("1900000003")) {
											if (port.getPortExtension().getBandwidth() != null
													|| port.getPortExtension().getFormfactor() != null) {
												String transmissionRate="";
												if(port.getPortExtension().getBandwidth() != null)
													transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
												if(port.getPortExtension().getFormfactor()!=null)
													transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();
												
												if(!transmissionRate.isEmpty())
												physicalPortBuilder
														.addResourceDescribedBy(
																"TransmissionRate",
																transmissionRate);
											}
										} else if (port.getBandwidthObject() != null
												&&port.getBandwidthObject()
												.getBandwidthid()!=null && !StringHelper.isEmpty(port.getBandwidthObject()
														.getBandwidthid())) {
											physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port
													.getBandwidthObject().getBandwidthid());
										}
										embededCardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());

									}
								}
								if (!applyPortFilter || cardCardHasPorts)
									cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
							}
							if (!applyPortFilter || cardHasPorts)
								if(cardOnCardDetailsBuilder.getCardOnCardDetails().getCardList().size()>0)
								{
									cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
								}
						}
						if (!applyPortFilter || cardHasPorts)
						{
							if(card.getCard2shelfslot().equals(slot.getSlotid()))
								slotBuilder.addHasCard(cardBuilder.getCard());
						}
					}
					if (!applyPortFilter || slotHasPorts)
					{
						if(shelfBuilder.getShelf()!=null && slot.getSlot2shelf().equals(shelf.getShelfid())
								&& !slots.contains(slotBuilder.getSlot().getObjectID()))
						{
							shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
							slots.add(slotBuilder.getSlot().getObjectID());
						}
					}
				}
				if (!applyPortFilter || shelfHasPorts)
				{
					if(shelfBuilder.getShelf()!=null)
					{
						rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
					}
				}
			}
			physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
		}

		if (node.getDevicePorts(portAdditionalQuery,false) != null && node.getDevicePorts(portAdditionalQuery,false).size() > 0)
		{
			for (Port port:node.getDevicePorts(portAdditionalQuery,false))
			{
				Node dslamNode=nodes.get(port.getParentport2port());
				if(port.getParentport2port()!=null)
					System.out.println("#PP"+port.getParentport2port());

				String networkPortName=null;
				if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
				{
					networkPortName=port.getPortExtension().getIfName();
				}
				nodeHasPorts = true;
				physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), port.getPortExtension().getBandwidth(),port.getPortExtension().getWavelength(),port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null,networkPortName);
				if(port.getPortExtension().getIfnum()!=null)
				{
					physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
				}
				if (port.getPort2porttype().equals("1900000003")) {
					if (port.getPortExtension().getBandwidth() != null
							|| port.getPortExtension().getFormfactor() != null) {
						String transmissionRate="";
						if(port.getPortExtension().getBandwidth() != null)
							transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
						if(port.getPortExtension().getFormfactor()!=null)
							transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();
						
						if(!transmissionRate.isEmpty())
						physicalPortBuilder
								.addResourceDescribedBy(
										"TransmissionRate",
										transmissionRate);
					}
				} else if (port.getBandwidthObject() != null
						&&port.getBandwidthObject()
						.getBandwidthid()!=null && !StringHelper.isEmpty(port.getBandwidthObject()
								.getBandwidthid())) {
					physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port
							.getBandwidthObject().getBandwidthid());
				}
				
				if(dslamNode!=null)
				{
					ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
					resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
					resourceRelationshipBuilder.setDevice(GetImpactedDeviceByDeviceVOTransformation.buildDeviceRelationship(dslamNode));
					physicalPortBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
				}
				physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());
				String sfpName = port.getSfpName(port.getPortid());	
				if(null !=sfpName){							
					sfpOnDevice.add(sfpName);
				}

			}

			if (sfpOnDevice != null && !sfpOnDevice.isEmpty())
			{
				cardBuilder.buildCard(null, null, null);
				cardOnCardDetailsBuilder.buildCardOnCardDetails();
				for (String sfpName : sfpOnDevice)
				{
					tempcardOnCardDetailsBuilder.buildCardOnCardDetails(sfpName, null, null, null);
					cardBuilder.addCardOnCardDetails(tempcardOnCardDetailsBuilder.getCardOnCardDetails());
				}
				cardOnCardDetailsBuilder.addCard(cardBuilder.getCard());
				physicalDeviceBuilder.addAllowableSFPDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
			}

		}

		if (nodes.size() > 0)
		{
			ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
			for( Entry<String, Node> associatedDevice:nodes.entrySet())
			{
				resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
				resourceRelationshipBuilder.setDevice(GetImpactedDeviceByDeviceVOTransformation.buildDeviceRelationship(associatedDevice.getValue()));
				physicalDeviceBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
			}
		}

		if (!applyPortFilter || nodeHasPorts)
			return physicalDeviceBuilder.getPhysicalDevice();
		else
			return null;
	}


	private static PhysicalDevice buildDeviceRelationship(Node node)
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node);
		return physicalDeviceBuilder.getPhysicalDevice();
	}

	private static PhysicalDeviceBuilder buildBasicDevice(Node node)
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		physicalDeviceBuilder.buildPhysicalDevice(node.getName(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		physicalDeviceBuilder.setAdditionInfo("ConnectedDSLAM");
		return physicalDeviceBuilder;
	}

}

