package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;

public interface TransportPathDAO 
{

	
	public List<ARMImpactedCircuits> getTransportPathDAO(String query,Boolean sequenceStatus,Boolean circuitServiceTypeStatus)throws Exception;
}
