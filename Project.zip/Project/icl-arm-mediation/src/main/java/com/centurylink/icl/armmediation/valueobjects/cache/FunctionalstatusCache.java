package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Functionalstatus;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class FunctionalstatusCache implements ValueObjectCache {
	
	private Map<String, Functionalstatus> cachedObjects = new HashMap<String, Functionalstatus>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Functionalstatus newFunctionalstatus = new Functionalstatus(key);
			if (newFunctionalstatus.isInstanciated())
			{
				cachedObjects.put(key, newFunctionalstatus);
				return newFunctionalstatus;
			} else {
				return null;
			}
		}
	}

}
