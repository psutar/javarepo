package com.centurylink.icl.armmediation.transformation;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuitDetails;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CustomerAccountBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.UNICircuitBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchCircuitToCim
{
	private final SubNetworkConnectionBuilder subNetworkConnectionBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final CustomerAccountBuilder customerAccountBuilder;
	private final ConnectionTerminationPointBuilder connectionTerminationPointBuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final UNICircuitBuilder uniCircuitBuilder;
	private final LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder;
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final ResourceRelationshipBuilder resourceRelationshipBuilder;
	private final Point2PointCircuitBuilder point2PointCircuitBuilder;

	private static final Log LOG = LogFactory.getLog(SearchCircuitToCim.class);

	public SearchCircuitToCim()
	{
		subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		customerBuilder = new CustomerBuilder();
		customerAccountBuilder = new CustomerAccountBuilder();
		connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		uniCircuitBuilder = new UNICircuitBuilder();
		logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		physicalDeviceBuilder = new PhysicalDeviceBuilder();
		resourceRelationshipBuilder = new ResourceRelationshipBuilder();
		point2PointCircuitBuilder = new Point2PointCircuitBuilder();
	}

	public SearchResourceResponseDocument transformCircuitToCim(SearchResourceRequestDocument request, List<ARMCircuitDetails> armCircuitSummaryList, List<ARMCircuitDetails> armServiceSummaryList)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchCircuitToCim: SearchCircuitSummary : transformServiceForLocationToCim : ");
		}
		if ((armCircuitSummaryList != null && armCircuitSummaryList.size() > 0) || (armServiceSummaryList != null && armServiceSummaryList.size() > 0))
		{
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			
			if (armCircuitSummaryList != null && armCircuitSummaryList.size() > 0)
			{
				Iterator<ARMCircuitDetails> circuitIterator = ((List<ARMCircuitDetails>) armCircuitSummaryList).iterator();
				ARMCircuitDetails armCircuit = null;
				while (circuitIterator.hasNext())
				{
					armCircuit = circuitIterator.next();
					subNetworkConnectionBuilder.buildSubNetworkConnection(armCircuit.getCommonName(), armCircuit.getCktObjectId(), null, "ARM", armCircuit.getCircuitType(), armCircuit.getCktStatus(), null, null, null, null, armCircuit.getCktFuncStatus(), null);
					//subNetworkConnectionBuilder.buildSubNetworkConnection(armCircuit.getCommonName(), armCircuit.getCktObjectId(), null, "ARM", armCircuit.getCircuitType(), armCircuit.getCktStatus(), null, null);
					if (armCircuit.getEthBearerMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armCircuit.getEthBearerMCO());
					}
					if (armCircuit.getLagMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armCircuit.getLagMCO());
					}
					if(armCircuit.getExceptionHandlingText() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", armCircuit.getExceptionHandlingText());
					}
					if (armCircuit.getRelativeName() != null)
					{
						ownsResourceDetailsBuilder.buildOwnsResourceDetails();
						String subscriberName = armCircuit.getRelativeName();
						String acna = null;
						String customerId = null;

						if (subscriberName != null && subscriberName.length() <= 3)
						{
							acna = subscriberName;
						} else if (subscriberName != null && (subscriberName.length() > 3 && subscriberName.length() <= 6))
						{
							customerId = subscriberName;
						}
						customerBuilder.buildCustomer(subscriberName, null, null, armCircuit.getDescription(), null, null, acna);
						customerBuilder.setCustomerDetails(null, null, null, null, customerId);

						ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
						subNetworkConnectionBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
					}
					if (armCircuit.getCkt2StartLocation() != null)
					{
						connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(armCircuit.getStartLocationName(), armCircuit.getStartLocationObjectID(), null, "ARM", null, armCircuit.getStartLocationLocality(), armCircuit.getStartLocationPostcode(), armCircuit.getStartLocationAddressLine1(), armCircuit.getStartLocationAddressLine2(), armCircuit.getStartLocationAddressLine3(), armCircuit.getStartLocationStateOrProvince());
						connectionTerminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
						subNetworkConnectionBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
					}
					if (armCircuit.getCkt2EndLocation() != null)
					{
						connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(armCircuit.getEndLocationName(), armCircuit.getEndLocationObjectID(), null, "ARM", null, armCircuit.getEndLocationLocality(), armCircuit.getEndLocationPostcode(), armCircuit.getEndLocationAddressLine1(), armCircuit.getEndLocationAddressLine2(), armCircuit.getEndLocationAddressLine3(), armCircuit.getEndLocationStateOrProvince());
						connectionTerminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
						subNetworkConnectionBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
					}
					searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
				}
			}
			if (armServiceSummaryList != null && armServiceSummaryList.size() > 0)
			{
				Iterator<ARMCircuitDetails> serviceIterator = ((List<ARMCircuitDetails>) armServiceSummaryList).iterator();
				ARMCircuitDetails armService = null;
				while (serviceIterator.hasNext())
				{
					armService = serviceIterator.next();
					subNetworkConnectionBuilder.buildSubNetworkConnection(armService.getServiceName(), armService.getServiceID(), null, "ARM", armService.getServiceType(), armService.getServiceStatus(), null, null, null, null, armService.getServiceFuncStatus(), null);
					//subNetworkConnectionBuilder.buildSubNetworkConnection(armService.getServiceName(), armService.getServiceID(), null, "ARM", armService.getServiceType(), armService.getServiceStatus(), null, null);
					if (armService.getUniMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armService.getUniMCO());
					}
					if (armService.getEnniMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armService.getEnniMCO());
					}
					if (armService.getEvcMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armService.getEvcMCO());
					}
					if (armService.getOvcMCO() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("MCO", armService.getOvcMCO());
					}
					if(armService.getExceptionHandlingText() != null)
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", armService.getExceptionHandlingText());
					}
					if (armService.getSubscriberName() != null || armService.getSubscriberID() != null || armService.getBan() != null)
					{
						ownsResourceDetailsBuilder.buildOwnsResourceDetails();
						String subscriberName = armService.getSubscriberName();
						String acna = null;
						String customerId = null;

						if (subscriberName != null && subscriberName.length() <= 3)
						{
							acna = subscriberName;
						} else if (subscriberName != null && (subscriberName.length() > 3 && subscriberName.length() <= 6))
						{
							customerId = subscriberName;
						}
						customerBuilder.buildCustomer(subscriberName, null, null, armService.getDescription(), null, null, acna);
						customerBuilder.setCustomerDetails(null, null, null, null, customerId);
						if (armService.getBan() != null)
						{
							customerAccountBuilder.buildCustomerAccount(armService.getBan(), "BAN");
							customerBuilder.addCustomerPosseses(customerAccountBuilder.getCustomerAccount());
						}
						ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
						subNetworkConnectionBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
					}

					if (armService != null)
					{
						connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(armService.getLocationName(), armService.getLocationObjectID(), null, "ARM", null, armService.getLocality(), armService.getPostcode(), armService.getAddressLine1(), armService.getAddressLine2(), armService.getAddressLine3(), armService.getStateOrProvince());
						connectionTerminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
						subNetworkConnectionBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
					}
					searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
				}
			}
			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		} else
		{
			throw new OSSDataNotFoundException();
		}
	}

	public SearchResourceResponseDocument transformUniEnniDataToCim(SearchResourceRequestDocument request, List<ARMCircuit> uniEnniCircuitList, List<ARMCircuit> relatedCircuits)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchUNIENNIDetails : transformUniEnniDataToCim : ");
		}
		if (null != uniEnniCircuitList && uniEnniCircuitList.size() > 0)
		{
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			for (ARMCircuit uniEnniCircuit : uniEnniCircuitList)
			{
				String resourceType = null;

				if (null != uniEnniCircuit)
				{
					if (uniEnniCircuit.getResourceType() != null && uniEnniCircuit.getResourceType().equalsIgnoreCase("MEF UNI"))
					{
						resourceType = "UNI";

					} else if (uniEnniCircuit.getResourceType() != null && uniEnniCircuit.getResourceType().equalsIgnoreCase("MEF ENNI"))
					{
						resourceType = "ENNI";

					}
					uniCircuitBuilder.buildUNICircuit(uniEnniCircuit.getName(), uniEnniCircuit.getObjectID(), null, "ARM", resourceType, null, null, null);

					connectionTerminationPointBuilder.buildConnectionTerminationPoint(uniEnniCircuit.getPortName(), null, uniEnniCircuit.getPortTypeName());
					if (null != uniEnniCircuit.getBandwidthName())
					{
						connectionTerminationPointBuilder.addResourceDescribedBy("Bandwidth", uniEnniCircuit.getBandwidthName());
					}
					if (null != uniEnniCircuit.getNodeName())
					{
						logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
						physicalDeviceBuilder.buildPhysicalDevice(uniEnniCircuit.getNodeName(), null, null, null, null, null, null, uniEnniCircuit.getClliCode(), null, null, null, null, null, null);
						logicalPhysicalResourceBuilder.addPhysicalDevice(physicalDeviceBuilder.getPhysicalDevice());
						connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					}
					if (null != uniEnniCircuit.getPortName() || null != uniEnniCircuit.getPortTypeName() || null != uniEnniCircuit.getBandwidthName() || null != uniEnniCircuit.getNodeName())
					{
						uniCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
					}
					if (null != relatedCircuits && relatedCircuits.size() > 0)
					{
						for (ARMCircuit relatedCkt : relatedCircuits)
						{
							String relatedResourceType = null;
							if (null != relatedCkt)
							{
								if (null != relatedCkt.getResourceType() && relatedCkt.getResourceType().equals("MEF EVC"))
								{
									relatedResourceType = "EVC";
								} else if (null != relatedCkt.getResourceType() && relatedCkt.getResourceType().equals("MEF OVC"))
								{
									relatedResourceType = "OVC";
								}
								resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
								point2PointCircuitBuilder.buildPoint2PointCircuit(relatedCkt.getName(), null, null, null, relatedResourceType, null, null, null, null);
								if (null != relatedCkt.getNcCode())
								{
									point2PointCircuitBuilder.addResourceDescribedBy("NCCode", relatedCkt.getNcCode());

								}
								if (null != relatedCkt.getNciCode())
								{
									point2PointCircuitBuilder.addResourceDescribedBy("NCICode", relatedCkt.getNciCode());
								}
								if (null != relatedCkt.getSecNciCode())
								{
									point2PointCircuitBuilder.addResourceDescribedBy("SecNCICode", relatedCkt.getSecNciCode());
								}
								if (null != relatedCkt.getCircuitType() && relatedCkt.getCircuitType().equals("S-VLAN"))
								{
									point2PointCircuitBuilder.addResourceDescribedBy("S-VLAN", relatedCkt.getCircuitName());
								} else if (null != relatedCkt.getCircuitType() && relatedCkt.getCircuitType().equals("CE-VLAN"))
								{
									point2PointCircuitBuilder.addResourceDescribedBy("CE-VLAN", relatedCkt.getCircuitName());
								}
								if (null != relatedCkt.getName() || null != relatedCkt.getNcCode() || null != relatedCkt.getNciCode() || null != relatedCkt.getSecNciCode()
										|| null != relatedCkt.getCircuitType() || null != relatedCkt.getCircuitName())
								{
									resourceRelationshipBuilder.addCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
									uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
								}

							}
						}
					}
					searchResponseDetailsBuilder.addP2PCircuit(uniCircuitBuilder.getUNICircuit());
				}
			}
			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		} else
		{
			throw new OSSDataNotFoundException();
		}

	}

}
