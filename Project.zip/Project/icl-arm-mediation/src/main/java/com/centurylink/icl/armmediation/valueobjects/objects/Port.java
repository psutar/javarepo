package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;
import com.centurylink.icl.arm.domainlayer.metadata.types.PortMTOSI;
import com.centurylink.icl.arm.exception.ARMException;
import com.centurylink.icl.arm.util.CommonUtils;
import com.centurylink.icl.armmediation.valueobjects.objects.Reservation;


public class Port extends AbstractReadOnlyTable {

	private static final Log LOG = LogFactory.getLog(Port.class);
	
	private static final String LABEL = "LABEL";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String PORTID = "PORTID";
	private static final String NAME = "NAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String PORT2CARD = "PORT2CARD";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String PORT2NODE = "PORT2NODE";
	private static final String PORT2PORTTYPE = "PORT2PORTTYPE";
	private static final String PORT2BANDWIDTH = "PORT2BANDWIDTH";
	private static final String PARENTPORT2PORT = "PARENTPORT2PORT";
	private static final String AGGRPORT2PORT = "AGGRPORT2PORT";
	private static final String PORT2PROVISIONSTATUS = "PORT2PROVISIONSTATUS";
	private static final String PORT2LOCATION = "PORT2LOCATION";
	private static final String PROTOCOL = "PROTOCOL";
	private static final String PORTNUMBER = "PORTNUMBER";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String INTERFACE = "INTERFACE";
	private static final String DNA = "DNA";
	private static final String PORT2FUNCTIONALSTATUS = "PORT2FUNCTIONALSTATUS";
	private static final String FREELINKCONNECTIONS = "FREELINKCONNECTIONS";
	private static final String FREECROSSCONNECTIONS = "FREECROSSCONNECTIONS";
	private static final String FREECONDUCTORCONNECTIONS = "FREECONDUCTORCONNECTIONS";
	private static final String PORT2RPBUILDTEMPLATE = "PORT2RPBUILDTEMPLATE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String PORT_MTOSI = "PORT_MTOSI";

	private static final String OBJECTNAME = "OBJECTNAME";
	
	private Porttype porttype = null;
	private PortExtension portExtension = null;
	private Provisionstatus provisionstatus = null;
	private Functionalstatus functionalstatus = null;
	private Card card;
	private Node node;
	
	private Port topLevelPort = null;
	
	private List<Numberobject> numberobjectList = null;
	private List<Parameterset> parametersetList = null;
	
	
	public Port()
	{
		super();
		this.tableName = "PORT";
	}
	
	public Port(String portId)
	{
		this();
		primaryKey.setValue(portId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	

	public static List<Port> getPortListByQuery(String query)
	{
		Port port = new Port();
		List<Port> portList = new ArrayList<Port>();
		List<Map<String,Object>> foundPortList = port.getFullRecordsByQuery(query);
		
        for (Map<String,Object> portMap : foundPortList)
        {
        	Port ind = new Port();
            ind.instanciated = true;
            ind.populateFields(portMap);
            portList.add(ind);
        }
		
		return portList;
	}

	public static List<Port> getPortobjectList(String portid)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(portid))
		{
			query = PORTID + " = '" +  portid + "'";
			connector = " AND ";
		}
		
		
		return getPortListByQuery(query);
	}
	public static List<Port> getPortListByQuery(String query,boolean isLinkTables)
	{
		Port port = new Port();
		List<Port> portList = new ArrayList<Port>();
		List<Map<String,Object>> foundPortList = port.getRecordsByQuery(query,isLinkTables);
		
		for (Map<String,Object> portMap : foundPortList)
		{
			Port workPort = new Port(portMap.get(PORTID).toString());
			portList.add(workPort);
		}
		return portList;
	}
	protected List<Map<String,Object>> getRecordsByQuery(String query,boolean isLinkTables)
	{
		String statement = "SELECT distinct(" + this.tableName +"." + this.primaryKey.getName() + ") FROM " + this.tableName;
		//add only ext. tables,don't add other child tables when portfilter is false.
		if(!isLinkTables)
		{	
			linkedTables.clear();
			linkedTables.add(new LinkedTable("PORT", "EXT_PORT_TABLE", "PORTID", "PORTID", true));
			linkedTables.add(new LinkedTable("PORT", "EXT_PORT_PLUGGABLE", "PORTID", "PORTID", true));
			linkedTables.add(new LinkedTable("PORT", "EXT_PORT_OFC","PORTID", "PORTID",true));
			linkedTables.add(new LinkedTable("PORT", "NODE", "PORT2NODE", "NODEID", false));
			linkedTables.add(new LinkedTable("PORT", "PORTTYPE", "PORT2PORTTYPE", "PORTTYPEID", false));
			linkedTables.add(new LinkedTable("PORT", "PROVISIONSTATUS","PORT2PROVISIONSTATUS","PROVISIONSTATUSID",false));
			
		}
			
			for (LinkedTable linkedTable:linkedTables)
			{
				statement += ", " + linkedTable.getChildTableName();
				
			}
			
			statement += " WHERE 1=1 ";
	
			for (LinkedTable linkedTable:linkedTables)
			{
				statement += " AND " + linkedTable.getWhereClause() + " ";
			}
				
		statement += "AND " + query;
		
		LOG.debug("AbstractTable.getRecordsByQuery - statement: " + statement);
		LOG.info("AbstractTable.getRecordsByQuery - statement: " + statement);
		System.out.println("AbstractTable.getRecordsByQuery - statement: " + statement);
		
		List<Map<String,Object>> records = valueObjectDataAccessUtil.getRecordsAsList(statement);
		return records;
	}
	@Override
	public void populateModel()
	{
		//fields.put(PORT2PROVISIONSTATUS, new ReferenceField(PORT2PROVISIONSTATUS, Field.TYPE_NUMERIC, "PROVISIONSTATUS", "NAME", "PROVISIONSTATUSID"));
		//fields.put(PORT2PORTTYPE, new ReferenceField(PORT2PORTTYPE, Field.TYPE_NUMERIC, "PORTTYPE", "NAME", "PORTTYPEID"));
		fields.put(PORT2PROVISIONSTATUS, new Field(PORT2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(PORT2PORTTYPE, new Field(PORT2PORTTYPE, Field.TYPE_NUMERIC));

		//For now removing this as a ReferenceField so it doesn't cause a db hit each time when it's not really needed
		//fields.put(CREATEDBY2DIMUSER, new ReferenceField(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC, "DIMUSER", NAME, "DIMUSERID"));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));

		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(PORTID, new Field(PORTID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(PORT2CARD, new Field(PORT2CARD, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(PORT2NODE, new Field(PORT2NODE, Field.TYPE_NUMERIC));
		fields.put(PORT2BANDWIDTH, new Field(PORT2BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(PARENTPORT2PORT, new Field(PARENTPORT2PORT, Field.TYPE_NUMERIC));
		fields.put(AGGRPORT2PORT, new Field(AGGRPORT2PORT, Field.TYPE_NUMERIC));
		fields.put(PORT2LOCATION, new Field(PORT2LOCATION, Field.TYPE_NUMERIC));
		fields.put(PROTOCOL, new Field(PROTOCOL, Field.TYPE_VARCHAR));
		fields.put(PORTNUMBER, new Field(PORTNUMBER, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(INTERFACE, new Field(INTERFACE, Field.TYPE_VARCHAR));
		fields.put(DNA, new Field(DNA, Field.TYPE_VARCHAR));
		fields.put(PORT2FUNCTIONALSTATUS, new Field(PORT2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(FREELINKCONNECTIONS, new Field(FREELINKCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(FREECROSSCONNECTIONS, new Field(FREECROSSCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(FREECONDUCTORCONNECTIONS, new Field(FREECONDUCTORCONNECTIONS, Field.TYPE_NUMERIC));
		fields.put(PORT2RPBUILDTEMPLATE, new Field(PORT2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(PORTID));
		
		linkedTables.add(new LinkedTable("PORT", "EXT_PORT_TABLE", PORTID, PORTID, true));
		linkedTables.add(new LinkedTable("PORT", "EXT_PORT_PLUGGABLE", PORTID, PORTID, true));
		linkedTables.add(new LinkedTable("PORT", "EXT_PORT_OFC", PORTID, PORTID, true));
		linkedTables.add(new LinkedTable("PORT", "NODE", PORT2NODE, "NODEID", false));
		linkedTables.add(new LinkedTable("PORT", "PORTTYPE", PORT2PORTTYPE, "PORTTYPEID", false));
		linkedTables.add(new LinkedTable("PORT", "PROVISIONSTATUS",PORT2PROVISIONSTATUS,"PROVISIONSTATUSID",false));
		linkedTables.add(new LinkedTable("PORT", "CARD",PORT2CARD,"CARDID",false));
		linkedTables.add(new LinkedTable("CARD", "SLOT","CARD2SHELFSLOT","SLOTID",false));
		linkedTables.add(new LinkedTable("SLOT", "SHELF","SLOT2SHELF","SHELFID",false));
		
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setPortid(String portid)
	{
		setField(PORTID,portid);
	}

	public String getPortid()
	{
		return getFieldAsString(PORTID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setPort2card(String port2card)
	{
		setField(PORT2CARD,port2card);
	}

	public String getPort2card()
	{
		return getFieldAsString(PORT2CARD);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setPort2node(String port2node)
	{
		setField(PORT2NODE,port2node);
	}

	public String getPort2node()
	{
		return getFieldAsString(PORT2NODE);
	}

	public void setPort2porttype(String port2porttype)
	{
		setField(PORT2PORTTYPE,port2porttype);
	}

	public String getPort2porttype()
	{
		return getFieldAsString(PORT2PORTTYPE);
	}

	public void setPort2bandwidth(String port2bandwidth)
	{
		setField(PORT2BANDWIDTH,port2bandwidth);
	}

	public String getPort2bandwidth()
	{
		return getFieldAsString(PORT2BANDWIDTH);
	}

	public void setParentport2port(String parentport2port)
	{
		setField(PARENTPORT2PORT,parentport2port);
	}

	public String getParentport2port()
	{
		return getFieldAsString(PARENTPORT2PORT);
	}

	public void setAggrport2port(String aggrport2port)
	{
		setField(AGGRPORT2PORT,aggrport2port);
	}

	public String getAggrport2port()
	{
		return getFieldAsString(AGGRPORT2PORT);
	}

	public void setPort2provisionstatus(String port2provisionstatus)
	{
		setField(PORT2PROVISIONSTATUS,port2provisionstatus);
	}

	public String getPort2provisionstatus()
	{
		return getFieldAsString(PORT2PROVISIONSTATUS);
	}

	public void setPort2location(String port2location)
	{
		setField(PORT2LOCATION,port2location);
	}

	public String getPort2location()
	{
		return getFieldAsString(PORT2LOCATION);
	}

	public void setProtocol(String protocol)
	{
		setField(PROTOCOL,protocol);
	}

	public String getProtocol()
	{
		return getFieldAsString(PROTOCOL);
	}

	public void setPortnumber(String portnumber)
	{
		setField(PORTNUMBER,portnumber);
	}

	public String getPortnumber()
	{
		return getFieldAsString(PORTNUMBER);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setInterface(String intface)
	{
		setField(INTERFACE,intface);
	}

	public String getInterface()
	{
		return getFieldAsString(INTERFACE);
	}

	public void setDna(String dna)
	{
		setField(DNA,dna);
	}

	public String getDna()
	{
		return getFieldAsString(DNA);
	}

	public void setPort2functionalstatus(String port2functionalstatus)
	{
		setField(PORT2FUNCTIONALSTATUS,port2functionalstatus);
	}

	public String getPort2functionalstatus()
	{
		return getFieldAsString(PORT2FUNCTIONALSTATUS);
	}

	public void setFreelinkconnections(String freelinkconnections)
	{
		setField(FREELINKCONNECTIONS,freelinkconnections);
	}

	public String getFreelinkconnections()
	{
		return getFieldAsString(FREELINKCONNECTIONS);
	}

	public void setFreecrossconnections(String freecrossconnections)
	{
		setField(FREECROSSCONNECTIONS,freecrossconnections);
	}

	public String getFreecrossconnections()
	{
		return getFieldAsString(FREECROSSCONNECTIONS);
	}

	public void setFreeconductorconnections(String freeconductorconnections)
	{
		setField(FREECONDUCTORCONNECTIONS,freeconductorconnections);
	}

	public String getFreeconductorconnections()
	{
		return getFieldAsString(FREECONDUCTORCONNECTIONS);
	}

	public void setPort2rpbuildtemplate(String port2rpbuildtemplate)
	{
		setField(PORT2RPBUILDTEMPLATE,port2rpbuildtemplate);
	}

	public String getPort2rpbuildtemplate()
	{
		return getFieldAsString(PORT2RPBUILDTEMPLATE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}
	
	public Porttype getPorttype()
	{
		if (porttype == null)
		{
			porttype = (Porttype) ValueObjectCacheAccessorFactory.getValueObjectCache("porttype").getCacheObject(getField(PORT2PORTTYPE).toString());
		}
		
		return porttype;
	}

	public Provisionstatus getProvisionstatus()
	{
		if (provisionstatus == null)
		{
			provisionstatus = (Provisionstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("provisionstatus").getCacheObject(getField(PORT2PROVISIONSTATUS).toString());
		}
		
		return provisionstatus;
	}

	public PortExtension getPortExtension()
	{
		if (portExtension == null)
		{
			portExtension = new PortExtension(fields.get(PORTID), this.getPorttype().getTablename());
		}
		
		return portExtension;
	}

	public Functionalstatus getFunctionalstatus()
	{
		if (functionalstatus == null)
		{
			if(getField(PORT2FUNCTIONALSTATUS)!=null)
			functionalstatus = (Functionalstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("functionalstatus").getCacheObject(getField(PORT2FUNCTIONALSTATUS).toString());
			if (functionalstatus == null)
			{
				functionalstatus = new Functionalstatus();
			}
		}
		
		return functionalstatus;
	}
	
	
	public Port getTopLevelPort()
	{
		if (topLevelPort == null)
		{
			if (StringHelper.isEmpty(this.getParentport2port()))
			{
				topLevelPort = this;
			} else {
				Port workPort = new Port(this.getParentport2port());
				while (!StringHelper.isEmpty(workPort.getParentport2port()))
				{
					workPort = new Port(workPort.getParentport2port());
				}
				topLevelPort = workPort;
			}
		}
		
		return topLevelPort;
	}
	
	public boolean isOnCard()
	{
		if (!StringHelper.isEmpty(this.getPort2card()))
			return true;
		else
			return false;
	}
	
	public Card getCard()
	{
		if (card == null)
		{
			if (StringHelper.isEmpty(this.getPort2card()))
			{
				card = new Card();
			} else {
				card = new Card(this.getPort2card());
			}
		}
		return card;
	}

	public Node getNode()
	{
		if (node == null)
		{
			if (StringHelper.isEmpty(this.getPort2node()))
			{
				node = new Node();
			} else {
				node = new Node(this.getPort2node());
			}
		}
		return node;
	}
	
	public List<Numberobject> getNumberObjectList()
	{
		if (numberobjectList == null)
		{
			numberobjectList = Numberobject.getNumberobjectListByObjectIdandDimObjectandRelationship(getPortid(), "4", null);
		}
		
		return numberobjectList;
	}
	
	public List<Parameterset> getParametersetList()
	{
		if (parametersetList == null)
		{
			parametersetList = Parameterset.getParametersetListByObjectIdandDimObjectandRelationship(getPortid(), "4");
		}
		
		return parametersetList;
	}
	
	public String getPortReservationByQuery(String id, String dimType)
	{              
	              Reservation reservation = new Reservation();	              
	              reservation = reservation.getPortReservationObject(id , dimType);	              
	              if(null == reservation){
	            return "N";
	      }
	      return "Y";    
	}
	
	public String getSfpName(String portId) 
	{
		ExtPortNic2Pluggable extPortNic2Pluggable = new ExtPortNic2Pluggable();		
		return extPortNic2Pluggable.getSfpName(portId);		
	}
	
	public Bandwidth getBandwidthObject()
	{
		Bandwidth bandwidth=null;
		if(this.getPort2bandwidth() != null)
			bandwidth=new Bandwidth(this.getPort2bandwidth());
		
		return bandwidth;
	}
	
	public String getPortMTOSI(String portId) 
    {
		 String query = "Select customization.PKGCTLPortUtils.getPortIdentifier(p.portid) PORT_MTOSI from port p where p.portid='"+portId+"'";
         List<Map<String,Object>> portMTOSIList = new ArrayList<Map<String,Object>>();
         portMTOSIList = valueObjectDataAccessUtil.getRecordsAsList(query);
         return portMTOSIList.get(0).get(PORT_MTOSI).toString();
  
    }
	
	public String getONTEthernetPortName(String cktId)
	{
		String query =  "Select ARMAPI.PKGARMCIRCUITCUSTOMIZATIONS.getPortIdforNtwkRole('"+cktId+"','ONT') as objectName from dual";
		List<Map<String,Object>> ontEthernetPortNameList = new ArrayList<Map<String,Object>>();
		ontEthernetPortNameList = valueObjectDataAccessUtil.getRecordsAsList(query);

		String query2 =  "Select ARMAPI.PKGARMPORTCUSTOMIZATIONS.getPhysicalPortFromLogical('"+ ontEthernetPortNameList.get(0).get(OBJECTNAME).toString() +"') as objectName from dual";
		List<Map<String,Object>> ontEthernetPortNameListForPhysicalPort = new ArrayList<Map<String,Object>>();
		ontEthernetPortNameListForPhysicalPort = valueObjectDataAccessUtil.getRecordsAsList(query2);
        return ontEthernetPortNameListForPhysicalPort.get(0).get(OBJECTNAME).toString();	
        		
	}
	
			
}