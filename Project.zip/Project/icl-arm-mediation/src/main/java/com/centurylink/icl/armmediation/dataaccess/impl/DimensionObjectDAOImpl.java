package com.centurylink.icl.armmediation.dataaccess.impl;

import java.math.BigDecimal;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.centurylink.icl.armmediation.dataaccess.DimensionObjectDAO;

public class DimensionObjectDAOImpl implements DimensionObjectDAO
{

	private JdbcTemplate	jdbcTemplate;

	public DimensionObjectDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public BigDecimal getDimensionObjectID(String name)
	{
		return jdbcTemplate.queryForObject("Select DIMENSIONOBJECTID from DIMENSIONOBJECT where name = ?", new Object[] { name }, BigDecimal.class);
	}

	@Override
	public BigDecimal getDimensionRelationShipID(String relationName)
	{
		return jdbcTemplate.queryForObject("select DIMENSIONRELATIONSHIPID from DIMENSIONRELATIONSHIP where name = ?", new Object[] { relationName }, BigDecimal.class);
	}

}
