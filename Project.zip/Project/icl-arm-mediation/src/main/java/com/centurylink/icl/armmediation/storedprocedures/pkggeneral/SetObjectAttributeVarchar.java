package com.centurylink.icl.armmediation.storedprocedures.pkggeneral;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class SetObjectAttributeVarchar extends StoredProcedure
{

	private static final Log	LOG	= LogFactory.getLog(AddToObjAttrListNumber.class);

	public SetObjectAttributeVarchar(DataSource dataSource, String procName)
	{
		super(dataSource, procName);

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlParameter("i_dimobject", Types.NUMERIC));
		declareParameter(new SqlParameter("i_objectid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_attribute", Types.VARCHAR));
		declareParameter(new SqlParameter("i_value", Types.VARCHAR));

		compile();

	}

	public Map<String, Object> execute(BigDecimal i_dimobject, BigDecimal i_objectid, String i_attribute, String i_value)
	{
		final Map<String, Object> in = new HashMap<String, Object>();

		in.put("i_dimobject", i_dimobject);
		in.put("i_objectid", i_objectid);
		in.put("i_attribute", i_attribute);
		in.put("i_value", i_value);

		return super.execute(in);
	}

}
