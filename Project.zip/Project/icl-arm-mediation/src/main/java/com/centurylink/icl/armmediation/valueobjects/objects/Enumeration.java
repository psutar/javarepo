package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Enumeration extends AbstractReadOnlyTable {

	private static String VALUE="VALUE";
	private static String ENUMERATIONID="ENUMERATIONID";
	public Enumeration()
	{
		super();
		this.tableName = "ENUMERATION";
	}

	public Enumeration(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(VALUE, new Field(VALUE, Field.TYPE_VARCHAR));
		fields.put(ENUMERATIONID, new Field(ENUMERATIONID, Field.TYPE_NUMERIC));
		primaryKey = new PrimaryKey(fields.get(ENUMERATIONID));
	}
	
	public static String getCosIdValue(String filedName,String sequence){
		
		String cosValue=null;
			String query = "TABLENAME = 'PARAMETERDEFINITION_M' " + " AND UPPER(FIELDNAME)='" + filedName + "'" +" AND SEQUENCE="+sequence;
			
			List<Enumeration> enumeration=Enumeration.getEnumerationTypeListByQuery(query);
			
			for(Enumeration enm:enumeration){
				cosValue= enm.getValue();
			}
			
		return cosValue;
	}

	public String getValue() {
		
		return getFieldAsString(VALUE);
	}

	public void setValue(String value) {
			setField(VALUE,value);
	}

	public static List<Enumeration> getEnumerationTypeListByQuery(String query)
	{
		Enumeration enumeration = new Enumeration();
		List<Enumeration> enumerationObjectList = new ArrayList<Enumeration>();
		List<Map<String,Object>> foundEnumerationTypeList = enumeration.getRecordsByQuery(query);
		
		for (Map<String,Object> enumerationobjectMap : foundEnumerationTypeList)
		{
			Enumeration workServiceobject = new Enumeration(enumerationobjectMap.get(ENUMERATIONID).toString());
			enumerationObjectList.add(workServiceobject);
		}
		
		return enumerationObjectList;
	}

	public String getEnumerationId() {
		
		return getFieldAsString(ENUMERATIONID);
	}

	public  void setEnumerationId(String enumerationId) {
		setField(ENUMERATIONID,enumerationId);
	
		
	}
	
	public static String getEnumerationValue(String tableName, String filedName, String sequence){
			
			String value=null;
				String query = "TABLENAME = '" + tableName + "' " + " AND UPPER(FIELDNAME)='" + filedName + "'" +" AND SEQUENCE="+sequence;
				
				List<Enumeration> enumeration=Enumeration.getEnumerationTypeListByQuery(query);
				
				for(Enumeration enm:enumeration){
					value= enm.getValue();
				}
				
			return value;
	}
	
}
