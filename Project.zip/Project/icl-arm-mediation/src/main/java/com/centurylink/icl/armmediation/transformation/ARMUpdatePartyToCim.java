package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.PartyBuilder;
import com.centurylink.icl.builder.cim2.UpdatePartyResponseBuilder;
import com.centurylink.icl.builder.cim2.UpdatePartyResponseDocumentBuilder;
import com.iclnbi.iclnbiV200.UpdatePartyRequestDocument;
import com.iclnbi.iclnbiV200.UpdatePartyResponseDocument;

public class ARMUpdatePartyToCim {

	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final UpdatePartyResponseDocumentBuilder    updatePartyResponseDocumentBuilder;
	private final UpdatePartyResponseBuilder		    updatePartyResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;
	private final PartyBuilder                          partyBuilder;
	
	public ARMUpdatePartyToCim()
	{
		updatePartyResponseBuilder = new UpdatePartyResponseBuilder();
		updatePartyResponseDocumentBuilder = new UpdatePartyResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
		partyBuilder = new PartyBuilder();
	}
	
	public UpdatePartyResponseDocument transformToCim(UpdatePartyRequestDocument updateRequest, String objectID,String commonName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("UpdateParty : Transform to CIM");
		}
		
		String partyId= updateRequest.getUpdatePartyRequest().getPartyDetails().getPartyId();
		String partyRoleType= updateRequest.getUpdatePartyRequest().getPartyDetails().getPartyRoleType();
		updatePartyResponseDocumentBuilder.buildUpdatePartyResponseDocumentBuilder();
		updatePartyResponseBuilder.buildUpdatePartyResponse();
		partyBuilder.buildParty(commonName, objectID, partyId, partyRoleType);
		updatePartyResponseBuilder.addParty(partyBuilder.getParty());
		updatePartyResponseDocumentBuilder.addUpdatePartyResponse(updatePartyResponseBuilder.getUpdatePartyResponse());
		return updatePartyResponseDocumentBuilder.getUpdatePartyResponseDocument();
	}
	
	public UpdatePartyResponseDocument transformErrorToCim(UpdatePartyRequestDocument updateRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("UpdateParty : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(updateRequest.getUpdatePartyRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		updatePartyResponseBuilder.buildUpdatePartyResponse();
		updatePartyResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		updatePartyResponseDocumentBuilder.buildUpdatePartyResponseDocumentBuilder(updatePartyResponseBuilder.getUpdatePartyResponse());
		return updatePartyResponseDocumentBuilder.getUpdatePartyResponseDocument();
	}
}
