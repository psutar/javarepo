package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

public interface GetDeviceListForCLLIDAO
{
	public List<String> getDeviceListForCLLI(String clli);
}
