package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.DeleteLocationResponseBuilder;
import com.centurylink.icl.builder.cim2.DeleteLocationResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.DeleteLocationRequestDocument;
import com.iclnbi.iclnbiV200.DeleteLocationResponseDocument;

public class ARMDeleteLocationToCim
{
	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final DeleteLocationResponseDocumentBuilder deleteLocationResponseDocumentBuilder;
	private final DeleteLocationResponseBuilder		    deleteLocationResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;

	public ARMDeleteLocationToCim()
	{
		deleteLocationResponseBuilder = new DeleteLocationResponseBuilder();
		deleteLocationResponseDocumentBuilder = new DeleteLocationResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
	}
	
	public DeleteLocationResponseDocument transformToCim(DeleteLocationRequestDocument deleteRequest, String objectName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("DeleteLocation : Transform to CIM");
		}

		final AmericanPropertyAddress addressDetails = deleteRequest.getDeleteLocationRequest().getAddressDetails();
		//addressDetails.setObjectID(objectName);
		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(deleteRequest.getDeleteLocationRequest().getMessageElements().getMessageAddressing());

		deleteLocationResponseBuilder.buildDeleteLocationResponse();
		deleteLocationResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		deleteLocationResponseBuilder.addAddressDetails(addressDetails);
		deleteLocationResponseDocumentBuilder.buildDeleteLocationResponseDocument(deleteLocationResponseBuilder.getDeleteLocationResponse());
		//deleteLocationResponseDocumentBuilder.
		return deleteLocationResponseDocumentBuilder.getDeleteLocationResponseDocument();
	}
	
	public DeleteLocationResponseDocument transformErrorToCim(DeleteLocationRequestDocument deleteRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("DeleteLocation : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(deleteRequest.getDeleteLocationRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		deleteLocationResponseBuilder.buildDeleteLocationResponse();
		deleteLocationResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		deleteLocationResponseDocumentBuilder.buildDeleteLocationResponseDocument(deleteLocationResponseBuilder.getDeleteLocationResponse());
		return deleteLocationResponseDocumentBuilder.getDeleteLocationResponseDocument();
	}


}
