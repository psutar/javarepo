package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.CreateCircuitResponseBuilder;
import com.centurylink.icl.builder.cim2.CreateCircuitResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;

public class ARMCreateServiceToCim
{

	private static final Log							LOG	= LogFactory.getLog(ARMCreateServiceToCim.class);

	private final CreateCircuitResponseDocumentBuilder	createCircuitResponseDocumentBuilder;
	private final CreateCircuitResponseBuilder			createCircuitResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;
	private final Point2PointCircuitBuilder				point2PointCircuitBuilder;

	public ARMCreateServiceToCim()
	{
		createCircuitResponseBuilder = new CreateCircuitResponseBuilder();
		createCircuitResponseDocumentBuilder = new CreateCircuitResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
		point2PointCircuitBuilder = new Point2PointCircuitBuilder();
	}

	public CreateCircuitResponseDocument transformErrorToCim(CreateCircuitRequestDocument requestObject, String errorText)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateCircuit : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(requestObject.getCreateCircuitRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError("1947", "ICLInternalError", "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		createCircuitResponseBuilder.buildCreateCircuitResponse();
		createCircuitResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createCircuitResponseDocumentBuilder.buildCreateCircuitResponseDocument(createCircuitResponseBuilder.getCreateCircuitResponse());
		return createCircuitResponseDocumentBuilder.getCreateCircuitResponseDocument();
	}

	public CreateCircuitResponseDocument transformToCim(CreateCircuitRequestDocument requestObject, String value, String serviceName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateCircuit : Transform to CIM");
		}
		ClassLoader mainLoader = Thread.currentThread().getContextClassLoader();
		Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
		try
		{
		point2PointCircuitBuilder.buildPoint2PointCircuit(serviceName, value, null, "ARM", requestObject.getCreateCircuitRequest().getP2PCircuitList().get(0).getResourceType(), null, null, null, null);

		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(requestObject.getCreateCircuitRequest().getMessageElements().getMessageAddressing());

		createCircuitResponseBuilder.buildCreateCircuitResponse();
		createCircuitResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createCircuitResponseBuilder.addPointToPointCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
		createCircuitResponseDocumentBuilder.buildCreateCircuitResponseDocument(createCircuitResponseBuilder.getCreateCircuitResponse());
		return createCircuitResponseDocumentBuilder.getCreateCircuitResponseDocument();
		}
		finally
		{
					Thread.currentThread().setContextClassLoader(mainLoader);
		}
	}
}
