package com.centurylink.icl.armmediation.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.GetTopologyDetailsToCim;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class GetTopologyDetailsService {
	private static final Log LOG = LogFactory.getLog(GetTopologyDetailsService.class);
	private SearchDeviceDAO searchDeviceDAO;
	List<ARMDevice> armdeviceList = null;
	public void setSearchDeviceDAO(SearchDeviceDAO searchDeviceDAO)
	{
		this.searchDeviceDAO = searchDeviceDAO;
	}

	public Object searchTopologyDetails(SearchResourceRequestDocument request) throws Exception
	{
		String Query=null;
		Node node=null;
		if (LOG.isInfoEnabled())
		{
			LOG.info("GetTopologyDetailsService: searchTopologyDetails");
		}

		final String deviceName = MediationUtil.getRcv(request, "DeviceName");
		if(deviceName!=null)
			Query="NODE.NAME='"+deviceName+"'";

		if(Query!=null)
			if(Node.getNodeListByQuery(Query)!=null&&Node.getNodeListByQuery(Query).size()>0)
				node=Node.getNodeListByQuery(Query).get(0);

		if(node!=null)
		{
			armdeviceList=searchDeviceDAO.getDeviceinTopology(buildDeviceQuery(deviceName));
			GetTopologyDetailsToCim getTopologyDetailsToCim =  new GetTopologyDetailsToCim();
			final SearchResourceResponseDocument response =	getTopologyDetailsToCim.transformToCim(armdeviceList,request);
			return response;
		}
		else
		{
			throw new OSSDataNotFoundException();
		}

	}

	public String buildDeviceQuery(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.NODE);
		sql.addTable(Constants.NETWORKROLE);
		sql.addTable(Constants.NETWORKROLEOBJECT);
		sql.addTable("TOPOBJECT");
		sql.addTable("TOPOBJECT","TOPOB");
		sql.addTable(Constants.NODE,"ND");
		sql.addTable("TOPOLOGY");
		sql.addTable("TOPOLOGYTYPE");
		sql.addFieldFromTable(Constants.NODE, Constants.NAME);
		sql.addFieldFromTable(Constants.NETWORKROLE, Constants.ALIAS_1);	
		sql.addFieldFromTable("TOPOLOGY", Constants.NAME, "TOPOLOGY_NAME");
		sql.addFieldFromTable("TOPOLOGYTYPE", Constants.NAME, "TOPOLOGY_TYPE");
		sql.eq("ND", Constants.NAME, deviceName);
		sql.joinFO("ND", "NODEID","TOPOBJECT", "TOPOBJECT2OBJECT");
		sql.joinFO("TOPOBJECT", "TOPOBJECT2TOPOLOGY", "TOPOB", "TOPOBJECT2TOPOLOGY");
		sql.eq(Constants.NODE, "NODEID", "TOPOB", "TOPOBJECT2OBJECT");
		sql.joinFO( "NODE", "NODEID",Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2OBJECT");
		sql.joinFO(Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2NETWORKROLE",Constants.NETWORKROLE,"NETWORKROLEID");
		sql.eq("TOPOLOGY", "TOPOLOGYID","TOPOB","TOPOBJECT2TOPOLOGY");
		sql.eq("TOPOLOGYTYPE", "TOPOLOGYTYPEID","TOPOLOGY","TOPOLOGY2TOPOLOGYTYPE");
		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildDeviceQuery ::" + query);
		}
		System.out.println("buildDeviceQuery ::" + query);
		return query;
	}
	
	
	
}
