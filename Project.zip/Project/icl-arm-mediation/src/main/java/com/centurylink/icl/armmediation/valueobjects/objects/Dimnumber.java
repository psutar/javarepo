package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Dimnumber extends AbstractReadOnlyTable {

	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String RPPLANID = "RPPLANID";
	private static final String NUMBER2RPBUILDTEMPLATE = "NUMBER2RPBUILDTEMPLATE";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String DIMNUMBERLEVEL = "DIMNUMBERLEVEL";
	private static final String DIMNUMBER2ROOTDIMNUMBER = "DIMNUMBER2ROOTDIMNUMBER";
	private static final String DIMNUMBER2UNIQUEDIMNUMBER = "DIMNUMBER2UNIQUEDIMNUMBER";
	private static final String VALUETO = "VALUETO";
	private static final String VALUEFROM = "VALUEFROM";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String DIMNUMBER2FUNCTIONALSTATUS = "DIMNUMBER2FUNCTIONALSTATUS";
	private static final String DIMNUMBER2PROVISIONSTATUS = "DIMNUMBER2PROVISIONSTATUS";
	private static final String DIMNUMBER2DIMNUMBERTYPE = "DIMNUMBER2DIMNUMBERTYPE";
	private static final String PARENTDIMNUMBER2DIMNUMBER = "PARENTDIMNUMBER2DIMNUMBER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String NOTES = "NOTES";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String OBJECTID = "OBJECTID";
	private static final String ALIAS2 = "ALIAS2";
	private static final String ALIAS1 = "ALIAS1";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String NAME = "NAME";
	private static final String DIMNUMBERID = "DIMNUMBERID";
	
	private Dimnumbertype dimnumbertype;
	private DimnumberExtension dimnumberExtension;

	public Dimnumber()
	{
		super();
		this.tableName = "DIMNUMBER";
	}

	public Dimnumber(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Dimnumber> getDimnumberListByQuery(String query)
	{
		Dimnumber dimnumber = new Dimnumber();
		List<Dimnumber> dimnumberList = new ArrayList<Dimnumber>();
		List<Map<String,Object>> foundDimnumberList = dimnumber.getRecordsByQuery(query);

		for (Map<String,Object> dimnumberMap : foundDimnumberList)
		{
			Dimnumber workDimnumber = new Dimnumber(dimnumberMap.get(DIMNUMBERID).toString());
			dimnumberList.add(workDimnumber);
		}
		return dimnumberList;
	}

	@Override
	public void populateModel()
	{
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(NUMBER2RPBUILDTEMPLATE, new Field(NUMBER2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBERLEVEL, new Field(DIMNUMBERLEVEL, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBER2ROOTDIMNUMBER, new Field(DIMNUMBER2ROOTDIMNUMBER, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBER2UNIQUEDIMNUMBER, new Field(DIMNUMBER2UNIQUEDIMNUMBER, Field.TYPE_NUMERIC));
		fields.put(VALUETO, new Field(VALUETO, Field.TYPE_VARCHAR));
		fields.put(VALUEFROM, new Field(VALUEFROM, Field.TYPE_VARCHAR));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBER2FUNCTIONALSTATUS, new Field(DIMNUMBER2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBER2PROVISIONSTATUS, new Field(DIMNUMBER2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBER2DIMNUMBERTYPE, new Field(DIMNUMBER2DIMNUMBERTYPE, Field.TYPE_NUMERIC));
		fields.put(PARENTDIMNUMBER2DIMNUMBER, new Field(PARENTDIMNUMBER2DIMNUMBER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(DIMNUMBERID, new Field(DIMNUMBERID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(DIMNUMBERID));
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setNumber2rpbuildtemplate(String number2rpbuildtemplate)
	{
		setField(NUMBER2RPBUILDTEMPLATE,number2rpbuildtemplate);
	}

	public String getNumber2rpbuildtemplate()
	{
		return getFieldAsString(NUMBER2RPBUILDTEMPLATE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setDimnumberlevel(String dimnumberlevel)
	{
		setField(DIMNUMBERLEVEL,dimnumberlevel);
	}

	public String getDimnumberlevel()
	{
		return getFieldAsString(DIMNUMBERLEVEL);
	}

	public void setDimnumber2rootdimnumber(String dimnumber2rootdimnumber)
	{
		setField(DIMNUMBER2ROOTDIMNUMBER,dimnumber2rootdimnumber);
	}

	public String getDimnumber2rootdimnumber()
	{
		return getFieldAsString(DIMNUMBER2ROOTDIMNUMBER);
	}

	public void setDimnumber2uniquedimnumber(String dimnumber2uniquedimnumber)
	{
		setField(DIMNUMBER2UNIQUEDIMNUMBER,dimnumber2uniquedimnumber);
	}

	public String getDimnumber2uniquedimnumber()
	{
		return getFieldAsString(DIMNUMBER2UNIQUEDIMNUMBER);
	}

	public void setValueto(String valueto)
	{
		setField(VALUETO,valueto);
	}

	public String getValueto()
	{
		return getFieldAsString(VALUETO);
	}

	public void setValuefrom(String valuefrom)
	{
		setField(VALUEFROM,valuefrom);
	}

	public String getValuefrom()
	{
		return getFieldAsString(VALUEFROM);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setDimnumber2functionalstatus(String dimnumber2functionalstatus)
	{
		setField(DIMNUMBER2FUNCTIONALSTATUS,dimnumber2functionalstatus);
	}

	public String getDimnumber2functionalstatus()
	{
		return getFieldAsString(DIMNUMBER2FUNCTIONALSTATUS);
	}

	public void setDimnumber2provisionstatus(String dimnumber2provisionstatus)
	{
		setField(DIMNUMBER2PROVISIONSTATUS,dimnumber2provisionstatus);
	}

	public String getDimnumber2provisionstatus()
	{
		return getFieldAsString(DIMNUMBER2PROVISIONSTATUS);
	}

	public void setDimnumber2dimnumbertype(String dimnumber2dimnumbertype)
	{
		setField(DIMNUMBER2DIMNUMBERTYPE,dimnumber2dimnumbertype);
	}

	public String getDimnumber2dimnumbertype()
	{
		return getFieldAsString(DIMNUMBER2DIMNUMBERTYPE);
	}

	public void setParentdimnumber2dimnumber(String parentdimnumber2dimnumber)
	{
		setField(PARENTDIMNUMBER2DIMNUMBER,parentdimnumber2dimnumber);
	}

	public String getParentdimnumber2dimnumber()
	{
		return getFieldAsString(PARENTDIMNUMBER2DIMNUMBER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setDimnumberid(String dimnumberid)
	{
		setField(DIMNUMBERID,dimnumberid);
	}

	public String getDimnumberid()
	{
		return getFieldAsString(DIMNUMBERID);
	}

	public Dimnumbertype getDimnumbertype()
	{
		if (dimnumbertype == null)
		{
			dimnumbertype = (Dimnumbertype) ValueObjectCacheAccessorFactory.getValueObjectCache("dimnumbertype").getCacheObject(getField(DIMNUMBER2DIMNUMBERTYPE).toString());
		}
		
		return dimnumbertype;
	}
	
	public DimnumberExtension getDimnumberExtension()
	{
		if (dimnumberExtension == null)
		{
			dimnumberExtension = new DimnumberExtension(fields.get(DIMNUMBERID), getDimnumbertype().getTablename());
		}

		return dimnumberExtension;
	}

}