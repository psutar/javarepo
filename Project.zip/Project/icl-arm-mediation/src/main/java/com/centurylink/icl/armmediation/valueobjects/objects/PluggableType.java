package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;


public class PluggableType extends AbstractReadOnlyTable {
	
	private static final Log LOG = LogFactory.getLog(PluggableType.class);
	private static final String PLUGGABLETYPEID = "PLUGGABLETYPEID";
	private static final String NAME = "NAME";
	
	public PluggableType()
	{
		super();
		this.tableName = "PLUGGABLETYPE";
	}
	public PluggableType(String pluggableTypeId)
	{
		this();
		primaryKey.setValue(pluggableTypeId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	@Override
	public void populateModel() {
		fields.put(PLUGGABLETYPEID, new Field(PLUGGABLETYPEID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(PLUGGABLETYPEID));
	}
	
	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}
	
	public void setPluggabletypeid(String pluggabletypeid)
	{
		setField(PLUGGABLETYPEID,pluggabletypeid);
	}

	public String getPluggabletypeid()
	{
		return getFieldAsString(PLUGGABLETYPEID);
	}
	
	public String getPluggableTypeById(String pluggabletypeId) 
	{
		String query = "PLUGGABLETYPEID= "+ pluggabletypeId; 
		PluggableType pluggableType = new PluggableType();
		List<Map<String,Object>> pluggableTypeList = pluggableType.getFullRecordsByQuery(query);
		
		for (Map<String,Object> pluggableTypeObj : pluggableTypeList)
		{
			if(null != pluggableTypeObj.get(NAME)){
				return pluggableTypeObj.get(NAME).toString();				
			}
		}		
		
		return null;		
	}
	public String pluggableTypeByPortId(String portId) 
	{
		   Port port = new Port(); 
		   Pluggable pluggable = new Pluggable();
		   PluggableType pluggableType = new PluggableType();       
		   String  pluggableTypeName  = null;
		   String sfpName = port.getSfpName(portId);		   
		   if(null != sfpName && sfpName.length() > 0){
	       String pluggableTypeId =  pluggable.getPluggableByName(sfpName);	      
	       pluggableTypeName  = pluggableType.getPluggableTypeById(pluggableTypeId);
	       }
		   return pluggableTypeName;
	}
}
