package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class SlaTargetTemplate extends AbstractReadOnlyTable {

	private static String PM_SLA_ID="PM_SLA_ID";
	private static String TEMPLATE_NAME="TEMPLATE_NAME";
	
	public SlaTargetTemplate()
	{
		super();
		this.tableName = "SLA_TARGET_TEMPLATE";
	}
	
	public SlaTargetTemplate(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static SlaTargetTemplate getSlaObject(String slaAgreementTemplate)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(slaAgreementTemplate))
		{
			query = TEMPLATE_NAME + " = '" +  slaAgreementTemplate + "'";
			connector = " AND ";
		}
				
		return getSlaByQuery(query);
	}

	public static SlaTargetTemplate getSlaByQuery(String query)
	{
		SlaTargetTemplate slaTemplate = new SlaTargetTemplate();
		List<SlaTargetTemplate> slaTemplateList = new ArrayList<SlaTargetTemplate>();
		List<Map<String,Object>> foundSlaTemplateList = slaTemplate.getRecordsByQuery(query);

		SlaTargetTemplate workslaTemplate=null;
		for (Map<String,Object> slaTemplateMap : foundSlaTemplateList)
		{
			workslaTemplate = new SlaTargetTemplate(slaTemplateMap.get(PM_SLA_ID).toString());
			if(workslaTemplate != null)
				return workslaTemplate;
		}
		
		return workslaTemplate;
	}
	
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub

		fields.put(PM_SLA_ID, new Field(PM_SLA_ID, Field.TYPE_NUMERIC));
		fields.put(TEMPLATE_NAME, new Field(TEMPLATE_NAME, Field.TYPE_VARCHAR));
		
		primaryKey = new PrimaryKey(fields.get(PM_SLA_ID));
	}
	public String getPmSlaId() {
		return getFieldAsString(PM_SLA_ID);
	}
	public void setPmSlaId(String pmSlaId) {
		setField(PM_SLA_ID,pmSlaId);
	}
	public String getTemplateName() {
		return getFieldAsString(TEMPLATE_NAME);
	}
	public void setTemplateName(String templateName) {
		setField(TEMPLATE_NAME,templateName);
	}

}
