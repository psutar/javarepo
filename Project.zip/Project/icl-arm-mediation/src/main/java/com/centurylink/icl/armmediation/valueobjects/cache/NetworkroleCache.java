package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Networkrole;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class NetworkroleCache implements ValueObjectCache {
	
	private Map<String, Networkrole> cachedObjects = new HashMap<String, Networkrole>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Networkrole newNetworkrole = new Networkrole(key);
			if (newNetworkrole.isInstanciated())
			{
				cachedObjects.put(key, newNetworkrole);
				return newNetworkrole;
			} else {
				return null;
			}
		}
	}

}
