package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class ExtPortNic2Pluggable extends AbstractReadOnlyTable {

	
	private static final Log LOG = LogFactory.getLog(ExtPortNic2Pluggable.class);	
	
	private static final String PORTID = "PORTID";
	private static final String CONNECTORTYPE = "CONNECTORTYPE";
	private static final String MAXPONCIRCUIT = "MAXPONCIRCUIT";
	private static final String LABEL = "LABEL";
	private static final String RESTRICTEDNOTES = "RESTRICTEDNOTES";
	private static final String PORTFUNCTION = "PORTFUNCTION";	
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String PLUGGABLEID = "PLUGGABLEID";
	private static final String RPPLANID = "RPPLANID";	
	private static final String PLUGGABLEDESC = "PLUGGABLEDESC";
	private static final String RESTRICTEDSTATUS = "RESTRICTEDSTATUS";
	private static final String MAXPONCUSTOMER = "MAXPONCUSTOMER";
		
	public ExtPortNic2Pluggable()
	{
		super();
		this.tableName = "ext_port_nic2pluggable";
	}
	
	public ExtPortNic2Pluggable(String reservationId)
	{
		this();
		primaryKey.setValue(reservationId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	@Override
	public void populateModel()
	{
			
		fields.put(PORTID, new Field(PORTID, Field.TYPE_NUMERIC));
		fields.put(CONNECTORTYPE, new Field(CONNECTORTYPE, Field.TYPE_NUMERIC));		
		fields.put(MAXPONCIRCUIT, new Field(MAXPONCIRCUIT, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RESTRICTEDNOTES, new Field(RESTRICTEDNOTES, Field.TYPE_VARCHAR));
		fields.put(PORTFUNCTION, new Field(PORTFUNCTION, Field.TYPE_VARCHAR));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(PLUGGABLEID, new Field(PLUGGABLEID, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(PLUGGABLEDESC, new Field(PLUGGABLEDESC, Field.TYPE_VARCHAR));		
		fields.put(RESTRICTEDSTATUS, new Field(RESTRICTEDSTATUS, Field.TYPE_NUMERIC));
		fields.put(MAXPONCUSTOMER, new Field(MAXPONCUSTOMER, Field.TYPE_NUMERIC));
				
		primaryKey = new PrimaryKey(fields.get(PORTID));
	}
			
	public void setPortId(String portId)
	{
		setField(PORTID,portId);
	}
	public String getPortId()
	{
		return getFieldAsString(PORTID);
	}	
	
	public void setConnectorType(String connectorType)
	{
		setField(CONNECTORTYPE, connectorType);
	}
	public String getConnectorType()
	{
		return getFieldAsString(CONNECTORTYPE);
	}
	
	public void setPluggableId(String pluggableId)
	{
		setField(PLUGGABLEID, pluggableId);
	}
	public String getPluggableId()
	{
		return getFieldAsString(PLUGGABLEID);
	}
	
	public void setLabel(String label)
	{
		setField(LABEL,label);
	}
	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}	

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}
		
	public String getSfpName(String portId)
	{
		
		//String query = "portid in (select portid from port where port2card  in (Select cardid from card where card2node  in (select nodeid from node))) and portid =" + portId;
		String query = "portid =" + portId;	
		return getSfpNameByQuery(query);
	}

	public String getSfpNameByQuery(String query)
	{
		ExtPortNic2Pluggable extPortNic2Pluggable = new ExtPortNic2Pluggable();		
		List<Map<String,Object>> extPortNic2PluggableList = extPortNic2Pluggable.getFullRecordsByQuery(query);
		String sfpFound = null;
		for (Map<String,Object> sfpMap : extPortNic2PluggableList)
		{
			if(null != sfpMap.get(PLUGGABLEID))
			  sfpFound = sfpMap.get(PLUGGABLEID).toString();
		
			if(sfpFound != null)
				return sfpFound;
		}
		
		return sfpFound;
	}
}