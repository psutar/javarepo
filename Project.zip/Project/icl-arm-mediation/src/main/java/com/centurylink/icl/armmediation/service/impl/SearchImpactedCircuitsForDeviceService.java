package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;
import com.centurylink.icl.armmediation.armaccessobject.SearchResourceCriteria;
import com.centurylink.icl.armmediation.dataaccess.ImpactedCircuitsForDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.transformation.ImpactedCircuitsForDeviceToCim;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchImpactedCircuitsForDeviceService 
{
	private static final Log LOG = LogFactory.getLog(SearchImpactedCircuitsForDeviceService.class);
	private String ND1="ND1";
	private String ND2="ND2";
	private String EXT_ND1="EXT_ND1";
	private String EXT_ND2="EXT_ND2";
	private String LOC1="LOC1";
	private String LOC2="LOC2";
	//private String PC="PC";
	//private String PD="PD";
	private ImpactedCircuitsForDeviceDAO impactedCircuitsForDeviceDAO;
	private ImpactedCircuitsForDeviceToCim impactedCircuitsForDeviceToCim;

	public void setImpactedCircuitsForDeviceDAO(ImpactedCircuitsForDeviceDAO impactedCircuitsForDeviceDAO)
	{
		this.impactedCircuitsForDeviceDAO = impactedCircuitsForDeviceDAO;
	}
	public void setImpactedCircuitsForDeviceToCim(
			ImpactedCircuitsForDeviceToCim impactedCircuitsForDeviceToCim) 
	{
		this.impactedCircuitsForDeviceToCim = impactedCircuitsForDeviceToCim;
	}

	public Object searchImpactedCircuitsForDevice(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchImpactedCircuitsForDeviceService: GetImpactedCircuitsForDevice method");
		}

		SearchResourceCriteria searchResourceCriteria = new SearchResourceCriteria();
		searchResourceCriteria.setDeviceName(MediationUtil.getRcv(request, "DeviceName"));
		searchResourceCriteria.setDeviceCLLI(MediationUtil.getRcv(request, "DeviceCLLI"));
		searchResourceCriteria.setStatus(MediationUtil.getRcv(request, "FunctionalStatus"));
		searchResourceCriteria.setShelfNumber(MediationUtil.getRcv(request, "ShelfNumber"));
		searchResourceCriteria.setSlotNumber(MediationUtil.getRcv(request, "SlotNumber"));
		searchResourceCriteria.setPortNumber(MediationUtil.getRcv(request, "PortNumber"));
		searchResourceCriteria.setEnDepth(MediationUtil.getRcv(request, "EnDepth"));
		if(request.getSearchResourceRequest().getSearchResourceDetails()!=null && request.getSearchResourceRequest().getSearchResourceDetails().getLevel()!=null)
		{
			searchResourceCriteria.setLevel(request.getSearchResourceRequest().getSearchResourceDetails().getLevel());
		}


		final String returnrelatedcircuits = MediationUtil.getRcv(request, "ReturnRelatedCircuits");
		Boolean returncircuits = true;
		Boolean funcStatus=false;
		if(!StringHelper.isEmpty(searchResourceCriteria.getStatus()))
			funcStatus=true;

		if (null != returnrelatedcircuits)
			returncircuits = Boolean.parseBoolean(returnrelatedcircuits);
		if (returncircuits.equals(true))
		{
			if (!StringHelper.isEmpty(searchResourceCriteria.getDeviceName()) || !StringHelper.isEmpty(searchResourceCriteria.getDeviceCLLI()))
			{
				List<ARMImpactedCircuits> cktList = null;
				List<ARMImpactedCircuits> serviceList = null;

				if(((StringHelper.isEmpty(searchResourceCriteria.getEnDepth())) || (!StringHelper.isEmpty(searchResourceCriteria.getEnDepth()))) && (StringHelper.isEmpty(searchResourceCriteria.getShelfNumber())) 
						&& (StringHelper.isEmpty(searchResourceCriteria.getSlotNumber())) &&  (StringHelper.isEmpty(searchResourceCriteria.getPortNumber())) && (!StringHelper.isEmpty(searchResourceCriteria.getLevel())) && searchResourceCriteria.getLevel().equalsIgnoreCase("ImpactedCircuit"))
				{	 
					return getImpactedCircuitsForDevice(searchResourceCriteria);
				}

				if(((StringHelper.isEmpty(searchResourceCriteria.getEnDepth())) || (!StringHelper.isEmpty(searchResourceCriteria.getEnDepth()))) && (StringHelper.isEmpty(searchResourceCriteria.getShelfNumber())) 
						&& (StringHelper.isEmpty(searchResourceCriteria.getSlotNumber())) &&  (StringHelper.isEmpty(searchResourceCriteria.getPortNumber())))
				{	 
					return getCircuitsWithoutFilter(searchResourceCriteria);
				}

				else if((!StringHelper.isEmpty(searchResourceCriteria.getEnDepth()))  && (!StringHelper.isEmpty(searchResourceCriteria.getShelfNumber()) 
						|| (!StringHelper.isEmpty(searchResourceCriteria.getSlotNumber())) ||  (!StringHelper.isEmpty(searchResourceCriteria.getPortNumber()))))
				{
					return getCircuitsWithFilter(searchResourceCriteria);
				}
			}
		}
		else
		{

			throw new OSSDataNotFoundException();
		}

		return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_INTERNAL_ERROR, Constants.ICL_REQUEST_VALIDATION_ERROR_DETAIL, request);
	}

	private  String buildImpactedCircuitsForDeviceWithCardPortQuery(SearchResourceCriteria criteria)
	{
		SQLBuilder sql=new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.PROVISION_STATUS,"CKT_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND1);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND2);
		sql.addTable(Constants.LOCATION, LOC1);
		sql.addTable(Constants.LOCATION, LOC2);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(EXT_ND1,Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID, "CKT_OBJECTID");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
		sql.addFieldFromTable("CKT_PROVISION_STATUS", Constants.NAME, "CKT_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTNODE");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDNODE");
		sql.addFieldFromTable(ND1, Constants.NAME, "STARTNODE_NAME");
		sql.addFieldFromTable(ND1, Constants.FULL_NAME, "STARTNODE_FULLNAME");
		sql.addFieldFromTable(ND1, Constants.OBJECT_ID, "STARTNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND1, Constants.CLLI, "STARTNODE_CLLI");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V4_MGM_ROUTER_ID, "STARTNODE_IP");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V6_MGM_ROUTERID, "STARTNODE_IP_1");
		sql.addFieldFromTable(ND2, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(ND2, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(ND2, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND2, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTLOCATION");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDLOCATION");
		sql.addFieldFromTable(LOC1, Constants.NAME, "STARTLOCATION_NAME");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS1, "STARTLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS2, "STARTLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS3, "STARTLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC1, Constants.TOWNCITY, "STARTLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC1, Constants.PROVINCE, "STARTLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC1, Constants.ZIP, "STARTLOCATION_ZIP");
		sql.addFieldFromTable(LOC2, Constants.NAME, "ENDLOCATION_NAME");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC2, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC2, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC2, Constants.ZIP, "ENDLOCATION_ZIP");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, "CKT_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);
		sql.eq(EXT_ND1, Constants.NODE_ID, ND1, Constants.NODE_ID);
		sql.eq(EXT_ND2, Constants.NODE_ID, ND2, Constants.NODE_ID);
		sql.eq(LOC1, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.eq(LOC2, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.eq(LOC1, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.joinFO(LOC1, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		//      sql.addCase("PortA", Constants.PARENT_PORT_2_PORT, Constants.CIRCUIT, Constants.CIRCUIT_2_START_PORT, Constants.CIRCUIT_2_START_PORT);
		//      sql.addCase("PortZ", Constants.PARENT_PORT_2_PORT, Constants.CIRCUIT, Constants.CIRCUIT_2_END_PORT, Constants.CIRCUIT_2_END_PORT);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.eq("ND1",Constants.NODE_2_PROVISION_STATUS,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq("ND2",Constants.NODE_2_PROVISION_STATUS ,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Circuit");

		//TODO 
		if (!StringHelper.isEmpty(criteria.getEnDepth())) {
			sql.addTable(Constants.PORT,"PortA");
			sql.addTable(Constants.PORT,"PortZ");
			sql.addTable(Constants.PORT,"PPORT");
			sql.addTable(Constants.SHELF);
			sql.addTable(Constants.SLOT);
			sql.addTable(Constants.CARD);
			if (!StringHelper.isEmpty(criteria.getPortNumber())) {

				if(criteria.getEnDepth().equalsIgnoreCase("Port")){
					sql.eq("PPORT", Constants.PORT_NUMBER,
							criteria.getPortNumber());
				}
			}
			String tables [] ={"PortA","PortZ","PPORT"};

			String columnNames [] ={Constants.PARENT_PORT_2_PORT,Constants.PARENT_PORT_2_PORT,Constants.PORT_ID};
			sql.orClauseTables(tables, columnNames);


			sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_START_PORT,"PortA",Constants.PORT_ID);
			sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_END_PORT,"PortZ",Constants.PORT_ID);

			if (!StringHelper.isEmpty(criteria.getShelfNumber())
					&& (criteria.getEnDepth().equalsIgnoreCase("Shelf")
							|| criteria.getEnDepth().equalsIgnoreCase("Slot") || criteria
							.getEnDepth().equalsIgnoreCase("Port"))) {
				sql.eq(Constants.SHELF, Constants.SHELF_NUMBER,
						criteria.getShelfNumber());
			}

			if (!StringHelper.isEmpty(criteria.getSlotNumber())
					&& (criteria.getEnDepth().equalsIgnoreCase("Slot") || criteria
							.getEnDepth().equalsIgnoreCase("Port"))) {
				sql.eq(Constants.SLOT, Constants.SLOT_NUMBER,
						criteria.getSlotNumber());
			}

			////
			String nodeTtables [] ={"ND1","ND2","PPORT"};
			String nodeColumnNames [] ={Constants.NODE_ID,Constants.NODE_ID,Constants.PORT_2_NODE};
			sql.orClauseTables(nodeTtables, nodeColumnNames);

			sql.eq("PPORT", Constants.PORT_2_CARD,Constants.CARD , Constants.CARD_ID);
			sql.eq(Constants.CARD, Constants.CARD_2_SHELF_SLOT,Constants.SLOT , Constants.SLOT_ID);
			sql.eq(Constants.SLOT, Constants.SLOT_2_SHELF,Constants.SHELF , Constants.SHELF_ID);

			String shelfTables [] ={"ND1","ND2",Constants.SHELF};
			String shelfColumnNames [] ={Constants.NODE_ID,Constants.NODE_ID,Constants.SHELF_2_NODE};
			sql.orClauseTables(shelfTables, shelfColumnNames);

			sql.eq("PPORT", Constants.PORT_2_CARD,Constants.CARD , Constants.CARD_ID);

		}

		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "CKT_FUNC_STATUS");
			sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
			sql.eqUpperCase(Constants.FUNCTIONAL_STATUS, Constants.NAME, criteria.getStatus());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
		{
			sql.orUpperCase(ND1, Constants.NAME, criteria.getDeviceName(), ND2, Constants.NAME, criteria.getDeviceName());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceCLLI()))
		{
			sql.orUpperCase(EXT_ND1, Constants.CLLI, criteria.getDeviceCLLI(), EXT_ND2, Constants.CLLI, criteria.getDeviceCLLI());
		}
		String query=null;

		if(!StringHelper.isEmpty(criteria.getEnDepth())){
			query = sql.getStatement().concat("AND PPORT.PARENTPORT2PORT IS NULL AND PPORT.PORT2CARD IS NOT NULL");
		}
		else{
			query = sql.getStatement();
		}
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildImpactedCircuitsForDeviceWithCardPortQuery :" + query);
		}
		System.out.println("Query"+query);
		return query;
	}
	//Port on devices.
	private  String buildImpactedCktsForDevWithDirectPortQuery(SearchResourceCriteria criteria)
	{
		SQLBuilder sql=new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.PROVISION_STATUS,"CKT_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND1);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND2);
		sql.addTable(Constants.LOCATION, LOC1);
		sql.addTable(Constants.LOCATION, LOC2);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
		sql.addFieldFromTable(EXT_ND1,Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID, "CKT_OBJECTID");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable("CKT_PROVISION_STATUS", Constants.NAME, "CKT_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTNODE");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDNODE");
		sql.addFieldFromTable(ND1, Constants.NAME, "STARTNODE_NAME");
		sql.addFieldFromTable(ND1, Constants.FULL_NAME, "STARTNODE_FULLNAME");
		sql.addFieldFromTable(ND1, Constants.OBJECT_ID, "STARTNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND1, Constants.CLLI, "STARTNODE_CLLI");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V4_MGM_ROUTER_ID, "STARTNODE_IP");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V6_MGM_ROUTERID, "STARTNODE_IP_1");
		sql.addFieldFromTable(ND2, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(ND2, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(ND2, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND2, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTLOCATION");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDLOCATION");
		sql.addFieldFromTable(LOC1, Constants.NAME, "STARTLOCATION_NAME");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS1, "STARTLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS2, "STARTLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS3, "STARTLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC1, Constants.TOWNCITY, "STARTLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC1, Constants.PROVINCE, "STARTLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC1, Constants.ZIP, "STARTLOCATION_ZIP");
		sql.addFieldFromTable(LOC2, Constants.NAME, "ENDLOCATION_NAME");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC2, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC2, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC2, Constants.ZIP, "ENDLOCATION_ZIP");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, "CKT_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);
		sql.eq(EXT_ND1, Constants.NODE_ID, ND1, Constants.NODE_ID);
		sql.eq(EXT_ND2, Constants.NODE_ID, ND2, Constants.NODE_ID);
		sql.eq(LOC1, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.eq(LOC2, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.joinFO(LOC1, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.eq("ND1",Constants.NODE_2_PROVISION_STATUS,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq("ND2",Constants.NODE_2_PROVISION_STATUS ,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Circuit");
		//TODO 
		if (!StringHelper.isEmpty(criteria.getEnDepth()) && criteria.getEnDepth().equalsIgnoreCase("Port")
				&& StringHelper.isEmpty(criteria.getShelfNumber()) && StringHelper.isEmpty(criteria.getSlotNumber()))
		{
			sql.addTable(Constants.PORT,"PPORT");
			sql.addTable(Constants.PORT,"PortA");
			sql.addTable(Constants.PORT,"PortZ");
			if (!StringHelper.isEmpty(criteria.getPortNumber())) {

				sql.eq("PPORT", Constants.PORT_NUMBER,
						criteria.getPortNumber());
				String tables [] ={"PortA","PortZ","PPORT"};
				String columnNames [] ={Constants.PARENT_PORT_2_PORT,Constants.PARENT_PORT_2_PORT,Constants.PORT_ID};
				sql.orClauseTables(tables, columnNames);

				sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_START_PORT,"PortA",Constants.PORT_ID);
				sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_END_PORT,"PortZ",Constants.PORT_ID);
			}

			String nodeTtables [] ={"ND1","ND2","PPORT"};
			String nodeColumnNames [] ={Constants.NODE_ID,Constants.NODE_ID,Constants.PORT_2_NODE};
			sql.orClauseTables(nodeTtables, nodeColumnNames);
		}

		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "CKT_FUNC_STATUS");
			sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
			sql.eqUpperCase(Constants.FUNCTIONAL_STATUS, Constants.NAME, criteria.getStatus());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
		{
			sql.orUpperCase(ND1, Constants.NAME, criteria.getDeviceName(), ND2, Constants.NAME, criteria.getDeviceName());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceCLLI()))
		{
			sql.orUpperCase(EXT_ND1, Constants.CLLI, criteria.getDeviceCLLI(), EXT_ND2, Constants.CLLI, criteria.getDeviceCLLI());
		}

		final String query = sql.getStatement().concat(" AND PPORT.PARENTPORT2PORT IS NULL ");
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildImpactedCktsForDevWithDirectPortQuery :" + query);
		}
		System.out.println("Query"+query);
		return query;
	}



	private String buildImpactedServiceForDeviceQuery(SearchResourceCriteria criteria)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"SERV_PROVISION_STATUS");
		sql.addTable(Constants.SERVICEOBJECT);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.EXT_MEF_UNI);
		sql.addTable(Constants.EXT_MEF_ENNI);
		sql.addTable(Constants.EXT_MEF_EVC);
		sql.addTable(Constants.EXT_MEF_OVC);
		sql.addTable(Constants.PORT);
		sql.addTable(Constants.NODE);
		sql.addTable(Constants.EXT_DEVICE_TYPE);
		sql.addTable(Constants.LOCATION);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.EXT_SERVICE_PROBE_UNI);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS1");
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS2");
		sql.addFieldFromTable("SERV_PROVISION_STATUS", Constants.NAME, "SERV_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPENAME");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPCEXPIRATIONDATE, "UNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPC, "UNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPCEXPIRATIONDATE, "ENNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPC, "ENNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPCEXPIRATIONDATE, "EVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPC, "EVC_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPCEXPIRATIONDATE, "OVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPC, "OVC_HPC");
		sql.addFieldFromTable(Constants.NODE, Constants.NODE_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(Constants.NODE, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(Constants.NODE, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.LOCATION, Constants.NAME, "ENDLOCATION_NAME");
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
		sql.addFieldFromTable(Constants.LOCATION, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
		sql.addFieldFromTable(Constants.LOCATION, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
		sql.addFieldFromTable(Constants.LOCATION, Constants.ZIP, "ENDLOCATION_ZIP");
		sql.addField("(SELECT CUSTACCTBAN from  EXT_MEF_UNI where SERVICEID = SERVICE.SERVICEID)", "UNIBAN");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER, Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS, "SERV_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE, Constants.SERVICE, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_UNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_ENNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_EVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_OVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_SERVICE_PROBE_UNI, Constants.SERVICE_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT, Constants.PORT, Constants.PORT_ID);
		sql.eq(Constants.PORT, Constants.PORT_2_NODE, Constants.NODE, Constants.NODE_ID);
		sql.eq(Constants.EXT_DEVICE_TYPE, Constants.NODE_ID, Constants.NODE, Constants.NODE_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_LOCATION, Constants.LOCATION, Constants.LOCATION_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_PROVISION_STATUS, "DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.LOCATION, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.joinFOValue(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "'Service'");

		//TODO 
		if (!StringHelper.isEmpty(criteria.getEnDepth())) {
			if ((criteria.getEnDepth().equalsIgnoreCase("Shelf")
					|| criteria.getEnDepth().equalsIgnoreCase("Slot")
					|| criteria.getEnDepth().equalsIgnoreCase("Port")) && ( !StringHelper.isEmpty(criteria.getShelfNumber()) || !StringHelper.isEmpty(criteria.getSlotNumber()) || !StringHelper.isEmpty(criteria.getPortNumber()))) {

				sql.addTable(Constants.SHELF);
				sql.addTable(Constants.SLOT);			
				if (!StringHelper.isEmpty(criteria.getShelfNumber())) {
					sql.eq(Constants.SHELF, Constants.SHELF_NUMBER,
							criteria.getShelfNumber());
				}
				sql.eq(Constants.SHELF, Constants.SHELF_2_NODE, Constants.NODE,
						Constants.NODE_ID);

				if (criteria.getEnDepth().equalsIgnoreCase("Port")
						|| criteria.getEnDepth().equalsIgnoreCase("Slot")) {


					if (!StringHelper.isEmpty(criteria.getSlotNumber())) {
						sql.eq(Constants.SLOT, Constants.SLOT_NUMBER,
								criteria.getSlotNumber());
					}


				}

				if (criteria.getEnDepth().equalsIgnoreCase("Port")) {

					if (!StringHelper.isEmpty(criteria.getPortNumber())) {
						sql.eq(Constants.PORT, Constants.PORT_NUMBER,
								criteria.getPortNumber());
					}
				}
				sql.addTable(Constants.CARD);
				sql.eq(Constants.SLOT, Constants.SLOT_2_SHELF,
						Constants.SHELF, Constants.SHELF_ID);
				sql.eq(Constants.CARD, Constants.CARD_2_SHELF_SLOT,
						Constants.SLOT, Constants.SLOT_ID);
				sql.eq(Constants.PORT, Constants.PORT_2_CARD,
						Constants.CARD, Constants.CARD_ID);

			}
		}
		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "SERV_FUNC_STATUS");
			sql.eq(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS,Constants.FUNCTIONAL_STATUS_ID);
			sql.eqUpperCase(Constants.FUNCTIONAL_STATUS, Constants.NAME, criteria.getStatus());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
			sql.eqUpperCase(Constants.NODE, Constants.NAME, criteria.getDeviceName());
		if(!StringHelper.isEmpty(criteria.getDeviceCLLI()))
		{
			sql.eqUpperCase(Constants.EXT_DEVICE_TYPE, Constants.CLLI, criteria.getDeviceCLLI());
		}

		final String query = sql.getStatement();
		System.out.println("Query"+query);
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildImpactedServiceForDeviceQuery :" + query);
		}
		return query;
	}
	private  String buildImpactedCktsForDevWithoutFilterQuery(SearchResourceCriteria criteria,List<ARMImpactedCircuits> armImpactedCircuits)
	{
		SQLBuilder sql=new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.PROVISION_STATUS,"CKT_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND1);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND2);
		sql.addTable(Constants.LOCATION, LOC1);
		sql.addTable(Constants.LOCATION, LOC2);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
		sql.addFieldFromTable(EXT_ND1,Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID, "CKT_OBJECTID");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable("CKT_PROVISION_STATUS", Constants.NAME, "CKT_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTNODE");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDNODE");
		sql.addFieldFromTable(ND1, Constants.NAME, "STARTNODE_NAME");
		sql.addFieldFromTable(ND1, Constants.FULL_NAME, "STARTNODE_FULLNAME");
		sql.addFieldFromTable(ND1, Constants.OBJECT_ID, "STARTNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND1, Constants.CLLI, "STARTNODE_CLLI");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V4_MGM_ROUTER_ID, "STARTNODE_IP");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V6_MGM_ROUTERID, "STARTNODE_IP_1");
		sql.addFieldFromTable(ND2, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(ND2, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(ND2, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND2, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTLOCATION");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDLOCATION");
		sql.addFieldFromTable(LOC1, Constants.NAME, "STARTLOCATION_NAME");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS1, "STARTLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS2, "STARTLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS3, "STARTLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC1, Constants.TOWNCITY, "STARTLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC1, Constants.PROVINCE, "STARTLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC1, Constants.ZIP, "STARTLOCATION_ZIP");
		sql.addFieldFromTable(LOC2, Constants.NAME, "ENDLOCATION_NAME");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC2, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC2, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC2, Constants.ZIP, "ENDLOCATION_ZIP");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, "CKT_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);
		sql.eq(EXT_ND1, Constants.NODE_ID, ND1, Constants.NODE_ID);
		sql.eq(EXT_ND2, Constants.NODE_ID, ND2, Constants.NODE_ID);
		sql.eq(LOC1, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.eq(LOC2, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.joinFO(LOC1, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.eq("ND1",Constants.NODE_2_PROVISION_STATUS,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq("ND2",Constants.NODE_2_PROVISION_STATUS ,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Circuit");

		if(criteria!=null)
		{
			if(!StringHelper.isEmpty(criteria.getStatus()))
			{
				sql.addTable(Constants.FUNCTIONAL_STATUS);
				sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "CKT_FUNC_STATUS");
				sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
				sql.eqUpperCase(Constants.FUNCTIONAL_STATUS, Constants.NAME, criteria.getStatus());
			}
			if(!StringHelper.isEmpty(criteria.getDeviceName()))
			{
				sql.orUpperCase(ND1, Constants.NAME, criteria.getDeviceName(), ND2, Constants.NAME, criteria.getDeviceName());
			}
			if(!StringHelper.isEmpty(criteria.getDeviceCLLI()))
			{
				sql.orUpperCase(EXT_ND1, Constants.CLLI, criteria.getDeviceCLLI(), EXT_ND2, Constants.CLLI, criteria.getDeviceCLLI());
			}
		}
		if(armImpactedCircuits!=null)
		{
			List<String> nmiCircuitIDList=new ArrayList<String>();

			if(armImpactedCircuits!=null && armImpactedCircuits.size()>0)
			{
				for (ARMImpactedCircuits armCircuits :armImpactedCircuits)
				{
					if(armCircuits!=null)
					{
						if(armCircuits.getResourceType().equalsIgnoreCase("Unrouted Ethernet Bearer"));
						{
							nmiCircuitIDList.add(armCircuits.getCktId());
						}
					}
				}
			}

			if(nmiCircuitIDList!=null && nmiCircuitIDList.size()>0)
			{
				sql.addTable(Constants.CIRCUITCIRCUIT);
				sql.in(Constants.CIRCUITCIRCUIT, Constants.USES2CIRCUIT, nmiCircuitIDList);
				sql.eq(Constants.CIRCUITCIRCUIT, Constants.USEDBY2CIRCUIT, Constants.CIRCUIT,Constants.CIRCUIT_ID);
				sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_CIRCUIT_TYPE,"150000059");
			}

		}

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildImpactedCircuitsForDeviceQuery :" + query);
		}
		System.out.println("Query"+query);
		return query;
	}


	private Object getCircuitsWithoutFilter(
			SearchResourceCriteria searchResourceCriteria) throws Exception {
		List<ARMImpactedCircuits> cktList = null;
		List<ARMImpactedCircuits> serviceList = null;
		cktList = impactedCircuitsForDeviceDAO
				.getImpactedCircuitsForDevice(
						buildImpactedCktsForDevWithoutFilterQuery(searchResourceCriteria,null),
						!StringHelper.isEmpty(searchResourceCriteria
								.getStatus()));
		serviceList = impactedCircuitsForDeviceDAO
				.getImpactedServicesForDevice(
						buildImpactedServiceForDeviceQuery(searchResourceCriteria),
						!StringHelper.isEmpty(searchResourceCriteria
								.getStatus()));
		if ((cktList != null && cktList.size() > 0)
				|| (serviceList != null && serviceList.size() > 0)) {
			SearchResourceResponseDocument response = impactedCircuitsForDeviceToCim
					.transformImpactedCircuitsToCim(cktList, serviceList);

			if (LOG.isInfoEnabled()) {
				LOG.info(response.toString());
			}
			return response;
		} else {
			throw new OSSDataNotFoundException();
		}

	}
	
	private Object getImpactedCircuitsForDevice(
			SearchResourceCriteria searchResourceCriteria) throws Exception {
		List<ARMImpactedCircuits> cktList = null;
		List<ARMImpactedCircuits> relatedCircuitsList = null;
		List<ARMImpactedCircuits> serviceList = null;
		List<ARMImpactedCircuits> relatedserviceList = null;
		cktList = impactedCircuitsForDeviceDAO
				.getImpactedCircuitsForDevice(
						buildImpactedCktsForDevWithoutFilterQuery(searchResourceCriteria,null),
						!StringHelper.isEmpty(searchResourceCriteria
								.getStatus()));
		
		//Get VLAN Circuits List from NMI Circuits 
		if(cktList!=null && cktList.size()>0)
		{
			relatedCircuitsList=impactedCircuitsForDeviceDAO
					.getImpactedCircuitsForDevice(buildImpactedCktsForDevWithoutFilterQuery(null,cktList),false);
		}
		
		//Get EVC/OVC Services from the VLAN Circuits we got
		if(relatedCircuitsList!=null && relatedCircuitsList.size()>0)
		{
			serviceList= impactedCircuitsForDeviceDAO
					.getRelatedImpactedServicesForDevice(buildRelatedImpactedServicesForDevice(relatedCircuitsList,null));
		}

		//Get UNI/ENNI From EVC/OVC Services
		if(serviceList!=null && serviceList.size()>0)
		{
			relatedserviceList= impactedCircuitsForDeviceDAO
					.getRelatedImpactedServicesForDevice(buildRelatedImpactedServicesForDevice(null,serviceList));
		}
		//Merge UNI/ENNI with EVC/OVC Services
		if(relatedserviceList!=null && relatedserviceList.size()>0)
		{
			for(ARMImpactedCircuits relatedService:relatedserviceList)
			{
				if(relatedService!=null)
				{
					serviceList.add(relatedService);
				}
			}
		}


		//Merge all circuits alongwith the list of VLAN Circuits 
		if(cktList!=null && cktList.size()>0)
		{
			for (ARMImpactedCircuits ckt :cktList)
			{
				if(ckt!=null)
				{
					if(ckt.getResourceType().equalsIgnoreCase("Unrouted Ethernet Bearer")||ckt.getResourceType().equalsIgnoreCase("Link Aggregation Group"));
					{
						relatedCircuitsList.add(ckt);
					}
				}
			}
		}


		if ((relatedCircuitsList != null && relatedCircuitsList.size() > 0)
				|| (serviceList != null && serviceList.size() > 0)) {
			SearchResourceResponseDocument response = impactedCircuitsForDeviceToCim
					.transformImpactedCircuitsToCim(relatedCircuitsList, serviceList);

			if (LOG.isInfoEnabled()) {
				LOG.info(response.toString());
			}
			return response;
		} else {
			throw new OSSDataNotFoundException();
		}

	}

	private Object getCircuitsWithFilter(
			SearchResourceCriteria searchResourceCriteria) throws Exception {
		List<ARMImpactedCircuits> cktWithDevicePortList = null;
		List<ARMImpactedCircuits> cktListWithCardPorts = null;
		List<ARMImpactedCircuits> cktListWithChildCardPorts = null;
		List<ARMImpactedCircuits> aggregateCktList=null;
		List<ARMImpactedCircuits> serviceList = null;
		if (!StringHelper.isEmpty(searchResourceCriteria.getEnDepth()) && searchResourceCriteria.getEnDepth().equalsIgnoreCase("Port")
				&& StringHelper.isEmpty(searchResourceCriteria.getShelfNumber()) && StringHelper.isEmpty(searchResourceCriteria.getSlotNumber()) && !StringHelper.isEmpty(searchResourceCriteria.getPortNumber()))
		{
			cktWithDevicePortList = impactedCircuitsForDeviceDAO
					.getImpactedCircuitsForDevice(
							buildImpactedCktsForDevWithDirectPortQuery(searchResourceCriteria),
							!StringHelper.isEmpty(searchResourceCriteria
									.getStatus()));
		}
		if(cktWithDevicePortList!=null && cktWithDevicePortList.size()>0)
		{
			aggregateCktList=cktWithDevicePortList;
		}
		cktListWithCardPorts = impactedCircuitsForDeviceDAO.getImpactedCircuitsForDevice(buildImpactedCircuitsForDeviceWithCardPortQuery(
				searchResourceCriteria), !StringHelper.isEmpty(searchResourceCriteria.getStatus()));

		if(cktListWithCardPorts!=null && cktListWithCardPorts.size()>0)
		{
			if(aggregateCktList!=null && aggregateCktList.size()>0)
				aggregateCktList.addAll(cktListWithCardPorts);
			else
				aggregateCktList=cktListWithCardPorts;
		}

		cktListWithChildCardPorts = impactedCircuitsForDeviceDAO.getImpactedCircuitsForDevice(buildImpactedCircuitsForDeviceWithChildCardPortQuery(
				searchResourceCriteria), !StringHelper.isEmpty(searchResourceCriteria.getStatus()));

		if(cktListWithChildCardPorts!=null && cktListWithChildCardPorts.size()>0)
		{
			if(aggregateCktList!=null && aggregateCktList.size()>0)
				aggregateCktList.addAll(cktListWithChildCardPorts);
			else
				aggregateCktList=cktListWithChildCardPorts;
		}

		serviceList = impactedCircuitsForDeviceDAO
				.getImpactedServicesForDevice(
						buildImpactedServiceForDeviceQuery(searchResourceCriteria),
						!StringHelper.isEmpty(searchResourceCriteria
								.getStatus()));


		if ((aggregateCktList != null && aggregateCktList.size() > 0)
				|| (serviceList != null && serviceList.size() > 0)) {
			SearchResourceResponseDocument response = impactedCircuitsForDeviceToCim
					.transformImpactedCircuitsToCim(aggregateCktList,
							serviceList);

			if (LOG.isInfoEnabled()) {
				LOG.info(response.toString());
			}
			return response;
		} else {
			throw new OSSDataNotFoundException();
		}

	}
	private  String buildImpactedCircuitsForDeviceWithChildCardPortQuery(SearchResourceCriteria criteria)
	{
		SQLBuilder sql=new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.PROVISION_STATUS,"CKT_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND1);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND2);
		sql.addTable(Constants.LOCATION, LOC1);
		sql.addTable(Constants.LOCATION, LOC2);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
		sql.addFieldFromTable(EXT_ND1,Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID, "CKT_OBJECTID");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable("CKT_PROVISION_STATUS", Constants.NAME, "CKT_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTNODE");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDNODE");
		sql.addFieldFromTable(ND1, Constants.NAME, "STARTNODE_NAME");
		sql.addFieldFromTable(ND1, Constants.FULL_NAME, "STARTNODE_FULLNAME");
		sql.addFieldFromTable(ND1, Constants.OBJECT_ID, "STARTNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND1, Constants.CLLI, "STARTNODE_CLLI");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V4_MGM_ROUTER_ID, "STARTNODE_IP");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V6_MGM_ROUTERID, "STARTNODE_IP_1");
		sql.addFieldFromTable(ND2, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(ND2, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(ND2, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND2, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTLOCATION");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDLOCATION");
		sql.addFieldFromTable(LOC1, Constants.NAME, "STARTLOCATION_NAME");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS1, "STARTLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS2, "STARTLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC1, Constants.ADDRESS3, "STARTLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC1, Constants.TOWNCITY, "STARTLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC1, Constants.PROVINCE, "STARTLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC1, Constants.ZIP, "STARTLOCATION_ZIP");
		sql.addFieldFromTable(LOC2, Constants.NAME, "ENDLOCATION_NAME");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
		sql.addFieldFromTable(LOC2, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
		sql.addFieldFromTable(LOC2, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
		sql.addFieldFromTable(LOC2, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
		sql.addFieldFromTable(LOC2, Constants.ZIP, "ENDLOCATION_ZIP");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, "CKT_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);
		sql.eq(EXT_ND1, Constants.NODE_ID, ND1, Constants.NODE_ID);
		sql.eq(EXT_ND2, Constants.NODE_ID, ND2, Constants.NODE_ID);
		sql.eq("ND1",Constants.NODE_2_PROVISION_STATUS,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq("ND2",Constants.NODE_2_PROVISION_STATUS ,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(LOC1, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.eq(LOC2, Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.joinFO(LOC1, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Circuit");

		if (!StringHelper.isEmpty(criteria.getEnDepth())) {
			sql.addTable(Constants.PORT,"PortA");
			sql.addTable(Constants.PORT,"PortZ");
			sql.addTable(Constants.PORT,"PPORT");
			sql.addTable(Constants.SHELF);
			sql.addTable(Constants.SLOT);
			sql.addTable(Constants.SLOT,"PS");
			sql.addTable(Constants.CARD);
			sql.addTable(Constants.CARD,"PC");
			sql.addTable(Constants.CARD_TYPE,"PCT");
			sql.addTable(Constants.CARD_TYPE);
			sql.addFieldFromTable("PCT", Constants.NAME, "PARENTCARDTYPE");
			sql.addTable(Constants.CARD_IN_SLOT);
			if (!StringHelper.isEmpty(criteria.getPortNumber())) {

				if(criteria.getEnDepth().equalsIgnoreCase("Port")){
					sql.eq("PPORT", Constants.PORT_NUMBER,
							criteria.getPortNumber());
				}
			}

			String tables [] ={"PortA","PortZ","PPORT"};

			String columnNames [] ={Constants.PARENT_PORT_2_PORT,Constants.PARENT_PORT_2_PORT,Constants.PORT_ID};
			sql.orClauseTables(tables, columnNames);


			sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_START_PORT,"PortA",Constants.PORT_ID);
			sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_END_PORT,"PortZ",Constants.PORT_ID);

			if (!StringHelper.isEmpty(criteria.getShelfNumber())
					&& (criteria.getEnDepth().equalsIgnoreCase("Shelf")
							|| criteria.getEnDepth().equalsIgnoreCase("Slot") || criteria
							.getEnDepth().equalsIgnoreCase("Port"))) {
				sql.eq(Constants.SHELF, Constants.SHELF_NUMBER,
						criteria.getShelfNumber());
			}

			if (!StringHelper.isEmpty(criteria.getSlotNumber())
					&& (criteria.getEnDepth().equalsIgnoreCase("Slot") || criteria
							.getEnDepth().equalsIgnoreCase("Port"))) {
				sql.eq(Constants.SLOT, Constants.SLOT_NUMBER,
						criteria.getSlotNumber());
			}

			////
			String nodeTtables [] ={"ND1","ND2","PPORT"};
			String nodeColumnNames [] ={Constants.NODE_ID,Constants.NODE_ID,Constants.PORT_2_NODE};
			sql.orClauseTables(nodeTtables, nodeColumnNames);



			String shelfslotTables [] ={"PS",Constants.SLOT,Constants.SHELF};
			String shelfslotColumnNames [] ={Constants.SLOT_2_SHELF,Constants.SLOT_2_SHELF,Constants.SHELF_ID};
			sql.orClauseTables(shelfslotTables, shelfslotColumnNames);




			sql.eq("PPORT", Constants.PORT_2_CARD,Constants.CARD , Constants.CARD_ID);
			/*sql.eq(Constants.CARD, Constants.CARD_2_SHELF_SLOT,Constants.SLOT , Constants.SLOT_ID);
			sql.eq(Constants.SLOT, Constants.SLOT_2_SHELF,Constants.SHELF , Constants.SHELF_ID);*/
			sql.eq(Constants.CARD, Constants.CARD_2_CARD_TYPE, Constants.CARD_TYPE, Constants.CARD_TYPE_ID);
			sql.joinFO("PC", Constants.CARD_2_CARD_TYPE, "PCT", Constants.CARD_TYPE_ID);
			sql.joinFO(Constants.CARD_IN_SLOT, Constants.CARD_IN_SLOT_2_CARD, Constants.CARD, Constants.CARD_ID);
			sql.joinFO(Constants.CARD_IN_SLOT, Constants.CARD_IN_SLOT_2_SLOT, Constants.SLOT, Constants.SLOT_ID);
			sql.joinFO(Constants.CARD, Constants.CARD_2_SHELF_SLOT, "PS", Constants.SLOT_ID);
			sql.joinFO(Constants.SLOT, Constants.SLOT_2_CONTAINING_CARD, "PC", Constants.CARD_ID);

			String shelfTables [] ={"ND1","ND2",Constants.SHELF};
			String shelfColumnNames [] ={Constants.NODE_ID,Constants.NODE_ID,Constants.SHELF_2_NODE};
			sql.orClauseTables(shelfTables, shelfColumnNames);

		}

		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "CKT_FUNC_STATUS");
			sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
			sql.eqUpperCase(Constants.FUNCTIONAL_STATUS, Constants.NAME, criteria.getStatus());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
		{
			sql.orUpperCase(ND1, Constants.NAME, criteria.getDeviceName(), ND2, Constants.NAME, criteria.getDeviceName());
		}
		if(!StringHelper.isEmpty(criteria.getDeviceCLLI()))
		{
			sql.orUpperCase(EXT_ND1, Constants.CLLI, criteria.getDeviceCLLI(), EXT_ND2, Constants.CLLI, criteria.getDeviceCLLI());
		}
		String query=null;

		if(!StringHelper.isEmpty(criteria.getEnDepth())){
			query = sql.getStatement().concat("AND PPORT.PARENTPORT2PORT IS NULL AND PPORT.PORT2CARD IS NOT NULL");
		}
		else{
			query = sql.getStatement();
		}
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildImpactedCircuitsForDeviceWithChildCardPortQuery :" + query);
		}
		System.out.println("Query"+query);
		return query;
	}

	private String buildRelatedImpactedServicesForDevice(List<ARMImpactedCircuits> vlanCircuits,List<ARMImpactedCircuits> evcOvcServicesList)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.PROVISION_STATUS,"SERV_PROVISION_STATUS");
		sql.addTable(Constants.SERVICEOBJECT);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.SUBSCRIBER);

		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS1");
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS2");
		sql.addFieldFromTable("SERV_PROVISION_STATUS", Constants.NAME, "SERV_PROV_STATUS");
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPENAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);

		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER, Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS, "SERV_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);


		if(vlanCircuits!=null && vlanCircuits.size()>0)
		{
			List<String> circuitIDList =new ArrayList<String>();

			for(ARMImpactedCircuits vlanCircuit: vlanCircuits)
			{
				if(vlanCircuit.getResourceType().equalsIgnoreCase("VLAN Segment"))
				{
					circuitIDList.add(vlanCircuit.getCktId());
				}
			}

			if(circuitIDList!=null && circuitIDList.size()>0)
			{
				sql.addTable(Constants.EXT_MEF_EVC);
				sql.addTable(Constants.EXT_MEF_OVC);
				sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
				sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
				sql.in(Constants.SERVICEOBJECT,Constants.SERVICE_OBJECT_2_OBJECT,circuitIDList);
				sql.eq(Constants.SERVICEOBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT,"3");
				sql.eq(Constants.SERVICEOBJECT,Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE,Constants.SERVICE_ID);
				sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID, Constants.EXT_MEF_EVC,Constants.SERVICE_ID);
				sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID, Constants.EXT_MEF_OVC,Constants.SERVICE_ID);
				sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPCEXPIRATIONDATE, "EVC_EPI_DATE");
				sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPC, "EVC_HPC");
				sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPCEXPIRATIONDATE, "OVC_EPI_DATE");
				sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPC, "OVC_HPC");
				sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
				sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Service");
			}

		}
		if(evcOvcServicesList!=null && evcOvcServicesList.size()>0)
		{
			List<String> serviceIDList =new ArrayList<String>();

			for(ARMImpactedCircuits evcOvcService: evcOvcServicesList)
			{
				if(evcOvcService.getServiceTypeName().equalsIgnoreCase("MEF EVC")||evcOvcService.getServiceTypeName().equalsIgnoreCase("MEF OVC"))
				{
					serviceIDList.add(evcOvcService.getServiceID());
				}
			}
			if(serviceIDList!=null && serviceIDList.size()>0)
			{
				sql.addTable(Constants.EXT_MEF_UNI);
				sql.addTable(Constants.EXT_MEF_ENNI);
				sql.addTable(Constants.SERVICEOBJECT,"UNI_SO");
				sql.addTable(Constants.PORT);
				sql.addTable(Constants.NODE);
				sql.addTable(Constants.EXT_DEVICE_TYPE);
				sql.addTable(Constants.LOCATION);
				sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
				sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
				sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
				sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
				sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE,Constants.CLLI_CODE);
				sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
				sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPCEXPIRATIONDATE, "UNI_EPI_DATE");
				sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPC, "UNI_HPC");
				sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPCEXPIRATIONDATE, "ENNI_EPI_DATE");
				sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPC, "ENNI_HPC");
				sql.addFieldFromTable(Constants.NODE, Constants.NODE_ID);
				sql.addFieldFromTable(Constants.NODE, Constants.NAME, "ENDNODE_NAME");
				sql.addFieldFromTable(Constants.NODE, Constants.FULL_NAME, "ENDNODE_FULLNAME");
				sql.addFieldFromTable(Constants.NODE, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
				sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NETWORK_NAME);
				sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.CLLI, "ENDNODE_CLLI");
				sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
				sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
				sql.addFieldFromTable(Constants.LOCATION, Constants.NAME, "ENDLOCATION_NAME");
				sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS1, "ENDLOCATION_ADDRESS1");
				sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS2, "ENDLOCATION_ADDRESS2");
				sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS3, "ENDLOCATION_ADDRESS3");
				sql.addFieldFromTable(Constants.LOCATION, Constants.TOWNCITY, "ENDLOCATION_TOWNCITY");
				sql.addFieldFromTable(Constants.LOCATION, Constants.PROVINCE, "ENDLOCATION_PROVINCE");
				sql.addFieldFromTable(Constants.LOCATION, Constants.ZIP, "ENDLOCATION_ZIP");
				sql.addField("(SELECT CUSTACCTBAN from  EXT_MEF_UNI where SERVICEID = SERVICE.SERVICEID)", "UNIBAN");

				sql.in(Constants.SERVICEOBJECT,Constants.SERVICE_OBJECT_2_SERVICE,serviceIDList);
				sql.eq(Constants.SERVICEOBJECT,Constants.SERVICE_OBJECT_2_OBJECT,Constants.SERVICE,Constants.SERVICE_ID);
				sql.eq(Constants.SERVICEOBJECT,Constants.SERVICE_OBJECT_2_DIM_OBJECT,"8");
				sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_UNI,Constants.SERVICE_ID);
				sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_ENNI,Constants.SERVICE_ID);
				sql.eq("UNI_SO",Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE,Constants.SERVICE_ID);
				sql.eq("UNI_SO",Constants.SERVICE_OBJECT_2_OBJECT,Constants.PORT,Constants.PORT_ID);
				sql.eq("UNI_SO",Constants.SERVICE_OBJECT_2_DIM_OBJECT,"4");
				sql.eq(Constants.PORT, Constants.PORT_2_NODE, Constants.NODE, Constants.NODE_ID);
				sql.eq(Constants.EXT_DEVICE_TYPE, Constants.NODE_ID, Constants.NODE, Constants.NODE_ID);
				sql.eq(Constants.NODE, Constants.NODE_2_LOCATION, Constants.LOCATION, Constants.LOCATION_ID);
				sql.eq(Constants.NODE, Constants.NODE_2_PROVISION_STATUS, "DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
				sql.joinFO(Constants.LOCATION, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
				sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
				sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "Service");
				
			}
		}

		final String query = sql.getStatement();

		return query;
	}
}
