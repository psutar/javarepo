package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Parameterdefinition extends AbstractReadOnlyTable {

	private static final String DEFAULTDECIMALVALUE = "DEFAULTDECIMALVALUE";
	private static final String DEFAULTDATE = "DEFAULTDATE";
	private static final String DEFAULTINTEGERVALUE = "DEFAULTINTEGERVALUE";
	private static final String DEFAULTSTRINGVALUE = "DEFAULTSTRINGVALUE";
	private static final String EXTVALIDATIONFAILURE2EVENTTYPE = "EXTVALIDATIONFAILURE2EVENTTYPE";
	private static final String EXTERNALVALIDATIONCALLOUT = "EXTERNALVALIDATIONCALLOUT";
	private static final String ENUMKEY = "ENUMKEY";
	private static final String INTERNALVALIDATIONCALLOUT = "INTERNALVALIDATIONCALLOUT";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String MAXSTRINGLENGTH = "MAXSTRINGLENGTH";
	private static final String VALIDINCREMENT = "VALIDINCREMENT";
	private static final String UNIT = "UNIT";
	private static final String ISDERIVED = "ISDERIVED";
	private static final String ISINVARIANT = "ISINVARIANT";
	private static final String MAXOCCURRENCES = "MAXOCCURRENCES";
	private static final String MINOCCURRENCES = "MINOCCURRENCES";
	private static final String DATATYPE = "DATATYPE";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String REALNAME = "REALNAME";
	private static final String NAME = "NAME";
	private static final String PDEFINITION2PARAMDICTIONARY = "PDEFINITION2PARAMDICTIONARY";
	private static final String PARAMETERDEFINITIONID = "PARAMETERDEFINITIONID";

	public Parameterdefinition()
	{
		super();
		this.tableName = "PARAMETERDEFINITION";
	}

	public Parameterdefinition(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Parameterdefinition> getParameterdefinitionListByQuery(String query)
	{
		Parameterdefinition parameterdefinition = new Parameterdefinition();
		List<Parameterdefinition> parameterdefinitionList = new ArrayList<Parameterdefinition>();
		List<Map<String,Object>> foundParameterdefinitionList = parameterdefinition.getRecordsByQuery(query);

		for (Map<String,Object> parameterdefinitionMap : foundParameterdefinitionList)
		{
			Parameterdefinition workParameterdefinition = new Parameterdefinition(parameterdefinitionMap.get(PARAMETERDEFINITIONID).toString());
			parameterdefinitionList.add(workParameterdefinition);
		}
		return parameterdefinitionList;
	}

	@Override
	public void populateModel()
	{
		fields.put(DEFAULTDECIMALVALUE, new Field(DEFAULTDECIMALVALUE, Field.TYPE_NUMERIC));
		fields.put(DEFAULTDATE, new Field(DEFAULTDATE, Field.TYPE_DATE));
		fields.put(DEFAULTINTEGERVALUE, new Field(DEFAULTINTEGERVALUE, Field.TYPE_NUMERIC));
		fields.put(DEFAULTSTRINGVALUE, new Field(DEFAULTSTRINGVALUE, Field.TYPE_VARCHAR));
		fields.put(EXTVALIDATIONFAILURE2EVENTTYPE, new Field(EXTVALIDATIONFAILURE2EVENTTYPE, Field.TYPE_NUMERIC));
		fields.put(EXTERNALVALIDATIONCALLOUT, new Field(EXTERNALVALIDATIONCALLOUT, Field.TYPE_VARCHAR));
		fields.put(ENUMKEY, new Field(ENUMKEY, Field.TYPE_VARCHAR));
		fields.put(INTERNALVALIDATIONCALLOUT, new Field(INTERNALVALIDATIONCALLOUT, Field.TYPE_VARCHAR));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(MAXSTRINGLENGTH, new Field(MAXSTRINGLENGTH, Field.TYPE_NUMERIC));
		fields.put(VALIDINCREMENT, new Field(VALIDINCREMENT, Field.TYPE_NUMERIC));
		fields.put(UNIT, new Field(UNIT, Field.TYPE_VARCHAR));
		fields.put(ISDERIVED, new Field(ISDERIVED, Field.TYPE_NUMERIC));
		fields.put(ISINVARIANT, new Field(ISINVARIANT, Field.TYPE_NUMERIC));
		fields.put(MAXOCCURRENCES, new Field(MAXOCCURRENCES, Field.TYPE_NUMERIC));
		fields.put(MINOCCURRENCES, new Field(MINOCCURRENCES, Field.TYPE_NUMERIC));
		fields.put(DATATYPE, new Field(DATATYPE, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(REALNAME, new Field(REALNAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(PDEFINITION2PARAMDICTIONARY, new Field(PDEFINITION2PARAMDICTIONARY, Field.TYPE_NUMERIC));
		fields.put(PARAMETERDEFINITIONID, new Field(PARAMETERDEFINITIONID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PARAMETERDEFINITIONID));
	}

	public void setDefaultdecimalvalue(String defaultdecimalvalue)
	{
		setField(DEFAULTDECIMALVALUE,defaultdecimalvalue);
	}

	public String getDefaultdecimalvalue()
	{
		return getFieldAsString(DEFAULTDECIMALVALUE);
	}

	public void setDefaultdate(String defaultdate)
	{
		setField(DEFAULTDATE,defaultdate);
	}

	public String getDefaultdate()
	{
		return getFieldAsString(DEFAULTDATE);
	}

	public void setDefaultintegervalue(String defaultintegervalue)
	{
		setField(DEFAULTINTEGERVALUE,defaultintegervalue);
	}

	public String getDefaultintegervalue()
	{
		return getFieldAsString(DEFAULTINTEGERVALUE);
	}

	public void setDefaultstringvalue(String defaultstringvalue)
	{
		setField(DEFAULTSTRINGVALUE,defaultstringvalue);
	}

	public String getDefaultstringvalue()
	{
		return getFieldAsString(DEFAULTSTRINGVALUE);
	}

	public void setExtvalidationfailure2eventtype(String extvalidationfailure2eventtype)
	{
		setField(EXTVALIDATIONFAILURE2EVENTTYPE,extvalidationfailure2eventtype);
	}

	public String getExtvalidationfailure2eventtype()
	{
		return getFieldAsString(EXTVALIDATIONFAILURE2EVENTTYPE);
	}

	public void setExternalvalidationcallout(String externalvalidationcallout)
	{
		setField(EXTERNALVALIDATIONCALLOUT,externalvalidationcallout);
	}

	public String getExternalvalidationcallout()
	{
		return getFieldAsString(EXTERNALVALIDATIONCALLOUT);
	}

	public void setEnumkey(String enumkey)
	{
		setField(ENUMKEY,enumkey);
	}

	public String getEnumkey()
	{
		return getFieldAsString(ENUMKEY);
	}

	public void setInternalvalidationcallout(String internalvalidationcallout)
	{
		setField(INTERNALVALIDATIONCALLOUT,internalvalidationcallout);
	}

	public String getInternalvalidationcallout()
	{
		return getFieldAsString(INTERNALVALIDATIONCALLOUT);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setMaxstringlength(String maxstringlength)
	{
		setField(MAXSTRINGLENGTH,maxstringlength);
	}

	public String getMaxstringlength()
	{
		return getFieldAsString(MAXSTRINGLENGTH);
	}

	public void setValidincrement(String validincrement)
	{
		setField(VALIDINCREMENT,validincrement);
	}

	public String getValidincrement()
	{
		return getFieldAsString(VALIDINCREMENT);
	}

	public void setUnit(String unit)
	{
		setField(UNIT,unit);
	}

	public String getUnit()
	{
		return getFieldAsString(UNIT);
	}

	public void setIsderived(String isderived)
	{
		setField(ISDERIVED,isderived);
	}

	public String getIsderived()
	{
		return getFieldAsString(ISDERIVED);
	}

	public void setIsinvariant(String isinvariant)
	{
		setField(ISINVARIANT,isinvariant);
	}

	public String getIsinvariant()
	{
		return getFieldAsString(ISINVARIANT);
	}

	public void setMaxoccurrences(String maxoccurrences)
	{
		setField(MAXOCCURRENCES,maxoccurrences);
	}

	public String getMaxoccurrences()
	{
		return getFieldAsString(MAXOCCURRENCES);
	}

	public void setMinoccurrences(String minoccurrences)
	{
		setField(MINOCCURRENCES,minoccurrences);
	}

	public String getMinoccurrences()
	{
		return getFieldAsString(MINOCCURRENCES);
	}

	public void setDatatype(String datatype)
	{
		setField(DATATYPE,datatype);
	}

	public String getDatatype()
	{
		return getFieldAsString(DATATYPE);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setRealname(String realname)
	{
		setField(REALNAME,realname);
	}

	public String getRealname()
	{
		return getFieldAsString(REALNAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setPdefinition2paramdictionary(String pdefinition2paramdictionary)
	{
		setField(PDEFINITION2PARAMDICTIONARY,pdefinition2paramdictionary);
	}

	public String getPdefinition2paramdictionary()
	{
		return getFieldAsString(PDEFINITION2PARAMDICTIONARY);
	}

	public void setParameterdefinitionid(String parameterdefinitionid)
	{
		setField(PARAMETERDEFINITIONID,parameterdefinitionid);
	}

	public String getParameterdefinitionid()
	{
		return getFieldAsString(PARAMETERDEFINITIONID);
	}


}