package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.util.tracker.ServiceTracker;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.PartyBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceRequestBuilder;
import com.centurylink.icl.builder.util.SearchResourceRequestDocumentHelper;
import com.centurylink.icl.clc.routinggroup.CLCConstants;
import com.centurylink.icl.component.IConnector;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.ValidationCondition;

public class CLCLookupService {
	
	private static final Log LOG = LogFactory.getLog(CLCLookupService.class);
	
	private ServiceTracker connectorTracker;
    
    public CLCLookupService(BundleContext bundleContext) throws Exception
    {
		super();
	
		Filter filter = bundleContext.createFilter("(&(name=clcConnector))");
		connectorTracker = new ServiceTracker(bundleContext, filter, null);
		
		connectorTracker.open();
    }
    
    public AmericanPropertyAddress getAddressByName(String commonName) throws Exception
    {
    	//TODO: MICKEY - Add short lived CACHE (using EHCACHE) to address performance issues from this call.
    	
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHLOCATION");
    	
    	AmericanPropertyAddress address;
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	SearchResourceResponseDocument response = (SearchResourceResponseDocument) connector.call(SearchResourceRequestDocumentHelper.createSearchResourceRequest(Constants.LOCATION, Constants.LOCATION, "SUMMARY", Constants.CLC, commonName, null), inputMap);
    		address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);
    	} catch (Exception e) {
    		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
    		americanPropertyAddressBuilder.buildAmericanPropertyAddress(commonName, null, null, "ARM");
    		
    		address = americanPropertyAddressBuilder.getAmericanPropertyAddress();
    	}
    	
    	return address;
    }
    
    //CLC attributes for InstalledAtAddress Details 
    public AmericanPropertyAddress getInstalledAddressByName(String commonName, String nodeName) throws Exception
    {    
    	
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHLOCATION");
    	
    	AmericanPropertyAddress address;
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		americanPropertyAddressBuilder.buildAmericanPropertyAddress(commonName, null, null, "ARM"); 
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	SearchResourceResponseDocument response = (SearchResourceResponseDocument) connector.call(SearchResourceRequestDocumentHelper.createSearchResourceRequest(Constants.LOCATION, Constants.LOCATION, "SUMMARY", Constants.CLC, commonName, null), inputMap);
    		address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);
    	} catch (Exception e) {
	
    		address = americanPropertyAddressBuilder.getAmericanPropertyAddress();    		
    	}
    	
    	
    	try {
    		inputMap = new HashMap<String, Object>();
        	inputMap.put("OPERATIONNAME", "SEARCHDEVICEINSTALLDETAIL");
        	inputMap.put("DEVICE_NAME", nodeName); 
    		HashMap<String, Object> responseMap = (HashMap<String, Object>) connector.call(new Object(), inputMap);
    		
    		if(null != responseMap){
			LOG.info("SEARCHDEVICEINSTALLDETAIL response map size is " + responseMap.size());
			
			Iterator<Entry<String, Object>> it = responseMap.entrySet().iterator();
		    while (it.hasNext()) {
		        Entry<String, Object> pairs = it.next();
		        System.out.println(pairs.getKey() + " = " + pairs.getValue());		       
		    }
			
			}    		    		
    		
			if (null != responseMap && responseMap.size() > 0) {
				if (null != responseMap.get("TECHACCESSINDICATOR")) {
					CharacteristicValue cv = address.addNewRootEntityDescribedBy();
					cv.setCharacteristicName("TechAccessIndicator");
					cv.setCharacteristicValue(responseMap.get("TECHACCESSINDICATOR").toString());
					americanPropertyAddressBuilder.addRootEntityDescribedBy("TechAccessIndicator", responseMap.get("TECHACCESSINDICATOR").toString());
				}
				if (null != responseMap.get("ONTLOCATIONORIENTATION")) {
					CharacteristicValue cv = address.addNewRootEntityDescribedBy();
					cv.setCharacteristicName("ONTLocationOrientation");
					cv.setCharacteristicValue(responseMap.get("ONTLOCATIONORIENTATION").toString());
					americanPropertyAddressBuilder.addRootEntityDescribedBy("ONTLocationOrientation", responseMap.get("ONTLOCATIONORIENTATION").toString());
				}
				if (null != responseMap.get("ONTLOCATIONROOM")) {
					CharacteristicValue cv = address.addNewRootEntityDescribedBy();
					cv.setCharacteristicName("ONTLocationRoom");
					cv.setCharacteristicValue(responseMap.get("ONTLOCATIONROOM").toString());
					americanPropertyAddressBuilder.addRootEntityDescribedBy("ONTLocationRoom", responseMap.get("ONTLOCATIONROOM").toString());
				}
				if (null != responseMap.get("OUTSIDERESTRICTIONS")) {
					CharacteristicValue cv = address.addNewRootEntityDescribedBy();
					cv.setCharacteristicName("OutsideRestrictions");
					cv.setCharacteristicValue(responseMap.get("OUTSIDERESTRICTIONS").toString());
					americanPropertyAddressBuilder.addRootEntityDescribedBy("OutsideRestrictions", responseMap.get("OUTSIDERESTRICTIONS").toString());
				}
				if (null != responseMap.get("INSTALLATIONREMARKS")) {
					CharacteristicValue cv = address.addNewRootEntityDescribedBy();
					cv.setCharacteristicName("InstallationRemarks");
					cv.setCharacteristicValue(responseMap.get("INSTALLATIONREMARKS").toString());
					americanPropertyAddressBuilder.addRootEntityDescribedBy("InstallationRemarks", responseMap.get("INSTALLATIONREMARKS").toString());
				}    				    				
			}
    	} catch (Exception e1) {   
    		LOG.info("Error while fetching Installed Address details !!!!!! " + e1.getMessage());
			e1.printStackTrace();
    	}
    	
    	return address;    	
    }    
    
    public AmericanPropertyAddress getServiceAddressByName(String name) throws Exception
    {
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHLOCATION");
    	
    	AmericanPropertyAddress address = null;
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	SearchResourceResponseDocument response = (SearchResourceResponseDocument) connector.call(createCLCSearchResourceRequest(Constants.LOCATION, Constants.LOCATION, "SUMMARY", Constants.CLC, name, "ASSETVALUE"), inputMap);
    		address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);    		
    	} catch (Exception e) {
    		LOG.info("Location data not found in CLC!!! "+e.getMessage());
    	}
    	
    	return address;
    }

    public List<AmericanPropertyAddress> getServiceAddressListByBuildingCLLI(String buildingClli) throws Exception
    {
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHLOCATION");
    	
    	List<AmericanPropertyAddress> addresses = new ArrayList<AmericanPropertyAddress>();
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	SearchResourceResponseDocument response = (SearchResourceResponseDocument) connector.call(createCLCSearchResourceRequest(Constants.LOCATION, Constants.LOCATION, "SUMMARY", Constants.CLC, buildingClli, "BUILDINGCLLI"), inputMap);
    		addresses = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList();
    	} catch (Exception e) {
    		LOG.info("Location data not found in CLC!!! "+e.getMessage());
    	}
    	
    	return addresses;
    }
    
    public Party getCustomerByName(String commonName) throws Exception
    {
    	
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHCUSTOMER");
    	
    	Party party;
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	SearchResourceResponseDocument response = (SearchResourceResponseDocument) connector.call(createCLCSearchCustomerRequest(Constants.CUSTOMER, Constants.CUSTOMER, "SUMMARY", Constants.CLC, commonName), inputMap);
        	party = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getPartyList().get(0);
    	} catch (Exception e) {
    		PartyBuilder partyBuilder = new PartyBuilder();
    		partyBuilder.buildParty(commonName, null, null, null);
    		
    		party = partyBuilder.getParty();
    	}
    	
    	return party;
    }
    
    private static SearchResourceRequestDocument createCLCSearchResourceRequest(String entity, String level, String scope, String sourceSystem, String name, String variableName)
	{
		SearchResourceDetailsBuilder searchResouceDetailsBuilder = new SearchResourceDetailsBuilder();
		SearchResourceRequestBuilder searchResourceRequestBuilder = new SearchResourceRequestBuilder();

		searchResouceDetailsBuilder.buildSearchResourceDetails(null, null, sourceSystem, entity, level, scope);
		
		SearchResourceDetails searchResourceDetails = searchResouceDetailsBuilder.getSearchResourceDetails();
		
		Condition equalCond = searchResourceDetails.addNewFilterCriteria()
				.addNewValidationCondition().addNewEqualCondition();
		equalCond.setVariableName(variableName);
		equalCond.setValue(name);
		
		searchResourceRequestBuilder.buildSearchResourceRequest(null, searchResourceDetails);

		SearchResourceRequestDocument srrd = SearchResourceRequestDocument.Factory.newInstance();
		srrd.addNewSearchResourceRequest();
		srrd.setSearchResourceRequest(searchResourceRequestBuilder.getSearchResourceRequest());
		
		return srrd;
	}
    
    public SearchResourceResponseDocument getServiceAddressById(String id) throws Exception
    {
    	SearchResourceResponseDocument response = null;
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", CLCConstants.SEARCHRELATIONSHIPTOLOCATION);
    	
    	//AmericanPropertyAddress address = null;
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	response = (SearchResourceResponseDocument) connector.call(createCLCSearchResourceRequestForId(Constants.LOCATION, Constants.LOCATION, "DETAILED", Constants.CLC, id), inputMap);
    		//address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);    		
    	} catch (Exception e) {
    		LOG.info("Location data not found in CLC!!! "+e.getMessage());
    	}
    	
    	return response;
    }
    
    private static SearchResourceRequestDocument createCLCSearchCustomerRequest(String entity, String level, String scope, String sourceSystem, String name)
	{
		SearchResourceDetailsBuilder searchResouceDetailsBuilder = new SearchResourceDetailsBuilder();
		SearchResourceRequestBuilder searchResourceRequestBuilder = new SearchResourceRequestBuilder();

		searchResouceDetailsBuilder.buildSearchResourceDetails(null, null, sourceSystem, entity, level, scope);
		
		SearchResourceDetails searchResourceDetails = searchResouceDetailsBuilder.getSearchResourceDetails();

		
		ValidationCondition valCond =  searchResourceDetails.addNewFilterCriteria().addNewValidationCondition();
		valCond.setOperator("OR");
		Condition cond1 = valCond.addNewEqualCondition();
		cond1.setVariableName("ACNA");
		cond1.setValue(name);
	
		Condition cond2 = valCond.addNewEqualCondition();
		cond2.setVariableName("CustomerId");
		cond2.setValue(name);
		searchResourceRequestBuilder.buildSearchResourceRequest(null, searchResourceDetails);

		SearchResourceRequestDocument srrd = SearchResourceRequestDocument.Factory.newInstance();
		srrd.addNewSearchResourceRequest();
		srrd.setSearchResourceRequest(searchResourceRequestBuilder.getSearchResourceRequest());
		
		return srrd;
	}
    public SearchResourceResponseDocument getServiceArea(String clcId, String name) throws Exception
    {
    	SearchResourceResponseDocument response = null;
    	HashMap<String, Object> inputMap = new HashMap<String, Object>();
    	inputMap.put("OPERATIONNAME", "SEARCHSERVICEAREADETAILED");
    	
    	//List<AmericanPropertyAddress> address = null;
    	IConnector connector = (IConnector)connectorTracker.getService();

    	try {
        	response = (SearchResourceResponseDocument) connector.call(createCLCSearchResourceRequest(Constants.SERVICEAREA, Constants.SERVICEAREA, "Detailed", Constants.CLC, clcId, "ServiceAddressID"), inputMap);
    		
        	//address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList();    		
    	} catch (Exception e) {
    		LOG.info("Service Location is not within GPON footprint"+e.getMessage());
    		throw e;
    	}
    	
    	return response;
    }
        
    private static SearchResourceRequestDocument createCLCSearchResourceRequestForId(String entity, String level, String scope, String sourceSystem, String id)
   	{
   		SearchResourceDetailsBuilder searchResouceDetailsBuilder = new SearchResourceDetailsBuilder();
   		SearchResourceRequestBuilder searchResourceRequestBuilder = new SearchResourceRequestBuilder();

   		searchResouceDetailsBuilder.buildSearchResourceDetails(null, id, sourceSystem, entity, level, scope);
   		
   		SearchResourceDetails searchResourceDetails = searchResouceDetailsBuilder.getSearchResourceDetails();
   		
   		Condition equalCond = searchResourceDetails.addNewFilterCriteria()
   				.addNewValidationCondition().addNewEqualCondition();
   		equalCond.setVariableName("LocationID");
   		equalCond.setValue(id);
   		
   		searchResourceRequestBuilder.buildSearchResourceRequest(null, searchResourceDetails);

   		SearchResourceRequestDocument srrd = SearchResourceRequestDocument.Factory.newInstance();
   		srrd.addNewSearchResourceRequest();
   		srrd.setSearchResourceRequest(searchResourceRequestBuilder.getSearchResourceRequest());
   		
   		return srrd;
   	}
    
    
    
    
 }
