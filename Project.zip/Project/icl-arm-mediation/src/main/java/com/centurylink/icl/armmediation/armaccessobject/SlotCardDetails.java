package com.centurylink.icl.armmediation.armaccessobject;

import java.util.List;

public class SlotCardDetails {
	private String commonName; //Device Name
	private List<ShelfDetails> shelfDetails;
	
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	
	public List<ShelfDetails> getShelfDetails()
	{
		return shelfDetails;
	}
	public void setShelfDetails(List<ShelfDetails> shelfDetails)
	{
		this.shelfDetails = shelfDetails;
	}

}
