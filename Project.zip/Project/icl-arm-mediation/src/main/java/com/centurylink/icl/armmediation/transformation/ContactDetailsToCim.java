package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.ValidationCondition;

public class ContactDetailsToCim {
	
	private static final Log LOG = LogFactory.getLog(ContactDetailsToCim.class);
	
	public SearchResourceRequestDocument transformToCLCRequest(SearchResourceRequestDocument request, String subscriberName)
	{
		SearchResourceDetails searchResourceDetails =  request.getSearchResourceRequest().getSearchResourceDetails();
		searchResourceDetails.setSourceSystem("CLC");
		searchResourceDetails.setEntity("CONTACT");
		searchResourceDetails.setLevel("CONTACT");
		searchResourceDetails.setScope("SUMMARY");
		
		//LOG.info("subscriberName from ARM >>>>>> "+subscriberName);
		
		ValidationCondition validationCondition = searchResourceDetails.addNewFilterCriteria().addNewValidationCondition();
		validationCondition.setOperator(Constants.OR);
		Condition cond = validationCondition.addNewEqualCondition();
		cond.setVariableName(Constants.ACNA);
		cond.setValue(subscriberName);
		Condition cond1 = validationCondition.addNewEqualCondition();
		cond1.setVariableName(Constants.ASSIGNEDCUSTOMERID);
		cond1.setValue(subscriberName);

		ValidationCondition validationCondition2 = searchResourceDetails.getFilterCriteriaList().get(0).addNewValidationCondition();
		Condition cond2 = validationCondition2.addNewEqualCondition();
		cond2.setVariableName(Constants.STATUS);
		cond2.setValue(Constants.ACTIVE);
		
		LOG.info("CLC Request ::- "+ request.xmlText());
		
		return request;
	}

}
