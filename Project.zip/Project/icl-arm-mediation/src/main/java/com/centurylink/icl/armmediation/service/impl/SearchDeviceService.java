package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMNode;
import com.centurylink.icl.armmediation.armaccessobject.ARMPort;
import com.centurylink.icl.armmediation.armaccessobject.ARMSFP;
import com.centurylink.icl.armmediation.armaccessobject.ARMShelf;
import com.centurylink.icl.armmediation.armaccessobject.ARMSlot;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.SearchDeviceDetailsToCim;
import com.centurylink.icl.armmediation.transformation.SearchDeviceToCim;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.centurylink.icl.armmediation.service.MDWConstants;

public class SearchDeviceService
{
	private static final Log LOG = LogFactory.getLog(SearchDeviceService.class);

	private static final String ST = "ST";
	private static final String ND_DEF = "ND_DEF";
	private static final String LOC = "LOC";
	private static final String ND = "ND";
	private static final String EXT_ND = "EXT_ND";
	private static final String SHF = "SHF";
	private static final String EXT_SHF = "EXT_SHF";
	private static final String CARD = "CARD";
	private static final String PORT = "PORT";
	private static final String EXT_PT = "EXT_PT";
	private static final String CT = "CT";
	private static final String PT = "PT";
	private static final String AND = " AND ";
	private static final String SFP_DEF = "SFP_DEF";
	private static final String SM = "SM";
	private static final String META_DATA_REQUIRED = "False";
	private static final String ND_TYPE = "ND_TYPE";
	private static final String EPT_PT = "EPT_PT";
	private static final String SPACE = " ";
	private static final String FS = "FS";
	private static final String NR_O = "NR_O";
	private static final String NR = "NR";

	//private SearchDeviceToCim searchDeviceToCim;
	private SearchDeviceDetailsToCim searchDeviceDetailsToCim;
	private SearchDeviceDAO searchDeviceDAO;
	private JDBCTempleteUtil jdbcTempleteUtil;
	//SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

	/*public void setSearchDeviceToCim(SearchDeviceToCim searchDeviceToCim)
	{
		this.searchDeviceToCim = searchDeviceToCim;
	}*/
	public void setSearchDeviceDetailsToCim(SearchDeviceDetailsToCim searchDeviceDetailsToCim)
	{
		this.searchDeviceDetailsToCim = searchDeviceDetailsToCim;
	}
	public void setSearchDeviceDAO(SearchDeviceDAO searchDeviceDAO)
	{
		this.searchDeviceDAO = searchDeviceDAO;
	}
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public Object searchDeviceDetails(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchDeviceDetailsService: searchDeviceDetails method");
		}
		if(!StringHelper.isEmpty(MediationUtil.getRcv(request, "LocationName")))
		{
			return 	searchDevicesByLocation(request);
		}
		String deviceName = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		String deviceClli = MediationUtil.getRcv(request, "DeviceCLLI");
		String circuitId = MediationUtil.getRcv(request, "CircuitId");
		List<ARMDevice> armdeviceList = null;

		if (deviceName != null && !StringHelper.isEmpty(deviceName))
			armdeviceList = searchDeviceDAO.getDeviceList(buildDeviceDetailQuery(deviceName, null, null));
		else if (deviceClli != null && !StringHelper.isEmpty(deviceClli))
			armdeviceList = searchDeviceDAO.getDeviceList(buildDeviceDetailQuery(null, deviceClli, null));
		else if (circuitId != null && !StringHelper.isEmpty(circuitId))
			armdeviceList = searchDeviceDAO.getDeviceList(buildDeviceDetailQuery(null, null, circuitId));

		if ((armdeviceList != null && armdeviceList.size() > 0))
		{
			final SearchResourceResponseDocument response = searchDeviceDetailsToCim.transformDeviceDetailToCim(request, armdeviceList);
			if (LOG.isInfoEnabled())
			{
				LOG.info(response.toString());
			}
			return response;
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}

	public Object searchDeviceDetailsForMDW(HashMap<String, Object> iHashMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchDeviceDetailsService: searchDeviceDetails method");
		}
		
		PhysicalDevice physicalDevice=null;
		final String nodeId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.NODE_ID);
		String deviceName = MediationUtil.getValueFromMap(iHashMap, MDWConstants.DEVICE_NAME);
		
		if("NotFound" == deviceName)
		{	
			deviceName = jdbcTempleteUtil.getNodeName(nodeId);			
		}
		
		if (deviceName == "NotFound")
		{	
			return MediationUtil.getCreateDeviceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_REQUEST_VALIDATION_ERROR,
					"Request validation failure due to Device  not found", null);
		}		
		
		List<ARMNode> armdeviceList = null;

		if (deviceName != null && !StringHelper.isEmpty(deviceName))
			armdeviceList = searchDeviceDAO.getNodesList(buildNodeQuery(null,deviceName, null, null, null));;
		

		if ((armdeviceList != null && armdeviceList.size() > 0))
		{
			SearchDeviceToCim searchDeviceToCim =  new SearchDeviceToCim();
			physicalDevice = searchDeviceToCim.transformToCim(armdeviceList.get(0), null, null, null, null, null, null, null);
			
			return MediationUtil.getCreateDeviceSuccessResponse(physicalDevice, null);			
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}
	
	public Object searchDevice(String forRequest, String deviceClli, String portDirection, String metadataRequired, String shelfClass, String deviceName) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchDeviceService: GetDevice method");
		}
		
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		// To populate the node name list for the given Device CLLI
		List<ARMNode> nodeList=null;
		if(null!=deviceName || null!=deviceClli)
		{
			nodeList = searchDeviceDAO.getNodesList(buildNodeQuery(deviceClli,deviceName, null, null, null));
		}
		else
		{
			throw new ICLRequestValidationException("Device Name or DeviceCLLI Required");
		}
		// To build Error Response if Node List empty 
		if (nodeList == null || nodeList.isEmpty())
		{
			/*if (forRequest == Constants.CREATE_DEVICE_RESPONSE)
				return MediationUtil.getCreateDeviceErrorResponse("1951", "OSSDataNotFoundError", "Device could not be found in ARM", null);*/
			throw new ICLException("Device could not be found in ARM", "OSSDataNotFoundError",  "1951");
		}
		PhysicalDevice physicalDevice=null;
		// To build device response for each device name
		if(null!=nodeList && nodeList.size()>0)
		{
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			Map<String, ARMNode> uniqueDevicesMap  = new HashMap<String, ARMNode>();
			for(ARMNode armNode:nodeList)
			{
				uniqueDevicesMap.put(String.valueOf(armNode.getNodeId()), armNode);
			}
			
			
			
			Set<String> uniqueDevices = uniqueDevicesMap.keySet();
			
			for (String deviceObjectId : uniqueDevices)
			{
				
				ARMNode armNode = uniqueDevicesMap.get(deviceObjectId);
				
				String deviceName2=null;		
				if(null!=armNode)
				{
					deviceName2=armNode.getCommonName();
					final List<ARMShelf> shelfList = searchDeviceDAO.getShelfList(buildShelfQuery(deviceName2, shelfClass));
					final List<ARMCard> cardList = searchDeviceDAO.getCardList(buildCardQuery(deviceName2));
					final Map<Long, List<ARMSlot>> slot2ShelfMap = searchDeviceDAO.getSlotList(buildSlotQuery(deviceName2));
					final String portQuery = buildPortQuery(deviceName2, portDirection);
					final String portOnCardQuery = portQuery + AND + "PORT.PORT2CARD IS NOT NULL"+SPACE+"ORDER BY PORT.PORTID";
					final Map<Long, List<ARMPort>> port2CardMap = searchDeviceDAO.getPortList(portOnCardQuery);
					List<ARMSFP> sfpList = null;
					if (metadataRequired == null || metadataRequired.equalsIgnoreCase(META_DATA_REQUIRED))
					{
						sfpList = new ArrayList<ARMSFP>();
					} 
					else
					{
						sfpList = searchDeviceDAO.getSFPList(buildSFPQuery(deviceName2));
					}
					final String portOnDeviceQuery = portQuery + AND + "PORT.PORT2CARD IS NULL"+AND+"PORT.PARENTPORT2PORT IS NULL"+SPACE+"ORDER BY PORT.PORTID";
					final List<ARMPort> portOnDeviceList = searchDeviceDAO.getPortOnDeviceList(portOnDeviceQuery);
					final String loctaionType = jdbcTempleteUtil.getLocationTypeNameForDevice(deviceName2);
					final Integer locationId = jdbcTempleteUtil.getLocationIdForDevice(deviceName2);
					List<ARMLocation> locationList = null;
					if (loctaionType != null && null != String.valueOf(locationId))
					{
						locationList = searchDeviceDAO.getlocationList(buildLocationQuery(loctaionType, locationId));
					}
					SearchDeviceToCim searchDeviceToCim =  new SearchDeviceToCim();
					physicalDevice = searchDeviceToCim.transformToCim(armNode, shelfList, slot2ShelfMap, cardList, port2CardMap, portOnDeviceList, sfpList, locationList);
					searchResponseDetailsBuilder.addDevice(physicalDevice);
				}
			}
		}
		if (forRequest.equalsIgnoreCase(Constants.CREATE_DEVICE_RESPONSE))
		{
			return MediationUtil.getCreateDeviceSuccessResponse(physicalDevice, null);
		}
		else
		{
			return MediationUtil.getSearchResourceDeviceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		}
	}
	public Object searchDevicesByLocation(SearchResourceRequestDocument requestObject) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchDeviceDetailsService : calling searchDevicesByLocation method");
		}
		List<ARMLocation> armLocationList = null;
		List<ARMDevice> armdeviceList = null;
		String subscriberName = null;
		Boolean checkSubscriber = false;

		
		String locationName = MediationUtil.getRcv(requestObject, "LocationName");
		String usageState = MediationUtil.getRcv(requestObject, "SharedOrDedicated");
		if(!StringHelper.isEmpty(usageState) && usageState.equalsIgnoreCase("D"))
			subscriberName = MediationUtil.getRcv(requestObject, "SubscriberName");
		if(!StringHelper.isEmpty(subscriberName))
			checkSubscriber=true;
		if (locationName!=null)
			armdeviceList = searchDeviceDAO.getAllDeviceList(buildNodeQuery(null, null, locationName, usageState, subscriberName), checkSubscriber);

		if ((armdeviceList != null && armdeviceList.size() > 0))
		{
			SearchResourceResponseDocument response = searchDeviceDetailsToCim.transformDeviceDetailToCim(requestObject, armdeviceList);
			if (LOG.isInfoEnabled())
			{
				LOG.info(response.toString());
			}
			return response;
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}

	private String buildNodeQuery(String deviceCLLI,String deviceName, String locationName, String usageState, String subscriberName)
	{
		final SQLBuilder sql = new SQLBuilder("NODE", "ND");
		sql.addFieldFromTable(ND, "NAME");
		sql.addFieldFromTable(ND, "ALIAS1");
		sql.addFieldFromTable(ND, "ALIAS2");
		sql.addFieldFromTable(ND, "NODEID");
		sql.addFieldFromTable(ND, "RELATIVENAME");
		sql.addFieldFromTable(ST, "NAME", "PROVISIONSTATUS");
		sql.addFieldFromTable(FS, "NAME", "FUNCTIONALSTATUS");
		sql.addFieldFromTable(ND_DEF, "MANUFACTURER");
		sql.addFieldFromTable(EXT_ND, "SNMPOBJECTID");
		sql.addFieldFromTable(EXT_ND, "CLLI");
		sql.addFieldFromTable(EXT_ND, "CHASSISSERIALNUMBER");
		sql.addFieldFromTable(EXT_ND, "SERIALNUMBER");
		sql.addFieldFromTable(ND, "SOFTWAREVERSION");
		sql.addFieldFromTable(EXT_ND, "FIRMWAREVERSION");
		sql.addFieldFromTable(EXT_ND, "HARDWAREVERSION");
		sql.addFieldFromTable(EXT_ND, "NMSTYPE");
		sql.addFieldFromTable(EXT_ND, "NMSHOSTNAME");
		sql.addFieldFromTable(EXT_ND, "VENDORPARTNUMBER");
		sql.addFieldFromTable(EXT_ND, "VENDORNAME");
		sql.addFieldFromTable(EXT_ND, "MACADDRESS");
		sql.addFieldFromTable(EXT_ND, "SHARED_DEDICATED");
		sql.addFieldFromTable(EXT_ND, "MGMTVLAN");
		sql.addFieldFromTable(EXT_ND, "IPV4MGMROUTERID");
		sql.addFieldFromTable(EXT_ND, "IPV4CONSOLE1");
		sql.addFieldFromTable(EXT_ND, "IPV4CONSOLE2");
		sql.addFieldFromTable(EXT_ND, "IPV6MGMROUTERID");
		sql.addFieldFromTable(EXT_ND, "IPV6CONSOLE1");
		sql.addFieldFromTable(EXT_ND, "IPV6CONSOLE2");
		sql.addFieldFromTable(EXT_ND, "NETWORKNAME");
        sql.addFieldFromTable(ND, "DESCRIPTION");
        sql.addFieldFromTable(ND_TYPE, Constants.NAME, "RESOURCETYPE");
        sql.addFieldFromTable(ND_DEF, Constants.NAME, "RESOURCESUBTYPE");
		sql.addFieldFromTable(EXT_ND, "RESTRICTEDNOTES");		
		sql.addFieldFromTable(EXT_ND, "NWKNODENUMBER");
		sql.addFieldFromTable(EXT_ND, "MAXSUBSCRIBERBWOFFERED");
		sql.addFieldFromTable(EXT_ND, "PRISMNOSACERT");
		sql.addFieldFromTable(EXT_ND, "ONEGBPSINDICATOR");
		sql.addFieldFromTable(EXT_ND, "STACKRINGSEQNUM");
		sql.addFieldFromTable(EXT_ND, "STACKRINGSHELFID");
		sql.addFieldFromTable(EXT_ND, "AERIALORBURIED");
	
		sql.addFieldFromTable(EXT_ND, "MAXDOWNSTREAMRATE");
		sql.addFieldFromTable(EXT_ND, "MAXUPSTREAMRATE");
	
		sql.addFieldFromTable(EXT_ND, "FIBERINRANGE");
		sql.addFieldFromTable(EXT_ND, "FIBEROUTRANGE");
		sql.addFieldFromTable(EXT_ND, "SPLITTERGRPNUM");
		sql.addFieldFromTable(EXT_ND, "SPLITTERGRPNAME");
		sql.addFieldFromTable(EXT_ND, "SPLITTERSTARTPORTNUMBER");
		sql.addFieldFromTable(EXT_ND, "INSTALLDATE");
		sql.addFieldFromTable(EXT_ND, "INDOOR");
		sql.addFieldFromTable(EXT_ND, "SELFORTECHINSTALL");
		sql.addFieldFromTable(EXT_ND, "RONTAID");
		sql.addFieldFromTable(EXT_ND, "POWERSUPPLY");
		sql.addFieldFromTable(EXT_ND, "OPTITAP");
		sql.addFieldFromTable(EXT_ND, "SAPCODE");
		sql.addFieldFromTable(EXT_ND, "RESTRICTEDSTATUS");
		sql.addFieldFromTable(EXT_ND, "RELAYRACKID");
		sql.addFieldFromTable(EXT_ND, "REVISION");
		sql.addFieldFromTable(NR, "ALIAS1","ROLE");
        sql.addTable("NETWORKROLEOBJECT", NR_O);
		sql.addTable("NETWORKROLE", NR);
		
        sql.eq(ND, "NODEID", NR_O, "NETWORKROLEOBJECT2OBJECT");
		sql.eq(NR, "NETWORKROLEID", NR_O, "NETWORKROLEOBJECT2NETWORKROLE");
		
		sql.addFieldFromTable("DEVICE_COMPATIBILITY", "AUTO_IDENTIFY_NID");
		
		sql.addTable("STATUS", ST);
		sql.addTable("FUNCTIONALSTATUS", FS);
		sql.addTable("EXT_DEVICE_TYPE", EXT_ND);
		sql.addTable("NODEDEF", ND_DEF);
		sql.addTable("NODETYPE", ND_TYPE);
		sql.addTable("DEVICE_COMPATIBILITY","DEVICE_COMPATIBILITY");
				
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.eq(ND, "NODEID", EXT_ND, "NODEID");
		sql.eq(ND, "NODE2PROVISIONSTATUS", ST, "STATUSID");
		sql.eq(ND, "NODE2NODEDEF", ND_DEF, "NODEDEFID");
		sql.eq(ND, "NODE2NODETYPE", ND_TYPE, "NODETYPEID");
		
		sql.joinFO(ND, "NODE2FUNCTIONALSTATUS", FS, "FUNCTIONALSTATUSID");
		sql.joinFO(ND, "NODE2NODEDEF", "DEVICE_COMPATIBILITY", "NODE_DEF_ID");
		sql.joinFO(ND_DEF, Constants.NODE_DEF_ID, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "NODE",true);
		if(deviceCLLI!=null || !StringHelper.isEmpty(deviceCLLI) || deviceName!=null || !StringHelper.isEmpty(deviceName))
		{
			sql.addFieldFromTable(ND_DEF, "NAME", "NODEDEFNAME");
			sql.addFieldFromTable(ND_TYPE, "NAME", "NODETYPENAME");
			sql.addFieldFromTable(LOC, "NAME", "LOCATIONNAME");
			sql.addFieldFromTable(EXT_ND, "IS_DIVERSE");
			sql.addTable("LOCATION", LOC);
			sql.eq(LOC, "LOCATIONID", ND, "NODE2LOCATION");
			if(deviceCLLI!=null || !StringHelper.isEmpty(deviceCLLI))
			{
				sql.eqUpperCase(EXT_ND, "CLLI", deviceCLLI);
			}
			if(deviceName!=null || !StringHelper.isEmpty(deviceName))
			{
				sql.eqUpperCase(ND, "NAME", deviceName);
			}
		}
		if(!StringHelper.isEmpty(locationName))
		{
			sql.addFieldFromTable(ND, Constants.DESCRIPTION);
			sql.addFieldFromTable(ND, Constants.FULL_NAME);
			sql.addFieldFromTable(Constants.NETWORKROLE, "NETWORKROLEID");
			sql.addFieldFromTable(Constants.NETWORKROLE, Constants.ALIAS_1, "ROLE");
			sql.addFieldFromTable(ND, Constants.SUBTYPE);
			sql.addFieldFromTable(ND, Constants.SUB_STATUS);
			//sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNCTIONALSTATUS");
			sql.addFieldFromTable(ND_DEF, "VERSION");
			sql.addFieldFromTable(ND, Constants.MARKED_FOR_DELETE);
			sql.addFieldFromTable(EXT_ND, "REVISION");
			sql.addFieldFromTable(EXT_ND, "DISCONTINUEDATE");
			sql.addFieldFromTable(EXT_ND, "DISCONTINUEREASON");
			sql.addFieldFromTable(EXT_ND, "MANUFACTURERPARTNUMBER");
			sql.addFieldFromTable(EXT_ND, Constants.PART_TYPE);
			sql.addTable(Constants.NETWORKROLE);
			sql.addTable(Constants.NETWORKROLEOBJECT);
			//sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addTable(Constants.LOCATION);
			//sql.joinFO(ND, "NODE2FUNCTIONALSTATUS", Constants.FUNCTIONAL_STATUS, "FUNCTIONALSTATUSID");
			sql.joinFO(ND, "NODEID", Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2OBJECT");
			sql.joinFO(Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2NETWORKROLE", Constants.NETWORKROLE, "NETWORKROLEID");
			sql.joinFO(Constants.LOCATION, Constants.LOCATION_ID, ND, "NODE2LOCATION");
			sql.eq(Constants.LOCATION, "NAME", locationName);
			if(!StringHelper.isEmpty(usageState))
			{
				if(usageState.equalsIgnoreCase("S"))
					sql.eqUpperCase(EXT_ND, "SHARED_DEDICATED", "Shared");
				if(usageState.equalsIgnoreCase("D"))
					sql.eqUpperCase(EXT_ND, "SHARED_DEDICATED", "Dedicated");
				if(!StringHelper.isEmpty(subscriberName))
				{
					sql.addTable(Constants.SUBSCRIBER);
					sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID, "CUST_ID");
					sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME, "CUST_FULLNAME");
					sql.eq(ND, "RELATIVENAME", Constants.SUBSCRIBER, Constants.NAME);
					sql.eq(ND, "RELATIVENAME", subscriberName);
				}
			}
			String[] tables = {ND};
			String[] columnNames = {"NODEID"};
			sql.orderBy(tables, columnNames);
		}

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildNodeQuery ::" + query);
		}
		System.out.println("buildNodeQuery ::" + query);
		return query;
	}

	private String buildShelfQuery(String deviceName, String shelfClass)
	{
		final SQLBuilder sql = new SQLBuilder("SHELF", SHF);
		sql.addFieldFromTable(SHF, "NAME");
		sql.addFieldFromTable(SHF, "SHELFID");
		sql.addFieldFromTable(SHF, "DESCRIPTION");
		sql.addFieldFromTable(SHF, "ALIAS1");
		sql.addFieldFromTable(SHF, "ALIAS2");
		sql.addFieldFromTable(SHF, "NOTES");
		sql.addFieldFromTable(ND, "NODEID");
		sql.addFieldFromTable(EXT_SHF, "RELAYRACKID");
		sql.addFieldFromTable(EXT_SHF, "BAYNAME");
		sql.addFieldFromTable(EXT_SHF, "SHELFSERIALNUMBER");
		sql.addFieldFromTable(EXT_SHF, "HARDWAREVERSION");
		sql.addFieldFromTable(EXT_SHF, "SOFTWAREVERSION");
		sql.addFieldFromTable(EXT_SHF, "FIRMWAREVERSION");
		sql.addTable("EXT_SHELF_TABLE", EXT_SHF);
		sql.addTable("NODE", ND);
		if (shelfClass != null)
		{
			sql.addTable("SHELFTYPE", "SHELFTYPE");
			sql.eq("SHELFTYPE", "SHELFTYPEID", SHF, "SHELF2SHELFTYPE");
			sql.eq("SHELFTYPE", "DMPCLASS", shelfClass);
		}
		sql.eq(SHF, "SHELF2NODE", ND, "NODEID");
		sql.eq(SHF, "SHELFID", EXT_SHF, "SHELFID");
		sql.eq(ND, "NAME", deviceName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildShelfQuery ::" + query);
		}
		return query;
	}

	private String buildSlotQuery(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder("SLOT", ST);
		sql.addFieldFromTable(ST, "NAME");
		sql.addFieldFromTable(ST, "SLOTID");
		sql.addFieldFromTable(ST, "SLOT2SHELF");
		sql.addFieldFromTable(ST, "SLOTNUMBER");
		sql.addTable("SHELF", SHF);
		sql.addTable("NODE", ND);
		sql.eq(SHF, "SHELF2NODE", ND, "NODEID");
		sql.eq(ST, "SLOT2SHELF", SHF, "SHELFID");
		sql.eq(ND, "NAME", deviceName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildSlotQuery ::" + query);
		}
		return query;
	}

	private String buildCardQuery(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder("CARD", CARD);
		sql.addFieldFromTable(CARD, "NAME");
		sql.addFieldFromTable(CARD, "CARDID");
		sql.addFieldFromTable(CARD, "ALIAS1");
		sql.addFieldFromTable(CARD, "CARD2SHELFSLOT");
		sql.addFieldFromTable(CT, Constants.NAME, "SUBTYPE");
		sql.addFieldFromTable(ST,"SLOTID","SLOTID");	
		sql.addFieldFromTable(ST,"NAME","SLOTNAME");	
		sql.addFieldFromTable("PC",Constants.CARD_ID,"PARENTCARDID");	
		sql.addFieldFromTable(ST,"SLOTNUMBER","SLOTNUMBER");	
		sql.addTable("CARDTYPE", CT);
		sql.addTable("NODE", ND);
		sql.addTable("CARDINSLOT");
		sql.addTable("SLOT",ST);
		sql.addTable("CARD","PC");
		sql.eq(CARD, "CARD2NODE", ND, "NODEID");
		sql.eq(CARD, "CARD2CARDTYPE", CT, "CARDTYPEID");
		sql.eq(ND, "NAME", deviceName);
		sql.joinFO("CARDINSLOT","cardinslot2card",CARD,"CARDID");
		sql.joinFO("CARDINSLOT","cardinslot2slot",ST,"SLOTID");
		sql.joinFO(ST,"SLOT2CONTAININGCARD","PC",Constants.CARD_ID);
		String[] tables = {Constants.CARD };
		String[] columnNames = {Constants.CARD_ID};
		sql.orderBy(tables, columnNames);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildCardQuery : " + query);
		}
		return query;
	}

	private String buildPortQuery(String deviceName, String portDirection)
	{
		final SQLBuilder sql = new SQLBuilder("PORT", PORT);
		sql.addFieldFromTable(PORT, "NAME");
		sql.addFieldFromTable(PORT, "PORTID");
		sql.addFieldFromTable(PORT, "ALIAS1");
		sql.addTable(Constants.BANDWIDTH);
		sql.addFieldFromTable(PT, "NAME", "PORTTYPENAME");
		sql.addFieldFromTable(ST, "NAME", "STATUSNAME");
		sql.addCase(EXT_PT, "PORTFUNCTION", EPT_PT, "PORTFUNCTION", "portfunction");
		sql.addCase(EXT_PT, "DPEA", EPT_PT, "DPEA", "dpea");
		sql.addFieldFromTable(EPT_PT, "IFNUM");
		sql.addFieldFromTable(EXT_PT, "IFNUM","PLUGGABLEIFNUM");		
		sql.addFieldFromTable(EXT_PT, "WAVELENGTH");
		sql.addFieldFromTable(EXT_PT, "PLUGGABLETYPE");
		sql.addFieldFromTable(EXT_PT, "IF_NAME","PLUGGABLE_IF_NAME");
		sql.addFieldFromTable(EPT_PT, "IF_NAME","TABLE_IF_NAME");		
		sql.addFieldFromTable(Constants.BANDWIDTH, Constants.NAME, "BANDWIDTH_NAME");
		sql.addConcatenatedFieldFromTable(EXT_PT, Constants.BANDWIDTH, EXT_PT, Constants.FORM_FACTOR, "PLUGGABLE_TRANSMISSIONRATE");
		//sql.addFieldFromTable(EXT_PT, "DPEA");
		sql.addFieldFromTable(PORT, "PORT2CARD");
		sql.addFieldFromTable("RES", " ReservationID");
		sql.addFieldFromTable(EXT_PT, "PORTID", "PLUGGABLEPORTID");
		sql.addFieldFromTable(PORT, "PORTNUMBER");
		sql.addTable(Constants.EXT_PORT_PLUGGABLE, EXT_PT);
		sql.addTable(Constants.EXT_PORT_TABLE, EPT_PT);
		sql.addTable("NODE", ND);
		sql.addTable("PORTTYPE", PT);
		sql.addTable("STATUS", ST);
		sql.addTable("Reservation", "RES");
		sql.eq(PORT, "PORT2NODE", ND, "NODEID");
		sql.eq(EXT_PT, "PORTID(+)", PORT, "PORTID");
		sql.eq(EPT_PT, "PORTID(+)", PORT, "PORTID");
		sql.eq(PORT, "PORT2PORTTYPE", PT, "PORTTYPEID");
		sql.eq(PORT, "PORT2PROVISIONSTATUS", ST, "STATUSID");
		sql.eq("RES", "Reservation2object(+)", PORT, "PORTID");
		sql.joinFO(Constants.PORT, Constants.PORT2BANDWIDTH, Constants.BANDWIDTH, Constants.BANDWIDTH_ID);
		if (null != portDirection && !StringHelper.isEmpty(portDirection))
		{
			if ("NF".equalsIgnoreCase(portDirection))
			{
				portDirection = "NF";
			}
			if ("CF".equalsIgnoreCase(portDirection))
			{
				portDirection = "CF";
			}
			String[] table = { EXT_PT, EPT_PT,EXT_PT,EPT_PT };
			String[] column = { "PORTFUNCTION", "PORTFUNCTION","PORTFUNCTION","PORTFUNCTION" };
			String[] value = { portDirection, portDirection,"UN","UN" };
			sql.orClausesUpperCase(table, column, value);
		}
		sql.eq(ND, "NAME", deviceName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildPortQuery ::" + query);
		}
		System.out.println("Build port Query "+query);
		return query;
	}

	private String buildSFPQuery(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder("ARMOBJECTSFPDEF", SFP_DEF);
		sql.addField("SFPNAME");
		sql.addTable("NODE", ND);
		sql.addTable("SFPDEF_M", SM);
		sql.eq(SFP_DEF, "ARMOBJECTSFP2ARMOBJECTDIM", "1");
		sql.eq(SFP_DEF, "ARMOBJECTSFP2ARMOBJECTID", ND, "NODE2NODEDEF");
		sql.eq(SFP_DEF, "ARMOBJECTSFP2SFPDEFID", SM, "SFPDEFID");
		sql.eq(ND, "NAME", deviceName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildSFPQuery ::" + query);
		}
		return query;
	}

	private String buildLocationQuery(String loctaionType, Integer locationId)
	{
		final SQLBuilder sql2 = new SQLBuilder("LOCATION");
		sql2.addField("NAME");			
		sql2.eq("LOCATIONID", String.valueOf(locationId));

		String query2 = sql2.getStatement();
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildLocationQuery for Other Site ::" + query2);
		}
		return query2;
		
		/** Committed code By YVIKHE - This is no more required as data is populating from CLC & for clc only Need Location Name  * 
		
		 if (loctaionType.equalsIgnoreCase("Building Site"))
		{
			final SQLBuilder sql1 = new SQLBuilder("LOCATION", "Build_Loc");
			sql1.addFieldFromTable("Build_Loc", "NAME");
			sql1.addFieldFromTable("Build_Loc", "FULLNAME");
			sql1.addFieldFromTable("Loc_City", "NAME", "CITY");
			sql1.addFieldFromTable("Loc_State", "NAME", "STATE");
			sql1.addFieldFromTable("Build_Loc", "ADDRESS1");
			sql1.addFieldFromTable("Build_Loc", "ADDRESS2");
			sql1.addFieldFromTable("Build_Loc", "ADDRESS3");
			sql1.addFieldFromTable("Build_Loc", "ZIP");
			sql1.addFieldFromTable("Ext_Build", "VCOORDINATE");
			sql1.addFieldFromTable("Ext_Build", "HCOORDINATE");
			sql1.addFieldFromTable("Ext_Build", "LATA");
			sql1.addTable("LOCATION", "Loc_City");
			sql1.addTable("LOCATION", "Loc_State");
			sql1.addTable("EXT_LOCATION_BUILDING_SITE", "Ext_Build");
			sql1.eq("Build_Loc", "LOCATION2PARENTLOCATION", "Loc_City", "LOCATIONID");
			sql1.eq("Loc_City", "LOCATION2PARENTLOCATION", "Loc_State", "LOCATIONID");
			sql1.eq("Ext_Build", "LOCATIONID", "Build_Loc", "LOCATIONID");
			sql1.eq("Build_Loc", "LOCATIONID", String.valueOf(locationId));

			String query1 = sql1.getStatement();
			if (LOG.isInfoEnabled())
			{
				LOG.info("buildLocationQuery for Building Site ::" + query1);
			}
			return query1;
		}
		else
		{
			final SQLBuilder sql2 = new SQLBuilder("LOCATION", "Build_Loc");
			sql2.addFieldFromTable("Sub_Loc", "NAME");
			sql2.addFieldFromTable("Sub_Loc", "FULLNAME");
			sql2.addFieldFromTable("Loc_City", "NAME", "CITY");
			sql2.addFieldFromTable("Loc_State", "NAME", "STATE");
			sql2.addFieldFromTable("Sub_Loc", "ADDRESS1");
			sql2.addFieldFromTable("Sub_Loc", "ADDRESS2");
			sql2.addFieldFromTable("Sub_Loc", "ADDRESS3");
			sql2.addFieldFromTable("Sub_Loc", "ZIP");
			sql2.addFieldFromTable("Ext_Build", "VCOORDINATE");
			sql2.addFieldFromTable("Ext_Build", "HCOORDINATE");
			sql2.addFieldFromTable("Ext_Build", "LATA");
			sql2.addTable("LOCATION", "Loc_City");
			sql2.addTable("LOCATION", "Loc_State");
			sql2.addTable("EXT_LOCATION_BUILDING_SITE", "Ext_Build");
			sql2.addTable("LOCATION", "Sub_Loc");
			sql2.eq("Build_Loc", "LOCATION2PARENTLOCATION", "Loc_City", "LOCATIONID");
			sql2.eq("Loc_City", "LOCATION2PARENTLOCATION", "Loc_State", "LOCATIONID");
			sql2.eq("Sub_Loc", "LOCATION2PARENTLOCATION", "Build_Loc", "LOCATIONID");
			sql2.eq("Ext_Build", "LOCATIONID", "Build_Loc", "LOCATIONID");
			sql2.eq("Sub_Loc", "LOCATIONID", String.valueOf(locationId));

			String query2 = sql2.getStatement();
			if (LOG.isInfoEnabled())
			{
				LOG.info("buildLocationQuery for Other Site ::" + query2);
			}
			return query2;
		}*/

	}

	private String buildDeviceDetailQuery(String deviceName, String deviceClli, String circuitId)
	{
		SQLBuilder sql = new SQLBuilder(Constants.NODE);
		sql.addTable(Constants.EXT_DEVICE_TYPE);
		sql.addTable(Constants.NODE_TYPE);
		sql.addTable(Constants.NODE_DEF);
		sql.addTable(Constants.STATUS);
		sql.addTable(Constants.NETWORKROLE);
		sql.addTable(Constants.NETWORKROLEOBJECT);
		sql.addTable(Constants.LOCATION);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addFieldFromTable(Constants.NODE, Constants.NAME);
		sql.addFieldFromTable(Constants.NODE, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.NODE, "DESCRIPTION");
		sql.addFieldFromTable(Constants.NODE, Constants.NODE_ID, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.RELATIVE_NAME, "CUSTOMERNAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.CLLI);
		sql.addFieldFromTable(Constants.NODE_TYPE, Constants.NAME, "RESOURCETYPE");
		sql.addFieldFromTable(Constants.NODE_DEF, Constants.NAME, "RESOURCESUBTYPE");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "SHARED_DEDICATED");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.MCO);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.MANAGEMENT_VLAN);
		sql.addFieldFromTable(Constants.NODE_DEF, Constants.MANUFACTURER);
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.NETWORKROLE, "ALIAS1", "ROLE");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.PART_TYPE, "MODEL");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.VENDOR_NAME);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V4_MGM_ROUTER_ID);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "IPV4CONSOLE1");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "IPV4CONSOLE2");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V6_MGM_ROUTERID);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "IPV6CONSOLE1");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "IPV6CONSOLE2");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, "MACADDRESS");
		sql.addFieldFromTable(Constants.LOCATION, Constants.NAME, "LOCATION_NAME");
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.eq(Constants.NODE, Constants.NODE_ID, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_NODE_TYPE, Constants.NODE_TYPE, Constants.NODE_TYPE_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_NODE_DEF, Constants.NODE_DEF, Constants.NODE_DEF_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_PROVISION_STATUS, Constants.STATUS, Constants.STATUS_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_LOCATION, Constants.LOCATION, Constants.LOCATION_ID);
		sql.joinFO(Constants.NODE, Constants.NODE_ID, Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2OBJECT");
		sql.joinFO(Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2NETWORKROLE", Constants.NETWORKROLE, "NETWORKROLEID");
		sql.joinFO(Constants.NODE, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.joinFO(Constants.NODE_DEF, Constants.NODE_DEF_ID, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.eq(Constants.TT_SERVICETYPE_TRANSLATION,"ARM_OBJECT_TYPE", "NODE",true);
				
		
		if(!StringHelper.isEmpty(deviceName))
		{
			String [] table = {Constants.NODE,Constants.NODE,Constants.NODE};
			String [] column = {Constants.NAME,"ALIAS1","ALIAS2"};
			String [] value = {deviceName,deviceName,deviceName};
			if(deviceName.contains("%"))
				sql.orClausesLikeCase(table, column, value);		
			else
				sql.orClausesUpperCase(table, column, value);
		}
		if(!StringHelper.isEmpty(deviceClli))
			if(deviceClli.contains("%"))
				sql.like(Constants.EXT_DEVICE_TYPE, Constants.CLLI, deviceClli);	
			else
				sql.eqUpperCase(Constants.EXT_DEVICE_TYPE, Constants.CLLI, deviceClli);
		if (!StringHelper.isEmpty(circuitId))
		{
			sql.addTable(Constants.CIRCUIT);
			sql.or(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
			sql.eqUpperCase(Constants.CIRCUIT, Constants.NAME, circuitId);
		}
		String[] tables = {Constants.NODE};
		String[] columnNames = {Constants.NODE_ID};
		sql.orderBy(tables, columnNames);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildDeviceDetailQuery : " + query);
		}
		System.out.println("buildDeviceDetailQuery : " + query);
		return query;

	}

	private String buildLocationByBuildingClli(String buildingClli)
	{
		SQLBuilder sql = new SQLBuilder(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.LOCATION);
		sql.addFieldFromTable(Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID, "PARENT_LOC_ID");
		sql.addFieldFromTable(Constants.LOCATION, Constants.LOCATION_ID, "CHILD_LOC_ID");
		sql.eq(Constants.LOCATION, Constants.LOCATION_2_PARENT_LOCATION, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		if(buildingClli!=null && !StringHelper.isEmpty(buildingClli))
			sql.eq(Constants.EXT_LOCATION_BUILDING_SITE, Constants.CLLI_CODE, buildingClli);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildLocationByBuildingClli:" + query);
		}
		return query;
	}

}
