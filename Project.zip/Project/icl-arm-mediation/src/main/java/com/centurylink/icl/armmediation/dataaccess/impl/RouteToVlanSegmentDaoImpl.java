package com.centurylink.icl.armmediation.dataaccess.impl;

import java.util.List;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.RouteToVlanSegment;
import com.centurylink.icl.armmediation.dataaccess.RouteToVlanSegmentDAO;

public class RouteToVlanSegmentDaoImpl implements RouteToVlanSegmentDAO {
	
	private JdbcTemplate jdbcTemplate;
	
	private static final String INSERT_SQL = "INSERT INTO ROUTE_TO_VLAN_SEGMENT (ROUTE_HEADER_ID, VLAN_SEGMENTS) VALUES (?, ?)";
	private static final String VALIDATE_EMPTY_SQL = "SELECT COUNT(*) FROM ROUTE_TO_VLAN_SEGMENT WHERE ROUTE_HEADER_ID = ?";
	private static final String QUERY_BY_ID = "SELECT * FROM ROUTE_TO_VLAN_SEGMENT WHERE ROUTE_HEADER_ID=?";
	
	private static final String ROUTE_HEADER_ID = "ROUTE_HEADER_ID";
	private static final String VLAN_SEGMENTS = "VLAN_SEGMENTS";

	public RouteToVlanSegmentDaoImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public void insert(RouteToVlanSegment routeToVlanSegment) {
		this.jdbcTemplate.update(INSERT_SQL, new Object[] {routeToVlanSegment.getRouteHeaderId(), routeToVlanSegment.getVlanSegments()});
	}
	
	@Override
	public int getSegmentCountForRouteHeaderId(Long routeHeaderId)
	{
		return this.jdbcTemplate.queryForInt(VALIDATE_EMPTY_SQL, new Object[] {routeHeaderId});
	}

	@Override
	public List<RouteToVlanSegment> getVlanSegmentsForRouteHeaderId(Long routeHeaderId)
	{
		List<RouteToVlanSegment> routeToVlanSegmentList = this.jdbcTemplate.query(QUERY_BY_ID, new Object[] {routeHeaderId}, new RouteToVlanSegmentMapper());
		
		return routeToVlanSegmentList;
	}
	
	private class RouteToVlanSegmentMapper implements RowMapper<RouteToVlanSegment>
	{
		@Override
		public RouteToVlanSegment mapRow(ResultSet resultSet, int rowNum) throws SQLException
		{
			RouteToVlanSegment routeToVlanSegment = new RouteToVlanSegment();
			routeToVlanSegment.setRouteHeaderId(resultSet.getLong(ROUTE_HEADER_ID));
			routeToVlanSegment.setVlanSegments(resultSet.getString(VLAN_SEGMENTS));
			return routeToVlanSegment;
		}
	}
}
