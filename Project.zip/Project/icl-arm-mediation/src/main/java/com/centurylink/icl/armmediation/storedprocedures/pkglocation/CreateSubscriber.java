package com.centurylink.icl.armmediation.storedprocedures.pkglocation;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;



public class CreateSubscriber extends StoredProcedure{

	private static final Log	LOG	= LogFactory.getLog(CreateSubscriber.class);
	
	public CreateSubscriber(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGSUBSCRIBER.CREATESUBSCRIBER2");
		
		
		LOG.debug("ProcName: " + this.getSql());
		
		declareParameter(new SqlOutParameter("o_ErrorCode", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_ErrorText", Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_SubscriberID", Types.NUMERIC));
		declareParameter(new SqlParameter("i_SubscriberName", Types.VARCHAR));
		declareParameter(new SqlParameter("i_SubscriberTypeID", Types.NUMERIC));
		compile();
	}

	public  Map<String, Object> execute(String i_SubscriberName, BigDecimal i_SubscriberTypeID) {
		
		  Map<String, Object> in = new HashMap<String, Object>();
	  	  	  	  
	  	  in.put("i_SubscriberName", i_SubscriberName);
	  	  in.put("i_SubscriberTypeID", i_SubscriberTypeID);
	  	  
	  	  return super.execute(in);
  }
}
