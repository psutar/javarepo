package com.centurylink.icl.armmediation.transformation;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.NMIBandwidthDetails;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchNMIByDeviceToCim
{
	private static final Log LOG=LogFactory.getLog(SearchNMIByDeviceToCim.class);
	
	final private SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	final private Point2PointCircuitBuilder point2PointCircuitBuilder;
	
	public SearchNMIByDeviceToCim()
	{
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		point2PointCircuitBuilder = new Point2PointCircuitBuilder();
	}
	
	/**
	 * 
	 * Laukik : Date 08/28/2014 : 
	 * 
	 * Defect#2504 : This defect is reopened just before one day of release. Business and DSP wants both the :the LAG and Other circuits.
	 * As per ICL R2 AUC521760 – Get NMI and BANDWIDTH by Device, we need to return either LAG OR other circuits. However, today it is urgently and anyhow required to return both LAG and other circuits.
	 *
	 * 
	 * 
	 */
	public SearchResourceResponseDocument transformNMIByDeviceToCim(SearchResourceRequestDocument request, List<NMIBandwidthDetails> armNMICktsList, String resourseType,List<NMIBandwidthDetails> armLAGCktsList)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchNMIByDeviceToCim: SearchNMIByDevice : transformNMIByDeviceToCim : ");
		}
		
		boolean isEmpty = true;	// boolean to check : if both lists (armNMICktsList,armLAGCktsList) are null or empty. 
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		if(armNMICktsList != null && armNMICktsList.size() > 0)
		{
			isEmpty = false;
		    Iterator<NMIBandwidthDetails> iteratorNMI = armNMICktsList.iterator();
		    
		    while (iteratorNMI.hasNext()) {
				NMIBandwidthDetails nmiDetails = (NMIBandwidthDetails) iteratorNMI.next();
				point2PointCircuitBuilder.buildPoint2PointCircuit(nmiDetails.getCommonName(), nmiDetails.getObjectID(), null, "ARM", nmiDetails.getResourceType(), nmiDetails.getLrStatus() , null, null, nmiDetails.getBandwidth());
				searchResponseDetailsBuilder.addP2PCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
			}
		}
	
		if(armLAGCktsList != null && armLAGCktsList.size() > 0 )
		{
			isEmpty = false;
			Iterator<NMIBandwidthDetails> iteratorLAG = armLAGCktsList.iterator();
			while (iteratorLAG.hasNext()) {
				
				NMIBandwidthDetails lagDetails = (NMIBandwidthDetails) iteratorLAG.next();
				point2PointCircuitBuilder.buildPoint2PointCircuit(lagDetails.getCommonName(), lagDetails.getObjectID(), null, "ARM","LAG", lagDetails.getLrStatus() , null, null, lagDetails.getBandwidth());
				searchResponseDetailsBuilder.addP2PCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
			}
		}
		
		if(isEmpty)
		{
			throw new OSSDataNotFoundException();
		}
		
		return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
	}


}
