package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.CreateLocationResponseBuilder;
import com.centurylink.icl.builder.cim2.CreateLocationResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;
import com.iclnbi.iclnbiV200.CreateLocationResponseDocument;

public class ARMCreateLocationToCim
{

	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final CreateLocationResponseDocumentBuilder	createLocationResponseDocumentBuilder;
	private final CreateLocationResponseBuilder			createLocationResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;

	public ARMCreateLocationToCim()
	{
		createLocationResponseBuilder = new CreateLocationResponseBuilder();
		createLocationResponseDocumentBuilder = new CreateLocationResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
	}

	public CreateLocationResponseDocument transformToCim(CreateLocationRequestDocument createRequest, String objectID, String commonName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateLocation : Transform to CIM");
		}

		final AmericanPropertyAddress addressDetails = createRequest.getCreateLocationRequest().getAddressDetails();
		addressDetails.setObjectID(objectID);
		addressDetails.setCommonName(commonName);
		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(createRequest.getCreateLocationRequest().getMessageElements().getMessageAddressing());

		createLocationResponseBuilder.buildCreateLocationResponse();
		createLocationResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createLocationResponseBuilder.addAddressDetails(addressDetails);
		createLocationResponseDocumentBuilder.buildCreateLocationResponseDocument(createLocationResponseBuilder.getCreateLocationResponse());
		return createLocationResponseDocumentBuilder.getCreateLocationResponseDocument();
	}

	public CreateLocationResponseDocument transformErrorToCim(CreateLocationRequestDocument createRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateLocation : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(createRequest.getCreateLocationRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		createLocationResponseBuilder.buildCreateLocationResponse();
		createLocationResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createLocationResponseDocumentBuilder.buildCreateLocationResponseDocument(createLocationResponseBuilder.getCreateLocationResponse());
		return createLocationResponseDocumentBuilder.getCreateLocationResponseDocument();
	}

}
