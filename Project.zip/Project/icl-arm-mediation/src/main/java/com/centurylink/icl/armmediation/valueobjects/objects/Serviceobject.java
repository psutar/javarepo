package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Serviceobject extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String SERVICEOBJECT2RELATION = "SERVICEOBJECT2RELATION";
	private static final String SERVICEOBJECT2OBJECT = "SERVICEOBJECT2OBJECT";
	private static final String SERVICEOBJECT2DIMOBJECT = "SERVICEOBJECT2DIMOBJECT";
	private static final String SERVICEOBJECT2SERVICE = "SERVICEOBJECT2SERVICE";
	private static final String SERVICEOBJECTID = "SERVICEOBJECTID";

	public Serviceobject()
	{
		super();
		this.tableName = "SERVICEOBJECT";
	}

	public Serviceobject(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Serviceobject> getServiceobjectListByServiceIdandDimObject(String serviceId, String dimObject)
	{		
		return getServiceobjectListByServiceIdandDimObjectandRelationship(serviceId, dimObject, null);
	}

	public static List<Serviceobject> getServiceobjectListByServiceIdandDimObjectandRelationship(String serviceId, String dimObject, String relationship)
	{
		return getServiceobjectList(serviceId, dimObject, relationship, null);
	}
	
	public static List<Serviceobject> getServiceobjectListByObjectIdandDimObjectandRelationship(String objectId, String dimObject, String relationship)
	{
		return getServiceobjectList(null, dimObject, relationship, objectId);
	}

	public static List<Serviceobject> getServiceobjectList(String serviceId, String dimObject, String relationship, String objectId)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(serviceId))
		{
			query = SERVICEOBJECT2SERVICE + " = '" +  serviceId + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(objectId))
		{
			query += connector + SERVICEOBJECT2OBJECT + " = '" + objectId + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(dimObject))
		{
			query += connector + SERVICEOBJECT2DIMOBJECT + " = '" + dimObject + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(relationship))
		{
			query += " AND " + SERVICEOBJECT2RELATION + " = '" + relationship + "'";
		}
		
		return getServiceobjectListByQuery(query);
	}

	public static List<Serviceobject> getServiceobjectListByQuery(String query)
	{
		Serviceobject serviceobject = new Serviceobject();
		List<Serviceobject> serviceobjectList = new ArrayList<Serviceobject>();
		List<Map<String,Object>> foundServiceobjectList = serviceobject.getRecordsByQuery(query);

		for (Map<String,Object> serviceobjectMap : foundServiceobjectList)
		{
			Serviceobject workServiceobject = new Serviceobject(serviceobjectMap.get(SERVICEOBJECTID).toString());
			serviceobjectList.add(workServiceobject);
		}
		return serviceobjectList;
	}

	@Override
	public void populateModel()
	{
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(SERVICEOBJECT2RELATION, new Field(SERVICEOBJECT2RELATION, Field.TYPE_NUMERIC));
		fields.put(SERVICEOBJECT2OBJECT, new Field(SERVICEOBJECT2OBJECT, Field.TYPE_NUMERIC));
		fields.put(SERVICEOBJECT2DIMOBJECT, new Field(SERVICEOBJECT2DIMOBJECT, Field.TYPE_NUMERIC));
		fields.put(SERVICEOBJECT2SERVICE, new Field(SERVICEOBJECT2SERVICE, Field.TYPE_NUMERIC));
		fields.put(SERVICEOBJECTID, new Field(SERVICEOBJECTID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(SERVICEOBJECTID));
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setServiceobject2relation(String serviceobject2relation)
	{
		setField(SERVICEOBJECT2RELATION,serviceobject2relation);
	}

	public String getServiceobject2relation()
	{
		return getFieldAsString(SERVICEOBJECT2RELATION);
	}

	public void setServiceobject2object(String serviceobject2object)
	{
		setField(SERVICEOBJECT2OBJECT,serviceobject2object);
	}

	public String getServiceobject2object()
	{
		return getFieldAsString(SERVICEOBJECT2OBJECT);
	}

	public void setServiceobject2dimobject(String serviceobject2dimobject)
	{
		setField(SERVICEOBJECT2DIMOBJECT,serviceobject2dimobject);
	}

	public String getServiceobject2dimobject()
	{
		return getFieldAsString(SERVICEOBJECT2DIMOBJECT);
	}

	public void setServiceobject2service(String serviceobject2service)
	{
		setField(SERVICEOBJECT2SERVICE,serviceobject2service);
	}

	public String getServiceobject2service()
	{
		return getFieldAsString(SERVICEOBJECT2SERVICE);
	}

	public void setServiceobjectid(String serviceobjectid)
	{
		setField(SERVICEOBJECTID,serviceobjectid);
	}

	public String getServiceobjectid()
	{
		return getFieldAsString(SERVICEOBJECTID);
	}
}