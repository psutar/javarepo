package com.centurylink.icl.armmediation.storedprocedures.pkglocation;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class AddLocationToSubscriber extends StoredProcedure{


	private static final Log	LOG	= LogFactory.getLog(AddLocationToSubscriber.class);
	
	public AddLocationToSubscriber(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGSUBSCRIBER.ADDLOCATIONTOSUBSCRIBER");
		
		
		LOG.debug("ProcName: " + this.getSql());
		
		declareParameter(new SqlOutParameter("o_ErrorCode", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_ErrorText", Types.VARCHAR));
		declareParameter(new SqlParameter("i_subscriberid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_locationid", Types.NUMERIC));
		compile();
	}

	public  Map<String, Object> execute(BigDecimal i_subscriberid, BigDecimal i_locationid) {
		
		  Map<String, Object> in = new HashMap<String, Object>();
	  	  	  	  
	  	  in.put("i_subscriberid", i_subscriberid);
	  	  in.put("i_locationid", i_locationid);
	  	  
	  	  return super.execute(in);
  }


}
