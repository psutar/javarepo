package com.centurylink.icl.armmediation.armaccessobject;

public class SearchResourceCriteria {
	private String deviceName;
	private String deviceCLLI;
	private String status;
	private String shelfNumber;
	private String slotNumber;
	private String portNumber;
	private String enDepth;
	private String level;
	private String circuitName;
	
	
	public String getEnDepth() {
		return enDepth;
	}

	public void setEnDepth(String enDepth) {
		this.enDepth = enDepth;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDeviceCLLI() {
		return deviceCLLI;
	}

	public void setDeviceCLLI(String deviceCLLI) {
		this.deviceCLLI = deviceCLLI;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	//Added
	public String getShelfNumber() {
		return shelfNumber;
	}

	public void setShelfNumber(String shelfNumber) {
		this.shelfNumber = shelfNumber;
	}

	public String getSlotNumber() {
		return slotNumber;
	}

	public void setSlotNumber(String slotNumber) {
		this.slotNumber = slotNumber;
	}

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getCircuitName() {
		return circuitName;
	}

	public void setCircuitName(String circuitName) {
		this.circuitName = circuitName;
	}

}
