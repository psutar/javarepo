package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;

public interface SearchLocationDAO
{

	public List<ARMLocation> searchLocation(String query);

}
