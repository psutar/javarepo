package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Parameterinstance extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String PARAMINSTANCE2PARENTPARAM = "PARAMINSTANCE2PARENTPARAM";
	private static final String PARAMINSTANCE2PARAMDEFINITION = "PARAMINSTANCE2PARAMDEFINITION";
	private static final String PARAMINSTANCE2PARAMSETVERSION = "PARAMINSTANCE2PARAMSETVERSION";
	private static final String PARAMETERINSTANCEID = "PARAMETERINSTANCEID";
	
	private Parameterinstancevalue parameterinstancevalue = null;
	private Parameterdefinition parameterdefinition = null;

	private List<Parameterinstancevalue> parameterinstancevalueList = null;

	public Parameterinstance()
	{
		super();
		this.tableName = "PARAMETERINSTANCE";
	}

	public Parameterinstance(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public Parameterinstance(Parameterinstance template)
	{
		this();
		getRecordByTemplate(template);
		for(Field field:fields.values()){
			if (field.getValue() != null){
				this.instanciated = true;
				break;
			}
		}
	}

	public static List<Parameterinstance> getParameterinstanceByParametersetversionId(String parametersetversionId)
	{
		return getParameterinstanceListByQuery(PARAMINSTANCE2PARAMSETVERSION + " = " + parametersetversionId);
	}

	public static List<Parameterinstance> getParameterinstanceListByQuery(String query)
	{
		Parameterinstance parameterinstance = new Parameterinstance();
		List<Parameterinstance> parameterinstanceList = new ArrayList<Parameterinstance>();
		List<Map<String,Object>> foundParameterinstanceList = parameterinstance.getRecordsByQuery(query);

		for (Map<String,Object> parameterinstanceMap : foundParameterinstanceList)
		{
			Parameterinstance workParameterinstance = new Parameterinstance(parameterinstanceMap.get(PARAMETERINSTANCEID).toString());
			parameterinstanceList.add(workParameterinstance);
		}
		return parameterinstanceList;
	}

	@Override
	public void populateModel()
	{
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(PARAMINSTANCE2PARENTPARAM, new Field(PARAMINSTANCE2PARENTPARAM, Field.TYPE_NUMERIC));
		fields.put(PARAMINSTANCE2PARAMDEFINITION, new Field(PARAMINSTANCE2PARAMDEFINITION, Field.TYPE_NUMERIC));
		fields.put(PARAMINSTANCE2PARAMSETVERSION, new Field(PARAMINSTANCE2PARAMSETVERSION, Field.TYPE_NUMERIC));
		fields.put(PARAMETERINSTANCEID, new Field(PARAMETERINSTANCEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PARAMETERINSTANCEID));
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setParaminstance2parentparam(String paraminstance2parentparam)
	{
		setField(PARAMINSTANCE2PARENTPARAM,paraminstance2parentparam);
	}

	public String getParaminstance2parentparam()
	{
		return getFieldAsString(PARAMINSTANCE2PARENTPARAM);
	}

	public void setParaminstance2paramdefinition(String paraminstance2paramdefinition)
	{
		setField(PARAMINSTANCE2PARAMDEFINITION,paraminstance2paramdefinition);
	}

	public String getParaminstance2paramdefinition()
	{
		return getFieldAsString(PARAMINSTANCE2PARAMDEFINITION);
	}

	public void setParaminstance2paramsetversion(String paraminstance2paramsetversion)
	{
		setField(PARAMINSTANCE2PARAMSETVERSION,paraminstance2paramsetversion);
	}

	public String getParaminstance2paramsetversion()
	{
		return getFieldAsString(PARAMINSTANCE2PARAMSETVERSION);
	}

	public void setParameterinstanceid(String parameterinstanceid)
	{
		setField(PARAMETERINSTANCEID,parameterinstanceid);
	}

	public String getParameterinstanceid()
	{
		return getFieldAsString(PARAMETERINSTANCEID);
	}

	public Parameterinstancevalue getParameterinstancevalue()
	{
		if (parameterinstancevalue == null)
		{
			parameterinstancevalue = Parameterinstancevalue.getParameterinstancevalueByParameterinstanceId(this.getParameterinstanceid());
		}
		
		return parameterinstancevalue;
	}

	public Parameterdefinition getParameterdefinition()
	{
		if (parameterdefinition == null)
		{
			parameterdefinition = (Parameterdefinition) ValueObjectCacheAccessorFactory.getValueObjectCache("parameterdefinition").getCacheObject(getField(PARAMINSTANCE2PARAMDEFINITION).toString());
		}
		
		return parameterdefinition;
	}

	public List<Parameterinstancevalue> getParameterinstancevalueList()
	{
		if (parameterinstancevalueList == null)
		{
			parameterinstancevalueList = Parameterinstancevalue.getParameterinstancevalueListByQuery("PARAMVALUE2PARAMINSTANCE = '" + getParameterinstanceid() + "'");
		}
		
		return parameterinstancevalueList;
	}

}