package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;

import com.centurylink.icl.armmediation.dataaccess.GetDeviceListForCLLIDAO;

public class GetDeviceListForCLLIDAOImpl implements GetDeviceListForCLLIDAO
{
	private JdbcTemplate jdbcTemplate;
	
	private static final String GET_DEVICE_LIST_BY_CLLI_QUERY = "select N.NAME DEVICENAME from NODE N, EXT_DEVICE_TYPE EDT where N.NODEID = EDT.NODEID AND EDT.CLLI = ?";
	
	public GetDeviceListForCLLIDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public List<String> getDeviceListForCLLI(String clli)
	{
		final List<String> deviceList = this.jdbcTemplate.query(GET_DEVICE_LIST_BY_CLLI_QUERY, new Object[] {clli}, new RowMapper<String>()
		{
			public String mapRow(ResultSet resultSet, int rowNum) throws SQLException
			{
				return resultSet.getString("DEVICENAME");
			}
		});
				
		return deviceList;
	}
}
