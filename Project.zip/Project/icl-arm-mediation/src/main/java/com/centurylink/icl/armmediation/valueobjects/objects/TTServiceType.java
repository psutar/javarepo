package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class TTServiceType extends AbstractReadOnlyTable

{
	
	private static final String TTSERVICETYPETRANSLATIONID = "TT_SERVICETYPE_TRANSLATION_ID";
	private static final String ARMOBJECTID = "ARM_OBJECT_ID";
	private static final String ARMOBJECTTYPE = "ARM_OBJECT_TYPE";
	private static final String TTSERVICETYPE = "TT_SERVICE_TYPE";
	
	
	public TTServiceType()
	{
		super();
		this.tableName = "TT_SERVICETYPE_TRANSLATION";
	}

	public TTServiceType(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static List<TTServiceType> getTTServiceTypeListByQuery(String query)
	{
		TTServiceType ttServiceType = new TTServiceType();
		List<TTServiceType> ttServiceTypeList = new ArrayList<TTServiceType>();
		List<Map<String,Object>> foundTTServiceTypeList = ttServiceType.getRecordsByQuery(query);

		for (Map<String,Object> ttServiceTypeMap : foundTTServiceTypeList)
		{
			TTServiceType workttserviceType = new TTServiceType(ttServiceTypeMap.get(TTSERVICETYPETRANSLATIONID).toString());
			ttServiceTypeList.add(workttserviceType);
		}
		return ttServiceTypeList;
	}

	@Override
	public void populateModel() {
		
		
		fields.put(TTSERVICETYPETRANSLATIONID, new Field(TTSERVICETYPETRANSLATIONID, Field.TYPE_NUMERIC));
		fields.put(ARMOBJECTID, new Field(ARMOBJECTID, Field.TYPE_NUMERIC));
		fields.put(ARMOBJECTTYPE, new Field(ARMOBJECTTYPE, Field.TYPE_VARCHAR));
		fields.put(TTSERVICETYPE, new Field(TTSERVICETYPE, Field.TYPE_VARCHAR));
		
		primaryKey = new PrimaryKey(fields.get(TTSERVICETYPETRANSLATIONID));
	}

	public String getTtservicettypetranslationid() {
		return getFieldAsString(TTSERVICETYPETRANSLATIONID);
	}

	public  String getArmobjectid() {
		 return getFieldAsString(ARMOBJECTID);
	}

	public  String getArmobjecttype() {
		return getFieldAsString(ARMOBJECTTYPE);
	}

	public  String getTtservicetype() {
		return getFieldAsString(TTSERVICETYPE);
	}
	
	public void setTtservicettypetranslationid(String ttservicettypetranslationid)
	{
		setField(TTSERVICETYPETRANSLATIONID,ttservicettypetranslationid);
	}
	
	public void setArmobjectid(String armobjectid)
	{
		setField(ARMOBJECTID,armobjectid);
	}
	public void setArmobjecttype(String armobjecttype)
	{
		setField(ARMOBJECTTYPE,armobjecttype);
	}
	public void setTtservicetype(String ttservicetype)
	{
		setField(TTSERVICETYPE,ttservicetype);
	}
	

}
