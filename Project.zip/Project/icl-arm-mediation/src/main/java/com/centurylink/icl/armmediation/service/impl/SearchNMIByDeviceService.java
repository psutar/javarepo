package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.NMIBandwidthDetails;
import com.centurylink.icl.armmediation.dataaccess.SearchNMIByDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.transformation.SearchNMIByDeviceToCim;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchNMIByDeviceService
{
	private static final Log LOG = LogFactory.getLog(SearchNMIByDeviceService.class);
	
	private SearchNMIByDeviceToCim searchNMIByDeviceToCim;
	private SearchNMIByDeviceDAO searchNMIByDeviceDAO;
	
	public void setSearchNMIByDeviceToCim(SearchNMIByDeviceToCim searchNMIByDeviceToCim)
	{
		this.searchNMIByDeviceToCim = searchNMIByDeviceToCim;
	}

	public void setSearchNMIByDeviceDAO(SearchNMIByDeviceDAO searchNMIByDeviceDAO)
	{
		this.searchNMIByDeviceDAO = searchNMIByDeviceDAO;
	}

	/**
	 * 
	 * Laukik : Date 08/28/2014 : 
	 * 
	 * Defect#2504 : This defect is reopened just before one day of release. Business and DSP wants both the :the LAG and Other circuits in response.
	 * As per ICL R2 AUC521760 – Get NMI and BANDWIDTH by Device, we need to return either LAG OR other circuits. However, today it is urgently and anyhow required to return both LAG and other circuits.
	 * 
	 * To address this issue - It is required to make the changes at last moment.I am not removing the original code but commenting it for now.With below commented lines,
	 * it will execute both queries to get the LAG and Other Circuits and will pass the LAGs and Other circuits to transformation engine.
	 * There are changes in transformation side as well for SearchNMIByDeviceToCim.java 
	 * 
	 *  
	 */
	public Object searchNMIByDevice(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchNMIByDeviceService: GetNMIBYDevice");
		}
		
		final String deviceName = MediationUtil.getRcv(request, "DeviceName");
		final String status = MediationUtil.getRcv(request, "Status");
		//boolean noLAGFound=false;
		
		//check for startNode ckts and endNode by hardcoding the values.
		List<NMIBandwidthDetails> armLAGCktList = searchNMIByDeviceDAO.getLAGCktList(buildLAGQuery(deviceName, status));
		/*if(armLAGCktList!=null && armLAGCktList.size()>0)
		{
			final SearchResourceResponseDocument response = searchNMIByDeviceToCim.transformNMIByDeviceToCim(request, armLAGCktList, "LAG");
			if (LOG.isInfoEnabled())
			{
				LOG.info(response.toString());
			}
			return response;
		}
		else
		{
			noLAGFound=true;
		}
		if(noLAGFound)
		{*/
			//check for startNode ckts and endNode by hardcoding the values.
			List<NMIBandwidthDetails> armNMICktList = searchNMIByDeviceDAO.getNMICktList(buildNMIQuery(deviceName, status));
			//if(armNMICktList!=null && armNMICktList.size()>0)
			//{
				final SearchResourceResponseDocument response = searchNMIByDeviceToCim.transformNMIByDeviceToCim(request, armNMICktList, null,armLAGCktList);
				if (LOG.isInfoEnabled())
				{
					LOG.info(response.toString());
				}
				return response;
			/*}
			else
			{
				throw new OSSDataNotFoundException();
			}*/
		//}
			
		//return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_INTERNAL_ERROR, Constants.ICL_REQUEST_VALIDATION_ERROR_DETAIL, request);
		
	}

	private String buildNMIQuery(String deviceName, String status)
	{
		SQLBuilder sql =  new SQLBuilder(Constants.EXT_DEVICE_TYPE);
		sql.addTable(Constants.CIRCUIT);
		sql.addTable(Constants.STATUS);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.EXT_CIRCUIT_ETH_BEARER);
		sql.addTable(Constants.NODE);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.BANDWIDTH);
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, "BW");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUITSERVICETYPE, "RESOURCETYPE");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, Constants.STATUS, Constants.STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUIT_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
        sql.eq(Constants.NODE, Constants.NODE_ID, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.or(Constants.CIRCUIT,Constants.CIRCUIT_2_START_NODE,Constants.EXT_DEVICE_TYPE,Constants.NODE_ID,
				Constants.CIRCUIT,Constants.CIRCUIT_2_END_NODE,Constants.EXT_DEVICE_TYPE,Constants.NODE_ID);
		sql.eq(Constants.NODE, Constants.NAME, deviceName);
		if(!StringHelper.isEmpty(status) && StringHelper.isEqualIgnoreCase(status, "ACTIVE"))
		{
			List<String> statusList = new ArrayList<String>();
			statusList.add("In Service");
			statusList.add("Planned");
			statusList.add("Configured");
			statusList.add("Pending Activation");
			sql.in(Constants.STATUS, Constants.NAME, statusList);
		}
		sql.eq(Constants.CIRCUIT_TYPE, Constants.NAME, "Unrouted Ethernet Bearer");
		
		String query = sql.getStatement();
		if(LOG.isInfoEnabled())
		{
			LOG.info(query);
		}
		
		return query;
	}
	
	private String buildLAGQuery(String deviceName, String status)
	{
		SQLBuilder sql =  new SQLBuilder(Constants.EXT_DEVICE_TYPE);
		sql.addTable(Constants.CIRCUIT);
		sql.addTable(Constants.STATUS);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.EXT_CIRCUIT_LAG);
		sql.addTable(Constants.NODE);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.BANDWIDTH);
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, "BW");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPENAME");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, Constants.STATUS, Constants.STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_LAG, Constants.CIRCUIT_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
        sql.eq(Constants.NODE, Constants.NODE_ID, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.or(Constants.CIRCUIT,Constants.CIRCUIT_2_START_NODE,Constants.EXT_DEVICE_TYPE,Constants.NODE_ID,
					Constants.CIRCUIT,Constants.CIRCUIT_2_END_NODE,Constants.EXT_DEVICE_TYPE,Constants.NODE_ID);
		sql.eq(Constants.NODE, Constants.NAME, deviceName);
		if(!StringHelper.isEmpty(status) && StringHelper.isEqualIgnoreCase(status, "ACTIVE"))
		{
			List<String> statusList = new ArrayList<String>();
			statusList.add("In Service");
			statusList.add("Planned");
			statusList.add("Configured");
			statusList.add("Pending Activation");
			sql.in(Constants.STATUS, Constants.NAME, statusList);
		}
		sql.eq(Constants.CIRCUIT_TYPE, Constants.NAME, "Link Aggregation Group");
		
		String query = sql.getStatement();
		if(LOG.isInfoEnabled())
		{
			LOG.info(query);
		}
		return query;
	}
	

}
