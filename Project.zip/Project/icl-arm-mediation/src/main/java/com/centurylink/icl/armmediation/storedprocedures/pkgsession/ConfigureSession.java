package com.centurylink.icl.armmediation.storedprocedures.pkgsession;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.object.StoredProcedure;

public class ConfigureSession extends StoredProcedure
{

	public ConfigureSession(DataSource datasource)
	{
		super(datasource, "PKGSESSION.CONFIGURESESSION");

		compile();
	}

	public Map<String, Object> execute()
	{
		final Map<String, Object> in = new HashMap<String, Object>();

		return super.execute(in);
	}

}
