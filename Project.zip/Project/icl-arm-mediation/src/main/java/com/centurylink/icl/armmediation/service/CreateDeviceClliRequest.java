package com.centurylink.icl.armmediation.service;

public class CreateDeviceClliRequest
{
	private String locationClli;
	private String equipmentType;
	public String getLocationClli() {
		return locationClli;
	}
	public void setLocationClli(String locationClli) {
		this.locationClli = locationClli;
	}
	public String getEquipmentType() {
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
}
