package com.centurylink.icl.armmediation.armaccessobject;

import java.util.List;

public class SlotDetails {

	private String commonName; //Slot Name
	private List<String> cardTypesList;
	
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	
	public List<String> getCardTypesList()
	{
		return cardTypesList;
	}
	public void setCardTypesList(List<String> cardTypesList)
	{
		this.cardTypesList = cardTypesList;
	}
}
