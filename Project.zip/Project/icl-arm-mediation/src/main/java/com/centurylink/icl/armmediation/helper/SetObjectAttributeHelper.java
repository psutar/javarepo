package com.centurylink.icl.armmediation.helper;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.dataaccess.DimensionObjectDAO;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.AddToObjAttrListNumber;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.AddToObjAttrListVarchar;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.BeginObjAttrList;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.SetObjectAttributeNumber;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.SetObjectAttributeVarchar;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.WriteObjAttrListToDB;

public class SetObjectAttributeHelper
{

	private DimensionObjectDAO			dimensionObjectDAO;
	private SetObjectAttributeNumber	setObjectAttributeNumber;
	private SetObjectAttributeVarchar	setObjectAttributeVarchar;
	private BeginObjAttrList			beginObjAttrList;
	private AddToObjAttrListNumber		addToObjAttrListNumber;
	private AddToObjAttrListVarchar		addToObjAttrListVarchar;
	private WriteObjAttrListToDB		writeObjAttrListToDB;

	public SetObjectAttributeHelper(DimensionObjectDAO iDimensionObjectDAO, SetObjectAttributeNumber setObjectAttributeNumber, SetObjectAttributeVarchar setObjectAttributeVarchar, BeginObjAttrList beginObjAttrList, AddToObjAttrListNumber addToObjAttrListNumber, AddToObjAttrListVarchar addToObjAttrListVarchar, WriteObjAttrListToDB writeObjAttrListToDB)
	{
		this.dimensionObjectDAO = iDimensionObjectDAO;
		this.setObjectAttributeNumber = setObjectAttributeNumber;
		this.setObjectAttributeVarchar = setObjectAttributeVarchar;
		this.beginObjAttrList = beginObjAttrList;
		this.addToObjAttrListNumber = addToObjAttrListNumber;
		this.addToObjAttrListVarchar = addToObjAttrListVarchar;
		this.writeObjAttrListToDB = writeObjAttrListToDB;
	}

	public Map<String, Object> execute(BigDecimal i_dimobject, BigDecimal i_objectid, String i_attribute, BigDecimal i_value)
	{
		return setObjectAttributeNumber.execute(i_dimobject, i_objectid, i_attribute, i_value);
	}

	public Map<String, Object> execute(BigDecimal i_dimobject, BigDecimal i_objectid, String i_attribute, String i_value)
	{
		return setObjectAttributeVarchar.execute(i_dimobject, i_objectid, i_attribute, i_value);
	}

	public Map<String, Object> execute(String tableName, BigDecimal i_objectid, String i_attribute, BigDecimal i_value)
	{
		BigDecimal i_dimobject = dimensionObjectDAO.getDimensionObjectID(tableName);
		return this.execute(i_dimobject, i_objectid, i_attribute, i_value);
	}

	public Map<String, Object> execute(String tableName, BigDecimal i_objectid, String i_attribute, String i_value)
	{
		BigDecimal i_dimobject = dimensionObjectDAO.getDimensionObjectID(tableName);
		return this.execute(i_dimobject, i_objectid, i_attribute, i_value);
	}

	public Map<String, Object> execute(String tableName, BigDecimal i_objectid, HashMap<String, Object> attributeList) throws Exception
	{
		BigDecimal i_dimobject = dimensionObjectDAO.getDimensionObjectID(tableName);

		beginObjAttrList.execute(i_dimobject, i_objectid);
		for (String key : attributeList.keySet())
		{
			Object obj = attributeList.get(key);
			if (obj == null || obj instanceof String)
			{
				addToObjAttrListVarchar.execute(key, obj);
			} else if (obj instanceof BigDecimal)
			{
				addToObjAttrListNumber.execute(key, obj);
			} else
			{
				throw new Exception("Invalid type");
			}
		}

		return writeObjAttrListToDB.execute();
	}
}
