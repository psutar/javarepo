package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Servicetype extends AbstractReadOnlyTable {

	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String CLASS = "CLASS";
	private static final String OMSIDCALLOUT = "OMSIDCALLOUT";
	private static final String TABLENAME = "TABLENAME";
	private static final String SERVICETYPE2BROWSERBITMAP = "SERVICETYPE2BROWSERBITMAP";
	private static final String SERVICETYPE2GRAPHICSBITMAP = "SERVICETYPE2GRAPHICSBITMAP";
	private static final String NAME = "NAME";
	private static final String SERVICETYPEID = "SERVICETYPEID";

	public Servicetype()
	{
		super();
		this.tableName = "SERVICETYPE";
	}

	public Servicetype(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Servicetype> getServicetypeListByQuery(String query)
	{
		Servicetype servicetype = new Servicetype();
		List<Servicetype> servicetypeList = new ArrayList<Servicetype>();
		List<Map<String,Object>> foundServicetypeList = servicetype.getRecordsByQuery(query);

		for (Map<String,Object> servicetypeMap : foundServicetypeList)
		{
			Servicetype workServicetype = new Servicetype(servicetypeMap.get(SERVICETYPEID).toString());
			servicetypeList.add(workServicetype);
		}
		return servicetypeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(OMSIDCALLOUT, new Field(OMSIDCALLOUT, Field.TYPE_VARCHAR));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(SERVICETYPE2BROWSERBITMAP, new Field(SERVICETYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(SERVICETYPE2GRAPHICSBITMAP, new Field(SERVICETYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(SERVICETYPEID, new Field(SERVICETYPEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(SERVICETYPEID));
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setOmsidcallout(String omsidcallout)
	{
		setField(OMSIDCALLOUT,omsidcallout);
	}

	public String getOmsidcallout()
	{
		return getFieldAsString(OMSIDCALLOUT);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setServicetype2browserbitmap(String servicetype2browserbitmap)
	{
		setField(SERVICETYPE2BROWSERBITMAP,servicetype2browserbitmap);
	}

	public String getServicetype2browserbitmap()
	{
		return getFieldAsString(SERVICETYPE2BROWSERBITMAP);
	}

	public void setServicetype2graphicsbitmap(String servicetype2graphicsbitmap)
	{
		setField(SERVICETYPE2GRAPHICSBITMAP,servicetype2graphicsbitmap);
	}

	public String getServicetype2graphicsbitmap()
	{
		return getFieldAsString(SERVICETYPE2GRAPHICSBITMAP);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setServicetypeid(String servicetypeid)
	{
		setField(SERVICETYPEID,servicetypeid);
	}

	public String getServicetypeid()
	{
		return getFieldAsString(SERVICETYPEID);
	}
}