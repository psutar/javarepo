package com.centurylink.icl.armmediation.helper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.PortDirection;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;

public class JDBCTempleteUtil
{

	private static final Log LOG = LogFactory.getLog(JDBCTempleteUtil.class);
	private JdbcTemplate jdbcTemplate;

	public JDBCTempleteUtil(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int getCount(String query) throws Exception
	{
		final List<Integer> count = this.jdbcTemplate.query(query, new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("COUNT");
			}
		});

		return count.get(0);

	}

	public int getBuildingLocation(String clli) throws Exception
	{

		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION, Constants.LOCATION);
		sqlBuilder.addTable(Constants.EXT_LOCATION_BUILDING_SITE, Constants.EXT_LOCATION_BUILDING_SITE);

		sqlBuilder.addFieldFromTable(Constants.LOCATION,Constants.LOCATION_ID,Constants.LOCATION_ID);

		sqlBuilder.eq(Constants.LOCATION, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.EXT_LOCATION_BUILDING_SITE, Constants.CLLI_CODE, clli);

		final List<Integer> parentLoc = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.LOCATION_ID);
			}
		});

		return parentLoc.get(0);
	}

	public int getStateLocation(String state) throws Exception
	{

		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION, Constants.LOCATION);

		sqlBuilder.addFieldFromTable(Constants.LOCATION,Constants.LOCATION_ID,Constants.LOCATION_ID);
		sqlBuilder.addTable(Constants.LOCATIONTYPE, Constants.STATETYPE);
		
		sqlBuilder.eq(Constants.LOCATION,Constants.LOCATION_2_LOCATION_TYPE, Constants.STATETYPE, Constants.LOCATION_TYPE_ID);
		sqlBuilder.eq(Constants.STATETYPE, Constants.NAME, "State");
		sqlBuilder.eq(Constants.LOCATION,Constants.PROVINCE, state);

		final List<Integer> parentLoc = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.LOCATION_ID);
			}
		});

		return parentLoc.get(0);
	}

	public int getCityLocation(String locality,String stateName) throws Exception
	{

		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION,Constants.CITY);
		sqlBuilder.addTable(Constants.LOCATION, Constants.STATE);
		sqlBuilder.addTable(Constants.LOCATIONTYPE, Constants.CITYTYPE);
		sqlBuilder.addTable(Constants.LOCATIONTYPE, Constants.STATETYPE);

		sqlBuilder.addFieldFromTable(Constants.CITY, Constants.LOCATION_ID);
		sqlBuilder.addFieldFromTable(Constants.CITY, Constants.LOCATION_2_PARENT_LOCATION);


		sqlBuilder.eq(Constants.CITY,Constants.LOCATION_2_LOCATION_TYPE, Constants.CITYTYPE, Constants.LOCATION_TYPE_ID);
		sqlBuilder.eq(Constants.CITYTYPE, Constants.NAME, "City");
		sqlBuilder.eq(Constants.STATE,Constants.LOCATION_2_LOCATION_TYPE, Constants.STATETYPE, Constants.LOCATION_TYPE_ID);
		sqlBuilder.eq(Constants.STATETYPE, Constants.NAME, "State");
		sqlBuilder.eq(Constants.CITY, Constants.LOCATION_2_PARENT_LOCATION,Constants.STATE,Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.CITY,Constants.TOWNCITY, locality);
		sqlBuilder.eq(Constants.STATE,Constants.PROVINCE, stateName);
		/*
		sqlBuilder.eq(Constants.CITY,Constants.NAME, locality + ", " + stateName);
		sqlBuilder.eq(Constants.CITY, Constants.LOCATION_2_PARENT_LOCATION,Constants.STATE,Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.STATE,Constants.NAME, stateName);
		 */

		final List<Integer> parentLoc = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt( Constants.LOCATION_ID);
			}
		});

		return parentLoc.get(0);
	}

	public String getLocationId(String deviceCLLI)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addTable(Constants.EXT_LOCATION_BUILDING_SITE, Constants.EXT_LOCATION_BUILDING_SITE);

		sqlBuilder.addField("LOCATION.LOCATIONID", "locationId");

		sqlBuilder.eq(Constants.LOCATION, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.EXT_LOCATION_BUILDING_SITE, Constants.CLLI_CODE, deviceCLLI);

		final List<String> locationId = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("locationId");
			}
		});

		return locationId.get(0);

	}
	public String getDeviceDefId(String hesig)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.ARM_OBJECT_HECIG);

		sqlBuilder.addField("ARMOBJECTHECIG2ARMOBJECTID", "deviceDefId");

		sqlBuilder.eq(Constants.ARM_OBJECT_HESIG_2_ARM_OBJECT_DIM, "1");
		sqlBuilder.eq(Constants.ARM_OBJECT_HESIG_2_HESIG, hesig);

		final List<String> deviceDefId = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("deviceDefId");
			}
		});

		return deviceDefId.get(0);

	}

	public List<PortDirection> getPortInfo(String nodeId)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.ARMAPI_PORTDIRECTION, "ptp_dir");
		sqlBuilder.addTable(Constants.NODE);
		sqlBuilder.addTable(Constants.PORT);

		sqlBuilder.addField(Constants.PORT_ID);
		sqlBuilder.addField(Constants.PORT_DIRECTION);
		sqlBuilder.addField(Constants.PORT_NUMBER);

		sqlBuilder.eq(Constants.PORT_2_CARD, null);
		sqlBuilder.eq(Constants.PARENT_PORT_2_PORT, null);
		sqlBuilder.eq(Constants.PORT, Constants.PORT_2_NODE, Constants.NODE, Constants.NODE_ID);
		sqlBuilder.eq("ptp_dir", Constants.PORT_DIRECTION_2_NODE_DEF, Constants.NODE, Constants.NODE_2_NODE_DEF);
		sqlBuilder.eq("ptp_dir", Constants.PORT_DIRECTION_2_PORT_NUMBER, Constants.PORT, Constants.PORT_NUMBER);
		sqlBuilder.eq(Constants.NODE, Constants.NODE_ID, nodeId);

		final List<PortDirection> portDirections = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<PortDirection>() {
			public PortDirection mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				PortDirection portDirection = new PortDirection();
				portDirection.setPortId(rs.getInt(Constants.PORT_ID));
				portDirection.setPortDirection(rs.getString(Constants.PORT_DIRECTION));
				portDirection.setPortNumber(rs.getInt(Constants.PORT_NUMBER));
				return portDirection;
			}
		});

		return portDirections;

	}

	public HashMap<String, Object> getSFPAttribute(String sFPName)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SFPDEF_M);

		sqlBuilder.addField(Constants.PLUGGABLE_TYPE, Constants.PLUGGABLE_TYPE);
		sqlBuilder.addField(Constants.WAVELENGTH, Constants.WAVELENGTH);
		sqlBuilder.addField(Constants.BANDWIDTH, Constants.BANDWIDTH);
		sqlBuilder.addField("DISTANCE", Constants.DISTANCE);//num
		sqlBuilder.addField(Constants.PART_NUMBER, Constants.PART_NUMBER);
		sqlBuilder.addField(Constants.PART_NAME, Constants.PART_NAME);
		sqlBuilder.addField(Constants.TEMP_RANGE, Constants.TEMP_RANGE);
		sqlBuilder.addField(Constants.FORM_FACTOR, Constants.FORM_FACTOR);

		sqlBuilder.eq(Constants.SFP_NAME, sFPName);

		final List<HashMap<String, Object>> SfpAttrb = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<HashMap<String, Object>>() {
			public HashMap<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> attr = new HashMap<String, Object>();

				attr.put(Constants.PLUGGABLE_TYPE, rs.getString(Constants.PLUGGABLE_TYPE));
				attr.put(Constants.WAVELENGTH, rs.getString(Constants.WAVELENGTH));
				attr.put(Constants.BANDWIDTH, rs.getString(Constants.BANDWIDTH));
				attr.put(Constants.DISTANCE, rs.getString(Constants.DISTANCE));
				attr.put(Constants.PART_NUMBER, rs.getString(Constants.PART_NUMBER));
				attr.put(Constants.PART_NAME, rs.getString(Constants.PART_NAME));
				attr.put(Constants.TEMP_RANGE, rs.getString(Constants.TEMP_RANGE));
				attr.put(Constants.FORM_FACTOR, rs.getString(Constants.FORM_FACTOR));

				return attr;
			}
		});

		return SfpAttrb.get(0);

	}

	public void updatePortSfpAttribute(HashMap<String, Object> portSfpAttr, String portId)
	{
		final String query = "update EXT_PORT_PLUGGABLE set " + Constants.PLUGGABLE_TYPE + "= '" + portSfpAttr.get(Constants.PLUGGABLE_TYPE) + "' ," + Constants.WAVELENGTH + "= '"
				+ portSfpAttr.get(Constants.WAVELENGTH) + "' ," + Constants.BANDWIDTH + "= '" + portSfpAttr.get(Constants.BANDWIDTH) + "' ," + Constants.DISTANCE + "="
				+ portSfpAttr.get(Constants.DISTANCE) + "," + Constants.PART_NUMBER + "= '" + portSfpAttr.get(Constants.PART_NUMBER) + "' ," + Constants.PART_NAME + "= '"
				+ portSfpAttr.get(Constants.PART_NUMBER) + "' ," + Constants.TEMP_RANGE + "= '" + portSfpAttr.get(Constants.TEMP_RANGE) + "' ," + Constants.FORM_FACTOR + "= '"
				+ portSfpAttr.get(Constants.FORM_FACTOR) + "' where " + Constants.PORT_ID + "=" + portId;
		this.jdbcTemplate.execute(query);
	}

	public int getStartNodeId(String circuitStartPortID)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.PORT);

		sqlBuilder.addField(Constants.PORT_2_NODE, Constants.PORT_2_NODE);

		sqlBuilder.eq(Constants.PORT_ID, circuitStartPortID);

		final List<Integer> startNode = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.PORT_2_NODE);
			}
		});

		return startNode.get(0);
	}

	public int getEndNodeId(String circuitEndPortID)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.PORT);

		sqlBuilder.addField(Constants.PORT_2_NODE, Constants.PORT_2_NODE);

		sqlBuilder.eq(Constants.PORT_ID, circuitEndPortID);

		final List<Integer> endNode = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.PORT_2_NODE);
			}
		});

		return endNode.get(0);
	}

	public int getStartLocId(String startNodeId)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.NODE);

		sqlBuilder.addField(Constants.NODE_2_LOCATION, Constants.NODE_2_LOCATION);

		sqlBuilder.eq(Constants.NODE_ID, startNodeId);

		final List<Integer> startLoc = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.NODE_2_LOCATION);
			}
		});

		return startLoc.get(0);
	}

	public int getEndLocId(String endNodeId)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.NODE);

		sqlBuilder.addField(Constants.NODE_2_LOCATION, Constants.NODE_2_LOCATION);

		sqlBuilder.eq(Constants.NODE_ID, endNodeId);

		final List<Integer> endLoc = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.NODE_2_LOCATION);
			}
		});

		return endLoc.get(0);
	}

	public int getBandwidthId(String bandwidthKBPS)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.BANDWIDTH);

		sqlBuilder.addField(Constants.BANDWIDTH_ID, Constants.BANDWIDTH_ID);

		sqlBuilder.eq(Constants.KBPS_VALUE, bandwidthKBPS);

		final List<Integer> bandId = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<Integer>() {
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(Constants.BANDWIDTH_ID);
			}
		});

		return bandId.get(0);
	}

	public String getNodeClli(String nodeId)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.EXT_DEVICE_TYPE);

		sqlBuilder.addField(Constants.CLLI, Constants.CLLI);

		sqlBuilder.eq(Constants.NODE_ID, nodeId);

		final List<String> clli = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString(Constants.CLLI);
			}
		});

		return clli.get(0);
	}

	public String getNodeName(String nodeId)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.NODE);

		sqlBuilder.addField(Constants.NAME, Constants.NODE_NAME);

		sqlBuilder.eq(Constants.NODE_ID, nodeId);

		final List<String> nodeName = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString(Constants.NODE_NAME);
			}
		});

		return nodeName.get(0);
	}


	public String getNodeClliFromName(String nodeName,String deviceClli)
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.EXT_DEVICE_TYPE);

		sqlBuilder.addField(Constants.CLLI)
		.addTable(Constants.NODE)
		.eq(Constants.NODE, "NODEID", Constants.EXT_DEVICE_TYPE, "NODEID")
		.eq(Constants.NODE, "NAME", nodeName);
		if(deviceClli != null)
		{
			sqlBuilder.eq(Constants.EXT_DEVICE_TYPE,"CLLI",deviceClli);
		}

		LOG.info(sqlBuilder.getStatement() + "***********");

		final List<String> clli = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString(Constants.CLLI);
			}
		});
		if(clli != null && clli.size() == 0 )
		{
			throw new ICLException("OSSDataNotFoundError", "Device could not be found in ARM", "1951");
		}
		return clli.get(0);
	}



	public String getsubscriberId()
	{
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);

		sqlBuilder.addField(Constants.SUBSCIBER_ID, Constants.SUBSCIBER_ID);

		sqlBuilder.eq(Constants.NAME, "Generic Subscriber");

		final List<String> subId = this.jdbcTemplate.query(sqlBuilder.getStatement(), new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString(Constants.SUBSCIBER_ID);
			}
		});

		return subId.get(0);
	}

	public Integer getLocationIdForDevice(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder("LOCATION");
		sql.addFieldFromTable("LOCATION", "LOCATIONID");
		sql.addFieldFromTable("LOCATIONTYPE", "NAME");

		sql.addTable("LOCATIONTYPE");
		//sql.addTable("EXT_DEVICE_TYPE");
		sql.addTable("NODE");

		sql.eq("LOCATION", "LOCATION2LOCATIONTYPE", "LOCATIONTYPE", "LOCATIONTYPEID");	
		sql.eq("NODE", "NODE2LOCATION", "LOCATION", "LOCATIONID");
		/*if(!StringHelper.isEmpty(deviceClli))
		{	
		sql.eq("EXT_DEVICE_TYPE", "CLLI", deviceClli);
		sql.eq("EXT_DEVICE_TYPE", "NODEID", "NODE", "NODEID");
		}*/
		if(!StringHelper.isEmpty(deviceName))
		{
			sql.eq("NODE", "NAME", deviceName);
		}

		final List<Integer> locId = this.jdbcTemplate.query(sql.getStatement(), new RowMapper<Integer>()
				{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("LOCATIONID");
			}
				});

		return locId.get(0);

	}

	public String getLocationTypeNameForDevice(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder("LOCATION");
		sql.addFieldFromTable("LOCATION", "LOCATIONID");
		sql.addFieldFromTable("LOCATIONTYPE", "NAME");

		sql.addTable("LOCATIONTYPE");
		sql.addTable("EXT_DEVICE_TYPE");
		sql.addTable("NODE");

		sql.eq("LOCATION", "LOCATION2LOCATIONTYPE", "LOCATIONTYPE", "LOCATIONTYPEID");
		sql.eq("EXT_DEVICE_TYPE", "NODEID", "NODE", "NODEID");
		sql.eq("NODE", "NODE2LOCATION", "LOCATION", "LOCATIONID");
		/*if(!StringHelper.isEmpty(deviceClli))
		{
		sql.eq("EXT_DEVICE_TYPE", "CLLI", deviceClli);
		sql.eq("EXT_DEVICE_TYPE", "NODEID", "NODE", "NODEID");
		}*/
		if(!StringHelper.isEmpty(deviceName))
		{
			sql.eq("NODE","NAME",deviceName);
		}
		final List<String> locTypeName = this.jdbcTemplate.query(sql.getStatement(), new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("NAME");
			}
				});

		return locTypeName.get(0);


	}

	public List<Integer> getReservationID(String query)
	{
		final List<Integer> reservID = this.jdbcTemplate.query(query, new RowMapper<Integer>()
				{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("ReservationID");
			}
				});

		return reservID;
	}

	public HashMap<String, String> getCircuit2LocationAttribute(String query)
	{
		final List<HashMap<String, String>> locationAttrb = this.jdbcTemplate.query(query, new RowMapper<HashMap<String, String>>()
				{
			public HashMap<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, String> attr = new HashMap<String, String>();
				attr.put(Constants.CIRCUIT_2_START_LOCATION, rs.getString("CIRCUIT2STARTLOCATION"));
				attr.put(Constants.CIRCUIT_2_END_LOCATION, rs.getString("CIRCUIT2ENDLOCATION"));
				return attr;
			}
				});
		return locationAttrb.get(0);

	}

	public String getServiceTypeName(String query)
	{
		final List<String> serviceType = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("SERVICETYPENAME");
			}
				});
		if(serviceType!=null  && serviceType.size()>0)
		{	
			return serviceType.get(0);
		}
		else return null;
	}
	public String getServiceId(String query)
	{
		final List<String> serviceID = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("SERVICEID");
			}
				});
		if(serviceID!=null  && serviceID.size()>0)
		{	
			return serviceID.get(0);
		}
		else return null;		
	}
	
	public List<String> getServiceIdList(String query)
	{
		final List<String> serviceIDList = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("SERVICEID");
			}
				});
		if(serviceIDList!=null  && serviceIDList.size()>0)
		{	
			return serviceIDList;
		}
		else return null;		
	}

	public String getCircuitId(String query)
	{
		final List<String> serviceID = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString(Constants.CIRCUIT_ID);
			}
				});

		return serviceID.get(0);
	}

	public HashMap<String, String> getCircuit2PortAttribute(String query)
	{
		final List<HashMap<String, String>> portAttrb = this.jdbcTemplate.query(query, new RowMapper<HashMap<String, String>>()
				{
			public HashMap<String, String> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, String> attr = new HashMap<String, String>();
				attr.put(Constants.CIRCUIT_2_START_PORT, rs.getString("CIRCUIT2STARTPORT"));
				attr.put(Constants.CIRCUIT_2_END_PORT, rs.getString("CIRCUIT2ENDPORT"));
				return attr;
			}
				});
		return portAttrb.get(0);
	}

	public String getPortId(String query)
	{
		final List<String> portID = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("PORTID");
			}
				});
		if(portID!=null && portID.size()>0)
			return portID.get(0);
		else
			return	null;
	}

	public List<String> getPortIdList(String query)
	{
		final List<String> portID = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("PORTID");
			}
				});
		if(portID!=null && portID.size()>0)
			return portID;
		else
			return	null;
	}

	public Integer getDeleteLocationId(String query)
	{
		final List<Integer> locationID = this.jdbcTemplate.query(query, new RowMapper<Integer>()
				{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("LOCATIONID");
			}
				});

		//return locationID.get(0);
		if(locationID.isEmpty())
		{
			return 0;
		}
		else
		{
			return locationID.get(0);
		}
	}
	
	public List<Integer> getSubscriberIdMultiple(String query,final String columnName)
	{
		final List<Integer> subscribers = this.jdbcTemplate.query(query, new RowMapper<Integer>()
		{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt(columnName);
			}
		});
		return subscribers;
	}
	
	
	
	public Integer getSubscriberId(String query)
	{
		final List<Integer> subscriberID = this.jdbcTemplate.query(query, new RowMapper<Integer>()
				{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("SUBSCRIBERID");
			}
				});

		//return subscriberID.get(0);
		if(subscriberID.isEmpty())
		{
			return 0;
		}
		else
		{
			return subscriberID.get(0);
		}
	}

	public String getSubscriber2SubscriberTypeId(String query)
	{
		final List<String> subscriber2SubscriberID = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("SUBSCRIBER2SUBSCRIBERTYPE");
			}
				});

		//return subscriberID.get(0);
		if(subscriber2SubscriberID.isEmpty())
		{
			return null;
		}
		else
		{
			return subscriber2SubscriberID.get(0);
		}
	}

	public Integer getSubscriberTypeId(String query)
	{
		final List<Integer> subscriberTypeID = this.jdbcTemplate.query(query, new RowMapper<Integer>()
				{
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getInt("SUBSCRIBERTYPEID");
			}
				});
		return subscriberTypeID.get(0);
	}

	public String getBan(String query) 
	{
		final List<String> ban = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("CUSTACCTBAN");
			}
				});
		if(ban!=null  && ban.size()>0)
		{      
			return ban.get(0);
		}
		else return null;
	}

	public String getMarkedForDelete(String query)
	{
		final List<String> markedForDelete = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("MARKEDFORDELETE");
			}
				});

		if(markedForDelete.isEmpty()){

			return null;
		}
		else{
			return markedForDelete.get(0);
		}
	}

	public String getLocationName(String query)
	{
		final List<String> locName = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("NAME");
			}
				});

		if(locName.isEmpty()){

			return null;
		}
		else{
			return locName.get(0);
		}
	}

	public String getLocationTypeId(String query)
	{
		final List<String> locTypeId = this.jdbcTemplate.query(query, new RowMapper<String>()
				{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("NAME");
			}
				});

		return locTypeId.get(0);

	}

	public String getSubscriberName(String query)
	{
		return getLocationName(query); // Since we are returning only "NAME" from resultset...
	}

	public int executeUpdate(String query)
	{
		return jdbcTemplate.update(query);
		
	}
	
	public List<Map<String, String>> query(String query){
		try
		{
			LOG.info("final query executed>>> " + query);
			List<Map<String, String>> columnNamesAndValues = this.jdbcTemplate.query(query, new RowMapper<Map<String, String>>(){
	
				@Override
				public Map<String, String> mapRow(ResultSet rs, int rowNum)
						throws SQLException {
	
					Map<String, String> columnNameValue = new HashMap<String, String>();
				    ColumnNameExtractor columnNameExtractor = new ColumnNameExtractor();
				    List<String> columnNames = columnNameExtractor.extractData(rs);
				    
				    for (String columnName : columnNames) {
						
				    	String columnValue = rs.getString(columnName);
				    	columnNameValue.put(columnName, columnValue);
					}
					
					return columnNameValue;
				}
				
			});
			
			return columnNamesAndValues;
		}
		catch(Exception e)
		{
			throw new ICLException("ICLInternalError",e.getMessage(),"1947");
		}
	}
	
	private class ColumnNameExtractor implements ResultSetExtractor<List<String>>
	{
		
		@Override
		public List<String> extractData(ResultSet rs) throws SQLException,DataAccessException {
				
			ResultSetMetaData metaData = rs.getMetaData();
			List<String > columnNames = new ArrayList<String>(metaData.getColumnCount());
			for(int i = 1; i <= metaData.getColumnCount(); i ++)
			{
				columnNames.add(metaData.getColumnName(i).toUpperCase());
			}
			return columnNames;
		}
		
	}
}
