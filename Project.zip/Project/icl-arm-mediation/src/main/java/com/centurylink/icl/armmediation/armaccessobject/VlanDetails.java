package com.centurylink.icl.armmediation.armaccessobject;

public class VlanDetails 
{
	
	String numberValue;
	String numberType;
	String vlanPortID;
	String vlanFunction;
	String serviceID;
	
	public String getNumberValue() {
		return numberValue;
	}
	public void setNumberValue(String numberValue) {
		this.numberValue = numberValue;
	}
	public String getNumberType() {
		return numberType;
	}
	public void setNumberType(String numberType) {
		this.numberType = numberType;
	}
	public String getVlanPortID() {
		return vlanPortID;
	}
	public void setVlanPortID(String vlanPortID) {
		this.vlanPortID = vlanPortID;
	}
	public String getVlanFunction() {
		return vlanFunction;
	}
	public void setVlanFunction(String vlanFunction) {
		this.vlanFunction = vlanFunction;
	}
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

}
