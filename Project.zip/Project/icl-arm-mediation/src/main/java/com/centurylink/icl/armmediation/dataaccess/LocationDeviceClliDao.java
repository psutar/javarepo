package com.centurylink.icl.armmediation.dataaccess;



public interface LocationDeviceClliDao {

	public int LookupClliSequence(String locationCLLI);
	
	public void InsertClliSequence(int deviceClliSeq, String locationCLLI);
	
	public void UpdateClliSequence(int deviceClliSeq, String locationCLLI);
}
