package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.List;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class PortExtension extends AbstractReadOnlyTable {

	private static final String BW = "BW";
	private static final String FUNCTION = "FUNCTION";
	private static final String HARDWAREVERSION = "HARDWAREVERSION";
	private static final String SOFTWAREVERSION = "SOFTWAREVERSION";
	private static final String PLUGGABLETYPE = "PLUGGABLETYPE";
	private static final String MEDIATYPE = "MEDIATYPE";
	private static final String ENCAPSULATION = "ENCAPSULATION";
	private static final String RPPLANID = "RPPLANID";
	private static final String DPEA = "DPEA";
	private static final String DISTANCEPERKM = "DISTANCEPERKM";
	private static final String MODE_EB = "MODE_EB";
	private static final String PARTNAME = "PARTNAME";
	private static final String DUPLEXSTATE = "DUPLEXSTATE";
	private static final String IS_DIVERSE = "IS_DIVERSE";
	private static final String PARTNUMBER = "PARTNUMBER";
	private static final String FORMFACTOR = "FORMFACTOR";
	private static final String EVCNCICODE = "EVCNCICODE";
	private static final String LABEL = "LABEL";
	private static final String PORTID = "PORTID";
	private static final String PORTFUNCTION = "PORTFUNCTION";
	private static final String IFNUM = "IFNUM";
	private static final String MTU = "MTU";
	private static final String IS_LAG_MEMBER = "IS_LAG_MEMBER";
	private static final String IF_ALIAS = "IF_ALIAS";
	private static final String IF_NAME = "IF_NAME";
	private static final String RX = "RX";
	private static final String TX = "TX";
	private static final String IF_DESCR = "IF_DESCR";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String BANDWIDTH = "BANDWIDTH";
	private static final String FIRMWAREVERSION = "FIRMWAREVERSION";
	private static final String WAVELENGTH = "WAVELENGTH";
	private static final String TEMPRANGE = "TEMPRANGE";
	private static final String SLA_AGREEMENT_TEMPLATE = "SLA_AGREEMENT_TEMPLATE";
	private static final String MILEAGE_BETWEEN_ENDPOINTS = "MILEAGE_BETWEEN_ENDPOINTS";

	public PortExtension()
	{
		super();
	}

	public PortExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		this.getRecordByPrimaryKey();
	}


	@Override
	public void populateModel()
	{
		fields.put(BW, new Field(BW, Field.TYPE_VARCHAR));
		fields.put(FUNCTION, new Field(FUNCTION, Field.TYPE_VARCHAR));
		fields.put(HARDWAREVERSION, new Field(HARDWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(SOFTWAREVERSION, new Field(SOFTWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(PLUGGABLETYPE, new Field(PLUGGABLETYPE, Field.TYPE_VARCHAR));
		fields.put(MEDIATYPE, new Field(MEDIATYPE, Field.TYPE_VARCHAR));
		fields.put(ENCAPSULATION, new Field(ENCAPSULATION, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(DPEA, new Field(DPEA, Field.TYPE_VARCHAR));
		fields.put(DISTANCEPERKM, new Field(DISTANCEPERKM, Field.TYPE_NUMERIC));
		fields.put(MODE_EB, new Field(MODE_EB, Field.TYPE_VARCHAR));
		fields.put(PARTNAME, new Field(PARTNAME, Field.TYPE_VARCHAR));
		fields.put(DUPLEXSTATE, new Field(DUPLEXSTATE, Field.TYPE_VARCHAR));
		fields.put(IS_DIVERSE, new Field(IS_DIVERSE, Field.TYPE_VARCHAR));
		fields.put(PARTNUMBER, new Field(PARTNUMBER, Field.TYPE_VARCHAR));
		fields.put(FORMFACTOR, new Field(FORMFACTOR, Field.TYPE_VARCHAR));
		fields.put(EVCNCICODE, new Field(EVCNCICODE, Field.TYPE_VARCHAR));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(PORTID, new Field(PORTID, Field.TYPE_NUMERIC));
		fields.put(PORTFUNCTION, new Field(PORTFUNCTION, Field.TYPE_VARCHAR));
		fields.put(IFNUM, new Field(IFNUM, Field.TYPE_VARCHAR));
		fields.put(MTU, new Field(MTU, Field.TYPE_NUMERIC));
		fields.put(IS_LAG_MEMBER, new Field(IS_LAG_MEMBER, Field.TYPE_VARCHAR));
		fields.put(IF_ALIAS, new Field(IF_ALIAS, Field.TYPE_VARCHAR));
		fields.put(IF_NAME, new Field(IF_NAME, Field.TYPE_VARCHAR));
		fields.put(RX, new Field(RX, Field.TYPE_VARCHAR));
		fields.put(TX, new Field(TX, Field.TYPE_VARCHAR));
		fields.put(IF_DESCR, new Field(IF_DESCR, Field.TYPE_VARCHAR));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(BANDWIDTH, new Field(BANDWIDTH, Field.TYPE_VARCHAR));
		fields.put(FIRMWAREVERSION, new Field(FIRMWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(WAVELENGTH, new Field(WAVELENGTH, Field.TYPE_VARCHAR));
		fields.put(TEMPRANGE, new Field(TEMPRANGE, Field.TYPE_VARCHAR));
		fields.put(SLA_AGREEMENT_TEMPLATE, new Field(SLA_AGREEMENT_TEMPLATE, Field.TYPE_VARCHAR));
		fields.put(MILEAGE_BETWEEN_ENDPOINTS, new Field(MILEAGE_BETWEEN_ENDPOINTS, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PORTID));
	}

	public void setBw(String bw)
	{
		setField(BW,bw);
	}

	public String getBw()
	{
		return getFieldAsString(BW);
	}

	public void setFunction(String function)
	{
		setField(FUNCTION,function);
	}

	public String getFunction()
	{
		return getFieldAsString(FUNCTION);
	}

	public void setHardwareversion(String hardwareversion)
	{
		setField(HARDWAREVERSION,hardwareversion);
	}

	public String getHardwareversion()
	{
		return getFieldAsString(HARDWAREVERSION);
	}

	public void setSoftwareversion(String softwareversion)
	{
		setField(SOFTWAREVERSION,softwareversion);
	}

	public String getSoftwareversion()
	{
		return getFieldAsString(SOFTWAREVERSION);
	}

	public void setPluggabletype(String pluggabletype)
	{
		setField(PLUGGABLETYPE,pluggabletype);
	}

	public String getPluggabletype()
	{
		return getFieldAsString(PLUGGABLETYPE);
	}

	public void setMediatype(String mediatype)
	{
		setField(MEDIATYPE,mediatype);
	}

	public String getMediatype()
	{
		return getFieldAsString(MEDIATYPE);
	}

	public void setEncapsulation(String encapsulation)
	{
		setField(ENCAPSULATION,encapsulation);
	}

	public String getEncapsulation()
	{
		return getFieldAsString(ENCAPSULATION);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setDpea(String dpea)
	{
		setField(DPEA,dpea);
	}

	public String getDpea()
	{
		return getFieldAsString(DPEA);
	}

	public void setDistanceperkm(String distanceperkm)
	{
		setField(DISTANCEPERKM,distanceperkm);
	}

	public String getDistanceperkm()
	{
		return getFieldAsString(DISTANCEPERKM);
	}

	public void setModeEb(String modeEb)
	{
		setField(MODE_EB,modeEb);
	}

	public String getModeEb()
	{
		return getFieldAsString(MODE_EB);
	}

	public void setPartname(String partname)
	{
		setField(PARTNAME,partname);
	}

	public String getPartname()
	{
		return getFieldAsString(PARTNAME);
	}

	public void setDuplexstate(String duplexstate)
	{
		setField(DUPLEXSTATE,duplexstate);
	}

	public String getDuplexstate()
	{
		return getFieldAsString(DUPLEXSTATE);
	}

	public void setIsDiverse(String isDiverse)
	{
		setField(IS_DIVERSE,isDiverse);
	}

	public String getIsDiverse()
	{
		return getFieldAsString(IS_DIVERSE);
	}

	public void setPartnumber(String partnumber)
	{
		setField(PARTNUMBER,partnumber);
	}

	public String getPartnumber()
	{
		return getFieldAsString(PARTNUMBER);
	}

	public void setFormfactor(String formfactor)
	{
		setField(FORMFACTOR,formfactor);
	}

	public String getFormfactor()
	{
		return getFieldAsString(FORMFACTOR);
	}

	public void setEvcncicode(String evcncicode)
	{
		setField(EVCNCICODE,evcncicode);
	}

	public String getEvcncicode()
	{
		return getFieldAsString(EVCNCICODE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setPortid(String portid)
	{
		setField(PORTID,portid);
	}

	public String getPortid()
	{
		return getFieldAsString(PORTID);
	}

	public void setPortfunction(String portfunction)
	{
		setField(PORTFUNCTION,portfunction);
	}

	public String getPortfunction()
	{
		return getFieldAsString(PORTFUNCTION);
	}

	public void setIfnum(String ifnum)
	{
		setField(IFNUM,ifnum);
	}

	public String getIfnum()
	{
		return getFieldAsString(IFNUM);
	}

	public void setMtu(String mtu)
	{
		setField(MTU,mtu);
	}

	public String getMtu()
	{
		return getFieldAsString(MTU);
	}

	public void setIsLagMember(String isLagMember)
	{
		setField(IS_LAG_MEMBER,isLagMember);
	}

	public String getIsLagMember()
	{
		return getFieldAsString(IS_LAG_MEMBER);
	}

	public void setIfAlias(String ifAlias)
	{
		setField(IF_ALIAS,ifAlias);
	}

	public String getIfAlias()
	{
		return getFieldAsString(IF_ALIAS);
	}

	public void setIfName(String ifName)
	{
		setField(IF_NAME,ifName);
	}

	public String getIfName()
	{
		return getFieldAsString(IF_NAME);
	}

	public void setRx(String rx)
	{
		setField(RX,rx);
	}

	public String getRx()
	{
		return getFieldAsString(RX);
	}

	public void setTx(String tx)
	{
		setField(TX,tx);
	}

	public String getTx()
	{
		return getFieldAsString(TX);
	}

	public void setIfDescr(String ifDescr)
	{
		setField(IF_DESCR,ifDescr);
	}

	public String getIfDescr()
	{
		return getFieldAsString(IF_DESCR);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setBandwidth(String bandwidth)
	{
		setField(BANDWIDTH,bandwidth);
	}

	public String getBandwidth()
	{
		return getFieldAsString(BANDWIDTH);
	}

	public void setFirmwareversion(String firmwareversion)
	{
		setField(FIRMWAREVERSION,firmwareversion);
	}

	public String getFirmwareversion()
	{
		return getFieldAsString(FIRMWAREVERSION);
	}

	public void setWavelength(String wavelength)
	{
		setField(WAVELENGTH,wavelength);
	}

	public String getWavelength()
	{
		return getFieldAsString(WAVELENGTH);
	}

	public void setTemprange(String temprange)
	{
		setField(TEMPRANGE,temprange);
	}

	public String getTemprange()
	{
		return getFieldAsString(TEMPRANGE);
	}
	
	public String getSlaAgreementTemplate()
    {
        return getFieldAsString(SLA_AGREEMENT_TEMPLATE);
    }
	
	public String getMilageBetweenEndpoints()
    {
        return getFieldAsString(MILEAGE_BETWEEN_ENDPOINTS);
    }
}