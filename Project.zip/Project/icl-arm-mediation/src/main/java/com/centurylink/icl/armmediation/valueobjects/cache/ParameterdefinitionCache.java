package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Parameterdefinition;
import com.centurylink.icl.armmediation.valueobjects.objects.Servicetype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class ParameterdefinitionCache implements ValueObjectCache {
	
	private Map<String, Parameterdefinition> cachedObjects = new HashMap<String, Parameterdefinition>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Parameterdefinition newParameterdefinition = new Parameterdefinition(key);
			if (newParameterdefinition.isInstanciated())
			{
				cachedObjects.put(key, newParameterdefinition);
				return newParameterdefinition;
			} else {
				return null;
			}
		}
	}

}
