package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class DimnumberExtension extends AbstractReadOnlyTable {
	
	private static final String FUNCTION = "FUNCTION";
	private static String LABEL = "LABEL";	
	private static final String USEDBYSERVICE = "USEDBYSERVICE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String RPPLANID = "RPPLANID";
	private static final String DIMNUMBERID = "DIMNUMBERID";
	

	public DimnumberExtension() {
		super();
	}

	public DimnumberExtension(Field key, String tableName) {
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	@Override
	public void populateModel() {
		
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(FUNCTION, new Field(FUNCTION,Field.TYPE_VARCHAR));		
		fields.put(DIMNUMBERID, new Field(DIMNUMBERID, Field.TYPE_NUMERIC));		
		fields.put(USEDBYSERVICE, new Field(USEDBYSERVICE, Field.TYPE_VARCHAR));		

		primaryKey = new PrimaryKey(fields.get(DIMNUMBERID));
		
	}

	public void setLabel(String label) {
		setField(LABEL, label);
	}

	public String getLabel() {
		return getFieldAsString(LABEL);
	}

	public void setRpplanid(String rpplanid) {
		setField(RPPLANID, rpplanid);
	}

	public String getRpplanid() {
		return getFieldAsString(RPPLANID);
	}

	public void setIsvisible(String isvisible) {
		setField(ISVISIBLE, isvisible);
	}

	public String getIsvisible() {
		return getFieldAsString(ISVISIBLE);
	}
	
	public void setFunction(String function) {
		setField(FUNCTION, function);
	}

	public String getFunction() {
		return getFieldAsString(FUNCTION);
	}

	public void setDimnumberid(String linkid) {
		setField(DIMNUMBERID, linkid);
	}

	public String getDimnumberid() {
		return getFieldAsString(DIMNUMBERID);
	}

}
