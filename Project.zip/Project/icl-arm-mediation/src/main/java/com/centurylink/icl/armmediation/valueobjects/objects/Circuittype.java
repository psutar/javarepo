package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Circuittype extends AbstractReadOnlyTable {

	private static final String TIMESLOTBEHAVIOUR = "TIMESLOTBEHAVIOUR";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String SYMMETRICFLAG = "SYMMETRICFLAG";
	private static final String UNIDIRECTIONALFLAG = "UNIDIRECTIONALFLAG";
	private static final String TRANSPARENCYBEHAVIOUR = "TRANSPARENCYBEHAVIOUR";
	private static final String ROUTINGBEHAVIOUR = "ROUTINGBEHAVIOUR";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String CLASS = "CLASS";
	private static final String CIRCUITTYPE2PORTTYPE = "CIRCUITTYPE2PORTTYPE";
	private static final String AUTOCREATEPORT = "AUTOCREATEPORT";
	private static final String BURSTBANDWIDTHATTRNAME = "BURSTBANDWIDTHATTRNAME";
	private static final String EXPECTEDBANDWIDTHATTRNAME = "EXPECTEDBANDWIDTHATTRNAME";
	private static final String COMMITTEDBANDWIDTHATTRNAME = "COMMITTEDBANDWIDTHATTRNAME";
	private static final String BEHAVIOUR = "BEHAVIOUR";
	private static final String TABLENAME = "TABLENAME";
	private static final String CIRCUITTYPE2BROWSERBITMAP = "CIRCUITTYPE2BROWSERBITMAP";
	private static final String CIRCUITTYPE2GRAPHICSBITMAP = "CIRCUITTYPE2GRAPHICSBITMAP";
	private static final String NAME = "NAME";
	private static final String CIRCUITTYPEID = "CIRCUITTYPEID";

	public Circuittype()
	{
		super();
		this.tableName = "CIRCUITTYPE";
	}

	public Circuittype(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Circuittype> getCircuittypeListByQuery(String query)
	{
		Circuittype circuittype = new Circuittype();
		List<Circuittype> circuittypeList = new ArrayList<Circuittype>();
		List<Map<String,Object>> foundCircuittypeList = circuittype.getRecordsByQuery(query);

		for (Map<String,Object> circuittypeMap : foundCircuittypeList)
		{
			Circuittype workCircuittype = new Circuittype(circuittypeMap.get(CIRCUITTYPEID).toString());
			circuittypeList.add(workCircuittype);
		}
		return circuittypeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(TIMESLOTBEHAVIOUR, new Field(TIMESLOTBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(SYMMETRICFLAG, new Field(SYMMETRICFLAG, Field.TYPE_NUMERIC));
		fields.put(UNIDIRECTIONALFLAG, new Field(UNIDIRECTIONALFLAG, Field.TYPE_NUMERIC));
		fields.put(TRANSPARENCYBEHAVIOUR, new Field(TRANSPARENCYBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(ROUTINGBEHAVIOUR, new Field(ROUTINGBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(CIRCUITTYPE2PORTTYPE, new Field(CIRCUITTYPE2PORTTYPE, Field.TYPE_NUMERIC));
		fields.put(AUTOCREATEPORT, new Field(AUTOCREATEPORT, Field.TYPE_NUMERIC));
		fields.put(BURSTBANDWIDTHATTRNAME, new Field(BURSTBANDWIDTHATTRNAME, Field.TYPE_VARCHAR));
		fields.put(EXPECTEDBANDWIDTHATTRNAME, new Field(EXPECTEDBANDWIDTHATTRNAME, Field.TYPE_VARCHAR));
		fields.put(COMMITTEDBANDWIDTHATTRNAME, new Field(COMMITTEDBANDWIDTHATTRNAME, Field.TYPE_VARCHAR));
		fields.put(BEHAVIOUR, new Field(BEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(CIRCUITTYPE2BROWSERBITMAP, new Field(CIRCUITTYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(CIRCUITTYPE2GRAPHICSBITMAP, new Field(CIRCUITTYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(CIRCUITTYPEID, new Field(CIRCUITTYPEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CIRCUITTYPEID));
	}

	public void setTimeslotbehaviour(String timeslotbehaviour)
	{
		setField(TIMESLOTBEHAVIOUR,timeslotbehaviour);
	}

	public String getTimeslotbehaviour()
	{
		return getFieldAsString(TIMESLOTBEHAVIOUR);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setSymmetricflag(String symmetricflag)
	{
		setField(SYMMETRICFLAG,symmetricflag);
	}

	public String getSymmetricflag()
	{
		return getFieldAsString(SYMMETRICFLAG);
	}

	public void setUnidirectionalflag(String unidirectionalflag)
	{
		setField(UNIDIRECTIONALFLAG,unidirectionalflag);
	}

	public String getUnidirectionalflag()
	{
		return getFieldAsString(UNIDIRECTIONALFLAG);
	}

	public void setTransparencybehaviour(String transparencybehaviour)
	{
		setField(TRANSPARENCYBEHAVIOUR,transparencybehaviour);
	}

	public String getTransparencybehaviour()
	{
		return getFieldAsString(TRANSPARENCYBEHAVIOUR);
	}

	public void setRoutingbehaviour(String routingbehaviour)
	{
		setField(ROUTINGBEHAVIOUR,routingbehaviour);
	}

	public String getRoutingbehaviour()
	{
		return getFieldAsString(ROUTINGBEHAVIOUR);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setCircuittype2porttype(String circuittype2porttype)
	{
		setField(CIRCUITTYPE2PORTTYPE,circuittype2porttype);
	}

	public String getCircuittype2porttype()
	{
		return getFieldAsString(CIRCUITTYPE2PORTTYPE);
	}

	public void setAutocreateport(String autocreateport)
	{
		setField(AUTOCREATEPORT,autocreateport);
	}

	public String getAutocreateport()
	{
		return getFieldAsString(AUTOCREATEPORT);
	}

	public void setBurstbandwidthattrname(String burstbandwidthattrname)
	{
		setField(BURSTBANDWIDTHATTRNAME,burstbandwidthattrname);
	}

	public String getBurstbandwidthattrname()
	{
		return getFieldAsString(BURSTBANDWIDTHATTRNAME);
	}

	public void setExpectedbandwidthattrname(String expectedbandwidthattrname)
	{
		setField(EXPECTEDBANDWIDTHATTRNAME,expectedbandwidthattrname);
	}

	public String getExpectedbandwidthattrname()
	{
		return getFieldAsString(EXPECTEDBANDWIDTHATTRNAME);
	}

	public void setCommittedbandwidthattrname(String committedbandwidthattrname)
	{
		setField(COMMITTEDBANDWIDTHATTRNAME,committedbandwidthattrname);
	}

	public String getCommittedbandwidthattrname()
	{
		return getFieldAsString(COMMITTEDBANDWIDTHATTRNAME);
	}

	public void setBehaviour(String behaviour)
	{
		setField(BEHAVIOUR,behaviour);
	}

	public String getBehaviour()
	{
		return getFieldAsString(BEHAVIOUR);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setCircuittype2browserbitmap(String circuittype2browserbitmap)
	{
		setField(CIRCUITTYPE2BROWSERBITMAP,circuittype2browserbitmap);
	}

	public String getCircuittype2browserbitmap()
	{
		return getFieldAsString(CIRCUITTYPE2BROWSERBITMAP);
	}

	public void setCircuittype2graphicsbitmap(String circuittype2graphicsbitmap)
	{
		setField(CIRCUITTYPE2GRAPHICSBITMAP,circuittype2graphicsbitmap);
	}

	public String getCircuittype2graphicsbitmap()
	{
		return getFieldAsString(CIRCUITTYPE2GRAPHICSBITMAP);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setCircuittypeid(String circuittypeid)
	{
		setField(CIRCUITTYPEID,circuittypeid);
	}

	public String getCircuittypeid()
	{
		return getFieldAsString(CIRCUITTYPEID);
	}
}