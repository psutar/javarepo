package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import oracle.sql.ARRAY;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuitDetails;
import com.centurylink.icl.armmediation.armaccessobject.ARMEVCVlan;
import com.centurylink.icl.armmediation.armaccessobject.ARMOrderedNetworkRoleList;
import com.centurylink.icl.armmediation.armaccessobject.MaxNameValue;
import com.centurylink.icl.armmediation.armaccessobject.QosDetails;
import com.centurylink.icl.armmediation.armaccessobject.SearchCircuitDetailsCriteria;
import com.centurylink.icl.armmediation.armaccessobject.VlanDetails;
import com.centurylink.icl.armmediation.dataaccess.SearchCircuitDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager.GetSplitterCapability;
import com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager.PerformGPONLoopQual;
import com.centurylink.icl.armmediation.transformation.SearchCircuitDetailsToCim;
import com.centurylink.icl.armmediation.transformation.SearchCircuitToCim;
import com.centurylink.icl.armmediation.transformation.SearchServiceVOTransformation;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.RouteBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.builder.cim2.TopologicalLinkBuilder;
import com.centurylink.icl.clc.routinggroup.CLCConstants;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.valueobjects.exceptions.ValueObjectDataIntegrityException;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Remarks;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.TopologicalLink;

public class SearchCircuitService
{

	private static final Log LOG = LogFactory.getLog(SearchCircuitService.class);
	private String ND1="ND1";
	private String ND2="ND2";
	private static final String IN_SERVICE="IN SERVICE";
	private static final String CONFIGURED="CONFIGURED";
	private static final String PLANNED="PLANNED";
	private static final String PENDINGACTIVATION="PENDING ACTIVATION";
	private SearchCircuitDAO searchCircuitDAO;
	private JDBCTempleteUtil jdbcTempleteUtil;
	List<RouteBuilder> routeList = null;
	String splitterName = null;
	String fdh = null;
	List<TopologicalLinkBuilder> fdTopologicalList = new ArrayList<TopologicalLinkBuilder>();
	HashMap<String, Object> splitterMap;
	HashMap<String, Object> map;
	private PerformGPONLoopQual performGPONLoopQual;
	private GetSplitterCapability getSplitterCapability;
	private CLCLookupService clcLookupService;
	List<TopologicalLinkBuilder> splitterList = new ArrayList<TopologicalLinkBuilder>();
	private SearchDeviceDAO searchDeviceDAO;
	String query = "SELECT * FROM networkrole nr WHERE nr.networkroleid IN (SELECT nro.networkroleobject2networkrole FROM networkroleobject nro WHERE nro.networkroleobject2object in (SELECT n.nodeid FROM node n WHERE n.name ='";
	String appendQuery = "'))AND upper(nr.alias1) IN (SELECT DISTINCT upper(dc.allowable_role) FROM   device_compatibility dc WHERE upper(dc.technology) = 'GPON')";

	public void setSearchDeviceDAO(SearchDeviceDAO searchDeviceDAO) {
		this.searchDeviceDAO = searchDeviceDAO;
	}

	public void setClcLookupService(CLCLookupService clcLookupService) {
		this.clcLookupService = clcLookupService;
	}

	public void setPerformGPONLoopQual(PerformGPONLoopQual performGPONLoopQual) {
		this.performGPONLoopQual = performGPONLoopQual;
	}
		
	public void setGetSplitterCapability(GetSplitterCapability getSplitterCapability) {
		this.getSplitterCapability = getSplitterCapability;
	}


	public void setSearchCircuitDAO(SearchCircuitDAO searchCircuitDAO)
	{
		this.searchCircuitDAO = searchCircuitDAO;
	}
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public Object searchCircuitSummary(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchCircuitService: GetCircuitSummary");
		}
		final String commonName = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		final String srNumber = MediationUtil.getRcv(request, Constants.SERIAL_NUMBER);
		final String ban = MediationUtil.getRcv(request, Constants.BAN);
		final String customerName = MediationUtil.getRcv(request, Constants.CUSTOMER_NAME);
		final String addressLine1 = MediationUtil.getRcv(request, Constants.ADDRESS_LINE_1);
		final String city = MediationUtil.getRcv(request, "City");
		final String state = MediationUtil.getRcv(request, "State");
		final String zip = MediationUtil.getRcv(request, Constants.ZIP_CODE);
		List<ARMCircuitDetails> armCircuitSummaryList = null;
		List<ARMCircuitDetails> armServiceSummaryList = null;

		if (!StringHelper.isEmpty(ban) || !StringHelper.isEmpty(srNumber))
		{
			armServiceSummaryList = searchCircuitDAO.getServiceList(buildServiceSummaryQuery(null, null, ban, srNumber, null, null, null, null));
			if(armServiceSummaryList!=null && armServiceSummaryList.size()>0)
			{
				SearchCircuitToCim searchCircuitToCim = new SearchCircuitToCim(); 
				final SearchResourceResponseDocument response = searchCircuitToCim.transformCircuitToCim(request, null, armServiceSummaryList);
				if (LOG.isInfoEnabled())
				{
					LOG.info(response.toString());
				}
				return response;
			}
			else
			{
				throw new OSSDataNotFoundException();
			}
		}
		if(!StringHelper.isEmpty(commonName) || !StringHelper.isEmpty(customerName) || !StringHelper.isEmpty(addressLine1))
		{
			armCircuitSummaryList = searchCircuitDAO.getCircuitList(buildCircuitSummaryQuery(commonName, customerName, addressLine1, city, state, zip));
			armServiceSummaryList = searchCircuitDAO.getServiceList(buildServiceSummaryQuery(commonName, customerName, null, null, addressLine1, city, state, zip));
			if((armCircuitSummaryList!=null && armCircuitSummaryList.size()>0) || (armServiceSummaryList!=null && armServiceSummaryList.size()>0))
			{
				SearchCircuitToCim searchCircuitToCim = new SearchCircuitToCim(); 
				final SearchResourceResponseDocument response = searchCircuitToCim.transformCircuitToCim(request, armCircuitSummaryList, armServiceSummaryList);
				if (LOG.isInfoEnabled())
				{
					LOG.info(response.toString());
				}
				return response;
			}
			else
			{
				throw new OSSDataNotFoundException();
			}
		}

		return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_INTERNAL_ERROR, Constants.ICL_REQUEST_VALIDATION_ERROR_DETAIL, request);

	}

	public Object searchCircuitDetails(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchCircuitDetailsService: GetCircuitDetails method");
		}

		final String commonName = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		final String includeRelationship = MediationUtil.getRcv(request, "Include Relationships");
		final String circuitSerialNumber = MediationUtil.getRcv(request, "circuitSerialNumber");
		final String deviceName = MediationUtil.getRcv(request, "deviceName");
		final String circuitID = MediationUtil.getRcv(request, "circuitId");
		final String status = MediationUtil.getRcv(request,Constants.STATUS);
		SearchCircuitDetailsCriteria criteria=new SearchCircuitDetailsCriteria();

		Map<String, Object> transformParms = new HashMap<String, Object>();
		List<ARMCircuitDetails> armCktDetailsList = null;
		List<ARMCircuitDetails> armServiceList = null;
		boolean noCktsFound=false;
		if(!StringHelper.isEmpty(commonName))
			criteria.setCommonName(commonName);
		if(!StringHelper.isEmpty(circuitSerialNumber))
			criteria.setCircuitSerialNumber(circuitSerialNumber);
		if(!StringHelper.isEmpty(deviceName))
			criteria.setDeviceName(deviceName);
		if(!StringHelper.isEmpty(circuitID))
			criteria.setCircuitID(circuitID);
		if(!StringHelper.isEmpty(status))
			criteria.setStatus(status);
		transformParms.put("Request", request);
		if(!StringHelper.isEmpty(commonName))
		{
			List<Service> services = checkHSIService(commonName);
			if (services != null && services.size() > 0) {
				VOSearchHolder searchHolder = new VOSearchHolder();
				HashMap map = new HashMap<String, String>();
				
					map.put("INCLUDECLCCUSTOMER", "True");
					map.put("INCLUDECLCLOCATION", "True");
					map.put("INCLUDERELATIONSHIPS", "True");
				searchHolder.setModifiers(map);

				searchHolder.setCommonName(commonName);
				return SearchServiceVOTransformation.transformToCIM(services,
						searchHolder);
			}
		}
		if(!StringHelper.isEmpty(includeRelationship) && !includeRelationship.equalsIgnoreCase("True") && !includeRelationship.equalsIgnoreCase("False"))
		{
			throw new ICLRequestValidationException("Include Relationships should contain either True or False");
		}
		else if(!StringHelper.isEmpty(includeRelationship) && includeRelationship.equalsIgnoreCase("True"))
		{
			if(!StringHelper.isEmpty(commonName)  || !StringHelper.isEmpty(deviceName)  || !StringHelper.isEmpty(circuitID) || !StringHelper.isEmpty(circuitSerialNumber))
			{

				armCktDetailsList = searchCircuitDAO.getCircuitDetailsListForDSP(buildCircuitDetailsQuery(criteria,includeRelationship));
			}

			if(armCktDetailsList!=null && armCktDetailsList.size()>0)
			{
				return getCktDetails(armCktDetailsList,includeRelationship,request);
			}
			
			else
			{
				noCktsFound=true;
			}
		}
		if(noCktsFound)
		{
			armServiceList = searchCircuitDAO.getServiceDetailsListForDSP(buildServiceDetailsQuery(criteria, includeRelationship));
			return getServiceDetails(armServiceList, includeRelationship, request);
		}

		else if(!StringHelper.isEmpty(includeRelationship) && includeRelationship.equalsIgnoreCase("False")) 
		{
			if(!StringHelper.isEmpty(commonName) || !StringHelper.isEmpty(deviceName)  || !StringHelper.isEmpty(circuitID))
			{
				armCktDetailsList = searchCircuitDAO.getCircuitDetailsListForDSP(buildCircuitDetailsQuery(criteria,includeRelationship));
			}	
				if(armCktDetailsList!=null && armCktDetailsList.size()>0)
				{
					return getCktDetails(armCktDetailsList,includeRelationship,request);
				}
				else
				{
					noCktsFound=true;
				}
			}		
		if(noCktsFound)
		{
			armServiceList = searchCircuitDAO.getServiceDetailsListForDSP(buildServiceDetailsQuery(criteria, includeRelationship));
			return getServiceDetails(armServiceList, includeRelationship, request);
			 
		}
		else
		{
			
			if(!StringHelper.isEmpty(commonName)||!StringHelper.isEmpty(deviceName)||!StringHelper.isEmpty(circuitID))
			{
				armCktDetailsList = searchCircuitDAO.getCircuitDetailsList(buildCircuitDetailsQuery(criteria,includeRelationship));
			}	
				if(armCktDetailsList!=null && armCktDetailsList.size()>0)
				{
					return getCktDetails(armCktDetailsList,includeRelationship,request);
				}
				else
				{
					noCktsFound=true;
				}
			if(noCktsFound)
			{
				armServiceList = searchCircuitDAO.getServiceDetailsList(buildServiceDetailsQuery(criteria, includeRelationship));
				return getServiceDetails(armServiceList, includeRelationship, request);
			}
		}
		return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_INTERNAL_ERROR, Constants.ICL_REQUEST_VALIDATION_ERROR_DETAIL, request);

	}

	private String buildCircuitSummaryQuery(String commonName, String customerName, String addressLine1, String city, String state, String zip)
	{
		SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.STATUS);
		sql.addTable(Constants.EXT_CIRCUIT_ETH_BEARER);
		sql.addTable(Constants.EXT_CIRCUIT_LAG);
		sql.addTable(Constants.LOCATION, "startLoc");
		sql.addTable(Constants.LOCATION, "endLoc");
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNC_STATUS");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.MCO, "ETH_BEARER_MCO");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.MCO, "LAG_MCO");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.addFieldFromTable("startLoc", Constants.NAME, "START_LOC_NAME");
		sql.addFieldFromTable("startLoc", Constants.OBJECT_ID, "START_LOC_OBJECTID");
		sql.addFieldFromTable("startLoc", Constants.PROVINCE, "START_LOC_PROVINCE");
		sql.addFieldFromTable("startLoc", Constants.TOWNCITY, "START_LOC_TOWNCITY");
		sql.addFieldFromTable("startLoc", Constants.ZIP, "START_LOC_ZIP");
		sql.addFieldFromTable("startLoc", Constants.ADDRESS1, "START_LOC_ADDRESS1");
		sql.addFieldFromTable("startLoc", Constants.ADDRESS2, "START_LOC_ADDRESS2");
		sql.addFieldFromTable("startLoc", Constants.ADDRESS3, "START_LOC_ADDRESS3");
		sql.addFieldFromTable("endLoc", Constants.NAME, "END_LOC_NAME");
		sql.addFieldFromTable("endLoc", Constants.OBJECT_ID, "END_LOC_OBJECTID");
		sql.addFieldFromTable("endLoc", Constants.PROVINCE, "END_LOC_PROVINCE");
		sql.addFieldFromTable("endLoc", Constants.TOWNCITY, "END_LOC_TOWNCITY");
		sql.addFieldFromTable("endLoc", Constants.ZIP, "END_LOC_ZIP");
		sql.addFieldFromTable("endLoc", Constants.ADDRESS1, "END_LOC_ADDRESS1");
		sql.addFieldFromTable("endLoc", Constants.ADDRESS2, "END_LOC_ADDRESS2");
		sql.addFieldFromTable("endLoc", Constants.ADDRESS3, "END_LOC_ADDRESS3");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME,Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.EXCEPTION_HANDLING_INFO, "ETH_EXCEPTION_INFO");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.EXCEPTION_HANDLING_INFO, "LAG_EXCEPTION_INFO");
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, Constants.STATUS, Constants.STATUS_ID);
		sql.eq("startLoc", Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_START_LOCATION);
		sql.eq("endLoc", Constants.LOCATION_ID, Constants.CIRCUIT, Constants.CIRCUIT_2_END_LOCATION);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_LAG, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
		if(!StringHelper.isEmpty(commonName))
		{
			String [] table = {Constants.CIRCUIT,Constants.CIRCUIT,Constants.CIRCUIT};
			String [] column = {Constants.NAME,"ALIAS1","ALIAS2"};
			String [] value = {commonName,commonName,commonName};
			if(commonName.contains("%"))
				sql.orClausesLikeCase(table, column, value);		
			else
				sql.orClausesUpperCase(table, column, value);
		}
		if(!StringHelper.isEmpty(customerName))
			if(customerName.contains("%"))
				sql.like(Constants.CIRCUIT, Constants.RELATIVE_NAME, customerName);	
			else
				sql.eqUpperCase(Constants.CIRCUIT, Constants.RELATIVE_NAME, customerName);

		
		if(!StringHelper.isEmpty(addressLine1))
		{
			if(!StringHelper.isEmpty(city))
				city=city.toUpperCase();
			if(!StringHelper.isEmpty(state))
				state=state.toUpperCase();
			if(!StringHelper.isEmpty(zip))
				zip=zip.toUpperCase();
			String [] tablesBeforeOr={"startLoc", "startLoc", "startLoc", "startLoc"};
			String [] columnsBeforeOr={Constants.ADDRESS1,Constants.TOWNCITY,Constants.PROVINCE, Constants.ZIP};
			String [] valuesBeforeOr={addressLine1.toUpperCase(), city, state, zip};		
			String [] tablesAfterOr={"endLoc", "endLoc", "endLoc", "endLoc"};
			String [] columnsAfterOr={Constants.ADDRESS1,Constants.TOWNCITY,Constants.PROVINCE, Constants.ZIP};
			String [] valuesAfterOr={addressLine1.toUpperCase(), city, state, zip};
			sql.orCriterias(sql.andClausesUpperCase(tablesBeforeOr, columnsBeforeOr, valuesBeforeOr), sql.andClausesUpperCase(tablesAfterOr, columnsAfterOr, valuesAfterOr));
		}

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildCircuitSummaryQuery :" + query);

		}
		System.out.println("buildCircuitSummaryQuery :" + query);
		return query;
	}

	private String buildServiceSummaryQuery(String commonName, String subscriberName, String ban, String srNumber, String addressLine1, String city, String state, String zip)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.STATUS);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addTable(Constants.PORT);
		sql.addTable(Constants.NODE);
		sql.addTable(Constants.LOCATION);
		sql.addTable(Constants.EXT_MEF_UNI);
		sql.addTable(Constants.EXT_MEF_ENNI);
		sql.addTable(Constants.EXT_MEF_EVC);
		sql.addTable(Constants.EXT_MEF_OVC);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPE_NAME");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.MCO, "UNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.MCO, "ENNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.MCO, "EVC_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.MCO, "OVC_MCO");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME,Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNC_STATUS");
		sql.addFieldFromTable(Constants.LOCATION, Constants.NAME, "LOCATION_NAME");
		sql.addFieldFromTable(Constants.LOCATION, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.LOCATION, Constants.PROVINCE);
		sql.addFieldFromTable(Constants.LOCATION, Constants.TOWNCITY);
		sql.addFieldFromTable(Constants.LOCATION, Constants.ZIP);
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS1);
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS2);
		sql.addFieldFromTable(Constants.LOCATION, Constants.ADDRESS3);
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.EXCEPTION_HANDLING_INFO, "UNI_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.EXCEPTION_HANDLING_INFO, "ENNI_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EXCEPTION_HANDLING_INFO, "EVC_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EXCEPTION_HANDLING_INFO, "OVC_EXCEPTION_HANDLING_INFO");
		sql.addField("(SELECT CUSTACCTBAN from  EXT_MEF_UNI where serviceID = SERVICE.SERVICEID)", "UNIBAN");
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.STATUS, Constants.STATUS_ID, Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER, Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_LOCATION, Constants.LOCATION, Constants.LOCATION_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_UNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_ENNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_EVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_OVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
		sql.joinFO(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT, Constants.PORT, Constants.PORT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_2_NODE, Constants.NODE, Constants.NODE_ID);
		
		if(!StringHelper.isEmpty(commonName))
		{
			String [] table = {Constants.SERVICE,Constants.SERVICE,Constants.SERVICE};
			String [] column = {Constants.NAME,"ALIAS1","ALIAS2"};
			String [] value = {commonName,commonName,commonName};
			
			if(commonName.contains("%"))
				sql.orClausesLikeCase(table, column, value);
			else
				sql.orClausesUpperCase(table, column, value);

		}

		if(!StringHelper.isEmpty(subscriberName))
			if(subscriberName.contains("%"))
				sql.like(Constants.SERVICE, Constants.RELATIVE_NAME, subscriberName);	
			else
				sql.eqUpperCase(Constants.SERVICE, Constants.RELATIVE_NAME, subscriberName);
		
		if(!StringHelper.isEmpty(srNumber))
		{
			sql.addFieldFromTable(Constants.EXT_MEF_UNI,Constants.CIRCUITSERIALNUMBER, "uni_cir_sr_no" );
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.CIRCUITSERIALNUMBER, "enni_cir_sr_no" );
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.CIRCUITSERIALNUMBER, "evc_cir_sr_no" );
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.CIRCUITSERIALNUMBER, "ovc_cir_sr_no" );
			sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_UNI,Constants.SERVICE_ID);
			sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_ENNI,Constants.SERVICE_ID);
			sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_EVC,Constants.SERVICE_ID);
			sql.joinFO(Constants.SERVICE,Constants.SERVICE_ID,Constants.EXT_MEF_OVC,Constants.SERVICE_ID);
			String [] tables={Constants.EXT_MEF_UNI,Constants.EXT_MEF_EVC,Constants.EXT_MEF_OVC, Constants.EXT_MEF_ENNI};
			String [] columns={Constants.CIRCUITSERIALNUMBER,Constants.CIRCUITSERIALNUMBER,Constants.CIRCUITSERIALNUMBER, Constants.CIRCUITSERIALNUMBER};
			String [] values={srNumber,srNumber,srNumber,srNumber};
			sql.orClausesUpperCase(tables,columns,values);
		}
		if(!StringHelper.isEmpty(addressLine1) || !StringHelper.isEmpty(city) || !StringHelper.isEmpty(state) || !StringHelper.isEmpty(zip))
		{

			if(!StringHelper.isEmpty(addressLine1))
				sql.eqUpperCase(Constants.LOCATION, Constants.ADDRESS1, addressLine1);
			if(!StringHelper.isEmpty(city))
				sql.eqUpperCase(Constants.LOCATION, Constants.TOWNCITY, city);
			if(!StringHelper.isEmpty(state))
				sql.eqUpperCase(Constants.LOCATION, Constants.PROVINCE, state);
			if(!StringHelper.isEmpty(zip))
				sql.eqUpperCase(Constants.LOCATION, Constants.ZIP, zip);
		}
		if(!StringHelper.isEmpty(ban))
		{
			sql.eqUpperCase(Constants.EXT_MEF_UNI, "CUSTACCTBAN", ban);
		}

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildServiceSummaryQuery :" + query);
		}
		System.out.println("buildServiceSummaryQuery :" + query);
		return query;
	}


	private String buildCircuitDetailsQuery(SearchCircuitDetailsCriteria criteria,String includeRelationship)
	{
		SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.EXT_CIRCUIT_ETH_BEARER);
		sql.addTable(Constants.EXT_CIRCUIT_LAG);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.PORT,"PortA");
		sql.addTable(Constants.PORT,"PortZ");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT, "BANDWIDTH");
		sql.addFieldFromTable(Constants.SUBSCRIBER, "SUBSCRIBERID");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addCase("PortA", Constants.PARENT_PORT_2_PORT, Constants.CIRCUIT, Constants.CIRCUIT_2_START_PORT, Constants.CIRCUIT_2_START_PORT);
		sql.addCase("PortZ", Constants.PARENT_PORT_2_PORT, Constants.CIRCUIT, Constants.CIRCUIT_2_END_PORT, Constants.CIRCUIT_2_END_PORT);
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUITSERVICETYPE);
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.MCO, "ETH_BEARER_MCO");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.MCO, "LAG_MCO");
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, "PROVISIONSTATUS");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.IS_DIVERSE, "NMI_IS_DIVERSE");	
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.IS_DIVERSE, "LAG_IS_DIVERSE");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.EXCEPTION_HANDLING_INFO, "LAG_EXCEPTION_INFO");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.EXCEPTION_HANDLING_INFO, "ETH_EXCEPTION_INFO");
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS,Constants.PROVISION_STATUS,"PROVISIONSTATUSID");
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_START_PORT,"PortA",Constants.PORT_ID);
		sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_END_PORT,"PortZ",Constants.PORT_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_LAG, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);

		if(null != includeRelationship && (includeRelationship.equalsIgnoreCase("True") || includeRelationship.equalsIgnoreCase("False")))
		{
			//sql.addTable(Constants.PROVISION_STATUS);
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNCTIONALSTATUS");
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.TSP);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.BW, "NMI_BW");
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.IS_LAG_MEMBER);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.DIVERSE_CIRCUIT_ID, "NMI_DIVERSE_CKT_ID");
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.L1_TECHNOLOGY);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.PROTECTION_TYPE);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.LAG_NUMBER);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.AGGREGATION_PROTOCOL);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.HASHING);
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.BW, "LAG_BW");
			sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.DIVERSE_CIRCUIT_ID, "LAG_DIVERSE_CKT_ID");
			sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
			sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
		}


		if(!StringHelper.isEmpty(criteria.getCommonName()))
		{
			String [] table = {Constants.CIRCUIT,Constants.CIRCUIT,Constants.CIRCUIT};
			String [] column = {Constants.NAME,"ALIAS1","ALIAS2"};
			String [] value = {criteria.getCommonName(),criteria.getCommonName(),criteria.getCommonName()};
			
			if(criteria.getCommonName().contains("%"))
				sql.orClausesLikeCase(table, column, value);
			else
				sql.orClausesUpperCase(table, column, value);

		}
		if(!StringHelper.isEmpty(criteria.getCircuitSerialNumber())) {
			String [] table = {Constants.EXT_CIRCUIT_ETH_BEARER,Constants.EXT_CIRCUIT_LAG};
			String [] column = {"CIRCUITSERIALNUMBER","CIRCUITSERIALNUMBER"};
			String [] value = {criteria.getCircuitSerialNumber(),criteria.getCircuitSerialNumber()};
			sql.orClauses(table, column, value);
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
		{
			sql.addTable(Constants.NODE,"NODE");
			sql.addFieldFromTable("NODE", Constants.NODE_ID);
			sql.addFieldFromTable("NODE", Constants.NAME);
			sql.eqUpperCase("NODE", Constants.NAME, criteria.getDeviceName());
			//sql.orUpperCase("NODE", Constants.NODE_ID, ND1,Constants.NODE_ID,);
			String [] table = {ND1,ND2};
			String [] value = {criteria.getDeviceName(),criteria.getDeviceName()};
			String [] column = {Constants.NAME,Constants.NAME};
			sql.orClausesUpperCase(table, column,value);
			String [] idColumn = {Constants.NODE_ID,Constants.NODE_ID,Constants.NODE_ID};
			String [] tableforIDs = {ND1,ND2,"NODE"};
			sql.orClauseTables(tableforIDs,idColumn);
			
					
		}
		if(!StringHelper.isEmpty(criteria.getCircuitID()))
			sql.eqUpperCase(Constants.CIRCUIT, Constants.CIRCUIT_ID, criteria.getCircuitID());

		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			List<String> parameterList =new ArrayList<String>();
			parameterList.add(IN_SERVICE);
			parameterList.add(CONFIGURED);
			parameterList.add(PLANNED);
			parameterList.add(PENDINGACTIVATION);
			if(criteria.getStatus().equalsIgnoreCase("active"))
				sql.inUpper(Constants.PROVISION_STATUS, Constants.NAME, parameterList);
			else
				sql.notIn(Constants.PROVISION_STATUS, Constants.NAME, parameterList);
		}

		String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("buildCircuitDetailsQuery :" + query);
		}

		System.out.println("buildCircuitDetailsQuery :" + query);
		return query;
	}


	private String buildNodeDetailsQuery(String portId)
	{
		SQLBuilder sql = new SQLBuilder(Constants.STATUS);
		sql.addTable(Constants.NODE);
		sql.addTable(Constants.EXT_DEVICE_TYPE);
		sql.addTable(Constants.NODE_TYPE);
		sql.addTable(Constants.PORT);
		sql.addTable(Constants.PORTTYPE);
		sql.addTable(Constants.SHELF);
		sql.addTable(Constants.CARD);
		sql.addTable(Constants.SLOT);
		sql.addTable(Constants.EXT_PORT_TABLE);
		sql.addTable(Constants.EXT_PORT_PLUGGABLE);
		sql.addTable(Constants.LOCATION);
		sql.addTable(Constants.NODEDEF);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addTable(Constants.BANDWIDTH);
		sql.addTable(Constants.TT_SERVICETYPE_TRANSLATION);
		sql.addTable(Constants.NETWORKROLE);
		sql.addTable(Constants.NETWORKROLEOBJECT);
		sql.addFieldFromTable(Constants.TT_SERVICETYPE_TRANSLATION, Constants.TT_SERVICE_TYPE);
		sql.addFieldFromTable(Constants.NODE, Constants.NODE_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.NAME);
		sql.addFieldFromTable(Constants.NODE, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.RELATIVE_NAME);
		sql.addFieldFromTable(Constants.NODE, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.NODE, Constants.STORAGE_RAM);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.CLLI);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.VENDOR_NAME);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.MCO);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.PART_TYPE);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V4_MGM_ROUTER_ID, "IPADDRESS");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.IP_V6_MGM_ROUTERID, "IPADDRESS_1");
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.RELAY_RACK_ID);
		sql.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.NODE_TYPE, Constants.NAME, "NODETYPE");
		sql.addFieldFromTable(Constants.NODE_DEF,Constants.NAME,"NODEDEFNAME");
		sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNCTIONAL_STATUS");
		sql.addFieldFromTable(Constants.SHELF, Constants.NAME, "SHELFNAME");
		sql.addFieldFromTable(Constants.SHELF, Constants.SHELF_ID);
		sql.addFieldFromTable(Constants.SHELF, Constants.SHELFNUMBER);
		sql.addFieldFromTable(Constants.SHELF, Constants.ALIAS_1, "LogicalSHELFNAME");
		sql.addFieldFromTable(Constants.SLOT, Constants.NAME, "SLOTNAME");
		sql.addFieldFromTable(Constants.SLOT, Constants.SLOT_ID);
		sql.addFieldFromTable(Constants.SLOT, Constants.SLOT_NUMBER);
		sql.addFieldFromTable(Constants.CARD, Constants.NAME, "CARDNAME");
		sql.addFieldFromTable(Constants.CARD, Constants.CARD_ID);
		sql.addFieldFromTable(Constants.PORT, Constants.NAME, "PORTNAME");
		sql.addFieldFromTable(Constants.PORT, Constants.PORT_ID);
		sql.addFieldFromTable(Constants.PORT, Constants.PORTNUMBER);
		sql.addFieldFromTable(Constants.PORT, Constants.ALIAS_1, "LEGACYPORTNAME");
		sql.addFieldFromTable(Constants.PORT, Constants.PORT2BANDWIDTH);
		sql.addFieldFromTable(Constants.BANDWIDTH, Constants.NAME, "BANDWIDTH_NAME");
		sql.addFieldFromTable(Constants.EXT_PORT_TABLE, Constants.IF_NAME);
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.IF_NAME, "PLUGGABLE_IF_NAME");		
		sql.addConcatenatedFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.BANDWIDTH, Constants.EXT_PORT_PLUGGABLE, Constants.FORM_FACTOR, "PLUGGABLE_TRANSMISSIONRATE");
		sql.addFieldFromTable(Constants.PORTTYPE, Constants.NAME,"PORTTYPE");
		sql.addFieldFromTable(Constants.EXT_PORT_TABLE, Constants.DPEA);
		sql.addFieldFromTable(Constants.EXT_PORT_TABLE, Constants.IFNUM);
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.IFNUM, "PLUGGABLEIFNUM");
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.DPEA, "DPEA_1");
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.PORT_FUNCTION);
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.PLUGGABLE_TYPE);
		sql.addFieldFromTable(Constants.LOCATION, Constants.NAME, "LOCATION_NAME");
		sql.addFieldFromTable(Constants.NETWORKROLE, Constants.ALIAS_1, "ROLE");
		sql.eq(Constants.NODE, Constants.NODE_ID, Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sql.eq(Constants.NODE, Constants.NODE_2_NODE_TYPE, Constants.NODE_TYPE, Constants.NODE_TYPE_ID);
		sql.eq(Constants.STATUS, Constants.STATUS_ID, Constants.NODE, Constants.NODE_2_PROVISION_STATUS);
		sql.joinFO(Constants.NODE, Constants.NODE_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
		sql.eq(Constants.NODE, Constants.NODE_ID, Constants.PORT, Constants.PORT_2_NODE);
		sql.eq(Constants.NODE_DEF,Constants.NODE_DEF_ID,Constants.NODE,Constants.NODE_2_NODE_DEF);
		sql.joinFO(Constants.SLOT, Constants.SLOT_2_SHELF, Constants.SHELF, Constants.SHELF_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_2_CARD, Constants.CARD, Constants.CARD_ID);
		sql.joinFO(Constants.CARD, Constants.CARD_2_SHELF_SLOT, Constants.SLOT, Constants.SLOT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_ID, Constants.EXT_PORT_TABLE, Constants.PORT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_ID, Constants.EXT_PORT_PLUGGABLE, Constants.PORT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT2BANDWIDTH, Constants.BANDWIDTH, Constants.BANDWIDTH_ID);
		sql.joinFO(Constants.NODEDEF, Constants.NODE_DEF_ID, Constants.TT_SERVICETYPE_TRANSLATION, Constants.ARM_OBJECT_ID);
		sql.joinFO(Constants.NODE, "NODEID", Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2OBJECT");
		sql.joinFO(Constants.NETWORKROLEOBJECT, "NETWORKROLEOBJECT2NETWORKROLE", Constants.NETWORKROLE, "NETWORKROLEID");
		sql.eq(Constants.PORT, Constants.PORT_2_LOCATION, Constants.LOCATION, Constants.LOCATION_ID);
		sql.eq(Constants.PORT,Constants.PORT_2_PORTTYPE , Constants.PORTTYPE, Constants.PORTTYPEID);
		sql.eq(Constants.PORT, Constants.PORT_ID, portId);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildNodeDetailsQuery :" + query);
		}
		//System.out.println("buildNodeDetailsQuery :" + query);
		return query;
	}

	private String buildServiceDetailsQuery(SearchCircuitDetailsCriteria criteria,String includeRelationship)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.PORT);
		sql.addTable(Constants.NODE);
		//sql.addTable(Constants.STATUS);
		sql.addTable(Constants.EXT_MEF_UNI);
		sql.addTable(Constants.EXT_MEF_ENNI);
		sql.addTable(Constants.EXT_MEF_EVC);
		sql.addTable(Constants.EXT_MEF_OVC);
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS1");
		sql.addFieldFromTable(Constants.SERVICE, "ALIAS2");
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPENAME");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.MCO, "UNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.MCO, "ENNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.MCO, "EVC_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.MCO, "OVC_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPCEXPIRATIONDATE, "UNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPC, "UNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI,Constants.TSP,"UNI_TSP");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPCEXPIRATIONDATE, "ENNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPC, "ENNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI,Constants.TSP,"ENNI_TSP" );
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPCEXPIRATIONDATE, "EVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPC, "EVC_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPCEXPIRATIONDATE, "OVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPC, "OVC_HPC");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME,Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, "FIRSTNAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, "TITLE");
		//sql.addFieldFromTable(Constants.STATUS, Constants.NAME, "STATUS");
		sql.addFieldFromTable(Constants.PORT, Constants.PORT_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.NODE_ID);
		sql.addFieldFromTable(Constants.NODE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER);
		sql.addFieldFromTable(Constants.NODE, Constants.RELATIVE_NAME);
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, "PROVISIONSTATUS");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.IS_DIVERSE, "UNI_IS_DIVERSE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.DIVERSE_UNI_ID);
		sql.addField("(SELECT CUSTACCTBAN from  EXT_MEF_UNI where SERVICEID = SERVICE.SERVICEID)", "UNIBAN");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EXCEPTION_HANDLING_INFO, "OVC_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EXCEPTION_HANDLING_INFO, "EVC_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.EXCEPTION_HANDLING_INFO, "UNI_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.EXCEPTION_HANDLING_INFO,"ENNI_EXCEPTION_HANDLING_INFO");
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER, Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		//sql.eq(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS,Constants.STATUS, Constants.STATUS_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE);
		sql.joinFO(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT, Constants.PORT, Constants.PORT_ID);		
		
		sql.joinFO(Constants.PORT, Constants.PORT_2_NODE, Constants.NODE, Constants.NODE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_UNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_ENNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_EVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_OVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS,Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
		if(null != includeRelationship && (includeRelationship.equalsIgnoreCase("True") || includeRelationship.equalsIgnoreCase("False")))
		{
			sql.addTable(Constants.FUNCTIONAL_STATUS);
			sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNCTIONALSTATUS");
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SERVICE_MUX);
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.BUNDLING);
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.ALL_TO_1_BUNDLING);
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.CUSTOMER_SERIAL_NUMBER);
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SPEC_CODE, "UNI_SPECCODE");
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NC_CODE, "UNI_NCCODE");
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NCI_CODE, "UNI_NCICODE");
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SEC_NCI_CODE);
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.BW, "UNI_BW");
			sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.CIRCUITSERIALNUMBER, "UNI_CktSrNo");
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.FRAME_FORMAT);
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SPEC_CODE, "ENNI_SPECCODE");
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NC_CODE, "ENNI_NCCODE");
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NCI_CODE, "ENNI_NCICODE");
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.BW, "ENNI_BW");
			sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.CIRCUITSERIALNUMBER, "ENNI_CktSrNo");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EVC_MTU);
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.CE_VLAN_ID_PRESERVATION, "EVC_CEVLANIDPRESERVATION");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.CE_VLAN_COS_PRESERVATION, "EVC_CEVLANCOSPRESERVATION");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.UNICAST_FRAME_DELIVERY, "EVC_UNICASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.MULTICAST_FRAME_DELIVERY, "EVC_MULTICASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.BROADCAST_FRAME_DELIVERY, "EVC_BROADCASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EVC_OVC_NC, "EVC_EVCOVCNC");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.SERVICE_SUB_TYPE, "EVC_SERVICESUBTYPE");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.MCO, "EVC_MCO");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.COS_ID, "EVC_COS_ID");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.CIRCUITSERIALNUMBER, "EVC_CktSrNo");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.LOS_NAME, "EVC_LOS_NAME");
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.COS_VALUE, "EVC_COS_VALUE");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.OVC_MTU);
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.CE_VLAN_ID_PRESERVATION, "OVC_CEVLANIDPRESERVATION");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.CE_VLAN_COS_PRESERVATION, "OVC_CEVLANCOSPRESERVATION");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.S_VLAN_ID_PRESERVATION);
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.S_VLAN_COS_PRESERVATION);
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.COLOR_FORWARDING);
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.UNICAST_FRAME_DELIVERY, "OVC_UNICASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.MULTICAST_FRAME_DELIVERY, "OVC_MULTICASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.BROADCAST_FRAME_DELIVERY, "OVC_BROADCASTFRAMEDELIVERY");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EVC_OVC_NC, "OVC_EVCOVCNC");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.SERVICE_SUB_TYPE, "OVC_SERVICESUBTYPE");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EVC_OVC_REFERENCE);
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.MCO, "OVC_MCO");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.COS_ID, "OVC_COS_ID");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.LOS_NAME, "OVC_LOS_NAME");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.COS_VALUE, "OVC_COS_VALUE");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.CIRCUITSERIALNUMBER, "OVC_CktSrNo");
			sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.ASN,Constants.OVC_ASN);
			//sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.VPNID,Constants.OVC_VPNID);
			sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.ASN,Constants.EVC_ASN);
			//sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.VPNID,Constants.EVC_VPNID);
			sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS,Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);;
		}

		if(!StringHelper.isEmpty(criteria.getCommonName()))
		{
			String [] table = {Constants.SERVICE,Constants.SERVICE,Constants.SERVICE};
			String [] column = {Constants.NAME,"ALIAS1","ALIAS2"};
			String [] value = {criteria.getCommonName(),criteria.getCommonName(),criteria.getCommonName()};
						
			if(criteria.getCommonName().contains("%"))
				sql.orClausesLikeCase(table, column, value);
			else
				sql.orClausesUpperCase(table, column, value);

		}
		if(!StringHelper.isEmpty(criteria.getCircuitSerialNumber())) {
			String [] table = {Constants.EXT_MEF_UNI,Constants.EXT_MEF_EVC,Constants.EXT_MEF_ENNI,Constants.EXT_MEF_OVC};
			String [] column = {"CIRCUITSERIALNUMBER","CIRCUITSERIALNUMBER","CIRCUITSERIALNUMBER","CIRCUITSERIALNUMBER"};
			String [] value = {criteria.getCircuitSerialNumber(),criteria.getCircuitSerialNumber(),criteria.getCircuitSerialNumber(),criteria.getCircuitSerialNumber()};
			sql.orClauses(table, column, value);
		}
		if(!StringHelper.isEmpty(criteria.getDeviceName()))
		{
			sql.eqUpperCase(Constants.NODE, Constants.NAME, criteria.getDeviceName());
			sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");			
		}else 
		{
			sql.orWithIsNull(Constants.SERVICE_OBJECT,Constants.SERVICE_OBJECT_2_DIM_OBJECT,"4",Constants.SERVICE_OBJECT,Constants.SERVICE_OBJECT_2_DIM_OBJECT);
		}
		if(StringHelper.isEmpty(criteria.getCommonName()) && StringHelper.isEmpty(criteria.getCircuitSerialNumber()) && StringHelper.isEmpty(criteria.getDeviceName()))
		{    
			throw new OSSDataNotFoundException();
		}
		if(!StringHelper.isEmpty(criteria.getStatus()))
		{
			List<String> parameterList =new ArrayList<String>();
			parameterList.add(IN_SERVICE);
			parameterList.add(CONFIGURED);
			parameterList.add(PLANNED);
			parameterList.add(PENDINGACTIVATION);
			if(criteria.getStatus().equalsIgnoreCase("active"))
				sql.inUpper(Constants.PROVISION_STATUS, Constants.NAME, parameterList);
			else 
				sql.notIn(Constants.PROVISION_STATUS, Constants.NAME, parameterList);
		}
		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildServiceDetailsQuery :" + query);
		}
		System.out.println("buildServiceDetailsQuery :" + query);
		return query;
	}

	private String buildRelatedServiceQueryForNMILAG(String circuitID)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addTable(Constants.SERVICE_TYPE);	
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addTable(Constants.EXT_MEF_UNI);
		sql.addTable(Constants.EXT_MEF_ENNI);
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SERVICE_ID, "UNI_SERVICEID");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SPEC_CODE, "UNI_SPECCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NC_CODE, "UNI_NCCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NCI_CODE, "UNI_NCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SEC_NCI_CODE, "UNI_SECNCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.BW, "UNI_BW");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.MCO, "UNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SERVICE_ID, "ENNI_SERVICEID");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SPEC_CODE, "ENNI_SPECCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NC_CODE, "ENNI_NCCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NCI_CODE, "ENNI_NCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SEC_NCI_CODE, "ENNI_SECNCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.BW, "ENNI_BW");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.MCO, "ENNI_MCO");
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, Constants.PROVISION_STATUS);
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME,Constants.FUNCTIONAL_STATUS);
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.EXCEPTION_HANDLING_INFO, "UNI_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.EXCEPTION_HANDLING_INFO, "ENNI_EXCEPTION_HANDLING_INFO");
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS,Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "3");
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS,Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);	
		sql.joinFO(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_UNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_ENNI, Constants.SERVICE_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT, circuitID);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildRelatedServiceQueryForNMILAG :" + query);
		}
		System.out.println("buildRelatedServiceQueryForNMILAG :" + query);
		return query;
	}

	private String buildRelatedCktForUNIENNIQuery(String serviceId)
	{
		SQLBuilder sql =  new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.EXT_CIRCUIT_ETH_BEARER);
		sql.addTable(Constants.EXT_CIRCUIT_LAG);
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE");
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, "PROVISIONSTATUS");
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME, "FUNCTIONALSTATUS");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.BW, "NMI_BW");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUITSERVICETYPE);
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.BW, "LAG_BW");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_ETH_BEARER, Constants.EXCEPTION_HANDLING_INFO,"ETH_EXCEPTION_INFO");
		sql.addFieldFromTable(Constants.EXT_CIRCUIT_LAG, Constants.EXCEPTION_HANDLING_INFO, "LAG_EXCEPTION_INFO");
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "3");
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_2_FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_ETH_BEARER, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.CIRCUIT_ID, Constants.EXT_CIRCUIT_LAG, Constants.CIRCUIT_ID);
		sql.joinFO(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT,Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.eqUpperCase(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE, serviceId);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildRelatedCktForUNIENNIQuery :" + query);
		}
		//System.out.println("buildRelatedCktForUNIENNIQuery :" + query);
		return query;
	}
	private String buildRelatedServiceForUNIENNIQuery(String serviceId)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addTable(Constants.EXT_MEF_EVC);
		sql.addTable(Constants.EXT_MEF_OVC);
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addTable(Constants.PORT,"VLAN_PORT");
		sql.addTable(Constants.PORT,"EB_PORT");
		sql.addTable(Constants.PORT,"UNI_PORT");	
		sql.addTable(Constants.SERVICE_OBJECT,"EVC_SO");
		sql.addTable(Constants.SERVICE_OBJECT,"UNI_SO");
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPE");
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, Constants.PROVISION_STATUS);
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME,Constants.FUNCTIONAL_STATUS);
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.SERVICE_SUB_TYPE, "EVC_SERVICESUBTYPE");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EVC_OVC_NC, "EVC_NC");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.MCO, "EVC_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.SERVICE_SUB_TYPE, "OVC_SERVICESUBTYPE");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EVC_OVC_NC, "OVC_NC");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.MCO, "OVC_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPCEXPIRATIONDATE, "EVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.HPC, "EVC_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPCEXPIRATIONDATE, "OVC_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.HPC, "OVC_HPC");
		sql.addFieldFromTable("VLAN_PORT", Constants.PORT_ID, "VLAN_PORTID");
		//sql.addFieldFromTable(Constants.EXT_MEF_OVC,Constants.VPNID,Constants.OVC_VPNID);
		sql.addFieldFromTable(Constants.EXT_MEF_OVC,Constants.ASN,Constants.OVC_ASN);
		sql.addFieldFromTable(Constants.EXT_MEF_OVC, Constants.EXCEPTION_HANDLING_INFO, "OVC_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC, Constants.EXCEPTION_HANDLING_INFO, "EVC_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_EVC,Constants.ASN,Constants.EVC_ASN);
		//sql.addFieldFromTable(Constants.EXT_MEF_EVC,Constants.VPNID,Constants.EVC_VPNID);		
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS,Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS,Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);	
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_EVC, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_OVC, Constants.SERVICE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID,"EVC_SO",Constants.SERVICE_OBJECT_2_SERVICE);
		sql.joinFO("EVC_SO", Constants.SERVICE_OBJECT_2_OBJECT, "VLAN_PORT",Constants.PORT_ID);
		sql.joinFOValue("EVC_SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
		sql.joinFOValue("VLAN_PORT", Constants.PORT_2_PORTTYPE,"150020005");
		sql.joinFO("UNI_SO", Constants.SERVICE_OBJECT_2_SERVICE, Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT);
		sql.joinFO("UNI_PORT", Constants.PORT_ID, "UNI_SO", Constants.SERVICE_OBJECT_2_OBJECT);
		sql.eq("UNI_SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT ,"4");
		sql.joinFO("EB_PORT",Constants.PARENT_PORT_2_PORT,"UNI_PORT",Constants.PORT_ID);
		sql.eq("EB_PORT",Constants.PORT_2_PORTTYPE,"150020001");
		sql.eq("VLAN_PORT",Constants.PARENT_PORT_2_PORT,"EB_PORT",Constants.PORT_ID);
        sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "8");
		sql.eqUpperCase(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT, serviceId);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
		 	LOG.info("buildRelatedServiceForUNIENNIQuery :" + query);
		}
		//System.out.println("buildRelatedServiceForUNIENNIQuery :" +query);
		return query;
	}

	private String buildRelatedServiceForEVCOVCQuery(String serviceId)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_TYPE);
		sql.addTable(Constants.SERVICE_OBJECT);
		sql.addTable(Constants.SERVICE_OBJECT,"UNI_SO");
		sql.addTable(Constants.EXT_MEF_UNI);
		sql.addTable(Constants.EXT_MEF_ENNI);
		sql.addTable(Constants.PROVISION_STATUS);
		sql.addTable(Constants.FUNCTIONAL_STATUS);
		sql.addTable(Constants.PORT);
		sql.addFieldFromTable(Constants.SERVICE, Constants.NAME);
		sql.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, "SERVICETYPE");
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SERVICE, Constants.OBJECT_ID);
		sql.addFieldFromTable(Constants.PROVISION_STATUS, Constants.NAME, Constants.PROVISION_STATUS);
		sql.addFieldFromTable(Constants.FUNCTIONAL_STATUS, Constants.NAME,Constants.FUNCTIONAL_STATUS);
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SPEC_CODE, "UNI_SPECCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NC_CODE, "UNI_NCCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.NCI_CODE, "UNI_NCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.SEC_NCI_CODE, "UNI_SECNCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.BW, "UNI_BW");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.MCO, "UNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPCEXPIRATIONDATE, "UNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.HPC, "UNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_UNI,Constants.TSP,"UNI_TSP" );
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SPEC_CODE, "ENNI_SPECCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NC_CODE, "ENNI_NCCODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.NCI_CODE, "ENNI_NCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.SEC_NCI_CODE, "ENNI_SECNCICODE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.BW, "ENNI_BW");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.MCO, "ENNI_MCO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPCEXPIRATIONDATE, "ENNI_EPI_DATE");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI, Constants.HPC, "ENNI_HPC");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI,Constants.TSP,"ENNI_TSP" );
		sql.addFieldFromTable(Constants.EXT_MEF_UNI, Constants.EXCEPTION_HANDLING_INFO, "UNI_EXCEPTION_HANDLING_INFO");
		sql.addFieldFromTable(Constants.EXT_MEF_ENNI,Constants.EXCEPTION_HANDLING_INFO,"ENNI_EXCEPTION_HANDLING_INFO" );
		sql.addFieldFromTable(Constants.PORT,Constants.PORT_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE, Constants.SERVICE_TYPE, Constants.SERVICE_TYPE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_PROVISION_STATUS,Constants.PROVISION_STATUS, Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "8");
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_2_FUNCTIONAL_STATUS,Constants.FUNCTIONAL_STATUS, Constants.FUNCTIONAL_STATUS_ID);	
		sql.joinFO(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT,Constants.SERVICE, Constants.SERVICE_ID);
		sql.joinFO("UNI_SO",Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT);
		sql.joinFO("UNI_SO",Constants.SERVICE_OBJECT_2_OBJECT,Constants.PORT, Constants.PORT_ID);
		sql.eq("UNI_SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_UNI, Constants.SERVICE_ID);
		sql.joinFO(Constants.SERVICE, Constants.SERVICE_ID, Constants.EXT_MEF_ENNI, Constants.SERVICE_ID);
		sql.eqUpperCase(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE, serviceId);
		
		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildRelatedServiceForEVCOVCQuery :" + query);
		}
		System.out.println("buildRelatedServiceForEVCOVCQuery :" + query);
		return query;
	}

	private String buildQosQuery(List<String> portIdList, String serviceID)
	{
		SQLBuilder sql = new SQLBuilder(Constants.PARAMETER_SET);
		sql.addTable(Constants.PARAMETER_SET_VERSION);
		sql.addTable(Constants.PARAMETER_INSTANCE);
		sql.addTable(Constants.PARAMETER_DEFINITION);
		sql.addTable(Constants.PARAMETER_INSTANCE_VALUE);
		//sql.addTable(Constants.SERVICE_OBJECT,"EVC_SO");
		sql.addFieldFromTable(Constants.PARAMETER_DEFINITION, Constants.NAME, "PARAMETERDEFINITION");
		String[] decodeValues = {"0","1","2","3"};
		String[] types = {"Class A", "Class B", "Class C", "Class D"};
		sql.decode(Constants.PARAMETER_INSTANCE_VALUE, Constants.COMPOSITE_SEQUENCE, decodeValues, types, "class");
		sql.addFieldFromTable(Constants.PARAMETER_INSTANCE_VALUE, "INTEGERVALUE");
		sql.addFieldFromTable(Constants.PARAMETER_INSTANCE_VALUE,"DECIMALVALUE");
		sql.addFieldFromTable(Constants.PARAMETER_INSTANCE_VALUE, "STRINGVALUE");
		sql.addFieldFromTable(Constants.PARAMETER_INSTANCE_VALUE, "DATEVALUE");
		sql.addFieldFromTable(Constants.PARAMETER_SET, "PARAMETERSET2OBJECT");
		sql.addFieldFromTable(Constants.PARAMETER_SET, "PARAMETERSET2DIMOBJECT");
		sql.addFieldFromTable(Constants.PARAMETER_SET, Constants.NAME,"PARAMETERNAME");
		/*sql.addFieldFromTable("EVC_SO", Constants.SERVICE_OBJECT_2_SERVICE,"EVCOVC_SERVICEID");
		sql.addFieldFromTable("EVC_SO", Constants.SERVICE_OBJECT_2_OBJECT,"VLAN_PORTID");*/
		sql.eq(Constants.PARAMETER_INSTANCE, Constants.PARAM_INSTANCE_2_PARAM_DEFINITION, Constants.PARAMETER_DEFINITION, Constants.PARAMETER_DEFINITION_ID);
		sql.eq(Constants.PARAMETER_INSTANCE_VALUE, Constants.PARAM_VALUE_2_PARAM_INSTANCE, Constants.PARAMETER_INSTANCE, Constants.PARAMETER_INSTANCE_ID);
		sql.eq(Constants.PARAMETER_INSTANCE, Constants.PARAM_INSTANCE_2_PARAM_SET_VERSION, Constants.PARAMETER_SET_VERSION, Constants.PARAMETER_SET_VERSION_ID);
		sql.eq(Constants.PARAMETER_SET_VERSION, Constants.PSET_VERSION_2_PARAMETER_SET, Constants.PARAMETER_SET, Constants.PARAMETER_SET_ID);
		List<String> parameterList =new ArrayList<String>();
		parameterList.add("CoS Value");
		parameterList.add("LOS Name");
		parameterList.add("CoS ID");
		parameterList.add("CIR");
		parameterList.add("EIR");
		parameterList.add("BW");	
		if(parameterList!=null && parameterList.size()>0)
		{
			sql.in(Constants.PARAMETER_DEFINITION, Constants.NAME,parameterList);
		}
		if(null!=portIdList && portIdList.size()>0)
		{
			sql.in(Constants.PARAMETER_SET, Constants.PARAMETER_SET_2_OBJECT, portIdList);
		}
		/*if(null!=portIdList && portIdList.size()>0)
		{
			sql.in("EVC_SO", Constants.SERVICE_OBJECT_2_OBJECT ,portIdList);
			sql.joinFOValue("EVC_SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT,"4");
		}*/
		if(null!=serviceID)
		{
			sql.eqUpperCase(Constants.PARAMETER_SET, Constants.PARAMETER_SET_2_OBJECT, serviceID);
		}
		String[] tables = {Constants.PARAMETER_INSTANCE_VALUE };
		String[] columnNames = {Constants.COMPOSITE_SEQUENCE};
		sql.orderBy(tables, columnNames);

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildQosQuery :" + query);
		}
		//System.out.println("buildQosQuery :" + query);
		return query;
	}

	private String buildVlanQuery(List<String> portIDList,String serviceID)
	{
		SQLBuilder sql = new SQLBuilder(Constants.DIMNUMBER,"NUM");
		sql.addTable(Constants.NUMBER_OBJECT,"NO");
		sql.addTable(Constants.DIMNUMBER_TYPE,"DIMTYPE");
		sql.addTable(Constants.EXT_NUMBER_VLAN,"EXT_VLAN");
		sql.addFieldFromTable("NUM", Constants.NAME,"NUMBERVALUE");
		sql.addFieldFromTable("DIMTYPE", Constants.NAME,"NUMBERTYPE");
		sql.addFieldFromTable("NO", Constants.NUMBER_OBJECT_2_OBJECT,"PORTID");
		sql.addFieldFromTable("EXT_VLAN", Constants.FUNCTION,"VLANFUNCTION");
		sql.joinFO("NUM", Constants.DIMNUMBER_ID, "NO", Constants.NUMBER_OBJECT_2_NUMBER);
		sql.joinFO("NUM", Constants.DIMNUMBER_2_NUMBER_TYPE, "DIMTYPE", Constants.DIMNUMBER_TYPE_ID);
		sql.joinFO("NUM", Constants.DIMNUMBER_ID, "EXT_VLAN", Constants.DIMNUMBER_ID);
		sql.eq("NO",Constants.NUMBER_OBJECT_2_DIM_OBJECT,"4");

		if(null!=portIDList && portIDList.size()>0)
		{

			sql.in("NO",Constants.NUMBER_OBJECT_2_OBJECT,portIDList);
		}
		if(null!=serviceID)
		{
			sql.eqUpperCase("NO",Constants.NUMBER_OBJECT_2_OBJECT,serviceID);
		}

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildVlanQuery :" + query);
		}
		System.out.println("buildVlanQuery :" + query);
		return query;
	}

	private String buildVPNIDQuery(List<String> serviceIDList)
	{
		SQLBuilder sql = new SQLBuilder(Constants.DIMNUMBER,"NUM");
		sql.addTable(Constants.NUMBER_OBJECT,"NO");
		sql.addTable(Constants.DIMNUMBER_TYPE,"DIMTYPE");
		sql.addTable(Constants.EXT_NUMBER_VPN,"EXT_VPN");
		
		sql.addFieldFromTable("NUM", Constants.NAME,"NUMBERVALUE");
		sql.addFieldFromTable("DIMTYPE", Constants.NAME,"NUMBERTYPE");
		sql.addFieldFromTable("NO", Constants.NUMBER_OBJECT_2_OBJECT,"SERVICEID");
		
		sql.joinFO("NUM", Constants.DIMNUMBER_ID, "NO", Constants.NUMBER_OBJECT_2_NUMBER);
		sql.joinFO("NUM", Constants.DIMNUMBER_2_NUMBER_TYPE, "DIMTYPE", Constants.DIMNUMBER_TYPE_ID);
		sql.joinFO("NUM", Constants.DIMNUMBER_ID, "EXT_VPN", Constants.DIMNUMBER_ID);
		sql.eq("NO",Constants.NUMBER_OBJECT_2_DIM_OBJECT,"8");

		if(null!=serviceIDList && serviceIDList.size()>0)
		{

			sql.in("NO",Constants.NUMBER_OBJECT_2_OBJECT,serviceIDList);
		}
		
		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildVPNIDQuery :" + query);
		}
		System.out.println("buildVPNIDQuery :" + query);
		return query;
	}

	private String getVlanPortForRelatedService(String serviceID, String commonName)
	{
		if (null!= commonName)
		{
			SQLBuilder sql = new SQLBuilder(Constants.SERVICE, "UNI_SER");
			sql.addTable(Constants.SERVICE, "EVC_SER");
			sql.addTable(Constants.SERVICE_OBJECT, "SO_UNI");
			sql.addTable(Constants.SERVICE_OBJECT, "SO_EVC");
			sql.addTable(Constants.PORT, "UNI_PORT");
			sql.addTable(Constants.PORT, "EB_PORT");
			sql.addTable(Constants.PORT, "VLAN_PORT");
			sql.addFieldFromTable("VLAN_PORT", Constants.PORT_ID);
			sql.addFieldFromTable("VLAN_PORT", Constants.NAME);
			sql.eqUpperCase("EVC_SER", Constants.NAME, commonName);
			sql.eq("EVC_SER", Constants.SERVICE_ID, "SO_EVC", Constants.SERVICE_OBJECT_2_SERVICE);
			sql.eq("SO_EVC", Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
			sql.eq("VLAN_PORT", Constants.PORT_ID, "SO_EVC", Constants.SERVICE_OBJECT_2_OBJECT);
			sql.eq("EB_PORT", Constants.PORT_ID, "VLAN_PORT", Constants.PARENT_PORT_2_PORT);
			sql.eq("UNI_PORT", Constants.PORT_ID, "EB_PORT", Constants.PARENT_PORT_2_PORT);
			sql.eq("SO_UNI", Constants.SERVICE_OBJECT_2_OBJECT, "UNI_PORT", Constants.PORT_ID);
			sql.eq("UNI_SER", Constants.SERVICE_ID, "SO_UNI", Constants.SERVICE_OBJECT_2_SERVICE);
			if (null != serviceID)
			{
				sql.eqUpperCase("UNI_SER", Constants.SERVICE_ID, serviceID);
			}

			String query = sql.getStatement();
			if (LOG.isInfoEnabled())
			{
				LOG.info("getVlanPortForRelatedService :" + query);
			}
			System.out.println("getVlanPortForRelatedService :" + query);
			return query;
		} 
		else
		{
			SQLBuilder sql = new SQLBuilder(Constants.SERVICE, "SERVICE");
			sql.addTable(Constants.SERVICE_OBJECT, "SO");
			sql.addTable(Constants.PORT, "UNI_PORT");
			sql.addTable(Constants.PORT, "EB_PORT");
			sql.addTable(Constants.PORT, "VLAN_PORT");
			sql.addTable(Constants.SERVICE_OBJECT, "EVC_SO");
			sql.addTable(Constants.SERVICE, "EVCOVC_SERVICE");
			sql.addTable(Constants.SERVICE_TYPE, "SC_TYPE");
			sql.addFieldFromTable("VLAN_PORT", Constants.PORT_ID);
			sql.addFieldFromTable("EVCOVC_SERVICE", Constants.NAME,"EVCOVCSERVICE");
			sql.addFieldFromTable("SC_TYPE", Constants.NAME);
			sql.eq(Constants.SERVICE, Constants.SERVICE_ID, "SO", Constants.SERVICE_OBJECT_2_SERVICE);
			sql.eq("SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT, "4");
			sql.eq("SO", Constants.SERVICE_OBJECT_2_OBJECT, "UNI_PORT", Constants.PORT_ID);
			sql.eq("UNI_PORT", Constants.PORT_ID, "EB_PORT", Constants.PARENT_PORT_2_PORT);
			sql.eq("EB_PORT", Constants.PORT_2_PORTTYPE,"150020001");
			sql.eq("EB_PORT", Constants.PORT_ID, "VLAN_PORT", Constants.PARENT_PORT_2_PORT);
			sql.eq("VLAN_PORT",Constants.PORT_2_PORTTYPE, "150020005");
			sql.joinFO("EVC_SO",Constants.SERVICE_OBJECT_2_OBJECT,"VLAN_PORT", Constants.PORT_ID);
			sql.joinFO("EVC_SO",Constants.SERVICE_OBJECT_2_SERVICE,"EVCOVC_SERVICE", Constants.SERVICE_ID);
			sql.joinFO("EVCOVC_SERVICE", Constants.SERVICE_2_SERVICE_TYPE,"SC_TYPE",Constants.SERVICE_TYPE_ID);		
			sql.eq("EVC_SO",Constants.SERVICE_OBJECT_2_DIM_OBJECT,"4");

			if (null != serviceID)
			{
				sql.eqUpperCase(Constants.SERVICE, Constants.SERVICE_ID, serviceID);
			}
			String[] tables = {"SC_TYPE","SC_TYPE" };
			String[] columnNames = {Constants.NAME,Constants.NAME};
			String[] values = {"MEF EVC","MEF OVC"};

			sql.orClauses(tables, columnNames, values);

			String query = sql.getStatement();
			if (LOG.isInfoEnabled())
			{
				LOG.info("getVlanPortForRelatedService :" + query);
			}
			System.out.println("getVlanPortForRelatedService :" + query);
			return query;
		}
	}

	public String buildCardOnCardDetailsQuery (String portId)
	{
		SQLBuilder sql = new SQLBuilder(Constants.CARD);
		sql.addTable(Constants.CARD_TYPE);
		sql.addTable(Constants.CARD_IN_SLOT);
		sql.addTable(Constants.SLOT);
		sql.addTable(Constants.CARD, "PC");
		sql.addTable(Constants.CARD_TYPE, "PCT");
		sql.addTable(Constants.SLOT, "PS");
		sql.addTable(Constants.PORT);
		sql.addTable(Constants.PORTTYPE);
		sql.addTable(Constants.EXT_PORT_TABLE);
		sql.addTable(Constants.EXT_PORT_PLUGGABLE);
		sql.addTable(Constants.BANDWIDTH);
		sql.addFieldFromTable(Constants.CARD, Constants.NAME);
		sql.addFieldFromTable(Constants.CARD, Constants.CARD_ID);
		sql.addFieldFromTable(Constants.CARD, Constants.ALIAS_1);
		sql.addFieldFromTable(Constants.CARD_TYPE, Constants.NAME, "CARDTYPE");
		sql.addFieldFromTable(Constants.CARD, Constants.CARD_2_SHELF_SLOT);
		sql.addFieldFromTable("PC", Constants.NAME, "PARENTCARDNAME");
		sql.addFieldFromTable("PC", Constants.CARD_ID, "PARENTCARDID");
		sql.addFieldFromTable("PC", Constants.ALIAS_1, "PARENTALIAS1");
		sql.addFieldFromTable("PCT", Constants.NAME, "PARENTCARDTYPE");
		sql.addFieldFromTable("PS", Constants.SLOT_NUMBER, "PARENTSLOTNUMBER");
		sql.addFieldFromTable(Constants.SLOT, Constants.NAME, "SLOTNAME");
		sql.addFieldFromTable(Constants.SLOT, Constants.SLOT_ID);
		sql.addFieldFromTable(Constants.SLOT, Constants.SLOT_NUMBER);
		sql.addFieldFromTable(Constants.PORT, Constants.NAME, "PORTNAME");
		sql.addFieldFromTable(Constants.PORT, Constants.PORT_ID);
		sql.addFieldFromTable(Constants.PORTTYPE, Constants.NAME, "PORTTYPE");
		sql.addFieldFromTable(Constants.PORT, Constants.ALIAS_1, "LEGACYPORTNAME");
		sql.addFieldFromTable(Constants.PORT, Constants.PORT2BANDWIDTH);
		sql.addFieldFromTable(Constants.BANDWIDTH, Constants.NAME, "BANDWIDTH_NAME");
		sql.addFieldFromTable(Constants.EXT_PORT_TABLE, Constants.IF_NAME);
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.IF_NAME, "PLUGGABLE_IF_NAME");		
		sql.addConcatenatedFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.BANDWIDTH, Constants.EXT_PORT_PLUGGABLE, Constants.FORM_FACTOR, "PLUGGABLE_TRANSMISSIONRATE");
		sql.addFieldFromTable(Constants.EXT_PORT_TABLE, Constants.DPEA);
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.DPEA, "DPEA_1");
		sql.addFieldFromTable(Constants.EXT_PORT_PLUGGABLE, Constants.PLUGGABLE_TYPE);
		sql.addCase(Constants.EXT_PORT_PLUGGABLE, "PORTFUNCTION", Constants.EXT_PORT_TABLE, "PORTFUNCTION", "portfunction");
		sql.eq(Constants.CARD, Constants.CARD_2_CARD_TYPE, Constants.CARD_TYPE, Constants.CARD_TYPE_ID);
		sql.joinFO("PC", Constants.CARD_2_CARD_TYPE, "PCT", Constants.CARD_TYPE_ID);
		sql.joinFO(Constants.CARD_IN_SLOT, Constants.CARD_IN_SLOT_2_CARD, Constants.CARD, Constants.CARD_ID);
		sql.joinFO(Constants.CARD_IN_SLOT, Constants.CARD_IN_SLOT_2_SLOT, Constants.SLOT, Constants.SLOT_ID);
		sql.joinFO(Constants.CARD, Constants.CARD_2_SHELF_SLOT, "PS", Constants.SLOT_ID);
		sql.joinFO(Constants.SLOT, Constants.SLOT_2_CONTAINING_CARD, "PC", Constants.CARD_ID);
		sql.eq(Constants.PORT, Constants.PORT_2_CARD, Constants.CARD, Constants.CARD_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_2_PORTTYPE, Constants.PORTTYPE, Constants.PORTTYPEID);
		sql.joinFO(Constants.PORT, Constants.PORT_ID, Constants.EXT_PORT_TABLE, Constants.PORT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT_ID, Constants.EXT_PORT_PLUGGABLE, Constants.PORT_ID);
		sql.joinFO(Constants.PORT, Constants.PORT2BANDWIDTH, Constants.BANDWIDTH, Constants.BANDWIDTH_ID);
		if(!StringHelper.isEmpty(portId))
			sql.eq(Constants.PORT, Constants.PORT_ID, portId);

		String query = sql.getStatement();
		if(LOG.isInfoEnabled())
		{
			LOG.info("buildCardOnCardDetailsQuery :" + query);
		}
		//System.out.println("buildCardOnCardDetailsQuery :" + query);
		return query;
	}

	private String  getPhysicalPortForRelatedService(String serviceID)
	{
		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.SERVICE_OBJECT,"SO");
		sql.addTable(Constants.PORT,"UNI_PORT");
		sql.addFieldFromTable("UNI_PORT",Constants.PORT_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_ID,"SO", Constants.SERVICE_OBJECT_2_SERVICE);
		sql.eq("SO", Constants.SERVICE_OBJECT_2_OBJECT,"UNI_PORT", Constants.PORT_ID);
		sql.eq("SO", Constants.SERVICE_OBJECT_2_DIM_OBJECT,"4");
		if(null!=serviceID)
		{
			sql.eqUpperCase(Constants.SERVICE,Constants.SERVICE_ID,serviceID);
		}

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("getPhysicalPortForRelatedService :" + query);
		}
		//System.out.println("getPhysicalPortForRelatedService :" + query);
		return query;
	}

	private void getCardOnCardDetails(List<ARMCircuitDetails> startNodeList, List<ARMCircuitDetails> endNodeList) throws Exception
	{
		if (startNodeList != null && startNodeList.size() > 0)
		{
			for (ARMCircuitDetails node : startNodeList)
			{
				if (node != null && !StringHelper.isEmpty(node.getPortID()))
				{
					ARMCard childCards = new ARMCard();
					childCards.setChildCards(searchCircuitDAO.getCardList(buildCardOnCardDetailsQuery(node.getPortID())));
					node.setStartNodeCards(childCards);
				}
			}
		}
		if (endNodeList != null && endNodeList.size() > 0)
		{
			for (ARMCircuitDetails node : endNodeList)
			{
				if (node != null && !StringHelper.isEmpty(node.getPortID()))
				{
					ARMCard childCards = new ARMCard();
					childCards.setChildCards(searchCircuitDAO.getCardList(buildCardOnCardDetailsQuery(node.getPortID())));
					node.setEndNodeCards(childCards);
				}
			}
		}
	}

	private String buildMaxValueForServiceQuery()
	{
		SQLBuilder sql = new SQLBuilder("CIRCUIT_VALUES_MAX_NUM");
		sql.addFieldFromTable("CIRCUIT_VALUES_MAX_NUM", "MAX_VALUE");
		sql.addFieldFromTable("CIRCUIT_VALUES_MAX_NUM", "MAX_COLUMN_NAME");
		sql.addFieldFromTable("CIRCUIT_VALUES_MAX_NUM", "SERVICE_TYPE");

		String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("getMaxValue :" + query);
		}
		return query;
	}

	private HashMap<String,ArrayList<MaxNameValue>> getMaxValuesMap() throws Exception
	{
		HashMap<String,ArrayList<MaxNameValue>> MaxValuesMap=new HashMap<String,ArrayList<MaxNameValue>>();
		List<MaxNameValue> maxValuesList=searchCircuitDAO.getMaxValuesForService(buildMaxValueForServiceQuery());
		for (MaxNameValue value:maxValuesList)
		{
			if(null!=MaxValuesMap.get(value.getServiceType()))
			{
				MaxValuesMap.get(value.getServiceType()).add(value);
			}
			else
			{
				ArrayList<MaxNameValue> maxValueList=new ArrayList<MaxNameValue>();
				maxValueList.add(value);
				MaxValuesMap.put(value.getServiceType(),maxValueList);
			}
		}
		return MaxValuesMap;
	}
	private Object getCktDetails(List<ARMCircuitDetails> armCktDetailsList,String includeRelationship,
			SearchResourceRequestDocument request) throws Exception{
		SearchResponseDetailsBuilder searchResponseDetailsBuilder=new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		for (ARMCircuitDetails circuitdetails : armCktDetailsList) {
			Map<String, Object> transformParms = new HashMap<String, Object>();
			String circuitId = circuitdetails.getObjectID();
			String startPort = circuitdetails.getStartPort();
			String endPort = circuitdetails.getEndPort();
			List<ARMCircuitDetails> relatedServiceDetails=null;
			List<ARMCircuitDetails> startNodeList = null;
			List<ARMCircuitDetails> endNodeList = null;
			
			// Getting NodeDetails
			if (startPort != null) {
				startNodeList = searchCircuitDAO
						.getNodeDetailsList(buildNodeDetailsQuery(startPort));
			}
			if (endPort != null) {
				endNodeList = searchCircuitDAO
						.getNodeDetailsList(buildNodeDetailsQuery(endPort));
			}
			// Getting CardOnCardDetails
			getCardOnCardDetails(startNodeList, endNodeList);
			// Getting Related Services
			if (circuitId != null && !StringHelper.isEmpty(includeRelationship) && includeRelationship.equalsIgnoreCase("True")) {
				relatedServiceDetails = searchCircuitDAO
						.getRelatedServiceDetailsForNMILAG(buildRelatedServiceQueryForNMILAG(circuitId));
				transformParms.put("RelatedServiceDetails", relatedServiceDetails);
			}
			// Creating Response
			SearchCircuitDetailsToCim searchCircuitDetailsToCim = new SearchCircuitDetailsToCim();
			transformParms.put("ARMCktDetails", circuitdetails);
			transformParms.put("StartNodeList", startNodeList);
			transformParms.put("EndNodeList", endNodeList);
			transformParms.put("includeRelationship", includeRelationship);
			transformParms.put("responseBuilder", searchResponseDetailsBuilder);
			searchResponseDetailsBuilder = searchCircuitDetailsToCim
					.transformCircuitDetailsToCim(transformParms);

			
			
		}
		SearchResourceResponseDocument response=MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		if (LOG.isInfoEnabled()) {
			LOG.info(response.toString());
		}
		System.out.println(response);
		return response;

	}
	private Object getServiceDetails(List<ARMCircuitDetails> armServiceList,String includeRelationship,
			SearchResourceRequestDocument request) throws Exception
 {
		SearchResponseDetailsBuilder searchResponseDetailsBuilder=new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		if (armServiceList != null && armServiceList.size() > 0) {
			//Fix to handle duplicate EVCckts in case that ckt is having multiple VLANPortIds
			HashSet<String> serviceSet=new HashSet<String>();
			for (ARMCircuitDetails serviceDetails : armServiceList) {
				if (!serviceSet.contains(serviceDetails.getServiceID())) {
					serviceSet.add(serviceDetails.getServiceID());
					HashMap<String, List<QosDetails>> serviceidQOSMap = new HashMap<String, List<QosDetails>>();
					HashMap<String, List<VlanDetails>> serviceidVlanMap = new HashMap<String, List<VlanDetails>>();
					HashMap<String, List<ARMCircuitDetails>> serviceidNodeDetailsMap = new HashMap<String, List<ARMCircuitDetails>>();
					Map<String, Object> transformParms = new HashMap<String, Object>();
					String serviceType = serviceDetails.getServiceType();
					String serviceId = serviceDetails.getServiceID();
					String portId = serviceDetails.getPortID();
					List<ARMCircuitDetails> endNodeList = null;
					List<ARMCircuitDetails> relatedServiceDetails = null;
					List<ARMCircuitDetails> relatedCircuitDetails = null;
					List<QosDetails> qosDetailsList = null;
					List<QosDetails> qosDetailsForRelatedServiceList = null;
					List<VlanDetails> vlanDetailsList = null;
					List<VlanDetails> vlanRangeListForUNI = null;
					List<VlanDetails> vlanRangeListForEVC = null;
					List<VlanDetails> relatedVlanDetailsList = null;
					List<VlanDetails> vpnIDListForEVC = null;
					List<VlanDetails> vpnIDListForUNI=null;
					HashMap<String, ArrayList<MaxNameValue>> maxValuesMap = null;
					List<ARMEVCVlan> evcVlanList = null;
					transformParms.put("responseBuilder",
							searchResponseDetailsBuilder);
					transformParms.put("includeRelationship",
							includeRelationship);
					// String commonName =
					// request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
					// }
					if (portId != null) {
						endNodeList = searchCircuitDAO
								.getNodeDetailsList(buildNodeDetailsQuery(portId));

					}
					// Getting CardOnCardDetails
					getCardOnCardDetails(null, endNodeList);
					// Getting RelatedCircuitDetails/RelatedServiceDetails
					if (serviceId != null && serviceType != null) {
						maxValuesMap = getMaxValuesMap();
						if (serviceType.equalsIgnoreCase("MEF UNI")
								|| (serviceType.equalsIgnoreCase("MEF ENNI"))) {
							List<String> portIDList = new ArrayList<String>();
							relatedCircuitDetails = searchCircuitDAO
									.getRelatedNMILAGForUNIENNI(buildRelatedCktForUNIENNIQuery(serviceId));
							relatedServiceDetails = searchCircuitDAO
									.getRelatedEVCOVCForUNIENNI(buildRelatedServiceForUNIENNIQuery(serviceId));

							List<String> serviceIdList=new ArrayList<String>();
							
							if(relatedServiceDetails!=null && relatedServiceDetails.size()>0)
							{
								for(ARMCircuitDetails relatedService :relatedServiceDetails)
								{
									if(relatedService!=null && relatedService.getServiceID()!=null)
									{
										serviceIdList.add(relatedService.getServiceID());
									}
								}
							}
							vpnIDListForUNI=searchCircuitDAO
									.getVpnIDDetails(buildVPNIDQuery(
											serviceIdList));
							
							List<String> portIdsForQosVLAN = jdbcTempleteUtil
									.getPortIdList(getVlanPortForRelatedService(
											serviceId, null));
							evcVlanList = searchCircuitDAO
									.getEVCVlanDetails(getVlanPortForRelatedService(
											serviceId, null));
							if (portIdsForQosVLAN != null
									&& portIdsForQosVLAN.size() > 0) {
								qosDetailsList = searchCircuitDAO
										.getQosDetails(buildQosQuery(
												portIdsForQosVLAN, null));
								vlanDetailsList = searchCircuitDAO
										.getVlanDetails(buildVlanQuery(
												portIdsForQosVLAN, null));
							}

							if (portId != null) {
								portIDList.add(portId);
								vlanRangeListForUNI = searchCircuitDAO
										.getVlanDetails(buildVlanQuery(
												portIDList, null));
							}
						}
						if (serviceType.equalsIgnoreCase("MEF EVC")
								|| (serviceType.equalsIgnoreCase("MEF OVC"))) {
							
							List<String> serviceIdList=new ArrayList<String>();
							
							if(serviceId!=null)
							serviceIdList.add(serviceId);
							
							vpnIDListForEVC=searchCircuitDAO
							.getVpnIDDetails(buildVPNIDQuery(
									serviceIdList));
							
							relatedServiceDetails = searchCircuitDAO
									.getRelatedUNIENNIForEVCOVC(buildRelatedServiceForEVCOVCQuery(serviceId));
							if (null != relatedServiceDetails
									&& relatedServiceDetails.size() > 0) {
								List<String> portIDList = new ArrayList<String>();
								for (ARMCircuitDetails relatedService : relatedServiceDetails) {

									if (null != relatedService
											&& relatedService.getServiceID() != null) {
										List<String> relatedVLAnportIds = jdbcTempleteUtil
												.getPortIdList(getVlanPortForRelatedService(
														relatedService
																.getServiceID(),
														request.getSearchResourceRequest()
																.getSearchResourceDetails()
																.getCommonName()));
										String relatedportId = jdbcTempleteUtil
												.getPortId(getPhysicalPortForRelatedService(relatedService
														.getServiceID()));
										if (null != relatedVLAnportIds) {
											qosDetailsForRelatedServiceList = searchCircuitDAO
													.getQosDetails(buildQosQuery(
															relatedVLAnportIds,
															null));
											if (null != qosDetailsForRelatedServiceList
													&& qosDetailsForRelatedServiceList
															.size() > 0) {
												serviceidQOSMap
														.put(relatedService
																.getServiceID(),
																qosDetailsForRelatedServiceList);
											}
											relatedVlanDetailsList = searchCircuitDAO
													.getVlanDetails(buildVlanQuery(
															relatedVLAnportIds,
															null));
											if (null != relatedVlanDetailsList
													&& relatedVlanDetailsList
															.size() > 0) {
												serviceidVlanMap
														.put(relatedService
																.getServiceID(),
																relatedVlanDetailsList);
											}
										}
										if (null != relatedportId) {

											endNodeList = searchCircuitDAO
													.getNodeDetailsList(buildNodeDetailsQuery(relatedportId));
											// portIDList.add(relatedportId);
											// vlanRangeListForEVC=searchCircuitDAO.getVlanDetails(buildVlanQuery(portIDList,
											// null));
											if (null != endNodeList
													&& endNodeList.size() > 0) {
												serviceidNodeDetailsMap
														.put(relatedService
																.getServiceID(),
																endNodeList);
												// Getting CardOnCardDetails
												getCardOnCardDetails(null,
														endNodeList);
											}
										}
									}
								}
								for (ARMCircuitDetails relatedService : relatedServiceDetails) {
									portIDList.add(relatedService.getPortID());
									vlanRangeListForEVC = searchCircuitDAO
											.getVlanDetails(buildVlanQuery(
													portIDList, null));
								}
							}
						}
					}

					// Creating Response

					transformParms.put("ArmServiceDetails", serviceDetails);
					transformParms.put("RelatedCircuitDetails",
							relatedCircuitDetails);
					transformParms.put("RelatedServiceDetails",
							relatedServiceDetails);
					transformParms.put("MaxValues", maxValuesMap);
					if (serviceType.equalsIgnoreCase("MEF EVC")
							|| (serviceType.equalsIgnoreCase("MEF OVC"))) {
						SearchCircuitDetailsToCim searchCircuitDetailsToCim = new SearchCircuitDetailsToCim();
						transformParms.put("ServiceidQOSMap", serviceidQOSMap);
						transformParms
								.put("ServiceidVlanMap", serviceidVlanMap);
						transformParms.put("ServiceidNodeDetailsMap",
								serviceidNodeDetailsMap);
						transformParms.put("VlanRangeListForEVC",
								vlanRangeListForEVC);
						transformParms.put("VPNIDListForEVC",
								vpnIDListForEVC);
						searchResponseDetailsBuilder = searchCircuitDetailsToCim
								.transformCircuitDetailsToCim(transformParms);
					}
					if (serviceType.equalsIgnoreCase("MEF UNI")
							|| (serviceType.equalsIgnoreCase("MEF ENNI"))) {
						HashMap<String, ArrayList<QosDetails>> qosDetailsMap = new HashMap<String, ArrayList<QosDetails>>();
						if (qosDetailsList != null && qosDetailsList.size() > 0) {
							for (QosDetails qosDetails : qosDetailsList) {
								if (qosDetailsMap.get(qosDetails
										.getParameterObject()) != null) {
									qosDetailsMap.get(
											qosDetails.getParameterObject())
											.add(qosDetails);
								} else {
									ArrayList<QosDetails> newList = new ArrayList<QosDetails>();
									newList.add(qosDetails);
									qosDetailsMap.put(
											qosDetails.getParameterObject(),
											newList);
								}
							}
						}
						SearchCircuitDetailsToCim searchCircuitDetailsToCim = new SearchCircuitDetailsToCim();
						transformParms.put("EndNodeList", endNodeList);
						transformParms.put("UNIQosDetailsMap", qosDetailsMap);
						transformParms.put("VlanDetailsList", vlanDetailsList);
						transformParms.put("VlanRangeListForUNI",
								vlanRangeListForUNI);
						transformParms.put("EVCVlanList", evcVlanList);
						transformParms.put("VPNIDListForUNI",
								vpnIDListForUNI);
						
						// transformParms.put("Request", request);
						searchResponseDetailsBuilder = searchCircuitDetailsToCim
								.transformCircuitDetailsToCim(transformParms);
					}
				}
			}
			SearchResourceResponseDocument response=MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
			if (LOG.isInfoEnabled()) {
				LOG.info(response.toString());
			}
			System.out.println(response);
			return response;
		} 
		else 
		{
			throw new OSSDataNotFoundException();
		}
	}
	
	public Object performLoopQual(SearchResourceRequestDocument requestObject) {

		String serviceAddressId = requestObject.getSearchResourceRequest().getSearchResourceDetails().getObjectID();
		LOG.info("<<<<<<<<<<<<<<<<Search Circuit ---> PerformLoopQual Starts>>>>>>>>>>>>>>>>>>>>>>>>>>>"+serviceAddressId);
		/*if(StringUtils.trimToNull(serviceAddressId) == null){
			return getException(new ICLException("InvalidRequestException: CLC ObjectID is Null"), requestObject);
		}*/
		//String serviceLocation = "HNSONVXK";
		List<String> networkRoles = new ArrayList<String>();
		/*networkRoles.add("MST");
		networkRoles.add("FDP");
		networkRoles.add("Splitter");*/
		int ponCircuitCount = 1;
		int circuitCount = 1;


		//String serviceAddressId = requestObject.getSearchResourceRequest().getSearchResourceDetails().getObjectID();
		List<AmericanPropertyAddress> addressList = null;
		AmericanPropertyAddress address = null;
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		List<SubNetworkConnectionBuilder> subNetWorkList = new ArrayList<SubNetworkConnectionBuilder>();
		HashMap<RouteBuilder, LogicalPhysicalResourceBuilder> routeMap = null;
		fdTopologicalList = new ArrayList<TopologicalLinkBuilder>();
		splitterList = new ArrayList<TopologicalLinkBuilder>();
		String restrictedMessage = null;
		String restrictedFlag = "N";
		String restrictionReason = null;
		SearchResourceResponseDocument response = null;
		String serviceAddressLocationName = null;
		/*boolean isRestrictedAddress = false;
		boolean isRestrictedCode = false;
		boolean isRestrictionReason = false;*/
		LOG.info("<<<<<<<<<<<<<<<<Search Circuit ---> PerformLoopQual All Initilization done>>>>>>>>>>>>>>>>>>>>>>>>>>>");


		try{
			response = clcLookupService.getServiceAddressById(serviceAddressId);
			if(response != null){
				if(response.getSearchResourceResponse() != null && response.getSearchResourceResponse().getMessageElements() != null 
						&& response.getSearchResourceResponse().getMessageElements().getErrorListList() != null
						&& response.getSearchResourceResponse().getMessageElements().getErrorListList().size() > 0){
					LOG.info("******* Got Error From CLC Database For Search Location ******** "+response.getSearchResourceResponse().getMessageElements().getErrorListList().get(0).getErrorMessage());
					return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1951, Constants.OSS_NO_DATA_FOUND_ERROR, "Service Location doesn't exists in CLC database", requestObject);
				}
				address = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);

				if(address != null){
					List<CharacteristicValue> characteristicValueList= address.getRootEntityDescribedByList();
					if(address.getRemarksList() != null && address.getRemarksList().size() > 0){
						for(Remarks remarksData: address.getRemarksList()){
							if(CLCConstants.RESTRICTEDACCESSCODE.equals(remarksData.getType())){
								restrictedFlag = "Y";
								restrictedMessage = "Service Address found to be a RESTRICTED ADDRESSES";
							}
						}
						address.getRemarksList().clear();
					}
					if(null != characteristicValueList){
						for(CharacteristicValue characteristicValue:characteristicValueList){
							/*if("RestrictedAddressIndicator".equals(characteristicValue.getCharacteristicName()) && "Y".equals(characteristicValue.getCharacteristicValue())){
								restrictedFlag = characteristicValue.getCharacteristicValue();
								restrictedMessage = "Service Address found to be a RESTRICTED ADDRESSES";
							}else */
							/*if(CLCConstants.RESTRICTEDACCESSCODE.equals(characteristicValue.getCharacteristicName()) && Integer.parseInt(characteristicValue.getCharacteristicValue()) > 0){
								restrictedFlag = "Y";
								restrictedMessage = "Service Address found to be a RESTRICTED ADDRESSES";
							}else */
							if("Restriction Reason".equals(characteristicValue.getCharacteristicName()) && (characteristicValue.getCharacteristicValue() != null || !" ".equals(characteristicValue.getCharacteristicValue()))){
								restrictedFlag = "Y";
								restrictionReason = characteristicValue.getCharacteristicValue();
								restrictedMessage = "Service Address found to be a RESTRICTED ADDRESSES";
							}
						}
						
					}

					serviceAddressLocationName = address.getCommonName();
				}
			}else{
				return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1951,Constants.OSS_NO_DATA_FOUND_ERROR , "Service Location doesn't exists in CLC database", requestObject);
			}
			LOG.info("********* Service Address Response **********: "+response);
		}catch(Exception e){
			LOG.info("Exception Caught while Searching Location :" + e);
			if(e instanceof OSSDataNotFoundException){
				return MediationUtil.getSearchResourceErrorResponse(((OSSDataNotFoundException)e).getErrorCode(), ((OSSDataNotFoundException)e).getErrorText(), "Service Location doesn't exists in CLC database", requestObject);
			}else{
				return getException(e, requestObject);
			}
		}
		//Start SearchServiceArea 
		List<String> serviceAreaLocationNameList = new ArrayList<String>();
		try{
			response = clcLookupService.getServiceArea(serviceAddressId, null);
			LOG.info("******** HEREee ***" ); 
			System.out.println("------- HERE ----");
			LOG.info("************* ServiceArea Response******************"+response);

			if(response != null){
				if(response.getSearchResourceResponse() != null && response.getSearchResourceResponse().getMessageElements() != null 
						&& response.getSearchResourceResponse().getMessageElements().getErrorListList() != null
						&& response.getSearchResourceResponse().getMessageElements().getErrorListList().size() > 0){
					LOG.info("******* Got Error From CLC Database For Search Service Area: ******** "+response.getSearchResourceResponse().getMessageElements().getErrorListList().get(0).getErrorMessage());
					return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1951, Constants.OSS_NO_DATA_FOUND_ERROR, "Service Location is not within GPON footprint", requestObject);
				}
				if ((response != null)
						&& (response.getSearchResourceResponse() != null)
						&& (response.getSearchResourceResponse().getSearchResponseDetailsList() != null)
						&& (response.getSearchResourceResponse().getSearchResponseDetailsList().size() > 0)
						&& (response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0) != null)){
					LOG.info("******* Found Service Area  List count:  ******** "+response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().size());
					addressList = response.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList();
					for(AmericanPropertyAddress americanAddress: addressList){
						LOG.info("******* Service Area  Common Name  ******** "+americanAddress.getPlaceLocatesResourceList().get(0).getResourceRelationshipList().get(0).getDevice().getInstalledAtAddress().getCommonName());
						serviceAreaLocationNameList.add(americanAddress.getPlaceLocatesResourceList().get(0).getResourceRelationshipList().get(0).getDevice().getInstalledAtAddress().getCommonName());
						
					}
				}
				LOG.info("********* Service Area Response **********: "+response);
			}else{
				LOG.info("SearviceArea search and its response is :" + response);
				return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1951,Constants.OSS_NO_DATA_FOUND_ERROR , "Service Location is not within GPON footprint", requestObject);
			}
		}catch(Exception e){
			LOG.info("Exception Caught in SearviceArea search :" + e);
			if(e instanceof OSSDataNotFoundException){
				return MediationUtil.getSearchResourceErrorResponse(((OSSDataNotFoundException)e).getErrorCode(), ((OSSDataNotFoundException)e).getErrorText(), "Service Location is not within GPON footprint", requestObject);
			}else{
				return getException(e, requestObject);
			}
		}	
		//End SearchServiceArea 	

		//Start determine the Ordered priority list
		List<ARMOrderedNetworkRoleList> networkRoleListList = null;
		try {
			networkRoleListList= searchDeviceDAO.getOrderedNetworkRoleList("select * from Ordered_Network_Rolelist order by priority asc");
			for(ARMOrderedNetworkRoleList networkRoleList: networkRoleListList){
				String deviceRole = networkRoleList.getDeviceRole();
				if(!"ONT".equalsIgnoreCase(deviceRole) && !"OLT".equalsIgnoreCase(deviceRole))
					networkRoles.add(deviceRole);
			}
		} catch (Exception e) {
			LOG.info("Exception Caught in Network Role List: "+e);
		}

		//End determine the Ordered priority list	


		//Start Call performGPONLoopQual HV API

		try {
			String fiberDropIndiactor = null;
			String fiberDropType = null;
			for(String serviceAreaLocation: serviceAreaLocationNameList){
				LOG.info("************* Got serviceAreaLocation****************** "+serviceAreaLocation);
				map = (HashMap<String, Object>) performGPONLoopQual.execute(serviceAddressLocationName, serviceAreaLocation, networkRoles);
				LOG.info("*** Map size ***"+map);
				if(map != null && map.size() > 0){
					BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
					if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
					{
						final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
						if (LOG.isInfoEnabled())
						{
							LOG.info("******* Got Error From PerformLoopQual API:  ******** "+o_Errormsg);
						}
						if(o_ErrorCode.intValue() == -6502){
							return MediationUtil.getSearchResourceErrorResponse("1222", Constants.ICL_INTERNAL_ERROR, "Cannot find location identified by i_ServiceLocation", requestObject);
						}else{
							return MediationUtil.getSearchResourceErrorResponse(o_ErrorCode.toString(), Constants.ICL_INTERNAL_ERROR, o_Errormsg, requestObject);
						}
					}
					fdTopologicalList = createFiberDropLink((ARRAY) map.get("o_FDNodesPortCapacity"));
					fiberDropIndiactor = (String)(map.get("o_FiberDropIndicator").toString());
					fiberDropType = (String)map.get("o_FiberDropType");
					//routeList = createONTOLTTopologicalLink(map, fdTopologicalList, serviceAddressId);
					ARRAY splitterNodesArray = (ARRAY) map.get("o_SplitterNodes");
					Datum[] elements = splitterNodesArray.getOracleArray();
					if(elements != null && elements.length == 0){
						String splitterNames = (String)map.get("o_Splitter");
						if(splitterNames != null){
							splitterMap = (HashMap<String, Object>) getSplitterCapability.execute(splitterNames);
							o_ErrorCode = (BigDecimal) splitterMap.get(Constants.O_ERROR_CODE);
							if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
							{
								final String o_Errormsg = (String) splitterMap.get(Constants.O_ERROR_TEXT);
								if (LOG.isInfoEnabled())
								{
									LOG.info("******* Got Error From GetSplitterCapability API:  ******** "+o_Errormsg);
								}
							}
							LOG.info("************* Inside Thread Call *************");
							if(splitterMap != null && splitterMap.size() > 0){
								createSplitterOLTTopologicalLink(splitterNames, fdh, splitterMap, routeList, map, fdTopologicalList);
								LOG.info("<<<<<<<<<<<<<<<<Search Circuit ---> PerformLoopQual got splitter routelist>>>>>>>>>>>>>>>>>>>>>>>>>>>");
							}
						}
					}else{
						Thread t = null;
						for (int i=0;i<elements.length;i++){
							try{
								Object[] splitter = ((STRUCT) elements[i]).getAttributes();
								/*ARRAY splitterArray = (ARRAY)element[0];
							Datum[] splitters = splitterArray.getOracleArray();*/
								//for (int j=0;i<splitters.length;j++){
								//Object[] splitter = ((STRUCT) splitters[j]).getAttributes();
								//if(splitter != null && splitter.length > 0){
								splitterName = splitter[0] != null ? splitter[0].toString(): null;
								fdh = splitter[1] != null ? splitter[1].toString() : null;
								LOG.info("************* Got Splitter Data ******************");
								t = new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										if(splitterName != null){
											splitterMap = (HashMap<String, Object>) getSplitterCapability.execute(splitterName);
											BigDecimal o_ErrorCode = (BigDecimal) splitterMap.get(Constants.O_ERROR_CODE);
											if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
											{
												final String o_Errormsg = (String) splitterMap.get(Constants.O_ERROR_TEXT);
												if (LOG.isInfoEnabled())
												{
													LOG.info("******* Got Error From GetSplitterCapability API:  ******** "+o_Errormsg);
												}
											}
											LOG.info("************* Inside Thread Call *************");
											if(splitterMap != null && splitterMap.size() > 0){
												createSplitterOLTTopologicalLink(splitterName, fdh, splitterMap, routeList, map, fdTopologicalList);
												LOG.info("<<<<<<<<<<<<<<<<Search Circuit ---> PerformLoopQual got splitter routelist>>>>>>>>>>>>>>>>>>>>>>>>>>>");
											}
										}
									}
								});
								t.start();
								if (t != null) t.join();
								//}
								//}
							}catch(Exception e){
								LOG.info("Exception Caught in Splitter Node Process: "+e);
							}
						}
						//if (t != null) t.join();

					}
					routeMap = createONTOLTTopologicalLink(map, fdTopologicalList, serviceAddressId, splitterList);
				}
				if(address != null){
					address.getPlaceLocatesResourceList().clear();
					List<CharacteristicValue> characteristicValueList= address.getRootEntityDescribedByList();
					CharacteristicValue rcv = CharacteristicValue.Factory.newInstance();
					rcv.setCharacteristicName("RestrictedAddressFlag");
					rcv.setCharacteristicValue(restrictedFlag);
					address.getRootEntityDescribedByList().add(rcv);
					
					if(restrictionReason != null){
						rcv.setCharacteristicName("RestrictionReason");
						rcv.setCharacteristicValue(restrictionReason);
						address.getRootEntityDescribedByList().add(rcv);
					}

					if(fiberDropIndiactor != null){
						rcv = CharacteristicValue.Factory.newInstance();
						rcv.setCharacteristicName("FiberDropIndicator");
						rcv.setCharacteristicValue(fiberDropIndiactor);
						address.getRootEntityDescribedByList().add(rcv);
					}

					LOG.info("***** fiberDropType: ******"+fiberDropType);
					if(fiberDropType != null){
						rcv = CharacteristicValue.Factory.newInstance();
						rcv.setCharacteristicName("FiberDropType");
						rcv.setCharacteristicValue(fiberDropType);
						address.getRootEntityDescribedByList().add(rcv);
					}
					
					if(restrictedMessage != null){
						RemarkBuilder remarkBuilder = new RemarkBuilder();
						remarkBuilder.buildRemark(restrictedMessage,"RestrictedNotes");
						address.getRemarksList().add(remarkBuilder.getRemarks());
					}
					

				}
				for(Map.Entry<RouteBuilder, LogicalPhysicalResourceBuilder> routeMapObject: routeMap.entrySet()){
					/*subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
				subNetworkConnectionBuilder.buildSubNetworkConnection("PON Circuit"+ponCircuitCount, null, null, "ARM", null, null, null, null);
				ponCircuitCount++;*/
					RouteBuilder routeBuilderObject = routeMapObject.getKey();
					LogicalPhysicalResourceBuilder oltPhyscalDevice = routeMapObject.getValue();
					TerminationPointBuilder terminationPointBuilder = new TerminationPointBuilder();
					terminationPointBuilder.buildTerminationPoint(null, null, null, null);
					terminationPointBuilder.addAccessPointAddress(address);
					/*terminationPointBuilder.addResourceDescribedBy("RestrictedAddressFlag",restrictedFlag);
					terminationPointBuilder.addResourceDescribedBy("RestrictionReason",restrictionReason);
					terminationPointBuilder.addResourceDescribedBy("FiberDropIndicator",fiberDropIndiactor);
					terminationPointBuilder.addResourceDescribedBy("FiberDropType",fiberDropType);*/
					TerminationPointBuilder terminationPointBuilder1 = new TerminationPointBuilder();
					terminationPointBuilder1.buildTerminationPoint(null, null, null, null);
					//terminationPointBuilder1.addAccessPointAddress(address);
					//terminationPointBuilder.addLogicalPhysicalResource(routeBuilderObject.getRoute().getTopologicalLinkListArray(0).getAEndTpsArray(0).getLogicalPhysicalResourceArray(0));
					List<TopologicalLink> topologicList = routeBuilderObject.getRoute().getTopologicalLinkListList();
					boolean isPonCircuitExist = false;
					for(TopologicalLink topLink: topologicList){
						if(("ONT2MST".equalsIgnoreCase(topLink.getCommonName()) || (topLink.getCommonName().contains("ONT2"))) && topLink.getAEndTpsList() != null && !topLink.getAEndTpsList().isEmpty() && topLink.getAEndTpsList().size() > 0){
							terminationPointBuilder.addLogicalPhysicalResource(topLink.getAEndTpsList().get(0).getLogicalPhysicalResourceArray(0));
							List<ResourceCharacteristicValue> charactersticList = topLink.getAEndTpsList().get(0).getLogicalPhysicalResourceArray(0).getPhysicalDevice().getResourceDescribedByList();
							for(ResourceCharacteristicValue charactersticValue: charactersticList){
								if("PONCircuitExist".equalsIgnoreCase(charactersticValue.getCharacteristicName()) && "1".equalsIgnoreCase(charactersticValue.getCharacteristicValue())){
									isPonCircuitExist = true;
								}
							}
						}
						if(oltPhyscalDevice != null && oltPhyscalDevice.getLogicalPhysicalResource() != null){
							terminationPointBuilder1.addLogicalPhysicalResource(oltPhyscalDevice.getLogicalPhysicalResource());
						}else if("SPLITTER2OLT".equalsIgnoreCase(topLink.getCommonName()) && topLink.getZEndTpsList() != null && !topLink.getZEndTpsList().isEmpty() && topLink.getZEndTpsList().get(0) != null){
							terminationPointBuilder1.addLogicalPhysicalResource(topLink.getZEndTpsList().get(0).getLogicalPhysicalResourceArray(0));
						}
					}
					subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
					if(isPonCircuitExist){
						subNetworkConnectionBuilder.buildSubNetworkConnection("PON Circuit"+ponCircuitCount, null, null, "ARM", null, null, null, null);
						ponCircuitCount++;
					}else{
						subNetworkConnectionBuilder.buildSubNetworkConnection("Potential Fiber Assignment Path - Ckt  with  no identifier"+circuitCount, null, null, "ARM", null, null, null, null);
						isPonCircuitExist = false;
						circuitCount++;
					}
					subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder1.getTerminationPoint());
					subNetworkConnectionBuilder.addAEndTps(terminationPointBuilder.getTerminationPoint());
					subNetworkConnectionBuilder.addRoute(routeBuilderObject.getRoute());
					subNetWorkList.add(subNetworkConnectionBuilder);
				}
				routeMap = null;
			}
			//} end for each service area call
			for(SubNetworkConnectionBuilder netWorkCircuit: subNetWorkList){
				searchResponseDetailsBuilder.addCircuit(netWorkCircuit.getSubNetworkConnection());
			}

			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), requestObject);
		}catch (Exception e) {
			LOG.info("****** Caught Exception in LoopQual ******* "+e);
			return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, "", requestObject);

		}


		//End Call performGPONLoopQual HV API


		//return null;

	}

	
	private HashMap<RouteBuilder, LogicalPhysicalResourceBuilder> createONTOLTTopologicalLink(HashMap<String, Object> loopQualMap, List<TopologicalLinkBuilder> fdTopologicalLinkList, String location, List<TopologicalLinkBuilder> splitterTopologicalList){


		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();
		String commonName = "ONT";
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		HashMap<RouteBuilder, LogicalPhysicalResourceBuilder> routeListMap = new HashMap<RouteBuilder, LogicalPhysicalResourceBuilder>();
		RouteBuilder routeBuilder = null;
		
		//List<RouteBuilder> routeList = new ArrayList<RouteBuilder>();
		PhysicalDeviceBuilder physicalDeviceBuilder = null;
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder(); 
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();

		try{
			ARRAY ontNodesArray = (ARRAY) loopQualMap.get("o_ONTNodes");
			Datum[] elements = ontNodesArray.getOracleArray();

			/*for (int i=0;i<elements.length;i++){
				Object[] ontRecords = ((STRUCT) elements[i]).getAttributes();
				ARRAY ontArray = (ARRAY)ontRecords[0];
				Datum[] ontNodes = ontArray.getOracleArray();*/
			if(elements != null && elements.length > 0){
				for (int j=0;j<elements.length;j++){
					//ONT Topological AEnds Link
					Object[] ontRecord = ((STRUCT) elements[j]).getAttributes();
					if(ontRecord != null && ontRecord.length > 0){
						//commonName = getDeviceRole(commonName);
						physicalDeviceBuilder = new PhysicalDeviceBuilder();
						physicalDeviceBuilder.buildPhysicalDevice(commonName, null, ontRecord[1] != null ? (String)ontRecord[1]: null, null, null, null, null, null, null, null, ontRecord[3] != null ?(String)ontRecord[3]:null, null, ontRecord[2] != null ?(String)ontRecord[2]:null, null, null, null, null, null, ontRecord[4] != null ?(String)ontRecord[4]:null, null, null, null, null, null, null, null, null, null, null);
						physicalDeviceRoleBuilder.buildPhysicalDeviceRole(commonName);
						physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());// check it is there <!--Role to be NodeType ONT/Asset Type NID-->
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(location, null, null, null, null, null, null, null, null, null, null);
						physicalDeviceBuilder.addInstalledAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());

						PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
						physicalPortBuilder.buildPhysicalPort("Fiber Drop Device Port", null, null, null, null, null, null);
						//physicalPortBuilder.buildEntity("Fiber Drop Device Port", null, null, null);
						physicalPortBuilder.addResourceDescribedBy("FiberDropIndicator", loopQualMap.get("o_FiberDropIndicator") != null ? loopQualMap.get("o_FiberDropIndicator").toString(): null);
						physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());

						
						physicalDeviceBuilder.addResourceDescribedBy("ONTTYPE",ontRecord[0] != null ? ontRecord[0].toString(): null);
						//physicalDeviceBuilder.addResourceDescribedBy("ONT_SWVersion",ontRecord[4] != null ? ontRecord[4].toString(): null);
						physicalDeviceBuilder.addResourceDescribedBy("ONTMAKE",ontRecord[3] != null ? (String)ontRecord[3] : null);
						physicalDeviceBuilder.addResourceDescribedBy("ONTPowerSupply",ontRecord[5] != null ? (String)ontRecord[5] : null);
						physicalDeviceBuilder.addResourceDescribedBy("ONTPortCapacity",ontRecord[6] != null ? ontRecord[6].toString(): null);
						physicalDeviceBuilder.addResourceDescribedBy("PONCircuitExist",ontRecord[7] != null ? ontRecord[7].toString() : null);
						physicalDeviceBuilder.addResourceDescribedBy("ONTMDU",ontRecord[9] != null ? ontRecord[9].toString(): null);
						physicalDeviceBuilder.addResourceDescribedBy("MaxDownStreamRate",ontRecord[11] != null ? ontRecord[11].toString():null);
						physicalDeviceBuilder.addResourceDescribedBy("MaxUpStreamRate",ontRecord[12] != null ?ontRecord[12].toString():null);
						physicalDeviceBuilder.addResourceDescribedBy("SelfInstallIndicator",ontRecord[10] != null ?ontRecord[10].toString(): null);
						
						
						logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//new one need to change
						logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
						connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);//new one need to change
						connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
						topologicalLinkBuilder.buildTopologicalLink("ONT2MST", null, null, null, "FD", null, null, null, null); //Need to check FDP and commonName
						topologicalLinkBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());

						if(ontRecord[7] != null && !"1".equalsIgnoreCase(ontRecord[7].toString())){
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(null);
						}
							
						//OLT Topological ZEnds Link
						//List<TopologicalLinkBuilder> oltTopologicalList = new ArrayList<TopologicalLinkBuilder>();
						//ARRAY oltRecordArray = (ARRAY)ontRecord[8];
						//Object[] oltRecord = ((STRUCT) ontRecord[8]).getAttributes();
						Object[] oltRecord = ontRecord[8] != null ? ((STRUCT) ontRecord[8]).getAttributes(): null;
						/*Datum[] ele = oltRecordArray.getOracleArray();
						
						for (int k=0;k<ele.length;k++){
							Object[] obj = ((STRUCT) ele[k]).getAttributes();
							ARRAY oltArray = (ARRAY)obj[0];
							Datum[] oltNodes = oltArray.getOracleArray();
							for (int n=0;n<oltNodes.length;n++){
								Object[] oltRecord = ((STRUCT) oltNodes[n]).getAttributes();*/
								if(oltRecord != null && oltRecord.length > 0 && splitterTopologicalList != null && splitterTopologicalList.size() == 0){

									PhysicalDeviceRoleBuilder hasPhysicalDeviceRoles = new PhysicalDeviceRoleBuilder();
									ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
									hasPhysicalDeviceRoles.buildPhysicalDeviceRole("OLT");
									physicalDeviceBuilder.buildPhysicalDevice("OLT", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
									physicalDeviceBuilder.addHasPhysicalDeviceRoles(hasPhysicalDeviceRoles.getPhysicalDeviceRole());// check it is there <!--Role to be NodeType ONT-->
									americanPropertyAddressBuilder.buildAmericanPropertyAddress(location, null, null, null, null, null, null, null, null, null, null);
									physicalDeviceBuilder.addInstalledAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
									resourceRelationshipBuilder.buildResourceRelationship(null, fdh, null, null, null);


									
									physicalDeviceBuilder.addResourceDescribedBy("OLTPortIdentifier",null);
									physicalDeviceBuilder.addResourceDescribedBy("DropPortcount",null);
									physicalDeviceBuilder.addResourceDescribedBy("ConsumedPortcount",null);
									physicalDeviceBuilder.addResourceDescribedBy("PrismNosaCertifiedOLT",oltRecord[0] != null ? oltRecord[0].toString(): null);
									physicalDeviceBuilder.addResourceDescribedBy("1GBPSOLT",oltRecord[1] != null ? oltRecord[1].toString(): null);
									physicalDeviceBuilder.addResourceDescribedBy("MaxOfferedSubsBW",oltRecord[3] != null ? oltRecord[3].toString():null);
									physicalDeviceBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());

									physicalPortBuilder = new PhysicalPortBuilder();
									physicalPortBuilder.buildPhysicalPort(null, null, null, null, null, null, null);
									physicalPortBuilder.addResourceDescribedBy("OLTPortPONCktCount", null);
									physicalPortBuilder.addResourceDescribedBy("OLTMaxPONCkt", null);
									physicalPortBuilder.addResourceDescribedBy("OLTMaxSubcriber", null);
									physicalPortBuilder.addResourceDescribedBy("OLTPortSubscriberCount", null);
									physicalPortBuilder.addResourceDescribedBy("OLTPortSubsCapacity", oltRecord[2] != null ? (String)oltRecord[2]: null);
									physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());


									//TopologicalLinkBuilder topologicalLinkBuilder1 = new TopologicalLinkBuilder();
									logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//new one need to change
									logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
									/*connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
									connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
									topologicalLinkBuilder1.buildTopologicalLink("SPLITTER2OLT", null, null, null, "Fiber Link", null, null, null, null);
									topologicalLinkBuilder1.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
									physicalDeviceBuilder.buildPhysicalDevice(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
									logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//new one need to change
									logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
									connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
									connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
									topologicalLinkBuilder1.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());*/
									//oltTopologicalList.add(topologicalLinkBuilder1);
								}
						//	}
						//}
									//ONTMST LINK
								if(splitterTopologicalList != null && splitterTopologicalList.size() > 0){
									List<TopologicalLinkBuilder> topologicalList = new ArrayList<TopologicalLinkBuilder>();
									for(Object fdTopologicalObject: fdTopologicalLinkList){
										TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) fdTopologicalObject;
										TopologicalLinkBuilder topologicalALinkBuilder = new TopologicalLinkBuilder();
										topologicalALinkBuilder.buildTopologicalLink("ONT2"+topologicalLink.getTopologicalLink().getZEndTpsArray(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice().getCommonName(), null, null, null, "FD", null, null, null, null); //Need to check FDP and commonName
										topologicalALinkBuilder.addAEndTps(topologicalLinkBuilder.getTopologicalLink().getAEndTpsArray(0));
										topologicalALinkBuilder.addZEndTps(topologicalLink.getTopologicalLink().getZEndTpsArray(0));
										topologicalList.add(topologicalALinkBuilder);
									}
									
									for(Object oltTopologicalObject: splitterTopologicalList){
										TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) oltTopologicalObject;
										for(Object topologicalObject: topologicalList){
											TopologicalLinkBuilder topological = (TopologicalLinkBuilder) topologicalObject;
											LogicalPhysicalResourceBuilder oltLogicalLink= new LogicalPhysicalResourceBuilder();
											routeBuilder = new RouteBuilder();
											routeBuilder.buildRoute();
											routeBuilder.addTopologicalLink(topologicalLink.getTopologicalLink());
											routeBuilder.addTopologicalLink(topological.getTopologicalLink());
											routeListMap.put(routeBuilder, oltLogicalLink);
											//routeList.add(routeBuilder);
										}
									}
									/*if(routeBuilder != null && topologicalList != null && topologicalList.size() > 0){
										for(Object topologicalObject: topologicalList){
											TopologicalLinkBuilder topological = (TopologicalLinkBuilder) topologicalObject;
											routeBuilder = new RouteBuilder();
											routeBuilder.buildRoute();
											routeBuilder.addTopologicalLink(topologicalLink.getTopologicalLink());
											routeBuilder.addTopologicalLink(topological.getTopologicalLink());
											routeListMap.put(key, value);
											
											//routeList.add(routeBuilder);
										}
									}*/
									
								}else{
									for(Object fdTopologicalObject: fdTopologicalLinkList){
										TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) fdTopologicalObject;
										TopologicalLinkBuilder topologicalALinkBuilder = new TopologicalLinkBuilder();
										topologicalALinkBuilder.buildTopologicalLink("ONT2"+topologicalLink.getTopologicalLink().getZEndTpsArray(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice().getCommonName(), null, null, null, "FD", null, null, null, null); //Need to check FDP and commonName
										topologicalALinkBuilder.addAEndTps(topologicalLinkBuilder.getTopologicalLink().getAEndTpsArray(0));
										topologicalALinkBuilder.addZEndTps(topologicalLink.getTopologicalLink().getZEndTpsArray(0));
										routeBuilder = new RouteBuilder();
										routeBuilder.buildRoute();
										routeBuilder.addTopologicalLink(topologicalALinkBuilder.getTopologicalLink());
										//routeBuilder.addTopologicalLink(topological.getTopologicalLink());
										routeListMap.put(routeBuilder,logicalPhysicalResourceBuilder);
										//topologicalList.add(topologicalALinkBuilder);
									}
									
								}
					}
			
				}
			}else{
				TopologicalLinkBuilder topologicalLinkBuilderOnt = createEmptyONTTopologicalLink();
				List<TopologicalLinkBuilder> topologicalList = new ArrayList<TopologicalLinkBuilder>();
				if(splitterTopologicalList != null && splitterTopologicalList.size() > 0){
					topologicalList = new ArrayList<TopologicalLinkBuilder>();
					for(Object fdTopologicalObject: fdTopologicalLinkList){
						TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) fdTopologicalObject;
						TopologicalLinkBuilder topologicalALinkBuilder = new TopologicalLinkBuilder();
						topologicalALinkBuilder.buildTopologicalLink("ONT2"+topologicalLink.getTopologicalLink().getZEndTpsArray(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice().getCommonName(), null, null, null, "FD", null, null, null, null); //Need to check FDP and commonName
						topologicalALinkBuilder.addAEndTps(topologicalLinkBuilderOnt.getTopologicalLink().getAEndTpsArray(0));
						topologicalALinkBuilder.addZEndTps(topologicalLink.getTopologicalLink().getZEndTpsArray(0));
						topologicalList.add(topologicalALinkBuilder);
					}

					for(Object oltTopologicalObject: splitterTopologicalList){
						TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) oltTopologicalObject;
						for(Object topologicalObject: topologicalList){
							TopologicalLinkBuilder topological = (TopologicalLinkBuilder) topologicalObject;
							LogicalPhysicalResourceBuilder oltLogicalLink= new LogicalPhysicalResourceBuilder();
							routeBuilder = new RouteBuilder();
							routeBuilder.buildRoute();
							routeBuilder.addTopologicalLink(topologicalLink.getTopologicalLink());
							routeBuilder.addTopologicalLink(topological.getTopologicalLink());
							routeListMap.put(routeBuilder, oltLogicalLink);
							//routeList.add(routeBuilder);
						}
					}
				}else{
					for(Object fdTopologicalObject: fdTopologicalLinkList){
						TopologicalLinkBuilder topologicalLink = (TopologicalLinkBuilder) fdTopologicalObject;
						LogicalPhysicalResourceBuilder oltLogicalLink= new LogicalPhysicalResourceBuilder();
						TopologicalLinkBuilder topologicalALinkBuilder = new TopologicalLinkBuilder();
						topologicalALinkBuilder.buildTopologicalLink("ONT2"+topologicalLink.getTopologicalLink().getZEndTpsArray(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice().getCommonName(), null, null, null, "FD", null, null, null, null); //Need to check FDP and commonName
						topologicalALinkBuilder.addAEndTps(topologicalLinkBuilderOnt.getTopologicalLink().getAEndTpsArray(0));
						topologicalALinkBuilder.addZEndTps(topologicalLink.getTopologicalLink().getZEndTpsArray(0));
						routeBuilder = new RouteBuilder();
						routeBuilder.buildRoute();
						routeBuilder.addTopologicalLink(topologicalALinkBuilder.getTopologicalLink());
						//routeBuilder.addTopologicalLink(topological.getTopologicalLink());
						routeListMap.put(routeBuilder, oltLogicalLink);
						//topologicalList.add(topologicalALinkBuilder);
					}

				}
			}
			//}
			//}
		}catch(Exception e){
			LOG.info("Exception in ONT: "+e);
			//throw e;
		}

		return routeListMap;
	
	}
	
	private final List<TopologicalLinkBuilder> createSplitterOLTTopologicalLink(String splitterName, String fdh, HashMap<String, Object> splitterMap,List<RouteBuilder> routeList, HashMap<String, Object> loopQualMap, List<TopologicalLinkBuilder> fdTopologicalLinkList){

		//Splitter Topological AEnds Link		
			if(splitterMap != null && splitterMap.size() > 0){
				try{
					ARRAY splitterNodeArray = (ARRAY) splitterMap.get("o_Splittercap");
					Datum[] elements = splitterNodeArray != null? splitterNodeArray.getOracleArray(): null;
					for(int i= 0; i< elements.length; i++){
						Object[] splitterRecord = ((STRUCT) elements[i]).getAttributes();
						if(splitterRecord != null && splitterRecord.length > 0){
							TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();
							ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
							ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
							LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
							AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
							PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
							PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder(); 
							String commonName = getDeviceRole(query+(splitterName != null ? splitterName : "")+appendQuery);
							physicalDeviceRoleBuilder.buildPhysicalDeviceRole(commonName != null ? commonName : null);
							physicalDeviceBuilder.buildPhysicalDevice(commonName != null ? commonName : null, null, null, null, null, null, null, null, null, null,splitterRecord[5] != null ? (String)splitterRecord[5] : null, null, null, null);
							physicalDeviceBuilder.addResourceDescribedBy("SplitterPort",loopQualMap.get("o_SplitterPort") != null ? (String)loopQualMap.get("o_SplitterPort"):null);
							physicalDeviceBuilder.addResourceDescribedBy("DropPortcount",splitterRecord[1] != null? splitterRecord[1].toString():null);
							physicalDeviceBuilder.addResourceDescribedBy("ConsumedPortcount",splitterRecord[2] != null ? splitterRecord[2].toString():null);
							physicalDeviceBuilder.addResourceDescribedBy("OLTMaxOfferedSubsBW",splitterRecord[15] != null ? splitterRecord[15].toString():null);
							physicalDeviceBuilder.addResourceDescribedBy("FDNodePortCapacity",null);//(String)loopQualMap.get("o_FDNodesPortCapacity"));
							physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
							americanPropertyAddressBuilder.buildAmericanPropertyAddress(splitterMap.get("o_SplitterLocation") != null ? (String)splitterMap.get("o_SplitterLocation"):null, null, null, null, null, null, null, null, null, null, null);//need to check for the location or any other value
							physicalDeviceBuilder.addInstalledAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
							resourceRelationshipBuilder.buildResourceRelationship(null, fdh != null ? fdh : null, null, null, null);


							physicalDeviceBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//need to change
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							topologicalLinkBuilder.buildTopologicalLink("SPLITTER2OLT", null, null, null, "Fiber Link", null, null, null, null); //Need to check FDP and commonName
							topologicalLinkBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());

							//OLT Topological ZEnds Link

							PhysicalDeviceRoleBuilder hasPhysicalDeviceRoles = new PhysicalDeviceRoleBuilder();
							commonName = getDeviceRole(query+splitterRecord[3]+appendQuery);
							if(commonName == null) commonName = "OLT";
							hasPhysicalDeviceRoles.buildPhysicalDeviceRole(commonName);
							physicalDeviceBuilder.buildPhysicalDevice(commonName, null, null, null, null, null, null, null, null, null, splitterRecord[5] != null?(String)splitterRecord[5]:null, null, splitterRecord[4] != null ? (String)splitterRecord[4] : null, null, null, null, null, null, splitterRecord[6] != null? (String)splitterRecord[6]:null, null, null, null, null, null, null, null, null, null, null);
							physicalDeviceBuilder.addHasPhysicalDeviceRoles(hasPhysicalDeviceRoles.getPhysicalDeviceRole());// check it is there <!--Role to be NodeType ONT-->
							americanPropertyAddressBuilder.buildAmericanPropertyAddress(null, null, null, null, null, null, null, null, null, null, null);
							physicalDeviceBuilder.addInstalledAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());

							physicalDeviceBuilder.addResourceDescribedBy("OLTPortIdentifier",splitterRecord[7] != null ? (String)splitterRecord[7]: null);
							physicalDeviceBuilder.addResourceDescribedBy("DropPortcount",splitterRecord[1] != null ? splitterRecord[1].toString(): null);
							physicalDeviceBuilder.addResourceDescribedBy("ConsumedPortcount",splitterRecord[2] != null ? splitterRecord[2].toString():null);
							physicalDeviceBuilder.addResourceDescribedBy("PrismNosaCertifiedOLT",splitterRecord[11] != null ? splitterRecord[11].toString(): null);
							physicalDeviceBuilder.addResourceDescribedBy("1GBPSOLT",splitterRecord[12] != null ? splitterRecord[12].toString():null);
							physicalDeviceBuilder.addResourceDescribedBy("MaxOfferedSubsBW",splitterRecord[15] !=null ? splitterRecord[15].toString():null);

							PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
							physicalPortBuilder.buildPhysicalPort(null, null, null, null, null, splitterRecord[9] != null ? (String)splitterRecord[9]:null, null);
							physicalPortBuilder.addResourceDescribedBy("OLTPortPONCktCount", splitterRecord[8] != null ? splitterRecord[8].toString(): null);
							physicalPortBuilder.addResourceDescribedBy("OLTMaxPONCkt", splitterRecord[10] != null ? splitterRecord[10].toString():null);
							physicalPortBuilder.addResourceDescribedBy("OLTMaxSubcriber", splitterRecord[13] != null ? splitterRecord[13].toString():null);
							physicalPortBuilder.addResourceDescribedBy("OLTPortSubscriberCount", splitterRecord[14] != null ? splitterRecord[14].toString():null);
							physicalPortBuilder.addResourceDescribedBy("OLTPortSubsCapacity", null); //(String)splitterMap.get("need to check how to get it from OLTTerminationRecord	");
							physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());


							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//need to change
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);//need to change
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							topologicalLinkBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
							splitterList.add(topologicalLinkBuilder);
							/*for(TopologicalLinkBuilder topologicalLink: fdTopologicalLinkList){
				topologicalLink = createEmptyONTTopologicalLink(topologicalLink, loopQualMap);
				RouteBuilder routeBuilder = new RouteBuilder();
				routeBuilder.buildRoute();
				if(topologicalLinkBuilder.getTopologicalLink().getAEndTpsArray(0).getLogicalPhysicalResourceArray(0).getPhysicalDevice().getResourceDescribedByList().add(e)){
					String fdNodeCapacityValue = topologicalLinkBuilder.getTopologicalLink().getAEndTpsArray(0).getLogicalPhysicalResourceArray(0).getPhysicalDevice().getResourceDescribedByList().get(0).
					ResourceCharacteristicValue rcv = ResourceCharacteristicValue.Factory.newInstance();
					rcv.setCharacteristicName("FDNodePortCapacity");
					rcv.setCharacteristicValue(characteristicValue);
					topologicalLinkBuilder.getTopologicalLink().getAEndTpsArray(0).getLogicalPhysicalResourceArray(0).getPhysicalDevice().getResourceDescribedByList().add(rcv);
				}
				routeBuilder.addTopologicalLink(topologicalLink.getTopologicalLink());
				routeBuilder.addTopologicalLink(topologicalLinkBuilder.getTopologicalLink());
				if (routeList != null && routeList.size() > 0) routeList.add(routeBuilder);
			}*/
						}
					}
				}catch(Exception e){

				}
			}

			return splitterList;
	}
	private List<TopologicalLinkBuilder> createFiberDropLink(ARRAY fdNodeArray){

		List<TopologicalLinkBuilder> fdTopologicalLinkList = new ArrayList<TopologicalLinkBuilder>();

		try{
			Datum[] elements = fdNodeArray.getOracleArray();

			for (int i=0;i<elements.length;i++){
				TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();
				
				ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
				LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
				PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
				PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder(); 
				String commonName = null;
				
				Object[] fdRecArray = ((STRUCT) elements[i]).getAttributes();
				/*ARRAY fdArray = (ARRAY)element[0];
				Datum[] fdRecord = fdArray.getOracleArray();
				for (int j=0;i<fdRecord.length;j++){
					Object[] fdRecArray = ((STRUCT) fdRecord[j]).getAttributes();*/
					commonName = getDeviceRole(query+(String)fdRecArray[0]+appendQuery);
					physicalDeviceRoleBuilder.buildPhysicalDeviceRole(commonName);//need to check what is this commonName
					physicalDeviceBuilder.buildPhysicalDevice(commonName, null, null, null,null , null, null, null, null, null, null, null, null, null);//need to add vendor and model name
					physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
					
					if((String)fdRecArray[2] != null){
						String[] countArray = ((String)fdRecArray[2]).split("/");
						physicalDeviceBuilder.addResourceDescribedBy("FDNodePortCapacity",fdRecArray[2] != null ? (String)fdRecArray[2]:null);
						physicalDeviceBuilder.addResourceDescribedBy("DropPortcount",countArray[1] != null ? countArray[1]:null);
						physicalDeviceBuilder.addResourceDescribedBy("ConsumedPortcount",countArray[0] != null ? countArray[0]:null);
					}

					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);//new one need to change
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
					connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);//new one need to change
					connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					topologicalLinkBuilder.buildTopologicalLink("ONT2"+commonName, null, null, null, "FD", null, null, null, null);
					topologicalLinkBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
					fdTopologicalLinkList.add(topologicalLinkBuilder);
				}
			//}
		}catch(Exception e){
			LOG.info("Caught exception in createFiberDropLink method of SearchCircuitService"+e);
			//throw e;
		}
		return fdTopologicalLinkList;
	
	}
	
	private TopologicalLinkBuilder createEmptyONTTopologicalLink(){
		
		TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();

		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();

		physicalDeviceBuilder.buildPhysicalDevice("ONT Not Known", null, null, null, null, null, null, null, null, null, null, null, null, null);
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
		logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
		connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
		connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
		
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder1 = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder1 = new LogicalPhysicalResourceBuilder();
		PhysicalDeviceBuilder physicalDeviceBuilder1 = new PhysicalDeviceBuilder();

		physicalDeviceBuilder1.buildPhysicalDevice(null, null, null, null, null, null, null, null, null, null, null, null, null, null);
		logicalPhysicalResourceBuilder1.buildLogicalPhysicalResource(null, null, null, null, null);
		logicalPhysicalResourceBuilder1.addPhysicalDeviceAsDevice(physicalDeviceBuilder1.getPhysicalDevice());
		connectionTerminationPointBuilder1.buildConnectionTerminationPoint(null, null, null);
		connectionTerminationPointBuilder1.addLogicalPhysicalResource(logicalPhysicalResourceBuilder1.getLogicalPhysicalResource());
		topologicalLinkBuilder.buildTopologicalLink("ONT2MST", null, null, null, "FD", null, null, null, null); 
		topologicalLinkBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
		topologicalLinkBuilder.addZEndTps(connectionTerminationPointBuilder1.getConnectionTerminationPoint());
		return topologicalLinkBuilder;
	}
	
	public String getDeviceRole(String query){
		try{
			LOG.info("Get Device Role: "+query);
			List<String> roleList = searchDeviceDAO.getNetworkRole(query);
			if(roleList != null && roleList.size() > 0)
				return (roleList.get(0).split(" "))[0];
		}catch(Exception e){
			LOG.info("Exception in identifying network device names: "+e);
			//throw e;
		}
		return null;
	}
	
	public SearchResourceResponseDocument getException(Exception e, SearchResourceRequestDocument requestObject){
		if(e instanceof ICLException){
			return MediationUtil.getSearchResourceErrorResponse(((ICLException)e).getErrorCode(), ((ICLException)e).getErrorText(), ((ICLException)e).getMessage(), requestObject);
		}else if(e instanceof ValueObjectDataIntegrityException){
			return MediationUtil.getSearchResourceErrorResponse(((ValueObjectDataIntegrityException)e).getErrorCode(), ((ValueObjectDataIntegrityException)e).getErrorText(), ((ValueObjectDataIntegrityException)e).getMessage(), requestObject);
		}else if(e instanceof NullPointerException){
			return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR,"NullPointerException", requestObject);
		}else{
			return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR,"", requestObject);
		}
	}
	private List<Service> checkHSIService(String commonName)
	{
		String qyery = " upper(service.name) = '" + commonName
				+ "' and service.service2servicetype=1920000002 ";
		Service service = new Service();
		List<Service> services = service.getServiceListByQuery(qyery);
		System.out.println("Test" + services.size());
		return services;
		// return checkHSIService(qyery);
	}

}