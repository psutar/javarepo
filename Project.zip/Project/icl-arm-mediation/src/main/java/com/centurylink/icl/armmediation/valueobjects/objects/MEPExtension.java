package com.centurylink.icl.armmediation.valueobjects.objects;



import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class MEPExtension extends AbstractReadOnlyTable  {

	private static String CCMLTMPRIORITY="CCMLTMPRIORITY";
	private static String DIRECTION="DIRECTION";
	private static String MACADDRESS="MACADDRESS";
	private static String CCIENABLED="CCIENABLED";
	private static String FAULTRESETTIME="FAULTRESETTIME";
	private static String PRIMARYVLANID="PRIMARYVLANID";
	private static String FAULTALARMTIME="FAULTALARMTIME";
	private static String LOWESTPRIORITYDEFECT="LOWESTPRIORITYDEFECT";
	private static String MEG_LEVEL="MEG_LEVEL";
	private static String DIMNUMBERID="DIMNUMBERID";
	
	public MEPExtension()
	{
		super();
		this.tableName = "EXT_NUMBER_MEP";
	}

	public MEPExtension(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	/*public MEPExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		getRecordByPrimaryKey();
		this.instanciated = true;
	}*/
	public static List<MEPExtension> getMEPbjectList(String dimNumberId)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(dimNumberId))
		{
			query = DIMNUMBERID + " = '" +  dimNumberId + "'";
			connector = " AND ";
		}
		
		
		return getMEPListByQuery(query);
	}

	public static List<MEPExtension> getMEPListByQuery(String query)
	{
		MEPExtension mepExtension = new MEPExtension();
		List<MEPExtension> mepExtensionList = new ArrayList<MEPExtension>();
		List<Map<String,Object>> foundMepExtensionList = mepExtension.getRecordsByQuery(query);

		for (Map<String,Object> mepExtensionMap : foundMepExtensionList)
		{
			MEPExtension workMepExtension = new MEPExtension(mepExtensionMap.get(DIMNUMBERID).toString());
			mepExtensionList.add(workMepExtension);
		}
		return mepExtensionList;
		
		
	}
	
	@Override
	public void populateModel() {
		//Tushar Added for the AUC263845
		fields.put(MEG_LEVEL, new Field(MEG_LEVEL, Field.TYPE_NUMERIC));
		fields.put(LOWESTPRIORITYDEFECT, new Field(LOWESTPRIORITYDEFECT, Field.TYPE_NUMERIC));
		fields.put(CCMLTMPRIORITY, new Field(CCMLTMPRIORITY, Field.TYPE_NUMERIC));
		fields.put(DIRECTION, new Field(DIRECTION, Field.TYPE_NUMERIC));
		fields.put(CCIENABLED, new Field(CCIENABLED, Field.TYPE_NUMERIC));
		fields.put(PRIMARYVLANID, new Field(PRIMARYVLANID, Field.TYPE_NUMERIC));
		fields.put(MACADDRESS, new Field(MACADDRESS, Field.TYPE_VARCHAR));
		fields.put(DIMNUMBERID, new Field(DIMNUMBERID, Field.TYPE_NUMERIC));
		fields.put(FAULTRESETTIME, new Field(FAULTRESETTIME, Field.TYPE_FLOAT));
		fields.put(FAULTALARMTIME, new Field(FAULTALARMTIME, Field.TYPE_FLOAT));
		
		primaryKey = new PrimaryKey(fields.get(DIMNUMBERID));
	}

	public String getCcmltmpriority() {
		return getFieldAsString(CCMLTMPRIORITY);
	}

	public void setCcmltmpriority(String ccmltmpriority) {
		setField(CCMLTMPRIORITY,ccmltmpriority);
	}

	public String getDirection() {
		return getFieldAsString(DIRECTION);
	}

	public void setDirection(String direction) {
		setField(DIRECTION,direction);
	}

	public String getMacaddress() {
		return getFieldAsString(MACADDRESS);
	}

	public void setMacaddress(String macaddress) {
		setField(MACADDRESS,macaddress);
	}

	public String getCcienabled() {
		return getFieldAsString(CCIENABLED);
	}

	public void setCcienabled(String ccienabled) {
		setField(CCIENABLED,ccienabled);
	}

	public String getFaultresettime() {
		return getFieldAsString(FAULTRESETTIME);
	}

	public void setFaultresettime(String faultresettime) {
		setField(FAULTRESETTIME,faultresettime);
	}

	public String getPrimaryvlanid() {
		return getFieldAsString(PRIMARYVLANID);
	}

	public void setPrimaryvlanid(String primaryvlanid) {
		setField(PRIMARYVLANID,primaryvlanid);
	}

	public String getFaultalarmtime() {
		return getFieldAsString(FAULTALARMTIME);
	}

	public void setFaultalarmtime(String faultalarmtime) {
		setField(FAULTALARMTIME,faultalarmtime);
	}

	public String getLowestprioritydefect() {
		return getFieldAsString(LOWESTPRIORITYDEFECT);
	}

	public void setLowestprioritydefect(String lowestprioritydefect) {
		setField(LOWESTPRIORITYDEFECT,lowestprioritydefect);
	}

	public String getMegLevel() {
		return getFieldAsString(MEG_LEVEL);
	}

	public void setMegLevel(String megLevel) {
		setField(MEG_LEVEL,megLevel);
	}
	public void setDimnumberId(String dimnumberId)
	{
		setField(DIMNUMBERID,dimnumberId);
	}

	public String getDimnumberId()
	{
		return getFieldAsString(DIMNUMBERID);
	}

}
