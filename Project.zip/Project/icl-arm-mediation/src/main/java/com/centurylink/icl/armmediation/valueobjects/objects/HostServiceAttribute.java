package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class HostServiceAttribute extends AbstractReadOnlyTable{
	
private static final String HSTSRVCATR="HSTSRVCATR";	
private static final String HSTSRVCATRID="HSTSRVCATRID";
private static final String ISCOMPLETEINPLAN="ISCOMPLETEINPLAN";
private static final String NAME="NAME";
private static final String ALIAS2="ALIAS2";
private static String HSTSRVCATR2HSTSRVCATRTYPE ="HSTSRVCATR2HSTSRVCATRTYPE";

public HostServiceAttribute()
{
	super();
	this.tableName = HSTSRVCATR;
}

public HostServiceAttribute(String key)
{
	this();
	primaryKey.setValue(key);
	getRecordByPrimaryKey();
	this.instanciated = true;
}


	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(HSTSRVCATRID, new Field(HSTSRVCATRID, Field.TYPE_NUMERIC));
		fields.put(HSTSRVCATR2HSTSRVCATRTYPE, new Field(HSTSRVCATR2HSTSRVCATRTYPE, Field.TYPE_NUMERIC));
		
		
		primaryKey = new PrimaryKey(fields.get(HSTSRVCATRID));
		
	}

	public String getHstsrvcatrid() {
		return getFieldAsString(HSTSRVCATRID);
	}

	public void setHstsrvcatrid(String hstsrvcatrid) {
		setField(HSTSRVCATRID,hstsrvcatrid);
	}

	public String getIscompleteinplan() {
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setIscompleteinplan(String iscompleteinplan) {
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getName() {
		return getFieldAsString(NAME);
	}

	public void setName(String name) {
		setField(NAME,name);
	}

	public String getAlias2() {
		return getFieldAsString(ALIAS2);
	}

	public void setAlias2(String alias2) {
		setField(ALIAS2,alias2);
	}

	public String getHstsrvcatr2hstsrvcatrtype() {
		return getFieldAsString(HSTSRVCATR2HSTSRVCATRTYPE);
	}

	public void setHstsrvcatr2hstsrvcatrtype(String hstsrvcatr2hstsrvcatrtype) {
		setField(HSTSRVCATR2HSTSRVCATRTYPE,hstsrvcatr2hstsrvcatrtype);
	}

}
