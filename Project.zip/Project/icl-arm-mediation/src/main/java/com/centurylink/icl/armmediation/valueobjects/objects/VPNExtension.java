package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class VPNExtension extends AbstractReadOnlyTable {
	
		private static String DIMNUMBERID="DIMNUMBERID";
		private static String RPPLANID="RPPLANID";
		private static String ISVISIBLE="ISVISIBLE";
		private static String LABEL="LABEL";
		
		
		public VPNExtension()
		{
			super();
			this.tableName = "EXT_NUMBER_VPN";
		}

		public VPNExtension(String key)
		{
			this();
			primaryKey.setValue(key);
			getRecordByPrimaryKey();
			this.instanciated = true;
		}
		/*public MEPExtension(Field key, String tableName)
		{
			this();
			this.tableName = tableName;
			primaryKey.setValue(key.getValue());
			getRecordByPrimaryKey();
			this.instanciated = true;
		}*/
		public static List<VPNExtension> getVPNbjectList(String dimNumberId)
		{
			String connector = "";
			String query = "";
			
			if (!StringHelper.isEmpty(dimNumberId))
			{
				query = DIMNUMBERID + " = '" +  dimNumberId + "'";
				connector = " AND ";
			}
			
			
			return getVPNListByQuery(query);
		}

		public static List<VPNExtension> getVPNListByQuery(String query)
		{
			VPNExtension vpnExtension = new VPNExtension();
			List<VPNExtension> vpnExtensionList = new ArrayList<VPNExtension>();
			List<Map<String,Object>> foundVpnExtensionList = vpnExtension.getRecordsByQuery(query);

			for (Map<String,Object> vpnExtensionMap : foundVpnExtensionList)
			{
				VPNExtension workVpnExtension = new VPNExtension(vpnExtensionMap.get(DIMNUMBERID).toString());
				vpnExtensionList.add(workVpnExtension);
			}
			return vpnExtensionList;
			
			
		}
		
		@Override
		public void populateModel() {
			
			fields.put(DIMNUMBERID, new Field(DIMNUMBERID, Field.TYPE_NUMERIC));			
			
			primaryKey = new PrimaryKey(fields.get(DIMNUMBERID));
		}

		public void setDimnumberId(String dimnumberId)
		{
			setField(DIMNUMBERID,dimnumberId);
		}

		public String getDimnumberId()
		{
			return getFieldAsString(DIMNUMBERID);
		}
		

}
