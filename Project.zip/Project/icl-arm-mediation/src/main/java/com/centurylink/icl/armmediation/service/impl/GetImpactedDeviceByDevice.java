package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetImpactedDeviceByDevice 
{
	private static final Log LOG = LogFactory.getLog(GetImpactedDeviceByDevice.class);
	private String ND="ND";
	List<Circuit> circuitIDList=null;
	List<Circuit> parentCircuitList=null;
	HashMap<String,Node> dslamDeviceList= new HashMap<String,Node>() ;
	List<String> brasDeviceList= new ArrayList<String>() ;

	public HashMap<String,Node> getImpactedDeviceByDevice(SearchResourceRequestDocument requestObject)
	{
		return getOVCCircuit(requestObject);
	}

	protected HashMap<String,Node> getOVCCircuit(SearchResourceRequestDocument requestObject)
	{
		String deviceName=null;
		List<String> deviceNames=new ArrayList<String>();
		Node node=null;
		String Query=null;
		String deviceRole=null;

		deviceName = requestObject.getSearchResourceRequest().getSearchResourceDetails().getCommonName();

		if(deviceName!=null)
			Query="NODE.NAME='"+deviceName+"'";

		if(Query!=null)
			if(Node.getNodeListByQuery(Query)!=null&&Node.getNodeListByQuery(Query).size()>0)
				node=Node.getNodeListByQuery(Query).get(0);

		if(node!=null){
			deviceRole=node.getNetworkroleobjects().get(0).getNetworkroleobject2networkrole();
			System.out.println("deviceRole:"+deviceRole);

			if(deviceRole.equalsIgnoreCase("NPE"))
			{
				circuitIDList=Circuit.getCircuitListByQuery(getCircuitQuery(deviceName));
				for(Circuit circuit:circuitIDList) {
					String nodeName=null;
					//System.out.println(circuit.getCircuitid()+"##"+circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()+"###"+circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole());

					if(circuit.getStartNode()!=null)
						System.out.println("StartNode:"+circuit.getStartNode().getNodeid()+"###"+circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole());
					//case 1 NPE-DSLAM
					if((circuit.getStartNode()!=null && circuit.getStartNode().getNetworkroleobjects()!=null &&  circuit.getStartNode().getNetworkroleobjects()!=null && circuit.getStartNode().getNetworkroleobjects().size()>0 &&  
							circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))||

							(circuit.getEndNode()!=null&&circuit.getEndNode().getNetworkroleobjects()!=null && circuit.getEndNode().getNetworkroleobjects().size()>0 &&circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM")))
					{

						if(circuit.getStartNode()!=null&&circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{

							nodeName=circuit.getStartNode().getName();
							if(circuit.getStartPort()!=null)
								dslamDeviceList.put(circuit.getStartPort().getPortid(),circuit.getStartNode());
						}
						else if(circuit.getEndNode()!=null&&circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							nodeName=circuit.getEndNode().getName();
							if(circuit.getEndPort()!=null)
								dslamDeviceList.put(circuit.getEndPort().getPortid(),circuit.getEndNode());
						}


						if(nodeName!=null){
							System.out.println("DSLAM"+nodeName);}
					}


					//case 2 NPE-TD-DSLAM
					if((circuit.getStartNode()!=null&&circuit.getStartNode().getNetworkroleobjects()!=null && circuit.getStartNode().getNetworkroleobjects().size()>0 &&circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))||
							(circuit.getEndNode()!=null&&circuit.getEndNode().getNetworkroleobjects()!=null && circuit.getEndNode().getNetworkroleobjects().size()>0 &&circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD")))
					{

						String tdDevice=null;
						if(circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))
							tdDevice=circuit.getStartNode().getName();
						else 
							if(circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))
								tdDevice=circuit.getEndNode().getName();

						getDslamFromTd(tdDevice,circuitIDList);
					}

					// case 3 NPE-BRAS 
					if((circuit.getStartNode()!=null &&circuit.getStartNode().getNetworkroleobjects()!=null && circuit.getStartNode().getNetworkroleobjects().size()>0 && circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))||
							(circuit.getEndNode()!=null &&circuit.getEndNode().getNetworkroleobjects()!=null && circuit.getEndNode().getNetworkroleobjects().size()>0 && circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS")))
					{


						String brasDevice=null;
						if(circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))
							brasDevice=circuit.getStartNode().getName();
						else 
							if(circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))
								brasDevice=circuit.getEndNode().getName();

						getDSLAMFromBRAS(brasDevice);


					}
					
					
				}
			}
			else  if(deviceRole.equalsIgnoreCase("BRAS"))
			{
				
				getDSLAMFromBRAS(deviceName);
				
			}



			return dslamDeviceList;
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}


	public String getCircuitQuery(String deviceName)
	{
		SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.NODE,ND);

		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		String nodeTtables [] ={Constants.CIRCUIT,Constants.CIRCUIT, ND};
		String nodeColumnNames [] ={Constants.CIRCUIT_2_START_NODE,Constants.CIRCUIT_2_END_NODE,Constants.NODE_ID};
		sql.orClauseTables(nodeTtables, nodeColumnNames);
		sql.eq(ND, Constants.NAME,deviceName);
		//sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE,"150000059");

		String query = sql.getStatement();

		query=" CIRCUITID in("+query+")";

		if (LOG.isInfoEnabled())
		{
			LOG.info("getCircuitQuery :" + query);
		}

		System.out.println("getCircuitQuery :" + query);
		return query;

	}

	public void getDslamFromTd(String deviceName,List<Circuit> circuitList)
	{
		List<Circuit> associatedcircuitIDList=null;
		associatedcircuitIDList=Circuit.getCircuitListByQuery(getCircuitQuery(deviceName));

		for(Circuit circuit:associatedcircuitIDList) 
		{
			if(!isDuplicateCircuit(circuit.getCircuitid(),circuitList)){
				String nodeName=null;
				//	System.out.println(circuit.getCircuitid()+"##"+circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()+"###"+circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole());

				//case  TD-DSLAM
				if((circuit.getStartNode()!=null && circuit.getStartNode().getNetworkroleobjects()!=null &&  circuit.getStartNode().getNetworkroleobjects()!=null && circuit.getStartNode().getNetworkroleobjects().size()>0 &&  
						circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))||

						(circuit.getEndNode()!=null&&circuit.getEndNode().getNetworkroleobjects()!=null && circuit.getEndNode().getNetworkroleobjects().size()>0 &&circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))){

					if(circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
					{
						nodeName=circuit.getStartNode().getName();
						if(circuit.getStartPort()!=null)
							dslamDeviceList.put(circuit.getStartPort().getPortid(),circuit.getStartNode());
					}
					else if(circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
					{
						nodeName=circuit.getEndNode().getName();
						if(circuit.getEndPort()!=null)
							dslamDeviceList.put(circuit.getEndPort().getPortid(),circuit.getEndNode());
					}

					if(nodeName!=null)
					{
						System.out.println("DSLAM"+nodeName);
					}

				}


				//case TD-TD-***-DSLAM
				if(circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD")||
						circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))
				{
					String tdDevice=null;
					if(circuit.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))
						tdDevice=circuit.getStartNode().getName();
					else 
						if(circuit.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("TD"))
							tdDevice=circuit.getEndNode().getName();
					getDslamFromTd(tdDevice, associatedcircuitIDList);

				}

			}
		}
	}


	public void  getDSLAMFromBRAS(String brasDevice)
	{
		List<Circuit> brasCircuitsList = new ArrayList<Circuit>();
		brasCircuitsList=Circuit.getCircuitListByQuery(getCircuitQuery(brasDevice));

		if(brasCircuitsList!=null && brasCircuitsList.size()>0)
		{
			for(Circuit ckt:brasCircuitsList)
			{
				if(ckt!=null && ckt.getCircuittype().getName().equalsIgnoreCase("VLAN Segment"))
				{
					if(ckt.getAssociatedServices()!=null && ckt.getAssociatedServices().size()>0)
					{
						for(Service service:ckt.getAssociatedServices())
						{
							if(service!=null && service.getServicetype().getName().equalsIgnoreCase("DSL OVC"))
							{
								if(service.getAssociatedCircuits()!=null && service.getAssociatedCircuits().size()>0)
								{
									for(Circuit vlanCkt :service.getAssociatedCircuits())
									{
										if(vlanCkt!=null && vlanCkt.getCircuittype().getName().equalsIgnoreCase("VLAN Segment"))
										{
											if((vlanCkt.getStartNode()!=null && vlanCkt.getStartNode().getNetworkroleobjects()!=null && vlanCkt.getStartNode().getNetworkroleobjects().size()>0 && vlanCkt.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))||
													(vlanCkt.getEndNode()!=null&& vlanCkt.getEndNode().getNetworkroleobjects()!=null && vlanCkt.getEndNode().getNetworkroleobjects().size()>0 && vlanCkt.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM")))
											{
												if(vlanCkt.getStartNode()!=null && vlanCkt.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
												{

													if(vlanCkt.getStartPort()!=null)
														dslamDeviceList.put(vlanCkt.getStartPort().getTopLevelPort().getPortid(),vlanCkt.getStartNode());
												}
												else if(vlanCkt.getEndNode()!=null&& vlanCkt.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
												{

													if(vlanCkt.getEndPort()!=null)
														dslamDeviceList.put(vlanCkt.getEndPort().getTopLevelPort().getPortid(),vlanCkt.getEndNode());
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	boolean isDuplicateCircuit(String relatedCircuitID,List<Circuit> circuitList)
	{
		for(Circuit circuitID:circuitList)
		{
			if(circuitID.getCircuitid().equalsIgnoreCase(relatedCircuitID))
				return true;
		}
		return false;
	}

}
