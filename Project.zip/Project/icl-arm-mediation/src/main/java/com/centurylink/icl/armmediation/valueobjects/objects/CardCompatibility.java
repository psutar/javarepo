package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class CardCompatibility extends AbstractReadOnlyTable
{
	private static final String TABLENAME = "TABLENAME";
	private static final String CARDCOMPATIBILITYID = "CARDCOMPATIBILITYID";
	private static final String CARDCOMPATIBILITY2CARDTYPE = "CARDCOMPATIBILITY2CARDTYPE";
	private static final String CARDCOMPATIBILITY2SLOTTYPE = "CARDCOMPATIBILITY2SLOTTYPE";
	private static final String CARDCOMPATIBILITY2SHELFTYPE = "CARDCOMPATIBILITY2SHELFTYPE";
	private static final String SLOTNUMBER = "SLOTNUMBER";
	private static final String CARDCOMPATIBILITY2NODEDEF = "CARDCOMPATIBILITY2NODEDEF";
	private static final String CARDCOMPATIBILITY2CARDTYPE2 = "CARDCOMPATIBILITY2CARDTYPE2";
	private static final String SLOTPOSITION = "SLOTPOSITION";
	private static final Log LOG = LogFactory.getLog(CardCompatibility.class);
	public CardCompatibility()
	{
		super();
		this.tableName = "CARDCOMPATIBILITY";
	}

	public CardCompatibility(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public CardCompatibility(CardCompatibility template) {
		this();
		getRecordByTemplate(template);
		for (Field field : fields.values())
		{
			if (field.getValue() != null) {
				this.instanciated = true;
				break;
			}
		}		
	}
	
	public static List<CardCompatibility> getCardCompatibilityList(
			CardCompatibility template) {
		List<CardCompatibility> response = new ArrayList<CardCompatibility>();
		List<Map<String, Object>> records = template.getRecordsByTemplate();
		for (Map<String, Object> map : records) {
			CardCompatibility cardCompatibility = new CardCompatibility();
			cardCompatibility.instanciated = true;
			cardCompatibility.populateFields(map);
			response.add(cardCompatibility);
		}
		return response;
	}
	
	@Override
	public void populateModel() {
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(CARDCOMPATIBILITYID, new Field(CARDCOMPATIBILITYID, Field.TYPE_NUMERIC));
		fields.put(CARDCOMPATIBILITY2CARDTYPE, new Field(CARDCOMPATIBILITY2CARDTYPE, Field.TYPE_NUMERIC));
		fields.put(CARDCOMPATIBILITY2SLOTTYPE, new Field(CARDCOMPATIBILITY2SLOTTYPE, Field.TYPE_NUMERIC));
		fields.put(CARDCOMPATIBILITY2SHELFTYPE, new Field(CARDCOMPATIBILITY2SHELFTYPE, Field.TYPE_NUMERIC));
		fields.put(SLOTNUMBER, new Field(SLOTNUMBER, Field.TYPE_NUMERIC));
		fields.put(CARDCOMPATIBILITY2NODEDEF, new Field(CARDCOMPATIBILITY2NODEDEF, Field.TYPE_NUMERIC));
		fields.put(CARDCOMPATIBILITY2CARDTYPE2, new Field(CARDCOMPATIBILITY2CARDTYPE2, Field.TYPE_NUMERIC));
		fields.put(SLOTPOSITION, new Field(SLOTPOSITION, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CARDCOMPATIBILITYID));
		
	}
	
		
	public void setTableName(String tableName)
	{
		setField(TABLENAME,tableName);
	}
	
	public void setCardcompatibilityid(String cardcompatibilityid)
	{
		setField(CARDCOMPATIBILITYID,cardcompatibilityid);
	}
	
	public void setCardcompatibility2Cardtype(String cardcompatibility2Cardtype)
	{
		setField(CARDCOMPATIBILITY2CARDTYPE,cardcompatibility2Cardtype);
	}
	
	public void setCardcompatibility2slottype(String cardcompatibility2slottype)
	{
		setField(CARDCOMPATIBILITY2SLOTTYPE,cardcompatibility2slottype);
	}
	
	public void setCardcompatibility2shelftype(String cardcompatibility2shelftype)
	{
		setField(CARDCOMPATIBILITY2SHELFTYPE,cardcompatibility2shelftype);
	}
	
	public void setSlotNumber(String slotNumber)
	{
		setField(SLOTNUMBER,slotNumber);
	}
	
	public void setCardcompatibility2nodedef(String cardcompatibility2nodedef)
	{
		setField(CARDCOMPATIBILITY2NODEDEF,cardcompatibility2nodedef);
	}
	
	public void setCardcompatibility2cardtype2(String cardcompatibility2cardtype2)
	{
		setField(CARDCOMPATIBILITY2CARDTYPE2,cardcompatibility2cardtype2);
	}
	
	public void setSlotPosition(String slotPosition)
	{
		setField(SLOTPOSITION,slotPosition);
	}

	public String getTablename() {
		return getFieldAsString(TABLENAME);
	}

	public String getCardcompatibilityid() {
		return getFieldAsString(CARDCOMPATIBILITYID);
	}

	public String getCardcompatibility2cardtype() {
		return getFieldAsString(CARDCOMPATIBILITY2CARDTYPE);
	}

	public String getCardcompatibility2slottype() {
		return getFieldAsString(CARDCOMPATIBILITY2SLOTTYPE);
	}

	public String getCardcompatibility2shelftype() {
		return getFieldAsString(CARDCOMPATIBILITY2SHELFTYPE);
	}

	public String getSlotnumber() {
		return getFieldAsString(SLOTNUMBER);
	}

	public String getCardcompatibility2nodedef() {
		return getFieldAsString(CARDCOMPATIBILITY2NODEDEF);
	}

	public String getCardcompatibility2cardtype2() {
		return getFieldAsString(CARDCOMPATIBILITY2CARDTYPE2);
	}

	public  String getSlotposition() {
		return getFieldAsString(SLOTPOSITION);
	}
}
