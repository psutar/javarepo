package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkgcircuit.CreateDataCircuit;
import com.centurylink.icl.armmediation.transformation.ARMCreateCircuitToCim;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;

public class CreateCircuitService
{

	private static final Log LOG = LogFactory.getLog(CreateCircuitService.class);

	private CreateDataCircuit createDataCircuit;
	private JDBCTempleteUtil jdbcTempleteUtil;
	private ARMCreateCircuitToCim armCreateCircuitToCim;

	public Object createCircuit(CreateCircuitRequestDocument requestObject, HashMap<String, Object> ihashMap)
	{
		LOG.info("Starting Create Circuit");

		final String circuitName = MediationUtil.getValueFromMap(ihashMap, MDWConstants.CIRCUIT_NAME);
		final String circuitTypeId = MediationUtil.getValueFromMap(ihashMap, MDWConstants.CIRCUIT_TYPE_ID);
		final String circuitStartPortID = MediationUtil.getValueFromMap(ihashMap, MDWConstants.CIRCUIT_START_PORT_ID);
		final String circuitEndPortID = MediationUtil.getValueFromMap(ihashMap, MDWConstants.CIRCUIT_END_PORT_ID);
		//final String bandwidthKBPS = MediationUtil.getValueFromMap(ihashMap, MDWConstants.KBPS_VALUE);

		final int startNodeId = getStartNodeId(circuitStartPortID);

		final int endNodeId = getEndNodeId(circuitEndPortID);

		final int startLocId = getStartLocId(String.valueOf(startNodeId));

		final int endLocId = getEndLocId(String.valueOf(endNodeId));

		//final int bandwidthId = getBandwidthId(bandwidthKBPS);
		final HashMap<String, Object> map = (HashMap<String, Object>) createDataCircuit.execute(circuitName, new BigDecimal(circuitTypeId), startLocId, endLocId, startNodeId, endNodeId,
				new BigDecimal(circuitStartPortID), new BigDecimal(circuitEndPortID), null, null, null, null, null);

		final BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreateCircuitToCim.transformErrorToCim(requestObject, o_Errormsg);
		}

		final BigDecimal circuitId = (BigDecimal) map.get("o_circuitid");

		return armCreateCircuitToCim.transformToCim(requestObject, String.valueOf(circuitId));
	}

	private int getBandwidthId(String bandwidthKBPS)
	{
		return jdbcTempleteUtil.getBandwidthId(bandwidthKBPS);
	}

	private int getEndLocId(String endNodeId)
	{
		return jdbcTempleteUtil.getEndLocId(endNodeId);
	}

	private int getStartLocId(String startNodeId)
	{
		return jdbcTempleteUtil.getStartLocId(startNodeId);
	}

	private int getEndNodeId(String circuitEndPortID)
	{
		return jdbcTempleteUtil.getEndNodeId(circuitEndPortID);
	}

	private int getStartNodeId(String circuitStartPortID)
	{
		return jdbcTempleteUtil.getStartNodeId(circuitStartPortID);
	}

	public void setCreateDataCircuit(CreateDataCircuit createDataCircuit)
	{
		this.createDataCircuit = createDataCircuit;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setArmCreateCircuitToCim(ARMCreateCircuitToCim armCreateCircuitToCim)
	{
		this.armCreateCircuitToCim = armCreateCircuitToCim;
	}

}
