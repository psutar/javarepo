package com.centurylink.icl.armmediation.transformation;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.EllipticBuilder;
import com.centurylink.icl.builder.cim2.ExchangeServiceAreaBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchLocationToCim
{

	final private SearchResponseDetailsBuilder		searchResponseDetailsBuilder;
	final private AmericanPropertyAddressBuilder	americanPropertyAddressBuilder;
	final private EllipticBuilder					ellipticBuilder;
	final private ExchangeServiceAreaBuilder		exchangeServiceAreaBuilder;

	private static final Log						LOG	= LogFactory.getLog(SearchLocationToCim.class);

	public SearchLocationToCim()
	{
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		ellipticBuilder = new EllipticBuilder();
		exchangeServiceAreaBuilder = new ExchangeServiceAreaBuilder();
	}

	public SearchResourceResponseDocument transformToCim(List<ARMLocation> armLocationList, SearchResourceRequestDocument request)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("SearchLocationToCim: SearchLocation");
		}
		if (armLocationList == null || armLocationList.isEmpty())
		{
			return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Location could not be found in ARM", request);
		}

		Iterator<ARMLocation> locationIterator = ((List<ARMLocation>) armLocationList).iterator();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		ARMLocation location = null;
		while (locationIterator.hasNext())
		{
			location = locationIterator.next();
			americanPropertyAddressBuilder.buildAmericanPropertyAddress(location.getCommonName(), location.getObjectID(), location.getDescription(), location.getSourceSystem(), null, null, null,
					null, null, null, null);
			americanPropertyAddressBuilder.setShortAddress(location.getStateOrProvince(), location.getLocality(), location.getPostcode(), location.getAddressLine1(), location.getAddressLine2(),
					location.getAddressLine3());
			americanPropertyAddressBuilder.setAdditionalInformation(location.getClli(), location.getAddressType());
			americanPropertyAddressBuilder.addRootEntityDescribedBy("SwitchLocationCLLI", location.getSwitchLocationCLLI());
			ellipticBuilder.buildElliptic(location.getHcoordinate(), location.getVcoordinate());
			americanPropertyAddressBuilder.setEllipticLocation(ellipticBuilder.getElliptic());
			exchangeServiceAreaBuilder.buildExchangeServiceArea("LATA", null, location.getLata());
			americanPropertyAddressBuilder.addExchangeServiceArea(exchangeServiceAreaBuilder.getExchangeServiceArea());
			exchangeServiceAreaBuilder.buildExchangeServiceArea("NPA", null, location.getNpa());
			americanPropertyAddressBuilder.addExchangeServiceArea(exchangeServiceAreaBuilder.getExchangeServiceArea());
			exchangeServiceAreaBuilder.buildExchangeServiceArea("NXX", null, location.getNxx());
			americanPropertyAddressBuilder.addExchangeServiceArea(exchangeServiceAreaBuilder.getExchangeServiceArea());
			searchResponseDetailsBuilder.addAddressDetails(americanPropertyAddressBuilder.getAmericanPropertyAddress());
		}

		return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
	}

}
