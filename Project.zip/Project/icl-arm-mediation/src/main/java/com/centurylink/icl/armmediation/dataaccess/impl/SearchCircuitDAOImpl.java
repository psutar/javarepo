package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuitDetails;
import com.centurylink.icl.armmediation.armaccessobject.ARMEVCVlan;
import com.centurylink.icl.armmediation.armaccessobject.MaxNameValue;
import com.centurylink.icl.armmediation.armaccessobject.QosDetails;
import com.centurylink.icl.armmediation.armaccessobject.VlanDetails;
import com.centurylink.icl.armmediation.dataaccess.SearchCircuitDAO;
import com.centurylink.icl.armmediation.helper.Constants;

public class SearchCircuitDAOImpl implements SearchCircuitDAO
{
	private JdbcTemplate	jdbcTemplate;

	public SearchCircuitDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<ARMCircuitDetails> getCircuitList(String query) throws Exception 
	{
		final List<ARMCircuitDetails> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armCircuit = new ARMCircuitDetails();
				armCircuit.setCommonName(rs.getString("NAME"));
				armCircuit.setCktObjectId(rs.getString("CIRCUITID"));
				armCircuit.setCircuitType(rs.getString("CIRCUITTYPE_NAME"));
				armCircuit.setRelativeName(rs.getString("CUSTOMER_NAME"));
				armCircuit.setCktStatus(rs.getString("STATUS"));
				armCircuit.setCktFuncStatus(rs.getString("FUNC_STATUS"));
				armCircuit.setEthBearerMCO(rs.getString("ETH_BEARER_MCO"));
				armCircuit.setLagMCO(rs.getString("LAG_MCO"));
				armCircuit.setCkt2StartLocation(rs.getString("CIRCUIT2STARTLOCATION"));
				armCircuit.setCkt2EndLocation(rs.getString("CIRCUIT2ENDLOCATION"));
				armCircuit.setStartLocationName(rs.getString("START_LOC_NAME"));
				armCircuit.setStartLocationObjectID(rs.getString("START_LOC_OBJECTID"));
				armCircuit.setStartLocationStateOrProvince(rs.getString("START_LOC_PROVINCE"));
				armCircuit.setStartLocationLocality(rs.getString("START_LOC_TOWNCITY"));
				armCircuit.setStartLocationPostcode(rs.getString("START_LOC_ZIP"));
				armCircuit.setStartLocationAddressLine1(rs.getString("START_LOC_ADDRESS1"));
				armCircuit.setStartLocationAddressLine2(rs.getString("START_LOC_ADDRESS2"));
				armCircuit.setStartLocationAddressLine3(rs.getString("START_LOC_ADDRESS3"));
				armCircuit.setEndLocationName(rs.getString("END_LOC_NAME"));
				armCircuit.setEndLocationObjectID(rs.getString("END_LOC_OBJECTID"));
				armCircuit.setEndLocationStateOrProvince(rs.getString("END_LOC_PROVINCE"));
				armCircuit.setEndLocationLocality(rs.getString("END_LOC_TOWNCITY"));
				armCircuit.setEndLocationPostcode(rs.getString("END_LOC_ZIP"));
				armCircuit.setEndLocationAddressLine1(rs.getString("END_LOC_ADDRESS1"));
				armCircuit.setEndLocationAddressLine2(rs.getString("END_LOC_ADDRESS2"));
				armCircuit.setEndLocationAddressLine3(rs.getString("END_LOC_ADDRESS3"));
				armCircuit.setDescription(rs.getString(Constants.FULL_NAME));
				if(rs.getString("ETH_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("ETH_EXCEPTION_INFO"));
				else if(rs.getString("LAG_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("LAG_EXCEPTION_INFO"));
				
				return armCircuit;
			}
		});
		return circuitList;
	}

	@Override
	public List<ARMCircuitDetails> getServiceList(String query) throws Exception
	{
		final List<ARMCircuitDetails> armServiceList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armCircuit = new ARMCircuitDetails();
				armCircuit.setServiceName(rs.getString("NAME"));
				armCircuit.setServiceID(rs.getString("SERVICEID"));
				armCircuit.setServiceType(rs.getString("SERVICETYPE_NAME"));
				armCircuit.setUniMCO(rs.getString("UNI_MCO"));
				armCircuit.setEnniMCO(rs.getString("ENNI_MCO"));
				armCircuit.setEvcMCO(rs.getString("EVC_MCO"));
				armCircuit.setOvcMCO(rs.getString("OVC_MCO"));
				armCircuit.setServiceStatus(rs.getString("STATUS"));
				armCircuit.setServiceFuncStatus(rs.getString("FUNC_STATUS"));
				armCircuit.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCircuit.setSubscriberID(rs.getString("SUBSCRIBERID"));
				armCircuit.setBan(rs.getString("UNIBAN"));
				armCircuit.setLocationName(rs.getString("LOCATION_NAME"));
				armCircuit.setLocationObjectID(rs.getString("OBJECTID"));
				armCircuit.setStateOrProvince(rs.getString("PROVINCE"));
				armCircuit.setLocality(rs.getString("TOWNCITY"));
				armCircuit.setPostcode(rs.getString("ZIP"));
				armCircuit.setAddressLine1(rs.getString("ADDRESS1"));
				armCircuit.setAddressLine2(rs.getString("ADDRESS2"));
				armCircuit.setAddressLine3(rs.getString("ADDRESS3"));
				armCircuit.setDescription(rs.getString(Constants.FULL_NAME));
				if(rs.getString("UNI_EXCEPTION_HANDLING_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("UNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("ENNI_EXCEPTION_HANDLING_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("ENNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("EVC_EXCEPTION_HANDLING_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("EVC_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("OVC_EXCEPTION_HANDLING_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("OVC_EXCEPTION_HANDLING_INFO"));
				
				return armCircuit;
			}
				
		});
		return armServiceList;
	}

	@Override
	public List<ARMCircuitDetails> getCircuitDetailsList(String query) throws Exception
	{
		final List<ARMCircuitDetails> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armCircuit = new ARMCircuitDetails();
				armCircuit.setCommonName(rs.getString("NAME"));
				armCircuit.setObjectID(rs.getString(Constants.CIRCUIT_ID));
				armCircuit.setAlias1(rs.getString("ALIAS1"));
				armCircuit.setAlias2(rs.getString("ALIAS2"));
				armCircuit.setCircuitType(rs.getString("CIRCUITTYPE"));
				armCircuit.setCktSerType(rs.getString("CIRCUITSERVICETYPE"));
				armCircuit.setEthBearerMCO(rs.getString("ETH_BEARER_MCO"));
				armCircuit.setLagMCO(rs.getString("LAG_MCO"));
				armCircuit.setNmiIsDiverse(rs.getString("NMI_IS_DIVERSE"));
				armCircuit.setLagIsDiverse(rs.getString("LAG_IS_DIVERSE"));
				armCircuit.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCircuit.setSubscriberID(rs.getString(Constants.SUBSCIBER_ID));
				armCircuit.setSubscriberFullName(rs.getString(Constants.FULL_NAME));
				armCircuit.setCktStatus(rs.getString("PROVISIONSTATUS"));
				armCircuit.setStartPort(rs.getString(Constants.CIRCUIT_2_START_PORT));
				armCircuit.setEndPort(rs.getString(Constants.CIRCUIT_2_END_PORT));
				if(rs.getString("ETH_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("ETH_EXCEPTION_INFO"));
				else if(rs.getString("LAG_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("LAG_EXCEPTION_INFO"));
				
				return armCircuit;
			}
		});
		return circuitList;
	}

	@Override
	public List<ARMCircuitDetails> getNodeDetailsList(String query)
	{
		final List<ARMCircuitDetails> nodeList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armNode = new ARMCircuitDetails();
				armNode.setDeviceName(rs.getString("NAME"));
				armNode.setDeviceObjectId(rs.getString("OBJECTID"));
				armNode.setStorageRAM(rs.getString("STORAGERAM"));
				armNode.setDeviceType(rs.getString("NODETYPE"));
				armNode.setDevicesubType(rs.getString("NODEDEFNAME"));
				armNode.setDeviceFuncStatus(rs.getString("FUNCTIONAL_STATUS"));
				armNode.setDeviceFullName(rs.getString("FULLNAME"));
				armNode.setDeviceRelativeName(rs.getString("RELATIVENAME"));
				armNode.setClli(rs.getString("CLLI"));
				armNode.setVendorName(rs.getString("VENDORNAME"));
				armNode.setMco(rs.getString("MCO"));
				armNode.setPartType(rs.getString("PARTTYPE"));
				armNode.setIpAddress(rs.getString("IPADDRESS"));
				armNode.setIpAddress1(rs.getString("IPADDRESS_1"));
				armNode.setRelayrackid(rs.getString("RELAYRACKID"));
				armNode.setShelfName(rs.getString("SHELFNAME"));
				armNode.setShelfId(rs.getString(Constants.SHELF_ID));
				armNode.setShelfNumber(rs.getString(Constants.SHELF_NUMBER));
				armNode.setAlias1(rs.getString("LogicalSHELFNAME"));
				armNode.setSlotName(rs.getString("SLOTNAME"));
				armNode.setSlotId(rs.getString("SLOTID"));
				armNode.setSlotNumber(rs.getString(Constants.SLOT_NUMBER));
				armNode.setCardName(rs.getString("CARDNAME"));
				armNode.setCardId(rs.getString(Constants.CARD_ID));
				armNode.setPortName(rs.getString("PORTNAME"));
				armNode.setPortID(rs.getString(Constants.PORT_ID));
				armNode.setPortNumber(rs.getString(Constants.PORTNUMBER));
				armNode.setPortType(rs.getString("PORTTYPE"));
				armNode.setPortDpea(rs.getString("DPEA"));
				armNode.setPortDpea1(rs.getString("DPEA_1"));
				armNode.setPortFuncT(rs.getString("PORTFUNCTION"));
				armNode.setPluggableType(rs.getString("PLUGGABLETYPE"));
				armNode.setDeviceStatus(rs.getString("STATUS"));
				armNode.setLocationName(rs.getString("LOCATION_NAME"));
				armNode.setNetworkName(rs.getString(Constants.NETWORK_NAME));
				armNode.setIfnum(rs.getString(Constants.IFNUM));
				armNode.setPluggableIfNum(rs.getString("PLUGGABLEIFNUM"));
				armNode.setTtServiceType(rs.getString(Constants.TT_SERVICE_TYPE));
				armNode.setRole(rs.getString("ROLE"));
				armNode.setTransmissionRate(rs.getString("BANDWIDTH_NAME"));
				armNode.setNetworkName(rs.getString(Constants.NETWORK_NAME));
				armNode.setNetworkPortName(rs.getString("IF_NAME"));
				armNode.setNetworkPortNamePluggable(rs.getString("PLUGGABLE_IF_NAME"));
				armNode.setLegacyPortName(rs.getString("LEGACYPORTNAME"));
				armNode.setTransmissionRatePluggable(rs.getString("PLUGGABLE_TRANSMISSIONRATE"));				
				
				return armNode;
			}
		});
		return nodeList;
	}

	@Override
	public List<ARMCircuitDetails> getServiceDetailsList(String query)
	{
		final List<ARMCircuitDetails> serviceList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armService = new ARMCircuitDetails();
				armService.setServiceName(rs.getString("NAME"));
				armService.setServiceID(rs.getString("SERVICEID"));
				armService.setAlias1(rs.getString("ALIAS1"));
				armService.setAlias2(rs.getString("ALIAS2"));
				armService.setServiceType(rs.getString("SERVICETYPENAME"));
				armService.setUniMCO(rs.getString("UNI_MCO"));
				armService.setEnniMCO(rs.getString("ENNI_MCO"));
				armService.setUniIsDiverse(rs.getString("UNI_IS_DIVERSE"));
				armService.setDiverseUniId(rs.getString("DIVERSE_UNI_ID"));
				armService.setEvcMCO(rs.getString("EVC_MCO"));
				armService.setOvcMCO(rs.getString("OVC_MCO"));
				armService.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armService.setSubscriberID(rs.getString("SUBSCRIBERID"));
				armService.setSubscriberFullName(rs.getString(Constants.FULL_NAME));
				armService.setServiceProStatus(rs.getString("PROVISIONSTATUS"));
				armService.setPortID(rs.getString("PORTID"));
				armService.setBan(rs.getString("UNIBAN"));
				armService.setDescription(rs.getString(Constants.FULL_NAME));
				if(rs.getString("UNI_HPC")!=null)
					armService.setHpc(rs.getString("UNI_HPC"));
				else if(rs.getString("ENNI_HPC")!=null)
					armService.setHpc(rs.getString("ENNI_HPC"));
				else if(rs.getString("EVC_HPC")!=null)
					armService.setHpc(rs.getString("EVC_HPC"));
				else if(null!=rs.getString("OVC_HPC"))
					armService.setHpc(rs.getString("OVC_HPC"));
				if(null!=rs.getString("UNI_EPI_DATE"))
					armService.setHpcExpDate(rs.getString("UNI_EPI_DATE"));
				else if(rs.getString("ENNI_EPI_DATE")!=null)
					armService.setHpcExpDate(rs.getString("ENNI_EPI_DATE"));
				else if(null!=rs.getString("EVC_EPI_DATE"))
					armService.setHpcExpDate(rs.getString("EVC_EPI_DATE"));
				else if(null!=rs.getString("OVC_EPI_DATE"))
					armService.setHpcExpDate(rs.getString("OVC_EPI_DATE"));
				if(rs.getString("UNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("UNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("ENNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("ENNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("EVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("EVC_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("OVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("OVC_EXCEPTION_HANDLING_INFO"));
				
				
				return armService;
			}
		});
		return serviceList;
	}

	@Override
	public List<ARMCircuit> getUniEnniCircuit(String query) throws Exception
	{
		final List<ARMCircuit> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuit>()
		{
			public ARMCircuit mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuit armCircuit = new ARMCircuit();
				armCircuit.setName(rs.getString(Constants.SERVICE_NAME));
				armCircuit.setObjectID(rs.getString(Constants.SERVICE_ID));
				armCircuit.setNodeName(rs.getString(Constants.NODE_NAME));
				armCircuit.setBandwidthName(rs.getString(Constants.BANDWIDTH));
				armCircuit.setPortTypeName(rs.getString(Constants.PORTTYPE));
				armCircuit.setPortName(rs.getString(Constants.PORT));
				armCircuit.setResourceType(rs.getString(Constants.SERVICE_TYPE));
				armCircuit.setClliCode(rs.getString(Constants.DEVICE_CILLI));
				
				return armCircuit;
			}
		});
		return circuitList;

	}

	@Override
	public List<ARMCircuit> getUniEnniRelatedCircuits(String query)throws Exception 
	{
		final List<ARMCircuit> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuit>()
		{
			public ARMCircuit mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuit armCircuit = new ARMCircuit();
					
				armCircuit.setName(rs.getString("EVC_OVC_SER_NAME"));
				armCircuit.setResourceType(rs.getString("EVC_OVC_SERVICETYPE"));
				armCircuit.setNcCode(rs.getString(Constants.NC_CODE));
				armCircuit.setNciCode(rs.getString(Constants.NCI_CODE));
				armCircuit.setSecNciCode(rs.getString(Constants.SEC_NCI_CODE));
				armCircuit.setCircuitName(rs.getString("DIM_NO_NAME"));
				armCircuit.setCircuitType(rs.getString("DIM_NO_TYPE_NAME"));
				
				return armCircuit;
			}
		});
		return circuitList;
	}

	@Override
	public List<ARMCircuit> getEnniRelatedCircuits(String query)throws Exception 
	{
		final List<ARMCircuit> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuit>()
		{
			public ARMCircuit mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuit armCircuit = new ARMCircuit();
						
				if(null!=rs.getString("OVC_SER_NAME"))				
				{
				armCircuit.setName(rs.getString("OVC_SER_NAME"));
				}
				armCircuit.setNcCode(rs.getString(Constants.NC_CODE));
				armCircuit.setNciCode(rs.getString(Constants.NCI_CODE));
				armCircuit.setSecNciCode(rs.getString(Constants.SEC_NCI_CODE));
				armCircuit.setCircuitName(rs.getString("DIM_NO_NAME"));
				armCircuit.setCircuitType(rs.getString("DIM_NO_TYPE_NAME"));
				
				return armCircuit;
			}
		});
		return circuitList;
	}

	@Override
	public List<ARMCircuitDetails> getCircuitDetailsListForDSP(String query)
	{
		final List<ARMCircuitDetails> circuitList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armCircuit = new ARMCircuitDetails();
				armCircuit.setCommonName(rs.getString("NAME"));
				armCircuit.setObjectID(rs.getString(Constants.CIRCUIT_ID));
				armCircuit.setAlias1(rs.getString("ALIAS1"));
				armCircuit.setAlias2(rs.getString("ALIAS2"));
				armCircuit.setCircuitType(rs.getString("CIRCUITTYPE"));
				armCircuit.setCktSerType(rs.getString("CIRCUITSERVICETYPE"));
				armCircuit.setEthBearerMCO(rs.getString("ETH_BEARER_MCO"));
				armCircuit.setLagMCO(rs.getString("LAG_MCO"));
				armCircuit.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCircuit.setSubscriberFullName(rs.getString(Constants.FULL_NAME));
				armCircuit.setSubscriberID(rs.getString(Constants.SUBSCIBER_ID));
				armCircuit.setCktProStatus(rs.getString("PROVISIONSTATUS"));
				armCircuit.setCktFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armCircuit.setTsp(rs.getString("TSP"));
				armCircuit.setBandwidth(rs.getString("BANDWIDTH"));
				armCircuit.setNmiBW(rs.getString("NMI_BW"));
				armCircuit.setIsLagMember(rs.getString("IS_LAG_MEMBER"));
				armCircuit.setNmiIsDiverse(rs.getString("NMI_IS_DIVERSE"));
				armCircuit.setNmiDiverseCktId(rs.getString("NMI_DIVERSE_CKT_ID"));
				armCircuit.setL1Technology(rs.getString("L1_TECHNOLOGY"));
				armCircuit.setProtectionType(rs.getString("PROTECTIONTYPE"));
				armCircuit.setLagNumber(rs.getString("LAGNUMBER"));
				armCircuit.setAggregationProtocol(rs.getString("AGGREGATIONPROTOCOL"));
				armCircuit.setHashing(rs.getString("HASHING"));
				armCircuit.setLagBW(rs.getString("LAG_BW"));
				armCircuit.setLagIsDiverse(rs.getString("LAG_IS_DIVERSE"));
				armCircuit.setLagDiverseCktId(rs.getString("LAG_DIVERSE_CKT_ID"));
				armCircuit.setStartPort(rs.getString(Constants.CIRCUIT_2_START_PORT));
				armCircuit.setEndPort(rs.getString(Constants.CIRCUIT_2_END_PORT));
				if(rs.getString("ETH_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("ETH_EXCEPTION_INFO"));
				else if(rs.getString("LAG_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("LAG_EXCEPTION_INFO"));
				return armCircuit;
			}
		});
		return circuitList;
	}

	@Override
	public List<ARMCircuitDetails> getRelatedServiceDetailsForNMILAG(String query) throws Exception
	{
		final List<ARMCircuitDetails> relatedServiceDetailsList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armService = new ARMCircuitDetails();
				armService.setServiceName(rs.getString(Constants.NAME));					
				armService.setServiceType(rs.getString(Constants.SERVICE_TYPE));
				armService.setServiceProStatus(rs.getString(Constants.PROVISION_STATUS));
				armService.setServiceFuncStatus(rs.getString(Constants.FUNCTIONAL_STATUS));
				armService.setUniCktId(rs.getString("UNI_SERVICEID"));
				armService.setUniSpecCode(rs.getString("UNI_SPECCODE"));
				armService.setUniNCCode(rs.getString("UNI_NCCODE"));
				armService.setUniNCICode(rs.getString("UNI_NCICODE"));
				armService.setUniSecNCICode(rs.getString("UNI_SECNCICODE"));
				armService.setUniBW(rs.getString("UNI_BW"));
				armService.setUniMCO(rs.getString("UNI_MCO"));
				armService.setEnniCktId(rs.getString("ENNI_SERVICEID"));
				armService.setEnniSpecCode(rs.getString("ENNI_SPECCODE"));
				armService.setEnniNCCode(rs.getString("ENNI_NCCODE"));
				armService.setEnniNCICode(rs.getString("ENNI_NCICODE"));
				armService.setEnniSecNCICode(rs.getString("ENNI_SECNCICODE"));
				armService.setEnniBW(rs.getString("ENNI_BW"));
				armService.setEnniMCO(rs.getString("ENNI_MCO"));
				if(rs.getString("UNI_EXCEPTION_HANDLING_INFO") != null)
				armService.setExceptionHandlingText(rs.getString("UNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("ENNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("ENNI_EXCEPTION_HANDLING_INFO"));

				return armService;
			}
		});
		return relatedServiceDetailsList;
	}

	@Override
	public List<ARMCircuitDetails> getServiceDetailsListForDSP(String query)
	{
		final List<ARMCircuitDetails> serviceList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armService = new ARMCircuitDetails();
				armService.setServiceName(rs.getString("NAME"));
				armService.setServiceID(rs.getString("SERVICEID"));
				armService.setAlias1(rs.getString("ALIAS1"));
				armService.setAlias2(rs.getString("ALIAS2"));
				armService.setServiceType(rs.getString("SERVICETYPENAME"));
				armService.setUniMCO(rs.getString("UNI_MCO"));
				armService.setEnniMCO(rs.getString("ENNI_MCO"));
				armService.setEvcMCO(rs.getString("EVC_MCO"));
				armService.setOvcMCO(rs.getString("OVC_MCO"));
				armService.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armService.setSubscriberID(rs.getString("SUBSCRIBERID"));
				armService.setSubscriberObjectId(rs.getString("OBJECTID"));
				armService.setDescription(rs.getString(Constants.FULL_NAME));
				armService.setSubscriberFullName(rs.getString("FULLNAME"));
				armService.setSubscriberFirstName(rs.getString("FIRSTNAME"));
				armService.setSubscriberLastName(rs.getString("TITLE"));
				armService.setBan(rs.getString("UNIBAN"));
				armService.setServiceProStatus(rs.getString("PROVISIONSTATUS"));
				armService.setPortID(rs.getString("PORTID"));
				armService.setDescription(rs.getString(Constants.FULL_NAME));
				armService.setServiceFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armService.setServiceMux(rs.getString("SERVICEMUX"));
				armService.setBundling(rs.getString("BUNDLING"));
				armService.setAllToOneBundling(rs.getString("ALLTO1BUNDLING"));
				armService.setCustomerSrNo(rs.getString("CUSTOMERSERIALNUMBER"));
				armService.setUniSpecCode(rs.getString("UNI_SPECCODE"));
				armService.setUniNCCode(rs.getString("UNI_NCCODE"));
				armService.setUniNCICode(rs.getString("UNI_NCICODE"));
				armService.setUniSecNCICode(rs.getString("SECNCICODE"));
				armService.setUniBW(rs.getString("UNI_BW"));
				armService.setUniIsDiverse(rs.getString("UNI_IS_DIVERSE"));
				armService.setDiverseUniId(rs.getString("DIVERSE_UNI_ID"));
				armService.setUniCktSrNo(rs.getString("UNI_CktSrNo"));
				armService.setEnniTSP(rs.getString("ENNI_TSP"));
				armService.setUniTSP(rs.getString("UNI_TSP"));
				if(rs.getString("UNI_HPC")!=null)
					armService.setHpc(rs.getString("UNI_HPC"));
				else if(rs.getString("ENNI_HPC")!=null)
					armService.setHpc(rs.getString("ENNI_HPC"));
				else if(rs.getString("EVC_HPC")!=null)
					armService.setHpc(rs.getString("EVC_HPC"));
				else if(null!=rs.getString("OVC_HPC"))
					armService.setHpc(rs.getString("OVC_HPC"));
				if(null!=rs.getString("UNI_EPI_DATE"))
				      armService.setHpcExpDate(rs.getString("UNI_EPI_DATE"));
				else if(rs.getString("ENNI_EPI_DATE")!=null)
					armService.setHpcExpDate(rs.getString("ENNI_EPI_DATE"));
				else if(null!=rs.getString("EVC_EPI_DATE"))
					armService.setHpcExpDate(rs.getString("EVC_EPI_DATE"));
				else if(null!=rs.getString("OVC_EPI_DATE"))
					armService.setHpcExpDate(rs.getString("OVC_EPI_DATE"));
				armService.setFrameFormat(rs.getString("FRAMEFORMAT"));
				armService.setEnniSpecCode(rs.getString("ENNI_SPECCODE"));
				armService.setEnniNCCode(rs.getString("ENNI_NCCODE"));
				armService.setEnniNCICode(rs.getString("ENNI_NCICODE"));
				armService.setEnniBW(rs.getString("ENNI_BW"));
				armService.setEnniCktSrNo(rs.getString("ENNI_CktSrNo"));
				armService.setEvcMtu(rs.getString("EVCMTU"));
				armService.setEvcCeVlanIdPreservation(rs.getString("EVC_CEVLANIDPRESERVATION"));
				armService.setEvcCeVlanCosPreservation(rs.getString("EVC_CEVLANCOSPRESERVATION"));
				armService.setEvcUnicastFrameDelivery(rs.getString("EVC_UNICASTFRAMEDELIVERY"));
				armService.setEvcMulticastFrameDelivery(rs.getString("EVC_MULTICASTFRAMEDELIVERY"));
				armService.setEvcBroadcastFrameDelivery(rs.getString("EVC_BROADCASTFRAMEDELIVERY"));
				armService.setEvcEvcOvcNc(rs.getString("EVC_EVCOVCNC"));
				armService.setEvcServiceSubType(rs.getString("EVC_SERVICESUBTYPE"));
				armService.setEvcMCO(rs.getString("EVC_MCO"));
				armService.setEvcCosId(rs.getString("EVC_COS_ID"));
				armService.setEvcCktSrNo(rs.getString("EVC_CktSrNo"));
				armService.setOvcMtu(rs.getString("OVCMTU"));
				armService.setOvcCeVlanIdPreservation(rs.getString("OVC_CEVLANIDPRESERVATION"));
				armService.setOvcCeVlanCosPreservation(rs.getString("OVC_CEVLANCOSPRESERVATION"));
				armService.setsVlanIdPreservation(rs.getString("SVLANIDPRESERVATION"));
				armService.setsVlanCosPreservation(rs.getString("SVLANCOSPRESERVATION"));
				armService.setColorForwarding(rs.getString("COLORFORWARDING"));
				armService.setOvcUnicastFrameDelivery(rs.getString("OVC_UNICASTFRAMEDELIVERY"));
				armService.setOvcMulticastFrameDelivery(rs.getString("OVC_MULTICASTFRAMEDELIVERY"));
				armService.setOvcBroadcastFrameDelivery(rs.getString("OVC_BROADCASTFRAMEDELIVERY"));
				armService.setOvcEvcOvcNc(rs.getString("OVC_EVCOVCNC"));
				armService.setOvcServiceSubType(rs.getString("OVC_SERVICESUBTYPE"));
				armService.setEvcOvcReference(rs.getString("EVCOVCREFERENCE"));
				armService.setOvcMCO(rs.getString("OVC_MCO"));
				armService.setOvcCosId(rs.getString("OVC_COS_ID"));
				armService.setOvcCktSrNo(rs.getString("OVC_CktSrNo"));
				if(rs.getString(Constants.EVC_ASN) != null)
					armService.setAsn(rs.getString(Constants.EVC_ASN));
				else if(rs.getString(Constants.OVC_ASN) != null)
					armService.setAsn(rs.getString(Constants.OVC_ASN));
				/*if(rs.getString(Constants.EVC_VPNID) != null)
					armService.setVpnId(rs.getString(Constants.EVC_VPNID));
				else if(rs.getString(Constants.OVC_VPNID) != null)
					armService.setVpnId(rs.getString(Constants.OVC_VPNID));*/
				if(rs.getString("OVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("OVC_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("EVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("EVC_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("UNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("UNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("ENNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("ENNI_EXCEPTION_HANDLING_INFO"));
				
				return armService;
			}
		});
		return serviceList;
	}

	@Override
	public List<ARMCircuitDetails> getRelatedNMILAGForUNIENNI(String query)
	{
		final List<ARMCircuitDetails> relatedCircuitDetailsList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armCircuit = new ARMCircuitDetails();
				armCircuit.setCommonName(rs.getString("NAME"));
				armCircuit.setCircuitType(rs.getString("CIRCUITTYPE"));
				armCircuit.setObjectID(rs.getString("CIRCUITID"));
				armCircuit.setCktSerType(rs.getString("CIRCUITSERVICETYPE"));
				armCircuit.setCktProStatus(rs.getString("PROVISIONSTATUS"));
				armCircuit.setCktFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armCircuit.setNmiBW(rs.getString("NMI_BW"));
				armCircuit.setLagBW(rs.getString("LAG_BW"));
				if(rs.getString("ETH_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("ETH_EXCEPTION_INFO"));
				else if(rs.getString("LAG_EXCEPTION_INFO") != null)
					armCircuit.setExceptionHandlingText(rs.getString("LAG_EXCEPTION_INFO"));				
						
				return armCircuit;
			}
		});
		return relatedCircuitDetailsList;
	}

	@Override
	public List<ARMCircuitDetails> getRelatedEVCOVCForUNIENNI(String query)
	{
		final List<ARMCircuitDetails> relatedServiceDetailsList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armService = new ARMCircuitDetails();
				armService.setServiceName(rs.getString("NAME"));					
				armService.setServiceType(rs.getString("SERVICETYPE"));
				armService.setServiceID(rs.getString("SERVICEID"));
				armService.setObjectID(rs.getString("OBJECTID"));
				armService.setServiceProStatus(rs.getString("PROVISIONSTATUS"));
				armService.setServiceFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armService.setEvcServiceSubType(rs.getString("EVC_SERVICESUBTYPE"));
				armService.setEvcNc(rs.getString("EVC_NC"));
				armService.setEvcMCO(rs.getString("EVC_MCO"));
				if(rs.getString("EVC_HPC")!=null)
						armService.setHpc(rs.getString("EVC_HPC"));
				else if(null!=rs.getString("OVC_HPC"))
						armService.setHpc(rs.getString("OVC_HPC"));
				if(null!=rs.getString("EVC_EPI_DATE"))
						armService.setHpcExpDate(rs.getString("EVC_EPI_DATE"));
				else if(null!=rs.getString("OVC_EPI_DATE"))
					  armService.setHpcExpDate(rs.getString("OVC_EPI_DATE"));
				armService.setOvcServiceSubType(rs.getString("OVC_SERVICESUBTYPE"));
				armService.setOvcNc(rs.getString("OVC_NC"));
				armService.setOvcMCO(rs.getString("OVC_MCO"));
				armService.setVlanPortId(rs.getString("VLAN_PORTID"));
				if(rs.getString(Constants.EVC_ASN) != null)
					armService.setAsn(rs.getString(Constants.EVC_ASN));
				else if(rs.getString(Constants.OVC_ASN) != null)
					armService.setAsn(rs.getString(Constants.OVC_ASN));
				/*if(rs.getString(Constants.EVC_VPNID) != null)
					armService.setVpnId(rs.getString(Constants.EVC_VPNID));
				else if(rs.getString(Constants.OVC_VPNID) != null)
					armService.setVpnId(rs.getString(Constants.OVC_VPNID));*/
				if(rs.getString("OVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("OVC_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("EVC_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("EVC_EXCEPTION_HANDLING_INFO"));
				
				return armService;
			}
		});
		return relatedServiceDetailsList;
	}

	@Override
	public List<ARMCircuitDetails> getRelatedUNIENNIForEVCOVC(String query)
	{
		final List<ARMCircuitDetails> relatedServiceDetailsList = this.jdbcTemplate.query(query, new RowMapper<ARMCircuitDetails>()
		{
			public ARMCircuitDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuitDetails armService = new ARMCircuitDetails();
				armService.setServiceName(rs.getString("NAME"));					
				armService.setServiceType(rs.getString("SERVICETYPE"));
				armService.setServiceID(rs.getString("SERVICEID"));
				armService.setObjectID(rs.getString("OBJECTID"));
				armService.setServiceProStatus(rs.getString("PROVISIONSTATUS"));
				armService.setServiceFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armService.setUniSpecCode(rs.getString("UNI_SPECCODE"));
				armService.setUniNCCode(rs.getString("UNI_NCCODE"));
				armService.setUniNCICode(rs.getString("UNI_NCICODE"));
				armService.setUniSecNCICode(rs.getString("UNI_SECNCICODE"));
				armService.setUniBW(rs.getString("UNI_BW"));
				armService.setUniTSP(rs.getString("UNI_TSP"));
				armService.setUniMCO(rs.getString("UNI_MCO"));
				if(rs.getString("UNI_HPC")!=null)
				    armService.setHpc(rs.getString("UNI_HPC"));
				else if(rs.getString("ENNI_HPC")!=null)
					armService.setHpc(rs.getString("ENNI_HPC"));
				if(rs.getString("UNI_EPI_DATE")!=null)
				    armService.setHpcExpDate(rs.getString("UNI_EPI_DATE"));
				else if(rs.getString("ENNI_EPI_DATE")!=null)
					armService.setHpcExpDate(rs.getString("ENNI_EPI_DATE"));
				armService.setEnniSpecCode(rs.getString("ENNI_SPECCODE"));
				armService.setEnniNCCode(rs.getString("ENNI_NCCODE"));
				armService.setEnniNCICode(rs.getString("ENNI_NCICODE"));
				armService.setEnniSecNCICode(rs.getString("ENNI_SECNCICODE"));
				armService.setEnniBW(rs.getString("ENNI_BW"));
				armService.setEnniMCO(rs.getString("ENNI_MCO"));
				armService.setEnniTSP(rs.getString("ENNI_TSP"));
				armService.setPortID(rs.getString("PORTID"));
				if(rs.getString("UNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("UNI_EXCEPTION_HANDLING_INFO"));
				else if(rs.getString("ENNI_EXCEPTION_HANDLING_INFO") != null)
					armService.setExceptionHandlingText(rs.getString("ENNI_EXCEPTION_HANDLING_INFO"));
				return armService;
			}
		});
		return relatedServiceDetailsList;
	}
	
	@Override
	public List<VlanDetails> getVlanDetails(String query)
	{
		final List<VlanDetails> vlanDetailsList = this.jdbcTemplate.query(query, new RowMapper<VlanDetails>()
		{
			public VlanDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				VlanDetails vlanDetails = new VlanDetails();
				vlanDetails.setNumberValue(rs.getString("NUMBERVALUE"));
				vlanDetails.setNumberType(rs.getString("NUMBERTYPE"));
				vlanDetails.setVlanPortID(rs.getString("PORTID"));
				vlanDetails.setVlanFunction(rs.getString("VLANFUNCTION"));
						
				return vlanDetails;
			}
		});
		return vlanDetailsList;
		
	}
	
	@Override
	public List<VlanDetails> getVpnIDDetails(String query)
	{
		final List<VlanDetails> vpnIdDetailsList = this.jdbcTemplate.query(query, new RowMapper<VlanDetails>()
		{
			public VlanDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				VlanDetails vpnIdDetails = new VlanDetails();
				vpnIdDetails.setNumberValue(rs.getString("NUMBERVALUE"));
				vpnIdDetails.setNumberType(rs.getString("NUMBERTYPE"));
				vpnIdDetails.setServiceID(rs.getString("SERVICEID"));
				
						
				return vpnIdDetails;
			}
		});
		return vpnIdDetailsList;
		
	}
	
	public List<QosDetails> getQosDetails(String query)
	{
		final List<QosDetails> qosDetailsList = this.jdbcTemplate.query(query, new RowMapper<QosDetails>()
		{
			public QosDetails mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				QosDetails qosDetails = new QosDetails();
				qosDetails.setParameterDefinition(rs.getString("PARAMETERDEFINITION"));
				qosDetails.setParameterClass(rs.getString("class"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("EIR"))
					qosDetails.setParameterIntegerValueForEIR(rs.getString("INTEGERVALUE"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("CIR"))
					qosDetails.setParameterIntegerValueForCIR(rs.getString("INTEGERVALUE"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("LOS Name"))
						qosDetails.setParameterStringValueForLOSName(rs.getString("STRINGVALUE"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("BW"))
							qosDetails.setParameterIntegerValueForBW(rs.getString("STRINGVALUE"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("CoS Value"))
					qosDetails.setParameterIntegerValueForCOS(rs.getString("INTEGERVALUE"));
				if(rs.getString("PARAMETERDEFINITION").equalsIgnoreCase("CoS ID"))
					qosDetails.setParameterIntegerValueForCOSID(rs.getString("INTEGERVALUE"));
				qosDetails.setParameterStringValue(rs.getString("STRINGVALUE"));
				qosDetails.setParameterDateValue(rs.getString("DATEVALUE"));
				qosDetails.setParameterObject(rs.getString("PARAMETERSET2OBJECT"));
				qosDetails.setParameterDimObject(rs.getString("PARAMETERSET2DIMOBJECT"));
				qosDetails.setParameterName(rs.getString("PARAMETERNAME"));
				
				return qosDetails;
			}
		});
		return qosDetailsList;
	}

	@Override
	public List<ARMCard> getCardList(String query) throws Exception
	{
		final List<ARMCard> cardList = jdbcTemplate.query(query, new RowMapper<ARMCard>()
		{
			public ARMCard mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCard armCard = new ARMCard();
				armCard.setCommonName(rs.getString(Constants.NAME));
				armCard.setCardId(rs.getLong(Constants.CARD_ID));
				armCard.setAliasName(rs.getString(Constants.ALIAS_1));
				armCard.setSubType(rs.getString("CARDTYPE"));
				armCard.setParentCardName(rs.getString("PARENTCARDNAME"));
				armCard.setParentCardID(rs.getString("PARENTCARDID"));
				armCard.setParentCardAliasName(rs.getString("PARENTALIAS1"));
				armCard.setParentSubType(rs.getString("PARENTCARDTYPE"));
				armCard.setParentSlotNumber(rs.getString("PARENTSLOTNUMBER"));
				armCard.setSlotNumber(rs.getString(Constants.SLOT_NUMBER));
				armCard.setSlotName(rs.getString("SLOTNAME"));
				armCard.setSlotId(rs.getLong("SLOTID"));
				armCard.setPortName(rs.getString("PORTNAME"));
				armCard.setPortId(rs.getString(Constants.PORT_ID));
				armCard.setPortType(rs.getString("PORTTYPE"));
				armCard.setPluggableType(rs.getString(Constants.PLUGGABLE_TYPE));
				armCard.setDpea(rs.getString(Constants.DPEA));
				armCard.setDpea1(rs.getString("DPEA_1"));
				armCard.setPortFunc(rs.getString(Constants.PORT_FUNCTION));
				armCard.setNetworkPortName(rs.getString("IF_NAME"));
				armCard.setNetworkPortNamePluggable(rs.getString("PLUGGABLE_IF_NAME"));
				armCard.setLegacyPortName(rs.getString("LEGACYPORTNAME"));
				armCard.setTransmissionRate(rs.getString("BANDWIDTH_NAME"));
				armCard.setTransmissionRatePluggable(rs.getString("PLUGGABLE_TRANSMISSIONRATE"));
				return armCard;
			}
		});
		
		return cardList;
	}
	
	public List<MaxNameValue> getMaxValuesForService(String query) throws Exception
	{
		final List<MaxNameValue> nameValueList = jdbcTemplate.query(query, new RowMapper<MaxNameValue>()
		{
			public MaxNameValue mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				MaxNameValue values=new MaxNameValue();
				values.setMaxColName(rs.getString("MAX_COLUMN_NAME"));
				values.setMaxValue(rs.getString("MAX_VALUE"));
				values.setServiceType(rs.getString("SERVICE_TYPE"));
				return values;
			}
		});
		return nameValueList;
	}
	
	private static final String QUERY_SQL = "select CIRCUITID from CIRCUIT where RELATIVENAME = ?";
	@Override
	public List<Long> getCircuitIdsBySubscriber(String subscriber) throws Exception
	{
		final List<Long> longList = this.jdbcTemplate.query(QUERY_SQL, new Object[] {subscriber}, new RowMapper<Long>()
		{
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				Long id = rs.getLong("CIRCUITID");
				return id;
			}
		});
		return longList;
	}

	@Override
	public List<ARMEVCVlan> getEVCVlanDetails(String query) {
		
		final List<ARMEVCVlan> evcVlanList = jdbcTemplate.query(query, new RowMapper<ARMEVCVlan>()
				{
					public ARMEVCVlan mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						ARMEVCVlan evcVlan = new ARMEVCVlan();
						
						evcVlan.setVlanPortID(rs.getString(Constants.PORT_ID));
						evcVlan.setevcOvcID(rs.getString("EVCOVCSERVICE"));
						
						return evcVlan;
					}
				});
				
				return evcVlanList;
		
	}
   
}
