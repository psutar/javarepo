package com.centurylink.icl.armmediation.transformation;

import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuitcircuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Numberobject;
import com.centurylink.icl.armmediation.valueobjects.objects.OntProfile;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class HSIServiceDetailsVOTransformation 
{
	static List<OntProfile> profilemList=null;
	private static final Log LOG = LogFactory.getLog(HSIServiceDetailsVOTransformation.class);

	static Service foundService = null;

	public static SearchResourceResponseDocument transformToCIM(List<Service> services, VOSearchHolder searchHolder) throws Exception
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		boolean serviceFound = false;

		for (Service service:services)
		{
			SubNetworkConnection circuit = buildService(service, searchHolder);
			if (circuit != null)
			{
				searchResponseDetailsBuilder.addCircuit(circuit);
				serviceFound = true;
			}
		}

		if (!serviceFound)
		{
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());

		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}

		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	protected static SubNetworkConnection buildService(Service service, VOSearchHolder searchHolder) throws Exception
	{

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		ResourceRelationshipBuilder resourceRelationshipBuilder =new ResourceRelationshipBuilder();
		Point2PointCircuitBuilder point2PointCircuitBuilder=new Point2PointCircuitBuilder();
		RemarkBuilder remarkBuilder=new RemarkBuilder();
		Map<String, String> modifiers = searchHolder.getModifiers();
		boolean includeRelationships = false;
		boolean includeCustomer = false;
		boolean includeLocation = false;

		if(modifiers!=null)
		{
			if (modifiers.containsKey("INCLUDERELATIONSHIPS"))
			{
				if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE"))
				{
					includeRelationships = true;

				}
			}
			if (modifiers.containsKey("INCLUDECLCLOCATION"))
			{
				if (modifiers.get("INCLUDECLCLOCATION").equalsIgnoreCase("TRUE"))
				{
					includeLocation = true;

				}
			}
			if (modifiers.containsKey("INCLUDECLCCUSTOMER"))
			{
				if (modifiers.get("INCLUDECLCCUSTOMER").equalsIgnoreCase("TRUE"))
				{
					includeCustomer = true;

				}
			}
		}
		if(service!=null)
		{
			foundService = service;

			subNetworkConnectionBuilder.buildSubNetworkConnection(service.getName(), service.getServiceid(), null, "ARM", service.getServicetype().getName(), service.getProvisionstatus().getName(), null, null, null, null, service.getFunctionalstatus().getName(), null, null, null, null);

			if(service.getNotes()!=null)
			{
				remarkBuilder.buildRemark(service.getNotes(), "RestrictedNotes");
				subNetworkConnectionBuilder.addRemark(remarkBuilder.getRemarks());
			}
			if(service.getServiceExtension()!=null)
			{
				if(service.getServiceExtension().getServiceProfile()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("ServiceProfile", service.getServiceExtension().getServiceProfile());

				if(service.getServiceExtension().getDTN()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("DTN", service.getServiceExtension().getDTN());
				}

				if(service.getServiceExtension().getCvoipTn()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("CVoIPTN", service.getServiceExtension().getCvoipTn());
				}

				if(service.getServiceExtension().getUpstreamRate()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("UpstreamBandwidth", service.getServiceExtension().getUpstreamRate());
				}

				if(service.getServiceExtension().getDownStreamRate()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("DownstreamBandwidth", service.getServiceExtension().getDownStreamRate());
				}

				if(service.getServiceExtension().getHdstream()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("HDStream", service.getServiceExtension().getHdstream());
				}

				subNetworkConnectionBuilder.setDates(service.getCreateddate(), service.getLastmodifieddate());

				if(service.getServiceExtension().getUsage()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("Usage", service.getServiceExtension().getUsage());



			}
			if(includeCustomer)
			{
				if(service.getSubscriber()!=null)
				{
					subNetworkConnectionBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber()));
				}
			}
			if(service.getAssociatedPorts()!=null)
			{		
				if(service.getAssociatedPorts()!=null && service.getAssociatedPorts().size()>0)
				{
					Port port = service.getAssociatedPorts().get(0);
					if(null != port)
					{
						if(port!=null && port.getPorttype()!=null && port.getPorttype().getName()!=null && port.getPorttype().getName().equalsIgnoreCase("VLAN Interface (T)"))
						{
							if(port.getNumberObjectList()!=null && port.getNumberObjectList().size()>0)
							{								
								LOG.info("Port : " + port.getPortid());
								Numberobject numberObject = port.getNumberObjectList().get(0);
								if(null != numberObject)
								{
									if(numberObject!=null && numberObject.getDimnumber()!=null && numberObject.getDimnumber().getName()!=null)
									{
										if(numberObject.getDimnumber().getDimnumbertype()!=null && numberObject.getDimnumber().getDimnumbertype().getName()!=null)
										{
											if(numberObject.getDimnumber().getDimnumbertype().getName().equalsIgnoreCase("VLAN"))
											{		//This will be for unicast IPTV/HSI											
												subNetworkConnectionBuilder.addResourceDescribedBy("CVLAN", numberObject.getDimnumber().getName());													
											}else if(numberObject.getDimnumber().getDimnumbertype().getName().equalsIgnoreCase("S-VLAN"))
											{		//This will be for multicast IPTV											
												subNetworkConnectionBuilder.addResourceDescribedBy("SVLAN", numberObject.getDimnumber().getName());													
											}

											if(service.getServicetype().getName().equalsIgnoreCase("HSI") || service.getServicetype().getName().equalsIgnoreCase("IPTV Unicast"))
											{
												List<Circuit> cktList = Circuit.getCircuitListByQuery(" (circuit2startport = " + port.getPortid() + " OR circuit2endport = " + port.getPortid() + ")");

												if(null != cktList && cktList.size() >0)
												{
													Circuit ckt = cktList.get(0);													
													Circuit assCircuit =  Circuitcircuit.getCircuitcircuitListByUsedBy(ckt.getCircuitid()).get(0).getUsesCircuit();													
													Port srtPort = assCircuit.getStartPort();													
													LOG.info("srtPort Name : " + srtPort.getName());
													if(srtPort.getNumberObjectList().size()>0 && srtPort.getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName().equalsIgnoreCase("S-VLAN")){

														subNetworkConnectionBuilder.addResourceDescribedBy("SVLAN", srtPort.getNumberObjectList().get(0).getDimnumber().getName());
													}																										
												}
											}													

											String NodeDef = null;
											String NodeType = null;
											List<Port> portList = service.getAssociatedPorts();
											for(Port associatedPort : portList){
												if(associatedPort.getNode()!=null && associatedPort.getNode().getNetworkroleobjects()!=null)
												{
													if(associatedPort.getNode().getNetworkroleobjects()!=null && associatedPort.getNode().getNetworkroleobjects().size()>0)
													{
														for(Networkroleobject nwkRoleObject: associatedPort.getNode().getNetworkroleobjects())
														{
															String role = nwkRoleObject.getNetworkroleobject2networkrole();
															if(role.equalsIgnoreCase("ONT"))
															{
																NodeDef = associatedPort.getNode().getNodeDef().getName();	
															}
															else if(role.equalsIgnoreCase("OLT"))
															{
																NodeType = associatedPort.getNode().getNodeType().getName();
															}
														}
													}
												}
											}


											if(NodeDef!=null&&NodeType!=null){
												String Query="ONT_NODEDEF_NM='"+NodeDef+"'and OLT_NODETYPE_NM='"+NodeType+"'";
												System.out.println("NodeDef:"+NodeDef+"getNodeType:"+NodeType);
												if(NodeDef!=null&&NodeType!=null)
													profilemList=OntProfile.getNodeListByQuery(Query);
												if(profilemList!=null&&profilemList.size()>0)
												{
													subNetworkConnectionBuilder.addResourceDescribedBy("ONTProfile",profilemList.get(0).getOntProfile());
													subNetworkConnectionBuilder.addResourceDescribedBy("ONTPWEProfile",profilemList.get(0).getOntPweProfile());
												}
											}

											boolean flag = false;
											for(Port associatedPort : portList){
												if(associatedPort!=null && associatedPort.getPorttype()!=null && associatedPort.getPorttype().getName()!=null && associatedPort.getPorttype().getName().equalsIgnoreCase("VLAN Interface (T)"))
												{
													if(associatedPort.getNode()!=null && associatedPort.getNode().getNetworkroleobjects()!=null)
													{
														LOG.info("associatedPort           : " + associatedPort.getName());
														LOG.info("associatedPort.getNode() : " + associatedPort.getNode().getName());
														if(associatedPort.getNode().getNetworkroleobjects()!=null && associatedPort.getNode().getNetworkroleobjects().size()>0)
														{
															for(Networkroleobject nwkRoleObject: associatedPort.getNode().getNetworkroleobjects())
															{
																String role = nwkRoleObject.getNetworkroleobject2networkrole();
																if(role.equalsIgnoreCase("ONT"))
																{																	
																	if(associatedPort.getNode().getCircuitsList()!=null && associatedPort.getNode().getCircuitsList().size()>0)
																	{
																		for(Circuit cir:associatedPort.getNode().getCircuitsList())
																		{																	
																			addPONCircuit(cir,subNetworkConnectionBuilder,includeLocation);
																		}
																	}
																	flag = true;
																	break;
																}																
															}
														}
													}
													if(flag){
														break;
													}
												}
											}
										}
									}
								}
							}

						}
					}
				}
			}
			if(includeRelationships)
			{
				if(service.getAssociatedServices()!=null && service.getAssociatedServices().size()>0)
				{
					for(Service relatedService:service.getAssociatedServices())
					{
						if(relatedService!=null && relatedService.getServicetype()!=null && relatedService.getServicetype().getName().equalsIgnoreCase("MEF EVC"))
						{
							point2PointCircuitBuilder.buildPoint2PointCircuit(relatedService.getName(), relatedService.getServiceid(), null, null, relatedService.getServicetype().getName(), relatedService.getProvisionstatus().getName(), null, null, null);
							if(relatedService.getServicetype()!=null)
								point2PointCircuitBuilder.setResourceTypes(relatedService.getServicetype().getName(),null);
							point2PointCircuitBuilder.addResourceDescribedBy("Usage",relatedService.getServiceExtension().getUsage());
							resourceRelationshipBuilder.buildResourceRelationship(null, null, null);
							resourceRelationshipBuilder.setCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
							subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
						}	
						if(relatedService!=null && relatedService.getServicetype()!=null && relatedService.getServicetype().getName().equalsIgnoreCase("IPTV") || (relatedService!=null && relatedService.getServicetype()!=null && relatedService.getServicetype().getName().equalsIgnoreCase("IPTV Unicast")))
						{
							point2PointCircuitBuilder.buildPoint2PointCircuit(relatedService.getName(), relatedService.getServiceid(), null, null, relatedService.getServicetype().getName(), relatedService.getProvisionstatus().getName(), null, null, null);	
							//point2PointCircuitBuilder.buildPoint2PointCircuit(relatedService.getName(), relatedService.getServiceid(), null, null, null, null, null, null, null);
							if(relatedService.getServicetype()!=null)
								point2PointCircuitBuilder.setResourceTypes(relatedService.getServicetype().getName(),null);
							point2PointCircuitBuilder.addResourceDescribedBy("Usage",relatedService.getServiceExtension().getUsage());
							resourceRelationshipBuilder.buildResourceRelationship(null, null, null,null,null);
							resourceRelationshipBuilder.setCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
							subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
						}  
					}
				}
			}
			if(service.getName() !=null)
				subNetworkConnectionBuilder.addAddressDetails(SearchLocationVOTransformation.getCLCServiceAddressFromName(service.getName()));

			return subNetworkConnectionBuilder.getSubNetworkConnection();
		}
		else
		{
			throw new OSSDataNotFoundException();
		}


	}

	private static void addPONCircuit(Circuit ckt,SubNetworkConnectionBuilder subNetworkConnectionBuilder,Boolean includeLocation) throws Exception
	{
		TerminationPointBuilder terminationPointBuilder=new TerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder=new LogicalPhysicalResourceBuilder();
		PhysicalDeviceBuilder physicalDeviceBuilder=new PhysicalDeviceBuilder();
		ResourceRelationshipBuilder resourceRelationshipBuilder =new ResourceRelationshipBuilder();
		Point2PointCircuitBuilder point2PointCircuitBuilder=new Point2PointCircuitBuilder();
		RemarkBuilder remarkBuilder=new RemarkBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();

		if(ckt!=null && ckt.getCircuittype()!=null && ckt.getCircuittype().getName().equalsIgnoreCase("PON Circuit (T)"))
		{
			point2PointCircuitBuilder.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, "ARM", ckt.getCircuittype().getName(), ckt.getProvisionstatus().getName(), null, null, null, ckt.getFunctionalstatus().getName(), null);

			if(ckt.getCircuitExtension().getRestrictedNotes()!=null)
			{
				point2PointCircuitBuilder.addResourceDescribedBy("RestrictedNotes", ckt.getCircuitExtension().getRestrictedNotes());
			}

			if(ckt.getCircuitExtension().getrestrictedStatus()!=null)
			{
				point2PointCircuitBuilder.addResourceDescribedBy("RestrictedStatus", ckt.getCircuitExtension().getrestrictedStatus());
			}
			resourceRelationshipBuilder.buildResourceRelationship(null, null, null);
			resourceRelationshipBuilder.setCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());

			subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());

			// Added code for HSIDetails Child
			if(ckt.getStartNode()!=null)
			{
				physicalDeviceBuilder.buildPhysicalDevice(ckt.getStartNode().getName(), ckt.getStartNode().getNodeid(), null, "ARM", null, null, ckt.getStartNode().getProvisionstatus().getName(), ckt.getStartNode().getNodeExtension().getClli(), null, null, ckt.getStartNode().getNodeExtension().getParttype(), null, ckt.getStartNode().getNodeExtension().getVendorname(), null, null, ckt.getEndNode().getFunctionalstatus().getName(), null);  

				if(ckt.getStartNode().getNodeExtension()!=null) 
				{
					if(ckt.getStartNode().getNodeExtension().getRestrictednotes()!=null)
					{
						remarkBuilder.buildRemark(ckt.getStartNode().getNodeExtension().getRestrictednotes(), "RestrictedNotes");
						physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
					}

					if(ckt.getStartNode().getNodeExtension().getRestrictedStatus()!=null)
					{
						physicalDeviceBuilder.addResourceDescribedBy("RestrictedStatus", ckt.getStartNode().getNodeExtension().getRestrictedStatus());
					}
				}
				/*if(ckt.getStartNode().getNodeExtension().getParttype()!=null)
					physicalDeviceBuilder.addResourceDescribedBy("Model", ckt.getStartNode().getNodeExtension().getParttype());*/

				if(ckt.getEndPort()!=null)
				{
					physicalDeviceBuilder.addResourceDescribedBy("PortType", ckt.getStartPort().getPorttype().getName());
				}
				if(ckt.getStartPort()!=null && ckt.getStartPort().getTopLevelPort()!=null)
				{
					if (!(ckt.getStartPort().getTopLevelPort()).isOnCard())
					{				
						physicalDeviceBuilder.addHasPorts(SearchPortVOTransformation.transformPortToCIM(ckt.getStartPort().getTopLevelPort(), "BASIC"));
						shelfBuilder.buildShelf(null, null, null);
						if(ckt.getStartPort().getNode()!=null)
						{
							shelfBuilder.setRackInformation(ckt.getStartPort().getNode().getNodeExtension().getRelayrackid(), null);
						}
						physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
					} 
					else 
					{
						if (ckt.getStartPort().getTopLevelPort().getCard()!=null && ckt.getStartPort().getTopLevelPort().getCard().getParentSlot()!=null && ckt.getStartPort().getTopLevelPort().getCard().getParentSlot().isOnCard())
						{
							Card cardCard = ckt.getStartPort().getTopLevelPort().getCard();
							Slot cardSlot = cardCard.getParentSlot();
							Card card = cardSlot.getParentCard();
							Slot slot = card.getParentSlot();
							Shelf shelf = slot.getShelf();
							String relayRackID=null;

							if(ckt.getStartPort().getNode()!=null && ckt.getStartPort().getNode().getNodeExtension().getRelayrackid()!=null)
							{
								relayRackID=ckt.getStartPort().getNode().getNodeExtension().getRelayrackid();
							}
							rackBuilder.buildRack(null, null, null, null, null, null, null, null);
							shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, relayRackID, null);
							slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
							cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCard2cardtype(), null);
							cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
							embededCardBuilder.buildCard(cardCard.getName(), cardCard.getCardid(), cardCard.getCard2provisionstatus(), null, null, null, null, cardCard.getAlias1(), cardCard.getCard2cardtype(), null);
							embededCardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(ckt.getStartPort().getTopLevelPort(), "BASIC"));

							cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
							cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
							slotBuilder.addHasCard(cardBuilder.getCard());
							shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
							rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
							physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
						} else 
						{
							Card card = ckt.getStartPort().getTopLevelPort().getCard();
							Slot slot = card.getParentSlot();
							Shelf shelf = slot.getShelf();
							String relayRackID=null;

							if(ckt.getStartPort().getNode()!=null && ckt.getStartPort().getNode().getNodeExtension().getRelayrackid()!=null)
							{
								relayRackID=ckt.getStartPort().getNode().getNodeExtension().getRelayrackid();
							}
							rackBuilder.buildRack(null, null, null, null, null, null, null, null);
							shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, relayRackID, null);
							slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
							cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCard2cardtype(), null);
							cardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(ckt.getStartPort().getTopLevelPort(), "BASIC"));
							slotBuilder.addHasCard(cardBuilder.getCard());
							shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
							rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
							physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
						}
					}
				}
				String role = null;
				if(ckt.getStartNode().getNetworkroleobjects()!=null && ckt.getStartNode().getNetworkroleobjects().size()>0)
				{

					for (Networkroleobject networkroleobject : ckt.getStartNode().getNetworkroleobjects())
					{
						physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
						physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
						if("ONT".equalsIgnoreCase(networkroleobject.getNetworkroleobject2networkrole())){
							role = "ONT";
						}
					}
				}
				logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
				logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
				terminationPointBuilder.buildTerminationPoint(null, null, null);
				terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
				if(includeLocation)
				{
					if(ckt.getStartNode().getLocation()!=null)
					{

						if(role!=null&&role.equalsIgnoreCase("ONT"))
						{
							terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCInstalledAddressFromLocation(ckt.getEndNode().getLocation(), ckt.getEndNode().getName()));
						}
						else
						{
							terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ckt.getStartNode().getLocation()));
						}
					}
				}
				subNetworkConnectionBuilder.addAEndTps(terminationPointBuilder.getTerminationPoint());
			}
			if(ckt.getEndNode()!=null)
			{
				physicalDeviceBuilder.buildPhysicalDevice(ckt.getEndNode().getName(), ckt.getEndNode().getNodeid(), null, "ARM", null, null, ckt.getEndNode().getProvisionstatus().getName(), ckt.getEndNode().getNodeExtension().getClli(), null, null, ckt.getEndNode().getNodeExtension().getParttype(), null, ckt.getEndNode().getNodeExtension().getVendorname(), null, null, ckt.getEndNode().getFunctionalstatus().getName(), null);

				if(ckt.getEndNode().getNodeExtension()!=null) 
				{
					if(ckt.getEndNode().getNodeExtension().getRestrictednotes()!=null)
					{
						remarkBuilder.buildRemark(ckt.getEndNode().getNodeExtension().getRestrictednotes(), "RestrictedNotes");
						physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
					}

					if(ckt.getEndNode().getNodeExtension().getRestrictedStatus()!=null)
					{
						physicalDeviceBuilder.addResourceDescribedBy("RestrictedStatus", ckt.getEndNode().getNodeExtension().getRestrictedStatus());

					}

					/*if(ckt.getEndNode().getNodeExtension().getParttype()!=null)
						physicalDeviceBuilder.addResourceDescribedBy("Model", ckt.getEndNode().getNodeExtension().getParttype());*/

					if(ckt.getEndNode().getNodeExtension().getRontaid()!=null)
					{
						physicalDeviceBuilder.addResourceDescribedBy("RONTAID", ckt.getEndNode().getNodeExtension().getRontaid());
					}
				}

				if(ckt.getEndPort()!=null && ckt.getEndPort().getTopLevelPort()!=null)
				{	
					String ontPhysicalPortName = getOntPhysicalPortName(foundService);		

					physicalDeviceBuilder.addResourceDescribedBy("ONTEthernetPortName", ontPhysicalPortName);			

				}

				if(ckt.getEndPort()!=null)
				{
					physicalDeviceBuilder.addResourceDescribedBy("PortType", ckt.getEndPort().getPorttype().getName());
				}
				String role=null;
				if(ckt.getEndNode().getNetworkroleobjects()!=null && ckt.getEndNode().getNetworkroleobjects().size()>0)
				{
					for (Networkroleobject networkroleobject : ckt.getEndNode().getNetworkroleobjects())
					{
						physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
						physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
						if("ONT".equalsIgnoreCase(networkroleobject.getNetworkroleobject2networkrole())){
							role = "ONT";
						}

					}
				}
				logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
				logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
				terminationPointBuilder.buildTerminationPoint(null, null, null);
				terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
				if(includeLocation)
				{
					if(ckt.getEndNode().getLocation()!=null)
					{

						if(role.equalsIgnoreCase("ONT"))
							terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCInstalledAddressFromLocation(ckt.getEndNode().getLocation(), ckt.getEndNode().getName()));
						else
							terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ckt.getEndNode().getLocation()));


					}
				}
				subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder.getTerminationPoint());
			}


		}
	}


	private static String getOntPhysicalPortName(Service foundService)
	{
		String circuitId = null;
		String portName = null;

		Port ontPort = new Port();
		Circuit circuitObj = new Circuit();

		String query = "SERVICE.NAME='"+ foundService.getName() +"' AND SERVICE.SERVICE2SERVICETYPE='"+ foundService.getService2servicetype() +"' AND SERVICEOBJECT.SERVICEOBJECT2DIMOBJECT='4'";
		List<Map<String,Object>> foundCircuitList = circuitObj.getcircuitIdListByQuery(query, true);                    

		for (Map<String,Object> circuitMap : foundCircuitList)
		{
			circuitId = circuitMap.get("CIRCUITID").toString();            			
		}                    


		if(circuitId!=null&&foundService!=null && foundService.getServicetype()!=null && (foundService.getServicetype().getName().equalsIgnoreCase("HSI") || foundService.getServicetype().getName().equalsIgnoreCase("IPTV Unicast") || foundService.getServicetype().getName().equalsIgnoreCase("IPTV") ))
		{
			String portId = ontPort.getONTEthernetPortName(circuitId);  
			Port newOntPort = new Port(portId);		
			portName = newOntPort.getName().toString();				
		}

		return portName;
	}

}
