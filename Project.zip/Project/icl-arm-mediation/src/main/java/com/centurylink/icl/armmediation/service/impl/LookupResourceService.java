package com.centurylink.icl.armmediation.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMSubscriber;
import com.centurylink.icl.armmediation.dataaccess.LookupDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.transformation.ARMLookupToCim;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

/**
 * Sub service class to interact with dao and pass the dao returned data to transformer
 *
 */
public class LookupResourceService
{

	private static final Log	LOG	= LogFactory.getLog(LookupResourceService.class);
	
	private LookupDAO			lookupDAO;
	private ARMLookupToCim		armLookupToCim;

	private static final String UNI_SERVICE = "UNI_Service";
	private static final String EVC_SERVICE = "EVC_Service";
	private static final String DIM_NUMBER = "DIMNUMBER";
	private static final String DIM_NUMBER_TYPE = "Dimnumbertype";
	
	
	/**
	 * 
	 * Lookup from ICL
	 *
	 */
	private enum LookupType
	{
		Device, Circuit,Customer
	}

	/**
	 * 
	 * Lookup from MDW
	 *
	 */
	private enum LookupTypeMDW
	{
		Status, Port, Device, Location, Hecig, Circuit, Service, Bandwidth, CircuitType, CircuitOnPort, ServiceType, Subscriber
	}

	public Map<String, Object> lookupFromMDW(Map<String, Object> inputMap) throws Exception //Need to throw Exception ?? TODO XXX 
	{
		final String entity = MediationUtil.getValueFromMap(inputMap, MDWConstants.ENTITY);

		switch (LookupTypeMDW.valueOf(entity))
		{

			case Status:

				return lookupStatus(inputMap);

			case Port:

				return lookupPort(inputMap);

			case Device:

				return lookupDeviceMDW(inputMap);

			case Location:

				return lookupLocation(inputMap);

			case Hecig:

				return lookupHECIGCode(inputMap);

			case Circuit:

				return lookupCiruitName(inputMap);

			case Service:

				return lookupServiceName(inputMap);

			case Bandwidth:

				return lookupBandwidth(inputMap);

			case CircuitType:

				return lookupCircuittype(inputMap);

			case CircuitOnPort:

				return lookupCircuitOnPort(inputMap);

			case ServiceType:

				return lookupServiceType(inputMap);

			case Subscriber:

				return lookupSubscriber(inputMap);

		}

		throw new Exception("Operation Not Supported");
	}

	public SearchResourceResponseDocument lookup(SearchResourceRequestDocument request) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Starting lookup from ICL..");
		}

		final String entity = ((SearchResourceRequestDocument) request).getSearchResourceRequest().getSearchResourceDetails().getEntity();

		System.out.println(entity);
		switch (LookupType.valueOf(entity))
		{

			case Device:

				return lookupDevice((SearchResourceRequestDocument) request);

			case Circuit:
				final String entityType = MediationUtil.getRcv(request, Constants.ENTITY_TYPE);
				final String status  = MediationUtil.getRcv(request, "Status");
				if (entityType != null && entityType.equalsIgnoreCase("EVC"))
				{
					return lookupService((SearchResourceRequestDocument) request,"EVC",status);
					
				} 
				else if ("LAG".equalsIgnoreCase(entityType))
				{
					return lookupCircuit((SearchResourceRequestDocument) request,"LAG",status);
				}
				else if ("UNI".equalsIgnoreCase(entityType))
				{
					return lookupService((SearchResourceRequestDocument) request,"UNI",status);
				}
				else if("CE-VLAN".equalsIgnoreCase(entityType)  || "S-VLAN".equalsIgnoreCase(entityType))
				{
					return lookupService((SearchResourceRequestDocument) request,entityType,status);
				}
				else if(null != entityType)
				{
					throw new ICLException("ICLRequestValidationError", "Invalid EntityType", "1948");
				}
				else
				{
					return lookupServiceAndCircuit((SearchResourceRequestDocument) request,status);
				}
			
			case Customer:
				
				return lookupSubscriberByUNIId((SearchResourceRequestDocument) request);
				
				
		}

		throw new Exception("Operation Not Supported");

	}

	/**
	 * Lookup to be performed from MDW
	 * 
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupStatus(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Status from mdw");
		}

		final String statusName = MediationUtil.getValueFromMap(inputMap, MDWConstants.STATUS_NAME);
		final Object dimObject = MediationUtil.getValueFromMap(inputMap, MDWConstants.DIM_OBJECT);

		final String query = buildStatusQuery(statusName, dimObject);
		final List<Map<String, Object>> lookupStatus = lookupDAO.lookupStatus(query);

		if (lookupStatus != null && lookupStatus.size() > 0)
		{
			lookupStatus.get(0).put(MDWConstants.errorCode, new Integer(0));
			return lookupStatus.get(0);
		} else
		{
			return errorMapNoDataFound();
		}

	}

	/**
	 * 
	 * Lookup to be performed from MDW
	 * 
	 * @param inputMap  - MDW Passes input parameters
	 * @return - Map with out values using MDWConstants
	 * @throws Exception
	 */
	private Map<String, Object> lookupPort(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Port from mdw");
		}

		final String portId = MediationUtil.getValueFromMap(inputMap, MDWConstants.PORT_ID);
		final String query = buildPortQuery(portId);
		final List<Map<String, Object>> lookupPort = lookupDAO.lookupPort(query);

		if (lookupPort != null && lookupPort.size() > 0)
		{
			lookupPort.get(0).put(MDWConstants.errorCode, new Integer(0));
			return lookupPort.get(0);
		} else
		{
			return errorMapNoDataFound();
		}

	}

	/**
	 * Lookup to be performed from MDW
	 * 
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupDeviceMDW(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Device from mdw");
		}

		final String deviceName = MediationUtil.getValueFromMap(inputMap, MDWConstants.DEVICE_NAME);
		final String query = buildDeviceQueryMDW(deviceName);
		final List<Map<String, Object>> deviceList = lookupDAO.lookupDeviceMDW(query);

		if (deviceList != null && deviceList.size() > 0)
		{
			deviceList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return deviceList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed from MDW
	 * 
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupLocation(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Location from mdw");
		}

		final String locationCLLI = MediationUtil.getValueFromMap(inputMap, MDWConstants.LOCATION_CLLI);
		final String query = buildLocationQuery(locationCLLI);
		final List<Map<String, Object>> locationList = lookupDAO.lookupLocationMDW(query);

		if (locationList != null && locationList.size() > 0)
		{
			locationList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return locationList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed by MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupHECIGCode(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup lookupHECIGCode from mdw");
		}

		final String hecigCode = MediationUtil.getValueFromMap(inputMap, MDWConstants.HESIG_CODE);
		final String query = buildHecigQuery(hecigCode);
		final List<Map<String, Object>> hecigList = lookupDAO.lookupHecigMDW(query);

		if (hecigList != null && hecigList.size() > 0)
		{
			hecigList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return hecigList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupCiruitName(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Ciruit Name from mdw");
		}

		final String circuitName = MediationUtil.getValueFromMap(inputMap, MDWConstants.CIRCUIT_NAME);
		final String query = buildCircuitNameQuery(circuitName);
		final List<Map<String, Object>> circuitNameList = lookupDAO.lookupCircuitNameMDW(query);
		
		if (circuitNameList != null && circuitNameList.size() > 0)
		{
			circuitNameList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return circuitNameList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupServiceName(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Service Name from mdw");
		}

		final String serviceName = MediationUtil.getValueFromMap(inputMap, MDWConstants.SERVICE_NAME);
		final String query = buildServiceNameQuery(serviceName);
		final List<Map<String, Object>> serviceNameList = lookupDAO.lookupServiceNameMDW(query);

		if (serviceNameList != null && serviceNameList.size() > 0)
		{
			serviceNameList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return serviceNameList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupBandwidth(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Bandwidth from mdw");
		}

		final String bandwidthKbpsValue = MediationUtil.getValueFromMap(inputMap, MDWConstants.KBPS_VALUE);
		final String query = buildBandwidthQuery(bandwidthKbpsValue);
		final List<Map<String, Object>> lookupBandwidth = lookupDAO.lookupBandwidth(query);

		if (lookupBandwidth != null && lookupBandwidth.size() > 0)
		{
			lookupBandwidth.get(0).put(MDWConstants.errorCode, new Integer(0));
			return lookupBandwidth.get(0);
		} else
		{

			return errorMapNoDataFound();
		}
	}

	/**
	 * To be called from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupCircuittype(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Circuittype from mdw");
		}

		final String circuittypeName = MediationUtil.getValueFromMap(inputMap, MDWConstants.CIRCUIT_TYPE_NAME);
		final String query = buildCircuittypeQuery(circuittypeName);
		final List<Map<String, Object>> lookupCircuittype = lookupDAO.lookupCircuitType(query);

		if (lookupCircuittype != null && lookupCircuittype.size() > 0)
		{
			lookupCircuittype.get(0).put(MDWConstants.errorCode, new Integer(0));
			return lookupCircuittype.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * To be called from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupCircuitOnPort(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup CircuitOnPort from mdw");
		}

		final String portId = MediationUtil.getValueFromMap(inputMap, MDWConstants.PORT_ID);
		final String query = buildCircuitOnPortQuery(portId);
		final List<Map<String, Object>> lookupCircuitOnPort = lookupDAO.lookupCircuitOnPort(query);

		if (lookupCircuitOnPort != null && lookupCircuitOnPort.size() > 0)
		{
			lookupCircuitOnPort.get(0).put(MDWConstants.errorCode, new Integer(0));
			return lookupCircuitOnPort.get(0);
		} else
		{
			return errorMapNoDataFound();
		}
	}

	/**
	 * Lookup to be performed from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupServiceType(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Service Type from mdw");
		}

		final String serviceTypeName = MediationUtil.getValueFromMap(inputMap, MDWConstants.SERVICE_TYPE_NAME);
		final String query = buildServiceTypeQuery(serviceTypeName);
		final List<Map<String, Object>> serviceTypeList = lookupDAO.lookupServiceType(query);

		if (serviceTypeList != null && serviceTypeList.size() > 0)
		{
			serviceTypeList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return serviceTypeList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}

	}

	/**
	 * Lookup to be performed from MDW
	 * @param inputMap
	 * @return
	 * @throws Exception
	 */
	private Map<String, Object> lookupSubscriber(Map<String, Object> inputMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside lookup Subcriber from mdw");
		}

		final String subscriberName = MediationUtil.getValueFromMap(inputMap, MDWConstants.SUBSCRIBER_NAME);
		final String query = buildSubscriberQuery(subscriberName);
		final List<Map<String, Object>> subscriberList = lookupDAO.lookupSubscriber(query);
		if (subscriberList != null && subscriberList.size() > 0)
		{
			subscriberList.get(0).put(MDWConstants.errorCode, new Integer(0));
			return subscriberList.get(0);
		} else
		{
			return errorMapNoDataFound();
		}

	}

	
	private String buildSubscriberQuery(String subscriberName)
	{

		final SQLBuilder sql = new SQLBuilder(Constants.SUBSCRIBER, Constants.SUR);

		sql.addFieldFromTable(Constants.SUR, Constants.SUBSCRIBER_ID);
		sql.addFieldFromTable(Constants.SUR, Constants.NAME);

		sql.eq(Constants.SUR, Constants.NAME, subscriberName);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Subscriber : " + query);
		}

		return query;
	}

	private String buildServiceTypeQuery(String serviceTypeName)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.SERVICE_TYPE, Constants.SER);

		sql.addFieldFromTable(Constants.SER, Constants.SERVICE_TYPE_ID);

		sql.eq(Constants.SER, Constants.NAME, serviceTypeName);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for ServiceType : " + query);
		}

		return query;
	}

	private String buildPortQuery(String portId)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.PORT, Constants.POT);

		sql.addFieldFromTable(Constants.POT, Constants.NAME);
		sql.addFieldFromTable(Constants.POT, Constants.PORT_ID);

		sql.addTable(Constants.STATUS, Constants.STS);

		sql.eq(Constants.POT, Constants.PORT_2_PROVISION_STATUS, Constants.STS, Constants.STATUS_ID);
		sql.eq(Constants.POT, Constants.PORT_ID, portId);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for PortLookup : " + query);
		}
		return query;
	}

	private String buildStatusQuery(String statusName, Object dimObject)
	{

		final SQLBuilder sql = new SQLBuilder(Constants.STATUS, Constants.STS);

		sql.addFieldFromTable(Constants.STS, Constants.STATUS_ID);

		sql.addTable(Constants.STATUS_TYPE, Constants.STE);
		sql.addTable(Constants.DIMENSION_OBJECT, Constants.DIT);

		sql.eq(Constants.STE, Constants.STATUS_TYPE_2_DIMENSION_OBJECT, Constants.DIT, Constants.DIMENSION_OBJECT_ID);
		sql.eq(Constants.STS, Constants.STATUS_2_STATUS_TYPE, Constants.STE, Constants.STATUS_TYPE_ID);
		sql.eq(Constants.DIT, Constants.NAME, (String) dimObject);
		sql.eq(Constants.STS, Constants.NAME, statusName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for StatusLookup : " + query);
		}
		return query;
	}

	private String buildDeviceQueryMDW(String deviceName)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.NODE, Constants.NOE);

		sql.addFieldFromTable(Constants.NOE, Constants.NAME);
		sql.addFieldFromTable(Constants.NOE, Constants.NODE_ID);
		sql.addFieldFromTable(Constants.STS, Constants.NAME);

		sql.addTable(Constants.STATUS, Constants.STS);

		sql.eq(Constants.NOE, Constants.NODE_2_PROVISION_STATUS, Constants.STS, Constants.STATUS_ID);
		sql.eq(Constants.NOE, Constants.NAME, deviceName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for DeviceLookupFromMDW : " + query);
		}
		return query;
	}

	private String buildHecigQuery(String hecigCode)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.ARM_OBJECT_HECIG, Constants.ARG);

		sql.addFieldFromTable(Constants.ARG, Constants.ARM_OBJECT_HECIG_2_ARM_OBJECT_ID, Constants.ARM_OBJECT_HECIG_2_ARM_OBJECT_ID);

		sql.eq(Constants.ARG, Constants.ARM_OBJECT_HECIG_2_ARM_OBJECT_DIM, "1");
		sql.eq(Constants.ARG, Constants.ARM_OBJECT_HECIG_2_HECIG, hecigCode);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Lookup Hecig :: " + query);
		}

		return query;
	}

	private String buildLocationQuery(String clli) throws Exception
	{

		final SQLBuilder sql = new SQLBuilder(Constants.LOCATION, Constants.LON);

		sql.addFieldFromTable(Constants.LON, Constants.NAME);
		sql.addFieldFromTable(Constants.LON, Constants.LOCATION_ID);
		sql.addFieldFromTable(Constants.EXTE, Constants.CLLI_CODE);

		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE, Constants.EXTE);

		sql.eq(Constants.LON, Constants.LOCATION_ID, Constants.EXTE, Constants.LOCATION_ID);

		sql.eq(Constants.EXTE, Constants.CLLI_CODE, clli);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for LocationLookup : " + query);
		}

		return query;
	}

	private String buildCircuitNameQuery(String circuitName)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT, Constants.CIT);

		sql.addFieldFromTable(Constants.CIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIT, Constants.NAME);

		sql.eq(Constants.CIT, Constants.NAME, circuitName);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for CircuitLookupFromMDW : " + query);
		}

		return query;
	}

	/*public String buildCircuitQuery(String criteria, String type)
	{

		final SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT, Constants.CIT);
		
		sql.addFieldFromTable(Constants.CIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIT, Constants.NAME);

		if (type.equalsIgnoreCase(Constants.CIRCUIT_ID))
		{
			sql.eq(Constants.CIT, Constants.CIRCUIT_ID, criteria);
		} else
		{
			sql.eq(Constants.CIT, Constants.NAME, criteria);
		}

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Circuit Lookup : " + query);
		}

		return query;
	}*/

	private String buildServiceQuery(String name,String entityType,String status)
	{
		
		final SQLBuilder serviceLookupSQL  
		= new SQLBuilder(Constants.SERVICE)
		  .addFieldFromTable(Constants.STATUS, Constants.NAME,Constants.STATUS_NAME)
		  .addFieldFromTable(Constants.SERVICE, Constants.NAME,Constants.SERVICE_NAME)
		  .addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID,Constants.SERVICE_ID)
		  .addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME,Constants.SERVICE_TYPE)
		  .addTable(Constants.STATUS)
		  .addTable(Constants.SERVICE_TYPE)
		 
		  .eq(Constants.SERVICE, "SERVICE2SERVICETYPE",Constants.SERVICE_TYPE,Constants.SERVICE_TYPE_ID)
		 .eq(Constants.SERVICE, "SERVICE2PROVISIONSTATUS",Constants.STATUS,Constants.STATUS_ID);
		
			if("EVC".equals(entityType))
			{
				serviceLookupSQL.eq(Constants.SERVICE_TYPE,Constants.NAME,"MEF EVC");
			}
			else if("UNI".equalsIgnoreCase(entityType))
			{
				serviceLookupSQL.eq(Constants.SERVICE_TYPE,Constants.NAME,"MEF UNI");
			}
			if("Active".equals(status))
			{
				serviceLookupSQL.in(Constants.STATUS, Constants.NAME, Arrays.asList("In Service","Planned","Configured","Pending Activation"));
			}	
			
			String[] table={Constants.SERVICE,Constants.SERVICE,Constants.SERVICE};
			String[] column={Constants.NAME,"ALIAS1","ALIAS2"};
			String[] values={name,name,name};
		  serviceLookupSQL.orClause(table,column,values);
		  

		final String query = serviceLookupSQL.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Service Lookup : " + query);
		}
		
		return query;
	}

	private String buildQueryForValidateVLAN(String uni,String entityType,String status,String evc)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.SERVICE,UNI_SERVICE)
		.addFieldFromTable(DIM_NUMBER, "dimnumberid", Constants.SERVICE_ID)
		.addFieldFromTable(DIM_NUMBER, Constants.NAME,Constants.SERVICE_NAME)
		.addFieldFromTable(DIM_NUMBER_TYPE,Constants.NAME,Constants.SERVICE_TYPE)
		.addFieldFromTable(Constants.STATUS,Constants.NAME, Constants.STATUS_NAME)
		.addFieldFromTable(Constants.EXT_NUMBER_VLAN,Constants.FUNCTION,"FUNCTION")
		.addTable(Constants.SERVICE, EVC_SERVICE)
		.addTable(Constants.STATUS)
		.addTable(Constants.SERVICEOBJECT)
		.addTable("numberobject")
		.addTable(DIM_NUMBER)
		.addTable(DIM_NUMBER_TYPE)
		.addTable(Constants.SERVICEOBJECT, "ueso")
		.addTable(Constants.EXT_NUMBER_VLAN)
		.eq(UNI_SERVICE, Constants.NAME,uni)
		.eq(EVC_SERVICE, Constants.NAME,evc)
		.eq("ueso","serviceobject2service",EVC_SERVICE,Constants.SERVICE_ID)
		.eq("ueso","serviceobject2object",UNI_SERVICE,Constants.SERVICE_ID)
		.eq(Constants.SERVICEOBJECT, "serviceobject2dimobject","4")
		.eq(Constants.SERVICEOBJECT, "serviceobject2service",EVC_SERVICE,Constants.SERVICE_ID)
		.eq("numberobject", "numberobject2object",Constants.SERVICEOBJECT,"serviceobject2object")
		.eq(DIM_NUMBER, "dimnumberid","numberobject","numberobject2number")
		.joinFO(DIM_NUMBER, "dimnumberid",Constants.EXT_NUMBER_VLAN,"dimnumberid")
		.eq(DIM_NUMBER_TYPE, "dimnumbertypeid",DIM_NUMBER,"dimnumber2dimnumbertype")
		.eq(DIM_NUMBER, "dimnumber2provisionstatus",Constants.STATUS,Constants.STATUS_ID);
		
		LOG.info("buildQueryForValidateVLAN>>>>>>> "+sql.getStatement());
		System.out.println(sql.getStatement());
		return sql.getStatement();
	}
	
	private String buildRelatedServiceQuery(String serviceId,String stats)
	{
		final SQLBuilder serviceQuery 
				= new SQLBuilder(Constants.SERVICE)
				.addFieldFromTable(Constants.SERVICE, Constants.NAME,Constants.SERVICE_NAME)
				.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID,Constants.SERVICE_ID)
				.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME,Constants.SERVICE_TYPE)
				.addFieldFromTable(Constants.STATUS, Constants.NAME, Constants.STATUS_NAME)
				.addTable(Constants.STATUS)
				.addTable(Constants.SERVICE_TYPE)
				.addTable(Constants.SERVICEOBJECT)
				.eq(Constants.SERVICE, "SERVICE2PROVISIONSTATUS", Constants.STATUS, Constants.STATUS_ID)
				.eq(Constants.SERVICE, "SERVICE2SERVICETYPE",Constants.SERVICE_TYPE,Constants.SERVICE_TYPE_ID)
				.in(Constants.STATUS, Constants.NAME, Arrays.asList("In Service","Planned","Configured","Pending Activation"))
				.eq(Constants.SERVICE, Constants.SERVICE_ID,Constants.SERVICEOBJECT,"serviceobject2service")
				.eq(Constants.SERVICEOBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT, "8")
				.eq(Constants.SERVICEOBJECT, "serviceobject2object",serviceId);
				
		return serviceQuery.getStatement();
	}
	private String buildRelatedCircuitsQuery(String circuitId,String status,boolean hasLAGCheckTrue)
	{
			final SQLBuilder circuitQuery 
				= new SQLBuilder(Constants.CIRCUIT)
				  .addFieldFromTable(Constants.STATUS, Constants.NAME,"STATUSNAME")
				  .addFieldFromTable(Constants.CIRCUIT, Constants.NAME,Constants.NAME)
				  .addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME,"CIRCUITTYPENAME")
				   .addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID,Constants.CIRCUIT_ID)
				  .addTable(Constants.STATUS)
				  .addTable(Constants.CIRCUIT_TYPE)
				  .addTable("CIRCUITCIRCUIT")
				  .eq(Constants.CIRCUIT, "circuit2PROVISIONSTATUS",Constants.STATUS,Constants.STATUS_ID)
				  .eq(Constants.CIRCUIT, "circuit2circuittype",Constants.CIRCUIT_TYPE,Constants.CIRCUIT_TYPE_ID)
				  .in(Constants.STATUS, Constants.NAME, Arrays.asList("In Service","Planned","Configured","Pending Activation"));
					if(hasLAGCheckTrue)
					{
						circuitQuery.eq(Constants.CIRCUIT, Constants.CIRCUIT_ID,"CIRCUITCIRCUIT","usedby2circuit")
						.eq(Constants.CIRCUIT_TYPE, Constants.NAME,"Link Aggregation Group")
						.eq("CIRCUITCIRCUIT","uses2circuit", circuitId);
						
					}
					else
					{
						circuitQuery.eq(Constants.CIRCUIT,Constants.CIRCUIT_ID,"CIRCUITCIRCUIT","uses2circuit")
						.eq("CIRCUITCIRCUIT","usedby2circuit", circuitId);
					}
		
		return circuitQuery.getStatement();
	}
	
	
	private String buildCircuitQuery(String name,String entityType,String status,String ccna)
	{

		final SQLBuilder circuuitQuery  
				= new SQLBuilder(Constants.CIRCUIT)
				  .addFieldFromTable(Constants.STATUS, Constants.NAME,"STATUSNAME")
				  .addFieldFromTable(Constants.CIRCUIT, Constants.NAME,Constants.NAME)
				  .addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID,Constants.CIRCUIT_ID)
				  .addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME,"CIRCUITTYPENAME")
				  .addTable(Constants.STATUS)
				  .addTable(Constants.CIRCUIT_TYPE)
				  
				  .eq(Constants.CIRCUIT, "circuit2PROVISIONSTATUS",Constants.STATUS,Constants.STATUS_ID)
				  .eq(Constants.CIRCUIT, "circuit2circuittype",Constants.CIRCUIT_TYPE,Constants.CIRCUIT_TYPE_ID);
				
				
				  if("LAG".equals(entityType))
				  {
					  
					  circuuitQuery.eq(Constants.CIRCUIT_TYPE,Constants.NAME,"Link Aggregation Group");
					  if(null != ccna && !"".equals(ccna))
					  {
						 circuuitQuery.eq(Constants.CIRCUIT, "RELATIVENAME",ccna);
					  }
					  
				  }
				  if("Active".equals(status))
				  {
					  circuuitQuery.in(Constants.STATUS, Constants.NAME, Arrays.asList("In Service","Planned","Configured","Pending Activation"));
				  }
				  circuuitQuery.eq(Constants.CIRCUIT, Constants.NAME,name)
				  .or(Constants.CIRCUIT, "ALIAS1",name)
				  .or(Constants.CIRCUIT, "ALIAS2",name);

		final String query = circuuitQuery.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Service Lookup : " + query);
		}
		
		return query;
	}
	
	private String buildDeviceQuery(String deviceClli, String objectId, String commonName) throws Exception
	{

		final SQLBuilder sql = new SQLBuilder(Constants.NODE, Constants.NOE);

		sql.addFieldFromTable(Constants.NOE, Constants.NAME, Constants.NAME);
		sql.addFieldFromTable(Constants.NOE, Constants.NODE_ID, Constants.NODE_ID);
		//sql.addFieldFromTable(Constants.NODE, Constants.DESCRIPTION, Constants.DESCRIPTION);
		sql.addFieldFromTable(Constants.EXT, Constants.CLLI, Constants.CLLI);
		sql.addFieldFromTable(Constants.STS, Constants.NAME, Constants.STATUS_NAME);
		
		

		sql.addTable(Constants.EXT_DEVICE_TYPE, Constants.EXT);
		sql.addTable(Constants.STATUS, Constants.STS);

		sql.eq(Constants.NOE, Constants.NODE_ID, objectId);
		sql.eq(Constants.NOE, Constants.NODE_2_PROVISION_STATUS, Constants.STS, Constants.STATUS_ID);
		sql.eq(Constants.EXT, Constants.NODE_ID, Constants.NOE, Constants.NODE_ID);
		if (objectId != null)
			sql.eq(Constants.NOE, Constants.NODE_ID, objectId);
		if (commonName != null)
			sql.eq(Constants.NOE, Constants.NAME, commonName);
		if (deviceClli != null)
			sql.eq(Constants.EXT, Constants.CLLI, deviceClli);

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for DeviceLookup : " + query);
		}

		return query;
	}
	
	private String buildDeviceQuery(String circuitId)
	{
		SQLBuilder builder = new SQLBuilder(Constants.SERVICE)
		.addFieldFromTable(Constants.NODE, Constants.NAME,Constants.NAME)
		.addFieldFromTable(Constants.NODE, Constants.NODE_ID, Constants.NODE_ID)
		.addFieldFromTable(Constants.NODE, Constants.DESCRIPTION, Constants.DESCRIPTION)
		.addFieldFromTable(Constants.EXT_NODE, Constants.CLLI, Constants.CLLI)
		.addFieldFromTable(Constants.NODEDEF,Constants.NAME,"NODEDEFNAME")
		.addFieldFromTable(Constants.STATUS, Constants.NAME,Constants.STATUS_NAME)
		.addFieldFromTable(Constants.NODEDEF, Constants.MANUFACTURER)
		.addFieldFromTable(Constants.EXT_NODE, Constants.PART_TYPE, "MODEL")
		.addFieldFromTable(Constants.EXT_NODE, Constants.VENDOR_NAME)
		.addFieldFromTable("LOCATION", "LOCATIONID","LOCATIONID")
		.addFieldFromTable("LOCATIONTYPE","TABLENAME","TABLENAME")
		.addTable(Constants.SERVICEOBJECT)
		.addTable(Constants.NODE)
		.addTable(Constants.PORT)
		.addTable(Constants.EXT_DEVICE_TYPE,Constants.EXT_NODE)
		.addTable(Constants.NODEDEF)
		.addTable(Constants.STATUS)
		.addTable("LOCATIONTYPE")
		.addTable("LOCATION")
		.eq(Constants.SERVICEOBJECT,"serviceobject2service",Constants.SERVICE,Constants.SERVICE_ID)
		.eq(Constants.SERVICEOBJECT, "serviceobject2dimobject","4")
		.eq(Constants.SERVICEOBJECT, "serviceobject2object",Constants.PORT,Constants.PORT_ID)
		.eq(Constants.PORT, Constants.PORT_2_NODE,Constants.NODE,Constants.NODE_ID)
		.eq(Constants.EXT_NODE, Constants.NODE_ID,Constants.NODE,Constants.NODE_ID)
		.eq(Constants.NODE, "node2nodedef",Constants.NODEDEF,"nodedefid")
		.eq(Constants.NODE,"node2provisionstatus",Constants.STATUS,Constants.STATUS_ID)
		.eq("LOCATION", "LOCATION2LOCATIONTYPE", "LOCATIONTYPE", "LOCATIONTYPEID")
		.eq(Constants.EXT_NODE, "NODEID", "NODE", "NODEID")
		.eq("NODE", "NODE2LOCATION", "LOCATION", "LOCATIONID")
		
		.eq(Constants.SERVICE,Constants.NAME,circuitId);
		
		return builder.getStatement();
		
	}
	
	
	private String buildServiceNameQuery(String serviceName)
	{
		final SQLBuilder sql = new SQLBuilder(Constants.SERVICE, Constants.SER);

		sql.addFieldFromTable(Constants.SER, Constants.SERVICE_ID, Constants.SERVICE_ID);
		sql.addFieldFromTable(Constants.SER, Constants.NAME, Constants.NAME);

		sql.eq(Constants.SER, Constants.NAME, serviceName);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for ServiceName :: " + query);
		}

		return query;
	}

	private String buildCircuitOnPortQuery(String portId) throws Exception
	{

		final SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT, Constants.CKT);

		sql.addFieldFromTable(Constants.CKT, Constants.NAME);
		sql.addFieldFromTable(Constants.CKT, Constants.CIRCUIT_ID);

		sql.addTable(Constants.PORT, Constants.PTP1);
		sql.addTable(Constants.PORT, Constants.PTP2);

		sql.eq(Constants.PTP1, Constants.PORT_ID, Constants.PTP2, Constants.PARENT_PORT_2_PORT);
		sql.or(Constants.PTP2, Constants.PORT_ID, Constants.CKT, Constants.CIRCUIT_2_END_PORT, Constants.PTP2, Constants.PORT_ID, Constants.CKT, Constants.CIRCUIT_2_START_PORT);
		sql.eq(Constants.PTP1, Constants.PORT_ID, portId);

		final String query = sql.getStatement();
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for CircuitOnPortLookup : " + query);
		}

		return query;
	}

	private String buildCircuittypeQuery(String circuittypeName) throws Exception
	{

		final SQLBuilder sql = new SQLBuilder(Constants.CIRCUIT_TYPE, Constants.CIE);

		sql.addFieldFromTable(Constants.CIE, Constants.CIRCUIT_TYPE_ID);
		sql.addFieldFromTable(Constants.CIE, Constants.NAME);

		sql.eq(Constants.CIE, Constants.NAME, circuittypeName);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for CircuitTypeLookup : " + query);
		}

		return query;
	}

	private String buildBandwidthQuery(String bandwidthKbpsValue) throws Exception
	{

		final SQLBuilder sql = new SQLBuilder(Constants.BANDWIDTH, Constants.BAH);

		sql.addFieldFromTable(Constants.BAH, Constants.NAME);
		sql.addFieldFromTable(Constants.BAH, Constants.BANDWIDTH_ID);

		sql.eq(Constants.BAH, Constants.KBPSVALUE, bandwidthKbpsValue);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Lookup Bandwidth : " + query);
		}

		return query;
	}

	
	
	private SearchResourceResponseDocument lookupDevice(SearchResourceRequestDocument request) throws Exception
	{
		String circuitId = MediationUtil.getRcv(request, "RUID");
		
		final String deviceClli = MediationUtil.getRcv(request,"DeviceCLLI");
		final String objectId = MediationUtil.getRcv(request, Constants.OBJECT_ID);
		final String commonName = MediationUtil.getRcv(request, Constants.COMMON_NAME);
		
		if (circuitId==null && deviceClli == null && objectId == null && commonName == null)
		{
			throw new ICLException("ICLRequestValidationError", "Invalid request", "1948");
		}
		else if (circuitId != null)
		{
			final List<ARMDevice> lookupDevice = lookupDAO.lookupDevice(buildDeviceQuery(circuitId));
			return armLookupToCim.transformToCim(lookupDevice, request);
		}
		else
		{
			final List<ARMDevice> deviceList = lookupDAO.lookupDevice(buildDeviceQuery(deviceClli, objectId, commonName));
			return armLookupToCim.transformToCim(deviceList, request);
		}
		
	}
	
	
	private SearchResourceResponseDocument lookupCircuit(SearchResourceRequestDocument request,String entityType,String status) throws Exception
	{
		final String name = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		
		String ccna = null;
		String returnRelatedCircuits = null;
		
		if(null == name)
		{
			throw new ICLException("ICLRequestValidationError", "Invalid request", "1948");
		}
		if("LAG".equals(entityType))
		{
			ccna = MediationUtil.getRcv(request, "CCNA");
			returnRelatedCircuits = MediationUtil.getRcv(request, "ReturnRelatedCircuits");
		}
		
		String query = buildCircuitQuery(name, entityType,status,ccna);
		final List<ARMCircuit> circuitList = lookupDAO.lookupCircuit(query);
		
		if("True".equalsIgnoreCase(returnRelatedCircuits) && circuitList != null && circuitList.size() > 0)
		{
			
			String evcCircuitId = circuitList.get(0).getObjectID();
			String relatedCircuitsQuery = buildRelatedCircuitsQuery(evcCircuitId, null,false);
			final List<ARMCircuit> relatedCircuits = lookupDAO.lookupCircuit(relatedCircuitsQuery);
			return armLookupToCim.transformCLSToCim(circuitList, request,relatedCircuits);
		}
		else
		{
			return armLookupToCim.transformToCim(circuitList, request);
		}
	}

	private SearchResourceResponseDocument lookupService(SearchResourceRequestDocument request,String entityType,String status) throws Exception
	{
		final String name = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		String returnRelatedEVC = MediationUtil.getRcv(request, "ReturnRelatedEVC");
		List<ARMCircuit> serviceList = null;
		
		if(null == name && ((!"CE-VLAN".equals(entityType)) && (!"S-VLAN".equals(entityType))))
		{
			throw new ICLException("ICLRequestValidationError", "Invalid request", "1948");
		}
		
		if("CE-VLAN".equalsIgnoreCase(entityType)  || "S-VLAN".equalsIgnoreCase(entityType))
		{
			String evcId = MediationUtil.getRcv(request, "EVCId");
			String uniId = MediationUtil.getRcv(request, "RUID");
					
			serviceList = lookupDAO.lookupService(buildQueryForValidateVLAN(uniId,null,status,evcId));
		}
		else
		{
			serviceList = lookupDAO.lookupService(buildServiceQuery(name,entityType,status));
		}
		
		if("True".equalsIgnoreCase(returnRelatedEVC) && serviceList != null && serviceList.size() > 0)
		{
			
			String uniServiceId = serviceList.get(0).getObjectID();
			String relatedEVCsQuery = buildRelatedServiceQuery(uniServiceId, null);
			final List<ARMCircuit> relatedEVCs = lookupDAO.lookupService(relatedEVCsQuery);
			return armLookupToCim.transformToCim(serviceList, request,relatedEVCs);
		}
		else
		{
			return armLookupToCim.transformToCim(serviceList, request);
		}
	}

	
	private SearchResourceResponseDocument lookupServiceAndCircuit(SearchResourceRequestDocument request,String status) throws Exception
	{
		final String name = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		if(null == name)
		{
			throw new ICLException("ICLRequestValidationError", "Invalid request : commonName not found", "1948");
		}
		final List<ARMCircuit> serviceList = lookupDAO.lookupService(buildServiceQuery(name,null,status));
		if(serviceList !=null && !serviceList.isEmpty())
		{
			return armLookupToCim.transformToCim(serviceList, request);
		}
		else
		{
			final List<ARMCircuit> circuitList = lookupDAO.lookupCircuit(buildCircuitQuery(name, null,status,null));
			if(null != circuitList && !circuitList.isEmpty() && "True".equalsIgnoreCase(MediationUtil.getRcv(request, "HasLAG")))
			{
				String circuitId = circuitList.get(0).getObjectID();
				List<ARMCircuit> relatedLAG = lookupDAO.lookupCircuit(buildRelatedCircuitsQuery(circuitId, status, true));
				
				return armLookupToCim.transformCLSToCim(circuitList, request, relatedLAG);
			}
			else
			{
				return armLookupToCim.transformToCim(circuitList, request);
			}
		}
	}
	
	
	private SearchResourceResponseDocument lookupSubscriberByUNIId(SearchResourceRequestDocument request) throws Exception
	{
		final String uniId = MediationUtil.getRcv(request, "RUID");
		
		if(null == uniId)
		{
			throw new ICLException("ICLRequestValidationError", "Invalid request : RUID not found", "1948");
		}
		final List<ARMSubscriber> subscriberList = lookupDAO.lookupSubscriberByUNIId(buildSubscriberByUNIIdQuery(uniId));
		return armLookupToCim.transformToCim(subscriberList, request);
		
	}
	
	private String buildSubscriberByUNIIdQuery(String uniId)
	{
				
		SQLBuilder subscriberQuery = new SQLBuilder(Constants.SUBSCRIBER)
									.addTable(Constants.SUBSCRIBERTYPE)
									.addTable(Constants.SERVICE)
									.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME,Constants.NAME)
									.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID, Constants.SUBSCIBER_ID)
									.addFieldFromTable(Constants.SUBSCRIBERTYPE, Constants.NAME, "SUBSCRIBERTYPENAME")
									.eq(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID,Constants.SERVICE,"service2subscriber")
									.eq(Constants.SUBSCRIBER, "subscriber2subscribertype",Constants.SUBSCRIBERTYPE,"subscribertypeid")
									.eq(Constants.SERVICE,Constants.NAME, uniId);
		
		
		return subscriberQuery.getStatement();
		
	}
	

	private Map<String, Object> errorMapNoDataFound()
	{
		final Map<String, Object> errorMap = new HashMap<String, Object>();
		errorMap.put(MDWConstants.errorCode, new Integer(1951));
		errorMap.put(MDWConstants.errorMessage, "No Data Found in ARM");
		return errorMap;
	}

	public void setLookupDAO(LookupDAO lookupDAO)
	{
		this.lookupDAO = lookupDAO;
	}

	public void setArmLookupToCim(ARMLookupToCim armLookupToCim)
	{
		this.armLookupToCim = armLookupToCim;
	}

}
