package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMSubscriber;
import com.centurylink.icl.armmediation.dataaccess.LookupDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.MDWConstants;

public class LookupDAOImpl implements LookupDAO
{

	private JdbcTemplate jdbcTemplate;

	public LookupDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<ARMDevice> lookupDevice(String query) throws Exception
	{

		final List<ARMDevice> armDevices = this.jdbcTemplate.query(query, new RowMapper<ARMDevice>() {
			public ARMDevice mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMDevice armDevice = new ARMDevice();
				armDevice.setCommonName(rs.getString("NAME"));
				armDevice.setObjectID(rs.getString("NODEID"));
				armDevice.setDescription(rs.getString(Constants.DESCRIPTION));
				armDevice.setClliCode(rs.getString("CLLI"));
				armDevice.setName(rs.getString("NODEDEFNAME"));
				armDevice.setPrStatus(rs.getString(Constants.STATUS_NAME));
				armDevice.setManufacturer(rs.getString(Constants.MANUFACTURER));
				armDevice.setModel(rs.getString("MODEL"));
				armDevice.setVendorName(rs.getString(Constants.VENDOR_NAME));
				if("EXT_LOCATION_BUILDING_SITE".equals(rs.getString("TABLENAME")))
				{
					List<String> clli = jdbcTemplate.query("SELECT CLLICODE FROM EXT_LOCATION_BUILDING_SITE WHERE LOCATIONID="+rs.getString("LOCATIONID"),
							new RowMapper<String>(){

								@Override
								public String mapRow(ResultSet rs, int rowNum)
										throws SQLException {
									
									return rs.getString("CLLICODE");
								}
							}
					);
					
					if(clli != null && clli.size() > 0 )
					{
						armDevice.setLocationClli(clli.get(0));
					}
					
				}
				//armDevice.setLocationClli(rs.getString(Constants.LOCATION));
				armDevice.setSourceSystem("ARM");
				return armDevice;
			}
		});

		return armDevices;

	}

	@Override
	public List<ARMCircuit> lookupCircuit(String query) throws Exception
	{
		final List<ARMCircuit> armCircuits = this.jdbcTemplate.query(query, new RowMapper<ARMCircuit>() {
			public ARMCircuit mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuit armCircuit = new ARMCircuit();
				armCircuit.setCommonName(rs.getString("NAME"));
				armCircuit.setObjectID(rs.getString("CIRCUITID"));
				armCircuit.setSourceSystem("ARM");
				armCircuit.setStatus(rs.getString("STATUSNAME"));
				String resourceType = rs.getString("CIRCUITTYPENAME");
				
				if("Link Aggregation Group".equals(resourceType))
				{
					armCircuit.setResourceType("LAG");
				}
				else if("MEF EVC".equals(resourceType))
				{
					armCircuit.setResourceType("EVC");
				}
				else
				{
					armCircuit.setResourceType(resourceType);
				}
				return armCircuit;
			}
		});

		return armCircuits;
	}

	@Override
	public List<ARMCircuit> lookupService(String query) throws Exception
	{
		final List<ARMCircuit> armCircuits = this.jdbcTemplate.query(query, new RowMapper<ARMCircuit>() {
			public ARMCircuit mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCircuit armCircuit = new ARMCircuit();
				armCircuit.setObjectID(rs.getString(Constants.SERVICE_ID));
				armCircuit.setCommonName(rs.getString(Constants.SERVICE_NAME));
				String resourceType = rs.getString(Constants.SERVICE_TYPE);
									
				if("MEF UNI".equalsIgnoreCase(resourceType))
				{
					armCircuit.setResourceType("UNI");
				}
				else if("MEF EVC".equalsIgnoreCase(resourceType))
				{
					armCircuit.setResourceType("EVC");
				}
				else if("VLAN".equalsIgnoreCase(resourceType))
				{
					if(rs.getString("FUNCTION")!=null)
					{
						armCircuit.setVlanFunction(rs.getString("FUNCTION"));
					}
					armCircuit.setResourceType(resourceType);
				}
				else 
				{
					armCircuit.setResourceType(resourceType);
				}
				
				
				
				armCircuit.setStatus(rs.getString(Constants.STATUS_NAME));
				armCircuit.setSourceSystem("ARM");
				return armCircuit;
			}
		});

		return armCircuits;
	}

	@Override
	public List<ARMLocation> lookupLocation(String query)
	{

		final List<ARMLocation> armLocationList = this.jdbcTemplate.query(query, new RowMapper<ARMLocation>() {

			public ARMLocation mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMLocation armLocation = new ARMLocation();
				armLocation.setCommonName(rs.getString("NAME"));
				armLocation.setObjectID(rs.getString("LOCATIONID"));
				armLocation.setClli(rs.getString("CLLICODE"));
				armLocation.setSourceSystem("ARM");
				return armLocation;

			}
		});
		return armLocationList;

	}

	@Override
	public List<ARMDevice> lookupHecigCode(String query) throws Exception
	{

		final List<ARMDevice> armDevices = this.jdbcTemplate.query(query, new RowMapper<ARMDevice>() {
			public ARMDevice mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMDevice armDevice = new ARMDevice();
				armDevice.setCharacteristicValue(rs.getString("ARMOBJECTHECIG2ARMOBJECTID"));

				return armDevice;
			}
		});

		return armDevices;

	}

	@Override
	public List<Map<String, Object>> lookupPort(String query) throws Exception
	{
		final List<Map<String, Object>> armPorts = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armPort = new HashMap<String, Object>();
				armPort.put(MDWConstants.COMMON_NAME, rs.getString("NAME"));
				armPort.put(MDWConstants.OBJECTID, rs.getString("PORTID"));
				armPort.put(MDWConstants.SOURCESYSTEM, "ARM");

				return armPort;
			}
		});

		return armPorts;
	}

	@Override
	public List<Map<String, Object>> lookupStatus(String query) throws Exception
	{
		final List<Map<String, Object>> armStatuses = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armStatus = new HashMap<String, Object>();
				armStatus.put(MDWConstants.STATUS_ID, rs.getString(Constants.STATUS_ID));

				return armStatus;
			}
		});

		return armStatuses;
	}

	@Override
	public List<Map<String, Object>> lookupDeviceMDW(String query) throws Exception
	{
		final List<Map<String, Object>> armDevices = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armDevice = new HashMap<String, Object>();
				armDevice.put(MDWConstants.DEVICE_NAME, rs.getString(Constants.NAME));
				armDevice.put(MDWConstants.DEVICE_ID, rs.getString(Constants.NODE_ID));
				armDevice.put(MDWConstants.DEVICE_PROVISION, rs.getString(Constants.NAME));

				return armDevice;
			}
		});

		return armDevices;
	}

	@Override
	public List<Map<String, Object>> lookupLocationMDW(String query) throws Exception
	{
		final List<Map<String, Object>> armLocations = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armLocation = new HashMap<String, Object>();

				armLocation.put(MDWConstants.LOCATION_NAME, rs.getString("NAME"));
				armLocation.put(MDWConstants.LOCATION_ID, rs.getString("LOCATIONID"));
				armLocation.put(MDWConstants.LOCATION_CLLI, rs.getString("CLLICODE"));

				return armLocation;
			}
		});

		return armLocations;
	}

	@Override
	public List<Map<String, Object>> lookupHecigMDW(String query) throws Exception
	{
		final List<Map<String, Object>> armHecigs = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armHecig = new HashMap<String, Object>();

				armHecig.put(MDWConstants.DEVICE_DEF_ID, rs.getString("ARMOBJECTHECIG2ARMOBJECTID"));

				return armHecig;
			}
		});

		return armHecigs;
	}

	@Override
	public List<Map<String, Object>> lookupCircuitNameMDW(String query) throws Exception
	{
		final List<Map<String, Object>> armCircuitNames = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armCircuitName = new HashMap<String, Object>();

				armCircuitName.put(MDWConstants.CIRCUIT_ID, rs.getString(Constants.CIRCUIT_ID));
				armCircuitName.put(MDWConstants.CIRCUIT_NAME, rs.getString(Constants.NAME));

				return armCircuitName;
			}
		});

		return armCircuitNames;
	}

	@Override
	public List<Map<String, Object>> lookupServiceNameMDW(String query) throws Exception
	{
		final List<Map<String, Object>> armServiceNames = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armServiceName = new HashMap<String, Object>();

				armServiceName.put(MDWConstants.SERVICE_ID, rs.getString(Constants.SERVICE_ID));
				armServiceName.put(MDWConstants.NAME, rs.getString(Constants.NAME));

				return armServiceName;
			}
		});

		return armServiceNames;
	}

	@Override
	public List<Map<String, Object>> lookupBandwidth(String query) throws Exception
	{
		final List<Map<String, Object>> armBandwidths = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armBandwidth = new HashMap<String, Object>();

				armBandwidth.put(MDWConstants.BANDWIDTH_NAME, rs.getString("NAME"));
				armBandwidth.put(MDWConstants.BANDWIDTH_ID, rs.getString("BANDWIDTHID"));

				return armBandwidth;
			}
		});

		return armBandwidths;
	}

	@Override
	public List<Map<String, Object>> lookupCircuitType(String query) throws Exception
	{
		final List<Map<String, Object>> armCircuitTypes = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armCircuitType = new HashMap<String, Object>();
				armCircuitType.put(MDWConstants.NAME, rs.getString("NAME"));
				armCircuitType.put(MDWConstants.CIRCUIT_TYPE_ID, rs.getString("CIRCUITTYPEID"));

				return armCircuitType;
			}
		});

		return armCircuitTypes;
	}

	@Override
	public List<Map<String, Object>> lookupCircuitOnPort(String query) throws Exception
	{
		final List<Map<String, Object>> armCircuitsOnPort = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armCircuitOnPort = new HashMap<String, Object>();
				armCircuitOnPort.put(MDWConstants.CIRCUIT_NAME, rs.getString("NAME"));
				armCircuitOnPort.put(MDWConstants.CIRCUIT_ID, rs.getString("CIRCUITID"));

				return armCircuitOnPort;
			}
		});

		return armCircuitsOnPort;
	}

	@Override
	public List<Map<String, Object>> lookupServiceType(String query) throws Exception
	{
		final List<Map<String, Object>> armServiceTypes = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armServiceType = new HashMap<String, Object>();

				armServiceType.put(MDWConstants.SERVICE_TYPE_ID, rs.getString(Constants.SERVICE_TYPE_ID));

				return armServiceType;
			}
		});

		return armServiceTypes;
	}

	@Override
	public List<Map<String, Object>> lookupSubscriber(String query) throws Exception
	{
		final List<Map<String, Object>> armSubscribers = this.jdbcTemplate.query(query, new RowMapper<Map<String, Object>>() {
			public Map<String, Object> mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				HashMap<String, Object> armSubscriber = new HashMap<String, Object>();

				armSubscriber.put(MDWConstants.NAME, rs.getString(Constants.NAME));
				armSubscriber.put(MDWConstants.SUBSCRIBER_ID, rs.getString(Constants.SUBSCRIBER_ID));

				return armSubscriber;
			}
		});

		return armSubscribers;
	}

	@Override
	public List<ARMSubscriber> lookupSubscriberByUNIId(String query)
			throws Exception {

		final List<ARMSubscriber> armSubscribers = this.jdbcTemplate.query(query, new RowMapper<ARMSubscriber>() {
			public ARMSubscriber mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMSubscriber armSubscriber = new ARMSubscriber();
				armSubscriber.setCommonName(rs.getString("NAME"));
				armSubscriber.setObjectId(rs.getString("subscriberId"));
				armSubscriber.setSourceSystem("ARM");
				armSubscriber.setPartyType(rs.getString("SUBSCRIBERTYPENAME"));
				return armSubscriber;
			}
		});
		
		return armSubscribers;
	}

}
