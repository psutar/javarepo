package com.centurylink.icl.armmediation.transformation;

import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.service.impl.QCtrlNotificationsService;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CountryBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.ResourceNotificationBuilder;
import com.centurylink.icl.builder.cim2.ResourceNotificationDocumentBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.UNICircuitBuilder;
import com.centurylink.icl.builder.iclnotification.ParameterBuilder;
import com.centurylink.icl.builder.util.SearchResourceRequestDocumentHelper;
import com.centurylink.icl.iclnotification.EventNotification;
import com.centurylink.icl.iclnotification.EventNotificationDocument;
import com.centurylink.icl.iclnotification.Parameter;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.ConnectionTerminationPoint;
import com.iclnbi.iclnbiV200.MessageAddressing;
import com.iclnbi.iclnbiV200.MessageElements;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceNotification;
import com.iclnbi.iclnbiV200.ResourceNotificationDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TerminationPoint;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UNICircuit;

public class ARMCLCNotificationTransformation {
	
	private static final Log LOG = LogFactory.getLog(ARMCLCNotificationTransformation.class);
	
	
	/**
	 * EVC Notification contain the same data as event contains. Just convert the event to ResourceNotification.
	 * @param event
	 * @return
	 */
	private static ResourceNotificationDocument transformSimpleServiceEventToResourceNotification(EventNotificationDocument event,String action,String type) 
	{
		try
		{
			
			SubNetworkConnectionBuilder evcCircuitBuilder = new SubNetworkConnectionBuilder();
			
			EventNotification eventNotification = event.getEventNotification();
			Parameter resourceSubtypeParameter = getParameterValue(event, "ResourceSubtype");
			

			evcCircuitBuilder.buildSubNetworkConnection(eventNotification.getCommonName(),eventNotification.getObjectId(), null, "ARM", (resourceSubtypeParameter == null) ? null : resourceSubtypeParameter.getValue(),null,null,null);
			evcCircuitBuilder.setAction(action);
			SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			searchResponseDetailsBuilder.addVoidCircuit(evcCircuitBuilder.getSubNetworkConnection());

			ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
			resourceNotificationBuilder.buildResourceNotification(null, getMessageElements(type));
			resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
			
			ResourceNotificationDocumentBuilder notificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
			notificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
			//System.out.println(notificationDocumentBuilder.getResourceNotificationDocument());
			LOG.info(notificationDocumentBuilder.getResourceNotificationDocument());
			return notificationDocumentBuilder.getResourceNotificationDocument();
		}
		catch(Exception e)
		{
			LOG.error("Could not process ResourceNotification for "+type + "   "+ action , e);
		}
		return null;
	}
	
	
	public static ResourceNotificationDocument transformEVCToResourceNotification(EventNotificationDocument event,String action) throws Exception
	{
		return transformSimpleServiceEventToResourceNotification(event, action, "EVCNotification");
	}
	
	/**
	 * Get the CLC Location from CLC and add an extra NVP for "Action"
	 * @param address
	 * @param action
	 * @return
	 */
	public static ResourceNotificationDocument transformLocationToResourceNotification(AmericanPropertyAddress address,String action) 
	{

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		americanPropertyAddressBuilder.buildAmericanPropertyAddress(address.getCommonName(),address.getObjectID(),null,"CLC",address.getStreetName(),address.getLocality(),address.getPostcode(),address.getAddressLine1(),address.getAddressLine2(),address.getAddressLine3(),address.getStateOrProvince(),address.getAddressType());
		americanPropertyAddressBuilder.addRootEntityDescribedBy("Action", action);
		
		CountryBuilder countryBuilder = new CountryBuilder();
		countryBuilder.buildCountry(null, null);
		countryBuilder.setCountryName("USA");
		countryBuilder.getCountry();
		
		americanPropertyAddressBuilder.addCountry(countryBuilder.getCountry());
		
		searchResponseDetailsBuilder.addAddressDetails(americanPropertyAddressBuilder.getAmericanPropertyAddress());
		
		ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
		resourceNotificationBuilder.buildResourceNotification(null, getMessageElements("LocationNotification"));
		resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
		
		ResourceNotificationDocumentBuilder notificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
		notificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
		
		return notificationDocumentBuilder.getResourceNotificationDocument();
	
		
	}
	
	public static ResourceNotificationDocument transformDeleteUNIToResourceNotification(EventNotificationDocument event,String action) throws Exception
	{
		
		return transformSimpleServiceEventToResourceNotification(event, action, "UNINotification");
		
	}
	
	public static ResourceNotificationDocument transformUNIToResourceNotification(SearchResourceResponseDocument searchResourceResponseDocument,EventNotificationDocument event,String action) 
	{
		try {
			
			
		   TopologicalLink topologicalLink = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getP2PCircuitList().get(0);
			
			OwnsResourceDetails ownsResourceDetails = topologicalLink.getOwnsResourceDetails();
			
			
			UNICircuitBuilder uniCircuitBuilder = new UNICircuitBuilder();
			//uniCircuitBuilder.buildUNICircuit(topologicalLink.getCommonName(), topologicalLink.getObjectID(), topologicalLink.getDescription(), "ARM", topologicalLink.getResourceType(), topologicalLink.getLrStatus(), null, topologicalLink.getBandwidth(),"ADD");
			uniCircuitBuilder.buildUNICircuit(topologicalLink.getCommonName(), topologicalLink.getObjectID(), null, "ARM", topologicalLink.getResourceType(), topologicalLink.getLrStatus(), null, null, null, topologicalLink.getAliasName(), topologicalLink.getAliasName2(), null, null, null, null, null, null, null, null, topologicalLink.getBandwidth());
			uniCircuitBuilder.addAction(action);
			List<ResourceCharacteristicValue> resourceDescribedByList = topologicalLink.getResourceDescribedByList();
			for (ResourceCharacteristicValue resourceCharacteristicValue : resourceDescribedByList) {
				
				uniCircuitBuilder.addResourceDescribedBy(resourceCharacteristicValue.getCharacteristicName(), resourceCharacteristicValue.getCharacteristicValue());
				
			}
			
			if(((UNICircuit)topologicalLink).getQoSBandwidthList() != null && ((UNICircuit)topologicalLink).getQoSBandwidthList().size() > 0){
				
				uniCircuitBuilder.addResourceDescribedBy("QoSExists", "Yes");
			}
			else
			{
				uniCircuitBuilder.addResourceDescribedBy("QoSExists", "No");
			}
			
			uniCircuitBuilder.setOwnsResourceDetails(ownsResourceDetails);
			
			if(topologicalLink.getZEndTpsList() != null && topologicalLink.getZEndTpsList().size() >0)
			{
				TerminationPoint terminationPoint = topologicalLink.getZEndTpsList().get(0);
				uniCircuitBuilder.addZEndTps((ConnectionTerminationPoint)terminationPoint);
			}
			SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			searchResponseDetailsBuilder.addP2PCircuit(uniCircuitBuilder.getUNICircuit());
			
			ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
			resourceNotificationBuilder.buildResourceNotification(null, getMessageElements("UNINotification"));
			resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
			
			ResourceNotificationDocumentBuilder resourceNotificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
			resourceNotificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
			LOG.info(resourceNotificationDocumentBuilder.getResourceNotificationDocument());
			//System.out.println(resourceNotificationDocumentBuilder.getResourceNotificationDocument());
			return resourceNotificationDocumentBuilder.getResourceNotificationDocument();
		
			
		} catch (Exception e) {
			
			LOG.error("Could not process  UNI ResourceNotification" ,e);
		}
		return null;
	}

	@SuppressWarnings("deprecation")
	public static ResourceNotificationDocument transformEvcMemberToResourceNotification(SearchResourceResponseDocument searchResourceResponseDocument,EventNotificationDocument event,String resourceSubtype) {
		
		SubNetworkConnection subNetworkConnection = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList().get(0);
	
		SubNetworkConnectionBuilder circuitBuilder = new SubNetworkConnectionBuilder();
		circuitBuilder.buildSubNetworkConnection(subNetworkConnection.getCommonName(), subNetworkConnection.getObjectID(), null, "ARM", "EVCMember", subNetworkConnection.getLrStatus(), null, null, subNetworkConnection.getAliasName(), subNetworkConnection.getAliasName2(), null, null,subNetworkConnection.getBandwidth());
		circuitBuilder.setAction(event.getEventNotification().getAction());
		List<ResourceCharacteristicValue> resourceDescribedByList = subNetworkConnection.getResourceDescribedByList();
		for (ResourceCharacteristicValue resourceCharacteristicValue : resourceDescribedByList) {
			
			circuitBuilder.addResourceDescribedBy(resourceCharacteristicValue.getCharacteristicName(), resourceCharacteristicValue.getCharacteristicValue());
			
		}
		
		Parameter associatedService = getAssociatedService(event, resourceSubtype);
		if(associatedService != null)
		{
			ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
			resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
			
			Point2PointCircuitBuilder associatedCircuitBuilder = new Point2PointCircuitBuilder();
			associatedCircuitBuilder.buildPoint2PointCircuit(associatedService.getValue(), associatedService.getObjectId(), null, null, associatedService.getType(), null, null, null, null);
			resourceRelationshipBuilder.setCircuit(associatedCircuitBuilder.getPoint2PointCircuit());
			circuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
		}
		
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		searchResponseDetailsBuilder.addVoidCircuit(circuitBuilder.getSubNetworkConnection());
		
		ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
		resourceNotificationBuilder.buildResourceNotification(null, null);
		resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
		
		ResourceNotificationDocumentBuilder resourceNotificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
		resourceNotificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
		
		return resourceNotificationDocumentBuilder.getResourceNotificationDocument();
	}
	
	public static ResourceNotificationDocument transformDeleteLocationToResourceNotification(EventNotificationDocument event)
	{
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		americanPropertyAddressBuilder.buildAmericanPropertyAddress(event.getEventNotification().getCommonName(),event.getEventNotification().getObjectId(),null,"ARM",null,null,null,null,null,null,null,null);
		americanPropertyAddressBuilder.addRootEntityDescribedBy("Action", "DELETE");
		
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		searchResponseDetailsBuilder.addAddressDetails(americanPropertyAddressBuilder.getAmericanPropertyAddress());
		
		ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
		resourceNotificationBuilder.buildResourceNotification(null, null);
		resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
		
		ResourceNotificationDocumentBuilder notificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
		notificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
		
		return notificationDocumentBuilder.getResourceNotificationDocument();
	}
	
	
	public static ResourceNotificationDocument transformEvcMemberNotification(SearchResponseDetails searchResponseDetails)
	{
		
		ResourceNotificationBuilder resourceNotificationBuilder = new ResourceNotificationBuilder();
		resourceNotificationBuilder.buildResourceNotification(null, getMessageElements("EVCMemberNotification"));
		resourceNotificationBuilder.addResourceNotificationDetails(searchResponseDetails);
		
		ResourceNotificationDocumentBuilder resourceNotificationDocumentBuilder = new ResourceNotificationDocumentBuilder();
		resourceNotificationDocumentBuilder.buildResourceNotificationDocument(resourceNotificationBuilder.getResourceNotification());
		LOG.info(resourceNotificationDocumentBuilder.getResourceNotificationDocument());
		//System.out.println(resourceNotificationDocumentBuilder.getResourceNotificationDocument());
		return resourceNotificationDocumentBuilder.getResourceNotificationDocument();
		
	}
	
	
	
	private static Parameter getAssociatedService(EventNotificationDocument event,String resourceSubtype)
	{
		Parameter parameter = getParameterValue(event, "AssociatedService");
		if(QCtrlNotificationsService.EVC.equalsIgnoreCase(parameter.getType()) || QCtrlNotificationsService.OVC.equalsIgnoreCase(parameter.getType()))
		{
			return parameter;
		}
		else{
			
			ParameterBuilder parameterBuilder = new ParameterBuilder();
			parameterBuilder.buildParameter(event.getEventNotification().getObjectId(), "AssociatedService", event.getEventNotification().getCommonName(), resourceSubtype);
			return parameterBuilder.getParameter();
		}
	}
	
	
	public ResourceNotification transformServiceUpdateToResourceNotification(EventNotificationDocument event,String resourceSubType,String updatedAttributeName,String updatedAttributeValue)
	{
		return null;
	}
	
	private static MessageElements getMessageElements(String action)
	{
		MessageAddressing messageAddresing = SearchResourceRequestDocumentHelper.createMessageAddressing("ICL","QCTRL",null,action, new Date()+"", null, "ResourceNotification", null);
		MessageElements messageElements = SearchResourceRequestDocumentHelper.createMessageElements(messageAddresing, "SUCCESS");
		return messageElements;
	}
	
	private static Parameter getParameterValue(EventNotificationDocument event,String parameterName)
	{
		if(event.getEventNotification().getParameterSet() != null && event.getEventNotification().getParameterSet().getParameterList() != null)
		{
			for(Parameter parameter : event.getEventNotification().getParameterSet().getParameterList())
			{
				if(parameterName.equalsIgnoreCase(parameter.getName()))
					return parameter;
			}
		}
		return null;
	}
}
