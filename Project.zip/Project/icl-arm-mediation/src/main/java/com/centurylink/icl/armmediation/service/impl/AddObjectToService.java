package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.dataaccess.DimensionObjectDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkgservice.AddObject2Service;

public class AddObjectToService
{

	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private DimensionObjectDAO dimensionObjectDAO;
	private AddObject2Service addObject2Service;

	public Object addObjectToService(HashMap<String, Object> iHashMap)
	{
		LOG.info("Adding Object To Service");

		final String serviceId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.SERVICE_ID);
		final String objectId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.OBJECT_ID);
		final String dimObject = MediationUtil.getValueFromMap(iHashMap, MDWConstants.DIM_OBJECT);
		final String relationName = MediationUtil.getValueFromMap(iHashMap, MDWConstants.RELATIONSHIP_NAME);

		final BigDecimal dimObjectId = dimensionObjectDAO.getDimensionObjectID(dimObject);

		final BigDecimal dimRelationShipId = dimensionObjectDAO.getDimensionRelationShipID(relationName);

		final Map<String, Object> map = (HashMap<String, Object>) addObject2Service.execute(new BigDecimal(serviceId), dimObjectId, new BigDecimal(objectId), dimRelationShipId, new BigDecimal(1));
		final BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			iHashMap.put(MDWConstants.errorCode, o_ErrorCode);
			iHashMap.put(MDWConstants.errorMessage, o_Errormsg);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
		} else
		{
			iHashMap.put(MDWConstants.errorCode, new Integer(0));
		}
		return iHashMap;

	}

	public void setDimensionObjectDAO(DimensionObjectDAO dimensionObjectDAO)
	{
		this.dimensionObjectDAO = dimensionObjectDAO;
	}

	public void setAddObject2Service(AddObject2Service addObject2Service)
	{
		this.addObject2Service = addObject2Service;
	}

}
