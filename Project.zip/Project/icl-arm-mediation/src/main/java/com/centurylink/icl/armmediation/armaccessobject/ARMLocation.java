package com.centurylink.icl.armmediation.armaccessobject;

public class ARMLocation extends ARMObject
{
	private String	addressLine1;
	private String	addressLine3;
	private String	addressLine2;
	private String	addressType;
	private String	clli;
	private String	locality;
	private String	province;
	private String	sourceSystem;
	private String	room;
	private String	postcode;
	private String	hcoordinate;
	private String	vcoordinate;
	private String	lata;
	private String	npa;
	private String	nxx;
	private String	switchLocationCLLI;
	private String	commonName;
	private String	objectID;
	private String	stateOrProvince;
	private String	addressFormatType;
	private String	description;
	private String	childLocName;
	private String	childLocId;
	private String locType;

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	@Override
	public String toString()
	{
		return "ARMLocation [addressLine1=" + addressLine1 + ", addressLine3=" + addressLine3 + ", addressLine2=" + addressLine2 + ", addressType=" + addressType + ", clli=" + clli + ", locality="
				+ locality + ", province=" + province + ", sourceSystem=" + sourceSystem + ", room=" + room + ", postcode=" + postcode + ", hcoordinate=" + hcoordinate + ", vcoordinate="
				+ vcoordinate + ", lata=" + lata + ", npa=" + npa + ", nxx=" + nxx + ", switchLocationCLLI=" + switchLocationCLLI + ", commonName=" + commonName + ", objectID=" + objectID
				+ ", stateOrProvince=" + stateOrProvince + ", addressFormatType=" + addressFormatType + "]";
	}

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public String getObjectID()
	{
		return objectID;
	}

	public void setObjectID(String objectID)
	{
		this.objectID = objectID;
	}

	public String getStateOrProvince()
	{
		return stateOrProvince;
	}

	public void setStateOrProvince(String stateOrProvince)
	{
		this.stateOrProvince = stateOrProvince;
	}

	public String getAddressFormatType()
	{
		return addressFormatType;
	}

	public void setAddressFormatType(String addressFormatType)
	{
		this.addressFormatType = addressFormatType;
	}

	public String getAddressLine1()
	{
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1)
	{
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine3()
	{
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3)
	{
		this.addressLine3 = addressLine3;
	}

	public String getAddressLine2()
	{
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2)
	{
		this.addressLine2 = addressLine2;
	}

	public String getAddressType()
	{
		return addressType;
	}

	public void setAddressType(String addressType)
	{
		this.addressType = addressType;
	}

	public String getClli()
	{
		return clli;
	}

	public void setClli(String clli)
	{
		this.clli = clli;
	}

	public String getLocality()
	{
		return locality;
	}

	public void setLocality(String locality)
	{
		this.locality = locality;
	}

	public String getProvince()
	{
		return province;
	}

	public void setProvince(String province)
	{
		this.province = province;
	}

	public String getRoom()
	{
		return room;
	}

	public void setRoom(String room)
	{
		this.room = room;
	}

	public String getPostcode()
	{
		return postcode;
	}

	public void setPostcode(String postcode)
	{
		this.postcode = postcode;
	}

	public String getHcoordinate()
	{
		return hcoordinate;
	}

	public void setHcoordinate(String hcoordinate)
	{
		this.hcoordinate = hcoordinate;
	}

	public String getVcoordinate()
	{
		return vcoordinate;
	}

	public void setVcoordinate(String vcoordinate)
	{
		this.vcoordinate = vcoordinate;
	}

	public String getLata()
	{
		return lata;
	}

	public void setLata(String lata)
	{
		this.lata = lata;
	}

	public String getNpa()
	{
		return npa;
	}

	public void setNpa(String npa)
	{
		this.npa = npa;
	}

	public String getNxx()
	{
		return nxx;
	}

	public void setNxx(String nxx)
	{
		this.nxx = nxx;
	}

	public String getSwitchLocationCLLI()
	{
		return switchLocationCLLI;
	}

	public void setSwitchLocationCLLI(String switchLocationCLLI)
	{
		this.switchLocationCLLI = switchLocationCLLI;
	}

	public String getChildLocName()
	{
		return childLocName;
	}

	public void setChildLocName(String childLocName)
	{
		this.childLocName = childLocName;
	}

	public String getChildLocId()
	{
		return childLocId;
	}

	public void setChildLocId(String childLocId)
	{
		this.childLocId = childLocId;
	}

	public String getLocType()
	{
		return locType;
	}

	public void setLocType(String locType)
	{
		this.locType = locType;
	}
}
