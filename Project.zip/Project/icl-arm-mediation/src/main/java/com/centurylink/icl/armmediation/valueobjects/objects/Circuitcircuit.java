package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.CompositePrimaryKeyField;
import com.centurylink.icl.valueobjects.impl.Field;

public class Circuitcircuit extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String AUTOCREATEPORT = "AUTOCREATEPORT";
	private static final String TURNED = "TURNED";
	private static final String PREEMPTIVEUSAGE = "PREEMPTIVEUSAGE";
	private static final String NORMALUSAGE = "NORMALUSAGE";
	private static final String ROUTESEQUENCE = "ROUTESEQUENCE";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String USES2CIRCUIT = "USES2CIRCUIT";
	private static final String USEDBY2CIRCUIT = "USEDBY2CIRCUIT";
	
	private Circuit usesCircuit = null;
	private Circuit usedByCircuit = null;

	public Circuitcircuit()
	{
		super();
		this.tableName = "CIRCUITCIRCUIT";
	}

	public Circuitcircuit(String uses2Circuit, String usedby2Circuit)
	{
		this();
		fields.get(USES2CIRCUIT).setValue(uses2Circuit);
		fields.get(USEDBY2CIRCUIT).setValue(usedby2Circuit);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	/*
	 * Right now the get Object by Query does not work for tables that have a composite primary key. Need 
	 * To work on this when I have more time. For now use the Template method for this. 
	 */
/*
	public static List<Circuitcircuit> getCircuitcircuitListByQuery(String query)
	{
		Circuitcircuit circuitcircuit = new Circuitcircuit();
		List<Circuitcircuit> circuitcircuitList = new ArrayList<Circuitcircuit>();
		List<Map<String,Object>> foundCircuitcircuitList = circuitcircuit.getRecordsByQuery(query);

		for (Map<String,Object> circuitcircuitMap : foundCircuitcircuitList)
		{
			Circuitcircuit workCircuitcircuit = new Circuitcircuit(circuitcircuitMap.get([PRIKEY]).toString());
			circuitcircuitList.add(workCircuitcircuit);
		}
		return circuitcircuitList;
	}
*/
	public static List<Circuitcircuit> getCircuitcircuitListByUses(String circuitId)
	{
		Circuitcircuit template = new Circuitcircuit();
		template.setUses2circuit(circuitId);
		return getCircuitcircuitList(template);
	}
	
	public static List<Circuitcircuit> getCircuitcircuitListByUsedBy(String circuitId)
	{
		Circuitcircuit template = new Circuitcircuit();
		template.setUsedby2circuit(circuitId);
		return getCircuitcircuitList(template);
	}
	
	public static List<Circuitcircuit> getCircuitcircuitList(Circuitcircuit template)
	{
		List<Circuitcircuit> response = new ArrayList<Circuitcircuit>();
		
		List<Map<String, Object>> records = template.getRecordsByTemplate();
		for (Map<String, Object> map:records)
		{
			Circuitcircuit cc = new Circuitcircuit();
			cc.instanciated = true;
			cc.populateFields(map);
			response.add(cc);
		}
		
		return response;
	}
	
	//added for PON
	
		public List<Circuitcircuit> getCircuitcircuitListPONByUsedBy(String circuitId)
		{
			
			return getCircuitcircuitListPON(circuitId);
		}
		
		public List<Circuitcircuit> getCircuitcircuitListPON(String template)
		{
			List<Circuitcircuit> response = new ArrayList<Circuitcircuit>();
			
			List<Map<String, Object>> records = getRecordsByTemplateForPON(template);
			for (Map<String, Object> map:records)
			{
				Circuitcircuit cc = new Circuitcircuit();
				cc.instanciated = true;
				cc.populateFields(map);
				response.add(cc);
			}
			
			return response;
		}

		
		public List<Map<String,Object>> getRecordsByTemplateForPON(String usedby2circuit)
		{
			String statement = "SELECT * FROM " + this.tableName + buildWhere(this.fields) + "and usedby2Circuit='"+usedby2circuit+"' order by sequence asc"; 
			List<Map<String,Object>> records = valueObjectDataAccessUtil.getRecordsAsList(statement);
			return records;
		}

	@Override
	public void populateModel()
	{
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(AUTOCREATEPORT, new Field(AUTOCREATEPORT, Field.TYPE_NUMERIC));
		fields.put(TURNED, new Field(TURNED, Field.TYPE_NUMERIC));
		fields.put(PREEMPTIVEUSAGE, new Field(PREEMPTIVEUSAGE, Field.TYPE_NUMERIC));
		fields.put(NORMALUSAGE, new Field(NORMALUSAGE, Field.TYPE_NUMERIC));
		fields.put(ROUTESEQUENCE, new Field(ROUTESEQUENCE, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(USES2CIRCUIT, new Field(USES2CIRCUIT, Field.TYPE_NUMERIC));
		fields.put(USEDBY2CIRCUIT, new Field(USEDBY2CIRCUIT, Field.TYPE_NUMERIC));

		this.primaryKey = new CompositePrimaryKeyField();
		((CompositePrimaryKeyField) this.primaryKey).addField(fields.get(USES2CIRCUIT));
		((CompositePrimaryKeyField) this.primaryKey).addField(fields.get(USEDBY2CIRCUIT));	
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setAutocreateport(String autocreateport)
	{
		setField(AUTOCREATEPORT,autocreateport);
	}

	public String getAutocreateport()
	{
		return getFieldAsString(AUTOCREATEPORT);
	}

	public void setTurned(String turned)
	{
		setField(TURNED,turned);
	}

	public String getTurned()
	{
		return getFieldAsString(TURNED);
	}

	public void setPreemptiveusage(String preemptiveusage)
	{
		setField(PREEMPTIVEUSAGE,preemptiveusage);
	}

	public String getPreemptiveusage()
	{
		return getFieldAsString(PREEMPTIVEUSAGE);
	}

	public void setNormalusage(String normalusage)
	{
		setField(NORMALUSAGE,normalusage);
	}

	public String getNormalusage()
	{
		return getFieldAsString(NORMALUSAGE);
	}

	public void setRoutesequence(String routesequence)
	{
		setField(ROUTESEQUENCE,routesequence);
	}

	public String getRoutesequence()
	{
		return getFieldAsString(ROUTESEQUENCE);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setUses2circuit(String uses2circuit)
	{
		setField(USES2CIRCUIT,uses2circuit);
	}

	public String getUses2circuit()
	{
		return getFieldAsString(USES2CIRCUIT);
	}

	public void setUsedby2circuit(String usedby2circuit)
	{
		setField(USEDBY2CIRCUIT,usedby2circuit);
	}

	public String getUsedby2circuit()
	{
		return getFieldAsString(USEDBY2CIRCUIT);
	}
	
	public Circuit getUsesCircuit()
	{
		if (usesCircuit == null)
		{
			usesCircuit = new Circuit(this.getUses2circuit());
		}
		
		return usesCircuit;
	}

	public Circuit getUsedByCircuit()
	{
		if (usedByCircuit == null)
		{
			usedByCircuit = new Circuit(this.getUsedby2circuit());
		}
		
		return usedByCircuit;
	}
}