package com.centurylink.icl.armmediation.transformation;

import java.util.List;
import java.util.Map;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMNode;
import com.centurylink.icl.armmediation.armaccessobject.ARMPort;
import com.centurylink.icl.armmediation.armaccessobject.ARMSFP;
import com.centurylink.icl.armmediation.armaccessobject.ARMShelf;
import com.centurylink.icl.armmediation.armaccessobject.ARMSlot;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.EllipticBuilder;
import com.centurylink.icl.builder.cim2.ExchangeServiceAreaBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;

public class SearchDeviceToCim
{
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final EllipticBuilder ellipticBuilder;
	private final ExchangeServiceAreaBuilder exchangeServiceAreaBuilder;
	private final RackBuilder rackBuilder;
	private final ShelfBuilder shelfBuilder;
	private final SlotBuilder slotBuilder;
	private final CardBuilder cardBuilder;
	private final CardBuilder tempcardBuilder;
	private final PhysicalPortBuilder physicalPortBuilder;
	private final IPAddressBuilder ipAddressBuilder;
	private final CardOnCardDetailsBuilder cardOnCardDetailsBuilder;
	private final CardOnCardDetailsBuilder tempcardOnCardDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;
	private Map<Long, List<ARMPort>> port2CardMap;
	private Map<Long, List<ARMSlot>> slot2ShelfMap;
	private List<ARMShelf> shelfList;
	private List<ARMCard> cardList;
	private List<ARMSFP> sfpList;
	private List<ARMLocation> locationList;

	public SearchDeviceToCim()
	{
		physicalDeviceBuilder = new PhysicalDeviceBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		ellipticBuilder = new EllipticBuilder();
		exchangeServiceAreaBuilder = new ExchangeServiceAreaBuilder();
		rackBuilder = new RackBuilder();
		shelfBuilder = new ShelfBuilder();
		slotBuilder = new SlotBuilder();
		cardBuilder = new CardBuilder();
		physicalPortBuilder = new PhysicalPortBuilder();
		ipAddressBuilder = new IPAddressBuilder();
		cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		customerBuilder = new CustomerBuilder();
		ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		tempcardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		tempcardBuilder = new CardBuilder();
	}

	public PhysicalDevice transformToCim(ARMNode armNode, List<ARMShelf> shelfList, Map<Long, List<ARMSlot>> slot2ShelfMap, List<ARMCard> cardList, Map<Long, List<ARMPort>> port2CardMap, List<ARMPort> portOnDeviceList, List<ARMSFP> sfpList, List<ARMLocation> locationList)
	{
		this.cardList = cardList;
		this.shelfList = shelfList;
		this.port2CardMap = port2CardMap;
		this.slot2ShelfMap = slot2ShelfMap;
		this.sfpList = sfpList;
		this.locationList = locationList;

		physicalDeviceBuilder.buildPhysicalDevice(armNode.getCommonName(), String.valueOf(armNode.getNodeId()), armNode.getDescription(), "ARM", armNode.getResourceType(), null, armNode.getProvisionStatus(), armNode.getClliCode(), armNode.getAliasName(), armNode.getManufacturer(), null, null, null, null,null,armNode.getFunctionalStatus());
		physicalDeviceBuilder.addDetails(null, armNode.getFirmwareVersion(), armNode.getSoftwareVersion(), armNode.getAliasName2(), null, null, armNode.getResourceSubType(), armNode.getSerialNumber(), armNode.getVendorName(), armNode.getVendorPartNo(), null, armNode.getNetworkName(), armNode.getNmsType(), armNode.getNmsHostName(), null, armNode.getSnmpObjectId(), armNode.getChasisSerialNo());

		addLocation(locationList);
		addRack();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		RackBuilder rackBuilder = new RackBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();
		
		if (portOnDeviceList != null && !portOnDeviceList.isEmpty())
		{
			addPortToDevice(portOnDeviceList);
		}
		if (armNode.getMgmtVlan() != null)
			physicalDeviceBuilder.addResourceDescribedBy("ManagementVLAN", armNode.getMgmtVlan());
		
		if(armNode.getAutoIdentifyNID()!=null)
			physicalDeviceBuilder.addResourceDescribedBy("AutoIndentifyNID", armNode.getAutoIdentifyNID());
			
		if (armNode.getMacAddress() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getMacAddress(), "MAC address", null, null, null, null);
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpV4MgmRouterId() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpV4MgmRouterId(), "IP v4  Mgm Router Id", null, null, null, "4");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpV4Console1() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpV4Console1(), "IP v4 Console 1", null, null, null, "4");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpV4Console2() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpV4Console2(), "IP v4 Console2", null, null, null, "4");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpV6MgmRouterId() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpV6MgmRouterId(), "IP v6 Mgm Router Id", null, null, null, "6");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpV6Console1() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpV6Console1(), "IP v6 Console 1", null, null, null, "6");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getIpv6Console2() != null)
		{
			ipAddressBuilder.buildIPAddress(armNode.getIpv6Console2(), "IP v6 Console2", null, null, null, "6");
			physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
		}
		if (armNode.getSharedOrDedicated() != null)
		{
			physicalDeviceBuilder.addResourceDescribedBy("IsSharedOrDedicated", armNode.getSharedOrDedicated());
		}
		if (null != armNode.getDiversed())
		{
			physicalDeviceBuilder.addResourceDescribedBy("IsDiversed", armNode.getDiversed());
		}
		if (null != armNode.getRestrictedNotes())
        {
		/*remarkBuilder.buildRemark(armNode.getRestrictedNotes(),"RestrictedNotes");
		physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());*/
         //physicalDeviceBuilder.addResourceDescribedBy("RestrictedNotes", armNode.getRestrictedNotes());
        }
		
		if(null!=armNode.getNwkNodeNumber())
		{
		physicalDeviceBuilder.addResourceDescribedBy("NetworkNodeNumber", armNode.getNwkNodeNumber());
		}
		if(null!=armNode.getMaxSubscriberBWOffered())
		{
	physicalDeviceBuilder.addResourceDescribedBy("MaximumSubscriberOfferedBW", armNode.getMaxSubscriberBWOffered());
		}
		if(null!=armNode.getPrismNosaCert())
		{
		physicalDeviceBuilder.addResourceDescribedBy("NOSACertification", armNode.getPrismNosaCert());
		}
		if(null!=armNode.getOneGbpsIndicator())
		{
		physicalDeviceBuilder.addResourceDescribedBy("1GbpsIndicator", armNode.getOneGbpsIndicator());
		}		
		if(null!=armNode.getStackRingSeqNum())
		{
		physicalDeviceBuilder.addResourceDescribedBy("StackRingSeqNum", armNode.getStackRingSeqNum());
		}		
		if(null!=armNode.getStackRingShelfId())
		{
		physicalDeviceBuilder.addResourceDescribedBy("StackRingShelfID", armNode.getStackRingShelfId());
		}	
		if(null!=armNode.getAerialORBuried())
		{
		physicalDeviceBuilder.addResourceDescribedBy("AerialOrBuried", armNode.getAerialORBuried());
		}		
		
	
		if(null!=armNode.getMaxDownStreamRate())
		{
		physicalDeviceBuilder.addResourceDescribedBy("MaxDownStreamRate", armNode.getMaxDownStreamRate());
		}
		if(null!=armNode.getMaxUpStreamRate())
		{
		physicalDeviceBuilder.addResourceDescribedBy("MaxUpStreamRate", armNode.getMaxUpStreamRate());
		}
	
		
		if(null!=armNode.getFiberINRange())
		{
		physicalDeviceBuilder.addResourceDescribedBy("FiberINRange", armNode.getFiberINRange());
		}		
		if(null!=armNode.getFiberOUTRange())
		{
		physicalDeviceBuilder.addResourceDescribedBy("FiberOUTRange", armNode.getFiberOUTRange());
		}		
		if(null!=armNode.getSplitterGrpNum())
		{
		physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupNumber", armNode.getSplitterGrpNum());
		}		
		if(null!=armNode.getSplitterGrpName())
		{
		physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupName", armNode.getSplitterGrpName());
		}		
		if(null!=armNode.getSplitterStartPortNumber())
		{
		physicalDeviceBuilder.addResourceDescribedBy("StartPortNumber", armNode.getSplitterStartPortNumber());
		}		
		if(null!=armNode.getInstallDate())
		{
		physicalDeviceBuilder.addResourceDescribedBy("InstallDate", armNode.getInstallDate());
		}			
		if(null!=armNode.getInDoor())
		{
		physicalDeviceBuilder.addResourceDescribedBy("IsIndoor", armNode.getInDoor());
		}		
		if(null!=armNode.getSelfORTechInstall())
		{
		physicalDeviceBuilder.addResourceDescribedBy("InstallationIndicator", armNode.getSelfORTechInstall());
		}		
		if(null!=armNode.getRontaId())
		{
		physicalDeviceBuilder.addResourceDescribedBy("RONTAID", armNode.getRontaId());
		}			
		if(null!=armNode.getPowerSupply())
		{
		/*remarkBuilder.buildRemark(armNode.getPowerSupply(),"PowerSupply");
		physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());*/
		//physicalDeviceBuilder.addResourceDescribedBy("PowerSupply", armNode.getPowerSupply());
		}		
		if(null!=armNode.getOptiTap())
		{
		physicalDeviceBuilder.addResourceDescribedBy("Opti-tap", armNode.getOptiTap());
		}		
		if(null!=armNode.getSapCode())
		{
		physicalDeviceBuilder.addResourceDescribedBy("SAPCode", armNode.getSapCode());
		}	
		if(null!=armNode.getRevision())
		{
		physicalDeviceBuilder.addResourceDescribedBy("Revision", armNode.getRevision());
		}		
		if(null!=armNode.getRestrictedStatus())
		{
		/*remarkBuilder.buildRemark(armNode.getRestrictedStatus(),"RestrictedStatus");
		physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());*/
		//physicalDeviceBuilder.addResourceDescribedBy("RestrictedStatus", armNode.getRestrictedStatus());
		}		
		if(null!=armNode.getRelayRackId())
		{
		rackBuilder.buildRack(armNode.getRelayRackId(), null, null, null, null, null, null, null);
		physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
		}		
		if(null!=armNode.getNetworkRoleObject2NetworkRole())
		{
		physicalDeviceRoleBuilder.buildPhysicalDeviceRole(armNode.getNetworkRoleObject2NetworkRole());
		physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
		}
		
		if (null != armNode.getRelativeName())
		{
			ownsResourceDetailsBuilder.buildOwnsResourceDetails();
			customerBuilder.buildCustomer(armNode.getRelativeName(), null, null, null, null, null);
			ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
			physicalDeviceBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
		}
		return physicalDeviceBuilder.getPhysicalDevice();
	}

	private void addRack()
	{
		rackBuilder.buildRack(null, null, null, null, null, null, null, null);
		if (shelfList != null && !shelfList.isEmpty())
		{
			for (ARMShelf armShelf : shelfList)
			{
				addShelf(armShelf);
			}
		}
		physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
	}

	private void addShelf(ARMShelf armShelf)
	{
		shelfBuilder.buildShelf(armShelf.getCommonName(), String.valueOf(armShelf.getShelfID()), null, armShelf.getDescription(), armShelf.getVersion(), armShelf.getFirmwareVersion(), armShelf.getSoftwareVersion(), armShelf.getAliasName(), armShelf.getAliasName2(), armShelf.getSerialNumber(), armShelf.getRelayRackID(), armShelf.getBayName());
		final List<ARMSlot> slotList = slot2ShelfMap.get(armShelf.getShelfID());
		if (slotList != null && !slotList.isEmpty())
		{
			for (ARMSlot armSlot : slotList)
			{
				addSlot(armSlot);
			}
		}
		rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
	}

	private void addSlot(ARMSlot armSlot)
	{
		slotBuilder.buildSlot(armSlot.getCommonName(), String.valueOf(armSlot.getSlodId()), null, armSlot.getSlotNumber());
		if (cardList != null && !cardList.isEmpty())
		{
			for (ARMCard armCard : cardList)
			{
				if (armCard.getCard2ShelfSlot() == armSlot.getSlodId())
				{
					cardBuilder.buildCard(armCard.getCommonName(), String.valueOf(armCard.getCardId()), null, null, "ARM", null, null, armCard.getAliasName(), armCard.getSubType(), null);
					List<ARMCard> childCards = armCard.getChildCards();
					if (null != childCards && childCards.size() > 0)
					{
						for (ARMCard childcard : childCards)
						{
							cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, String.valueOf(childcard.getSlotNumber()));
							tempcardBuilder.buildCard(childcard.getCommonName(), String.valueOf(childcard.getCardId()), null, null, "ARM", null, null, childcard.getAliasName(), childcard.getSubType(), null);
							final List<ARMPort> childportList = port2CardMap.get(childcard.getCardId());
							if (childportList != null && !childportList.isEmpty())
							{
								addPortForChildCard(childportList);
							}
							cardOnCardDetailsBuilder.addCard(tempcardBuilder.getCard());
							cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
						}
					}
					final List<ARMPort> portList = port2CardMap.get(armCard.getCardId());
					if (portList != null && !portList.isEmpty())
					{
						addPort(portList);
					}
					if (sfpList != null && !sfpList.isEmpty())
					{
						cardOnCardDetailsBuilder.buildCardOnCardDetails();
						for (ARMSFP armSFP : sfpList)
						{
							cardOnCardDetailsBuilder.addCard(armSFP.getSfpName());//(armSFP.getSfpName());
						}
						cardBuilder.addAllowableCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
					}
					slotBuilder.addHasCard(cardBuilder.getCard());
				}
			}
		}
		shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
	}

	private void addPort(List<ARMPort> portList)
	{
		for (int i = 0; i < portList.size(); ++i)
		{
			String resourceType=null;
			ARMPort armPort = portList.get(i);
			/*if(armPort.getPluggableType()!=null)
			{
				resourceType=armPort.getPluggableType();
			}
			else 
			{*/
				resourceType=armPort.getResourceType();
			//}
			//XXX LD :- fix because of "CSOF: 96603 in E2E Env" issue going on. ResourceType MUST BE 'Pluggable' in case of Pluggalbe port
			physicalPortBuilder.buildPhysicalPort(armPort.getCommonName(), String.valueOf(armPort.getPortId()), armPort.getPrStatus(), Integer.parseInt(armPort.getPortNumber()), armPort.getDPEA(), armPort.getPluggableType(), armPort.getBandWidth(), armPort.getWaveLength(), armPort.getAliasName(), armPort.getPortFunction(), resourceType, armPort.getResourceSubType(), null, null, null, null,armPort.getIfName());
			if (armPort != null && !StringHelper.isEmpty(armPort.getReservationdId()))
			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "True");
			}
			else
			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "False");
			}	
			if (armPort != null && armPort.getIfNum()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getIfNum());
			}
			if (armPort != null && armPort.getPLUGGABLEIFNUM()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getPLUGGABLEIFNUM());
			}
			if (armPort != null && armPort.getResourceType()!=null && armPort.getResourceType().equalsIgnoreCase("Pluggable"))
			{				
					physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRatePluggable());				
			}
			else if( armPort.getTransmissionRate()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRate());
			}
			cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
		}
	}

	private void addPortForChildCard(List<ARMPort> portList)
	{
		for(int i=0; i<portList.size() ; ++i)
		{

			String resourceType=null;
		   ARMPort armPort = portList.get(i);
		   /*if(armPort !=null && armPort.getPluggableType()!=null)
			{
				resourceType=armPort.getPluggableType();
			}
			else 
			{*/
				resourceType=armPort.getResourceType();
			//}
			//XXX LD :- fix because of "CSOF: 96603 in E2E Env" issue going on. ResourceType MUST BE 'Pluggable' in case of Pluggalbe port
		   physicalPortBuilder.buildPhysicalPort(armPort.getCommonName(), String.valueOf(armPort.getPortId()), armPort.getPrStatus(), Integer.parseInt(armPort.getPortNumber()), armPort.getDPEA(), armPort.getPluggableType(), armPort.getBandWidth(), armPort.getWaveLength(), armPort.getAliasName(), armPort.getPortFunction(), resourceType, armPort.getResourceSubType(), null, null, null,null,armPort.getIfName());
		   if(armPort !=null && ! StringHelper.isEmpty(armPort.getReservationdId()))


			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "True");
			}
			else
			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "False");
			}
			if (armPort != null && armPort.getPLUGGABLEIFNUM()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getPLUGGABLEIFNUM());
			}
			if (armPort != null && armPort.getIfNum()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getIfNum());
			}
			if  (armPort != null && armPort.getResourceType()!=null && armPort.getResourceType().equalsIgnoreCase("Pluggable"))
			{				
					physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRatePluggable());
							}
			else if(armPort.getTransmissionRate()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRate());
			}
			tempcardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
		}
	}

	private void addPortToDevice(List<ARMPort> portList)
	{
		for (ARMPort armPort : portList)
		{
			String resourceType=null;
			 /*if(armPort !=null && armPort.getPluggableType()!=null)
				{
					resourceType=armPort.getPluggableType();
				}
				else 
				{*/
					resourceType=armPort.getResourceType();
				//}
				//XXX LD :- fix because of "CSOF: 96603 in E2E Env" issue going on. ResourceType MUST BE 'Pluggable' in case of Pluggalbe port
			physicalPortBuilder.buildPhysicalPort(armPort.getCommonName(), String.valueOf(armPort.getPortId()), armPort.getPrStatus(), Integer.parseInt(armPort.getPortNumber()), armPort.getDPEA(), armPort.getPluggableType(), armPort.getBandWidth(), armPort.getWaveLength(), armPort.getAliasName(), armPort.getPortFunction(), resourceType, armPort.getResourceSubType(), null, null, null, null,armPort.getIfName());
			if (armPort != null && !StringHelper.isEmpty(armPort.getReservationdId()))
			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "True");
			}
			else
			{
				physicalPortBuilder.addResourceDescribedBy("ReservationFlag", "False");
			}
			if (armPort != null && armPort.getIfNum()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getIfNum());
			}
			if (armPort != null && armPort.getPLUGGABLEIFNUM()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("SNMPId", armPort.getPLUGGABLEIFNUM());
			}
			if (armPort != null && armPort.getResourceType()!=null && armPort.getResourceType().equalsIgnoreCase("Pluggable"))
			{				
					physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRatePluggable());					
			}
			else if(armPort.getTransmissionRate()!=null)
			{
				physicalPortBuilder.addResourceDescribedBy("TransmissionRate", armPort.getTransmissionRate());
			}
			physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());
		}
		addSFPonDevicePort();
	}

	private void addSFPonDevicePort()
	{
		if (sfpList != null && !sfpList.isEmpty())
		{
			cardBuilder.buildCard(null, null, null);
			cardOnCardDetailsBuilder.buildCardOnCardDetails();
			for (ARMSFP armSFP : sfpList)
			{
				tempcardOnCardDetailsBuilder.buildCardOnCardDetails(armSFP.getSfpName(), null, null, null);
				cardBuilder.addCardOnCardDetails(tempcardOnCardDetailsBuilder.getCardOnCardDetails());
			}
			cardOnCardDetailsBuilder.addCard(cardBuilder.getCard());
			physicalDeviceBuilder.addAllowableSFPDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
		}
	}

	private void addLocation(List<ARMLocation> locationList)
	{
		if (locationList != null && locationList.size() > 0)
		{
			for (ARMLocation location : locationList)
			{
				americanPropertyAddressBuilder.buildAmericanPropertyAddress(location.getCommonName(), null, null, null, null, null, null, null, null, null, null);
				/*ellipticBuilder.buildElliptic(location.getHcoordinate(), location.getVcoordinate());
				americanPropertyAddressBuilder.setEllipticLocation(ellipticBuilder.getElliptic());
				exchangeServiceAreaBuilder.buildExchangeServiceArea("LATA", null, location.getLata());
				americanPropertyAddressBuilder.addExchangeServiceArea(exchangeServiceAreaBuilder.getExchangeServiceArea());*/
				physicalDeviceBuilder.addInstallAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
			}
		}
	}

}
