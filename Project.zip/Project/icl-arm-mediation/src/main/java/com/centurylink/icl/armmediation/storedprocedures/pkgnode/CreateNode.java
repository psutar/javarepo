package com.centurylink.icl.armmediation.storedprocedures.pkgnode;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.AddToObjAttrListNumber;

public class CreateNode extends StoredProcedure
{

	private static final Log LOG = LogFactory.getLog(AddToObjAttrListNumber.class);

	public CreateNode(DataSource dataSource)
	{
		super(dataSource, "PKGNODE.CREATENODE");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_nodeid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_name", Types.VARCHAR));
		declareParameter(new SqlParameter("i_node2nodedef", Types.NUMERIC));
		declareParameter(new SqlParameter("i_node2location", Types.NUMERIC));

		compile();
	}

	public Map<String, Object> execute(String i_name, BigDecimal i_node2nodedef, BigDecimal i_node2location)
	{
		final Map<String, Object> in = new HashMap<String, Object>();

		in.put("i_name", i_name);
		in.put("i_node2nodedef", i_node2nodedef);
		in.put("i_node2location", i_node2location);

		return super.execute(in);
	}

}
