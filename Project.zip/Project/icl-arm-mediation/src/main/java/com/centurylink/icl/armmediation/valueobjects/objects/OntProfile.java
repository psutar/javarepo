package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class OntProfile extends AbstractReadOnlyTable {

	private static final long serialVersionUID = 1L;

	private static final Log LOG = LogFactory.getLog(OntProfile.class);


	private static final String ONTPROFILE="ONT_PROFILE_NM";
	private static final String ONTPWEPROFILE="ONT_PWE_PROFILE_NM";
	private static final String NODETYPE="OLT_NODETYPE_NM";
	private static final String NODEDEF="ONT_NODEDEF_NM";
	private static final String ONTPROFILEID="ONT_PROFILE_ID";


	public OntProfile()
	{
		super();
		this.tableName = "Ont_Profile";
	}

	

	public static List<OntProfile> getNodeListByQuery(String query)
	{
		OntProfile node = new OntProfile();
		List<OntProfile> nodeList = new ArrayList<OntProfile>();
		List<Map<String,Object>> foundNodeList = node.getFullRecordsByQuery(query);

		for (Map<String,Object> nodeMap : foundNodeList)
		{
			OntProfile workNode = new OntProfile();
			workNode.instanciated = true;
			workNode.populateFields(nodeMap);
			nodeList.add(workNode);
		}

		return nodeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(ONTPROFILE, new Field(ONTPROFILE, Field.TYPE_VARCHAR));
		fields.put(ONTPROFILEID, new Field(ONTPROFILEID, Field.TYPE_NUMERIC));
		fields.put(ONTPWEPROFILE, new Field(ONTPWEPROFILE, Field.TYPE_VARCHAR));
		fields.put(NODETYPE, new Field(NODETYPE, Field.TYPE_VARCHAR));
		fields.put(NODEDEF, new Field(NODEDEF, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(ONTPROFILEID));
	}


	public String getOntProfile() {
		return getFieldAsString(ONTPROFILE);
	}
	public String getOntProfileId() {
		return getFieldAsString(ONTPROFILEID);
	}
	public String getOntPweProfile() {
		return getFieldAsString(ONTPWEPROFILE);
	}
	public String getNodeType() {
		return getFieldAsString(NODETYPE);
	}
	public String getNodeDef() {
		return getFieldAsString(NODEDEF);
	}

	public void setOntProfile(String ontProfile) {
		setField(ONTPROFILE,ontProfile);
	}
	public void setOntPweProfile(String ontPweProfile) {
		setField(ONTPWEPROFILE,ontPweProfile);
	}
	public void setOntProfileId(String ontProfileId) {
		setField(ONTPROFILEID , ontProfileId);
	}

	public void setNodeType(String nodeType) {
		setField(NODETYPE , nodeType);
	}

	public void setNodeDef(String nodeDef) {
		setField(NODEDEF , nodeDef);
	}
}




