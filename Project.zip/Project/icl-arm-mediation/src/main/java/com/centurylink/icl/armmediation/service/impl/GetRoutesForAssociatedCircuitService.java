package com.centurylink.icl.armmediation.service.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.dataaccess.GetRoutesForAssociatedCircuitDAO;

public class GetRoutesForAssociatedCircuitService
{
	private static final Log LOG = LogFactory.getLog(GetRoutesForAssociatedCircuitService.class);
	private GetRoutesForAssociatedCircuitDAO getRoutesForAssociatedCircuitDAO;
	
	List<String> routesList = null;
	public void setGetRoutesForAssociatedCircuitDAO(GetRoutesForAssociatedCircuitDAO getRoutesForAssociatedCircuitDAO)
	{
		this.getRoutesForAssociatedCircuitDAO = getRoutesForAssociatedCircuitDAO;
	}

	public List<String> getRoutes(HashMap map) throws Exception
	{
		
		if(map != null && map.get("AssociatedCircuit") != null){
			routesList = getRoutesForAssociatedCircuitDAO.getRoutes(map.get("AssociatedCircuit").toString());
			
			return routesList;
		}
		return null;
	}
}
