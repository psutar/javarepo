package com.centurylink.icl.armmediation.dataaccess;

import java.math.BigDecimal;

public interface DimensionObjectDAO
{

	public BigDecimal getDimensionObjectID(String name);

	public BigDecimal getDimensionRelationShipID(String dimObject);
}
