package com.centurylink.icl.armmediation.dataaccess;



import com.centurylink.icl.armmediation.armaccessobject.LocationBuildingSite;;



public interface ExtLocationBuildingSiteDAO {
	
		public LocationBuildingSite getlocationClli(String  clliCode);

	}
