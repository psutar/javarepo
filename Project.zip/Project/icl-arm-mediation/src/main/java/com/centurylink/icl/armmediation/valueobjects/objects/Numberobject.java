package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Numberobject extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String NUMBEROBJECT2RELATION = "NUMBEROBJECT2RELATION";
	private static final String NUMBEROBJECT2OBJECT = "NUMBEROBJECT2OBJECT";
	private static final String NUMBEROBJECT2DIMOBJECT = "NUMBEROBJECT2DIMOBJECT";
	private static final String NUMBEROBJECT2NUMBER = "NUMBEROBJECT2NUMBER";
	private static final String NUMBEROBJECTID = "NUMBEROBJECTID";
	
	private Dimnumber dimnumber;

	public Numberobject()
	{
		super();
		this.tableName = "NUMBEROBJECT";
	}

	public Numberobject(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static List<Numberobject> getNumberobjectListByObjectIdandDimObjectandRelationship(String objectId, String dimObject, String relationship)
	{
		return getNumberobjectList(null, dimObject, relationship, objectId);
	}

	public static List<Numberobject> getNumberobjectList(String dimNumberId, String dimObject, String relationship, String objectId)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(dimNumberId))
		{
			query = NUMBEROBJECT2DIMOBJECT + " = '" +  dimNumberId + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(objectId))
		{
			query += connector + NUMBEROBJECT2OBJECT + " = '" + objectId + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(dimObject))
		{
			query += connector + NUMBEROBJECT2DIMOBJECT + " = '" + dimObject + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(relationship))
		{
			query += " AND " + NUMBEROBJECT2RELATION + " = '" + relationship + "'";
		}
		
		return getNumberobjectListByQuery(query);
	}

	public static List<Numberobject> getNumberobjectListByQuery(String query)
	{
		Numberobject numberobject = new Numberobject();
		List<Numberobject> numberobjectList = new ArrayList<Numberobject>();
		List<Map<String,Object>> foundNumberobjectList = numberobject.getRecordsByQuery(query);

		for (Map<String,Object> numberobjectMap : foundNumberobjectList)
		{
			Numberobject workNumberobject = new Numberobject(numberobjectMap.get(NUMBEROBJECTID).toString());
			numberobjectList.add(workNumberobject);
		}
		return numberobjectList;
	}

	@Override
	public void populateModel()
	{
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(NUMBEROBJECT2RELATION, new Field(NUMBEROBJECT2RELATION, Field.TYPE_NUMERIC));
		fields.put(NUMBEROBJECT2OBJECT, new Field(NUMBEROBJECT2OBJECT, Field.TYPE_NUMERIC));
		fields.put(NUMBEROBJECT2DIMOBJECT, new Field(NUMBEROBJECT2DIMOBJECT, Field.TYPE_NUMERIC));
		fields.put(NUMBEROBJECT2NUMBER, new Field(NUMBEROBJECT2NUMBER, Field.TYPE_NUMERIC));
		fields.put(NUMBEROBJECTID, new Field(NUMBEROBJECTID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(NUMBEROBJECTID));
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setNumberobject2relation(String numberobject2relation)
	{
		setField(NUMBEROBJECT2RELATION,numberobject2relation);
	}

	public String getNumberobject2relation()
	{
		return getFieldAsString(NUMBEROBJECT2RELATION);
	}

	public void setNumberobject2object(String numberobject2object)
	{
		setField(NUMBEROBJECT2OBJECT,numberobject2object);
	}

	public String getNumberobject2object()
	{
		return getFieldAsString(NUMBEROBJECT2OBJECT);
	}

	public void setNumberobject2dimobject(String numberobject2dimobject)
	{
		setField(NUMBEROBJECT2DIMOBJECT,numberobject2dimobject);
	}

	public String getNumberobject2dimobject()
	{
		return getFieldAsString(NUMBEROBJECT2DIMOBJECT);
	}

	public void setNumberobject2number(String numberobject2number)
	{
		setField(NUMBEROBJECT2NUMBER,numberobject2number);
	}

	public String getNumberobject2number()
	{
		return getFieldAsString(NUMBEROBJECT2NUMBER);
	}

	public void setNumberobjectid(String numberobjectid)
	{
		setField(NUMBEROBJECTID,numberobjectid);
	}

	public String getNumberobjectid()
	{
		return getFieldAsString(NUMBEROBJECTID);
	}
	
	public Dimnumber getDimnumber()
	{
		if (dimnumber == null)
		{
			dimnumber = new Dimnumber(this.getNumberobject2number());
		}
		
		return dimnumber;
	}


}