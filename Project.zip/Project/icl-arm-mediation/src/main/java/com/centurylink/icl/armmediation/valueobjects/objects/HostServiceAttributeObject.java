package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class HostServiceAttributeObject extends AbstractReadOnlyTable{

	private static final String HSTSRVCATROBJECTID = "HSTSRVCATROBJECTID";
	private static final String HSTSRVCATROBJECT2HSTSRVCATR="HSTSRVCATROBJECT2HSTSRVCATR";
	private static final String HSTSRVCATROBJECT="HSTSRVCATROBJECT";
	private static final String HSTSRVCATROBJECT2OBJECT="HSTSRVCATROBJECT2OBJECT";

	private HostServiceAttribute hostServiceAttribute;
	
	public HostServiceAttributeObject()
	{
		super();
		this.tableName = HSTSRVCATROBJECT;
	}

	public HostServiceAttributeObject(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(HSTSRVCATROBJECT2HSTSRVCATR, new Field(HSTSRVCATROBJECT2HSTSRVCATR, Field.TYPE_VARCHAR));
		fields.put(HSTSRVCATROBJECTID, new Field(HSTSRVCATROBJECTID, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(HSTSRVCATROBJECTID));
	}

	public String getHstsrvcatrobjectid() {
		return getFieldAsString(HSTSRVCATROBJECTID);
	}

	public void setHstsrvcatrobjectid(String hstsrvcatrobjectid) {
		setField(HSTSRVCATROBJECTID,hstsrvcatrobjectid);
	}

	public String getHstsrvcatrobject2hstsrvcatr() {
		return getFieldAsString(HSTSRVCATROBJECT2HSTSRVCATR);
	}

	public void setHstsrvcatrobject2hstsrvcatr(
			String hstsrvcatrobject2hstsrvcatr) {
		setField(HSTSRVCATROBJECT2HSTSRVCATR,hstsrvcatrobject2hstsrvcatr);
	}
	
	public String getHstsrvcatrobject2object() {
		return getFieldAsString(HSTSRVCATROBJECT2OBJECT);
	}

	public void setHstsrvcatrobject2object(String hstsrvcatrobject2object) {
		setField(HSTSRVCATROBJECT2OBJECT,hstsrvcatrobject2object);
	}
	
	public HostServiceAttribute getHostServiceAttr(String hostServiceAttr)
	{
		
		hostServiceAttribute=new HostServiceAttribute(hostServiceAttr);
		return hostServiceAttribute;
	}
	
	public static List<HostServiceAttributeObject> getHostServiceAttrObj(String serviceId)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(serviceId))
		{
			query =  HSTSRVCATROBJECT2OBJECT+ " = '" +  serviceId + "'";
			connector = " AND ";
		}
		return getServiceSpecificationByQuery(query);
	}

	public static List<HostServiceAttributeObject> getServiceSpecificationByQuery(String query)
	{
		HostServiceAttributeObject serviceAttributeObj = new HostServiceAttributeObject();
		List<HostServiceAttributeObject> hostServAttrObjList = new ArrayList<HostServiceAttributeObject>();
		List<Map<String,Object>> foundservAttrObjList = serviceAttributeObj.getRecordsByQuery(query);

		for (Map<String,Object> serviceAttributMap : foundservAttrObjList)
		{
			HostServiceAttributeObject workServiceAttr = new HostServiceAttributeObject(serviceAttributMap.get(HSTSRVCATROBJECTID).toString());
			hostServAttrObjList.add(workServiceAttr);
		}
		
		return hostServAttrObjList;
	}
	
}
