package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.dataaccess.SearchLocationDAO;

public class SearchLocationDAOImpl implements SearchLocationDAO
{

	private JdbcTemplate	jdbcTemplate;

	public SearchLocationDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<ARMLocation> searchLocation(String query)
	{
		final List<ARMLocation> armLocationList = this.jdbcTemplate.query(query, new RowMapper<ARMLocation>() {

			public ARMLocation mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMLocation armLocation = new ARMLocation();
				armLocation.setCommonName(rs.getString("NAME"));
				armLocation.setObjectID(rs.getString("LOCATIONID"));
				armLocation.setDescription(rs.getString("FULLNAME"));
				armLocation.setStateOrProvince(rs.getString("PROVINCE"));
				armLocation.setSourceSystem("ARM");
				armLocation.setLocality(rs.getString("TOWNCITY"));
				armLocation.setPostcode(rs.getString("ZIP"));
				armLocation.setAddressLine1(rs.getString("ADDRESS1"));
				armLocation.setAddressLine2(rs.getString("ADDRESS2"));
				armLocation.setAddressLine3(rs.getString("ADDRESS3"));
				armLocation.setSwitchLocationCLLI(rs.getString("PHONESWITCHCLLI"));
				armLocation.setHcoordinate(rs.getString("HCOORDINATE"));
				armLocation.setVcoordinate(rs.getString("VCOORDINATE"));
				armLocation.setNpa(rs.getString("NPA"));
				armLocation.setLata(rs.getString("LATA"));
				armLocation.setNxx(rs.getString("NXX"));
				armLocation.setAddressType(rs.getString("LOCATIONTYPENAME"));
				armLocation.setClli(rs.getString("CLLICODE"));
				return armLocation;

			}
		});
		return armLocationList;
	}

}
