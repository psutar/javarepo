package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.common.util.SQLBuilder;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class HSIRouteVOService 
{
	private static final Log LOG = LogFactory.getLog(HSIRouteVOService.class);
	private String ND="ND";

	private JDBCTempleteUtil jdbcTempleteUtil;

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public List<Service> getHSIRoute(SearchResourceRequestDocument requestObject,HashMap<String, Object> map )
	{

		List<Service> services=new ArrayList<Service>();
		if(map!=null)
		{
			services=getOVCCircuit(requestObject,map);
		}

		return services;
	}

	protected List<Service> getOVCCircuit(SearchResourceRequestDocument requestObject,HashMap<String, Object> map)
	{

		String vlanNumber=null;
		String deviceName=null;
		List<Service> serviceList= new ArrayList<Service>();
		List<String> serviceIDList=new ArrayList<String>();

		if(map.get("VLANNumber")!=null)
		{
			vlanNumber=map.get("VLANNumber").toString();
		}
		if(map.get("DeviceName")!=null)
		{
			deviceName=map.get("DeviceName").toString();
		}	


		if(deviceName!=null)
		{
			serviceIDList= jdbcTempleteUtil.getServiceIdList(getOVCIDQuery(deviceName,vlanNumber));
		}

		if(serviceIDList!=null && serviceIDList.size()>0)
		{
			for(String serviceID:serviceIDList)
			{
				Service service = new Service(serviceID);
				serviceList.add(service);
			}

		}
		return serviceList;
	}


		public String getOVCIDQuery(String deviceName,String vlanNumber)
	{

		SQLBuilder sql = new SQLBuilder(Constants.SERVICE);
		sql.addTable(Constants.CIRCUIT);
		sql.addTable(Constants.SERVICEOBJECT);
		sql.addTable(Constants.NODE,ND);
		sql.addTable(Constants.EXT_DEVICE_TYPE);
		sql.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID);

		if(vlanNumber!=null)
		{
			sql.addTable(Constants.DIMNUMBER);
			sql.addTable(Constants.NUMBER_OBJECT);
			sql.eq(Constants.DIMNUMBER, Constants.NAME,vlanNumber);
			sql.eq(Constants.NUMBER_OBJECT, Constants.NUMBER_OBJECT_2_NUMBER,Constants.DIMNUMBER, Constants.DIMNUMBER_ID);
			sql.eq(Constants.NUMBER_OBJECT, Constants.NUMBER_OBJECT_2_DIM_OBJECT,"3");
			sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_ID,Constants.NUMBER_OBJECT, Constants.NUMBER_OBJECT_2_OBJECT);
			/*sql.eq(Constants.NUMBER_OBJECT, Constants.NUMBER_OBJECT_2_DIM_OBJECT,"4");*/
			/*String [] idColumn = {Constants.CIRCUIT_2_START_PORT,Constants.CIRCUIT_2_END_PORT,Constants.NUMBER_OBJECT_2_OBJECT};
			String [] tableforIDs = {Constants.CIRCUIT,Constants.CIRCUIT,Constants.NUMBER_OBJECT};
			sql.orClauseTables(tableforIDs,idColumn);*/
		}
		if(deviceName!=null)
		{
			String [] table = {ND,ND,ND,Constants.EXT_DEVICE_TYPE};
			String [] column = {Constants.NAME,"ALIAS1","FULLNAME","NETWORKNAME"};
			String [] value = {deviceName,deviceName,deviceName,deviceName};
			
			sql.orClausesUpperCase(table, column, value);
		}
		
		String nodeTtables [] ={Constants.CIRCUIT,Constants.CIRCUIT, ND};
		String nodeColumnNames [] ={Constants.CIRCUIT_2_START_NODE,Constants.CIRCUIT_2_END_NODE,Constants.NODE_ID};
		sql.orClauseTables(nodeTtables, nodeColumnNames);
		sql.eq(ND, Constants.NODE_ID,Constants.EXT_DEVICE_TYPE,Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE,"150000059");
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_OBJECT,Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_DIM_OBJECT,"3");
		sql.eq(Constants.SERVICE_OBJECT, Constants.SERVICE_OBJECT_2_SERVICE,Constants.SERVICE, Constants.SERVICE_ID);
		sql.eq(Constants.SERVICE, Constants.SERVICE_2_SERVICE_TYPE,"1900000000");

		String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("getOVCIDQuery :" + query);
		}

		System.out.println("getOVCIDQuery :" + query);
		return query;

	}
}
