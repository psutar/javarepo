package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Nodetype extends AbstractReadOnlyTable {

	private static final String NODETYPEID = "NODETYPEID";
	private static final String NAME = "NAME";
	private static final String TABLENAME = "TABLENAME";
	private static final String NODETYPE2GRAPHICSBITMAP = "NODETYPE2GRAPHICSBITMAP";
	private static final String NODETYPE2BROWSERBITMAP = "NODETYPE2BROWSERBITMAP";
	private static final String BEHAVIOUR = "BEHAVIOUR";
	private static final String CONTAINERBEHAVIOUR = "CONTAINERBEHAVIOUR";
	private static final String EXTERNALWIDTH = "EXTERNALWIDTH";
	private static final String EXTERNALDEPTH = "EXTERNALDEPTH";
	private static final String EXTERNALHEIGHT = "EXTERNALHEIGHT";
	private static final String LENGTHUNITS = "LENGTHUNITS";
	private static final String EXTERNALAREA = "EXTERNALAREA";
	private static final String AREAUNITS = "AREAUNITS";
	private static final String POWERSUPPLIED = "POWERSUPPLIED";
	private static final String POWERUSED = "POWERUSED";
	private static final String POWERUNITS = "POWERUNITS";
	private static final String COOLINGSUPPLIED = "COOLINGSUPPLIED";
	private static final String COOLINGUSED = "COOLINGUSED";
	private static final String COOLINGUNITS = "COOLINGUNITS";
	private static final String CLASS = "CLASS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String DMPCLASS = "DMPCLASS";
	private static final String NODETYPE2PRODUCTFAMILY = "NODETYPE2PRODUCTFAMILY";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";

	public Nodetype()
	{
		super();
		this.tableName = "NODETYPE";
	}

	public Nodetype(String nodetypeId)
	{
		this();
		primaryKey.setValue(nodetypeId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}


	public static List<Nodetype> getNodetypeListByQuery(String query)
	{
		Nodetype nodetype = new Nodetype();
		List<Nodetype> nodetypeList = new ArrayList<Nodetype>();
		List<Map<String,Object>> foundNodetypeList = nodetype.getRecordsByQuery(query);

		for (Map<String,Object> nodetypeMap : foundNodetypeList)
		{
			Nodetype workNodetype = new Nodetype(nodetypeMap.get(NODETYPEID).toString());
			nodetypeList.add(workNodetype);
		}
		return nodetypeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(NODETYPEID, new Field(NODETYPEID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(NODETYPE2GRAPHICSBITMAP, new Field(NODETYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(NODETYPE2BROWSERBITMAP, new Field(NODETYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(BEHAVIOUR, new Field(BEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(CONTAINERBEHAVIOUR, new Field(CONTAINERBEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(EXTERNALWIDTH, new Field(EXTERNALWIDTH, Field.TYPE_NUMERIC));
		fields.put(EXTERNALDEPTH, new Field(EXTERNALDEPTH, Field.TYPE_NUMERIC));
		fields.put(EXTERNALHEIGHT, new Field(EXTERNALHEIGHT, Field.TYPE_NUMERIC));
		fields.put(LENGTHUNITS, new Field(LENGTHUNITS, Field.TYPE_NUMERIC));
		fields.put(EXTERNALAREA, new Field(EXTERNALAREA, Field.TYPE_NUMERIC));
		fields.put(AREAUNITS, new Field(AREAUNITS, Field.TYPE_NUMERIC));
		fields.put(POWERSUPPLIED, new Field(POWERSUPPLIED, Field.TYPE_NUMERIC));
		fields.put(POWERUSED, new Field(POWERUSED, Field.TYPE_NUMERIC));
		fields.put(POWERUNITS, new Field(POWERUNITS, Field.TYPE_NUMERIC));
		fields.put(COOLINGSUPPLIED, new Field(COOLINGSUPPLIED, Field.TYPE_NUMERIC));
		fields.put(COOLINGUSED, new Field(COOLINGUSED, Field.TYPE_NUMERIC));
		fields.put(COOLINGUNITS, new Field(COOLINGUNITS, Field.TYPE_NUMERIC));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(DMPCLASS, new Field(DMPCLASS, Field.TYPE_VARCHAR));
		fields.put(NODETYPE2PRODUCTFAMILY, new Field(NODETYPE2PRODUCTFAMILY, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(NODETYPEID));
	}

	public void setNodetypeid(String nodetypeid)
	{
		setField(NODETYPEID,nodetypeid);
	}

	public String getNodetypeid()
	{
		return getFieldAsString(NODETYPEID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setNodetype2graphicsbitmap(String nodetype2graphicsbitmap)
	{
		setField(NODETYPE2GRAPHICSBITMAP,nodetype2graphicsbitmap);
	}

	public String getNodetype2graphicsbitmap()
	{
		return getFieldAsString(NODETYPE2GRAPHICSBITMAP);
	}

	public void setNodetype2browserbitmap(String nodetype2browserbitmap)
	{
		setField(NODETYPE2BROWSERBITMAP,nodetype2browserbitmap);
	}

	public String getNodetype2browserbitmap()
	{
		return getFieldAsString(NODETYPE2BROWSERBITMAP);
	}

	public void setBehaviour(String behaviour)
	{
		setField(BEHAVIOUR,behaviour);
	}

	public String getBehaviour()
	{
		return getFieldAsString(BEHAVIOUR);
	}

	public void setContainerbehaviour(String containerbehaviour)
	{
		setField(CONTAINERBEHAVIOUR,containerbehaviour);
	}

	public String getContainerbehaviour()
	{
		return getFieldAsString(CONTAINERBEHAVIOUR);
	}

	public void setExternalwidth(String externalwidth)
	{
		setField(EXTERNALWIDTH,externalwidth);
	}

	public String getExternalwidth()
	{
		return getFieldAsString(EXTERNALWIDTH);
	}

	public void setExternaldepth(String externaldepth)
	{
		setField(EXTERNALDEPTH,externaldepth);
	}

	public String getExternaldepth()
	{
		return getFieldAsString(EXTERNALDEPTH);
	}

	public void setExternalheight(String externalheight)
	{
		setField(EXTERNALHEIGHT,externalheight);
	}

	public String getExternalheight()
	{
		return getFieldAsString(EXTERNALHEIGHT);
	}

	public void setLengthunits(String lengthunits)
	{
		setField(LENGTHUNITS,lengthunits);
	}

	public String getLengthunits()
	{
		return getFieldAsString(LENGTHUNITS);
	}

	public void setExternalarea(String externalarea)
	{
		setField(EXTERNALAREA,externalarea);
	}

	public String getExternalarea()
	{
		return getFieldAsString(EXTERNALAREA);
	}

	public void setAreaunits(String areaunits)
	{
		setField(AREAUNITS,areaunits);
	}

	public String getAreaunits()
	{
		return getFieldAsString(AREAUNITS);
	}

	public void setPowersupplied(String powersupplied)
	{
		setField(POWERSUPPLIED,powersupplied);
	}

	public String getPowersupplied()
	{
		return getFieldAsString(POWERSUPPLIED);
	}

	public void setPowerused(String powerused)
	{
		setField(POWERUSED,powerused);
	}

	public String getPowerused()
	{
		return getFieldAsString(POWERUSED);
	}

	public void setPowerunits(String powerunits)
	{
		setField(POWERUNITS,powerunits);
	}

	public String getPowerunits()
	{
		return getFieldAsString(POWERUNITS);
	}

	public void setCoolingsupplied(String coolingsupplied)
	{
		setField(COOLINGSUPPLIED,coolingsupplied);
	}

	public String getCoolingsupplied()
	{
		return getFieldAsString(COOLINGSUPPLIED);
	}

	public void setCoolingused(String coolingused)
	{
		setField(COOLINGUSED,coolingused);
	}

	public String getCoolingused()
	{
		return getFieldAsString(COOLINGUSED);
	}

	public void setCoolingunits(String coolingunits)
	{
		setField(COOLINGUNITS,coolingunits);
	}

	public String getCoolingunits()
	{
		return getFieldAsString(COOLINGUNITS);
	}

	/*
	public void setClass(String class)
	{
		setField(CLASS,class);
	}

	public String getClass()
	{
		return getFieldAsString(CLASS);
	}
	 */

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setDmpclass(String dmpclass)
	{
		setField(DMPCLASS,dmpclass);
	}

	public String getDmpclass()
	{
		return getFieldAsString(DMPCLASS);
	}

	public void setNodetype2productfamily(String nodetype2productfamily)
	{
		setField(NODETYPE2PRODUCTFAMILY,nodetype2productfamily);
	}

	public String getNodetype2productfamily()
	{
		return getFieldAsString(NODETYPE2PRODUCTFAMILY);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}
}