package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.service.CreateDeviceClliRequest;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager.IsDSLAMPathResolved;
import com.centurylink.icl.armmediation.transformation.AlarmEncrichmentVOTransformation;
import com.centurylink.icl.armmediation.transformation.GetImpactedDeviceByDeviceVOTransformation;
import com.centurylink.icl.armmediation.transformation.HSIRouteVOTransformation;
import com.centurylink.icl.armmediation.transformation.SearchCircuitVOTransformation;
import com.centurylink.icl.armmediation.transformation.SearchNodeVOTransformation;
import com.centurylink.icl.armmediation.transformation.SearchPortVOTransformation;
import com.centurylink.icl.armmediation.transformation.SearchServiceVOTransformation;
import com.centurylink.icl.armmediation.transformation.SearchSlotCardCompatibilityToCim;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.component.IConnector;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.iclaction.ICLActionRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;
import com.iclnbi.iclnbiV200.CreatePartyRequestDocument;
import com.iclnbi.iclnbiV200.DeleteCircuitRequestDocument;
import com.iclnbi.iclnbiV200.DeleteLocationRequestDocument;
import com.iclnbi.iclnbiV200.DeletePartyRequestDocument;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.ResourceNotificationDocument;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.UpdateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.UpdateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.UpdateLocationRequestDocument;
import com.iclnbi.iclnbiV200.UpdatePartyRequestDocument;
import com.iclnbi.iclnbiV200.ValidationRule;


public class ARMMediationServiceImpl implements IConnector
{

	private static final Log LOG = LogFactory.getLog(ARMMediationServiceImpl.class);
	private static final String PORT_DIRECTION = "PortFunction";
	private static final String META_DATA_REQUIRED = "MetaDataRequired";
	private static final String SHELFCLASS  = "ShelfClass";
	private LookupResourceService lookupResourceService;
	private SearchLocationService searchLocationService;
	private CreateLocationService createLocationService;
	private CreatePartyService createPartyService;
	private DeleteLocationService deleteLocationService;
	private DeletePartyService deletePartyService;
	private SearchDeviceService searchDeviceService;
	private CreateDeviceService createDeviceService;
	private UpdateProvisionStatus updateProvisionStatus;
	private UpdatePortSFPAttribute updatePortSFPAttribute;
	private SetNodePortDirectionService setNodePortDirectionService;
	private CreateCircuitService createCircuitService;
	private CreateServiceService createServiceService;
	private AddObjectToService addObjectToService;
	private SearchCircuitService searchCircuitService;
	private SearchNMIByDeviceService searchNMIByDeviceService;
	private SearchImpactedCircuitsForDeviceService searchImpactedCircuitsForDeviceService;
	private GetUNIDataService getUniDataService ;
	private UpdateLocationService updateLocationService;
	private UpdatePartyService updatePartyService;
	private GetContactDetailsService getContactDetailsService;
	private GetNextEventService getNextEventService;
	private TransportPathServiceImpl transportPathService;
	private SubscriberSwapService subscriberSwapService;
	private CreateDeviceClliImpl createDeviceClliService;
	private QCtrlNotificationsService qctrlNotificationsService;

	private DeviceVOService deviceVOService;
	private PortVOService portVOService;
	private CircuitVOService circuitVOService;
	private ServiceVOService serviceVOService;
	private FetchPreferredCompatibleONTModelsVO fetchPreferredCompatibleONTModelsVO;
	private AlarmEnrichmentVOService alarmEnrichmentVOService;
	private DiscoverTransportPathService  discoverTransportPathService;
	private  SearchTransportPathService searchtransportPathService;
	private HSIRouteVOService hsiRouteVOService;
	private ISYSARMPortSyncAuditLogService portSyncAuditLogService;
	private GetImpactedDeviceByDevice getImpactedDeviceByDevice;
	private SearchSlotCardCompatibilityVOService searchSlotCardCompatibilityVOService;
	private GetTopologyDetailsService getTopologyDetailsService;
	private GetDeviceListForCLLIService getDeviceListForCLLIService;
	private GetRoutesForAssociatedCircuitService getRoutesForAssociatedCircuitService;
	private IsDSLAMPathResolved isDSLAMPathResolved;

	
	public void setCreateDeviceClliService(
			CreateDeviceClliImpl createDeviceClliService) {
		this.createDeviceClliService = createDeviceClliService;
	}

	private enum ArmMethod
	{
		GetEVCSP,getSubscriber,ArmLookup, GetDevice, SearchLocation, CreateLocation, CreateDevice, PortDirectionFromMDW, UpdateProvisionStatusFromMDW, UpdatePortSFPAttributeFromMDW, ArmLookupFromMDW, CreateCircuit, CreateService, AddObjectToServiceFromMDW, GetCircuitSummary, GetCircuitDetail,GetImpactedCircuitsForDevice, GetNMIBandwidth, GetUNIRelatedEVCDetails, GetDeviceDetails, DeleteLocation,DeleteParty,CreateParty,UpdateLocation,UpdateParty
		,GetContactDetails, GetEvent, CreateRoute, SubscriberSwap, SearchRoute, DeleteRoute, UpdateRoute, CreateDeviceClli, GetDeviceVO, GetPortVO, GetCircuitVO, GetServiceVO,
		GetARMCLCNotificationDetails, DeviceDetailsFromMDW,GetAlarmEnrichmentVO,FetchPreferredCompatibleONTModelsVO,
		PerformLoopQual,SearchTransportPath,DiscoverTransportPath,HSIRouteVOService,PortSyncAuditLog,GetimpactedDeviceByDeviceVoService,QueryServiceRouteForGPONVO,
		GetDeviceByPortVO,SearchSlotCardCompatibilityVOService,GetTopologyDetailsService,GetDeviceListForCLLIService,GetRoutesForAssociatedCircuitService
	}

	@Override
	public Object call(Object requestObject, HashMap<String, Object> map) throws Exception
	{
		LOG.debug("ARMMediationServiceImpl : Call " + requestObject);
		
		Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
		final String methodName = MediationUtil.getValueFromMap(map, Constants.METHOD_NAME);
		HSIRouteVOTransformation hsiRouteVOTransformation = new HSIRouteVOTransformation(isDSLAMPathResolved);

		switch (ArmMethod.valueOf(methodName))
		{

		case GetEVCSP:

			return lookupResourceService.lookup((SearchResourceRequestDocument) requestObject);

		case getSubscriber:

			return lookupResourceService.lookup((SearchResourceRequestDocument) requestObject);

		case ArmLookup:

			return lookupResourceService.lookup((SearchResourceRequestDocument) requestObject);

		case GetDevice:

			SearchResourceRequestDocument request = (SearchResourceRequestDocument) requestObject;
			final String deviceName = request.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
			final String deviceClli = MediationUtil.getRcv(request, Constants.DEVICE_CILLI);
			if (deviceClli == null && deviceName == null)
			{
				return MediationUtil.getSearchResourceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_INTERNAL_ERROR, Constants.ICL_REQUEST_VALIDATION_ERROR_DETAIL, request);
			}
			final String portDirection = MediationUtil.getRcv(request, PORT_DIRECTION);
			final String metaDataRequired = MediationUtil.getRcv(request, META_DATA_REQUIRED);

			final String shelfClass = MediationUtil.getRcv(request, SHELFCLASS);
			return searchDeviceService.searchDevice(Constants.SEARCH_DEVICE_RESPONSE, deviceClli, portDirection, metaDataRequired, shelfClass, deviceName);

		case SearchLocation:

			return searchLocationService.searchLocation((SearchResourceRequestDocument) requestObject);

		case CreateParty:

			return createPartyService.createParty((CreatePartyRequestDocument) requestObject);

		case CreateLocation:

			return createLocationService.createLocation((CreateLocationRequestDocument) requestObject);

		case DeleteLocation:

			return deleteLocationService.deleteLocation((DeleteLocationRequestDocument)requestObject);

		case DeleteParty:

			return deletePartyService.deleteParty((DeletePartyRequestDocument)requestObject);

		case CreateDevice:

			return createDeviceService.createDevice((CreateDeviceRequestDocument) requestObject, map);

		case CreateCircuit:

			return createCircuitService.createCircuit((CreateCircuitRequestDocument) requestObject, map);

		case CreateService:

			return createServiceService.createService((CreateCircuitRequestDocument) requestObject, map);

		case GetCircuitSummary:

			return searchCircuitService.searchCircuitSummary((SearchResourceRequestDocument) requestObject);

		case GetCircuitDetail:

			return searchCircuitService.searchCircuitDetails((SearchResourceRequestDocument) requestObject);

		case GetNMIBandwidth:

			return searchNMIByDeviceService.searchNMIByDevice((SearchResourceRequestDocument) requestObject);

		case GetImpactedCircuitsForDevice:

			return searchImpactedCircuitsForDeviceService.searchImpactedCircuitsForDevice((SearchResourceRequestDocument) requestObject);

		case GetDeviceDetails:

			return searchDeviceService.searchDeviceDetails((SearchResourceRequestDocument) requestObject);

		case GetUNIRelatedEVCDetails:

			return getUniDataService.getUNIAndRelatedData((SearchResourceRequestDocument) requestObject);

		case GetContactDetails:

			return getContactDetailsService.getName((SearchResourceRequestDocument) requestObject);

		case GetEvent:

			return getNextEventService.processEvent();

		case CreateRoute:

			return transportPathService.createRoute((CreateCircuitRequestDocument)requestObject);

		case SubscriberSwap:

			return subscriberSwapService.swapSubscriber((ICLActionRequestDocument)requestObject);

		case SearchRoute:

			return transportPathService.searchRoute((SearchResourceRequestDocument) requestObject);

		case DeleteRoute:

			return transportPathService.deleteRoute((DeleteCircuitRequestDocument) requestObject);

		case UpdateRoute:

			return transportPathService.updateRoute((UpdateCircuitRequestDocument) requestObject);

		case GetDeviceVO:
		{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return SearchNodeVOTransformation.transformToCIM(deviceVOService.getDevices(searchHolder), searchHolder);
		}
		case GetPortVO:
		{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return SearchPortVOTransformation.transformToCIM(portVOService.getPorts(searchHolder), searchHolder);
		}
		case GetCircuitVO:
		{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return SearchCircuitVOTransformation.transformToCIM(circuitVOService.getCircuits(searchHolder), searchHolder);
		}
		case GetServiceVO:
		{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return SearchServiceVOTransformation.transformToCIM(serviceVOService.getServices(searchHolder), searchHolder);
		}
		case GetARMCLCNotificationDetails:
		{
			
			ResourceNotificationDocument resourceNotificationDocument = qctrlNotificationsService.getResourceNotification((String)requestObject);
			LOG.debug("Generated resource notification " + resourceNotificationDocument);
			return resourceNotificationDocument;
		}

		case FetchPreferredCompatibleONTModelsVO:
		{
			/*VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return FetchPreferredVOTransformation.transformToCIM(portVOService.getPorts(searchHolder), searchHolder);*/
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			return SearchNodeVOTransformation.transformToCIMForPreferredCompatibleONTModels(deviceVOService.getDevices(searchHolder), searchHolder);

		}
		
		case PortSyncAuditLog:
		{
			if(((String)map.get("action"))!=null && ((String)map.get("action")).equalsIgnoreCase("Search")){
				return portSyncAuditLogService.checkInAuditLog(requestObject, map);
			}
			else{
				UpdateDeviceResponseDocument updateDEviceResponseDocument = portSyncAuditLogService.doAuditLogEntry((UpdateDeviceResponseDocument)requestObject,map);
				return updateDEviceResponseDocument;	
			}	
		}


                case QueryServiceRouteForGPONVO:
		{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			//return SearchNodeVOTransformation.transformToCIMForPreferredCompatibleONTModels(deviceVOService.getDevices(searchHolder), searchHolder);
			
			return SearchServiceVOTransformation.transformToCIMForQueryServiceRouteForGPON(searchHolder);
		}
		case GetDeviceByPortVO:
{
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) requestObject);
			SearchResourceRequestDocument request1 = (SearchResourceRequestDocument) requestObject;			
			final String portId = MediationUtil.getRcv(request1, Constants.PORTOBJECTID);
			searchHolder.setObjectID(portId);			
			return SearchPortVOTransformation.transformToCIMForGetDeviceByPortVO(portVOService.getPorts(searchHolder), searchHolder);
		}

		case GetTopologyDetailsService:

			return getTopologyDetailsService.searchTopologyDetails((SearchResourceRequestDocument) requestObject);

		//Operations called from MDW

		case ArmLookupFromMDW:

			return lookupResourceService.lookupFromMDW(map);

		case PortDirectionFromMDW:

			return setNodePortDirectionService.setPortDirection(map);

		case DeviceDetailsFromMDW:
			String nodeName = MediationUtil.getValueFromMap(map, MDWConstants.DEVICE_NAME);
			String nodeId = MediationUtil.getValueFromMap(map, MDWConstants.NODE_ID);
			String returnDeviceDetails = MediationUtil.getValueFromMap(map, "ReturnDeviceDetails");
			String levelFromMDW = MediationUtil.getValueFromMap(map, "Level");
			VOSearchHolder searchHolder = new VOSearchHolder();
			searchHolder.setEntity("DEVICE");				
			searchHolder.setScope("DETAILED");
			searchHolder.setCommonName(nodeName);
			searchHolder.setObjectID(nodeId);
			searchHolder.setLevel(levelFromMDW);
			Map<String, String> modifiers = new HashMap<String, String>();
			Map<String, ValidationRule> filterCriteraList = new HashMap<String, ValidationRule>();      
			searchHolder.setModifiers(modifiers);
			searchHolder.setFilterCriteraList(filterCriteraList);			

			return SearchNodeVOTransformation.transformToCIMForCreateDevice(deviceVOService.getDevices(searchHolder), searchHolder);

			//return searchDeviceService.searchDeviceDetailsForMDW(map);

		case UpdateProvisionStatusFromMDW:

			return updateProvisionStatus.updateProvisionStatus(map);

		case UpdatePortSFPAttributeFromMDW:

			return updatePortSFPAttribute.updatePortSFPAttribute(map);

		case AddObjectToServiceFromMDW:

			return addObjectToService.addObjectToService(map);

		case UpdateLocation:

			return updateLocationService.UpdateLocation((UpdateLocationRequestDocument)requestObject);

		case UpdateParty:

			return updatePartyService.updateParty((UpdatePartyRequestDocument)requestObject);

		case CreateDeviceClli:

			if(requestObject instanceof CreateDeviceClliRequest)
			{
				return createDeviceClliService.createDeviceClli((CreateDeviceClliRequest)requestObject);
			}

			return createDeviceClliService.createDeviceClli((CreateDeviceRequestDocument)requestObject);

		case PerformLoopQual:

			return searchCircuitService.performLoopQual((SearchResourceRequestDocument) requestObject);			


		case GetAlarmEnrichmentVO:

			SearchResourceRequestDocument requestDoc = (SearchResourceRequestDocument) requestObject;
			SearchResourceRequestDocument  req=AlarmEncrichmentVOTransformation.transformToVOCriteria(requestDoc);
			final String level2 =req.getSearchResourceRequest().getSearchResourceDetails().getLevel();	
			//When Level is PPORT return Circuits and Services 
			if(level2 != null && level2.equalsIgnoreCase("PPORT"))
			{
				return AlarmEncrichmentVOTransformation.transformToCIM(alarmEnrichmentVOService.getCircuits((SearchResourceRequestDocument)req),alarmEnrichmentVOService.getServices((SearchResourceRequestDocument)req),(SearchResourceRequestDocument)req);
			}
			//When Level is other than PPORT(Node,Shelf,Slot,Fan,PS) return Device 
			else 
			{
				PhysicalDevice physicalDevice =alarmEnrichmentVOService.getDevice(req);
				if(physicalDevice!=null)
				{
					SearchResponseDetailsBuilder searchResponseDetailsBuilder =new SearchResponseDetailsBuilder();
					SearchResourceResponseBuilder searchResourceResponseBuilder=new SearchResourceResponseBuilder();
					SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder=new SearchResourceResponseDocumentBuilder();

					searchResponseDetailsBuilder.buildSearchResponseDetails();
					searchResponseDetailsBuilder.addDevice(physicalDevice);
					searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
					searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
					searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
					return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
				}
				else
				{
					throw new OSSDataNotFoundException();
				}

			}
		case DiscoverTransportPath:

			return discoverTransportPathService.discoverTransportPathService((SearchResourceRequestDocument) requestObject);

		case SearchTransportPath:

			return searchtransportPathService.searchTransportPathService((SearchResourceRequestDocument) requestObject);


		case HSIRouteVOService:
			return hsiRouteVOTransformation.transformToCIM(hsiRouteVOService.getHSIRoute(null,map),map);

		case GetimpactedDeviceByDeviceVoService:

			final String Name =  ((SearchResourceRequestDocument) requestObject).getSearchResourceRequest().getSearchResourceDetails().getCommonName();
			return  GetImpactedDeviceByDeviceVOTransformation.transformToCIM(getImpactedDeviceByDevice.getImpactedDeviceByDevice((SearchResourceRequestDocument)requestObject),Name);
			
		case SearchSlotCardCompatibilityVOService:
			
			SearchSlotCardCompatibilityToCim searchSlotCardCompatibilityToCim = new SearchSlotCardCompatibilityToCim();
			return searchSlotCardCompatibilityToCim.transformSlotCardCompatibilityToCim((SearchResourceRequestDocument)requestObject, searchSlotCardCompatibilityVOService.getSlotCardCompatibilityDetails((SearchResourceRequestDocument)requestObject, map));
			
		case GetDeviceListForCLLIService:
						
			return getDeviceListForCLLIService.getDeviceListForCLLI(map);
			
		case GetRoutesForAssociatedCircuitService:
			
			return getRoutesForAssociatedCircuitService.getRoutes(map);
			
		}


		throw new Exception("Operation not supported Exception.");  

	}

	public void setDeletePartyService(DeletePartyService deletePartyService) {
		this.deletePartyService = deletePartyService;
	}

	public void setSearchImpactedCircuitsForDeviceService(
			SearchImpactedCircuitsForDeviceService searchImpactedCircuitsForDeviceService) 
	{
		this.searchImpactedCircuitsForDeviceService = searchImpactedCircuitsForDeviceService;
	}

	public void setSearchLocationService(SearchLocationService searchLocationService)
	{
		this.searchLocationService = searchLocationService;
	}

	public void setLookupResourceService(LookupResourceService lookupResourceService)
	{
		this.lookupResourceService = lookupResourceService;
	}

	public void setCreateLocationService(CreateLocationService createLocationService)
	{
		this.createLocationService = createLocationService;
	}

	public void setDeleteLocationService(DeleteLocationService deleteLocationService)
	{
		this.deleteLocationService = deleteLocationService;
	}

	public void setCreateDeviceService(CreateDeviceService createDeviceService)
	{
		this.createDeviceService = createDeviceService;
	}

	public void setSearchDeviceService(SearchDeviceService searchDeviceService)
	{
		this.searchDeviceService = searchDeviceService;
	}

	public void setSetNodePortDirectionService(SetNodePortDirectionService setNodePortDirectionService)
	{
		this.setNodePortDirectionService = setNodePortDirectionService;
	}

	public void setUpdateProvisionStatus(UpdateProvisionStatus updateProvisionStatus)
	{
		this.updateProvisionStatus = updateProvisionStatus;
	}

	public void setUpdatePortSFPAttribute(UpdatePortSFPAttribute updatePortSFPAttribute)
	{
		this.updatePortSFPAttribute = updatePortSFPAttribute;
	}

	public void setCreateCircuitService(CreateCircuitService createCircuitService)
	{
		this.createCircuitService = createCircuitService;
	}

	public void setCreateServiceService(CreateServiceService createServiceService)
	{
		this.createServiceService = createServiceService;
	}

	public void setAddObjectToService(AddObjectToService addObjectToService)
	{
		this.addObjectToService = addObjectToService;
	}

	public void setSearchCircuitService(SearchCircuitService searchCircuitService)
	{
		this.searchCircuitService = searchCircuitService;
	}

	public void setSearchNMIByDeviceService(SearchNMIByDeviceService searchNMIByDeviceService)
	{
		this.searchNMIByDeviceService = searchNMIByDeviceService;
	}

	public void setGetUniDataService(GetUNIDataService getUniDataService) {
		this.getUniDataService = getUniDataService;
	}

	public void setCreatePartyService(CreatePartyService createPartyService) {
		this.createPartyService = createPartyService;
	}

	public void setUpdateLocationService(UpdateLocationService updateLocationService) {
		this.updateLocationService = updateLocationService;
	}

	public void setUpdatePartyService(UpdatePartyService updatePartyService) {
		this.updatePartyService = updatePartyService;
	}

	public void setGetContactDetailsService(
			GetContactDetailsService getContactDetailsService) {
		this.getContactDetailsService = getContactDetailsService;
	}

	public void setGetNextEventService(GetNextEventService getNextEventService)
	{
		this.getNextEventService = getNextEventService;
	}

	public void setTransportPathService(TransportPathServiceImpl itransportPathService)
	{
		this.transportPathService = itransportPathService;
	}
	public void setSubscriberSwapService(SubscriberSwapService iSubscriberSwapService)
	{
		this.subscriberSwapService = iSubscriberSwapService;
	}
	public void setDeviceVOService(DeviceVOService deviceVOService)
	{
		this.deviceVOService = deviceVOService;
	}

	public void setPortVOService(PortVOService portVOService)
	{
		this.portVOService = portVOService;
	}

	public void setCircuitVOService(CircuitVOService circuitVOService)
	{
		this.circuitVOService = circuitVOService;
	}

	public void setServiceVOService(ServiceVOService serviceVOService)
	{
		this.serviceVOService = serviceVOService;
	}

	public void setAlarmEnrichmentVOService(
			AlarmEnrichmentVOService alarmEnrichmentVOService) {
		this.alarmEnrichmentVOService = alarmEnrichmentVOService;
	}

	public FetchPreferredCompatibleONTModelsVO getFetchPreferredCompatibleONTModelsVO() {
		return fetchPreferredCompatibleONTModelsVO;
	}

	public void setFetchPreferredCompatibleONTModelsVO(
			FetchPreferredCompatibleONTModelsVO fetchPreferredCompatibleONTModelsVO) {
		this.fetchPreferredCompatibleONTModelsVO = fetchPreferredCompatibleONTModelsVO;
	}

	public void setDiscoverTransportPathService(DiscoverTransportPathService discoverTransportPathService)
	{
		this.discoverTransportPathService = discoverTransportPathService;
	}
	public void setSearchTransportPathService(SearchTransportPathService searchtransportPathService)
	{
		this.searchtransportPathService = searchtransportPathService;
	}
	public void setHsiRouteVOService(HSIRouteVOService hsiRouteVOService)
	{
		this.hsiRouteVOService = hsiRouteVOService;
	}

	public void setPortSyncAuditLogService(
			ISYSARMPortSyncAuditLogService portSyncAuditLogService) {
		this.portSyncAuditLogService = portSyncAuditLogService;
	}

	public ISYSARMPortSyncAuditLogService getPortSyncAuditLogService() {
		return portSyncAuditLogService;
	}
	public void setGetImpactedDeviceByDevice(GetImpactedDeviceByDevice getImpactedDeviceByDevice)
	{
		this.getImpactedDeviceByDevice = getImpactedDeviceByDevice;
	}
	
	public void setIsDSLAMPathResolved(IsDSLAMPathResolved isDSLAMPathResolved)
	{
		this.isDSLAMPathResolved = isDSLAMPathResolved;
	}

	public QCtrlNotificationsService getQctrlNotificationsService() {
		return qctrlNotificationsService;
	}

	public void setQctrlNotificationsService(
			QCtrlNotificationsService qctrlNotificationsService) {
		this.qctrlNotificationsService = qctrlNotificationsService;
	}
	
	public void setGetTopologyDetailsService(GetTopologyDetailsService getTopologyDetailsService)
	{
		this.getTopologyDetailsService = getTopologyDetailsService;
	}

	public void setSearchSlotCardCompatibilityVOService(SearchSlotCardCompatibilityVOService searchSlotCardCompatibilityVOService)
	{
		this.searchSlotCardCompatibilityVOService = searchSlotCardCompatibilityVOService;
	}
	
	public void setGetDeviceListForCLLIService(GetDeviceListForCLLIService getDeviceListForCLLIService)
	{
		this.getDeviceListForCLLIService = getDeviceListForCLLIService;
	}
	public void setGetRoutesForAssociatedCircuitService(GetRoutesForAssociatedCircuitService getRoutesForAssociatedCircuitService)
	{
		this.getRoutesForAssociatedCircuitService = getRoutesForAssociatedCircuitService;
	}
	
}