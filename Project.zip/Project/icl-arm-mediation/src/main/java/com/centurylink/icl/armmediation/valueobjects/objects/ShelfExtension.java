package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class ShelfExtension  extends AbstractReadOnlyTable 
{
	private static final String SHELFID = "SHELFID";
	private static final String HARDWAREVERSION = "HARDWAREVERSION";
	private static final String BAYNAME = "BAYNAME";
	private static final String LOGICALSHELFNAME = "LOGICALSHELFNAME";
	private static final String SOFTWAREVERSION = "SOFTWAREVERSION";
	private static final String SHELFSERIALNUMBER = "SHELFSERIALNUMBER";
	private static final String RELAYRACKID = "RELAYRACKID";	
	private static final String FIRMWAREVERSION = "FIRMWAREVERSION";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	

	
	public ShelfExtension()
	{
		super();
	}
	
	public ShelfExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		this.getRecordByPrimaryKey();
	}
	@Override
	public void populateModel() {
		fields.put(SHELFID, new Field(SHELFID, Field.TYPE_NUMERIC));
		fields.put(HARDWAREVERSION, new Field(HARDWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(BAYNAME, new Field(BAYNAME, Field.TYPE_VARCHAR));
		fields.put(LOGICALSHELFNAME, new Field(LOGICALSHELFNAME, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));		
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(SHELFSERIALNUMBER, new Field(SHELFSERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(RELAYRACKID, new Field(RELAYRACKID, Field.TYPE_VARCHAR));		
		fields.put(FIRMWAREVERSION, new Field(FIRMWAREVERSION, Field.TYPE_VARCHAR));		
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(SOFTWAREVERSION, new Field(SOFTWAREVERSION, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(SHELFID));
		
	}
	
	
	
	public void setHardwareversion(String hardwareversion)
	{
		setField(HARDWAREVERSION,hardwareversion);
	}

	public String getHardwareversion()
	{
		return getFieldAsString(HARDWAREVERSION);
	}	
	
	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}
	
	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}	
	

	public void setFirmwareversion(String firmwareversion)
	{
		setField(FIRMWAREVERSION,firmwareversion);
	}

	public String getFirmwareversion()
	{
		return getFieldAsString(FIRMWAREVERSION);
	}	
	
	
	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}
	public void setShelfid(String shelfId)
	{
		setField(SHELFID,shelfId);
	}

	public  String getShelfid() {
		return getFieldAsString(SHELFID);
	}

	public void setBayname(String bayname)
	{
		setField(BAYNAME,bayname);
	}
	public  String getBayname() {
		return getFieldAsString(BAYNAME);
	}
	
	public void setLogicalshelfname(String logicalSelfName)
	{
		setField(LOGICALSHELFNAME,logicalSelfName);
	}
	
	public  String getLogicalshelfname() {
		return getFieldAsString(LOGICALSHELFNAME);
	}
	public void setSoftwareversion(String softwareVersion)
	{
		setField(SOFTWAREVERSION,softwareVersion);
	}
	public  String getSoftwareversion() {
		return getFieldAsString(SOFTWAREVERSION);
	}
	public void setShelfserialnumber(String shelfSerialNumber)
	{
		setField(SHELFSERIALNUMBER,shelfSerialNumber);
	}
	public  String getShelfserialnumber() {
		return getFieldAsString(SHELFSERIALNUMBER);
	}
	public void setRelayrackid(String relayRackId)
	{
		setField(RELAYRACKID,relayRackId);
	}
	public  String getRelayrackid() {
		return getFieldAsString(RELAYRACKID);
	}

	
	
}
