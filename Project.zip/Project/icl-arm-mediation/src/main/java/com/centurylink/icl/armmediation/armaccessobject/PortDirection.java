package com.centurylink.icl.armmediation.armaccessobject;

public class PortDirection
{
	private int		portId;
	private String	portDirection;
	private int		portNumber;

	@Override
	public String toString()
	{
		return "PortDirection [portId=" + portId + ", portDirection=" + portDirection + ", portNumber=" + portNumber + "]";
	}

	public int getPortId()
	{
		return portId;
	}

	public void setPortId(int portId)
	{
		this.portId = portId;
	}

	public String getPortDirection()
	{
		return portDirection;
	}

	public void setPortDirection(String portDirection)
	{
		this.portDirection = portDirection;
	}

	public int getPortNumber()
	{
		return portNumber;
	}

	public void setPortNumber(int portNumber)
	{
		this.portNumber = portNumber;
	}
}
