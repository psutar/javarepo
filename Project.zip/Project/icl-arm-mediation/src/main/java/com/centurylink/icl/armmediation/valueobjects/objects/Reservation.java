package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;

import com.centurylink.icl.valueobjects.impl.PrimaryKey;


public class Reservation extends AbstractReadOnlyTable {

	
	private static final Log LOG = LogFactory.getLog(Reservation.class);
	
	
	private static final String RESERVATIONID = "RESERVATIONID";
	private static final String NAME = "NAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String FULLNAME = "FULLNAME";	
	
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";	
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String RESERVATION2PROVISIONSTATUS = "RESERVATION2PROVISIONSTATUS";
	private static final String RESERVATION2RESERVATIONTYPE = "RESERVATION2RESERVATIONTYPE";
	private static final String RESERVATION2FUNCTIONALSTATUS = "RESERVATION2FUNCTIONALSTATUS";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String TIMETOLIVE = "TIMETOLIVE";
	private static final String RESERVATION2OWNERDIMOBJECT = "RESERVATION2OWNERDIMOBJECT";
	private static final String RESERVATION2OWNEROBJECT = "RESERVATION2OWNEROBJECT";
	private static final String RESERVATION2DIMOBJECT = "RESERVATION2DIMOBJECT";
	private static final String ISHARDRESERVATION = "ISHARDRESERVATION";	
	private static final String PARTIALAMOUNT = "PARTIALAMOUNT";
	private static final String RES2CONTAINEDDIMOBJECT = "RES2CONTAINEDDIMOBJECT";
	private static final String QUANTITY = "QUANTITY";
	private static final String BANDWIDTH = "BANDWIDTH";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";
	private static final String RESERVATION2RPPLAN = "RESERVATION2RPPLAN";

	
	
	
	public Reservation()
	{
		super();
		this.tableName = "Reservation";
	}
	
	public Reservation(String reservationId)
	{
		this();
		primaryKey.setValue(reservationId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	

	
	@Override
	public void populateModel()
	{
		
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RESERVATIONID, new Field(RESERVATIONID, Field.TYPE_NUMERIC));		
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(RESERVATION2PROVISIONSTATUS, new Field(RESERVATION2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(RESERVATION2RESERVATIONTYPE, new Field(RESERVATION2RESERVATIONTYPE, Field.TYPE_NUMERIC));
		fields.put(RESERVATION2FUNCTIONALSTATUS, new Field(RESERVATION2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(RESERVATION2OWNERDIMOBJECT, new Field(RESERVATION2OWNERDIMOBJECT, Field.TYPE_NUMERIC));
		fields.put(RESERVATION2OWNEROBJECT, new Field(RESERVATION2OWNEROBJECT, Field.TYPE_NUMERIC));
		fields.put(RESERVATION2DIMOBJECT, new Field(RESERVATION2DIMOBJECT, Field.TYPE_NUMERIC));		
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));		
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(RESERVATIONID));
		
		
	}
	
	
	public void setReservationId(String reservationId)
	{
		setField(RESERVATIONID,reservationId);
	}

	public String getReservationId()
	{
		return getFieldAsString(RESERVATIONID);
	}
	
	public void setReservation2ProvisionStatus(String reservation2ProvisionStatus)
	{
		setField(RESERVATION2PROVISIONSTATUS,reservation2ProvisionStatus);
	}

	public String getReservation2ProvisionStatus()
	{
		return getFieldAsString(RESERVATION2PROVISIONSTATUS);
	}
	
	public void setReservation2FunctionStatus(String reservation2FunctionStatus)
	{
		setField(RESERVATION2FUNCTIONALSTATUS,reservation2FunctionStatus);
	}

	public String getReservation2FunctionStatus()
	{
		return getFieldAsString(RESERVATION2FUNCTIONALSTATUS);
	}
	
	

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}	

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}
	

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}


	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}
	
	
	public Reservation getPortReservationObject(String id , String dimType)
	{
		
		
		String query = RESERVATION2DIMOBJECT + "=" + dimType + " and reservation2object=" + id;		
		
		return getPortReservationByQuery(query);
	}

	public Reservation getPortReservationByQuery(String query)
	{
		Reservation reservation = new Reservation();
		List<Map<String,Object>> reservationList = reservation.getRecordsByQuery(query);

		Reservation reservationFound = null;
		for (Map<String,Object> reservationMap : reservationList)
		{
			reservationFound = new Reservation(reservationMap.get(RESERVATIONID).toString());
			if(reservationFound != null)
				return reservationFound;
		}
		
		return reservationFound;
	}
	
	
	
	
	
	/*public static String getPortReservationByQuery(String query)
	{
		Port port = new Port();
		//List<Port> portList = new ArrayList<Port>();
		List<Map<String,Object>> foundPortList = port.getFullRecordsByQuery(query);
		
		if(null == foundPortList ||  foundPortList.size() == 0){
            return "N";
      }
      return "Y";	
	}*/
}