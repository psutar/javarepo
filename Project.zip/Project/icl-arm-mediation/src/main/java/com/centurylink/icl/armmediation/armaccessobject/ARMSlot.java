package com.centurylink.icl.armmediation.armaccessobject;

public class ARMSlot
{
	private Long	slodId;
	private Long	slot2Shelf;
	private String	commonName;
	private int slotNumber;

	public Long getSlodId()
	{
		return slodId;
	}

	public void setSlodId(Long slodId)
	{
		this.slodId = slodId;
	}

	public Long getSlot2Shelf()
	{
		return slot2Shelf;
	}

	public void setSlot2Shelf(Long slot2Shelf)
	{
		this.slot2Shelf = slot2Shelf;
	}

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public int getSlotNumber()
	{
		return slotNumber;
	}

	public void setSlotNumber(int slotNumber)
	{
		this.slotNumber = slotNumber;
	}

}
