package com.centurylink.icl.armmediation.armaccessobject;

public class MaxNameValue {
	private String maxColName;
	private String maxValue;
	private String serviceType;
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getMaxColName() {
		return maxColName;
	}
	public void setMaxColName(String maxColName) {
		this.maxColName = maxColName;
	}
	public String getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}
}
