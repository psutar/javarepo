package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMNode;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.AffectedServiceTypeListBuilder;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchDeviceDetailsToCim
{
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final PhysicalDeviceRoleBuilder physicaldevicerolebuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final IPAddressBuilder ipaddressbuilder;
	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;

	public SearchDeviceDetailsToCim()
	{
		physicalDeviceBuilder = new PhysicalDeviceBuilder();
		physicaldevicerolebuilder = new PhysicalDeviceRoleBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		ipaddressbuilder = new IPAddressBuilder();
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		customerBuilder = new CustomerBuilder();
		ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
	}

	public SearchResourceResponseDocument transformDeviceDetailToCim(SearchResourceRequestDocument request, List<ARMDevice> armdeviceList)
	{
		if (armdeviceList != null && armdeviceList.size() > 0)
		{
			@SuppressWarnings("unchecked")
			HashMap<String,ArrayList<String>> rolesMap=getDeviceRoles(armdeviceList);
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			List<String> l1 = new ArrayList<String>();
			int count = 0;
			
			Map<String, ARMDevice> uniqueDevicesMap  = new HashMap<String, ARMDevice>();
			for(ARMDevice armNode:armdeviceList)
			{
				uniqueDevicesMap.put(String.valueOf(armNode.getObjectID()), armNode);
			}
			
			Set<String> uniqueDevices = uniqueDevicesMap.keySet();
			
			for (String deviceObjectId : uniqueDevices)
			{
				ARMDevice armDevice = uniqueDevicesMap.get(deviceObjectId);
				
				/*String prevNodeId = "";
				if (count != 0)
				{
					prevNodeId = (armdeviceList.get(count - 1)).getObjectID();
				}*/
				/*if(count==0 ||!prevNodeId.equals(armDevice.getObjectID()) )
				{*/
					String armDevicen = armDevice.getCommonName();

					l1.add(armDevicen);
					physicalDeviceBuilder.buildPhysicalDevice(armDevice.getCommonName(), armDevice.getObjectID(), armDevice.getDescription(), "ARM", armDevice.getResourceType(), null, armDevice.getPrStatus(), armDevice.getClliCode(), armDevice.getAlias1(), armDevice.getManufacturer(), armDevice.getModel(), null, armDevice.getVendorName(), armDevice.getResourceSubType(), armDevice.getMco(), armDevice.getFuncStatus(), armDevice.getVersion(), armDevice.getFirmwareVersion(), armDevice.getSoftwareVersion(), armDevice.getAlias2(), armDevice.getSerialNumber(), armDevice.getVersionNumber(), armDevice.getVendorPartNumber(), armDevice.getNmsType(), armDevice.getNmsHostName(), armDevice.getSnmpObjectId(), armDevice.getChassisSerialNumber(), armDevice.getUsageState(),armDevice.getNetworkName());
					
					if(armDevice.getSubStatus() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("SubStatus", armDevice.getSubStatus());
					
					if(armDevice.getHardwareVersion() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("HardwareVersion", armDevice.getHardwareVersion());
					
					if(armDevice.getRevision() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("Revision", armDevice.getRevision());
					
					if(armDevice.getMarkedForDelete() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("MarkedForDeletion", armDevice.getMarkedForDelete());
					
					if(armDevice.getDisContinueDate() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("DiscontinueDate", armDevice.getDisContinueDate());
					
					if(armDevice.getDisContinueReason() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("DiscontinueReason", armDevice.getDisContinueReason());
					
					if(armDevice.getManufacturerPartNumber() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("ManufacturerPartNumber", armDevice.getManufacturerPartNumber());
					
					if(armDevice.getPartType() !=null)
						physicalDeviceBuilder.addResourceDescribedBy("PartType", armDevice.getPartType());
					
					if (armDevice.getMco() != null)
						physicalDeviceBuilder.addResourceDescribedBy("MCO", armDevice.getMco());
					
					if (armDevice.getMgmtVlan() != null)
						physicalDeviceBuilder.addResourceDescribedBy("ManagementVLAN", armDevice.getMgmtVlan());
					
					if (armDevice.getFullName() != null)
						physicalDeviceBuilder.addResourceDescribedBy("FullName", armDevice.getFullName());

					if (armDevice.getMacAddress() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getMacAddress(), "MAC Address", null, null, null, null);
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV4MgmRouterId() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV4MgmRouterId(), "MGM Router Id", null, null, null, "4");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV4Console1() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV4Console1(), "Console 1", null, null, null, "4");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV4Console2() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV4Console2(), "Console 2", null, null, null, "4");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV6MgmRouterId() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV6MgmRouterId(), "MGM Router Id", null, null, null, "6");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV6Console1() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV6Console1(), "Console 1", null, null, null, "6");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getIpV6Console2() != null)
					{
						ipaddressbuilder.buildIPAddress(armDevice.getIpV6Console2(), "Console 2", null, null, null, "6");
						physicalDeviceBuilder.addIPAddress(ipaddressbuilder.getIPAddress());
					}
					if (armDevice.getLocationName() != null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(armDevice.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						physicalDeviceBuilder.addInstalledAtAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					if (armDevice.getCustomerName() != null)
					{
						ownsResourceDetailsBuilder.buildOwnsResourceDetails();
						String subscriberName = armDevice.getCustomerName();
						
						customerBuilder.buildCustomer(subscriberName, armDevice.getCustomerId(), null,armDevice.getCustomerFullName(), null, null,null);
						ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
						physicalDeviceBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
					}
					if(armDevice.getTtServiceType() != null)
					{
						physicalDeviceBuilder.addResourceDescribedBy("TtServiceType ", armDevice.getTtServiceType());
					}
					if (rolesMap.get(armDevice.getObjectID()) != null && rolesMap.get(armDevice.getObjectID()).size()>0)
					{
						for(String role:rolesMap.get(armDevice.getObjectID()))
						{	
							if(!StringHelper.isEmpty(role))
							{
								physicaldevicerolebuilder.buildPhysicalDeviceRole(role);
								physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicaldevicerolebuilder.getPhysicaldevicerole());
							}
						}
					}
					
					searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());
				}
				/*if(count==0 ||!prevNodeId.equals(armDevice.getObjectID()) )
				{	
					searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());
				}
				++count;
			}*/
			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		} 
		else
		{
			throw new OSSDataNotFoundException();
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HashMap getDeviceRoles(List<ARMDevice> armdeviceList)
	{
		HashMap<String, ArrayList<String>> rolesMap = new HashMap<String, ArrayList<String>>();
		for (ARMDevice armDevice : armdeviceList)
		{
			if (rolesMap.get(armDevice.getObjectID()) != null)
			{
				rolesMap.get(armDevice.getObjectID()).add(armDevice.getRole());
			} else
			{
				ArrayList roles = new ArrayList();
				roles.add(armDevice.getRole());
				rolesMap.put(armDevice.getObjectID(), roles);
			}
		}
		return rolesMap;
	}

}
