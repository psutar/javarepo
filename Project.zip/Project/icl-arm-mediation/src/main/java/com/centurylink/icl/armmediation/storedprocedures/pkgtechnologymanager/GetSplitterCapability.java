package com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager;


import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class GetSplitterCapability extends StoredProcedure
{

	private static final Log LOG = LogFactory.getLog(GetSplitterCapability.class);

	public GetSplitterCapability(DataSource dataSource)
	{
		super(dataSource, "Customization.PkgTechnologyManager.GetSplitterCapability");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_SplitterLocation", Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_Splittercap", OracleTypes.ARRAY, "CUSTOMIZATION.T_SPLITTERCAPABILITY"));
				
		declareParameter(new SqlParameter("i_Splitter", Types.VARCHAR));
		
		compile();
	}

	public Map<String, Object> execute(String i_Splitter)
	{
		final Map<String, Object> in = new HashMap<String, Object>();

		in.put("i_Splitter", i_Splitter);
		
		return super.execute(in);
	}

}