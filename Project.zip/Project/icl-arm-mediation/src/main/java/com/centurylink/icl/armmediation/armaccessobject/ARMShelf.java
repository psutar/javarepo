package com.centurylink.icl.armmediation.armaccessobject;

public class ARMShelf
{
	private String	aliasName;
	private String	aliasName2;
	private String	bayName;
	private String	commonName;
	private String	description;
	private String	firmwareVersion;
	private String	relayRackID;
	private String	serialNumber;
	private String	softwareVersion;
	private String	type;
	private String	version;
	private long	shelfID;

	public String getAliasName()
	{
		return aliasName;
	}

	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}

	public String getAliasName2()
	{
		return aliasName2;
	}

	public void setAliasName2(String aliasName2)
	{
		this.aliasName2 = aliasName2;
	}

	public String getBayName()
	{
		return bayName;
	}

	public void setBayName(String bayName)
	{
		this.bayName = bayName;
	}

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getFirmwareVersion()
	{
		return firmwareVersion;
	}

	public void setFirmwareVersion(String firmwareVersion)
	{
		this.firmwareVersion = firmwareVersion;
	}

	public String getRelayRackID()
	{
		return relayRackID;
	}

	public void setRelayRackID(String relayRackID)
	{
		this.relayRackID = relayRackID;
	}

	public String getSerialNumber()
	{
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber)
	{
		this.serialNumber = serialNumber;
	}

	public String getSoftwareVersion()
	{
		return softwareVersion;
	}

	public void setSoftwareVersion(String softwareVersion)
	{
		this.softwareVersion = softwareVersion;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getVersion()
	{
		return version;
	}

	public void setVersion(String version)
	{
		this.version = version;
	}

	public long getShelfID()
	{
		return shelfID;
	}

	public void setShelfID(long shelfID)
	{
		this.shelfID = shelfID;
	}

}
