package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

public interface CircuitCircuitDAO
{
	public List<Long> getUnderlyingCircuits(Long vlanCircuitId);
}
