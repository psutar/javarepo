package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.centurylink.icl.querybuilder.interfaces.VariableAndValueProcessor;
import com.centurylink.icl.querybuilder.translator.MultipleFieldTranslator;
import com.centurylink.icl.querybuilder.translator.ValueTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.VariableTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.value.ConvertToUpperCase;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.ValidationRule;

public class PortVOService {
	
	private static final Log LOG = LogFactory.getLog(PortVOService.class);
	private static QueryBuilder queryBuilder;
	
	static {
		Map<String, VariableAndValueProcessor> variableAndValueProcessorMap = new HashMap<String, VariableAndValueProcessor>();
		
		variableAndValueProcessorMap.put("NAME", new VariableTranslatorOnly("PORT.NAME"));
		variableAndValueProcessorMap.put("SHELFNUMBER", new VariableTranslatorOnly("SHELF.SHELFNUMBER"));
		variableAndValueProcessorMap.put("SLOTNUMBER", new VariableTranslatorOnly("SLOT.SLOTNUMBER"));
		variableAndValueProcessorMap.put("PORTNUMBER", new MultipleFieldTranslator(Arrays.asList("EXT_PORT_PLUGGABLE.IF_NAME","EXT_PORT_TABLE.IF_NAME"),new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("TYPE", new VariableTranslatorOnly("PORTTYPE.NAME"));
		variableAndValueProcessorMap.put("DEVICENAME", new ValueTranslatorOnly("NODE.NAME", new ConvertToUpperCase()));
		
		Map<String, List<String>> directionMap = new HashMap<String, List<String>>();
		directionMap.put("NF", Arrays.asList("NF","UN"));
		directionMap.put("CF", Arrays.asList("CF","UN"));
		variableAndValueProcessorMap.put("DIRECTION", new MultipleFieldTranslator(Arrays.asList("EXT_PORT_PLUGGABLE.PORTFUNCTION", "EXT_PORT_TABLE.PORTFUNCTION","EXT_PORT_OFC.PORTFUNCTION") ,directionMap, new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("STATUS", new VariableTranslatorOnly("PROVISIONSTATUS.NAME"));
		variableAndValueProcessorMap.put("PORTID", new VariableTranslatorOnly("PORT.PORTID"));
		
		queryBuilder = new QueryBuilder(variableAndValueProcessorMap);
	}

	public PortVOService()
	{

	}
	
	public static QueryBuilder getQueryBuilder()
	{
		return queryBuilder;
	}
	
	public List<Port> getPorts(VOSearchHolder searchHolder) throws Exception {

		List<Port> ports = new ArrayList<Port>();
		
		if (!StringHelper.isEmpty(searchHolder.getObjectID()))
		{
			Port port = new Port(searchHolder.getObjectID());
			if (port.isInstanciated())
			{
				ports.add(port);
			} 
		} else if (!StringHelper.isEmpty(searchHolder.getCommonName()))
		{
			String query = "PORT.NAME = '"+searchHolder.getCommonName().toUpperCase()+"'";
			ports = Port.getPortListByQuery(query);
		} else if (searchHolder.getFilterCriteraList() != null && searchHolder.getFilterCriteraList().get("ENTITYFILTER") != null)
		{
			//TODO: MICKEY - Switch to using SearchHolder
			String query = queryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("ENTITYFILTER"));
			LOG.debug("Port Search Query: " + query);
			//TODO:Mickey - Is there a better way
			//Only want Physical Ports... 
			query += " AND PORT.PARENTPORT2PORT IS NULL ";
			ports = Port.getPortListByQuery(query);
		} else {
			throw new ICLRequestValidationException("No Search Criteria Found in Request");
		}
		
		if (ports.size() < 1)
		{
			throw new OSSDataNotFoundException();
		}
		
		
		return ports;
	}
	
}
