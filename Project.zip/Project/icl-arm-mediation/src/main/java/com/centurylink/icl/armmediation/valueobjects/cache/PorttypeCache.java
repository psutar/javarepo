package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Porttype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class PorttypeCache implements ValueObjectCache {
	
	private Map<String, Porttype> cachedObjects = new HashMap<String, Porttype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Porttype newPorttype = new Porttype(key);
			if (newPorttype.isInstanciated())
			{
				cachedObjects.put(key, newPorttype);
				return newPorttype;
			} else {
				return null;
			}
		}
	}

}
