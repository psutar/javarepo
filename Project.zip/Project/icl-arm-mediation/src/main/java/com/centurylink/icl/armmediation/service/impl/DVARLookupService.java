package com.centurylink.icl.armmediation.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.util.tracker.ServiceTracker;

import com.centurylink.icl.component.IConnector;
import com.centurylink.icl.component.ITransformationEngine;
import com.centurylink.icl.dvar.transformationengine.DvarTransformationEngine;
import com.centurylink.icl.exceptions.ICLException;

public class DVARLookupService {

private static final Log LOG = LogFactory.getLog(DVARLookupService.class);
	
	private ServiceTracker connectorTracker;
	private ServiceTracker engineTracker;
	private String userId;
	private String passWord;
    
    public DVARLookupService(BundleContext bundleContext) throws Exception
    {
		super();
		
		Filter filter = bundleContext.createFilter("(&(name=dvarTransformationEngine))");
		engineTracker = new ServiceTracker(bundleContext, filter, null);
		
		filter = bundleContext.createFilter("(&(name=dvarConnector))");
		connectorTracker = new ServiceTracker(bundleContext, filter, null);
		
		engineTracker.open();
		connectorTracker.open();
		LOG.info("tracker started");
    }
    
    public DVARLookupService (){}
    
    public void close()
    {
    	engineTracker.close();
    	connectorTracker.close();
    	LOG.info("tracker closed");
    }
    
    public Object callConnector(Object in) throws Exception 
    {
		LOG.info("DVAR callConnector");
		IConnector connector = (IConnector) connectorTracker.getService();

		if (null != connector) {
			return connector.call(in, null);
		} else {
			throw new ICLException("Connector not running");
		}
	}
    
    public Object callTransformFromSid(Object circuitid) throws Exception 
    {
    	LOG.info("callTransformFromSid");
    	DvarTransformationEngine engine = (DvarTransformationEngine) engineTracker.getService();
    	
    	HashMap<String ,Object> authtenticationDetail = new HashMap<String, Object>();
    	authtenticationDetail.put("userId", engine.getUserId());
    	authtenticationDetail.put("passWord", engine.getPassWord());

    	LOG.info("Authentication Details  : " + authtenticationDetail.get("userId") + authtenticationDetail.get("passWord"));
    	return engine.transformFromCim(circuitid, authtenticationDetail);

    }
    
    public Object callTransformToSid(Object response) throws Exception 
    {
    	LOG.info("callTransformToSid");
    	DvarTransformationEngine engine = (DvarTransformationEngine) engineTracker.getService();    	
    	return engine.transformToCim(response, null);

    }


}
