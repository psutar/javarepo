package com.centurylink.icl.armmediation.service;

import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;
import com.centurylink.icl.armmediation.armaccessobject.RouteToVlanSegment;

public interface TransportPathService
{
	public void insertRouteToVlanSegment(RouteToVlanSegment routeToVlanSegment);
	public String createRouteName(String nidClli, String npeClli);
	public void insertRoute(RouteHeader routeHeader);
	public void linkToTransportPath(String newFirstCircuitName, String newFirstCircuitAssetType, String existingFirstDeviceName, String existingSecondDeviceName);
}
