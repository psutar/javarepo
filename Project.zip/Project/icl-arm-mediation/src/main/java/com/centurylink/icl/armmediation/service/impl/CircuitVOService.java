package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.centurylink.icl.querybuilder.interfaces.VariableAndValueProcessor;
import com.centurylink.icl.querybuilder.translator.MultipleFieldTranslator;
import com.centurylink.icl.querybuilder.translator.ValueTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.VariableTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.value.ConvertToUpperCase;

public class CircuitVOService {
	
	private QueryBuilder queryBuilder;

	public CircuitVOService()
	{
		Map<String, VariableAndValueProcessor> variableAndValueProcessorMap = new HashMap<String, VariableAndValueProcessor>();
		variableAndValueProcessorMap.put("NAME", new ValueTranslatorOnly("UPPER(CIRCUIT.NAME)", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("STARTLOCATIONNAME", new ValueTranslatorOnly("UPPER(STARTLOCATION.NAME)", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("ENDLOCATIONNAME", new ValueTranslatorOnly("UPPER(ENDLOCATION.NAME)", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("TYPE", new VariableTranslatorOnly("CIRCUITTYPE.NAME"));
		
		variableAndValueProcessorMap.put("LOCATIONNAME", new MultipleFieldTranslator(Arrays.asList("STARTLOCATION.NAME","ENDLOCATION.NAME"), new ConvertToUpperCase()));

		queryBuilder = new QueryBuilder(variableAndValueProcessorMap);
		//queryBuilder.setVariableValueTranslatorMap(variableValueTranslationMap);
	}
	
	public List<Circuit> getCircuits(VOSearchHolder searchHolder) throws Exception {
		List<Circuit> circuits = new ArrayList<Circuit>();
		
		if (!StringHelper.isEmpty(searchHolder.getObjectID()))
		{
			Circuit circuit = new Circuit(searchHolder.getObjectID());
			if (circuit.isInstanciated())
			{
				circuits.add(circuit);
			} 
		} else if (!StringHelper.isEmpty(searchHolder.getCommonName()))
		{
			String query = null;
		
			if(searchHolder.getCommonName().startsWith("%") || searchHolder.getCommonName().endsWith("%")){
				query = "UPPER(CIRCUIT.NAME) LIKE '"+searchHolder.getCommonName().toUpperCase()+"'";
			}
			else{
				 query = "UPPER(CIRCUIT.NAME) = '"+searchHolder.getCommonName().toUpperCase()+"'";
			}
			circuits = Circuit.getCircuitListByQuery(query);
		} else if (searchHolder.getFilterCriteraList() != null && searchHolder.getFilterCriteraList().get("ENTITYFILTER") != null)
		{
			//TODO: MICKEY - Switch to using SearchHolder
			String query = queryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("ENTITYFILTER"));
			circuits = Circuit.getCircuitListByQuery(query);
		} else {
			throw new ICLRequestValidationException("No Search Criteria Found in Request");
		}
		
		if (circuits.size() < 1)
		{
			throw new OSSDataNotFoundException();
		}
		
		
		return circuits;
	}
	
}
