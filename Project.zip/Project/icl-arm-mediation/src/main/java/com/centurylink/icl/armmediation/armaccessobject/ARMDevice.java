package com.centurylink.icl.armmediation.armaccessobject;

public class ARMDevice extends ARMObject
{
	//Node
	private String commonName;
	private String objectID;
	private String fullName;
	private String description;
	private String sourceSystem;
	private String subType;
	private String subStatus;
	private String markedForDelete;
	private String softwareVersion;
	private String resourceType;
	private String characteristicName;
	private String characteristicValue;
	private String autoIdentifyNID;
	private String resourceSubType;
	
	//NODEDEF
	private String manufacturer;
	private String version;
	//EXT_DEVICE_TYPE
	private String clliCode;
	private String manufacturerPartNumber;
	private String manufactureDate;
	private String otherIdentifier;
	private int powerState;
	private String hecig;
	private String model;
	private String mco;
	private String vendorName;
	private String vendorPartNumber;
	private String hardwareVersion;
	private String firmwareVersion;
	private String serialNumber;
	private String chassisSerialNumber;
	private String usageState;
	private String snmpObjectId;
	private String revision;
	private String nmsType;
	private String nmsHostName;
	private String disContinueDate;
	private String disContinueReason;
	private String versionNumber;
	private String partType;
	private String macAddress;
	private String ipV4MgmRouterId;
	private String ipV4Console1;
	private String ipV4Console2;
	private String ipV6MgmRouterId;
	private String ipV6Console1;
	private String ipV6Console2;
	private String mgmtVlan;
	private String networkName;
	//Status
	private String prStatus;
	private String funcStatus;
	//NETWORKROLE
	private String role;
	private String roleId;
	//Location
	private String locationName;
	private String locationClli;
	//Subscriber
	private String customerName;
	private String customerFullName;
	private String customerId;
	private String ttServiceType;
	private String topologyName;
	private String topologyType;

	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	public String getObjectID()
	{
		return objectID;
	}
	public void setObjectID(String objectID)
	{
		this.objectID = objectID;
	}
	public String getFullName()
	{
		return fullName;
	}
	public void setFullName(String fullName)
	{
		this.fullName = fullName;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public String getSourceSystem()
	{
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}
	public String getSubType()
	{
		return subType;
	}
	public void setSubType(String subType)
	{
		this.subType = subType;
	}
	public String getSubStatus()
	{
		return subStatus;
	}
	public void setSubStatus(String subStatus)
	{
		this.subStatus = subStatus;
	}
	public String getMarkedForDelete()
	{
		return markedForDelete;
	}
	public void setMarkedForDelete(String markedForDelete)
	{
		this.markedForDelete = markedForDelete;
	}
	public String getSoftwareVersion()
	{
		return softwareVersion;
	}
	public void setSoftwareVersion(String softwareVersion)
	{
		this.softwareVersion = softwareVersion;
	}
	public String getResourceType()
	{
		return resourceType;
	}
	public void setResourceType(String resourceType)
	{
		this.resourceType = resourceType;
	}
	public String getResourceSubType() {
		return resourceSubType;
	}
	public void setResourceSubType(String resourceSubType) {
		this.resourceSubType = resourceSubType;
	}
	public String getCharacteristicName()
	{
		return characteristicName;
	}
	public void setCharacteristicName(String characteristicName)
	{
		this.characteristicName = characteristicName;
	}
	public String getCharacteristicValue()
	{
		return characteristicValue;
	}
	public void setCharacteristicValue(String characteristicValue)
	{
		this.characteristicValue = characteristicValue;
	}
	public String getManufacturer()
	{
		return manufacturer;
	}
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}
	public String getVersion()
	{
		return version;
	}
	public void setVersion(String version)
	{
		this.version = version;
	}
	public String getClliCode()
	{
		return clliCode;
	}
	public void setClliCode(String clliCode)
	{
		this.clliCode = clliCode;
	}
	public String getManufacturerPartNumber()
	{
		return manufacturerPartNumber;
	}
	public void setManufacturerPartNumber(String manufacturerPartNumber)
	{
		this.manufacturerPartNumber = manufacturerPartNumber;
	}
	public String getManufactureDate()
	{
		return manufactureDate;
	}
	public void setManufactureDate(String manufactureDate)
	{
		this.manufactureDate = manufactureDate;
	}
	public String getOtherIdentifier()
	{
		return otherIdentifier;
	}
	public void setOtherIdentifier(String otherIdentifier)
	{
		this.otherIdentifier = otherIdentifier;
	}
	public int getPowerState()
	{
		return powerState;
	}
	public void setPowerState(int powerState)
	{
		this.powerState = powerState;
	}
	public String getHecig()
	{
		return hecig;
	}
	public void setHecig(String hecig)
	{
		this.hecig = hecig;
	}
	public String getModel()
	{
		return model;
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public String getMco()
	{
		return mco;
	}
	public void setMco(String mco)
	{
		this.mco = mco;
	}
	public String getVendorName()
	{
		return vendorName;
	}
	public void setVendorName(String vendorName)
	{
		this.vendorName = vendorName;
	}
	public String getVendorPartNumber()
	{
		return vendorPartNumber;
	}
	public void setVendorPartNumber(String vendorPartNumber)
	{
		this.vendorPartNumber = vendorPartNumber;
	}
	public String getHardwareVersion()
	{
		return hardwareVersion;
	}
	public void setHardwareVersion(String hardwareVersion)
	{
		this.hardwareVersion = hardwareVersion;
	}
	public String getFirmwareVersion()
	{
		return firmwareVersion;
	}
	public void setFirmwareVersion(String firmwareVersion)
	{
		this.firmwareVersion = firmwareVersion;
	}
	public String getSerialNumber()
	{
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber)
	{
		this.serialNumber = serialNumber;
	}
	public String getChassisSerialNumber()
	{
		return chassisSerialNumber;
	}
	public void setChassisSerialNumber(String chassisSerialNumber)
	{
		this.chassisSerialNumber = chassisSerialNumber;
	}
	public String getUsageState()
	{
		return usageState;
	}
	public void setUsageState(String usageState)
	{
		this.usageState = usageState;
	}
	public String getSnmpObjectId()
	{
		return snmpObjectId;
	}
	public void setSnmpObjectId(String snmpObjectId)
	{
		this.snmpObjectId = snmpObjectId;
	}
	public String getRevision()
	{
		return revision;
	}
	public void setRevision(String revision)
	{
		this.revision = revision;
	}
	public String getNmsType()
	{
		return nmsType;
	}
	public void setNmsType(String nmsType)
	{
		this.nmsType = nmsType;
	}
	public String getNmsHostName()
	{
		return nmsHostName;
	}
	public void setNmsHostName(String nmsHostName)
	{
		this.nmsHostName = nmsHostName;
	}
	public String getDisContinueDate()
	{
		return disContinueDate;
	}
	public void setDisContinueDate(String disContinueDate)
	{
		this.disContinueDate = disContinueDate;
	}
	public String getDisContinueReason()
	{
		return disContinueReason;
	}
	public void setDisContinueReason(String disContinueReason)
	{
		this.disContinueReason = disContinueReason;
	}
	public String getVersionNumber()
	{
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber)
	{
		this.versionNumber = versionNumber;
	}
	public String getPartType()
	{
		return partType;
	}
	public void setPartType(String partType)
	{
		this.partType = partType;
	}
	public String getMacAddress()
	{
		return macAddress;
	}
	public void setMacAddress(String macAddress)
	{
		this.macAddress = macAddress;
	}
	public String getIpV4MgmRouterId()
	{
		return ipV4MgmRouterId;
	}
	public void setIpV4MgmRouterId(String ipV4MgmRouterId)
	{
		this.ipV4MgmRouterId = ipV4MgmRouterId;
	}
	public String getIpV4Console1()
	{
		return ipV4Console1;
	}
	public void setIpV4Console1(String ipV4Console1)
	{
		this.ipV4Console1 = ipV4Console1;
	}
	public String getIpV4Console2()
	{
		return ipV4Console2;
	}
	public void setIpV4Console2(String ipV4Console2)
	{
		this.ipV4Console2 = ipV4Console2;
	}
	public String getIpV6MgmRouterId()
	{
		return ipV6MgmRouterId;
	}
	public void setIpV6MgmRouterId(String ipV6MgmRouterId)
	{
		this.ipV6MgmRouterId = ipV6MgmRouterId;
	}
	public String getIpV6Console1()
	{
		return ipV6Console1;
	}
	public void setIpV6Console1(String ipV6Console1)
	{
		this.ipV6Console1 = ipV6Console1;
	}
	public String getIpV6Console2()
	{
		return ipV6Console2;
	}
	public void setIpV6Console2(String ipV6Console2)
	{
		this.ipV6Console2 = ipV6Console2;
	}
	public String getMgmtVlan()
	{
		return mgmtVlan;
	}
	public void setMgmtVlan(String mgmtVlan)
	{
		this.mgmtVlan = mgmtVlan;
	}
	public String getPrStatus()
	{
		return prStatus;
	}
	public void setPrStatus(String prStatus)
	{
		this.prStatus = prStatus;
	}
	public String getFuncStatus()
	{
		return funcStatus;
	}
	public void setFuncStatus(String funcStatus)
	{
		this.funcStatus = funcStatus;
	}
	public String getRole()
	{
		return role;
	}
	public void setRole(String role)
	{
		this.role = role;
	}
	public String getRoleId()
	{
		return roleId;
	}
	public void setRoleId(String roleId)
	{
		this.roleId = roleId;
	}
	public String getLocationName()
	{
		return locationName;
	}
	public void setLocationName(String locationName)
	{
		this.locationName = locationName;
	}
	public String getLocationClli()
	{
		return locationClli;
	}
	public void setLocationClli(String locationClli)
	{
		this.locationClli = locationClli;
	}
	public String getCustomerName()
	{
		return customerName;
	}
	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}
	public String getCustomerFullName()
	{
		return customerFullName;
	}
	public void setCustomerFullName(String customerFullName)
	{
		this.customerFullName = customerFullName;
	}
	public String getCustomerId()
	{
		return customerId;
	}
	public void setCustomerId(String customerId)
	{
		this.customerId = customerId;
	}
	public String getNetworkName() {
		return networkName;
	}
	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}
	public String getAutoIdentifyNID() {
		return autoIdentifyNID;
	}
	public void setAutoIdentifyNID(String autoIdentifyNID) {
		this.autoIdentifyNID = autoIdentifyNID;
	}
	public String getTtServiceType() {
		return ttServiceType;
	}
	public void setTtServiceType(String ttServiceType) {
		this.ttServiceType = ttServiceType;
	}
	public String getTopologyName() {
		return topologyName;
	}
	public void setTopologyName(String topologyName) {
		this.topologyName = topologyName;
	}
	public String getTopologyType() {
		return topologyType;
	}
	public void setTopologyType(String topologyType) {
		this.topologyType = topologyType;
	}
	
	
}
