package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;

import com.centurylink.icl.armmediation.dataaccess.CircuitCircuitDAO;

public class CircuitCircuitDAOImpl implements CircuitCircuitDAO
{
	private JdbcTemplate jdbcTemplate;
	
	private static final String QUERY_BY_USEDBY2CIRCUIT = "SELECT USES2CIRCUIT FROM CIRCUITCIRCUIT WHERE USEDBY2CIRCUIT=? ORDER BY SEQUENCE DESC";
	
	public CircuitCircuitDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public List<Long> getUnderlyingCircuits(Long circuitId)
	{
		final List<Long> circuitIdList = this.jdbcTemplate.query(QUERY_BY_USEDBY2CIRCUIT, new Object[] {circuitId}, new RowMapper<Long>()
		{
			public Long mapRow(ResultSet resultSet, int rowNum) throws SQLException
			{
				return resultSet.getLong("USES2CIRCUIT");
			}
		});
		return circuitIdList;
	}
}
