package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Nodedef;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class NodedefCache implements ValueObjectCache {
	
	private Map<String, Nodedef> cachedObjects = new HashMap<String, Nodedef>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Nodedef newNodedef = new Nodedef(key);
			if (newNodedef.isInstanciated())
			{
				cachedObjects.put(key, newNodedef);
				return newNodedef;
			} else {
				return null;
			}
		}
	}

}
