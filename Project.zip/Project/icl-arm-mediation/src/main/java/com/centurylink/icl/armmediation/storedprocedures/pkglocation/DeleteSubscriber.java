package com.centurylink.icl.armmediation.storedprocedures.pkglocation;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.service.impl.CreateServiceService;

public class DeleteSubscriber extends StoredProcedure
{

	//private static final Logger LOG = LoggerFactory.getLogger(DeleteSubscriber.class);
	private static final Log LOG = LogFactory.getLog(DeleteSubscriber.class);

	public DeleteSubscriber(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGSUBSCRIBER.DELETESUBSCRIBER");

		LOG.debug("ProcName: " + this.getSql());

		declareParameter(new SqlOutParameter("o_ErrorCode", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_ErrorText", Types.VARCHAR));
		declareParameter(new SqlParameter("i_SubscriberID", Types.NUMERIC));

		compile();
	}

	public Map<String, Object> execute(BigDecimal i_SubscriberID)
	{

		Map<String, Object> in = new HashMap<String, Object>();

		in.put("i_SubscriberID", i_SubscriberID);

		return super.execute(in);
	}
}
