package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.ResourceNotificationBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.ResourceNotification;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class EvcMemberNotificationService {
	private static final Log LOG = LogFactory.getLog(ServiceVOService.class);
	String uniServiceName=null;
	private String uniPhysicalPort=null;
	double bandwidth=0.0;
	Point2PointCircuitBuilder point2PointCircuit=new Point2PointCircuitBuilder();
	ConnectionTerminationPointBuilder ctp = new ConnectionTerminationPointBuilder();
	SearchResponseDetailsBuilder searchResponseDetails=new SearchResponseDetailsBuilder();
	ResourceRelationshipBuilder relationshipBuilder = new ResourceRelationshipBuilder();
	

	public SearchResponseDetails getEvcMemberNotification(String evcName,String uniName,String action) throws Exception
	{
		List<Service> services = new ArrayList<Service>();
		String query=null;
		if(StringHelper.isEmpty(evcName)||StringHelper.isEmpty(uniName))
			throw new OSSDataNotFoundException();


		query = "UPPER(SERVICE.NAME) = '"+evcName.toUpperCase()+"'";
		services = Service.getServiceListByQuery(query);

		uniServiceName=uniName;
		if(services.size()>0)
			return buildEVC(services.get(0),action);
		else
			throw new OSSDataNotFoundException();
	}

	private SearchResponseDetails buildEVC(Service service,String action) throws Exception
	{
		relationshipBuilder.buildResourceRelationship(null, null, null,null, null);
		point2PointCircuit.buildPoint2PointCircuit(service.getName(), service.getServiceid(), null, "ARM", "MEF EVC", null, null, null, null, null, null);
		relationshipBuilder.setCircuit(point2PointCircuit.getPoint2PointCircuit());
		ctp.buildConnectionTerminationPoint(null, null, null);
		ctp.addResourceRelationship(relationshipBuilder.getResourceRelationship());
		if (service.getAssociatedServices().size() > 0) {
			for (Service associatedService : service
					.getAssociatedServices()) {
				if(associatedService.getServiceExtension().getBw()!=null)
					bandwidth=bandwidth+Float.parseFloat(associatedService.getServiceExtension().getBw());
				if(uniServiceName!=null&&associatedService.getName().equalsIgnoreCase(uniServiceName)||
						(associatedService.getAlias1()!=null&&associatedService.getAlias1().equals(uniServiceName))||
						(associatedService.getAlias2()!=null&&associatedService.getAlias2().equals(uniServiceName)))
				{
					relationshipBuilder.buildResourceRelationship(null, null, null,null, null);
					point2PointCircuit.buildPoint2PointCircuit(associatedService.getName(), associatedService.getServiceid(), null, null, "MEF UNI", null, null, null, null, null, null);
					relationshipBuilder.setCircuit(point2PointCircuit.getPoint2PointCircuit());
					uniPhysicalPort=associatedService.getPort().getPortid();
					ctp.addResourceRelationship(relationshipBuilder.getResourceRelationship());
				}
			}
		}

		if(service.getAssociatedPorts().size()>0)
		{
			for(Port port:service.getAssociatedPorts())
			{ 
				Port vli2UniPort=new Port(port.getParentport2port());
				if(uniPhysicalPort!=null)
					if(vli2UniPort.getParentport2port().equalsIgnoreCase(uniPhysicalPort)){
						ctp.setCommonName(vli2UniPort.getName());
						ctp.setObjectID(vli2UniPort.getPortid());
						ctp.setSourceSystem("ARM");
						ctp.setResourceTypes("EVCMember", null);
						ctp.setlrStatus(vli2UniPort.getProvisionstatus().getName());
					}
			}
		}
		ctp.addResourceDescribedBy("Bandwidth", String.valueOf(bandwidth));
		if(action!=null&&!action.isEmpty())
			ctp.setAction(action);
		
		searchResponseDetails.buildSearchResponseDetails();
		searchResponseDetails.addTerminationPoint(ctp.getConnectionTerminationPoint());
		return searchResponseDetails.getSearchResponseDetails();

	}

}
