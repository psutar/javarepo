package com.centurylink.icl.armmediation.transformation;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager.IsDSLAMPathResolved;
import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.HostServiceAttribute;
import com.centurylink.icl.armmediation.valueobjects.objects.HostServiceAttributeObject;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Numberobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.armmediation.valueobjects.objects.TTServiceType;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.ResourceCharacteristicValueBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.IPAddress;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class HSIRouteVOTransformation 
{

	private static final Log LOG = LogFactory.getLog(HSIRouteVOTransformation.class);
	private IsDSLAMPathResolved isDSLAMPathResolved;

     public HSIRouteVOTransformation(IsDSLAMPathResolved isDSLAMPathResolved)
     {
       this.isDSLAMPathResolved = isDSLAMPathResolved;
     }
     
     public HSIRouteVOTransformation()
     {
       
     }
     public void setIsDSLAMPathResolved(IsDSLAMPathResolved isDSLAMPathResolved) {
    	this.isDSLAMPathResolved = isDSLAMPathResolved;
     }
     
	public SearchResourceResponseDocument transformToCIM(List<Service> services,HashMap<String, Object> map) throws Exception
	{

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		boolean datafound =false;

		if(services!=null && services.size()>0)
		{
			for(Service service:services)
			{
			searchResponseDetailsBuilder.addCircuit(buildCircuit(service,map));
			}
			datafound =true;
		}
		if(!datafound)
		{
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());

//		if (LOG.isInfoEnabled())
//		{
//			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
//		}
//		System.out.println(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	@SuppressWarnings("null")
	private SubNetworkConnection buildCircuit(Service service,HashMap<String, Object> map) throws Exception
	{
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		ResourceRelationshipBuilder resourceRelationshipBuilder=new ResourceRelationshipBuilder();
		ResourceRelationshipBuilder tempResourceRelationshipBuilder=new ResourceRelationshipBuilder();
		Point2PointCircuitBuilder point2PointCircuitBuilder=new Point2PointCircuitBuilder();
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder=new Point2PointCircuitBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		ResourceRelationshipBuilder tempResourceRelationshipBuilder2=new ResourceRelationshipBuilder();	
		ResourceRelationshipBuilder npeRouteResourceRelationshipBuilder=new ResourceRelationshipBuilder();
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder2=new Point2PointCircuitBuilder();
		Point2PointCircuitBuilder npeRoutepoint2PointCircuitBuilder=new Point2PointCircuitBuilder();
		String resourceType=null;
		String lrStatus=null;
		String functionalStatus=null;
		String numberType=null;
		//String IsDSLAM=null;
		
		if(service!=null && service.getServiceid()!=null)

		{
			if(service.getServicetype()!=null)
			{
				resourceType=service.getServicetype().getName();
			}
			if(service.getFunctionalstatus()!=null)
			{
				functionalStatus=service.getFunctionalstatus().getName();
			}
			 
			//TODO: MICKEY - This is actually done in a differnet place in the route so should really just update the map there, but it's not in an easy palce to do that at this time
			if (map.get("DeviceName") != null)
			{
				String actualDeviceName = determineActualDeviceName((String) map.get("DeviceName"));
				if (!StringHelper.isEmpty(actualDeviceName))
				{
					map.put("DeviceName", actualDeviceName);
				}
			}

			try {
					if(null!=service.getServiceExtension())
			{
					HashMap<String, Object> map1 = (HashMap<String, Object>) isDSLAMPathResolved.execute(map.get("DeviceName").toString(), service.getServiceExtension().getIpVersion(), service.getServiceExtension().getUsage(),	service.getServiceExtension().getProtocolType(), service.getName());
					
					LOG.info("*** Map size ***"+map1);
					if(map1 != null && map1.size() > 0){
						BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
						if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
						{
							final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
							if (LOG.isInfoEnabled())
							{
								LOG.info("******* Got Error From isDSLAMPathResolved API:  ******** "+o_Errormsg);
							}							
						}					
						BigDecimal isDSLAM = (BigDecimal) map1.get("O_ISVALID");
							
						if(isDSLAM!=null)
						{
							if (isDSLAM.intValue() == 0)
								lrStatus = "Restricted";
							else if(isDSLAM.intValue() == 1)
								lrStatus = "In-Service";
						}
					}
				}

			} catch (Exception e) {
				LOG.info("Error in getting LR Status for DSL OVC!!! "+ e.getMessage() );
			}
					
			subNetworkConnectionBuilder.buildSubNetworkConnection(service.getName(), service.getServiceid(), null, "ARM", resourceType, lrStatus, null, null, service.getAlias1(), service.getAlias2(), functionalStatus, service.getSubtype(), null, "UllCircuit");
			subNetworkConnectionBuilder.setDates(service.getCreateddate(), service.getLastmodifieddate());
			
			if(service.getServiceExtension()!=null)
			{
				if(service.getServiceExtension().getIpVersion()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("IPVersion", service.getServiceExtension().getIpVersion());

				if(service.getServiceExtension().getUsage()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("Usage", service.getServiceExtension().getUsage());

				if(service.getServiceExtension().getProtocolType()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("ProtocolType", service.getServiceExtension().getProtocolType());

				if(service.getServiceExtension().getProtocolType()!=null)
					subNetworkConnectionBuilder.addResourceDescribedBy("NetworkProtocol", service.getServiceExtension().getProtocolType());
			}
			if(map!=null && map.get("DeviceName")!=null)
			{
				subNetworkConnectionBuilder.addResourceDescribedBy("DSLAMName", map.get("DeviceName").toString());
			}

			if (service.getSubscriber() != null)
			{
				subNetworkConnectionBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber()));
			}
			if(service.getAssociatedServices()!=null && service.getAssociatedServices().size()>0)
			{

				
				for(Service hostService:service.getAssociatedServices())
				{
					if(hostService!= null && hostService.getServicetype() !=null  && hostService.getServicetype().getName().equalsIgnoreCase("Host Service"))
					{
						if(hostService.getProvisionstatus()!=null)
						{
							lrStatus=hostService.getProvisionstatus().getName();
						}
						if(hostService.getServicetype()!=null)
						{
							resourceType=hostService.getServicetype().getName();
						}

						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						point2PointCircuitBuilder.buildPoint2PointCircuit(null, null, null, "ARM", null, null, null, null, null,null,null,null,null,null,null,"Host Service List");			
						tempResourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);		
						temppoint2PointCircuitBuilder.buildPoint2PointCircuit(hostService.getName(), hostService.getServiceid(), null, "ARM", resourceType, lrStatus, null, null, null, null, null, null, null, hostService.getCreateddate(), hostService.getLastmodifieddate(), "HostService");

						if(hostService.getName()!=null)
						{
							temppoint2PointCircuitBuilder.addResourceDescribedBy("HostName", hostService.getName());
						}
						if(hostService.getServiceExtension() !=null && hostService.getServiceExtension().getFidName()!=null)
						{
							temppoint2PointCircuitBuilder.addResourceDescribedBy("HostFid", hostService.getServiceExtension().getFidName());
						}
						if (hostService.getSubscriber() != null)
						{						
							temppoint2PointCircuitBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(hostService.getSubscriber()));					
						}
						if(hostService.getPort() !=null && hostService.getPort().getPortid()!=null)
						{
							temppoint2PointCircuitBuilder.addZEndTps(SearchCircuitVOTransformation.buildConnectionTerminationPointFromPort(hostService.getPort(), null));

						}
						List<HostServiceAttributeObject> hostServiceAttributeObjectList=null;
						ResourceCharacteristicValueBuilder resourceCharacteristicValueBuilderServ=new ResourceCharacteristicValueBuilder();
						ResourceCharacteristicValueBuilder resourceCharacteristicValueBuilderIP=new ResourceCharacteristicValueBuilder();
						ResourceCharacteristicValueBuilder resourceCharacteristicValueBuilderNP=new ResourceCharacteristicValueBuilder();
						if(hostService != null && hostService.getServiceid() != null)
						{
							hostServiceAttributeObjectList=hostService.getHostServiceAttrObjectList(hostService.getServiceid());
							resourceCharacteristicValueBuilderServ.buildResourceCharacteristicValue("ServiceCapabilityType");
							resourceCharacteristicValueBuilderIP.buildResourceCharacteristicValue("SupportedIpVersion");
							resourceCharacteristicValueBuilderNP.buildResourceCharacteristicValue("NetworkProtocol");
							for(HostServiceAttributeObject hostSerObject:hostServiceAttributeObjectList){
							
								if(hostSerObject.getHstsrvcatrobject2hstsrvcatr() != null)
								{
									HostServiceAttribute hostServiceAttribute=hostSerObject.getHostServiceAttr(hostSerObject.getHstsrvcatrobject2hstsrvcatr());
									
									if(hostServiceAttribute != null && hostServiceAttribute.getHstsrvcatr2hstsrvcatrtype() != null)
									{
										if(hostServiceAttribute.getHstsrvcatr2hstsrvcatrtype().equalsIgnoreCase("1900000013"))
										{
											resourceCharacteristicValueBuilderServ.addResourceCharValueReferences(null, hostServiceAttribute.getName());
										}
										if(hostServiceAttribute.getHstsrvcatr2hstsrvcatrtype().equalsIgnoreCase("1900000014"))
										{
											resourceCharacteristicValueBuilderIP.addResourceCharValueReferences(null, hostServiceAttribute.getName());
										}
										if(hostServiceAttribute.getHstsrvcatr2hstsrvcatrtype().equalsIgnoreCase("1900000015"))
										{
											resourceCharacteristicValueBuilderNP.addResourceCharValueReferences(null, hostServiceAttribute.getName());
										}
										
									}
									
								}
							}
						}
						temppoint2PointCircuitBuilder.addResourceDescribedBy(resourceCharacteristicValueBuilderServ.getResourceCharacteristicValue());
						temppoint2PointCircuitBuilder.addResourceDescribedBy(resourceCharacteristicValueBuilderIP.getResourceCharacteristicValue());
						temppoint2PointCircuitBuilder.addResourceDescribedBy(resourceCharacteristicValueBuilderNP.getResourceCharacteristicValue());
						tempResourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
						point2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());
					}		
				}
				resourceRelationshipBuilder.setCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
				subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
			}
			if(service.getAssociatedCircuits()!=null && service.getAssociatedCircuits().size()>0)
			{

				for(Circuit ckt:service.getAssociatedCircuits())
				{
					if(ckt!=null && ckt.getCircuittype()!=null && ckt.getCircuittype().getName().equalsIgnoreCase("VLAN Segment") && map!=null && map.get("DeviceName")!=null && ckt.getStartNode() !=null && ckt.getEndNode() !=null && (ckt.getStartNode().getName().equalsIgnoreCase(map.get("DeviceName").toString())|| ckt.getEndNode().getName().equalsIgnoreCase(map.get("DeviceName").toString())))
					{
						//For NPE Route Main ResourceRelationship Tag
						npeRouteResourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						//npeRoutepoint2PointCircuitBuilder=new Point2PointCircuitBuilder();
						npeRoutepoint2PointCircuitBuilder.buildPoint2PointCircuit(null, null, null, "ARM", null, null, null, null, null,null,null,null,null,null,null,"NPE Route Details");

						tempResourceRelationshipBuilder.buildResourceRelationship(null, null, null);
						temppoint2PointCircuitBuilder.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, "ARM", ckt.getCircuittype().getName(), ckt.getProvisionstatus().getName(), null, null, ckt.getBandwidth(), null, ckt.getCircuitExtension().getCircuitservicetype(), null, null, ckt.getCreateddate(), ckt.getLastmodifieddate(), "DSLAMToNetworkCircuit");
						/*
						if(ckt.getStartPort()!=null && ckt.getStartPort().getNode()!=null && ckt.getStartPort().getNode().getNetworkroleobjects()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().size()>0  && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							if(ckt.getStartPort().getNumberObjectList()!=null && ckt.getStartPort().getNumberObjectList().size()>0 &&  ckt.getStartPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									temppoint2PointCircuitBuilder.addResourceDescribedBy("VLANNumber", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									temppoint2PointCircuitBuilder.addResourceDescribedBy("VLANNumber", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}
						else if(ckt.getEndPort()!=null && ckt.getEndPort().getNode()!=null && ckt.getEndPort().getNode().getNetworkroleobjects()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().size()>0  && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							if(ckt.getEndPort().getNumberObjectList()!=null && ckt.getEndPort().getNumberObjectList().size()>0 &&  ckt.getEndPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									temppoint2PointCircuitBuilder.addResourceDescribedBy("VLANNumber", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									temppoint2PointCircuitBuilder.addResourceDescribedBy("VLANNumber", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}
						*/
					
						
						if (ckt.getNumberObjectList() != null)
						{
							for(Numberobject no:ckt.getNumberObjectList())
							{
								String type = no.getDimnumber().getDimnumbertype().getName();
								if (type.equalsIgnoreCase("S-VLAN") || type.equalsIgnoreCase("CE-VLAN") || type.equalsIgnoreCase("VLAN"))
								{
									temppoint2PointCircuitBuilder.addResourceDescribedBy("VLANNumber", no.getDimnumber().getName());
									LOG.info("Adding VLAN - " + type + " " + no.getDimnumber().getName());
								}
							}
						}
						
						
						if(ckt.getStartNode()!=null && ckt.getStartNode().getNetworkroleobjects() !=null && ckt.getStartNode().getNetworkroleobjects().size()>0 && ckt.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null &&  ckt.getStartNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							//When A end is DSLAM
							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
							if(ckt.getStartPort()!=null && ckt.getStartPort().getTopLevelPort()!=null && ckt.getStartPort().getTopLevelPort().getTopLevelPort()!=null)
							{
								connectionTerminationPointBuilder.setObjectID(ckt.getStartPort().getTopLevelPort().getTopLevelPort().getPortid());
							}
							connectionTerminationPointBuilder.setAdditionalInfo("EgressPort");
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
							
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ckt.getStartPort().getTopLevelPort(),true,null));
							
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							temppoint2PointCircuitBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
							
							// When Z end is NPE

							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
							if(ckt.getEndPort()!=null && ckt.getEndPort().getTopLevelPort()!=null && ckt.getEndPort().getTopLevelPort().getTopLevelPort()!=null)
							{
								connectionTerminationPointBuilder.setObjectID(ckt.getEndPort().getTopLevelPort().getTopLevelPort().getPortid());
							}
							connectionTerminationPointBuilder.setAdditionalInfo("NetworkIngressPort");
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
							
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ckt.getEndPort().getTopLevelPort(),true,null));
							
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							temppoint2PointCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
							
						}
						else if(ckt.getEndNode()!=null && ckt.getEndNode().getNetworkroleobjects()!=null && ckt.getEndNode().getNetworkroleobjects().size()>0 && ckt.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole() !=null && ckt.getEndNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							//When Z end is DSLAM
							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
							if(ckt.getEndPort()!=null && ckt.getEndPort().getTopLevelPort()!=null && ckt.getEndPort().getTopLevelPort().getTopLevelPort()!=null)
							{
								connectionTerminationPointBuilder.setObjectID(ckt.getEndPort().getTopLevelPort().getTopLevelPort().getPortid());
							}
							connectionTerminationPointBuilder.setAdditionalInfo("EgressPort");
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
							
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ckt.getEndPort().getTopLevelPort(),true,null));
							
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							temppoint2PointCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
							
							// When A end is NPE
							connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
							if(ckt.getStartPort()!=null && ckt.getStartPort().getTopLevelPort()!=null && ckt.getStartPort().getTopLevelPort().getTopLevelPort()!=null)
							{
								connectionTerminationPointBuilder.setObjectID(ckt.getStartPort().getTopLevelPort().getTopLevelPort().getPortid());
							}
							connectionTerminationPointBuilder.setAdditionalInfo("NetworkIngressPort");
							logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
							
							logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ckt.getStartPort().getTopLevelPort(),true,null));
							
							connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							temppoint2PointCircuitBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
						}
						tempResourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
						npeRoutepoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());
										
						addEBCkts(ckt,resourceRelationshipBuilder,npeRoutepoint2PointCircuitBuilder);

						//npeRouteResourceRelationshipBuilder.setCircuit(npeRoutepoint2PointCircuitBuilder.getPoint2PointCircuit());


						/*if(ckt.getStartPort()!=null && ckt.getStartPort().getNode()!=null && ckt.getStartPort().getNode().getNetworkroleobjects()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().size()>0  && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							if(ckt.getStartPort().getNumberObjectList()!=null && ckt.getStartPort().getNumberObjectList().size()>0 &&  ckt.getStartPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									subNetworkConnectionBuilder.addResourceDescribedBy("SVLAN", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									subNetworkConnectionBuilder.addResourceDescribedBy("CEVLAN", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}
						else if(ckt.getEndPort()!=null && ckt.getEndPort().getNode()!=null && ckt.getEndPort().getNode().getNetworkroleobjects()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().size()>0  && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("DSLAM"))
						{
							if(ckt.getEndPort().getNumberObjectList()!=null && ckt.getEndPort().getNumberObjectList().size()>0 &&  ckt.getEndPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									subNetworkConnectionBuilder.addResourceDescribedBy("SVLAN", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									subNetworkConnectionBuilder.addResourceDescribedBy("CEVLAN", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}*/
						

						if (ckt.getNumberObjectList() != null)
						{
							for(Numberobject no:ckt.getNumberObjectList())
							{
								String type = no.getDimnumber().getDimnumbertype().getName();
								LOG.info("Adding VLAN - " + type + " " + no.getDimnumber().getName() + no.getDimnumber().getDimnumberExtension().getFunction());
								if (type.equalsIgnoreCase("VLAN"))
								{
									type = no.getDimnumber().getDimnumberExtension().getFunction();
								}
								String vlanType = null;
								if (type.equalsIgnoreCase("S-VLAN"))
								{
									vlanType = "SVLAN";
								} else if  (type.equalsIgnoreCase("CE-VLAN")) {
									vlanType = "CEVLAN";
								} else {
									vlanType = type;
								}
								
								subNetworkConnectionBuilder.addResourceDescribedBy(vlanType, no.getDimnumber().getName());
							}
						}

						//subNetworkConnectionBuilder.addResourceRelationship(npeRouteResourceRelationshipBuilder.getResourceRelationship());

					}
					//For EthernetAccessLinkDetails
					else if(ckt!=null &&  ckt.getCircuittype()!=null && ckt.getCircuittype().getName().equalsIgnoreCase("VLAN Segment") && map!=null && map.get("DeviceName").toString()!=null && ckt.getStartNode()!=null && ckt.getEndNode()!=null && ((!ckt.getStartNode().getName().equalsIgnoreCase(map.get("DeviceName").toString()))|| (!ckt.getEndNode().getName().equalsIgnoreCase(map.get("DeviceName").toString()))))
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						point2PointCircuitBuilder.buildPoint2PointCircuit(null, null, null, "ARM", null, null, null, null, null,null,null,null,null,null,null,"Ethernet Access Link Details");

						tempResourceRelationshipBuilder.buildResourceRelationship(null, null, null);
						temppoint2PointCircuitBuilder.buildPoint2PointCircuit(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "HostSummaryList");
						
						//Adding BRAS Circuit
						tempResourceRelationshipBuilder2.buildResourceRelationship(null, null, null);
						temppoint2PointCircuitBuilder2.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, "ARM", ckt.getCircuittype().getName(), ckt.getProvisionstatus().getName(), null, null, ckt.getBandwidth(), null, ckt.getCircuitExtension().getCircuitservicetype(), null, null, ckt.getCreateddate(), ckt.getLastmodifieddate(), "BrasCircuit");
						
						temppoint2PointCircuitBuilder2.addAEndTps(SearchCircuitVOTransformation.buildConnectionTerminationPointFromPort(ckt.getStartPort().getTopLevelPort(), null));
						temppoint2PointCircuitBuilder2.addZEndTps(SearchCircuitVOTransformation.buildConnectionTerminationPointFromPort(ckt.getEndPort().getTopLevelPort(), null));
						if(ckt.getStartPort()!=null && ckt.getStartPort().getNode()!=null && ckt.getStartPort().getNode().getNetworkroleobjects()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().size()>0  && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getStartPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))
						{
							if(ckt.getStartPort().getNumberObjectList()!=null && ckt.getStartPort().getNumberObjectList().size()>0 &&  ckt.getStartPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									temppoint2PointCircuitBuilder2.addResourceDescribedBy("VLANNumber", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									temppoint2PointCircuitBuilder2.addResourceDescribedBy("VLANNumber", ckt.getStartPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}
						else if(ckt.getEndPort()!=null && ckt.getEndPort().getNode()!=null && ckt.getEndPort().getNode().getNetworkroleobjects()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().size()>0  && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole()!=null && ckt.getEndPort().getNode().getNetworkroleobjects().get(0).getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))
						{
							if(ckt.getEndPort().getNumberObjectList()!=null && ckt.getEndPort().getNumberObjectList().size()>0 &&  ckt.getEndPort().getNumberObjectList().get(0).getDimnumber() !=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype()!=null && ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName()!=null)
							{
								if(ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName()!=null)
								{
									numberType=ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getDimnumbertype().getName();
								}
								if(numberType.equalsIgnoreCase("S-VLAN"))
								{
									temppoint2PointCircuitBuilder2.addResourceDescribedBy("VLANNumber", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
								else if(numberType.equalsIgnoreCase("CE-VLAN"))
								{
									temppoint2PointCircuitBuilder2.addResourceDescribedBy("VLANNumber", ckt.getEndPort().getNumberObjectList().get(0).getDimnumber().getName());
								}
							}
						}
						tempResourceRelationshipBuilder2.setCircuit(temppoint2PointCircuitBuilder2.getPoint2PointCircuit());
						temppoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder2.getResourceRelationship());

						//Adding Host Circuits
						addHostCircuits(ckt,tempResourceRelationshipBuilder,temppoint2PointCircuitBuilder);

						tempResourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
						point2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());		
						resourceRelationshipBuilder.setCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
						subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
					//Added For PW Circuit
					else if(ckt!=null && ckt.getCircuittype() !=null && ckt.getCircuittype().getName().equalsIgnoreCase("PW Unrouted (Path)"))
					{
						if(ckt.getProvisionstatus()!=null)
						{
							lrStatus=ckt.getProvisionstatus().getName();
						}
						if(ckt.getFunctionalstatus()!=null)
						{
							functionalStatus=ckt.getFunctionalstatus().getName();
						}
						if(ckt.getCircuittype()!=null)
						{
							resourceType=ckt.getCircuittype().getName();
						}
						//resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						//point2PointCircuitBuilder.buildPoint2PointCircuit(null, null, null, "ARM", null, null, null, null, null,null,null,null,null,null,null,"Network Circuit");

						tempResourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						temppoint2PointCircuitBuilder.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, "ARM",resourceType, lrStatus, null, null, null,functionalStatus,ckt.getCircuitExtension().getCircuitservicetype(),ckt.getAlias1(),ckt.getAlias2(),ckt.getCreateddate(),ckt.getLastmodifieddate(),"NetworkCircuit");

						if (ckt.getSubscriber() != null)
						{
							temppoint2PointCircuitBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(ckt.getSubscriber()));
						}
						
						connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
						connectionTerminationPointBuilder.setAdditionalInfo("NetworkIngressPort");
						logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
						logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(SearchNodeVOTransformation.buildDeviceFromPort(ckt.getEndPort().getTopLevelPort()));
						connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
						temppoint2PointCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
						
						temppoint2PointCircuitBuilder.addAEndTps(SearchCircuitVOTransformation.buildConnectionTerminationPointFromPort(ckt.getStartPort().getTopLevelPort(), null));
						
						tempResourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
					//	point2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());
						npeRoutepoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());
						//resourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
						npeRouteResourceRelationshipBuilder.setCircuit(npeRoutepoint2PointCircuitBuilder.getPoint2PointCircuit());
						//subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
						subNetworkConnectionBuilder.addResourceRelationship(npeRouteResourceRelationshipBuilder.getResourceRelationship());
					}
				}
			}
		}
		else 
		{
			throw new OSSDataNotFoundException();
		}
		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}



	private static void addHostCircuits(Circuit ckt,ResourceRelationshipBuilder tempResourceRelationshipBuilder,Point2PointCircuitBuilder temppoint2PointCircuitBuilder) throws Exception
	{
		ResourceRelationshipBuilder tempResourceRelationshipBuilder2=new ResourceRelationshipBuilder();
		ResourceRelationshipBuilder tempResourceRelationshipBuilder3=new ResourceRelationshipBuilder();	
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder2=new Point2PointCircuitBuilder();
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder3=new Point2PointCircuitBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		if(ckt.getAssociatedCircuits()!=null && ckt.getAssociatedCircuits().size()>0)
		{
			for(Circuit tpCKt:ckt.getAssociatedCircuits())
			{
				if(tpCKt!=null && tpCKt.getCircuittype() !=null && tpCKt.getCircuittype().getName().equalsIgnoreCase("Transport Path"))
				{
					if(tpCKt.getAssociatedCircuits()!=null && tpCKt.getAssociatedCircuits().size()>0)
					{
						for(Circuit ebCkt:tpCKt.getAssociatedCircuits())
						{
							if(ebCkt.getCircuittype() !=null && ebCkt.getCircuittype().getName().equalsIgnoreCase("Unrouted Ethernet Bearer"))
							{
								//ResourceRelationship for EB Circuit 
								tempResourceRelationshipBuilder2.buildResourceRelationship(null, null, null, null, null);		
								temppoint2PointCircuitBuilder2.buildPoint2PointCircuit(ebCkt.getName(), ebCkt.getCircuitid(), null, "ARM", ebCkt.getCircuittype().getName(),ebCkt.getProvisionstatus().getName() , null, null, ebCkt.getBandwidth(), null, ebCkt.getCircuitExtension().getCircuitservicetype(), null, null, ebCkt.getCreateddate(), ebCkt.getLastmodifieddate(), "HostCircuit");
								if (ebCkt.getSubscriber() != null)
								{								
									temppoint2PointCircuitBuilder2.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(ebCkt.getSubscriber()));								
								}
								//Adding Vlan Segment in EB Circuit 
								temppoint2PointCircuitBuilder3.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, null, ckt.getCircuittype().getName(), null, null, null, null);
								tempResourceRelationshipBuilder3.buildResourceRelationship(null, null, null, null, null);
								tempResourceRelationshipBuilder3.setCircuit(temppoint2PointCircuitBuilder3.getPoint2PointCircuit());

								temppoint2PointCircuitBuilder2.addResourceRelationship(tempResourceRelationshipBuilder3.getResourceRelationship());

								//Adding TP Circuit in EB Circuit
								temppoint2PointCircuitBuilder3.buildPoint2PointCircuit(tpCKt.getName(), tpCKt.getCircuitid(), null, null, tpCKt.getCircuittype().getName(), null, null, null, null);
								tempResourceRelationshipBuilder3.buildResourceRelationship(null, null, null, null, null);
								tempResourceRelationshipBuilder3.setCircuit(temppoint2PointCircuitBuilder3.getPoint2PointCircuit());

								temppoint2PointCircuitBuilder2.addResourceRelationship(tempResourceRelationshipBuilder3.getResourceRelationship());


								//When A end is BRAS
								connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
								
								if(ebCkt.getStartPort()!=null && ebCkt.getStartPort().getTopLevelPort()!=null)
								{
								connectionTerminationPointBuilder.setObjectID(ebCkt.getStartPort().getTopLevelPort().getPortid());
								}
								connectionTerminationPointBuilder.setAdditionalInfo("HostRouterPort");
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);						
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ebCkt.getStartPort().getTopLevelPort(),true,ckt.getStartPort()));
								connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
								connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ebCkt.getStartLocation()));
								temppoint2PointCircuitBuilder2.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());

								// When Z end is NPE
								connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
								
								if(ebCkt.getEndPort()!=null && ebCkt.getEndPort().getTopLevelPort()!=null)
								{
									connectionTerminationPointBuilder.setObjectID(ebCkt.getEndPort().getTopLevelPort().getPortid());
								}
								
								connectionTerminationPointBuilder.setAdditionalInfo("HostPort");
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ebCkt.getEndPort().getTopLevelPort(),true,ckt.getEndPort()));
								connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
								connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ebCkt.getEndLocation()));
								temppoint2PointCircuitBuilder2.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());


								tempResourceRelationshipBuilder2.setCircuit(temppoint2PointCircuitBuilder2.getPoint2PointCircuit());
								temppoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder2.getResourceRelationship());

							}
						}
					}
				}
			}

		}
	}

	private static void addEBCkts(Circuit ckt,ResourceRelationshipBuilder resourceRelationshipBuilder,Point2PointCircuitBuilder point2PointCircuitBuilder) throws Exception
	{
		ResourceRelationshipBuilder tempResourceRelationshipBuilder=new ResourceRelationshipBuilder();
		ResourceRelationshipBuilder tempResourceRelationshipBuilder2=new ResourceRelationshipBuilder();	
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder2=new Point2PointCircuitBuilder();
		Point2PointCircuitBuilder temppoint2PointCircuitBuilder=new Point2PointCircuitBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();

		if(ckt.getAssociatedCircuits()!=null && ckt.getAssociatedCircuits().size()>0)
		{
			for(Circuit tpCKt:ckt.getAssociatedCircuits())
			{
				if(tpCKt!=null && tpCKt.getCircuittype() !=null && tpCKt.getCircuittype().getName().equalsIgnoreCase("Transport Path"))
				{
					if(tpCKt.getAssociatedCircuits()!=null && tpCKt.getAssociatedCircuits().size()>0)
					{
						for(Circuit ebCkt:tpCKt.getAssociatedCircuits())
						{
							if(ebCkt.getCircuittype() !=null && ebCkt.getCircuittype().getName().equalsIgnoreCase("Unrouted Ethernet Bearer"))
							{
								//ResourceRelationship for EB Circuit 
								tempResourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);		
								temppoint2PointCircuitBuilder.buildPoint2PointCircuit(ebCkt.getName(), ebCkt.getCircuitid(), null, "ARM", ebCkt.getCircuittype().getName(),ebCkt.getProvisionstatus().getName() , null, null, ebCkt.getBandwidth(), null, ebCkt.getCircuitExtension().getCircuitservicetype(), null, null, ebCkt.getCreateddate(), ebCkt.getLastmodifieddate(), "SubtendedCircuit");
								if (ebCkt.getSubscriber() != null)
								{								
									temppoint2PointCircuitBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(ebCkt.getSubscriber()));								
								}
								//Adding Vlan Segment in EB Circuit 
								temppoint2PointCircuitBuilder2.buildPoint2PointCircuit(ckt.getName(), ckt.getCircuitid(), null, null, ckt.getCircuittype().getName(), null, null, null, null);
								tempResourceRelationshipBuilder2.buildResourceRelationship(null, null, null, null, null);
								tempResourceRelationshipBuilder2.setCircuit(temppoint2PointCircuitBuilder2.getPoint2PointCircuit());

								temppoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder2.getResourceRelationship());

								//Adding TP Circuit in EB Circuit
								temppoint2PointCircuitBuilder2.buildPoint2PointCircuit(tpCKt.getName(), tpCKt.getCircuitid(), null, null, tpCKt.getCircuittype().getName(), null, null, null, null);
								tempResourceRelationshipBuilder2.buildResourceRelationship(null, null, null, null, null);
								tempResourceRelationshipBuilder2.setCircuit(temppoint2PointCircuitBuilder2.getPoint2PointCircuit());

								temppoint2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder2.getResourceRelationship());


								connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
								connectionTerminationPointBuilder.setAdditionalInfo("SubtendedPort");
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ebCkt.getEndPort(),true ,ckt.getEndPort()));
								connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							    connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ebCkt.getEndLocation()));
								temppoint2PointCircuitBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());

								connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(buildDeviceFromPort(ebCkt.getStartPort(),true,ckt.getStartPort()));
								connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
								connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(ebCkt.getStartLocation()));
								temppoint2PointCircuitBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());


								tempResourceRelationshipBuilder.setCircuit(temppoint2PointCircuitBuilder.getPoint2PointCircuit());
								point2PointCircuitBuilder.addResourceRelationship(tempResourceRelationshipBuilder.getResourceRelationship());

							}
						}
					}
				}
			}

		}
	}

	private static PhysicalDevice buildDeviceFromPort(Port port, boolean includePort,Port vlanPort)
	{
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();


		Port topPort = port.getTopLevelPort();
		Node node = port.getNode();

		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node);


		if (!topPort.isOnCard())
		{
			if (includePort)
			{
				physicalDeviceBuilder.addHasPorts(transformPortToCIM(topPort,vlanPort));
				shelfBuilder.buildShelf(null, null, null);
				shelfBuilder.setRackInformation(node.getNodeExtension().getRelayrackid(), null);
				physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
}
		} else {
			if (topPort.getCard().getParentSlot().isOnCard())
			{
				Card cardCard = topPort.getCard();
				Slot cardSlot = cardCard.getParentSlot();
				Card card = cardSlot.getParentCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(shelf.getShelfExtension().getRelayrackid(), null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCard2cardtype(), null);
				cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
				embededCardBuilder.buildCard(cardCard.getName(), cardCard.getCardid(), cardCard.getCard2provisionstatus(), null, null, null, null, cardCard.getAlias1(), cardCard.getCard2cardtype(), null);
				if (includePort)
				{
					embededCardBuilder.addPhysicalPort(transformPortToCIM(topPort,vlanPort));
				}
				cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
				cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			} else {
				Card card = topPort.getCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(shelf.getShelfExtension().getRelayrackid(), null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCard2cardtype(), null);
				if (includePort)
				{
					cardBuilder.addPhysicalPort(transformPortToCIM(topPort,vlanPort));
				}
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			}
		}

		return physicalDeviceBuilder.getPhysicalDevice();
	}

	private static PhysicalDeviceBuilder buildBasicDevice(Node node)
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();


		physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), node.getDescription(), "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), node.getAlias1(), null, node.getNodeExtension().getParttype(), null, node.getNodeExtension().getVendorname(), node.getNodeDef().getName(), node.getNodeExtension().getMco(), node.getFunctionalstatus().getName());
		physicalDeviceBuilder.addDetails(null, null, node.getSoftwareversion(), node.getAlias2(), null, null, null, null, null, node.getNodeExtension().getVendorpartnumber(), null, null, null, null, null, null, null);

		if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4mgmrouterid()))
			physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4mgmrouterid(), "Mgm Router Id","4"));

		physicalDeviceBuilder.addResourceDescribedBy("Fullname", node.getFullname());
		physicalDeviceBuilder.addResourceDescribedBy("IsSharedOrDedicated", node.getNodeExtension().getSharedDedicated());
		physicalDeviceBuilder.addResourceDescribedBy("IsDiversed", node.getNodeExtension().getIsDiverse());
		physicalDeviceBuilder.addResourceDescribedBy("RAM", node.getStorageram());

		if (node.getSubscriber() != null)
		{
			ownsResourceDetailsBuilder.buildOwnsResourceDetails();
			customerBuilder.buildCustomer(node.getSubscriber().getName(), node.getSubscriber().getSubscriberid(), null, node.getSubscriber().getFullname(), null, null);
			ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
			physicalDeviceBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
		}


		if(node.getNetworkroleobjects() != null )
			for (Networkroleobject networkroleobject : node.getNetworkroleobjects()) {
				if(networkroleobject.getNetworkroleobject2networkrole()!= null){
					physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
					physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicaldevicerole());
				}
			}	
		if(node.getNodeExtension() != null && node.getNodeExtension().getRelayrackid()!= null){
			physicalDeviceBuilder.addResourceDescribedBy("RelayRackId", node.getNodeExtension().getRelayrackid());
		}

		return physicalDeviceBuilder;
	}

	private static PhysicalPort transformPortToCIM(Port port,Port vlanPort)
	{
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		ResourceRelationshipBuilder resourceRelationshipBuilder= new ResourceRelationshipBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder =new ConnectionTerminationPointBuilder();

		String networkPortName=null;
		if(port != null &&port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
			networkPortName=port.getPortExtension().getIfName();

		physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), null, port.getPortExtension().getDpea(), null, port.getPortExtension().getBandwidth(),null,port.getAlias1(), port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null,networkPortName);
		if(port.getNode() != null && port.getNode().getNodeExtension() != null)
			physicalPortBuilder.addResourceDescribedBy("ExceptionHandlingText", port.getNode().getNodeExtension().getExceptionHandlingInfo());
		if(port.getPorttype().getName().equalsIgnoreCase("Pluggable"))
		{
			physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());
		}else
		{
			physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum()); 
		}
		if(port.getNode() != null && port.getNode().getTTServiceTypeList()!= null){

			for (TTServiceType ttServiceType : port.getNode().getTTServiceTypeList()) {
				physicalPortBuilder.addResourceDescribedBy("TtServiceType", ttServiceType.getTtservicetype());
			}

		}
		if (port.getPort2porttype().equals("1900000003")) {
            if (port.getPortExtension().getBandwidth() != null
                         || port.getPortExtension().getFormfactor() != null) {
                  String transmissionRate="";
                  if(port.getPortExtension().getBandwidth() != null)
                         transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
                  if(port.getPortExtension().getFormfactor()!=null)
                         transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();
                  
                  if(!transmissionRate.isEmpty())
                  physicalPortBuilder
                                .addResourceDescribedBy(
                                              "TransmissionRate",
                                              transmissionRate);
		}
     } else if (port.getBandwidthObject() != null
                  &&port.getBandwidthObject()
                  .getBandwidthid()!=null && !StringHelper.isEmpty(port.getBandwidthObject()
                                .getBandwidthid())) {
            physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port
                         .getBandwidthObject().getBandwidthid());
     }



		physicalPortBuilder.addResourceDescribedBy("CreatedDate", port.getCreateddate());
		physicalPortBuilder.addResourceDescribedBy("CreatedUser", port.getCreatedby2dimuser());

		if(port.getPortExtension().getIfnum()!=null)
		{
			physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
		}

		String  reservation = port.getPortReservationByQuery(port.getPortid(), "4");
		physicalPortBuilder.addResourceDescribedBy("ReservationFlag", reservation);

		//Adding VLI Port Details 
		if(vlanPort!=null)
		{
			resourceRelationshipBuilder.buildResourceRelationship(null, null, null);
			connectionTerminationPointBuilder.buildConnectionTerminationPoint(vlanPort.getName(), null, vlanPort.getPorttype().getName(), "VLI Port");

			if(vlanPort.getTopLevelPort()!=null && vlanPort.getTopLevelPort().getTopLevelPort()!=null)
			{
				connectionTerminationPointBuilder.addResourceDescribedBy("PortNumber", vlanPort.getTopLevelPort().getTopLevelPort().getPortnumber());
			}
			resourceRelationshipBuilder.addTerminationPoint(connectionTerminationPointBuilder.getConnectionTerminationPoint());
			physicalPortBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
		}

		

		return physicalPortBuilder.getPhysicalPort();
	}


	private static IPAddress buildIPAddress(String address, String type, String version)
	{
		IPAddressBuilder ipAddressBuilder = new IPAddressBuilder();

		ipAddressBuilder.buildIPAddress(address, type, null, null, null, version);

		return ipAddressBuilder.getIPAddress();
	}
	
	private static String determineActualDeviceName(String deviceName)
	{
		String foundDeviceName = null;
		
		String query = " (NODE.NAME = UPPER('" + deviceName + "') OR NODE.ALIAS1 = UPPER('" + deviceName + "') OR NODE.ALIAS2 = UPPER('" + deviceName + "') OR EXT_DEVICE_TYPE.NETWORKNAME = UPPER('" + deviceName +"'))";
		List<Node> nodeList = Node.getNodeListByQuery(query);
		
		if (nodeList != null && nodeList.size() == 1)
		{
			foundDeviceName = nodeList.get(0).getName();
		}
		
		return foundDeviceName;
	}
}

