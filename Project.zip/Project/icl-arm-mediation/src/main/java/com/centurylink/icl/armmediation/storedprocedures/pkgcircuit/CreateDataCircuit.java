package com.centurylink.icl.armmediation.storedprocedures.pkgcircuit;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class CreateDataCircuit extends StoredProcedure
{
	private static final Log	LOG	= LogFactory.getLog(CreateDataCircuit.class);

	public CreateDataCircuit(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGCIRCUIT.CREATEDATACIRCUIT");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_circuitid", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_startlogportid", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_endlogportid", Types.NUMERIC));

		declareParameter(new SqlParameter("i_circuitname", Types.VARCHAR));
		declareParameter(new SqlParameter("i_circuittypeid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_startlocid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_endlocid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_startnodeid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_endnodeid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_startportid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_endportid", Types.NUMERIC));

		declareParameter(new SqlParameter("i_bandwidthid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_bandwidthKBPS", Types.NUMERIC));
		declareParameter(new SqlParameter("i_direction", Types.NUMERIC));
		declareParameter(new SqlParameter("i_isStartPortBearer", Types.NUMERIC));
		declareParameter(new SqlParameter("i_isEndPortBearer", Types.NUMERIC));

		compile();

	}

	public Map<String, Object> execute(String i_circuitname, BigDecimal i_circuittypeid, BigDecimal i_startlocid, BigDecimal i_endlocid, BigDecimal i_startnodeid, BigDecimal i_endnodeid,
			BigDecimal i_startportid, BigDecimal i_endportid, BigDecimal i_bandwidthid, BigDecimal i_bandwidthKBPS, BigDecimal i_direction, BigDecimal i_isStartPortBearer, BigDecimal i_isEndPortBearer)
	{
		final Map<String, Object> in = new HashMap<String, Object>();
		in.put("i_circuitname", i_circuitname);
		in.put("i_circuittypeid", i_circuittypeid);
		in.put("i_startlocid", i_startlocid);
		in.put("i_endlocid", i_endlocid);
		in.put("i_startnodeid", i_startnodeid);
		in.put("i_endnodeid", i_endnodeid);
		in.put("i_startportid", i_startportid);
		in.put("i_endportid", i_endportid);
		in.put("i_bandwidthid", i_bandwidthid);
		in.put("i_bandwidthKBPS", i_bandwidthKBPS);
		in.put("i_direction", i_direction);
		in.put("i_isStartPortBearer", i_isStartPortBearer);
		in.put("i_isEndPortBearer", i_isEndPortBearer);
		return super.execute(in);
	}

}
