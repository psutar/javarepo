package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.dataaccess.LookupDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchCircuitDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchServiceDAO;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.SQLBuilder;

import com.centurylink.icl.armmediation.service.MDWConstants;

import com.centurylink.icl.arm.domainlayer.circuits.Circuit;
import com.centurylink.icl.arm.domainlayer.circuits.CircuitFactory;

import com.centurylink.icl.arm.domainlayer.devices.Device;
import com.centurylink.icl.arm.domainlayer.devices.DeviceFactory;

import com.centurylink.icl.arm.domainlayer.service.Service;
import com.centurylink.icl.arm.domainlayer.service.ServiceFactory;

import com.centurylink.icl.arm.persistancelayer.ARMTransactionContext;
import com.centurylink.icl.arm.persistancelayer.ARMTransactionManager;

import com.centurylink.icl.iclaction.ICLActionRequestDocument;
import com.centurylink.icl.iclaction.Parameter;

import com.centurylink.icl.clc.routinggroup.util.CustomerSwapFailedMessage;

public class SubscriberSwapService
{
	private static final Log LOG = LogFactory.getLog(SubscriberSwapService.class);
	
	private SearchCircuitDAO searchCircuitDAO;
	private SearchDeviceDAO searchDeviceDAO;
	private SearchServiceDAO searchServiceDAO;
	private LookupDAO lookupDAO;
	
	public SubscriberSwapService(SearchCircuitDAO iSearchCircuitDAO, SearchDeviceDAO iSearchDeviceDAO, SearchServiceDAO iSearchServiceDAO, LookupDAO iLookupDAO)
	{
		this.searchCircuitDAO = iSearchCircuitDAO;
		this.searchDeviceDAO = iSearchDeviceDAO;
		this.searchServiceDAO = iSearchServiceDAO;
		this.lookupDAO = iLookupDAO;
	}

	public List<CustomerSwapFailedMessage> swapSubscriber(ICLActionRequestDocument iICLActionRequestDocument) throws Exception
	{
		ARMTransactionContext myARMTransactionContext = ARMTransactionManager.startTransaction("SubscriberSwap");
		
		List<CustomerSwapFailedMessage> swapErrors = new ArrayList<CustomerSwapFailedMessage>();
		
		List<Parameter> iICLActionRequestParameters = iICLActionRequestDocument.getICLActionRequest().getParameterList();
		
		String subscriberTo = null;
		String subscriberFrom = null;
		
		for (Parameter iICLActionRequestParameter : iICLActionRequestParameters)
		{
			if (iICLActionRequestParameter.getName().equalsIgnoreCase("ASSIGNED_CUSTOMER_ID_FROM") ||
				iICLActionRequestParameter.getName().equalsIgnoreCase("ACNA_FROM"))
			{
				subscriberFrom = iICLActionRequestParameter.getValue();
				LOG.info("From Subscriber = " + subscriberFrom);
			}
			else if (iICLActionRequestParameter.getName().equalsIgnoreCase("ASSIGNED_CUSTOMER_ID_TO") ||
					 iICLActionRequestParameter.getName().equalsIgnoreCase("ACNA_TO"))
			{
				subscriberTo = iICLActionRequestParameter.getValue();
				LOG.info("  To Subscriber = " + subscriberTo);
			}
		}
		
		final List<Long> circuitIds = this.searchCircuitDAO.getCircuitIdsBySubscriber(subscriberFrom);
		LOG.info("CircuitIds " + circuitIds.size());
		final List<Long> deviceIds = this.searchDeviceDAO.getDeviceIdsBySubscriber(subscriberFrom);
		LOG.info(" DeviceIds " + deviceIds.size());
		final List<Long> serviceIds = this.searchServiceDAO.getServiceIdsBySubscriber(subscriberFrom);
		LOG.info(" ServiceIds " + serviceIds.size());
		
		for (Long circuitId : circuitIds)
		{
			LOG.info("Updating circuitId " + circuitId);
			try
			{
				Circuit circuit = CircuitFactory.newCircuitInstance();
				circuit.properties().setCircuitId(circuitId);
//				LOG.info("Before set: " + circuit.properties().getRelativeName());
				circuit.properties().setRelativeName(subscriberTo);
//				LOG.info("After set: " + circuit.properties().getRelativeName());
				circuit.save();
			}
			catch (Exception e)
			{
				LOG.info("CircuitId update failed " + circuitId);
				LOG.info("Msg: " + e.getMessage());
				swapErrors.add(new CustomerSwapFailedMessage("UPDATE", "CIRCUIT", circuitId.toString(), "ARM", e.getMessage()));
			}
		}
		
		for (Long deviceId : deviceIds)
		{
			LOG.info(" Updating deviceId " + deviceId);
			try
			{
				Device device = DeviceFactory.newDevice();
				device.properties().setNodeId(deviceId);
//				LOG.info("Before set: " + device.properties().getRelativeName());
				device.properties().setRelativeName(subscriberTo);
//				LOG.info("After set: " + device.properties().getRelativeName());
				device.save();
			}
			catch (Exception e)
			{
				LOG.info(" DeviceId update failed " + deviceId);
				LOG.info("Msg: " + e.getMessage());
				swapErrors.add(new CustomerSwapFailedMessage("UPDATE", "DEVICE", deviceId.toString(), "ARM", e.getMessage()));
			}
		}
		
		final SQLBuilder sql = new SQLBuilder(Constants.SUBSCRIBER, Constants.SUR);

		sql.addFieldFromTable(Constants.SUR, Constants.SUBSCRIBER_ID);
		sql.addFieldFromTable(Constants.SUR, Constants.NAME);

		sql.eq(Constants.SUR, Constants.NAME, subscriberTo);

		final String query = sql.getStatement();
		
		LOG.info("Query = " + query);

		List<Map<String,Object>> subscriberMaps = this.lookupDAO.lookupSubscriber(query);
		Long subscriberId = -1l;
		for (Map<String,Object> subscriberMap : subscriberMaps)
		{
			if (subscriberMap.containsKey(MDWConstants.SUBSCRIBER_ID))
			{
				subscriberId = Long.parseLong((String)subscriberMap.get(MDWConstants.SUBSCRIBER_ID));
				break;
			}
		}
		
		LOG.info("SubscriberId = " + subscriberId);
		
		if (!subscriberId.equals(-1l))
		{
			for (Long serviceId : serviceIds)
			{
				LOG.info(" Updating ServiceId " + serviceId);
				try
				{
					Service service = ServiceFactory.newService();
					service.properties().setServiceId(serviceId);
//					LOG.info("Before Set: " + service.properties().getService2subscriber());
					service.properties().setService2subscriber(subscriberId);
//					LOG.info("After Set: " + service.properties().getService2subscriber());
					service.assignSubscriber();
					service.save();
				}
				catch (Exception e)
				{
					LOG.info(" ServiceId update failed " + serviceId);
					LOG.info("Msg: " + e.getMessage());
					swapErrors.add(new CustomerSwapFailedMessage("UPDATE", "SERVICE", serviceId.toString(), "ARM", e.getMessage()));
				}
			}
		}
		
		for (CustomerSwapFailedMessage swapError : swapErrors)
		{
			swapError.setFromCustomerId(subscriberFrom);
			swapError.setToCustomerId(subscriberTo);
			LOG.info("SwapError " + swapError.toString());
		}

		myARMTransactionContext.commit();
		
		return swapErrors;
	}
}
