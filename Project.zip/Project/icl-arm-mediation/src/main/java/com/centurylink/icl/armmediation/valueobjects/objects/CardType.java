package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.service.impl.SearchSlotCardCompatibilityVOService;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class CardType extends AbstractReadOnlyTable

{
	private static final Log LOG = LogFactory.getLog(CardType.class);
	private static final String TABLENAME = "TABLENAME";
	private static final String NAME = "NAME";
	private static final String CARDTYPEID = "CARDTYPEID";
	
	public CardType()
	{
		super();
		this.tableName = "CARDTYPE";
	}

	public CardType(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	@Override
	public void populateModel()
	{
		
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(CARDTYPEID, new Field(CARDTYPEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CARDTYPEID));
	}
	
	public static List<CardType> getCardTypeListByQuery(String query)
	{
		CardType cardType = new CardType();
		List<CardType> cardTypeList = new ArrayList<CardType>();
		List<Map<String,Object>> foundCardTypeList = cardType.getFullRecordsByQuery(query);

		for (Map<String,Object> cardTypeMap : foundCardTypeList)
		{
			CardType workcardType = new CardType();
			workcardType.instanciated = true;
			workcardType.populateFields(cardTypeMap);
			cardTypeList.add(workcardType);
		}

		return cardTypeList;
	}
	
	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}
	
	
	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setCardtypeid(String cardtypeid)
	{
		setField(CARDTYPEID,cardtypeid);
	}

	public String getCardtypeid()
	{
		return getFieldAsString(CARDTYPEID);
	}
}
