package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;

public interface RouteDetailDAO {

	public void insert(RouteDetail routeDetail);

	public boolean validateRouteAsset(String assetType, String assetValue);
	
	public List<RouteDetail> lookupRouteDetailByFirstCircuitName(String firstCircuitName);

	public List<RouteDetail> lookupRouteDetailByRouteHeaderId(Long routeHeaderId);

	public int deleteAll(Long routeHeaderId);

	public RouteDetail getNPEForRoute(Long routeHeaderId, String npeValue);
}
