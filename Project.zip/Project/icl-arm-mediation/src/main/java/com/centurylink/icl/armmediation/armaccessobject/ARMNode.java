package com.centurylink.icl.armmediation.armaccessobject;

public class ARMNode
{
	private String commonName;
	private Long   nodeId;
	private String aliasName;
	private String aliasName2;
	private String relativeName;
	private String resourceType;
	private String resourceSubType;
	private String clliCode;
	private String sharedOrDedicated;
	private String diversed;
	private String serialNumber;
	private String additionalInfo;
	private String snmpObjectId;
	private String chasisSerialNo;
	private String softwareVersion;
	private String firmwareVersion;
	private String hardwareVersion;
	private String nmsType;
	private String nmsHostName;
	private String manufacturer;
	private String vendorPartNo;
	private String vendorName;
	private String macAddress;
	private String mgmtVlan;
	private String ipV4MgmRouterId;
	private String ipV4Console1;
	private String ipV4Console2;
	private String ipV6MgmRouterId;
	private String ipV6Console1;
	private String ipv6Console2;
	private String provisionStatus;
	private String locationClli;
	private String NetworkName;
	private String description;
	private String functionalStatus;
	private String autoIdentifyNID;
	private String restrictedNotes;
	
	private String nwkNodeNumber;
	private String maxSubscriberBWOffered;
	private String prismNosaCert;
	private String oneGbpsIndicator;
	private String stackRingSeqNum;
	private String stackRingShelfId;
	private String aerialORBuried;
	private String maxDownStreamRate;
	private String maxUpStreamRate;
	private String fiberINRange;
	private String fiberOUTRange;
	private String splitterGrpNum;
	private String splitterGrpName;
	private String splitterStartPortNumber;
	private String installDate;
	private String inDoor;
	private String selfORTechInstall;
	private String rontaId;
	private String powerSupply;
	private String optiTap;
	private String sapCode;
	private String restrictedStatus;
	private String relayRackId;
	private String revision;
	private String networkRoleObject2NetworkRole;
	
	public String getNetworkRoleObject2NetworkRole() {
    return networkRoleObject2NetworkRole;
  }

  public void setNetworkRoleObject2NetworkRole(String networkRoleObject2NetworkRole) {
    this.networkRoleObject2NetworkRole = networkRoleObject2NetworkRole;
  }
	public String getRevision() {
    return revision;
  }

  public void setRevision(String revision) {
    this.revision = revision;
  }
	public String getRelayRackId() {
    return relayRackId;
  }

  public void setRelayRackId(String relayRackId) {
    this.relayRackId = relayRackId;
  }
	
	public String getNwkNodeNumber() {
    return nwkNodeNumber;
  }

  public void setNwkNodeNumber(String nwkNodeNumber) {
    this.nwkNodeNumber = nwkNodeNumber;
  }

  public String getMaxSubscriberBWOffered() {
    return maxSubscriberBWOffered;
  }

  public void setMaxSubscriberBWOffered(String maxSubscriberBWOffered) {
    this.maxSubscriberBWOffered = maxSubscriberBWOffered;
  }

  public String getPrismNosaCert() {
    return prismNosaCert;
  }

  public void setPrismNosaCert(String prismNosaCert) {
    this.prismNosaCert = prismNosaCert;
  }

  public String getOneGbpsIndicator() {
    return oneGbpsIndicator;
  }

  public void setOneGbpsIndicator(String oneGbpsIndicator) {
    this.oneGbpsIndicator = oneGbpsIndicator;
  }

  public String getStackRingSeqNum() {
    return stackRingSeqNum;
  }

  public void setStackRingSeqNum(String stackRingSeqNum) {
    this.stackRingSeqNum = stackRingSeqNum;
  }

  public String getStackRingShelfId() {
    return stackRingShelfId;
  }

  public void setStackRingShelfId(String stackRingShelfId) {
    this.stackRingShelfId = stackRingShelfId;
  }

  public String getAerialORBuried() {
    return aerialORBuried;
  }

  public void setAerialORBuried(String aerialORBuried) {
    this.aerialORBuried = aerialORBuried;
  }

  public String getMaxDownStreamRate() {
	return maxDownStreamRate;
  }

  public void setMaxDownStreamRate(String maxDownStreamRate) {
	this.maxDownStreamRate = maxDownStreamRate;
  }
	
  public String getMaxUpStreamRate() {
	return maxUpStreamRate;
  }
	
  public void setMaxUpStreamRate(String maxUpStreamRate) {
	this.maxUpStreamRate = maxUpStreamRate;
  }

  public String getFiberINRange() {
    return fiberINRange;
  }

  public void setFiberINRange(String fiberINRange) {
    this.fiberINRange = fiberINRange;
  }

  public String getFiberOUTRange() {
    return fiberOUTRange;
  }

  public void setFiberOUTRange(String fiberOUTRange) {
    this.fiberOUTRange = fiberOUTRange;
  }

  public String getSplitterGrpNum() {
    return splitterGrpNum;
  }

  public void setSplitterGrpNum(String splitterGrpNum) {
    this.splitterGrpNum = splitterGrpNum;
  }

  public String getSplitterGrpName() {
    return splitterGrpName;
  }

  public void setSplitterGrpName(String splitterGrpName) {
    this.splitterGrpName = splitterGrpName;
  }

  public String getSplitterStartPortNumber() {
    return splitterStartPortNumber;
  }

  public void setSplitterStartPortNumber(String splitterStartPortNumber) {
    this.splitterStartPortNumber = splitterStartPortNumber;
  }

  public String getInstallDate() {
    return installDate;
  }

  public void setInstallDate(String installDate) {
    this.installDate = installDate;
  }

  public String getInDoor() {
    return inDoor;
  }

  public void setInDoor(String inDoor) {
    this.inDoor = inDoor;
  }

  public String getSelfORTechInstall() {
    return selfORTechInstall;
  }

  public void setSelfORTechInstall(String selfORTechInstall) {
    this.selfORTechInstall = selfORTechInstall;
  }

  public String getRontaId() {
    return rontaId;
  }

  public void setRontaId(String rontaId) {
    this.rontaId = rontaId;
  }

  public String getPowerSupply() {
    return powerSupply;
  }

  public void setPowerSupply(String powerSupply) {
    this.powerSupply = powerSupply;
  }

  public String getOptiTap() {
    return optiTap;
  }

  public void setOptiTap(String optiTap) {
    this.optiTap = optiTap;
  }

  public String getSapCode() {
    return sapCode;
  }

  public void setSapCode(String sapCode) {
    this.sapCode = sapCode;
  }

  public String getRestrictedStatus() {
    return restrictedStatus;
  }

  public void setRestrictedStatus(String restrictedStatus) {
    this.restrictedStatus = restrictedStatus;
  }
	
	
	public String getRestrictedNotes() {
		return restrictedNotes;
	}
	public void setRestrictedNotes(String restrictedNotes) {
		this.restrictedNotes = restrictedNotes;
	}
	public String getNetworkName() {
		return NetworkName;
	}
	public void setNetworkName(String networkName) {
		NetworkName = networkName;
	}
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	public Long getNodeId()
	{
		return nodeId;
	}
	public void setNodeId(Long nodeId)
	{
		this.nodeId = nodeId;
	}
	public String getAliasName()
	{
		return aliasName;
	}
	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}
	public String getAliasName2()
	{
		return aliasName2;
	}
	public void setAliasName2(String aliasName2)
	{
		this.aliasName2 = aliasName2;
	}
	public String getRelativeName()
	{
		return relativeName;
	}
	public void setRelativeName(String relativeName)
	{
		this.relativeName = relativeName;
	}
	public String getResourceType()
	{
		return resourceType;
	}
	public void setResourceType(String resourceType)
	{
		this.resourceType = resourceType;
	}
	public String getResourceSubType()
	{
		return resourceSubType;
	}
	public void setResourceSubType(String resourceSubType)
	{
		this.resourceSubType = resourceSubType;
	}
	public String getClliCode()
	{
		return clliCode;
	}
	public void setClliCode(String clliCode)
	{
		this.clliCode = clliCode;
	}
	public String getSharedOrDedicated()
	{
		return sharedOrDedicated;
	}
	public void setSharedOrDedicated(String sharedOrDedicated)
	{
		this.sharedOrDedicated = sharedOrDedicated;
	}
	public String getDiversed()
	{
		return diversed;
	}
	public void setDiversed(String diversed)
	{
		this.diversed = diversed;
	}
	public String getSerialNumber()
	{
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber)
	{
		this.serialNumber = serialNumber;
	}
	public String getAdditionalInfo()
	{
		return additionalInfo;
	}
	public void setAdditionalInfo(String additionalInfo)
	{
		this.additionalInfo = additionalInfo;
	}
	public String getSnmpObjectId()
	{
		return snmpObjectId;
	}
	public void setSnmpObjectId(String snmpObjectId)
	{
		this.snmpObjectId = snmpObjectId;
	}
	public String getChasisSerialNo()
	{
		return chasisSerialNo;
	}
	public void setChasisSerialNo(String chasisSerialNo)
	{
		this.chasisSerialNo = chasisSerialNo;
	}
	public String getSoftwareVersion()
	{
		return softwareVersion;
	}
	public void setSoftwareVersion(String softwareVersion)
	{
		this.softwareVersion = softwareVersion;
	}
	public String getFirmwareVersion()
	{
		return firmwareVersion;
	}
	public void setFirmwareVersion(String firmwareVersion)
	{
		this.firmwareVersion = firmwareVersion;
	}
	public String getHardwareVersion()
	{
		return hardwareVersion;
	}
	public void setHardwareVersion(String hardwareVersion)
	{
		this.hardwareVersion = hardwareVersion;
	}
	public String getNmsType()
	{
		return nmsType;
	}
	public void setNmsType(String nmsType)
	{
		this.nmsType = nmsType;
	}
	public String getNmsHostName()
	{
		return nmsHostName;
	}
	public void setNmsHostName(String nmsHostName)
	{
		this.nmsHostName = nmsHostName;
	}
	public String getManufacturer()
	{
		return manufacturer;
	}
	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}
	public String getVendorPartNo()
	{
		return vendorPartNo;
	}
	public void setVendorPartNo(String vendorPartNo)
	{
		this.vendorPartNo = vendorPartNo;
	}
	public String getVendorName()
	{
		return vendorName;
	}
	public void setVendorName(String vendorName)
	{
		this.vendorName = vendorName;
	}
	public String getMacAddress()
	{
		return macAddress;
	}
	public void setMacAddress(String macAddress)
	{
		this.macAddress = macAddress;
	}
	public String getMgmtVlan()
	{
		return mgmtVlan;
	}
	public void setMgmtVlan(String mgmtVlan)
	{
		this.mgmtVlan = mgmtVlan;
	}
	public String getIpV4MgmRouterId()
	{
		return ipV4MgmRouterId;
	}
	public void setIpV4MgmRouterId(String ipV4MgmRouterId)
	{
		this.ipV4MgmRouterId = ipV4MgmRouterId;
	}
	public String getIpV4Console1()
	{
		return ipV4Console1;
	}
	public void setIpV4Console1(String ipV4Console1)
	{
		this.ipV4Console1 = ipV4Console1;
	}
	public String getIpV4Console2()
	{
		return ipV4Console2;
	}
	public void setIpV4Console2(String ipV4Console2)
	{
		this.ipV4Console2 = ipV4Console2;
	}
	public String getIpV6MgmRouterId()
	{
		return ipV6MgmRouterId;
	}
	public void setIpV6MgmRouterId(String ipV6MgmRouterId)
	{
		this.ipV6MgmRouterId = ipV6MgmRouterId;
	}
	public String getIpV6Console1()
	{
		return ipV6Console1;
	}
	public void setIpV6Console1(String ipV6Console1)
	{
		this.ipV6Console1 = ipV6Console1;
	}
	public String getIpv6Console2()
	{
		return ipv6Console2;
	}
	public void setIpv6Console2(String ipv6Console2)
	{
		this.ipv6Console2 = ipv6Console2;
	}
	public String getProvisionStatus()
	{
		return provisionStatus;
	}
	public void setProvisionStatus(String provisionStatus)
	{
		this.provisionStatus = provisionStatus;
	}
	public String getLocationClli()
	{
		return locationClli;
	}
	public void setLocationClli(String locationClli)
	{
		this.locationClli = locationClli;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFunctionalStatus() {
		return functionalStatus;
	}
	public void setFunctionalStatus(String functionalStatus) {
		this.functionalStatus = functionalStatus;
	}
	public String getAutoIdentifyNID() {
		return autoIdentifyNID;
	}
	public void setAutoIdentifyNID(String autoIdentifyNID) {
		this.autoIdentifyNID = autoIdentifyNID;
	}	

}
