package com.centurylink.icl.armmediation.service.impl;

import com.centurylink.icl.armmediation.armaccessobject.ARMEvent;
import com.centurylink.icl.armmediation.dataaccess.EventsDAO;
import com.centurylink.icl.armmediation.transformation.ARMEventToICLEventNotification;
import com.centurylink.icl.iclnotification.EventNotification;

public class GetNextEventService {
	
	private EventsDAO eventsDAO;
	private ARMEventToICLEventNotification armEventToICLEventNotification;
	
	public GetNextEventService(ARMEventToICLEventNotification armEventToICLEventNotification, EventsDAO eventsDAO)
	{
		this.armEventToICLEventNotification = armEventToICLEventNotification;
		this.eventsDAO = eventsDAO;
	}
	
	public EventNotification processEvent()
	{
		ARMEvent event = eventsDAO.getNextEvent();
		
		if (event != null)
		{
			eventsDAO.deleteEvent(event);
			return armEventToICLEventNotification.transformARMEventToEventNotification(event);
		} else {
			return null;
		}
	}
	
}
