package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Circuit extends AbstractReadOnlyTable {

	private static final Log LOG = LogFactory.getLog(Circuit.class);
	
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String CIRCUIT2RPBUILDTEMPLATE = "CIRCUIT2RPBUILDTEMPLATE";
	private static final String BANDWIDTH = "BANDWIDTH";
	private static final String CIRCUIT2PROTECTIONTYPE = "CIRCUIT2PROTECTIONTYPE";
	private static final String PROTECTIONSTATUS = "PROTECTIONSTATUS";
	private static final String CIRCUIT2RESOLUTIONSTATUS = "CIRCUIT2RESOLUTIONSTATUS";
	private static final String ISENDPORTAUTODELETED = "ISENDPORTAUTODELETED";
	private static final String ISSTARTPORTAUTODELETED = "ISSTARTPORTAUTODELETED";
	private static final String ISENDPORTBEARER = "ISENDPORTBEARER";
	private static final String ISSTARTPORTBEARER = "ISSTARTPORTBEARER";
	private static final String CIRCUIT2ENDNODE = "CIRCUIT2ENDNODE";
	private static final String CIRCUIT2STARTNODE = "CIRCUIT2STARTNODE";
	private static final String CIRCUIT2FUNCTIONALSTATUS = "CIRCUIT2FUNCTIONALSTATUS";
	private static final String CIRCUIT2BANDWIDTH = "CIRCUIT2BANDWIDTH";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String CIRCUIT2PROVISIONSTATUS = "CIRCUIT2PROVISIONSTATUS";
	private static final String CIRCUIT2ENDLOCATION = "CIRCUIT2ENDLOCATION";
	private static final String CIRCUIT2STARTLOCATION = "CIRCUIT2STARTLOCATION";
	private static final String CIRCUIT2ENDPORT = "CIRCUIT2ENDPORT";
	private static final String CIRCUIT2STARTPORT = "CIRCUIT2STARTPORT";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String NOTES = "NOTES";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String CIRCUIT2CIRCUITDEF = "CIRCUIT2CIRCUITDEF";
	private static final String CIRCUIT2CIRCUITTYPE = "CIRCUIT2CIRCUITTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String OBJECTID = "OBJECTID";
	private static final String ALIAS2 = "ALIAS2";
	private static final String ALIAS1 = "ALIAS1";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String NAME = "NAME";
	private static final String CIRCUITID = "CIRCUITID";
	private static final String CIRCUIT = "Circuit";
	
	private Location startLocation = null;
	private Location endLocation = null;
	private Node startNode = null;
	private Node endNode = null;
	private Circuittype circuittype = null;
	private CircuitExtension circuitExtension = null;
	
	private Port startPort = null;
	private Port endPort = null;
	private Provisionstatus provisionstatus = null;
	private Functionalstatus functionalstatus = null;
	private Subscriber subscriber = null;
	
	private List<Service> associatedServices = null;
	private List<Circuit> associatedCircuits = null;
	private List<TTServiceType> ttserviceTypeList=null;
	private List<Numberobject> numberobjectList = null;

	public Circuit()
	{
		super();
		this.tableName = CIRCUIT;
	}

	public Circuit(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		if(!StringHelper.isEmpty(this.getCircuit2circuittype()))
			this.instanciated = true;
	}

	public static List<Circuit> getCircuitListByQuery(String query)
	{
		Circuit circuit = new Circuit();
		List<Circuit> circuitList = new ArrayList<Circuit>();
		List<Map<String,Object>> foundCircuitList = circuit.getRecordsByQuery(query);

		for (Map<String,Object> circuitMap : foundCircuitList)
		{
			Circuit workCircuit = new Circuit(circuitMap.get(CIRCUITID).toString());
			circuitList.add(workCircuit);
		}
		return circuitList;
	}
	
	public static List<Circuit> getCircuitListByQuery(String query,boolean lookup)
	{
		Circuit circuit = new Circuit();
		List<Circuit> circuitList = new ArrayList<Circuit>();
		List<Map<String,Object>> foundCircuitList = circuit.getRecordsByQuery(query,lookup);

		for (Map<String,Object> circuitMap : foundCircuitList)
		{
			Circuit workCircuit = new Circuit(circuitMap.get(CIRCUITID).toString());
			circuitList.add(workCircuit);
		}
		return circuitList;
	}
	protected List<Map<String,Object>> getRecordsByQuery(String query,boolean lookup)
	{
		String statement = "SELECT distinct(" + this.tableName +"." + this.primaryKey.getName() + ") FROM " + this.tableName;
		//add only ext. tables,don't add other child tables when portfilter is false.
		if(lookup)
		{	
			linkedTables.clear();
			linkedTables.add(new LinkedTable("CIRCUIT", "CIRCUITTYPE", CIRCUIT2CIRCUITTYPE, "CIRCUITTYPEID", false));
			linkedTables.add(new LinkedTable("CIRCUIT", "PORT","PORTA",CIRCUIT2STARTPORT, "PORTID", false));
			linkedTables.add(new LinkedTable("CIRCUIT", "PORT","PORTZ",CIRCUIT2ENDPORT, "PORTID", false));
			
		}
			
			for (LinkedTable linkedTable:linkedTables)
			{
				statement += ", " + linkedTable.getChildTableName();
				
			}
			
			statement += " WHERE 1=1 ";
	
			for (LinkedTable linkedTable:linkedTables)
			{
				statement += " AND " + linkedTable.getWhereClause() + " ";
			}
				
		statement += "AND " + query;
		
		LOG.debug("AbstractTable.getRecordsByQuery - statement: " + statement);
		LOG.info("AbstractTable.getRecordsByQuery - statement: " + statement);
		
		
		List<Map<String,Object>> records = valueObjectDataAccessUtil.getRecordsAsList(statement);
		return records;
	}
	@Override
	public void populateModel()
	{
		fields.put(CIRCUIT2PROVISIONSTATUS, new Field(CIRCUIT2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2FUNCTIONALSTATUS, new Field(CIRCUIT2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));

		fields.put(CIRCUIT2CIRCUITTYPE, new Field(CIRCUIT2CIRCUITTYPE, Field.TYPE_NUMERIC));

		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2RPBUILDTEMPLATE, new Field(CIRCUIT2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(BANDWIDTH, new Field(BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2PROTECTIONTYPE, new Field(CIRCUIT2PROTECTIONTYPE, Field.TYPE_NUMERIC));
		fields.put(PROTECTIONSTATUS, new Field(PROTECTIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2RESOLUTIONSTATUS, new Field(CIRCUIT2RESOLUTIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(ISENDPORTAUTODELETED, new Field(ISENDPORTAUTODELETED, Field.TYPE_NUMERIC));
		fields.put(ISSTARTPORTAUTODELETED, new Field(ISSTARTPORTAUTODELETED, Field.TYPE_NUMERIC));
		fields.put(ISENDPORTBEARER, new Field(ISENDPORTBEARER, Field.TYPE_NUMERIC));
		fields.put(ISSTARTPORTBEARER, new Field(ISSTARTPORTBEARER, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2ENDNODE, new Field(CIRCUIT2ENDNODE, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2STARTNODE, new Field(CIRCUIT2STARTNODE, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2BANDWIDTH, new Field(CIRCUIT2BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2ENDLOCATION, new Field(CIRCUIT2ENDLOCATION, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2STARTLOCATION, new Field(CIRCUIT2STARTLOCATION, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2ENDPORT, new Field(CIRCUIT2ENDPORT, Field.TYPE_NUMERIC));
		fields.put(CIRCUIT2STARTPORT, new Field(CIRCUIT2STARTPORT, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CIRCUIT2CIRCUITDEF, new Field(CIRCUIT2CIRCUITDEF, Field.TYPE_NUMERIC));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(CIRCUITID, new Field(CIRCUITID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CIRCUITID));

		linkedTables.add(new LinkedTable("CIRCUIT", "CIRCUITTYPE", CIRCUIT2CIRCUITTYPE, "CIRCUITTYPEID", false));
		linkedTables.add(new LinkedTable("CIRCUIT", "LOCATION", "STARTLOCATION", CIRCUIT2STARTLOCATION, "LOCATIONID", false));
		linkedTables.add(new LinkedTable("CIRCUIT", "LOCATION", "ENDLOCATION", CIRCUIT2ENDLOCATION, "LOCATIONID", false));
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setCircuit2rpbuildtemplate(String circuit2rpbuildtemplate)
	{
		setField(CIRCUIT2RPBUILDTEMPLATE,circuit2rpbuildtemplate);
	}

	public String getCircuit2rpbuildtemplate()
	{
		return getFieldAsString(CIRCUIT2RPBUILDTEMPLATE);
	}

	public void setBandwidth(String bandwidth)
	{
		setField(BANDWIDTH,bandwidth);
	}

	public String getBandwidth()
	{
		return getFieldAsString(BANDWIDTH);
	}

	public void setCircuit2protectiontype(String circuit2protectiontype)
	{
		setField(CIRCUIT2PROTECTIONTYPE,circuit2protectiontype);
	}

	public String getCircuit2protectiontype()
	{
		return getFieldAsString(CIRCUIT2PROTECTIONTYPE);
	}

	public void setProtectionstatus(String protectionstatus)
	{
		setField(PROTECTIONSTATUS,protectionstatus);
	}

	public String getProtectionstatus()
	{
		return getFieldAsString(PROTECTIONSTATUS);
	}

	public void setCircuit2resolutionstatus(String circuit2resolutionstatus)
	{
		setField(CIRCUIT2RESOLUTIONSTATUS,circuit2resolutionstatus);
	}

	public String getCircuit2resolutionstatus()
	{
		return getFieldAsString(CIRCUIT2RESOLUTIONSTATUS);
	}

	public void setIsendportautodeleted(String isendportautodeleted)
	{
		setField(ISENDPORTAUTODELETED,isendportautodeleted);
	}

	public String getIsendportautodeleted()
	{
		return getFieldAsString(ISENDPORTAUTODELETED);
	}

	public void setIsstartportautodeleted(String isstartportautodeleted)
	{
		setField(ISSTARTPORTAUTODELETED,isstartportautodeleted);
	}

	public String getIsstartportautodeleted()
	{
		return getFieldAsString(ISSTARTPORTAUTODELETED);
	}

	public void setIsendportbearer(String isendportbearer)
	{
		setField(ISENDPORTBEARER,isendportbearer);
	}

	public String getIsendportbearer()
	{
		return getFieldAsString(ISENDPORTBEARER);
	}

	public void setIsstartportbearer(String isstartportbearer)
	{
		setField(ISSTARTPORTBEARER,isstartportbearer);
	}

	public String getIsstartportbearer()
	{
		return getFieldAsString(ISSTARTPORTBEARER);
	}

	public void setCircuit2endnode(String circuit2endnode)
	{
		setField(CIRCUIT2ENDNODE,circuit2endnode);
	}

	public String getCircuit2endnode()
	{
		return getFieldAsString(CIRCUIT2ENDNODE);
	}

	public void setCircuit2startnode(String circuit2startnode)
	{
		setField(CIRCUIT2STARTNODE,circuit2startnode);
	}

	public String getCircuit2startnode()
	{
		return getFieldAsString(CIRCUIT2STARTNODE);
	}

	public void setCircuit2functionalstatus(String circuit2functionalstatus)
	{
		setField(CIRCUIT2FUNCTIONALSTATUS,circuit2functionalstatus);
	}

	public String getCircuit2functionalstatus()
	{
		return getFieldAsString(CIRCUIT2FUNCTIONALSTATUS);
	}

	public void setCircuit2bandwidth(String circuit2bandwidth)
	{
		setField(CIRCUIT2BANDWIDTH,circuit2bandwidth);
	}

	public String getCircuit2bandwidth()
	{
		return getFieldAsString(CIRCUIT2BANDWIDTH);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setCircuit2provisionstatus(String circuit2provisionstatus)
	{
		setField(CIRCUIT2PROVISIONSTATUS,circuit2provisionstatus);
	}

	public String getCircuit2provisionstatus()
	{
		return getFieldAsString(CIRCUIT2PROVISIONSTATUS);
	}

	public void setCircuit2endlocation(String circuit2endlocation)
	{
		setField(CIRCUIT2ENDLOCATION,circuit2endlocation);
	}

	public String getCircuit2endlocation()
	{
		return getFieldAsString(CIRCUIT2ENDLOCATION);
	}

	public void setCircuit2startlocation(String circuit2startlocation)
	{
		setField(CIRCUIT2STARTLOCATION,circuit2startlocation);
	}

	public String getCircuit2startlocation()
	{
		return getFieldAsString(CIRCUIT2STARTLOCATION);
	}

	public void setCircuit2endport(String circuit2endport)
	{
		setField(CIRCUIT2ENDPORT,circuit2endport);
	}

	public String getCircuit2endport()
	{
		return getFieldAsString(CIRCUIT2ENDPORT);
	}

	public void setCircuit2startport(String circuit2startport)
	{
		setField(CIRCUIT2STARTPORT,circuit2startport);
	}

	public String getCircuit2startport()
	{
		return getFieldAsString(CIRCUIT2STARTPORT);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setCircuit2circuitdef(String circuit2circuitdef)
	{
		setField(CIRCUIT2CIRCUITDEF,circuit2circuitdef);
	}

	public String getCircuit2circuitdef()
	{
		return getFieldAsString(CIRCUIT2CIRCUITDEF);
	}

	public void setCircuit2circuittype(String circuit2circuittype)
	{
		setField(CIRCUIT2CIRCUITTYPE,circuit2circuittype);
	}

	public String getCircuit2circuittype()
	{
		return getFieldAsString(CIRCUIT2CIRCUITTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setCircuitid(String circuitid)
	{
		setField(CIRCUITID,circuitid);
	}

	public String getCircuitid()
	{
		return getFieldAsString(CIRCUITID);
	}

	public Location getStartLocation()
	{
		if (startLocation == null)
		{
			startLocation = new Location(getField(CIRCUIT2STARTLOCATION).toString());
		}
		
		return startLocation;
	}

	public Location getEndLocation()
	{
		if (endLocation == null)
		{
			endLocation = new Location(getField(CIRCUIT2ENDLOCATION).toString());
		}
		
		return endLocation;
	}

	public Node getStartNode()
	{
		if (startNode == null)
		{
			startNode = new Node(getField(CIRCUIT2STARTNODE).toString());
		}
		
		return startNode;
	}

	public Node getEndNode()
	{
		if (endNode == null)
		{
			endNode = new Node(getField(CIRCUIT2ENDNODE).toString());
		}
		
		return endNode;
	}
	
	public Port getStartPort()
	{
		if (startPort == null)
		{
			startPort = new Port(this.getCircuit2startport());
		}
		
		return startPort;
	}

	public Port getEndPort()
	{
		if (endPort == null)
		{
			endPort = new Port(this.getCircuit2endport());
		}
		
		return endPort;
	}

	public Circuittype getCircuittype()
	{
		if (circuittype == null)
		{
			circuittype = (Circuittype) ValueObjectCacheAccessorFactory.getValueObjectCache("circuittype").getCacheObject(getField(CIRCUIT2CIRCUITTYPE).toString());
		}
		
		return circuittype;
	}

	public CircuitExtension getCircuitExtension()
	{
		if (circuitExtension == null)
		{
			circuitExtension = new CircuitExtension(fields.get(CIRCUITID), getCircuittype().getTablename());
		}
		
		return circuitExtension;
	}

	public Provisionstatus getProvisionstatus()
	{
		if (provisionstatus == null)
		{
			provisionstatus = (Provisionstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("provisionstatus").getCacheObject(this.getCircuit2provisionstatus());
		}
		
		return provisionstatus;
	}

	public Functionalstatus getFunctionalstatus()
	{
		if (functionalstatus == null)
		{
			functionalstatus = (Functionalstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("functionalstatus").getCacheObject(this.getCircuit2functionalstatus());

			if (functionalstatus == null)
			{
				functionalstatus = new Functionalstatus();
			}
		}
		
		return functionalstatus;
	}
	
	public Subscriber getSubscriber()
	{
		if (this.subscriber == null)
		{
			if(this.getRelativename()!=null)
			{
				List<Subscriber> subscriberList = Subscriber.getSubscriberListByQuery("NAME = '" + this.getRelativename() + "'");
				if(subscriberList.size()>0 && subscriberList != null)
					subscriber = subscriberList.get(0);
			}
		}
		
		return subscriber;
	}
	
	public List<Service> getAssociatedServices()
	{
		if (associatedServices == null)
		{
			associatedServices = new ArrayList<Service>();
			List<Serviceobject> serviceobjectList = Serviceobject.getServiceobjectListByObjectIdandDimObjectandRelationship(this.getCircuitid(), "3", null);
			for (Serviceobject serviceObject:serviceobjectList)
			{
				associatedServices.add(new Service(serviceObject.getServiceobject2service()));
			}
		}
		
		return associatedServices;
	}
	
	public List<Circuit> getAssociatedCircuits()
	{
		if (associatedCircuits == null)
		{
			associatedCircuits = new ArrayList<Circuit>();
			for (Circuitcircuit circuitcircuit:Circuitcircuit.getCircuitcircuitListByUses(this.getCircuitid()))
			{
				associatedCircuits.add(circuitcircuit.getUsedByCircuit());
			}
			for (Circuitcircuit circuitcircuit:Circuitcircuit.getCircuitcircuitListByUsedBy(this.getCircuitid()))
			{
				associatedCircuits.add(circuitcircuit.getUsesCircuit());
			}
		}
		
		return associatedCircuits;
	}
	
	public List<TTServiceType> getTTServiceTypeList()
	{
		if (ttserviceTypeList == null)
		{
			String query = "ARM_OBJECT_ID = " +this.getCircuit2circuittype() + " AND ARM_OBJECT_TYPE='Circuit'";
			
			LOG.info("TTServiceType"+query);
			
			ttserviceTypeList = TTServiceType.getTTServiceTypeListByQuery(query);
		}
		
		return ttserviceTypeList;
	}
	public List<Numberobject> getNumberObjectList()
	{
		if (numberobjectList == null)
		{
			numberobjectList = Numberobject.getNumberobjectListByObjectIdandDimObjectandRelationship(getCircuitid(), "3", null);
		}
		
		return numberobjectList;
	}
	
	public List<Map<String,Object>> getcircuitIdListByQuery(String query,boolean lookup)
    {
           String statement = "SELECT distinct(" + this.tableName +"." + this.primaryKey.getName() + ") FROM " + this.tableName;
           //add only ext. tables,don't add other child tables when portfilter is false.
           if(lookup)
           {      
                  linkedTables.clear();
                  linkedTables.add(new LinkedTable("CIRCUIT", "SERVICEOBJECT", CIRCUIT2STARTPORT, "SERVICEOBJECT2OBJECT", false));
                  linkedTables.add(new LinkedTable("SERVICEOBJECT", "SERVICE","SERVICEOBJECT2SERVICE","SERVICEID", false));                              
                  
           }
                  
                  for (LinkedTable linkedTable:linkedTables)
                  {
                        statement += ", " + linkedTable.getChildTableName();
                        
                  }
                  
                  statement += " WHERE 1=1 ";
    
                  for (LinkedTable linkedTable:linkedTables)
                  {
                        statement += " AND " + linkedTable.getWhereClause() + " ";
                  }
                        
           statement += "AND " + query;
           
           LOG.debug("AbstractTable.getRecordsByQuery - statement: " + statement);
           LOG.info("AbstractTable.getRecordsByQuery - statement: " + statement);
           
           
           List<Map<String,Object>> records = valueObjectDataAccessUtil.getRecordsAsList(statement);
           return records;
    }

	
}