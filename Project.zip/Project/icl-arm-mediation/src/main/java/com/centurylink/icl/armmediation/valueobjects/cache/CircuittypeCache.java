package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Circuittype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class CircuittypeCache implements ValueObjectCache {
	
	private Map<String, Circuittype> cachedObjects = new HashMap<String, Circuittype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Circuittype newCircuittype = new Circuittype(key);
			if (newCircuittype.isInstanciated())
			{
				cachedObjects.put(key, newCircuittype);
				return newCircuittype;
			} else {
				return null;
			}
		}
	}

}
