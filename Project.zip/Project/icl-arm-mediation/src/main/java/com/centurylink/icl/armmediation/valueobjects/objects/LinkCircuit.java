package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class LinkCircuit extends AbstractReadOnlyTable {

	private static final Log LOG = LogFactory.getLog(LinkCircuit.class);

	private static final String LINKCIRCUIT2CIRCUIT = "LINKCIRCUIT2CIRCUIT";
	private static final String LINKCIRCUIT2LINK = "LINKCIRCUIT2LINK";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String ROUTESEQUENCE = "ROUTESEQUENCE";
	private static final String TURNED = "TURNED";
	private static final String RPPLANID = "RPPLANID";
	private static final String LINKCIRCUIT = "LinkCircuit";

	public LinkCircuit() {
		super();
		this.tableName = LINKCIRCUIT;
	}

	public LinkCircuit(String key) {
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		if (!StringHelper.isEmpty(this.getLinkcircuit2circuit()))
			this.instanciated = true;
	}

	public void populateModel() {
		fields.put(LINKCIRCUIT2CIRCUIT, new Field(LINKCIRCUIT2CIRCUIT,
				Field.TYPE_NUMERIC));
		fields.put(LINKCIRCUIT2LINK, new Field(LINKCIRCUIT2LINK,
				Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(ROUTESEQUENCE, new Field(ROUTESEQUENCE, Field.TYPE_NUMERIC));
		fields.put(TURNED, new Field(TURNED, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(LINKCIRCUIT2CIRCUIT));

		linkedTables.add(new LinkedTable("LINKCIRCUIT", "LINK",
				"LINKCIRCUIT2LINK", "LINKID", false));
	}

	public void setLinkcircuit2circuit(String linkcircuit2circuit) {
		setField(LINKCIRCUIT2CIRCUIT, linkcircuit2circuit);
	}

	public String getLinkcircuit2circuit() {
		return getFieldAsString(LINKCIRCUIT2CIRCUIT);
	}

	public void setLinkcircuit2link(String linkcircuit2link) {
		setField(LINKCIRCUIT2LINK, linkcircuit2link);
	}

	public String getLinkcircuit2link() {
		return getFieldAsString(LINKCIRCUIT2LINK);
	}

	public void setRpplanid(String rpplanid) {
		setField(RPPLANID, rpplanid);
	}

	public String getRpplanid() {
		return getFieldAsString(RPPLANID);
	}

	public void setSequence(String sequence) {
		setField(SEQUENCE, sequence);
	}

	public String getSequence() {
		return getFieldAsString(SEQUENCE);
	}

	public void setRouteSequence(String routesequence) {
		setField(ROUTESEQUENCE, routesequence);
	}

	public String getRouteSequence() {
		return getFieldAsString(ROUTESEQUENCE);
	}

	public void setTurned(String turned) {
		setField(TURNED, turned);
	}

	public String getTurned() {
		return getFieldAsString(TURNED);
	}

	public static List<LinkCircuit> getLinkcircuitListByLinkCircuit2Link(
			String linkId) {
		LinkCircuit template = new LinkCircuit();
		template.setLinkcircuit2link(linkId);
		return getCircuitcircuitList(template);
	}

	public static List<LinkCircuit> getCircuitcircuitList(LinkCircuit template) {
		List<LinkCircuit> response = new ArrayList<LinkCircuit>();

		List<Map<String, Object>> records = template.getRecordsByTemplate();
		for (Map<String, Object> map : records) {
			LinkCircuit cc = new LinkCircuit();
			cc.instanciated = true;
			cc.populateFields(map);
			response.add(cc);
		}

		return response;
	}

	public static String getLinkCircuit2LinkByCircuitid(String circuitid) {

		String query = " LINKCIRCUIT.LINKCIRCUIT2CIRCUIT=" + circuitid;
		return getLinkCircuit2LinkByQuery(query);

	}

	public static String getLinkCircuit2LinkByQuery(String query) {
		LinkCircuit linkCircuit = new LinkCircuit();
		List<LinkCircuit> linkCircuitList = new ArrayList<LinkCircuit>();
		List<Map<String, Object>> foundlinkCircuitList = linkCircuit
				.getRecordsByQuery(query);
		String circuit2Link = null;

		for (Map<String, Object> linkCircuitMap : foundlinkCircuitList) {
			LinkCircuit workLinkCircuit = new LinkCircuit(linkCircuitMap.get(
					LINKCIRCUIT2CIRCUIT).toString());
			linkCircuitList.add(workLinkCircuit);
			circuit2Link = workLinkCircuit.getLinkcircuit2link();
		}
		return circuit2Link;
	}

}
