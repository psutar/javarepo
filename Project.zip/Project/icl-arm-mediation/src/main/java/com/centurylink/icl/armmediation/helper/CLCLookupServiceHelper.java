package com.centurylink.icl.armmediation.helper;

import com.centurylink.icl.armmediation.service.impl.CLCLookupService;

/*
 * This class allow access to the CLCLookupService from a static context
 */
public class CLCLookupServiceHelper {
	private static CLCLookupService lookupService;
	
	public static CLCLookupService getCLCLookupService()
	{
		return lookupService;
	}
	
	public void setLookupService(CLCLookupService lookupService)
	{
		CLCLookupServiceHelper.lookupService = lookupService;
	}

}
