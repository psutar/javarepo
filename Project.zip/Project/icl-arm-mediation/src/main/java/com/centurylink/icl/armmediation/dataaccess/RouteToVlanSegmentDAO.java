package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.RouteToVlanSegment;

public interface RouteToVlanSegmentDAO {

	public void insert(RouteToVlanSegment routeToVlanSegment);

	public int getSegmentCountForRouteHeaderId(Long routeHeaderId);
	
	public List<RouteToVlanSegment> getVlanSegmentsForRouteHeaderId(Long routeHeaderId);
}
