package com.centurylink.icl.armmediation.service.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.ContactDetailsToCim;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetContactDetailsService {

	private static final Log LOG = LogFactory.getLog(GetContactDetailsService.class);
	private JDBCTempleteUtil jdbcTempleteUtil;
	private ContactDetailsToCim contactDetailsToCim;
	
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}
	
	public void setContactDetailsToCim(ContactDetailsToCim contactDetailsToCim) {
		this.contactDetailsToCim = contactDetailsToCim;
	}

	public Object getName(SearchResourceRequestDocument request) throws Exception
	{
		int subscriberID=0;
		String subscriberName = null;
		
		if(StringHelper.isDigit(MediationUtil.getRcv(request, "SubscriberID")))
		{
			subscriberID  = Integer.parseInt(MediationUtil.getRcv(request, "SubscriberID"));	
		}
		else
		{
			throw new ICLRequestValidationException("Invalid Subscriber ID, enter a Valid Subscriber ID");
		}		
		
		subscriberName = jdbcTempleteUtil.getSubscriberName(buildSubscriberQuery(subscriberID));
		
		if(subscriberName == null )
		{
			throw new OSSDataNotFoundException();
		}
		return contactDetailsToCim.transformToCLCRequest(request, subscriberName.trim());
			
		//return null;
	}	
	
	
	private String buildSubscriberQuery(int subscriberID)
	{
		//select subscriber.name from service,subscriber where service.service2subscriber=subscriber.subscriberid and service.name=''
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		//sqlBuilder.addTable(Constants.SUBSCRIBER);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBER, Constants.NAME);
		//sqlBuilder.eq(Constants.SERVICE, Constants.SERVICE_2_SUBSCRIBER, Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sqlBuilder.eqInt(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID,subscriberID);
		
		String query = sqlBuilder.getStatement();
		System.out.println(query);
		LOG.info("GetContactDetails from SubscriberID from Subscriber Table:: " + query);
		return query;
	}
}
