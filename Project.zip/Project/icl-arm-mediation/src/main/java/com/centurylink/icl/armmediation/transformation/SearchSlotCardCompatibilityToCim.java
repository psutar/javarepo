package com.centurylink.icl.armmediation.transformation;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ShelfDetails;
import com.centurylink.icl.armmediation.armaccessobject.SlotCardDetails;
import com.centurylink.icl.armmediation.armaccessobject.SlotDetails;
import com.centurylink.icl.armmediation.service.impl.SearchSlotCardCompatibilityVOService;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchSlotCardCompatibilityToCim
{
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final ShelfBuilder shelfBuilder;
	private final SlotBuilder slotBuilder;
	private final CardBuilder cardBuilder;

	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final SearchResourceResponseBuilder searchResourceResponseBuilder;
	private final SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder;

	private static final Log LOG = LogFactory.getLog(SearchSlotCardCompatibilityToCim.class);
	
	public SearchSlotCardCompatibilityToCim()
	{
		physicalDeviceBuilder = new PhysicalDeviceBuilder();
		shelfBuilder = new ShelfBuilder();
		slotBuilder = new SlotBuilder();
		cardBuilder = new CardBuilder();
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();

	}

	public SearchResourceResponseDocument transformSlotCardCompatibilityToCim(SearchResourceRequestDocument request,SlotCardDetails slotCardDetails)
	{

		if(null != slotCardDetails) {
			boolean isCardFound = false;
			
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			
			String deviceName = slotCardDetails.getCommonName();
			physicalDeviceBuilder.buildPhysicalDevice(deviceName, null, null, request.getSearchResourceRequest().getSearchResourceDetails().getSourceSystem(), null, null, null, null, null, null, null, null, null, null);
			List<ShelfDetails> shelfDetailsList = slotCardDetails.getShelfDetails();
			for (ShelfDetails shelfDetail : shelfDetailsList){
				
				String shelfName = shelfDetail.getCommonName();
				shelfBuilder.buildShelf(shelfName, null, null, null, null, null, null, null, null, null, null, null);
	
				List<SlotDetails> slotDetailsList = shelfDetail.getSlotDetails();

				for (SlotDetails slotDetail : slotDetailsList) {
					
					String slotName = slotDetail.getCommonName();
					slotBuilder.buildSlot(slotName, null, null, null);
					List<String> cardTypesList = slotDetail.getCardTypesList();
					if(null != cardTypesList && cardTypesList.size() > 0)
					{
						for(String cardType : cardTypesList) {						
							cardBuilder.buildCard(cardType, null, null, null, request.getSearchResourceRequest().getSearchResourceDetails().getSourceSystem(), null, null, null, null, null);
							slotBuilder.addAllowableCard(cardBuilder.getCard());
							isCardFound = true;
						}
					}
					shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				}
				physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
			}
			
			if(!isCardFound) {
				throw new ICLException("No compatible cards found for the given Device,Shelf(Or Shelves),Slot(s) and CardType(if any mentioned) combinations.");
			}
			searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());
			searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
			searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
			searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());

			return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}
	
	
}
