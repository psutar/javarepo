package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Provisionstatus;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class ProvisionstatusCache implements ValueObjectCache {
	
	private Map<String, Provisionstatus> cachedObjects = new HashMap<String, Provisionstatus>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Provisionstatus newProvisionstatus = new Provisionstatus(key);
			if (newProvisionstatus.isInstanciated())
			{
				cachedObjects.put(key, newProvisionstatus);
				return newProvisionstatus;
			} else {
				return null;
			}
		}
	}

}
