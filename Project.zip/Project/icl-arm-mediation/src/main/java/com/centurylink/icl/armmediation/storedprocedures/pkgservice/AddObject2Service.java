package com.centurylink.icl.armmediation.storedprocedures.pkgservice;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class AddObject2Service extends StoredProcedure
{
	private static final Log LOG = LogFactory.getLog(AddObject2Service.class);

	public AddObject2Service(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGSERVICE.ADDOBJECT2SERVICE");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));

		declareParameter(new SqlParameter("i_serviceid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_dimobjectid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_objectid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_relationshipid", Types.NUMERIC));
		declareParameter(new SqlParameter("i_sequence", Types.NUMERIC));

		compile();

	}

	public Map<String, Object> execute(BigDecimal i_serviceid, BigDecimal i_dimobjectid, BigDecimal i_objectid, BigDecimal i_relationshipid, BigDecimal i_sequence) 
	{
		final Map<String, Object> in = new HashMap<String, Object>();
		in.put("i_serviceid", i_serviceid);
		in.put("i_dimobjectid", i_dimobjectid);
		in.put("i_objectid", i_objectid);
		in.put("i_relationshipid", i_relationshipid);
		in.put("i_sequence", i_sequence);

		return super.execute(in);
	}

}
