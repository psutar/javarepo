package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.storedprocedures.pkglocation.CreateSubscriber;
import com.centurylink.icl.armmediation.transformation.ARMCreatePartyToCim;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.CreatePartyRequestDocument;
import com.iclnbi.iclnbiV200.CreatePartyResponseDocument;

public class CreatePartyService {

	private static final Log LOG = LogFactory.getLog(CreatePartyService.class);
	private JDBCTempleteUtil jdbcTempleteUtil;
	private CreateSubscriber createSubscriber;
	

	private ARMCreatePartyToCim armCreatePartyToCim;
	private SetObjectAttributeHelper setObjectAttributeHelper;

	

	public CreatePartyResponseDocument createParty (CreatePartyRequestDocument requestData) throws Exception
	{
	
		int commonId=0;
		final Long partyId;
		Map <String, Object>  map = null;
		String commonName = requestData.getCreatePartyRequest().getPartyDetails().getCommonName();
		String partyType = requestData.getCreatePartyRequest().getPartyDetails().getPartyType();
		String CustomerId = requestData.getCreatePartyRequest().getPartyDetails().getPartyId();	
		
		if(StringHelper.isEmpty(commonName) || StringHelper.isEmpty(partyType))
		{
			throw new ICLException("ICLRequestValidationError", "CommonName or partyType not present", "1948");
		}
		
		commonId=getSubscriberId(commonName);
		
		if(commonId !=0){
			
			throw new ICLException("ICLRequestValidationError", "Subscriber already present", "1948");
		}
		LOG.info("Starting Create Subscriber");
		try
		{
			partyId = getPartyId(partyType);
			
		} catch (IndexOutOfBoundsException exception)
		{
			//final String o_Errormsg = "Could not find Party id against the requested Party Type";
			//return armCreatePartyToCim.transformErrorToCim(requestData, Constants.ERROR_CODE_1948, Constants.ICL_REQUEST_VALIDATION_ERROR, o_Errormsg);
			throw new ICLException("ICLRequestValidationError", "Incorrect party type", "1948");
		}
		 map = createSubscriber.execute(commonName, partyId);
		 
		final BigDecimal subscriberId = (BigDecimal) map.get("o_SubscriberID");
		LOG.info("Obtained SubscriberID :::  " + subscriberId);
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreatePartyToCim.transformErrorToCim(requestData, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		
		HashMap<String, Object> attributesList = getPartyattributeslist(requestData, commonName, partyType,Long.valueOf(partyId).toString());
		LOG.info("SET ATTRIBUTES LIST :::: " + attributesList);
		map = setObjectAttributeHelper.execute("Subscriber",subscriberId, attributesList);
		
		LOG.info("AFTER Creating the subscriber , !!!  "+ map);
		//Map<String, Object> map = createSubscriber.execute(commonName, partyId);
		//final BigDecimal subscriberId = (BigDecimal) map.get("o_subscriberid");
		o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreatePartyToCim.transformErrorToCim(requestData, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		
		else{
			
			return armCreatePartyToCim.transformToCim(requestData, String.valueOf(partyId), commonName);
		}
	}

	private long getPartyId(String partyType) {

		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBERTYPE);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBERTYPE,
				Constants.SUBSCRIBERTYPEID);
		sqlBuilder.eq(Constants.SUBSCRIBERTYPE, Constants.NAME, partyType);

		final int subscriberTypeId = jdbcTempleteUtil.getSubscriberTypeId(sqlBuilder.getStatement());
				//.getSubscriberTypeId(sqlBuilder.getStatement());
		return subscriberTypeId;
	}
	
	
	private HashMap<String, Object> getPartyattributeslist(CreatePartyRequestDocument createPartyRequest, String subscriberName,String subscriberType, String partytypeid) throws Exception {
		
		final HashMap<String, Object> attributeList = new HashMap<String, Object>();
		//For Subscriber table
		attributeList.put(Constants.FULL_NAME, createPartyRequest.getCreatePartyRequest().getPartyDetails().getDescription() );
		attributeList.put(Constants.SUBTYPE, createPartyRequest.getCreatePartyRequest().getPartyDetails().getPartySubType());
		attributeList.put(Constants.NOTES, MediationUtil.getNotes(createPartyRequest, Constants.NOTES));
		
		
		//For EXT_SUBSCRIBER_EXTERNAL OR EXT_SUBSCRIBER_INTERNAL table
		if(partytypeid.equals("1900000001") || partytypeid.equals("1900000000"))
		{
			attributeList.put(Constants.CHANNEL, MediationUtil.rootEntityDescriberBy(createPartyRequest, Constants.CHANNEL));
			attributeList.put(Constants.CATEGORY, MediationUtil.getCategory(createPartyRequest, Constants.CATEGORY));
			attributeList.put(Constants.MCO, MediationUtil.rootEntityDescriberBy(createPartyRequest,Constants.MCO));
			//for EXT_SUBSCRIBER_EXTERNAL table
			if(partytypeid.equals("1900000001"))
			{
				attributeList.put(Constants.ENTERPRISEACCOUNTID, MediationUtil.rootEntityDescriberBy(createPartyRequest, Constants.ENTERPRISE));
				attributeList.put(Constants.LEGACYNETWORK, createPartyRequest.getCreatePartyRequest().getPartyDetails().getDataOwner());
			}
			
		}
			
		
		
		return attributeList;
	}
	
	private int	getSubscriberId(String subscriberName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sqlBuilder.eq(Constants.SUBSCRIBER, Constants.NAME, subscriberName);
		

		final int subscriberId = jdbcTempleteUtil.getSubscriberId(sqlBuilder.getStatement());
		return subscriberId;
	}

	public void setSetObjectAttributeHelper(
			SetObjectAttributeHelper setObjectAttributeHelper) {
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil) {
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setCreateSubscriber(CreateSubscriber createSubscriber) {
		this.createSubscriber = createSubscriber;
	}
	
	public void setArmCreatePartyToCim(ARMCreatePartyToCim armCreatePartyToCim) {
		this.armCreatePartyToCim = armCreatePartyToCim;
	}
}
