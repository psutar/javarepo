package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CustomerAccountBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.RouteBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.builder.cim2.TopologicalLinkBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.Route;
import com.iclnbi.iclnbiV200.TopologicalLink;

public class TransportPathToCim {

	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final SubNetworkConnectionBuilder subNetworkConnectionBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final CustomerAccountBuilder customerAccountBuilder;
	private final LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder;
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final IPAddressBuilder ipAddressBuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final TerminationPointBuilder terminationPointBuilder;
	private final SearchResourceResponseBuilder searchResourceResponseBuilder;
	private final SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder;
	private final RouteBuilder routeBuilder;
	private final TopologicalLinkBuilder topologicalLinkBuilder;
	private final PhysicalDeviceRoleBuilder physicaldevicerolebuilder;
	List<Route> routeList=new ArrayList<Route>();
	List<TopologicalLink> topologicalList=new ArrayList<TopologicalLink>();

	public TransportPathToCim()
	{
		this.searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		this.subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		this.ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		this.customerBuilder = new CustomerBuilder();
		this.customerAccountBuilder = new CustomerAccountBuilder();
		this.logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		this.physicalDeviceBuilder = new PhysicalDeviceBuilder();
		this.ipAddressBuilder = new IPAddressBuilder();
		this.americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		this.terminationPointBuilder = new TerminationPointBuilder();
		this.searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		this.searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		this.routeBuilder=new RouteBuilder();
		this.topologicalLinkBuilder=new TopologicalLinkBuilder();
		this.physicaldevicerolebuilder=new PhysicalDeviceRoleBuilder();
	}

	public SearchResponseDetailsBuilder transformTransportPathToCim(List<ARMImpactedCircuits> cktsList,List<ARMImpactedCircuits> lagTPCktsList)
	{
		SearchResponseDetailsBuilder searchResponseDetailsBuilder=new SearchResponseDetailsBuilder();

		if(cktsList!=null && cktsList.size()>0)
		{
			searchResponseDetailsBuilder= buildCircuit(cktsList);
		}
		else if(lagTPCktsList!=null && lagTPCktsList.size()>0)
		{
			searchResponseDetailsBuilder=buildCircuit(lagTPCktsList);
		}
		else 
		{
			throw new OSSDataNotFoundException();
		}
		return searchResponseDetailsBuilder;

	}


	private SearchResponseDetailsBuilder buildCircuit(List<ARMImpactedCircuits> circuitsList)
	{

		// Building circuit
		List<ARMImpactedCircuits>  tpCktList=new ArrayList<ARMImpactedCircuits>();
		List<ARMImpactedCircuits>  ebLagCktList=new ArrayList<ARMImpactedCircuits>();
		List<ARMImpactedCircuits>  lagCktList=new ArrayList<ARMImpactedCircuits>();

		if(circuitsList!=null && circuitsList.size()>0)
		{
			for(ARMImpactedCircuits circuit:circuitsList)
			{
				if(circuit.getResourceType().equalsIgnoreCase("Transport Path"))
				{
					tpCktList.add(circuit);

				}
				else if(circuit.getResourceType().equalsIgnoreCase("Unrouted Ethernet Bearer")|| circuit.getResourceType().equalsIgnoreCase("Link Aggregation Group"))
				{
					ebLagCktList.add(circuit);
				}
				 if(circuit.getResourceType().equalsIgnoreCase("Link Aggregation Group"))
				{
					lagCktList.add(circuit);
				}
			}
		}
		if(tpCktList!=null && tpCktList.size()>0)
		{
			
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			for(ARMImpactedCircuits tpCkt:tpCktList)
			{
				subNetworkConnectionBuilder.buildSubNetworkConnection(tpCkt.getCommonName(), tpCkt.getCktId(), null, "ARM", null, null, null, null, null, null, null, null);
				if(ebLagCktList!=null && ebLagCktList.size()>0)
				{
					routeBuilder.buildRoute();
					for(ARMImpactedCircuits ebLagCkt:ebLagCktList)
					{
						if(ebLagCkt!=null && ebLagCkt.getResourceType()!=null && ((ebLagCkt.getResourceType().equalsIgnoreCase("Unrouted Ethernet Bearer")&& ebLagCkt.getIsLagMember()==null)||ebLagCkt.getResourceType().equalsIgnoreCase("Link Aggregation Group")) && ebLagCkt.getRelatedCktID().equals(tpCkt.getCktId()))
						{
							buildEBLagCircuit(routeBuilder,ebLagCkt);
						}
						
						if(lagCktList!=null && lagCktList.size()>0)
						{
							for(ARMImpactedCircuits lagCkt:lagCktList)
							{
								if(ebLagCkt!=null && ebLagCkt.getResourceType()!=null && (ebLagCkt.getResourceType().equalsIgnoreCase("Unrouted Ethernet Bearer")&& ebLagCkt.getIsLagMember()!=null)&& (ebLagCkt.getRelatedCktID().equals(lagCkt.getCktId())) && (lagCkt.getRelatedCktID().equals(tpCkt.getCktId())))
								{
									buildEBLagCircuit(routeBuilder,ebLagCkt);
								}
							}
						}
						
					}
					subNetworkConnectionBuilder.addRoute(routeBuilder.getRoute());
				}
				searchResponseDetailsBuilder.addCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
			}
		}
		else 
		{
			throw new OSSDataNotFoundException();
		}


	  return searchResponseDetailsBuilder;

	}

	
	private void buildEBLagCircuit(RouteBuilder routeBuilder,ARMImpactedCircuits ebLagCkt)
	{
	topologicalLinkBuilder.buildTopologicalLink(ebLagCkt.getCommonName(), ebLagCkt.getCktId(), null, null, ebLagCkt.getCktServiceType(), ebLagCkt.getCktProvStatus(), null, null, null);
	topologicalLinkBuilder.addResourceDescribedBy("SequenceNo", ebLagCkt.getSequence());

	//Building connected TerminationPoint Builder
	ConnectionTerminationPointBuilder connectTerminationPointBuilder = new ConnectionTerminationPointBuilder();

	//Building Physical Device

	//For ZEndTps
	physicalDeviceBuilder.buildPhysicalDevice(ebLagCkt.getEndDeviceName(), ebLagCkt.getEndDeviceObjectId(), null, null, null, null, ebLagCkt.getEndDevicePrStatus(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
	LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
	logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null,null);

	//logicalPhysicalResourceBuilder.addPhysicalDevice(physicalDeviceBuilder.getPhysicalDevice());
	physicaldevicerolebuilder.buildPhysicalDeviceRole(ebLagCkt.getStartDevicerole());
	physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicaldevicerolebuilder.getPhysicaldevicerole());
	logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
	connectTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);

	connectTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
	topologicalLinkBuilder.addZEndTps(connectTerminationPointBuilder.getConnectionTerminationPoint());

	// For AEnd Tps
	physicalDeviceBuilder.buildPhysicalDevice(ebLagCkt.getStartDeviceName(), ebLagCkt.getStartDeviceObjectId(), null, null, null, null, ebLagCkt.getStartDevicePrStatus(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

	logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null,null);
	physicaldevicerolebuilder.buildPhysicalDeviceRole(ebLagCkt.getEndDevicerole());
	physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicaldevicerolebuilder.getPhysicaldevicerole());
	logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
	connectTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
	connectTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
	topologicalLinkBuilder.addAEndTps(connectTerminationPointBuilder.getConnectionTerminationPoint());
	routeBuilder.addTopologicalLink(topologicalLinkBuilder.getTopologicalLink());
	}
}
