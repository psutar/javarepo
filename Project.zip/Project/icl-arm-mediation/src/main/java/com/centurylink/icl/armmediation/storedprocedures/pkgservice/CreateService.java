package com.centurylink.icl.armmediation.storedprocedures.pkgservice;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class CreateService extends StoredProcedure
{
	private static final Log	LOG	= LogFactory.getLog(CreateService.class);

	public CreateService(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGSERVICE.CREATESERVICE");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_serviceid", Types.NUMERIC));

		declareParameter(new SqlParameter("i_name", Types.VARCHAR));
		declareParameter(new SqlParameter("i_servicetype", Types.NUMERIC));
		declareParameter(new SqlParameter("i_subscriber", Types.NUMERIC));

		compile();

	}

	public Map<String, Object> execute(String i_name, BigDecimal i_servicetype, BigDecimal i_subscriber)
	{
		final Map<String, Object> in = new HashMap<String, Object>();
		in.put("i_name", i_name);
		in.put("i_servicetype", i_servicetype);
		in.put("i_subscriber", i_subscriber);

		return super.execute(in);
	}

}
