package com.centurylink.icl.armmediation.armaccessobject;

public class ARMObject
{

	private String	name;
	private String	alias1;
	private String	alias2;
	private String	id;
	private String	fullName;
	private String	objectTypeId;
	private String	sourceSystem;

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getAlias1()
	{
		return alias1;
	}

	public void setAlias1(String alias1)
	{
		this.alias1 = alias1;
	}

	public String getAlias2()
	{
		return alias2;
	}

	public void setAlias2(String alias2)
	{
		this.alias2 = alias2;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getFullName()
	{
		return fullName;
	}

	public void setFullName(String fullName)
	{
		this.fullName = fullName;
	}

	public String getObjectTypeId()
	{
		return objectTypeId;
	}

	public void setObjectTypeId(String objectTypeId)
	{
		this.objectTypeId = objectTypeId;
	}

	public String getSourceSystem()
	{
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

}
