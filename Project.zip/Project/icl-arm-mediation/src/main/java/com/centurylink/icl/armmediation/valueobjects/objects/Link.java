package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Link extends AbstractReadOnlyTable {

	private static final Log LOG = LogFactory.getLog(Link.class);
	
	private static final String NAME = "NAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String OBJECTID = "OBJECTID";
	private static final String ALIAS2 = "ALIAS2";
	private static final String ALIAS1 = "ALIAS1";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String NOTES = "NOTES";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String BANDWIDTH = "BANDWIDTH";
	private static final String LINK2RPBUILDTEMPLATE = "LINK2RPBUILDTEMPLATE";
	private static final String MEASUREDATTENUATION = "MEASUREDATTENUATION";
	private static final String MEASUREDLENGTH = "MEASUREDLENGTH";	
	private static final String LINK2SOURCEPORT = "LINK2SOURCEPORT";
	private static final String LINK2DESTPORT = "LINK2DESTPORT";
	private static final String LINK2LINKTYPE = "LINK2LINKTYPE";
	private static final String LINK2BANDWIDTH = "LINK2BANDWIDTH";
	private static final String LINK2STARTLOCATION = "LINK2STARTLOCATION";
	private static final String LINK2ENDLOCATION = "LINK2ENDLOCATION";
	private static final String LINK2PROVISIONSTATUS = "LINK2PROVISIONSTATUS";
	private static final String LINK2FUNCTIONALSTATUS = "LINK2FUNCTIONALSTATUS";
	private static final String PROTECTIONSTATUS = "PROTECTIONSTATUS";
	private static final String LINK2PROTECTIONTYPE = "LINK2PROTECTIONTYPE";
	private static final String LINK2RESOLUTIONSTATUS = "LINK2RESOLUTIONSTATUS";
	private static final String CALCULATEDLENGTH = "CALCULATEDLENGTH";
	private static final String CALCULATEDATTENUATION = "CALCULATEDATTENUATION";
	private static final String LINKID = "LINKID";	
	private static final String LINK = "Link";
	
	private Location startLocation = null;
	private Location endLocation = null;
	private Linktype linktype = null;
	private LinkExtension linkExtension = null;
	
	private Port startPort = null;
	private Port endPort = null;
	private Provisionstatus provisionstatus = null;
	private Functionalstatus functionalstatus = null;
	

	public Link()
	{
		super();
		this.tableName = LINK;
	}

	public Link(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		if(!StringHelper.isEmpty(this.getLink2Linktype()))
			this.instanciated = true;
	}


	@Override
	public void populateModel()
	{
		  
		
		fields.put(LINKID, new Field(LINKID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(BANDWIDTH, new Field(BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(PROTECTIONSTATUS, new Field(PROTECTIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(LINK2SOURCEPORT, new Field(LINK2SOURCEPORT, Field.TYPE_NUMERIC));
		fields.put(LINK2DESTPORT, new Field(LINK2DESTPORT, Field.TYPE_NUMERIC));
		fields.put(LINK2LINKTYPE, new Field(LINK2LINKTYPE, Field.TYPE_NUMERIC));
		fields.put(LINK2BANDWIDTH, new Field(LINK2BANDWIDTH, Field.TYPE_NUMERIC));
		fields.put(LINK2STARTLOCATION, new Field(LINK2STARTLOCATION, Field.TYPE_NUMERIC));
		fields.put(LINK2ENDLOCATION, new Field(LINK2ENDLOCATION, Field.TYPE_NUMERIC));
		fields.put(LINK2PROVISIONSTATUS, new Field(LINK2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(LINK2FUNCTIONALSTATUS, new Field(LINK2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(LINK2PROTECTIONTYPE, new Field(LINK2PROTECTIONTYPE, Field.TYPE_NUMERIC));
		fields.put(LINK2RESOLUTIONSTATUS, new Field(LINK2RESOLUTIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(CALCULATEDLENGTH, new Field(CALCULATEDLENGTH, Field.TYPE_NUMERIC));
		fields.put(CALCULATEDATTENUATION, new Field(CALCULATEDATTENUATION, Field.TYPE_NUMERIC));
		fields.put(MEASUREDLENGTH, new Field(MEASUREDLENGTH, Field.TYPE_NUMERIC));
		fields.put(MEASUREDATTENUATION, new Field(MEASUREDATTENUATION, Field.TYPE_NUMERIC));
		fields.put(LINK2RPBUILDTEMPLATE, new Field(LINK2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(LINKID));
		
		linkedTables.add(new LinkedTable("LINK","LINKCIRCUIT", "LINKID", "LINKCIRCUIT2LINK",false));
		/*
		linkedTables.add(new LinkedTable("CIRCUIT", "CIRCUITTYPE", CIRCUIT2CIRCUITTYPE, "CIRCUITTYPEID", false));
		linkedTables.add(new LinkedTable("CIRCUIT", "LOCATION", "STARTLOCATION", CIRCUIT2STARTLOCATION, "LOCATIONID", false));
		linkedTables.add(new LinkedTable("CIRCUIT", "LOCATION", "ENDLOCATION", CIRCUIT2ENDLOCATION, "LOCATIONID", false));
		*/
	}
	
	
	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}
	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setLinkid(String linkid)
	{
		setField(LINKID,linkid);
	}

	public String getLinkid()
	{
		return getFieldAsString(LINKID);
	}
	public void setBandwidth(String bandwidth)
	{
		setField(BANDWIDTH,bandwidth);
	}

	public String getBandwidth()
	{
		return getFieldAsString(BANDWIDTH);
	}
	public void setProtectionstatus(String protectionstatus)
	{
		setField(PROTECTIONSTATUS,protectionstatus);
	}

	public String getProtectionstatus()
	{
		return getFieldAsString(PROTECTIONSTATUS);
	}
	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}
	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}
	
	public void setLink2SourcePort(String link2SourcePort)
	{
		setField(LINK2SOURCEPORT,link2SourcePort);
	}

	public String getLink2SourcePort()
	{
		return getFieldAsString(LINK2SOURCEPORT);
	}
	public void setLink2DestPort(String link2DestPort)
	{
		setField(LINK2DESTPORT,link2DestPort);
	}

	public String getLink2DestPort()
	{
		return getFieldAsString(LINK2DESTPORT);
	}
	public void setLink2Linktype(String link2Linktype)
	{
		setField(LINK2LINKTYPE,link2Linktype);
	}

	public String getLink2Linktype()
	{
		return getFieldAsString(LINK2LINKTYPE);
	}

	public void setLink2Bandwidth(String link2Bandwidth)
	{
		setField(LINK2BANDWIDTH,link2Bandwidth);
	}

	public String getLink2Bandwidth()
	{
		return getFieldAsString(LINK2BANDWIDTH);
	}

	public void setLink2StartLocation(String link2StartLocation)
	{
		setField(LINK2STARTLOCATION,link2StartLocation);
	}

	public String getLink2StartLocation()
	{
		return getFieldAsString(LINK2STARTLOCATION);
	}

	public void setLink2endLocations(String link2endLocations)
	{
		setField(LINK2ENDLOCATION,link2endLocations);
	}

	public String getLink2endLocation()
	{
		return getFieldAsString(LINK2ENDLOCATION);
	}
	public void setLink2provisionstatus(String link2provisionstatus)
	{
		setField(LINK2PROVISIONSTATUS,link2provisionstatus);
	}

	public String getLink2provisionstatus()
	{
		return getFieldAsString(LINK2PROVISIONSTATUS);
	}

	public void setLink2functionalstatus(String link2provisionstatus)
	{
		setField(LINK2FUNCTIONALSTATUS,link2provisionstatus);
	}
	
	public String getLink2functionalstatus()
	{
		return getFieldAsString(LINK2FUNCTIONALSTATUS);
	}
	public void setLink2protectiontype(String link2protectiontype)
	{
		setField(LINK2PROTECTIONTYPE,link2protectiontype);
	}
	public String getLink2protectiontype()
	{
		return getFieldAsString(LINK2PROTECTIONTYPE);
	}

	public void setLink2resolutionstatus(String link2resolutionstatus)
	{
		setField(LINK2RESOLUTIONSTATUS,link2resolutionstatus);
	}
	public String getLink2resolutionstatus()
	{
		return getFieldAsString(LINK2RESOLUTIONSTATUS);
	}
	public void setCalculatedlength(String calculatedlength)
	{
		setField(CALCULATEDLENGTH,calculatedlength);
	}
	public String getCalculatedlength()
	{
		return getFieldAsString(CALCULATEDLENGTH);
	}
	public void setCalculatedtenuation(String calculatedtenuation)
	{
		setField(CALCULATEDATTENUATION,calculatedtenuation);
	}

	public String getCalculatedtenuation()
	{
		return getFieldAsString(CALCULATEDATTENUATION);
	}

	public void setMeasuredlength(String measuredlength)
	{
		setField(MEASUREDLENGTH,measuredlength);
	}

	public String getMeasuredlength()
	{
		return getFieldAsString(MEASUREDLENGTH);
	}

	public void setMeasuredtenuation(String measuredtenuation)
	{
		setField(MEASUREDATTENUATION,measuredtenuation);
	}

	public String getMeasuredtenuation()
	{
		return getFieldAsString(MEASUREDATTENUATION);
	}
	public void setLink2rpbuildtemplate(String link2rpbuildtemplate)
	{
		setField(LINK2RPBUILDTEMPLATE,link2rpbuildtemplate);
	}

	public String getLink2rpbuildtemplate()
	{
		return getFieldAsString(LINK2RPBUILDTEMPLATE);
	}
	
	public Provisionstatus getProvisionstatus()
	{
		if (provisionstatus == null)
		{
			provisionstatus = (Provisionstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("provisionstatus").getCacheObject(this.getLink2provisionstatus());
		}
		
		return provisionstatus;
	}

	public Functionalstatus getFunctionalstatus()
	{
		if (functionalstatus == null)
		{
			functionalstatus = (Functionalstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("functionalstatus").getCacheObject(this.getLink2functionalstatus());

			if (functionalstatus == null)
			{
				functionalstatus = new Functionalstatus();
			}
		}
		
		return functionalstatus;
	}
	public Linktype getLinktype()
	{
		if (linktype == null)
		{
			linktype = (Linktype) ValueObjectCacheAccessorFactory.getValueObjectCache("linktype").getCacheObject(getField(LINK2LINKTYPE).toString());
		}
		
		return linktype;
	}

	public LinkExtension getLinkExtension()
	{
		if (linkExtension == null)
		{
			linkExtension = new LinkExtension(fields.get(LINKID), getLinktype().getTablename());
		}
		
		return linkExtension;
	}
	
	public Location getStartLocation()
	{
		if (startLocation == null)
		{
			startLocation = new Location(getField(LINK2STARTLOCATION).toString());
		}
		
		return startLocation;
	}

	public Location getEndLocation()
	{
		if (endLocation == null)
		{
			endLocation = new Location(getField(LINK2ENDLOCATION).toString());
		}
		
		return endLocation;
	}
	public Port getStartPort()
	{
		if (startPort == null)
		{
			startPort = new Port(this.getLink2SourcePort());
		}
		
		return startPort;
	}

	public Port getEndPort()
	{
		if (endPort == null)
		{
			endPort = new Port(this.getLink2DestPort());
		}
		
		return endPort;
	}


		
}