package com.centurylink.icl.armmediation.armaccessobject;

import java.util.ArrayList;
import java.util.List;

public class PortSyncAuditLog {

	private String deviceName;
	private List<ARMPort> consumedPorts = new ArrayList<ARMPort>(10);
	private List<ARMPort> releasedProts = new ArrayList<ARMPort>(10);
	private String requestedFrom  ="DEFAULT";
	private String time;
	private String prStatus;
	
	public String getPrStatus() {
		return prStatus;
	}

	public void setPrStatus(String prStatus) {
		this.prStatus = prStatus;
	}

	public String getDeviceName() {
		return deviceName;
	}
	
	public String getRequestedFrom() {
		return requestedFrom;
	}
	public void setRequestedFrom(String requestedFrom) {
		this.requestedFrom = requestedFrom;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}

	public List<ARMPort> getConsumedPorts() {
		return consumedPorts;
	}

	public void setConsumedPorts(List<ARMPort> consumedPorts) {
		this.consumedPorts = consumedPorts;
	}

	public List<ARMPort> getReleasedProts() {
		return releasedProts;
	}

	public void setReleasedProts(List<ARMPort> releasedProts) {
		this.releasedProts = releasedProts;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	
	
	
	
}
