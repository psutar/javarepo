package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuitDetails;
import com.centurylink.icl.armmediation.armaccessobject.ARMEVCVlan;
import com.centurylink.icl.armmediation.armaccessobject.MaxNameValue;
import com.centurylink.icl.armmediation.armaccessobject.QosDetails;
import com.centurylink.icl.armmediation.armaccessobject.VlanDetails;

public interface SearchCircuitDAO
{
	List<ARMCircuitDetails> getCircuitList(String query) throws Exception;
	
	List<ARMCircuitDetails> getServiceList(String query) throws Exception;

	List<ARMCircuitDetails> getCircuitDetailsList(String query)throws Exception;

	List<ARMCircuitDetails> getServiceDetailsList(String query);

	List<ARMCircuitDetails> getNodeDetailsList(String query);
	
	List<MaxNameValue> getMaxValuesForService(String query) throws Exception;
	
	List<ARMCircuit> getUniEnniCircuit(String query) throws Exception;

	List<ARMCircuit> getEnniRelatedCircuits(String query) throws Exception;

	List<ARMCircuit> getUniEnniRelatedCircuits(String query) throws Exception;
	
	List<ARMCircuitDetails> getCircuitDetailsListForDSP(String query);
	
	List<ARMCircuitDetails> getRelatedServiceDetailsForNMILAG(String query) throws Exception;

	List<ARMCircuitDetails> getServiceDetailsListForDSP(String query);
	
	List<ARMCircuitDetails> getRelatedNMILAGForUNIENNI(String query);

	List<ARMCircuitDetails> getRelatedEVCOVCForUNIENNI(String query);

	List<ARMCircuitDetails> getRelatedUNIENNIForEVCOVC(String query);

	List<QosDetails> getQosDetails(String query);

	List<VlanDetails> getVlanDetails(String query);
	
	List<ARMEVCVlan> getEVCVlanDetails(String query);
	
	public List<ARMCard> getCardList(String query) throws Exception;
	
	List<Long> getCircuitIdsBySubscriber(String subscriber) throws Exception;
	
	List<VlanDetails> getVpnIDDetails(String query);
	

}
