package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.NMIBandwidthDetails;

public interface SearchNMIByDeviceDAO
{

	public List<NMIBandwidthDetails> getNMICktList(String query) throws Exception;
	
	public List<NMIBandwidthDetails> getLAGCktList(String query) throws Exception;

}
