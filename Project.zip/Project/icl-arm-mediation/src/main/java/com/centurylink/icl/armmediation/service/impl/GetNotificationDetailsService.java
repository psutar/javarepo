package com.centurylink.icl.armmediation.service.impl;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.CLCLookupServiceHelper;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.transformation.ARMCLCNotificationTransformation;
import com.centurylink.icl.armmediation.transformation.SearchServiceVOTransformation;
import com.centurylink.icl.builder.util.SearchResourceRequestDocumentHelper;
import com.centurylink.icl.iclnotification.EventNotificationDocument;
import com.centurylink.icl.iclnotification.Parameter;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.ResourceNotificationDocument;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;


public class GetNotificationDetailsService {

	private static final Log LOG = LogFactory.getLog(GetNotificationDetailsService.class);
	
	public static final String EVC = "MEF EVC";
	public static final String UNI = "MEF UNI";
	public static final String OVC = "MEF OVC";
	public static final String ENNI = "MEF EENI";
	
	private static final String LOCATION = "LOCATION";
	private static final String SERVICE = "SERVICE";
	private ServiceVOService serviceVOService;
	
	
	public ResourceNotificationDocument getNotificationDetails(String eventAsString) throws Exception
	{
		
		try
			{
			EventNotificationDocument event = EventNotificationDocument.Factory.parse(eventAsString);
			
			
			String type = event.getEventNotification().getType();
			String action = event.getEventNotification().getAction();
			
			
			if(SERVICE.equalsIgnoreCase(type))
			{
				
				Parameter associatedService = getParameterValue(event, "AssociatedService");
				Parameter parameter = getParameterValue(event, "ResourceSubtype");
				String resourceSubtype = null;
				
				
				if(parameter != null)
				{
					resourceSubtype = parameter.getValue();
				}
				
				if(associatedService != null)
				{
					return ARMCLCNotificationTransformation.transformEvcMemberToResourceNotification(getUniEnniDetailsWithoutRelationships(event),event,resourceSubtype);
				}
				if(EVC.equalsIgnoreCase(resourceSubtype))
				{
					//return ARMCLCNotificationTransformation.transformEVCToResourceNotification(event);  
				}
				else if(UNI.equalsIgnoreCase(resourceSubtype))
				{
					if("DELETE".equalsIgnoreCase(action))
					{
						//return ARMCLCNotificationTransformation.transformDeleteUNIToResourceNotification(event);
					}
					else
					{
						//return ARMCLCNotificationTransformation.transformUNIToResourceNotification(getUNIDetails(event),event);
					}
				}
				
			}
			else if(LOCATION.equalsIgnoreCase(type) && "CLC".equalsIgnoreCase(event.getEventNotification().getSourceSystem()))
			{
				if("DELETE".equalsIgnoreCase(action))
				{
					return ARMCLCNotificationTransformation.transformDeleteLocationToResourceNotification(event);
				}
				else
				{
					return ARMCLCNotificationTransformation.transformLocationToResourceNotification(getCLCLocationAddressDetails(event),action);
				}
			}
		}
		catch(Exception e)
		{
			LOG.error("Could not get notification details" , e);
			throw e;
		}
		return null;
	}
	
	
	private AmericanPropertyAddress getCLCLocationAddressDetails(EventNotificationDocument event) throws Exception {
		
		return CLCLookupServiceHelper.getCLCLookupService().getAddressByName(event.getEventNotification().getCommonName());
	}

	private SearchResourceResponseDocument getUNIDetails(EventNotificationDocument event) throws Exception
	{
		
		Map<String, String> nvps = new java.util.HashMap<String, String>();
		nvps.put("IncludeRelationships", "True");
				
		SearchResourceRequestDocument searchResourceRequest = SearchResourceRequestDocumentHelper.createSearchResourceRequest("CIRCUIT", "CIRCUIT", "DETAILED", "ARM", event.getEventNotification().getCommonName(), event.getEventNotification().getObjectId(),nvps);
		
		VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) searchResourceRequest);
		return SearchServiceVOTransformation.transformToCIM(serviceVOService.getServices(searchHolder), searchHolder);
			
		
	}

	
	public static Parameter getParameterValue(EventNotificationDocument event,String parameterName)
	{
		if(event.getEventNotification().getParameterSet() != null && event.getEventNotification().getParameterSet().getParameterList() != null)
		{
			for(Parameter parameter : event.getEventNotification().getParameterSet().getParameterList())
			{
				if(parameterName.equalsIgnoreCase(parameter.getName()))
					return parameter;
			}
		}
		return null;
	}

	private SearchResourceResponseDocument getUniEnniDetailsWithoutRelationships(EventNotificationDocument event) throws Exception
	{
		String commonName = null;
		Parameter parameter = getParameterValue(event, "AssociatedService");
		
		if(EVC.equalsIgnoreCase(parameter.getType()) || OVC.equalsIgnoreCase(parameter.getType()))
		{
			commonName = event.getEventNotification().getCommonName();
		}
		else{
			
			commonName = parameter.getValue();
		}
		
		SearchResourceRequestDocument searchResourceRequest = SearchResourceRequestDocumentHelper.createSearchResourceRequest("CIRCUIT", "CIRCUIT", "SUMMARY", "ARM", commonName, null,null);
		
		VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) searchResourceRequest);
		return SearchServiceVOTransformation.transformToCIM(serviceVOService.getServices(searchHolder), searchHolder);
		
	}


	public ServiceVOService getServiceVOService() {
		return serviceVOService;
	}


	public void setServiceVOService(ServiceVOService serviceVOService) {
		this.serviceVOService = serviceVOService;
	}

	
}
