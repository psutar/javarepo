package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Shelf extends AbstractReadOnlyTable {

	private static final Log LOG = LogFactory.getLog(Circuit.class);
	
	private static final String SHELFID = "SHELFID";
	private static final String NAME = "NAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String SHELF2NODE = "SHELF2NODE";
	private static final String SHELF2PROVISIONSTATUS = "SHELF2PROVISIONSTATUS";
	private static final String SHELFNUMBER = "SHELFNUMBER";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String SHELF2SHELFTYPE = "SHELF2SHELFTYPE";
	private static final String SHELF2FUNCTIONALSTATUS = "SHELF2FUNCTIONALSTATUS";
	private static final String SHELF2RPBUILDTEMPLATE = "SHELF2RPBUILDTEMPLATE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	
	private List<Slot> slots;
	private List<TTServiceType> ttserviceTypeList=null;
	private Shelftype shelftype = null;	
	private ShelfExtension shelfExtension = null;
	
	public Shelf()
	{
		super();
		this.tableName = "SHELF";
	}
	
	public Shelf(String portId)
	{
		this();
		primaryKey.setValue(portId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public Shelf(Shelf template) {
		this();
		getRecordByTemplate(template);
		for (Field field : fields.values())
		{
			if (field.getValue() != null) {
				this.instanciated = true;
				break;
			}
		}		
	}
	
	public static List<Shelf> getShelfListByQuery(String query)
	{
		Shelf shelf = new Shelf();
		List<Shelf> shelfList = new ArrayList<Shelf>();
		List<Map<String,Object>> foundShelfList = shelf.getFullRecordsByQuery(query);
		
		for (Map<String,Object> shelfMap : foundShelfList)
		{
			Shelf workShelf = new Shelf();
			workShelf.instanciated = true;
			workShelf.populateFields(shelfMap);
			shelfList.add(workShelf);
		}
		return shelfList;
	}

	@Override
	public void populateModel()
	{
		fields.put(SHELFID, new Field(SHELFID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(SHELF2NODE, new Field(SHELF2NODE, Field.TYPE_NUMERIC));
		fields.put(SHELF2PROVISIONSTATUS, new Field(SHELF2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(SHELFNUMBER, new Field(SHELFNUMBER, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(SHELF2SHELFTYPE, new Field(SHELF2SHELFTYPE, Field.TYPE_NUMERIC));
		fields.put(SHELF2FUNCTIONALSTATUS, new Field(SHELF2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(SHELF2RPBUILDTEMPLATE, new Field(SHELF2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(SHELFID));
		linkedTables.add(new LinkedTable("SHELF", "SHELFTYPE", SHELF2SHELFTYPE, "SHELFTYPEID", false));
	}

	public void setShelfid(String shelfid)
	{
		setField(SHELFID,shelfid);
	}

	public String getShelfid()
	{
		return getFieldAsString(SHELFID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setShelf2node(String shelf2node)
	{
		setField(SHELF2NODE,shelf2node);
	}

	public String getShelf2node()
	{
		return getFieldAsString(SHELF2NODE);
	}

	public void setShelf2provisionstatus(String shelf2provisionstatus)
	{
		setField(SHELF2PROVISIONSTATUS,shelf2provisionstatus);
	}

	public String getShelf2provisionstatus()
	{
		return getFieldAsString(SHELF2PROVISIONSTATUS);
	}

	public void setShelfnumber(String shelfnumber)
	{
		setField(SHELFNUMBER,shelfnumber);
	}

	public String getShelfnumber()
	{
		return getFieldAsString(SHELFNUMBER);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setShelf2shelftype(String shelf2shelftype)
	{
		setField(SHELF2SHELFTYPE,shelf2shelftype);
	}

	public String getShelf2shelftype()
	{
		return getFieldAsString(SHELF2SHELFTYPE);
	}

	public void setShelf2functionalstatus(String shelf2functionalstatus)
	{
		setField(SHELF2FUNCTIONALSTATUS,shelf2functionalstatus);
	}

	public String getShelf2functionalstatus()
	{
		return getFieldAsString(SHELF2FUNCTIONALSTATUS);
	}

	public void setShelf2rpbuildtemplate(String shelf2rpbuildtemplate)
	{
		setField(SHELF2RPBUILDTEMPLATE,shelf2rpbuildtemplate);
	}

	public String getShelf2rpbuildtemplate()
	{
		return getFieldAsString(SHELF2RPBUILDTEMPLATE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}
	
	public List<Slot> getSlots()
	{
		if (slots == null)
		{
			slots = Slot.getSlotListByQuery("slot2shelf = " + fields.get(SHELFID).getQueryValue());
		}
		
		return slots;
	}
	
	public List<Slot> getSlots(String slotNumber)
	{
		if (slots == null)
		{
			if(slotNumber!=null)
			{
			slots = Slot.getSlotListByQuery("slot2shelf = " + fields.get(SHELFID).getQueryValue()+" AND SLOT.SLOTNUMBER = "+slotNumber);
			}
			
			else
			{
				slots = Slot.getSlotListByQuery("slot2shelf = " + fields.get(SHELFID).getQueryValue());
			}
		}
		
		return slots;
	}
	public List<TTServiceType> getTTServiceTypeList()
	{
		if (ttserviceTypeList == null)
		{
			String query = "ARM_OBJECT_ID = " +this.getShelf2shelftype() + " AND ARM_OBJECT_TYPE='Shelf'";
			
			LOG.info("TTServiceType"+query);
			
			ttserviceTypeList = TTServiceType.getTTServiceTypeListByQuery(query);
		}
		
		return ttserviceTypeList;
	}
	
	public ShelfExtension getShelfExtension()
	{
		if (shelfExtension == null)
		{
			shelfExtension = new ShelfExtension(fields.get(SHELFID), getShelfType().getTablename());
		}

		return shelfExtension;
	}
	
	public Shelftype getShelfType()
	{
		if (shelftype == null)
		{
			shelftype = (Shelftype) ValueObjectCacheAccessorFactory.getValueObjectCache("shelftype").getCacheObject(getField(SHELF2SHELFTYPE).toString());
		}

		return shelftype;
	}
	
}