package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Parameterinstancevalue extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String DATEVALUE = "DATEVALUE";
	private static final String STRINGVALUE = "STRINGVALUE";
	private static final String DECIMALVALUE = "DECIMALVALUE";
	private static final String INTEGERVALUE = "INTEGERVALUE";
	private static final String COMPOSITESEQUENCE = "COMPOSITESEQUENCE";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String PARAMVALUE2PARAMINSTANCE = "PARAMVALUE2PARAMINSTANCE";
	private static final String PARAMETERVALUEID = "PARAMETERVALUEID";

	public Parameterinstancevalue()
	{
		super();
		this.tableName = "PARAMETERINSTANCEVALUE";
	}

	public Parameterinstancevalue(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public Parameterinstancevalue(Parameterinstancevalue template)
	{
		this();
		getRecordByTemplate(template);
		for(Field field:fields.values()){
			if (field.getValue() != null){
				this.instanciated = true;
				break;
			}
		}
	}

	public static Parameterinstancevalue getParameterinstancevalueByParameterinstanceId(String parameterinstanceId)
	{
		Parameterinstancevalue template = new Parameterinstancevalue();
		template.setParamvalue2paraminstance(parameterinstanceId);
		return new Parameterinstancevalue(template);
	}

	public static List<Parameterinstancevalue> getParameterinstancevalueListByQuery(String query)
	{
		Parameterinstancevalue parameterinstancevalue = new Parameterinstancevalue();
		List<Parameterinstancevalue> parameterinstancevalueList = new ArrayList<Parameterinstancevalue>();
		List<Map<String,Object>> foundParameterinstancevalueList = parameterinstancevalue.getRecordsByQuery(query);

		for (Map<String,Object> parameterinstancevalueMap : foundParameterinstancevalueList)
		{
			Parameterinstancevalue workParameterinstancevalue = new Parameterinstancevalue(parameterinstancevalueMap.get(PARAMETERVALUEID).toString());
			parameterinstancevalueList.add(workParameterinstancevalue);
		}
		return parameterinstancevalueList;
	}

	@Override
	public void populateModel()
	{
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(DATEVALUE, new Field(DATEVALUE, Field.TYPE_DATE));
		fields.put(STRINGVALUE, new Field(STRINGVALUE, Field.TYPE_VARCHAR));
		fields.put(DECIMALVALUE, new Field(DECIMALVALUE, Field.TYPE_NUMERIC));
		fields.put(INTEGERVALUE, new Field(INTEGERVALUE, Field.TYPE_NUMERIC));
		fields.put(COMPOSITESEQUENCE, new Field(COMPOSITESEQUENCE, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(PARAMVALUE2PARAMINSTANCE, new Field(PARAMVALUE2PARAMINSTANCE, Field.TYPE_NUMERIC));
		fields.put(PARAMETERVALUEID, new Field(PARAMETERVALUEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PARAMETERVALUEID));
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setDatevalue(String datevalue)
	{
		setField(DATEVALUE,datevalue);
	}

	public String getDatevalue()
	{
		return getFieldAsString(DATEVALUE);
	}

	public void setStringvalue(String stringvalue)
	{
		setField(STRINGVALUE,stringvalue);
	}

	public String getStringvalue()
	{
		return getFieldAsString(STRINGVALUE);
	}

	public void setDecimalvalue(String decimalvalue)
	{
		setField(DECIMALVALUE,decimalvalue);
	}

	public String getDecimalvalue()
	{
		return getFieldAsString(DECIMALVALUE);
	}

	public void setIntegervalue(String integervalue)
	{
		setField(INTEGERVALUE,integervalue);
	}

	public String getIntegervalue()
	{
		return getFieldAsString(INTEGERVALUE);
	}

	public void setCompositesequence(String compositesequence)
	{
		setField(COMPOSITESEQUENCE,compositesequence);
	}

	public String getCompositesequence()
	{
		return getFieldAsString(COMPOSITESEQUENCE);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setParamvalue2paraminstance(String paramvalue2paraminstance)
	{
		setField(PARAMVALUE2PARAMINSTANCE,paramvalue2paraminstance);
	}

	public String getParamvalue2paraminstance()
	{
		return getFieldAsString(PARAMVALUE2PARAMINSTANCE);
	}

	public void setParametervalueid(String parametervalueid)
	{
		setField(PARAMETERVALUEID,parametervalueid);
	}

	public String getParametervalueid()
	{
		return getFieldAsString(PARAMETERVALUEID);
	}


}