package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.centurylink.icl.querybuilder.interfaces.VariableAndValueProcessor;
import com.centurylink.icl.querybuilder.translator.ValueTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.VariableTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.value.ConvertToUpperCase;

public class ServiceVOService {
	
	private static final Log LOG = LogFactory.getLog(ServiceVOService.class);
	private QueryBuilder queryBuilder;

	public ServiceVOService()
	{
		Map<String, VariableAndValueProcessor> variableAndValueProcessorMap = new HashMap<String, VariableAndValueProcessor>();
		variableAndValueProcessorMap.put("NAME", new ValueTranslatorOnly("UPPER(SERVICE.NAME)", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("TYPE", new VariableTranslatorOnly("SERVICETYPE.NAME"));

		queryBuilder = new QueryBuilder(variableAndValueProcessorMap);
		//queryBuilder.setVariableValueTranslatorMap(variableValueTranslationMap);
	}
	
	public List<Service> getServices(VOSearchHolder searchHolder) throws Exception {
		
		LOG.info("Entering into  Service Call >>>>>>>>>");
		List<Service> services = new ArrayList<Service>();
		
		 if (!StringHelper.isEmpty(searchHolder.getCommonName()))
		{
			String query=null;
			if(searchHolder.getCommonName().startsWith("%") || searchHolder.getCommonName().endsWith("%")){
				query = "UPPER(SERVICE.NAME) LIKE '"+searchHolder.getCommonName().toUpperCase()+"'";
			}
			else{
				 query = "UPPER(SERVICE.NAME) = '"+searchHolder.getCommonName().toUpperCase()+"'";
			}
			services = Service.getServiceListByQuery(query);
		}
		else if (!StringHelper.isEmpty(searchHolder.getObjectID()))
		{
			Service service = new Service(searchHolder.getObjectID());
			if (service.isInstanciated())
			{
				services.add(service);
			} 
		} 
		 else if (searchHolder.getFilterCriteraList() != null && searchHolder.getFilterCriteraList().get("ENTITYFILTER") != null)
		{
			//TODO: MICKEY - Switch to using SearchHolder
			String query = queryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("ENTITYFILTER"));
			services = Service.getServiceListByQuery(query);
		} else {
			throw new ICLRequestValidationException("No Search Criteria Found in Request");
		}
		
		if (services.size() < 1)
		{
			throw new OSSDataNotFoundException();
		}
		
		
		return services;
	}
	
}
