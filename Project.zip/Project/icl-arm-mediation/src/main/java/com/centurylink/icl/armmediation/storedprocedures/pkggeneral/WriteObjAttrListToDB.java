package com.centurylink.icl.armmediation.storedprocedures.pkggeneral;

import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class WriteObjAttrListToDB extends StoredProcedure
{

	private static final Log	LOG	= LogFactory.getLog(AddToObjAttrListNumber.class);

	public WriteObjAttrListToDB(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGGENERAL.WRITEOBJATTRLISTTODB");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		compile();

	}

	public Map<String, Object> execute()
	{
		return super.execute();
	}

}
