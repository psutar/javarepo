package com.centurylink.icl.armmediation.armaccessobject;

public class ARMEVCVlan extends ARMObject
{

	private String evcOvcID;
	private String vlanPortID;
	
	
	public String getevcOvcID() {
		return evcOvcID;
	}
	public void setevcOvcID(String evcOvcID) {
		this.evcOvcID = evcOvcID;
	}
	
	public String getVlanPortID() {
		return vlanPortID;
	}
	public void setVlanPortID(String vlanPortID) {
		this.vlanPortID = vlanPortID;
	}
	
	
}
