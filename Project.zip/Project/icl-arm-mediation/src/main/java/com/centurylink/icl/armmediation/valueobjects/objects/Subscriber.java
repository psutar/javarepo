package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;
import com.centurylink.icl.valueobjects.impl.ReferenceField;

public class Subscriber extends AbstractReadOnlyTable {

	private static final String SUBSCRIBERID = "SUBSCRIBERID";
	private static final String NAME = "NAME";
	private static final String FIRSTNAME = "FIRSTNAME";
	private static final String TITLE = "TITLE";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String SUBSCRIBER2PROVISIONSTATUS = "SUBSCRIBER2PROVISIONSTATUS";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String SUBSCRIBER2FUNCTIONALSTATUS = "SUBSCRIBER2FUNCTIONALSTATUS";
	private static final String SUBSCRIBER2SUBSCRIBERTYPE = "SUBSCRIBER2SUBSCRIBERTYPE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";
	private static final String SUBSCRIBER2RPBUILDTEMPLATE = "SUBSCRIBER2RPBUILDTEMPLATE";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";

	public Subscriber()
	{
		super();
		this.tableName = "SUBSCRIBER";
	}

	public Subscriber(String subscriberId)
	{
		this();
		primaryKey.setValue(subscriberId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public Subscriber(Subscriber template)
	{
		this();
		getRecordByTemplate(template);
		for(Field field:fields.values()){
			if (field.getValue() != null){
				this.instanciated = true;
				break;
			}
		}
	}
	
	public static List<Subscriber> getSubscriberListByQuery(String query)
	{
		Subscriber subscriber = new Subscriber();
		List<Subscriber> subscriberList = new ArrayList<Subscriber>();
		List<Map<String,Object>> foundSubscriberList = subscriber.getRecordsByQuery(query);

		for (Map<String,Object> subscriberMap : foundSubscriberList)
		{
			Subscriber workSubscriber = new Subscriber(subscriberMap.get(SUBSCRIBERID).toString());
			subscriberList.add(workSubscriber);
		}
		return subscriberList;
	}

	@Override
	public void populateModel()
	{
		fields.put(SUBSCRIBER2SUBSCRIBERTYPE, new ReferenceField(SUBSCRIBER2SUBSCRIBERTYPE, Field.TYPE_NUMERIC, "SUBSCRIBERTYPE", "NAME", "SUBSCRIBERTYPEID", this.getClass().getName()));

		fields.put(SUBSCRIBERID, new Field(SUBSCRIBERID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FIRSTNAME, new Field(FIRSTNAME, Field.TYPE_VARCHAR));
		fields.put(TITLE, new Field(TITLE, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(SUBSCRIBER2PROVISIONSTATUS, new Field(SUBSCRIBER2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(SUBSCRIBER2FUNCTIONALSTATUS, new Field(SUBSCRIBER2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(SUBSCRIBER2SUBSCRIBERTYPE, new Field(SUBSCRIBER2SUBSCRIBERTYPE, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(SUBSCRIBER2RPBUILDTEMPLATE, new Field(SUBSCRIBER2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(SUBSCRIBERID));
	}

	public void setSubscriberid(String subscriberid)
	{
		setField(SUBSCRIBERID,subscriberid);
	}

	public String getSubscriberid()
	{
		return getFieldAsString(SUBSCRIBERID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFirstname(String firstname)
	{
		setField(FIRSTNAME,firstname);
	}

	public String getFirstname()
	{
		return getFieldAsString(FIRSTNAME);
	}

	public void setTitle(String title)
	{
		setField(TITLE,title);
	}

	public String getTitle()
	{
		return getFieldAsString(TITLE);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setSubscriber2provisionstatus(String subscriber2provisionstatus)
	{
		setField(SUBSCRIBER2PROVISIONSTATUS,subscriber2provisionstatus);
	}

	public String getSubscriber2provisionstatus()
	{
		return getFieldAsString(SUBSCRIBER2PROVISIONSTATUS);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setSubscriber2functionalstatus(String subscriber2functionalstatus)
	{
		setField(SUBSCRIBER2FUNCTIONALSTATUS,subscriber2functionalstatus);
	}

	public String getSubscriber2functionalstatus()
	{
		return getFieldAsString(SUBSCRIBER2FUNCTIONALSTATUS);
	}

	public void setSubscriber2subscribertype(String subscriber2subscribertype)
	{
		setField(SUBSCRIBER2SUBSCRIBERTYPE,subscriber2subscribertype);
	}

	public String getSubscriber2subscribertype()
	{
		return getFieldAsString(SUBSCRIBER2SUBSCRIBERTYPE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setSubscriber2rpbuildtemplate(String subscriber2rpbuildtemplate)
	{
		setField(SUBSCRIBER2RPBUILDTEMPLATE,subscriber2rpbuildtemplate);
	}

	public String getSubscriber2rpbuildtemplate()
	{
		return getFieldAsString(SUBSCRIBER2RPBUILDTEMPLATE);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}
	
	public static List<String> getSubscriberIdListByQuery(String query)
	{
		Subscriber subscriber = new Subscriber();
		List<String> subscriberList = new ArrayList<String>();
		List<Map<String,Object>> foundSubscriberList = subscriber.getRecordsByQuery(query);

		for (Map<String,Object> subscriberMap : foundSubscriberList)
		{
			String subscriberId = subscriberMap.get(SUBSCRIBERID).toString();
			subscriberList.add(subscriberId);
			/*Subscriber workSubscriber = new Subscriber(subscriberMap.get(SUBSCRIBERID).toString());
			subscriberList.add(workSubscriber);*/
		}
		return subscriberList;
	}
}