package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.service.impl.PortVOService;
import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.armmediation.valueobjects.objects.TTServiceType;
import com.centurylink.icl.builder.cim2.AffectedServiceTypeListBuilder;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.common.util.ElementNameUtil;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.ValidationCondition;
import com.iclnbi.iclnbiV200.ValidationRule;

public class AlarmEncrichmentVOTransformation {
	private static QueryBuilder portQueryBuilder = PortVOService.getQueryBuilder();
	private static final Log LOG = LogFactory.getLog(AlarmEncrichmentVOTransformation.class);

	public static PhysicalDevice buildDevice(Node node, VOSearchHolder searchHolder) throws Exception {


		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		AffectedServiceTypeListBuilder affectedServiceTypeListBuilder=new AffectedServiceTypeListBuilder();

		boolean applyPortFilter = false;
		boolean nodeHasPorts = false;
		String shelfNumber=null;
		String parentslotNumber=null;
		String childslotNumber=null;
		HashMap<String,String> elementMap=new HashMap<String,String>(); ;
		List<Condition> conditions=new ArrayList<Condition>();
		String portAdditionalQuery = null;
		if (searchHolder.getFilterCriteraList().get("PORTFILTER") != null && searchHolder.getLevel().equalsIgnoreCase("PPORT"))
		{
			portAdditionalQuery = portQueryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("PORTFILTER"));
			applyPortFilter = true;
			//conditions =searchHolder.getFilterCriteraList().get("PORTFILTER").getValidationConditionList().get(0).getEqualConditionList();
		}
		if (searchHolder.getFilterCriteraList().get("PORTFILTER") != null)
		{
			conditions =searchHolder.getFilterCriteraList().get("PORTFILTER").getValidationConditionList().get(0).getEqualConditionList();
		}

		if(searchHolder.getModifiers()!=null && searchHolder.getModifiers().get("ELEMENTNAME")!=null)
		{
			elementMap=ElementNameUtil.validateElementName(searchHolder.getModifiers().get("ELEMENTNAME"));
			if(elementMap!=null)
			{
				if(elementMap.get("shelf")!=null)
				{
					shelfNumber=elementMap.get("shelf");
				}
				if(elementMap.get("slot")!=null)
				{
					parentslotNumber=elementMap.get("slot");
				}
				else if(elementMap.get("ps")!=null)
				{
					parentslotNumber=elementMap.get("ps");
				}
				else if(elementMap.get("fan")!=null)
				{
					parentslotNumber=elementMap.get("fan");
				}
				if(elementMap.get("subslot")!=null)
				{
					childslotNumber=elementMap.get("subslot");
				}
			}

		}
		if(shelfNumber!=null && shelfNumber.equals("0"))
		{
			shelfNumber=null;
		}
		if(parentslotNumber!=null && parentslotNumber.equals("0"))
		{
			parentslotNumber=null;
		}
		if(childslotNumber!=null  && childslotNumber.equals("0"))
		{
			childslotNumber=null;
		}


		if (searchHolder.getScope().equalsIgnoreCase("BASIC"))
		{
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), null, null, null, null, null, null, node.getNodeDef().getName(),null, null,null);

		} else {


			String resourceType=null;
			if(searchHolder.getLevel()!=null)
			{
				if(searchHolder.getLevel().equalsIgnoreCase("Node")||searchHolder.getLevel().equalsIgnoreCase("sw")||searchHolder.getLevel().equalsIgnoreCase("Shelf")||searchHolder.getLevel().equalsIgnoreCase("Slot")||searchHolder.getLevel().equalsIgnoreCase("PS")||searchHolder.getLevel().equalsIgnoreCase("Fan"))
				{
					resourceType="Node";
				}
				
			}
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), null, null, null, null, null, null, node.getNodeDef().getName(),null, null,null);


			if (node.getSubscriber() != null)
			{
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				customerBuilder.buildCustomer(node.getSubscriber().getName(), null, null, null, null, null);
				ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
				physicalDeviceBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
			}	


			if(searchHolder.getModifiers()!=null && searchHolder.getModifiers().get("ELEMENTNAME")!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("ElementName", searchHolder.getModifiers().get("ELEMENTNAME"));
			}

			if(searchHolder.getLevel()!=null)
			{
				if(searchHolder.getLevel().equalsIgnoreCase("Node")||searchHolder.getLevel().equalsIgnoreCase("sw")||searchHolder.getLevel().equalsIgnoreCase("Shelf")||searchHolder.getLevel().equalsIgnoreCase("Slot")||searchHolder.getLevel().equalsIgnoreCase("PS")||searchHolder.getLevel().equalsIgnoreCase("Fan"))
				{
					physicalDeviceBuilder.addResourceDescribedBy("ARMObjectType",resourceType);
					physicalDeviceBuilder.addResourceDescribedBy("ARMObjectTypeID", node.getNodeDef().getNodedefid());
					if(node.getTTServiceTypeList()!=null && node.getTTServiceTypeList().size()>0)
					{
						affectedServiceTypeListBuilder.buildAffectedServiceTypeList();
						for(TTServiceType ttservicetype:node.getTTServiceTypeList())
						{
							if(ttservicetype !=null && ttservicetype.getTtservicetype()!=null)
							{
								affectedServiceTypeListBuilder.addAffectedServiceTypeValue(ttservicetype.getTtservicetype());
							}
						}
						physicalDeviceBuilder.addAffectedServiceTypeList(affectedServiceTypeListBuilder.getAffectedServiceTypeList());
					}
				}
			}

			boolean shelfHasPorts;
			boolean slotHasPorts;
			boolean cardHasPorts;
			boolean cardCardHasPorts;

			if (searchHolder.getLevel().equalsIgnoreCase("PPORT"))
			{
				HashSet<String> slots=new HashSet<String>();
				int shelfSize=node.getShelves(shelfNumber).size();

				// Case when There are no Shelf/Slot/Card on a device And ShelfNumber is passed in Filter	
				if(shelfNumber!= null && shelfSize == 0)
				{
					throw new OSSDataNotFoundException();
				}	
				if (shelfSize > 0)
				{
					rackBuilder.buildRack(null, null, null, null, null, null, null, null);
					for (Shelf shelf:node.getShelves(shelfNumber))
					{ 
						shelfHasPorts = false;
						if(shelf!=null)
						{
							shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, null, null, null, null, null);
							shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
						}

						for (Slot slot:shelf.getSlots(parentslotNumber))
						{				
							slotHasPorts = false;
							if(slot!=null)
							{
								slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber())); 
							}

							for (Card card:slot.getCards(parentslotNumber)) {
								cardHasPorts = false;
								if(card!=null)
								{
									cardBuilder.buildCard(card.getName(), card.getCardid(), null, null, "ARM", null, null, null, card.getCard2cardtype(), null);
								}

								for (Port port:card.getCardPorts(portAdditionalQuery,applyPortFilter))
								{
									nodeHasPorts = true;
									shelfHasPorts = true;
									slotHasPorts = true;
									cardHasPorts = true;
									if(port!=null)
									{					
										String networkPortName=null;
										if(port.getPorttype() != null && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_TABLE") && port.getPortExtension() != null)
										{
											networkPortName=port.getPortExtension().getIfName();
										}
										else if(port.getPorttype() != null  && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_PLUGGABLE") && port.getPortExtension() != null)
										{
											networkPortName=port.getPortExtension().getIfName();
										}
										physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), null, null, null,null,port.getAlias1(),null,port.getPorttype().getName(),null,null,null,null,null,networkPortName);
										if(port.getPortExtension().getBandwidth()!=null && port.getPortExtension().getFormfactor() != null)
										{
											String transmissionRate=null;
											transmissionRate=port.getPortExtension().getBandwidth() + port.getPortExtension().getFormfactor();
											physicalPortBuilder.addResourceDescribedBy("TransmissionRate", transmissionRate);
										}
										cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());								
									}

								}
								for (Slot cardSlot:card.getCardSlots(childslotNumber))
								{
									cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
									for (Card slotCard:cardSlot.getCards())
									{
										cardCardHasPorts = false;
										if(slotCard!=null)
										{		
											embededCardBuilder.buildCard(slotCard.getName(), slotCard.getCardid(), slotCard.getProvisionstatus().getName(), null, "ARM", null, null, null, slotCard.getCard2cardtype(), null);
										}										
										for (Port port:slotCard.getCardPorts(portAdditionalQuery,applyPortFilter))
										{

											nodeHasPorts = true;
											shelfHasPorts = true;
											slotHasPorts = true;
											cardHasPorts = true;
											cardCardHasPorts = true;
											if(port!=null)
											{
												String networkPortName=null;
												if(port.getPorttype() != null && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_TABLE") && port.getPortExtension() != null)
												{
													networkPortName=port.getPortExtension().getIfName();
												}
												else if(port.getPorttype() != null  && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_PLUGGABLE") && port.getPortExtension() != null)
												{
													networkPortName=port.getPortExtension().getIfName();
												}	
												physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), null, null, null,null,port.getAlias1(),null,port.getPorttype().getName(),null,null,null,null,null,networkPortName);

												if(port.getPortExtension().getBandwidth()!=null && port.getPortExtension().getFormfactor() != null)
												{
													String transmissionRate=null;
													transmissionRate=port.getPortExtension().getBandwidth() + port.getPortExtension().getFormfactor();
													physicalPortBuilder.addResourceDescribedBy("TransmissionRate", transmissionRate);
												}
												embededCardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());

											}
										}
										if (!applyPortFilter || cardCardHasPorts)
											cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
									}
									if (!applyPortFilter || cardHasPorts)
										if(cardOnCardDetailsBuilder.getCardOnCardDetails().getCardList().size()>0)
										{
											cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
										}
								}
								if (!applyPortFilter || cardHasPorts)
								{
									if(card.getCard2shelfslot().equals(slot.getSlotid()))
										slotBuilder.addHasCard(cardBuilder.getCard());
								}
							}
							if (!applyPortFilter || slotHasPorts)
							{
								if(shelfBuilder.getShelf()!=null && slot.getSlot2shelf().equals(shelf.getShelfid())
										&& !slots.contains(slotBuilder.getSlot().getObjectID()))
								{
									shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
									slots.add(slotBuilder.getSlot().getObjectID());
								}
							}
						}
						if (!applyPortFilter || shelfHasPorts)
						{
							if(shelfBuilder.getShelf()!=null)
							{
								rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
							}
						}
					}
					physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
				}
				List<Port> devicePorts = node.getDevicePorts(portAdditionalQuery,false);
				if (devicePorts != null && devicePorts.size() > 0)
				{
					for (Port port:devicePorts)
					{
						nodeHasPorts = true;
						String networkPortName=null;
						if(port.getPorttype() != null && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_TABLE") && port.getPortExtension() != null)
						{
							networkPortName=port.getPortExtension().getIfName();
						}
						else if(port.getPorttype() != null  && port.getPorttype().getTablename().equalsIgnoreCase("EXT_PORT_PLUGGABLE") && port.getPortExtension() != null)
						{
							networkPortName=port.getPortExtension().getIfName();
						}
						physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), null, null, null,null,port.getAlias1(),null,port.getPorttype().getName(),null,null,null,null,null,networkPortName);
						if(port.getPortExtension().getBandwidth()!=null && port.getPortExtension().getFormfactor() != null)
						{
							String transmissionRate=null;
							transmissionRate=port.getPortExtension().getBandwidth() + port.getPortExtension().getFormfactor();
								
							physicalPortBuilder.addResourceDescribedBy("TransmissionRate", transmissionRate);
						}
						physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());
					}
				}
			}
		}

		if (!applyPortFilter || nodeHasPorts)
			return physicalDeviceBuilder.getPhysicalDevice();
		else
			return null;
	}
	public static SearchResourceRequestDocument transformToVOCriteria(SearchResourceRequestDocument request) throws Exception
	{
		LOG.info("Transforming SID Request:"+request);
		SearchResourceDetails resourceDetails=request.getSearchResourceRequest().getSearchResourceDetails();
		String elementName=SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(resourceDetails.getResourceCharacteristicValueList(), "ElementName");
		HashMap<String,String> elementMap =new HashMap<String, String>();


		if(elementName!=null)
		{
			elementMap=ElementNameUtil.validateElementName(elementName);
		}

		ValidationRule vr1=  ValidationRule.Factory.newInstance();
		ValidationCondition vc1= ValidationCondition.Factory.newInstance();

		Condition c1= Condition.Factory.newInstance();
		Condition c2= Condition.Factory.newInstance();
		Condition c3= Condition.Factory.newInstance();
		Condition c4= Condition.Factory.newInstance();

		if(elementMap.get("shelf")!=null && !elementMap.get("shelf").equals("0"))
		{
			c1.setVariableName("SHELFNUMBER");
			c1.setValue(elementMap.get("shelf"));
		}
		if(elementMap.get("slot")!=null && !elementMap.get("slot").equals("0"))
		{
			c2.setVariableName("SLOTNUMBER");
			c2.setValue(elementMap.get("slot"));
		}
		
		if(elementMap.get("pport")!=null)
		{
			c3.setVariableName("PORTNUMBER");
			c3.setValue(elementMap.get("pport"));
		}
		
		if(c1.getVariableName()!=null && c1.getValue()!=null)
		{
			vc1.getEqualConditionList().add(c1);
		}
		if(c2.getVariableName()!=null && c2.getValue()!=null)
		{
			vc1.getEqualConditionList().add(c2);
		}
		if(c3.getVariableName()!=null && c3.getValue()!=null)
		{
			vc1.getEqualConditionList().add(c3);
		}
		if(c4.getVariableName()!=null && c4.getValue()!=null)
		{
			vc1.getEqualConditionList().add(c4);
		}
		

		if(vc1.getEqualConditionList()!=null && vc1.getEqualConditionList().size()>0)
		{
			vr1.getValidationConditionList().add(vc1);
			vr1.setOperation("PORTFILTER");		
			resourceDetails.getFilterCriteriaList().add(vr1);
		}

		if(elementMap.get("sw")!=null)
		{
			resourceDetails.setCommonName(elementMap.get("sw"));
		}

		request.getSearchResourceRequest().setSearchResourceDetails(resourceDetails);

		
		LOG.info("Transformed Request "+request);
		return request;
	}


	public static SearchResourceResponseDocument transformToCIM(List<Circuit> circuitList,List<Service> servicelist,SearchResourceRequestDocument searchResourceRequestDocument) throws Exception
	{

		SearchResponseDetailsBuilder searchResponseDetailsBuilder =new SearchResponseDetailsBuilder();
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		AffectedServiceTypeListBuilder affectedServiceTypeListBuilder=new AffectedServiceTypeListBuilder();

		SearchResourceDetails searchResourceDetails=searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		String elementName=	SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceDetails.getResourceCharacteristicValueList(), "ElementName");
		if((circuitList!=null && circuitList.size()>0) || (servicelist!=null && servicelist.size()>0))
		{

			searchResponseDetailsBuilder.buildSearchResponseDetails();

			if(circuitList!=null && circuitList.size()>0){
				for(Circuit circuit:circuitList)
				{
					if(circuit!=null && !circuit.getCircuittype().getName().equalsIgnoreCase("Transport Path"))
					{
						subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null, null, null, null, null, null);
						if(circuit.getSubscriber()!=null)
						{		
							subNetworkConnectionBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(circuit.getSubscriber()));													
						}

						if(circuit.getTTServiceTypeList()!=null && circuit.getTTServiceTypeList().size()>0)
						{
							affectedServiceTypeListBuilder.buildAffectedServiceTypeList();
							for(TTServiceType ttservicetype:circuit.getTTServiceTypeList())
							{
								if(ttservicetype !=null && ttservicetype.getTtservicetype()!=null)
								{
									affectedServiceTypeListBuilder.addAffectedServiceTypeValue(ttservicetype.getTtservicetype());
								}
							}
							subNetworkConnectionBuilder.addAffectedServiceTypeList(affectedServiceTypeListBuilder.getAffectedServiceTypeList());
						}
						if(elementName!=null)
						{
							subNetworkConnectionBuilder.addResourceDescribedBy("ElementName", elementName);
						}
						if(circuit.getCircuit2circuittype()!=null)
						{
							subNetworkConnectionBuilder.addResourceDescribedBy("ARMObjectTypeID", circuit.getCircuit2circuittype());
						}
						subNetworkConnectionBuilder.addResourceDescribedBy("ARMObjectType", "Circuit");
						searchResponseDetailsBuilder.addCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
					}

				}
			}
			if(servicelist!=null && servicelist.size()>0){
				for(Service service:servicelist)
				{
					if(service!=null)
					{
						addService(service,searchResourceDetails,searchResponseDetailsBuilder);
						if(service.getAssociatedServices()!=null && service.getAssociatedServices().size()>0)
						{
							for(Service associatedservice:service.getAssociatedServices())
							{
								if(associatedservice!=null)
								{
									addService(associatedservice,searchResourceDetails,searchResponseDetailsBuilder);

								}
							}
						}
					}

				}
			}
			SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
			SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
			searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
			searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
			searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
			System.out.println(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument());
			return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
		} 
		else
		{
			throw new OSSDataNotFoundException();
		}	
	}

	private static SearchResponseDetails addService(Service service, SearchResourceDetails searchResourceDetails,SearchResponseDetailsBuilder searchResponseDetailsBuilder) throws Exception
	{
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		AffectedServiceTypeListBuilder affectedServiceTypeListBuilder=new AffectedServiceTypeListBuilder();


		String elementName=	SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceDetails.getResourceCharacteristicValueList(), "ElementName");

		subNetworkConnectionBuilder.buildSubNetworkConnection(service.getName(), service.getServiceid(), null, "ARM", service.getServicetype().getName(), service.getProvisionstatus().getName(), null, null, null, null, null, null, null);
		if(service.getSubscriber()!=null)
		{
			subNetworkConnectionBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber()));													
		}

		if(service.getTTServiceTypeList()!=null && service.getTTServiceTypeList().size()>0)
		{
			affectedServiceTypeListBuilder.buildAffectedServiceTypeList();
			for(TTServiceType ttservicetype:service.getTTServiceTypeList())
			{
				if(ttservicetype !=null && ttservicetype.getTtservicetype()!=null)
				{
					affectedServiceTypeListBuilder.addAffectedServiceTypeValue(ttservicetype.getTtservicetype());
				}
			}
			subNetworkConnectionBuilder.addAffectedServiceTypeList(affectedServiceTypeListBuilder.getAffectedServiceTypeList());
		}
		if(elementName!=null)
		{
			subNetworkConnectionBuilder.addResourceDescribedBy("ElementName", elementName);
		}
		if(service.getService2servicetype()!=null)
		{
			subNetworkConnectionBuilder.addResourceDescribedBy("ARMObjectTypeID", service.getService2servicetype());
		}
		subNetworkConnectionBuilder.addResourceDescribedBy("ARMObjectType", "Service");
		searchResponseDetailsBuilder.addCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
		return searchResponseDetailsBuilder.getSearchResponseDetails();
	}
}
