package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.NMIBandwidthDetails;
import com.centurylink.icl.armmediation.dataaccess.SearchNMIByDeviceDAO;

public class SearchNMIByDeviceDAOImpl implements SearchNMIByDeviceDAO
{

	private JdbcTemplate	jdbcTemplate;

	public SearchNMIByDeviceDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<NMIBandwidthDetails> getNMICktList(String query) throws Exception
	{
		final List<NMIBandwidthDetails> circuitList = this.jdbcTemplate.query(query, new RowMapper<NMIBandwidthDetails>()
				{
					public NMIBandwidthDetails mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						NMIBandwidthDetails nmiCkt = new NMIBandwidthDetails();
						nmiCkt.setCommonName(rs.getString("NAME"));
						nmiCkt.setObjectID(rs.getString("CIRCUITID"));
						//will need confirmation fro SA for  ailableBandwidth
						//nmiCkt.setAvailableBandwidth(rs.getString("BW"));
						nmiCkt.setBandwidth(rs.getString("BW"));
						nmiCkt.setLrStatus(rs.getString("STATUS"));
						nmiCkt.setResourceType(rs.getString("RESOURCETYPE"));

						return nmiCkt;
					}
				});

				return circuitList;
				
	}
	public List<NMIBandwidthDetails> getLAGCktList(String query) throws Exception
	{
		final List<NMIBandwidthDetails> circuitList = this.jdbcTemplate.query(query, new RowMapper<NMIBandwidthDetails>()
				{
					public NMIBandwidthDetails mapRow(ResultSet rs, int rowNum) throws SQLException
					{
						NMIBandwidthDetails nmiCkt = new NMIBandwidthDetails();
						nmiCkt.setCommonName(rs.getString("NAME"));
						nmiCkt.setObjectID(rs.getString("CIRCUITID"));
						//will need confirmation fro SA for  ailableBandwidth
						//nmiCkt.setAvailableBandwidth(rs.getString("BW"));
						nmiCkt.setBandwidth(rs.getString("BW"));
						nmiCkt.setLrStatus(rs.getString("STATUS"));
						return nmiCkt;
					}
				});

				return circuitList;
				
	}

	
}
