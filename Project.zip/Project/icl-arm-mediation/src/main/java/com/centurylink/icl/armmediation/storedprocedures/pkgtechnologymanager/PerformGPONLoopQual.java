package com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.commons.dbcp.DelegatingConnection;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class PerformGPONLoopQual extends StoredProcedure
{

	private static final Log LOG = LogFactory.getLog(PerformGPONLoopQual.class);

	public PerformGPONLoopQual(DataSource dataSource)
	{
		super(dataSource, "CUSTOMIZATION.PKGTECHNOLOGYMANAGER.PERFORMGPONLOOPQUAL");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}
		
		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_PrismNosaCertifiedOLT", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_1GBPSOLT", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_FiberDropIndicator", Types.NUMERIC));
		declareParameter(new SqlOutParameter("o_FiberDropType", Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_FDNodesPortCapacity", OracleTypes.ARRAY, "CUSTOMIZATION.T_FDNODEPORTCAPACITY"));
		declareParameter(new SqlOutParameter("o_Splitter", Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_SplitterPort", Types.VARCHAR));
		declareParameter(new SqlOutParameter("o_SplitterNodes", OracleTypes.ARRAY, "CUSTOMIZATION.T_SPLITTER_LIST"));
		declareParameter(new SqlOutParameter("o_ONTNodes", OracleTypes.ARRAY, "CUSTOMIZATION.T_ONT_LIST"));
		
		declareParameter(new SqlParameter("i_ServiceLocation", Types.VARCHAR));
		declareParameter(new SqlParameter("i_ServingAreaLocation", Types.VARCHAR));		
		declareParameter(new SqlParameter("i_NetworkRoleList", OracleTypes.ARRAY, "CUSTOMIZATION.T_NAME_LIST"));
		
		compile();
	}

	public Map<String, Object> execute(String i_ServiceLocation, String i_ServingAreaLocation, List<String> i_NetworkRoleList) throws Exception
	{
		final Map<String, Object> in = new HashMap<String, Object>();	
		Map<String, Object> response = null;
		
		try{
			LOG.info("Inside PerformLoopQual API ");

			in.put("i_ServiceLocation", i_ServiceLocation);
			in.put("i_ServingAreaLocation", i_ServingAreaLocation);
			in.put("i_NetworkRoleList", new MyArray(i_NetworkRoleList));
			response = super.execute(in);
		}catch(Exception e){
			LOG.info(e);
			e.printStackTrace();
		}
		return response;
	}
	
	public class MyArray extends AbstractSqlTypeValue {       
		  private List values;       
		  
		  public MyArray(List values) {         
			  this.values = values;      
		  }       
		  
		  public Object createTypeValue(Connection con, int sqlType, String typeName) throws SQLException {
			  Connection oradbconn = ((DelegatingConnection) con).getInnermostDelegate();
			  oracle.sql.ArrayDescriptor desc = new oracle.sql.ArrayDescriptor(typeName, oradbconn);         
			  return new oracle.sql.ARRAY(desc, oradbconn,(Object[])values.toArray(new Object[values.size()]));       
		  }
	}
	  
	
}