package com.centurylink.icl.armmediation.transformation;

import java.util.Iterator;
import java.util.List;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class FetchPreferredVOTransformation {
	
	PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
	public static SearchResourceResponseDocument transformToCIM(List<Port> ports, VOSearchHolder searchHolder)
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		physicalDeviceBuilder.buildPhysicalDevice(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);

		for (Port port:ports)
			physicalDeviceBuilder.addHasPorts(buildPort(port, searchHolder.getLevel(), searchHolder.getScope()));
		
		searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}
	
	
	protected static PhysicalPort buildPort(Port port, String level, String scope) {
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		
		if (scope.equalsIgnoreCase("BASIC"))
			physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), null, port.getPortExtension().getDpea(), null, null,null,null, null,port.getPorttype().getName(),null,null,null,null,null);
		else if (scope.equalsIgnoreCase("SUMMARY"))
			physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), null,null,null,port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null);
		else {
			physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), port.getPortExtension().getBandwidth(),port.getPortExtension().getWavelength(),null,port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,null,null,null,null);
			physicalPortBuilder.addResourceDescribedBy("CreatedDate", port.getCreateddate());
			physicalPortBuilder.addResourceDescribedBy("CreatedUser", port.getCreatedby2dimuser());
			physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
			if (level.equalsIgnoreCase("DEVICE"))
			{
				ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
				resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
				resourceRelationshipBuilder.addDevice(SearchNodeVOTransformation.buildDeviceFromPort(port, false,scope));
				physicalPortBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
			}
		}
		
		return physicalPortBuilder.getPhysicalPort();
	}

	protected static PhysicalDevice buildDevice(Node node, VOSearchHolder searchHolder) throws Exception
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		
		
	if (searchHolder.getScope().equalsIgnoreCase("Summary"))
	{
		physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", null, null, null, null, null, null, null, null, null, null, null, null,null);
	}
		/*else
		{
			
			Iterator itr = CompatibleONTMode.iterator();
		      while(itr.hasNext()) {
		         Object element = itr.next();
		        
		     
				
			if(node.getNodeExtension().getMgmtvlan() != null)
				physicalDeviceBuilder.addResourceDescribedBy("CompatibleONTMode", node.getNodeExtension().getCompatibleont());
		}
		      }*/
	return null;
	
	}

	}


