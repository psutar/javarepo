package com.centurylink.icl.armmediation.service.impl;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.transformation.ARMCLCNotificationTransformation;
import com.centurylink.icl.armmediation.transformation.SearchServiceVOTransformation;
import com.centurylink.icl.builder.util.SearchResourceRequestDocumentHelper;
import com.centurylink.icl.iclnotification.EventNotificationDocument;
import com.centurylink.icl.iclnotification.Parameter;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.ResourceNotificationDocument;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

/**
 * 
Laukik :- Below table shows that how to generate specific notifications for QCtrl based on ICL_CLC_SYNC.
+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------+
| QCtrl Notification |                                                        what to consider from ICL_CLC_SYNC                                                         |
+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------+
| UNI ADD            | Type is "SERVICE",Action is "UPDATE", UpdatedAttribute is "ProvisionStatus",NewValue of updated attribute is "In Service" or "Pending Disconnect" |
| EVC ADD            | Type is "SERVICE",Action is "UPDATE", UpdatedAttribute is "ProvisionStatus",NewValue of updated attribute is "In Service" or "Pending Disconnect" |
| UNI DELETE         | Type is "SERVICE",Action is "DELETE", UpdatedAttribute is "ProvisionStatus",NewValue of updated attribute is "Disconnected"                       |
| EVC DELETE         | Type is "SERVICE",Action is "DELETE", UpdatedAttribute is "ProvisionStatus",NewValue of updated attribute is "Disconnected"                       |
| EVC Member ADD     | Type is "SERVICE",Action is "ASSOCIATE" Associated details are filled and associated type is "SERVICE"                                            |
| EVC Member DELETE  | Type is "SERVICE",Action is "DISSOCIATE" Associated details are filled and associated type is "SERVICE"                                          |
+--------------------+---------------------------------------------------------------------------------------------------------------------------------------------------+
*/

public class QCtrlNotificationsService {

	private static final Log LOG = LogFactory.getLog(QCtrlNotificationsService.class);
	
	public static final String EVC = "MEF EVC";
	public static final String UNI = "MEF UNI";
	public static final String OVC = "MEF OVC";
	public static final String ENNI = "MEF EENI";
	
	private static final String LOCATION = "LOCATION";
	private static final String SERVICE = "SERVICE";
	private static final String UPDATE  = "UPDATE";
	private static final String DELETE  = "DELETE";
	private static final String CREATE = "CREATE";
	
	
	private static final String PROVISION_STATUS = "SERVICE2PROVISIONSTATUS";
	private static final String PENDING_DISCONNECT = "Pending Disconnect";
	private static final String IN_SERVICE = "In Service";
	private static final String DISCONNECTED = "Disconnected";
	private static final String UPDATED_ATTRIBUTE = "UpdatedAttribute";
	private static final String NEW_VALUE = "NewValue";
	private static final String RESOURCE_SUBTYPE = "ResourceSubtype";
	private static final String ASSOCIATE = "ASSOCIATE";
	private static final String DISSOCIATE = "DISSOCIATE";

	

	private ServiceVOService serviceVOService;
	//private SearchCircuitService searchCircuitService;
	private CLCLookupService clcLookupService;
	private EvcMemberNotificationService evcMemberNotificationService;
	
	private static  enum ResourceNotificationType
	{
		UNIADD,
		UNIDELETE,
		EVCADD,
		EVCDELETE,
		EVCMEMBER_ADD,
		EVCMEMBER_DELETE
	}
	
	
	public ResourceNotificationDocument getResourceNotification(String eventAsString) throws Exception
	{
		
			LOG.debug("Generating Notification for " + eventAsString);
			
			EventNotificationDocument event = EventNotificationDocument.Factory.parse(eventAsString);
			String type = event.getEventNotification().getType();
			String action = event.getEventNotification().getAction();
			
			if(SERVICE.equalsIgnoreCase(type))
			{
				ResourceNotificationType resourceNotificationType = getResourceNotificationType(event,action);
				switch (resourceNotificationType) 
				{
					case UNIADD: return ARMCLCNotificationTransformation.transformUNIToResourceNotification(getUNIDetails(event),event,"Add");
					case UNIDELETE: return ARMCLCNotificationTransformation.transformUNIToResourceNotification(getUNIDetails(event),event,"Delete");			
					case EVCADD: return ARMCLCNotificationTransformation.transformEVCToResourceNotification(event, "Add");
					case EVCDELETE: return ARMCLCNotificationTransformation.transformEVCToResourceNotification(event, "Delete");
					case EVCMEMBER_ADD: return ARMCLCNotificationTransformation.transformEvcMemberNotification(getEvcMemberDetails(event,"Add")); 
					case EVCMEMBER_DELETE:return ARMCLCNotificationTransformation.transformEvcMemberNotification(getEvcMemberDetails(event,"Delete"));
					default : 
							//System.out.println(" ******** This event should not be processed for ResourceNotification *********");
							LOG.info(" ******** This event(Type SERVICE) should not be processed for ResourceNotification *********");
							break;
					
				}
			}
			else if(LOCATION.equalsIgnoreCase(type))
			{
				if(CREATE.equalsIgnoreCase(action) || UPDATE.equalsIgnoreCase(action))
				{
					return ARMCLCNotificationTransformation.transformLocationToResourceNotification(getLocationDetails(event), "Add");
				}
				else if(DELETE.equalsIgnoreCase(action))
				{
					return ARMCLCNotificationTransformation.transformLocationToResourceNotification(getLocationDetails(event), "Delete");
				}
			}
			
		
			return null;
		
	}
	
	private SearchResourceResponseDocument getUNIDetails(EventNotificationDocument event) throws Exception
	{
		
		try
		{
			Map<String, String> nvps = new java.util.HashMap<String, String>();
			//nvps.put("Include Relationships", "True");
			nvps.put("INCLUDERELATIONSHIPS", "True");
			nvps.put("ResourceType","UNI");
			nvps.put("IncludeBanFromDVAR","UNI");
			//nvps.put("IncludeCLCLocation","True");
			//nvps.put("IncludeCLCCustomer","True");
			
			
			SearchResourceRequestDocument searchResourceRequest = SearchResourceRequestDocumentHelper.createSearchResourceRequest("CIRCUIT", "CIRCUIT", "DETAILED",
																										"ARM", event.getEventNotification().getCommonName(),
																										event.getEventNotification().getObjectId(), nvps);
			
			VOSearchHolder searchHolder = new VOSearchHolder((SearchResourceRequestDocument) searchResourceRequest);
			return SearchServiceVOTransformation.transformToCIM(serviceVOService.getServices(searchHolder), searchHolder);
			//return (SearchResourceResponseDocument)searchCircuitService.searchCircuitDetails(searchResourceRequest);
		}
		catch(Exception e)
		{
			LOG.error("Could not get UNI Details with UNI="+event.getEventNotification().getCommonName(), e);
			throw e;
		}
			
		
	}
	
	private AmericanPropertyAddress getLocationDetails(EventNotificationDocument event) throws Exception
	{
		try{
			SearchResourceResponseDocument searchResourceResponseDocument = clcLookupService.getServiceAddressById(event.getEventNotification().getObjectId());
			return searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);
		}
		catch(Exception e)
		{
			LOG.error("Location Data not found",e);
			throw e;
		}
	}
	
	
	private ResourceNotificationType getResourceNotificationType(EventNotificationDocument event,String action) throws Exception
	{
		if(UPDATE.equalsIgnoreCase(action) || DELETE.equalsIgnoreCase(action))
		{
			Parameter updatedAttributeParameter = getParameterValue(event, UPDATED_ATTRIBUTE);
			Parameter newValueParameter = getParameterValue(event, NEW_VALUE);
			Parameter resourceSubtypeParameter = getParameterValue(event, RESOURCE_SUBTYPE);
			
			//UNI - EVC - ADD
			if(updatedAttributeParameter != null && PROVISION_STATUS.equalsIgnoreCase(updatedAttributeParameter.getValue()))
			{
				if(UPDATE.equalsIgnoreCase(action)) // UNI - EVC - ADD
				{
					if(newValueParameter != null &&  
							( PENDING_DISCONNECT.equalsIgnoreCase(newValueParameter.getValue()) || IN_SERVICE.equalsIgnoreCase(newValueParameter.getValue())))
					{
						if(resourceSubtypeParameter != null)
						{
							if(UNI.equalsIgnoreCase(resourceSubtypeParameter.getValue())/* || ENNI.equalsIgnoreCase(resourceSubtypeParameter.getValue())*/)
								return ResourceNotificationType.UNIADD;
							else if(/*OVC.equalsIgnoreCase(resourceSubtypeParameter.getValue()) || */EVC.equalsIgnoreCase(resourceSubtypeParameter.getValue()))
								return ResourceNotificationType.EVCADD;	
						}
					}
				}
				else if(DELETE.equalsIgnoreCase(action))
				{
					if(newValueParameter != null && DISCONNECTED.equalsIgnoreCase(newValueParameter.getValue()))
					{
						if(resourceSubtypeParameter != null)
						{
							if(UNI.equalsIgnoreCase(resourceSubtypeParameter.getValue())/* || ENNI.equalsIgnoreCase(resourceSubtypeParameter.getValue())*/)
								return ResourceNotificationType.UNIDELETE;
							else if(/*OVC.equalsIgnoreCase(resourceSubtypeParameter.getValue()) || */EVC.equalsIgnoreCase(resourceSubtypeParameter.getValue()))
								return ResourceNotificationType.EVCDELETE;
						}
					}
				}
			}
		}
		else if(ASSOCIATE.equalsIgnoreCase(action))
		{
			return ResourceNotificationType.EVCMEMBER_ADD;
		}
		else if(DISSOCIATE.equalsIgnoreCase(action))
		{
			return ResourceNotificationType.EVCMEMBER_DELETE;
		}
		
		return null;
	}
	
	
	private SearchResponseDetails getEvcMemberDetails(EventNotificationDocument event,String action) throws Exception
	{
		String uniName = null;
		String evcName = null;
		try
		{
			Parameter associatedService = getParameterValue(event, "AssociatedService");
			
			if(associatedService != null)
			{
				if(UNI.equalsIgnoreCase(associatedService.getType()))
				{
					uniName = associatedService.getValue();
					evcName = event.getEventNotification().getCommonName();  
				}
				else if(EVC.equalsIgnoreCase(associatedService.getType()))
				{
					uniName = event.getEventNotification().getCommonName();
					evcName = associatedService.getValue();
				}
			}
			return evcMemberNotificationService.getEvcMemberNotification(evcName, uniName, action);
		}
		catch(Exception exception)
		{
			LOG.error("Could not get EvcMember details with UNI="+uniName+" and EVC="+evcName, exception);
			throw exception;
		}
	}
	
	
	private static Parameter getParameterValue(EventNotificationDocument event,String parameterName)
	{
		if(event.getEventNotification().getParameterSet() != null && event.getEventNotification().getParameterSet().getParameterList() != null)
		{
			for(Parameter parameter : event.getEventNotification().getParameterSet().getParameterList())
			{
				if(parameterName.equalsIgnoreCase(parameter.getName()))
					return parameter;
			}
		}
		return null;
	}

	public ServiceVOService getServiceVOService() {
		return serviceVOService;
	}

	public void setServiceVOService(ServiceVOService serviceVOService) {
		this.serviceVOService = serviceVOService;
	}

	public CLCLookupService getClcLookupService() {
		return clcLookupService;
	}

	public void setClcLookupService(CLCLookupService clcLookupService) {
		this.clcLookupService = clcLookupService;
	}

	public EvcMemberNotificationService getEvcMemberNotificationService() {
		return evcMemberNotificationService;
	}

	public void setEvcMemberNotificationService(
			EvcMemberNotificationService evcMemberNotificationService) {
		this.evcMemberNotificationService = evcMemberNotificationService;
	}

	
	/*public SearchCircuitService getSearchCircuitService() {
		return searchCircuitService;
	}

	public void setSearchCircuitService(SearchCircuitService searchCircuitService) {
		this.searchCircuitService = searchCircuitService;
	}*/
	
	
	
}
