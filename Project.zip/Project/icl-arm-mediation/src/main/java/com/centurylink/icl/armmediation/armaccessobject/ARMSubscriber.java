package com.centurylink.icl.armmediation.armaccessobject;

public class ARMSubscriber extends ARMObject{


	private String objectId;
	private String commonName;
	private String partyType;
	
	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}
	
	
	
}
