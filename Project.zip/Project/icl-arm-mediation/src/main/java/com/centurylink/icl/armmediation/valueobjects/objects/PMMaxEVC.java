package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class PMMaxEVC extends AbstractReadOnlyTable{

	private static String MONITORING_TYPE="MONITORING_TYPE";
	private static String MAX_NUMBER_OF_EVCS="MAX_NUMBER_OF_EVCS";
	private static String PM_MAX_EVC_ID="PM_MAX_EVC_ID";
	
	public PMMaxEVC()
	{
		super();
		this.tableName = "PM_MAX_EVC";
	}
	
	public PMMaxEVC(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static PMMaxEVC getPmMaxEvcObject(String monitoringType)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(monitoringType))
		{
			query = "UPPER("+MONITORING_TYPE+")" + " = '" +  monitoringType + "'";
			connector = " AND ";
		}
		
		return getPmMaxEvcByQuery(query);
	}

	public static PMMaxEVC getPmMaxEvcByQuery(String query)
	{
		PMMaxEVC pmMaxEvc = new PMMaxEVC();
		List<Map<String,Object>> foundPmMaxEvcList = pmMaxEvc.getRecordsByQuery(query);

		PMMaxEVC workPmMaxEvc=null;
		for (Map<String,Object> pmMaxEvcMap : foundPmMaxEvcList)
		{
			workPmMaxEvc = new PMMaxEVC(pmMaxEvcMap.get(PM_MAX_EVC_ID).toString());
			if(workPmMaxEvc != null)
				return workPmMaxEvc;
		}
		
		return workPmMaxEvc;
	}
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(PM_MAX_EVC_ID, new Field(PM_MAX_EVC_ID, Field.TYPE_NUMERIC));
		fields.put(MONITORING_TYPE, new Field(MONITORING_TYPE, Field.TYPE_VARCHAR));
		fields.put(MAX_NUMBER_OF_EVCS, new Field(MAX_NUMBER_OF_EVCS, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(PM_MAX_EVC_ID));
	}

	public String getMonitoringType() {
		return getFieldAsString(MONITORING_TYPE);
	}

	public void setMonitoringType(String monitoringType) {
		setField(MONITORING_TYPE,monitoringType);
	}

	public String getMaxNumberOfEvcs() {
		return getFieldAsString(MAX_NUMBER_OF_EVCS);
	}

	public void setMaxNumberOfEvcs(String maxNumberOfEvcs) {
		setField(MAX_NUMBER_OF_EVCS,maxNumberOfEvcs);
	}

	public String getPmMaxEvcId() {
		return getFieldAsString(PM_MAX_EVC_ID);
	}

	public void setPmMaxEvcId(String pmMaxEvcId) {
		setField(PM_MAX_EVC_ID,pmMaxEvcId);
	}

}
