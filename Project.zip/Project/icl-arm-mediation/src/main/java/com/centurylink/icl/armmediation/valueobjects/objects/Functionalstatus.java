package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Functionalstatus extends AbstractReadOnlyTable {

	private static final String FUNCTIONALSTATUS2COLOUR = "FUNCTIONALSTATUS2COLOUR";
	private static final String FS2DIMENSIONOBJECT = "FS2DIMENSIONOBJECT";
	private static final String NAME = "NAME";
	private static final String FUNCTIONALSTATUSID = "FUNCTIONALSTATUSID";

	public Functionalstatus()
	{
		super();
		this.tableName = "FUNCTIONALSTATUS";
	}

	public Functionalstatus(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Functionalstatus> getFunctionalstatusListByQuery(String query)
	{
		Functionalstatus functionalstatus = new Functionalstatus();
		List<Functionalstatus> functionalstatusList = new ArrayList<Functionalstatus>();
		List<Map<String,Object>> foundFunctionalstatusList = functionalstatus.getRecordsByQuery(query);

		for (Map<String,Object> functionalstatusMap : foundFunctionalstatusList)
		{
			Functionalstatus workFunctionalstatus = new Functionalstatus(functionalstatusMap.get(FUNCTIONALSTATUSID).toString());
			functionalstatusList.add(workFunctionalstatus);
		}
		return functionalstatusList;
	}

	@Override
	public void populateModel()
	{
		fields.put(FUNCTIONALSTATUS2COLOUR, new Field(FUNCTIONALSTATUS2COLOUR, Field.TYPE_NUMERIC));
		fields.put(FS2DIMENSIONOBJECT, new Field(FS2DIMENSIONOBJECT, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FUNCTIONALSTATUSID, new Field(FUNCTIONALSTATUSID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(FUNCTIONALSTATUSID));
	}

	public void setFunctionalstatus2colour(String functionalstatus2colour)
	{
		setField(FUNCTIONALSTATUS2COLOUR,functionalstatus2colour);
	}

	public String getFunctionalstatus2colour()
	{
		return getFieldAsString(FUNCTIONALSTATUS2COLOUR);
	}

	public void setFs2dimensionobject(String fs2dimensionobject)
	{
		setField(FS2DIMENSIONOBJECT,fs2dimensionobject);
	}

	public String getFs2dimensionobject()
	{
		return getFieldAsString(FS2DIMENSIONOBJECT);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFunctionalstatusid(String functionalstatusid)
	{
		setField(FUNCTIONALSTATUSID,functionalstatusid);
	}

	public String getFunctionalstatusid()
	{
		return getFieldAsString(FUNCTIONALSTATUSID);
	}
}