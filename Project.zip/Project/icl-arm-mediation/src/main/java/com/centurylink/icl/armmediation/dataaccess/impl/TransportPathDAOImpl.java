package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;
import com.centurylink.icl.armmediation.dataaccess.TransportPathDAO;
import com.centurylink.icl.armmediation.helper.Constants;

public class TransportPathDAOImpl implements TransportPathDAO 
{

	private JdbcTemplate jdbcTemplate;

	public TransportPathDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public List<ARMImpactedCircuits> getTransportPathDAO(String query,final Boolean sequenceStatus,final Boolean circuitServiceType)
			throws Exception {
		final List<ARMImpactedCircuits> cktList = this.jdbcTemplate.query(query, new RowMapper<ARMImpactedCircuits>()
				{
			public ARMImpactedCircuits mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMImpactedCircuits armCkt = new ARMImpactedCircuits();
				armCkt.setCommonName(rs.getString(Constants.NAME));
				armCkt.setObjectID(rs.getString("CKT_OBJECTID"));
				armCkt.setCktId(rs.getString(Constants.CIRCUIT_ID));
				armCkt.setCktfullName(rs.getString("FULLNAME"));
				armCkt.setAlias1(rs.getString("ALIAS1"));
				armCkt.setAlias2(rs.getString("ALIAS2"));
				armCkt.setResourceType(rs.getString("CIRCUITTYPE_NAME"));

				armCkt.setCktProvStatus(rs.getString("CKT_PROV_STATUS"));
				armCkt.setCkt2StartNode(rs.getString("CIRCUIT2STARTNODE"));
				armCkt.setCkt2EndNode(rs.getString("CIRCUIT2ENDNODE"));
				armCkt.setStartDeviceName(rs.getString("STARTNODE_NAME"));
				armCkt.setStartDeviceFullName(rs.getString("STARTNODE_FULLNAME"));
				armCkt.setStartDeviceObjectId(rs.getString("STARTNODE_OBJECTID"));
				armCkt.setStartDeviceClli(rs.getString("STARTNODE_CLLI"));
				armCkt.setStartDeviceIpAddress4(rs.getString("STARTNODE_IP"));
				armCkt.setStartDeviceIpAddress6(rs.getString("STARTNODE_IP_1"));
				armCkt.setEndDeviceName(rs.getString("ENDNODE_NAME"));
				armCkt.setEndDeviceFullName(rs.getString("ENDNODE_FULLNAME"));
				armCkt.setEndDeviceObjectId(rs.getString("ENDNODE_OBJECTID"));
				armCkt.setEndDeviceClli(rs.getString("ENDNODE_CLLI"));
				armCkt.setEndDeviceIpAddress4(rs.getString("ENDNODE_IP"));
				armCkt.setEndDeviceIpAddress6(rs.getString("ENDNODE_IP_1"));
				armCkt.setCkt2StartLoc(rs.getString("CIRCUIT2STARTLOCATION"));
				armCkt.setCkt2EndLoc(rs.getString("CIRCUIT2ENDLOCATION"));
				
				armCkt.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCkt.setSubsciberfullname(rs.getString(Constants.FULL_NAME));
				armCkt.setSubscriberId(rs.getString("subscriberId"));
				armCkt.setEmsHostName(rs.getString("NETWORKNAME"));
				/*armCkt.setStartDevicePrStatus(rs.getString("STARTDEVICE_PROV_STATUS"));
				armCkt.setEndDevicePrStatus(rs.getString("ENDDEVICE_PROV_STATUS"));
				armCkt.setDeviceResourceType(rs.getString("NODEDEFNAME"));
				armCkt.setDeviceResourceSubType(rs.getString("NODETYPENAME"));*/
				armCkt.setStartDevicerole(rs.getString("ROLE2"));
				armCkt.setEndDevicerole(rs.getString("ROLE1"));
				
				if(sequenceStatus==true)
				{
					armCkt.setSequence(rs.getString(Constants.SEQUENCE));
					armCkt.setRelatedCktID(rs.getString("TPCKTID"));
				}

				if(circuitServiceType==true)
				{
					armCkt.setCktServiceType(rs.getString("RESOURCETYPE"));
					armCkt.setIsLagMember(rs.getString(Constants.IS_LAG_MEMBER));
				}
			
				return armCkt;
			}
				});

		return cktList;

	}

}
