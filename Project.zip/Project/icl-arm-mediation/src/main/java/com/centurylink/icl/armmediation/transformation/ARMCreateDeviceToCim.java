package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.CreateDeviceResponseBuilder;
import com.centurylink.icl.builder.cim2.CreateDeviceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.PhysicalDevice;

public class ARMCreateDeviceToCim
{
	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final CreateDeviceResponseDocumentBuilder	createDeviceResponseDocumentBuilder;
	private final CreateDeviceResponseBuilder			createDeviceResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;

	public ARMCreateDeviceToCim()
	{
		createDeviceResponseBuilder = new CreateDeviceResponseBuilder();
		createDeviceResponseDocumentBuilder = new CreateDeviceResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
	}

	public CreateDeviceResponseDocument transformErrorToCim(CreateDeviceRequestDocument requestObject, String errorCode, String errorMsg, String errorText)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateDevice : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(requestObject.getCreateDeviceRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());

		createDeviceResponseBuilder.buildCreateDeviceResponse();
		createDeviceResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createDeviceResponseDocumentBuilder.buildCreateDeviceResponseDocument();
		createDeviceResponseDocumentBuilder.addCreateDeviceResponse(createDeviceResponseBuilder.getCreateDeviceResponse());
		return createDeviceResponseDocumentBuilder.getCreateDeviceResponseDocument();

	}

	public CreateDeviceResponseDocument transformToCim(CreateDeviceRequestDocument requestObject, String nodeId, String commonName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateDevice : Transform to CIM");
		}

		final PhysicalDevice physicalDevice = requestObject.getCreateDeviceRequest().getDeviceList().get(0);
		physicalDevice.setObjectID(nodeId);
		physicalDevice.setCommonName(commonName);
		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(requestObject.getCreateDeviceRequest().getMessageElements().getMessageAddressing());

		createDeviceResponseBuilder.buildCreateDeviceResponse();
		createDeviceResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createDeviceResponseBuilder.addDevice(physicalDevice);
		createDeviceResponseDocumentBuilder.buildCreateDeviceResponseDocument();
		createDeviceResponseDocumentBuilder.addCreateDeviceResponse(createDeviceResponseBuilder.getCreateDeviceResponse());
		return createDeviceResponseDocumentBuilder.getCreateDeviceResponseDocument();

	}

}
