package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Parameterset extends AbstractReadOnlyTable {

	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String NOTES = "NOTES";
	private static final String OBJECTID = "OBJECTID";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String ALIAS2 = "ALIAS2";
	private static final String ALIAS1 = "ALIAS1";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String PARAMETERSET2FUNCTIONALSTATUS = "PARAMETERSET2FUNCTIONALSTATUS";
	private static final String PARAMETERSET2PROVISIONSTATUS = "PARAMETERSET2PROVISIONSTATUS";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NAME = "NAME";
	private static final String PARAMETERSET2OBJECT = "PARAMETERSET2OBJECT";
	private static final String PARAMETERSET2DIMOBJECT = "PARAMETERSET2DIMOBJECT";
	private static final String PARAMETERSET2PARAMETERSETTYPE = "PARAMETERSET2PARAMETERSETTYPE";
	private static final String PARAMETERSETID = "PARAMETERSETID";
	
	private Parametersetversion parametersetversion = null;
	
	private List<Parametersetversion> parameteretversionList = null;

	public Parameterset()
	{
		super();
		this.tableName = "PARAMETERSET";
	}

	public Parameterset(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Parameterset> getParametersetListByObjectIdandDimObjectandRelationship(String objectId, String dimObject)
	{

		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(objectId))
		{
			query += connector + PARAMETERSET2OBJECT + " = '" + objectId + "'";
			connector = " AND ";
		}
		if (!StringHelper.isEmpty(dimObject))
		{
			query += connector + PARAMETERSET2DIMOBJECT + " = '" + dimObject + "'";
			connector = " AND ";
		}
		
		return getParametersetListByQuery(query);
	}

	public static List<Parameterset> getParametersetListByQuery(String query)
	{
		Parameterset parameterset = new Parameterset();
		List<Parameterset> parametersetList = new ArrayList<Parameterset>();
		List<Map<String,Object>> foundParametersetList = parameterset.getRecordsByQuery(query);

		for (Map<String,Object> parametersetMap : foundParametersetList)
		{
			Parameterset workParameterset = new Parameterset(parametersetMap.get(PARAMETERSETID).toString());
			parametersetList.add(workParameterset);
		}
		return parametersetList;
	}

	@Override
	public void populateModel()
	{
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(PARAMETERSET2FUNCTIONALSTATUS, new Field(PARAMETERSET2FUNCTIONALSTATUS, Field.TYPE_VARCHAR));
		fields.put(PARAMETERSET2PROVISIONSTATUS, new Field(PARAMETERSET2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(PARAMETERSET2OBJECT, new Field(PARAMETERSET2OBJECT, Field.TYPE_NUMERIC));
		fields.put(PARAMETERSET2DIMOBJECT, new Field(PARAMETERSET2DIMOBJECT, Field.TYPE_NUMERIC));
		fields.put(PARAMETERSET2PARAMETERSETTYPE, new Field(PARAMETERSET2PARAMETERSETTYPE, Field.TYPE_NUMERIC));
		fields.put(PARAMETERSETID, new Field(PARAMETERSETID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PARAMETERSETID));
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setParameterset2functionalstatus(String parameterset2functionalstatus)
	{
		setField(PARAMETERSET2FUNCTIONALSTATUS,parameterset2functionalstatus);
	}

	public String getParameterset2functionalstatus()
	{
		return getFieldAsString(PARAMETERSET2FUNCTIONALSTATUS);
	}

	public void setParameterset2provisionstatus(String parameterset2provisionstatus)
	{
		setField(PARAMETERSET2PROVISIONSTATUS,parameterset2provisionstatus);
	}

	public String getParameterset2provisionstatus()
	{
		return getFieldAsString(PARAMETERSET2PROVISIONSTATUS);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setParameterset2object(String parameterset2object)
	{
		setField(PARAMETERSET2OBJECT,parameterset2object);
	}

	public String getParameterset2object()
	{
		return getFieldAsString(PARAMETERSET2OBJECT);
	}

	public void setParameterset2dimobject(String parameterset2dimobject)
	{
		setField(PARAMETERSET2DIMOBJECT,parameterset2dimobject);
	}

	public String getParameterset2dimobject()
	{
		return getFieldAsString(PARAMETERSET2DIMOBJECT);
	}

	public void setParameterset2parametersettype(String parameterset2parametersettype)
	{
		setField(PARAMETERSET2PARAMETERSETTYPE,parameterset2parametersettype);
	}

	public String getParameterset2parametersettype()
	{
		return getFieldAsString(PARAMETERSET2PARAMETERSETTYPE);
	}

	public void setParametersetid(String parametersetid)
	{
		setField(PARAMETERSETID,parametersetid);
	}

	public String getParametersetid()
	{
		return getFieldAsString(PARAMETERSETID);
	}

	public Parametersetversion getParametersetversion()
	{
		if (parametersetversion == null)
		{
			parametersetversion = Parametersetversion.getParametersetversionByParametersetId(this.getParametersetid());
		}
		
		return parametersetversion;
	}
	
	public List<Parametersetversion> getParametersetversionList()
	{
		if (parameteretversionList == null)
		{
			parameteretversionList = Parametersetversion.getParametersetversionListByQuery("PSETVERSION2PARAMETERSET = '" + getParametersetid() + "'");
		}
		
		return parameteretversionList;
	}

}