package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMPort;
import com.centurylink.icl.armmediation.armaccessobject.PortSyncAuditLog;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.Card;
import com.iclnbi.iclnbiV200.CardOnCardDetails;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.Shelf;
import com.iclnbi.iclnbiV200.Slot;
import com.iclnbi.iclnbiV200.UpdateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.UpdateDeviceResponseDocument;

public class ISYSARMPortSyncAuditLogService {

	private JDBCTempleteUtil jdbcTempleteUtil;
	private static final Log LOG = LogFactory.getLog(ISYSARMPortSyncAuditLogService.class);
	
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}
	
	public UpdateDeviceResponseDocument doAuditLogEntry(UpdateDeviceResponseDocument updateDeviceResponseDocument,Map<String, Object> map) throws Exception
	{
		String responseAction = null;
		String replyTo = null;
		String errorTextMessage = null;
		
		LOG.info(" \n ***Response Recieved for Audit Logging*** \n"+updateDeviceResponseDocument);
		
		if(updateDeviceResponseDocument != null 
				&& updateDeviceResponseDocument.getUpdateDeviceResponse() != null 
				&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements() != null
				&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageAddressing()!=null)
		{
			LOG.info(" \n Message Elements in Response \n"+updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements());
				replyTo = updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageAddressing().getReplyTo();
				responseAction = updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageAddressing().getAction();
				LOG.info("replyTo tag  :"+replyTo+" responseAction: "+ responseAction);
		}
		
		
		if(map.get("PORTSTATUS") != null){
			PortSyncAuditLog auditLog = new PortSyncAuditLog();
			List<ARMPort> consumedPortsList = new ArrayList<ARMPort>(10);
			List<ARMPort> releasePortsList = new ArrayList<ARMPort>(10);
			LOG.info("PORTSTATUS  : "+map.get("PORTSTATUS")+"  PORT_NAME :"+map.get("PORT_NAME")+"  DEVICE_NAME :"+map.get("DEVICE_NAME"));
			ARMPort armPort = new ARMPort();
			if(map.get("PORT_NAME") != null){
			armPort.setCommonName((String)map.get("PORT_NAME"));
			}
			String responseStatus = null;
			if(updateDeviceResponseDocument != null 
					&& updateDeviceResponseDocument.getUpdateDeviceResponse() != null 
					&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements() != null
					&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageStatus()!=null)
			{
				responseStatus = updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageStatus();
				armPort.setStatus(responseStatus);
			}
			
			if(StringHelper.isEmpty(responseStatus)){
				
				int index = 1;				
				Pattern pattern = Pattern.compile("<messageStatus>(.+?)</messageStatus>"); 
				Matcher matcher = pattern.matcher(updateDeviceResponseDocument.toString());
				matcher.find();
				if (!StringHelper.isEmpty(matcher.group(index)))
				{
					armPort.setStatus(matcher.group(index));
					if (StringHelper.isEqualIgnoreCase(armPort.getStatus(), "FAIL"))
					{
						index = 1;
						pattern = Pattern.compile("<ErrorText>(.+?)</ErrorText>"); 
						matcher = pattern.matcher(updateDeviceResponseDocument.toString());
						matcher.find();
						if (!StringHelper.isEmpty(matcher.group(index)))
						{
							errorTextMessage = matcher.group(index);
						}
					}
				}
				else
					armPort.setStatus("NOT KNOWN");				
			}
					
			//Prateek:segregates as per the response received after MDW processing
			if(((String)map.get("PORTSTATUS")).equalsIgnoreCase("Configured") || ((String)map.get("PORTSTATUS")).equalsIgnoreCase("In Service")){
					consumedPortsList.add(armPort);
					auditLog.setConsumedPorts(consumedPortsList);
			}
			if(((String)map.get("PORTSTATUS")).equalsIgnoreCase("Planned")){
					releasePortsList.add(armPort);
					auditLog.setReleasedProts(releasePortsList);
			}
			
			if(replyTo != null )
			{
					auditLog.setRequestedFrom(replyTo);
			}
			else{
				auditLog.setRequestedFrom("ISYS");
			}
			if(map.get("DEVICE_NAME") != null){
			auditLog.setDeviceName( (String)map.get("DEVICE_NAME"));
			}
			auditLog.setTime(new Date()+"");
			auditLog.setPrStatus((String)map.get("PORTSTATUS"));
			insertAuditLogInDb(auditLog,"ISYS", errorTextMessage);
			
			return updateDeviceResponseDocument;
			
		}
		
	if(responseAction != null){
		
		if(isErrorResponse(updateDeviceResponseDocument))
		{
			List<ARMPort> consumedPortsList = new ArrayList<ARMPort>(10);
			List<ARMPort> releasePortsList = new ArrayList<ARMPort>(10);
		//	String request1 = "<icl:UpdateDeviceResponse xmlns:icl='http://www.ICLNBI.com/ICLNBI_V2.00.xsd'><MessageElements><messageStatus>FAILURE</messageStatus><messageType/><ErrorList><ErrorCode>1947</ErrorCode><ErrorMessage>ICLInternalError</ErrorMessage><SourceSystem>ICL</SourceSystem><ErrorStatus>FAILED</ErrorStatus><ErrorText>com.centurylink.icl.arm.exception.ARMException: Reservation Not Found</ErrorText></ErrorList><MessageAddressing><to>ICL</to><replyTo>DSP</replyTo><messageID>DSP1396861049925</messageID><action>UpdateDevice</action><timestamp>Mon Apr 07 14:27:29 IST 2014</timestamp><transactionID>1396861049925</transactionID><serviceName>UpdateDevice</serviceName><serviceVersion>3.0</serviceVersion><password>********</password></MessageAddressing></MessageElements></icl:UpdateDeviceResponse>";
			if(map.get("UpdateDeviceRequestPortSync") != null && map.get("UpdateDeviceRequestPortSync") instanceof UpdateDeviceRequestDocument)
			{
				UpdateDeviceRequestDocument request = (UpdateDeviceRequestDocument)map.get("UpdateDeviceRequestPortSync");
				String deviceName = request.getUpdateDeviceRequest().getDevice().getCommonName();
				PhysicalDevice device = request.getUpdateDeviceRequest().getDevice();
				if(device != null)
				{

					//Get Device Level Ports
					if(device.getHasPortsList() != null && device.getHasPortsList().size() > 0)
					{
						List<PhysicalPort> portsList = device.getHasPortsList();
						if(portsList != null && portsList.size()>0)
						{
							for (PhysicalPort physicalPort : portsList) {
								
								List<ResourceCharacteristicValue> describedByList = physicalPort.getResourceDescribedByList();
								String reservationId = getResourceCharactristicValue("ReservationID", describedByList);
								String reservationNeeded = getResourceCharactristicValue("ReservationNeeded", describedByList);
								if(!StringHelper.isEmpty(reservationId))
								{
									ARMPort armPort = new ARMPort();
									armPort.setCommonName(physicalPort.getCommonName());
									armPort.setStatus("FAILURE");
									consumedPortsList.add(armPort);
								}
								//else if(StringHe)
							}
						}
						
					}
					
					//Get Card Level Ports 
					if(device.getConsistsOfShelfList() != null && device.getConsistsOfShelfList().size()>0)
					{
						List<Shelf> shelfList = device.getConsistsOfShelfList();
						for (Shelf shelf : shelfList) {  //Shelf
							
							if(shelf  != null && shelf.getConsistsOfSlotList() != null && shelf.getConsistsOfSlotList().size() > 0)
							{
								List<Slot> slotList = shelf.getConsistsOfSlotList();
								for (Slot slot : slotList) { //Slot
									
									//Card
									if(slot != null && slot.getHasCard() != null && slot.getHasCard().getPhysicalPortList() != null && slot.getHasCard().getPhysicalPortList().size() > 0)
									{
										for (PhysicalPort physicalPort : slot.getHasCard().getPhysicalPortList()) { //Port
											
											if(physicalPort != null && physicalPort.getResourceDescribedByList() != null)
											{
												String reservationId = getResourceCharactristicValue("ReservationID", physicalPort.getResourceDescribedByList());
												
												if(!StringHelper.isEmpty(reservationId))
												{
													ARMPort armPort = new ARMPort();
													armPort.setCommonName(physicalPort.getCommonName());
													armPort.setStatus("FAILURE");//Prateek: Changed it to  FAILURE from success
													consumedPortsList.add(armPort);
													
												}
												
											}
										}
									}
								}
							}
							
						}
					}
					
				
				}
			}
		}
		else
		{
			return doAuditLogForSuccessResposne(updateDeviceResponseDocument, map);
		}
	}
		return updateDeviceResponseDocument;
	}
	
	
	private UpdateDeviceResponseDocument doAuditLogForFailureResponse(UpdateDeviceResponseDocument updateDeviceResponseDocument,Map<String, Object> map) throws Exception
	{
		return updateDeviceResponseDocument;
	}
	private  UpdateDeviceResponseDocument doAuditLogForSuccessResposne(UpdateDeviceResponseDocument updateDeviceResponseDocument,Map<String, Object> map) throws Exception
	{
		try {
			

			PortSyncAuditLog auditLog = new PortSyncAuditLog();
			
			List<ARMPort> consumedPortsList = new ArrayList<ARMPort>(10);
			List<ARMPort> releasePortsList = new ArrayList<ARMPort>(10);
			String deviceName = (String)map.get("DEVICE_NAME");
			String portAliasName = null;
			String portObjectId = null;
			
			PhysicalDevice device = updateDeviceResponseDocument.getUpdateDeviceResponse().getDevice();
			
			if(device != null)
			{
				//Get Device Level Ports
				if(device.getHasPortsList() != null && device.getHasPortsList().size() > 0)
				{
					List<PhysicalPort> portsList = device.getHasPortsList();
					if(portsList != null && portsList.size()>0)
					{
						
						for (PhysicalPort physicalPort : portsList) {
							LOG.info("### Device Level Ports prStatus : "+physicalPort.getPrStatus());
							auditLog.setPrStatus(physicalPort.getPrStatus());
							List<ResourceCharacteristicValue> describedByList = physicalPort.getResourceDescribedByList();
							String reservationId = getResourceCharactristicValue("ReservationID", describedByList);
							String reservationNeeded = getResourceCharactristicValue("ReservationNeeded",describedByList);
							String reservationExist = getResourceCharactristicValue("ReservationExist", describedByList);
							if(!StringHelper.isEmpty(reservationId)  || reservationExist != null || !StringHelper.isEmpty(reservationExist))
							{
								ARMPort armPort = new ARMPort();
								/*Prateek : Added the block for checking port common name/alias name*/
								if(physicalPort.getCommonName() != null){
								armPort.setCommonName(physicalPort.getCommonName());
								}
								else if(physicalPort.getCommonName() == null && physicalPort.getObjectID() != null){
									portAliasName = physicalPort.getAliasName();	
									portObjectId =  physicalPort.getObjectID().toString();
									armPort.setCommonName(getPortName(portAliasName,deviceName,portObjectId));
								}
								else{
									portAliasName = physicalPort.getAliasName();	
									armPort.setCommonName(getPortName(portAliasName,deviceName));
								}
								
								armPort.setStatus("SUCCESS");
								//Prateek:segregates as per the response received after MDW processing
								if(reservationNeeded != null || !StringHelper.isEmpty(reservationNeeded)){
									if(reservationNeeded.equalsIgnoreCase("TRUE")){
										consumedPortsList.add(armPort);
									}
								}
								if(reservationExist != null || !StringHelper.isEmpty(reservationExist)){
									if(reservationExist.equalsIgnoreCase("False")){
										releasePortsList.add(armPort);
									}
								}
							}
						}
					}
					
				}
				
				//Get Card Level Ports 
				if(device.getConsistsOfShelfList() != null && device.getConsistsOfShelfList().size()>0)
				{
					List<Shelf> shelfList = device.getConsistsOfShelfList();
					for (Shelf shelf : shelfList) {  //Shelf
						
						if(shelf  != null && shelf.getConsistsOfSlotList() != null && shelf.getConsistsOfSlotList().size() > 0)
						{
							List<Slot> slotList = shelf.getConsistsOfSlotList();
							for (Slot slot : slotList) { //Slot
								
								//Card
								if(slot != null && slot.getHasCard() != null && slot.getHasCard().getPhysicalPortList() != null && slot.getHasCard().getPhysicalPortList().size() > 0)
								{
									for (PhysicalPort physicalPort : slot.getHasCard().getPhysicalPortList()) { //Port
										
										if(physicalPort != null && physicalPort.getResourceDescribedByList() != null)
										{
											LOG.info("### Card Level Ports prStatus : "+physicalPort.getPrStatus());
											auditLog.setPrStatus(physicalPort.getPrStatus());
											String reservationId = getResourceCharactristicValue("ReservationID", physicalPort.getResourceDescribedByList());
											String reservationNeeded = getResourceCharactristicValue("ReservationNeeded",physicalPort.getResourceDescribedByList());
											String reservationExist = getResourceCharactristicValue("ReservationExist", physicalPort.getResourceDescribedByList());
											if(!StringHelper.isEmpty(reservationId) || reservationExist != null || !StringHelper.isEmpty(reservationExist))
											{
												ARMPort armPort = new ARMPort();
												/*Prateek : Added the block for checking port common name/alias name*/
												if(physicalPort.getCommonName() != null){
												armPort.setCommonName(physicalPort.getCommonName());
												}
												else if(physicalPort.getCommonName() == null && physicalPort.getObjectID() != null){
													portAliasName = physicalPort.getAliasName();	
													portObjectId =  physicalPort.getObjectID().toString();
													armPort.setCommonName(getPortName(portAliasName,deviceName,portObjectId));
												}
												else{
													portAliasName = physicalPort.getAliasName();	
													armPort.setCommonName(getPortName(portAliasName,deviceName));
												}
												
												armPort.setStatus("SUCCESS");
												//Prateek:segregates as per the response received after MDW processing
												if(reservationNeeded != null || !StringHelper.isEmpty(reservationNeeded)){
													if(reservationNeeded.equalsIgnoreCase("TRUE")){
														consumedPortsList.add(armPort);
													}
												}
												if(reservationExist != null || !StringHelper.isEmpty(reservationExist)){
													if(reservationExist.equalsIgnoreCase("False")){
														releasePortsList.add(armPort);
													}
												}
												
											}
											
										}
									}
								}
							}
						}
						
					}
				}
				
				//get card on card port
				if(device.getConsistsOfShelfList() != null && device.getConsistsOfShelfList().size()>0)
				{
					List<Shelf> shelfList = device.getConsistsOfShelfList();
					for (Shelf shelf : shelfList) {  //Shelf
						
						if(shelf  != null && shelf.getConsistsOfSlotList() != null && shelf.getConsistsOfSlotList().size() > 0)
						{
							List<Slot> slotList = shelf.getConsistsOfSlotList();
							for (Slot slot : slotList) { //Slot
								
								//Card 
								if(slot != null && slot.getHasCard() != null && slot.getHasCard().getCardOnCardDetailsList() != null && slot.getHasCard().getCardOnCardDetailsList().size() > 0)
								{
								
									for(CardOnCardDetails cardOnCard: slot.getHasCard().getCardOnCardDetailsList()) { //cardoncard
									
								if(cardOnCard != null && cardOnCard.getCardList() != null && cardOnCard.getCardList() != null && cardOnCard.getCardList().size() > 0)
								{
									for(Card card : cardOnCard.getCardList() ){//card
										if(card != null && card.getPhysicalPortList() != null && card.getPhysicalPortList().size() > 0)	
											for (PhysicalPort physicalPort : card.getPhysicalPortList()) { //Port
										
												if(physicalPort != null && physicalPort.getResourceDescribedByList() != null)
													{
														LOG.info("### Card on Card port prStatus : "+physicalPort.getPrStatus());
														auditLog.setPrStatus(physicalPort.getPrStatus());
														String reservationId = getResourceCharactristicValue("ReservationID", physicalPort.getResourceDescribedByList());
														String reservationNeeded = getResourceCharactristicValue("ReservationNeeded",physicalPort.getResourceDescribedByList());
														String reservationExist = getResourceCharactristicValue("ReservationExist", physicalPort.getResourceDescribedByList());
														if(!StringHelper.isEmpty(reservationId) || reservationExist != null || !StringHelper.isEmpty(reservationExist))
														{
															ARMPort armPort = new ARMPort();
															/*Prateek : Added the block for checking port common name/alias name*/
															if(physicalPort.getCommonName() != null){
															armPort.setCommonName(physicalPort.getCommonName());
															}
															else if(physicalPort.getCommonName() == null && physicalPort.getObjectID() != null){
																portAliasName = physicalPort.getAliasName();	
																portObjectId =  physicalPort.getObjectID().toString();
																armPort.setCommonName(getPortName(portAliasName,deviceName,portObjectId));
															}
															else{
																portAliasName = physicalPort.getAliasName();	
																armPort.setCommonName(getPortName(portAliasName,deviceName));
															}
															
															armPort.setStatus("SUCCESS");
															//Prateek:segregates as per the response received after MDW processing
															if(reservationNeeded != null || !StringHelper.isEmpty(reservationNeeded)){
																if(reservationNeeded.equalsIgnoreCase("TRUE")){
																	consumedPortsList.add(armPort);
																}
															}
															if(reservationExist != null || !StringHelper.isEmpty(reservationExist)){
																if(reservationExist.equalsIgnoreCase("False")){
																	releasePortsList.add(armPort);
																}
															}
															
														}
														
													}
												}
											}
										}
									}
								}
							}
						}
					}
			}
			
			}
				
			
			
			if(updateDeviceResponseDocument != null 
					&& updateDeviceResponseDocument.getUpdateDeviceResponse() != null 
					&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements() != null
					&& updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageAddressing()!=null)
			{
					auditLog.setRequestedFrom(updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageAddressing().getReplyTo());
			}
			//auditLog.setDeviceName(device.getCommonName());
			if(map.get("DEVICE_NAME") != null){
				auditLog.setDeviceName((String)map.get("DEVICE_NAME"));
				}else{
					auditLog.setDeviceName("null");	
				}
			auditLog.setConsumedPorts(consumedPortsList);
			auditLog.setReleasedProts(releasePortsList);
			auditLog.setTime(new Date()+"");
			LOG.info("getPrStatus()  :"+auditLog.getPrStatus());
			
			insertAuditLogInDb(auditLog,"ARM", null);
			
			return updateDeviceResponseDocument;
		
			
		} catch (Exception e) {
		
			LOG.error("Port Sync error while from ARM Mediation", e);
			throw new ICLException("Excpetion in process of port sync");
			
		}
	}
	
	private String getResourceCharactristicValue(String name,List<ResourceCharacteristicValue> describedByList)
	{
		for (ResourceCharacteristicValue resourceCharacteristicValue : describedByList) {
			
			if(name.equalsIgnoreCase(resourceCharacteristicValue.getCharacteristicName()))
				return resourceCharacteristicValue.getCharacteristicValue();
		}
		return null;
	}
	
 public List<Map<String, String>> checkInAuditLog(Object requestObject, HashMap<String, Object> map){
		
	 List<Map<String, String>> auditLogDetails = new ArrayList<Map<String,String>>();
		String portName = (String)map.get("PORT_NAME");
		String deviceName = (String)map.get("DEVICE_NAME");
		try {
			if(!StringHelper.isEmpty(portName) && !StringHelper.isEmpty(deviceName)){
				auditLogDetails = jdbcTempleteUtil.query("SELECT USERNAME FROM ARM_LOGGING.PORT_SYNC_AUDIT_LOG WHERE PORT_NAME='"+portName+"' AND DEVICE_NAME='"+deviceName+"' ORDER BY SYNC_TIME DESC");
			}		
			} catch (Exception e) {
					LOG.error("Could not search record into Audit Log table", e);	
				}
		return auditLogDetails;
	}
	
	private void insertAuditLogInDb(PortSyncAuditLog auditLog,String consumer, String errorTextMessage)
	{
		String query = "INSERT INTO   VALUES(?,?,?,?,?,?)";
		 // define query arguments
		if(auditLog != null && auditLog.getConsumedPorts() != null && auditLog.getConsumedPorts().size() > 0)
		{
			List<ARMPort> consumedPorts = auditLog.getConsumedPorts();
			for (ARMPort armPort : consumedPorts) {
				String description = null;
				if(armPort.getStatus()!=null && armPort.getStatus().equalsIgnoreCase("SUCCESS")){
				 description = auditLog.getDeviceName()+","+armPort.getCommonName()+" Status in "+consumer+" successfully changed to "+auditLog.getPrStatus();
				}
				else if(armPort.getStatus()!=null && armPort.getStatus().equalsIgnoreCase("NOT KNOWN")){
					 description = "NOT KNOWN";
				}
				else{
					if (StringHelper.isEmpty(errorTextMessage))
						description = "FAILURE";
					else
					 description = errorTextMessage;
				}
				Map<String, String> columnNameAndValues = new HashMap<String, String>();
				columnNameAndValues.put("DEVICE_NAME",  auditLog.getDeviceName());
				columnNameAndValues.put("PORT_NAME", armPort.getCommonName());
				columnNameAndValues.put("STATUS", armPort.getStatus());
				columnNameAndValues.put("DESCRIPTION", description);
				columnNameAndValues.put("USERNAME", auditLog.getRequestedFrom());
				columnNameAndValues.put("SYNC_TIME","sysdate");
				columnNameAndValues.put("PORT_STATUS", auditLog.getPrStatus());
				try {
					
					jdbcTempleteUtil.executeUpdate(buildInsertQuery("ARM_LOGGING.PORT_SYNC_AUDIT_LOG",columnNameAndValues));
					
					
				} catch (Exception e) {
					
					LOG.error("Could not insert record into Audit Log table", e);
					
				}
			}
			
		}
		//Prateek: Inserts the released ports into the DB
		if(auditLog != null && auditLog.getReleasedProts() != null && auditLog.getReleasedProts().size() > 0){

			List<ARMPort> releasedPorts = auditLog.getReleasedProts();
			for (ARMPort armPort : releasedPorts) {
				String description = null;
				//String description = auditLog.getDeviceName()+","+armPort.getCommonName()+" Status in ARM successfully changed from Configured to planned";
				if(armPort.getStatus().equalsIgnoreCase("SUCCESS")){
					 description = auditLog.getDeviceName()+","+armPort.getCommonName()+" Status in "+consumer+" successfully changed to planned";
					}
					else{
						if (StringHelper.isEmpty(errorTextMessage))
							description = "FAILURE";
						else
						 description = errorTextMessage;
					}
				
				Map<String, String> columnNameAndValues = new HashMap<String, String>();
				columnNameAndValues.put("DEVICE_NAME",  auditLog.getDeviceName());
				columnNameAndValues.put("PORT_NAME", armPort.getCommonName());
				columnNameAndValues.put("STATUS", armPort.getStatus());
				columnNameAndValues.put("DESCRIPTION", description);
				columnNameAndValues.put("USERNAME", auditLog.getRequestedFrom());
				columnNameAndValues.put("SYNC_TIME","sysdate");
				columnNameAndValues.put("PORT_STATUS", "planned");
				try {
					
					jdbcTempleteUtil.executeUpdate(buildInsertQuery("ARM_LOGGING.PORT_SYNC_AUDIT_LOG",columnNameAndValues));
					
					
				} catch (Exception e) {
					
					LOG.error("Could not insert record into Audit Log table", e);
					
				}
			}
			
		}

	}
	
	private boolean isErrorResponse(UpdateDeviceResponseDocument updateDeviceResponseDocument)
	{
		return !"SUCCESS".equalsIgnoreCase(updateDeviceResponseDocument.getUpdateDeviceResponse().getMessageElements().getMessageStatus());
	}
	
	private String buildInsertQuery(String tableName,Map<String, String> columnNameAndValues)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(tableName);
		Set<String> keySet = columnNameAndValues.keySet();
		for (String columnName : keySet) {
			
			if("SYNC_TIME".equalsIgnoreCase(columnName))
			{
				sqlBuilder.addField(columnName);
				sqlBuilder.addValuesNotAsString(columnNameAndValues.get(columnName));
			}
			else
			{
				sqlBuilder.addField(columnName);
				sqlBuilder.addValues(columnNameAndValues.get(columnName));
			}
		}
		LOG.info("Insert Query for audit LOG:::::::::::::"+sqlBuilder.getInsertStatement());
		return  sqlBuilder.getInsertStatement();
	}
	
	private String buildSearchQuery(String tableName,List<String> columnNames){
		SQLBuilder sqlBuilder = new SQLBuilder(tableName);
		for (String columnName : columnNames) {
				sqlBuilder.addField(columnName);
		}
		LOG.info("Search Query for audit LOG:::::::::::::"+sqlBuilder.getStatement());
		return  sqlBuilder.getStatement();
	}
	/*This method is used to fetch the port name in case of alias name comes in Response*/
	 private String getPortName(String portAliasName,String deviceName){
		 String portName = null;
		 List<Map<String, String>> portNameDetails = new ArrayList<Map<String,String>>();
		  String query ="select p.name from node n, port p "+
				 " where p.port2node= n.nodeid "+
				 " and n.name='"+deviceName+"' "+
				 " and p.alias1='"+portAliasName+"' ";
		 portNameDetails = jdbcTempleteUtil.query(query);
		 Map<String,String> portRecordMap = portNameDetails.get(0);
		 portName = portRecordMap.get("NAME").toString();
		 return portName;
	 }
	 
	 private String getPortName(String portAliasName,String deviceName,String portObjectId){
		 String portName = null;
		 List<Map<String, String>> portNameDetails = new ArrayList<Map<String,String>>();
		  String query ="select p.name from node n, port p "+
				 " where p.port2node= n.nodeid "+
				 " and n.name='"+deviceName+"' "+
				 " and p.alias1='"+portAliasName+"' "+
				 " and p.portid='"+portObjectId+"' " ;
		 portNameDetails = jdbcTempleteUtil.query(query);
		 Map<String,String> portRecordMap = portNameDetails.get(0);
		 portName = portRecordMap.get("NAME").toString();
		 return portName;
	 }
}
