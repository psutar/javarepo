package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.dataaccess.DimensionObjectDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.SetProvisionStatus;

public class UpdateProvisionStatus
{

	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private DimensionObjectDAO dimensionObjectDAO;
	private SetProvisionStatus setProvisionStatus;

	public Map<String, Object> updateProvisionStatus(HashMap<String, Object> iHashMap)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Updating Provision Status");
		}

		final String object = MediationUtil.getValueFromMap(iHashMap, MDWConstants.DIM_OBJECT);
		final String objectId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.OBJECT_ID);
		final String statusId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.STATUS_ID);
		final BigDecimal dimObjectId = dimensionObjectDAO.getDimensionObjectID(object);
		final Map<String, Object> map = (HashMap<String, Object>) setProvisionStatus.execute(dimObjectId, new BigDecimal(objectId), new BigDecimal(statusId));
		final BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			iHashMap.put(MDWConstants.errorCode, o_ErrorCode);
			iHashMap.put(MDWConstants.errorMessage, o_Errormsg);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
		} else
		{
			iHashMap.put(MDWConstants.errorCode, new Integer(0));
		}
		return iHashMap;
	}

	public void setDimensionObjectDAO(DimensionObjectDAO dimensionObjectDAO)
	{
		this.dimensionObjectDAO = dimensionObjectDAO;
	}

	public void setSetProvisionStatus(SetProvisionStatus setProvisionStatus)
	{
		this.setProvisionStatus = setProvisionStatus;
	}

}
