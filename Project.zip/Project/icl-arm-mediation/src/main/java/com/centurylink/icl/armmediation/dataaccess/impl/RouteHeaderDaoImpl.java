package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;
import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;
import com.centurylink.icl.armmediation.dataaccess.RouteDetailDAO;
import com.centurylink.icl.armmediation.dataaccess.RouteHeaderDAO;

public class RouteHeaderDaoImpl implements RouteHeaderDAO {
	
	private JdbcTemplate jdbcTemplate;
	private static final String INSERT_SQL = "INSERT INTO ROUTE_HEADER (ROUTE_NAME, NID_DEVICE_NAME) VALUES (?, ?)";
	private static final String LOOKUP_ROUTE_HEADER_ID_BY_ROUTE_NAME = "SELECT ROUTE_HEADER_ID from ROUTE_HEADER WHERE ROUTE_NAME=?";
	private static final String LOOKUP_ROUTE_NAMES_BY_LIKE_ROUTE_NAME = "SELECT ROUTE_NAME from ROUTE_HEADER WHERE ROUTE_NAME LIKE ?";
	private static final String LOOKUP_ROUTE_BY_ID = "SELECT * FROM ROUTE_HEADER WHERE ROUTE_HEADER_ID = ?";
	private static final String LOOKUP_ROUTE_BY_NID = "SELECT * FROM ROUTE_HEADER WHERE NID_DEVICE_NAME = ? AND ROWNUM=1";
	private static final String LOOKUP_ROUTES_BY_NID = "SELECT * FROM ROUTE_HEADER WHERE NID_DEVICE_NAME = ?";
	private static final String LOOKUP_ROUTES_BY_ROUTE_NAME = "Select * from ROUTE_HEADER where ROUTE_NAME = ?";
	private static final String DELETE_ROUTE_BY_ID = "DELETE FROM ROUTE_HEADER WHERE ROUTE_HEADER_ID = ?";
	private static final String UPDATE_ROUTE_NAME_BY_ID = "UPDATE ROUTE_HEADER SET ROUTE_NAME=? WHERE ROUTE_HEADER_ID=?";
	private static final String UPDATE_ROUTE_BY_ID = "UPDATE ROUTE_HEADER SET ROUTE_NAME=?, NID_DEVICE_NAME=? WHERE ROUTE_HEADER_ID=?";
///	private static final String LOOKUP_ROUTES_BY_LIKE_ROUTE_NAME = "Select * from ROUTE_HEADER where ROUTE_NAME LIKE ?";
	
	private static final String ROUTE_NAME = "ROUTE_NAME";
	private static final String ROUTE_HEADER_ID = "ROUTE_HEADER_ID";
	private static final String NID_DEVICE_NAME = "NID_DEVICE_NAME";
	
	public RouteHeaderDaoImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public void insert(RouteHeader routeHeader) {
		this.jdbcTemplate.update(INSERT_SQL, new Object[] {routeHeader.getRouteName(), routeHeader.getNidDeviceName()});
	}
	
	@Override
	public Long getRouteHeaderId(String routeName)
	{
		try
		{
			return this.jdbcTemplate.queryForLong(LOOKUP_ROUTE_HEADER_ID_BY_ROUTE_NAME, new Object[] {routeName});
		}
		catch (EmptyResultDataAccessException e)
		{
			return null;
		}
	}
	
	@Override
	public List<String> getLikeRouteNames(String routeName)
	{
		List<String> routeNameList = this.jdbcTemplate.query(LOOKUP_ROUTE_NAMES_BY_LIKE_ROUTE_NAME, new Object[] {routeName + "%"},
				new RowMapper<String>()
				{
					@Override
					public String mapRow(ResultSet rs, int rowNum) throws SQLException {
						return rs.getString(ROUTE_NAME);
					}
				});
		
		return routeNameList;
	}
	
	@Override
	public RouteHeader lookupRouteHeaderWithoutDetails(Long routeHeaderId)
	{
		try
		{
			return this.jdbcTemplate.queryForObject(LOOKUP_ROUTE_BY_ID, new Object [] {routeHeaderId}, new RouteHeaderMapper());
		}
		catch(EmptyResultDataAccessException exp)
		{
			return null;			
		}
	}
	
	@Override
	public RouteHeader lookupRouteHeaderWithoutDetails(String routeName)
	{
		try
		{
			return this.jdbcTemplate.queryForObject(LOOKUP_ROUTES_BY_ROUTE_NAME, new Object [] {routeName}, new RouteHeaderMapper());
		}
		catch(EmptyResultDataAccessException exp)
		{
			return null;			
		}
	}
	
	@Override
	public RouteHeader lookupRouteByNidDeviceName(String nidDeviceName, RouteDetailDAO routeDetailDao)
	{
		try
		{
			RouteHeader routeHeader =  this.jdbcTemplate.queryForObject(LOOKUP_ROUTE_BY_NID, new Object [] {nidDeviceName}, new RouteHeaderMapper());
			
			List<RouteDetail> routeDetailList = routeDetailDao.lookupRouteDetailByRouteHeaderId(routeHeader.getRouteHeaderId());
			routeHeader.setRouteDetailList(routeDetailList);
			
			return routeHeader;
		}
		catch(EmptyResultDataAccessException exp)
		{
			return null;			
		}
	}
	
	@Override
	public List<RouteHeader> searchRouteByNid(String nidDeviceName, RouteDetailDAO routeDetailDao)
	{
		List <RouteHeader> routeHeaderList = this.jdbcTemplate.query(LOOKUP_ROUTES_BY_NID, new Object [] {nidDeviceName}, new RouteHeaderMapper());
		for (RouteHeader routeHeader : routeHeaderList)
			routeHeader.setRouteDetailList(routeDetailDao.lookupRouteDetailByRouteHeaderId(routeHeader.getRouteHeaderId()));
		
		return routeHeaderList;
	}
	
	@Override
	public List<RouteHeader> lookupRouteHeaderWithDetails(String routeName, RouteDetailDAO routeDetailDao)
	{
		List <RouteHeader> routeHeaderList = this.jdbcTemplate.query(LOOKUP_ROUTES_BY_ROUTE_NAME, new Object [] {routeName}, new RouteHeaderMapper());
		for (RouteHeader routeHeader : routeHeaderList)
			routeHeader.setRouteDetailList(routeDetailDao.lookupRouteDetailByRouteHeaderId(routeHeader.getRouteHeaderId()));
		
		return routeHeaderList;
	}
	
	@Override
	public void delete(Long routeHeaderId)
	{
		this.jdbcTemplate.update(DELETE_ROUTE_BY_ID, new Object[] {routeHeaderId});
	}
	
	@Override
	public void updateRouteName(String routeName, Long routeHeaderId)
	{
		this.jdbcTemplate.update(UPDATE_ROUTE_NAME_BY_ID, new Object[] {routeName, routeHeaderId});
	}
	
	@Override
	public void update(String routeName, String nidDeviceName, Long routeHeaderId)
	{
		this.jdbcTemplate.update(UPDATE_ROUTE_BY_ID, new Object[] {routeName, nidDeviceName, routeHeaderId});
	}
	private class RouteHeaderMapper implements RowMapper<RouteHeader>
	{
		@Override
		public RouteHeader mapRow(ResultSet rs, int rowNum) throws SQLException {
			RouteHeader routeHeader = new RouteHeader();
			routeHeader.setRouteHeaderId(rs.getLong(ROUTE_HEADER_ID));
			routeHeader.setRouteName(rs.getString(ROUTE_NAME));
			routeHeader.setNidDeviceName(rs.getString(NID_DEVICE_NAME));
			
			return routeHeader;
		}
	}
}
