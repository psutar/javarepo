package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Provisionstatus extends AbstractReadOnlyTable {

	private static final String ISDEFAULT = "ISDEFAULT";
	private static final String CHANGETOCALLOUT = "CHANGETOCALLOUT";
	private static final String CHANGEFROMCALLOUT = "CHANGEFROMCALLOUT";
	private static final String PROVISIONSTATUS2METASTATUS = "PROVISIONSTATUS2METASTATUS";
	private static final String PROVISIONSTATUS2COLOUR = "PROVISIONSTATUS2COLOUR";
	private static final String PS2DIMENSIONOBJECT = "PS2DIMENSIONOBJECT";
	private static final String NAME = "NAME";
	private static final String PROVISIONSTATUSID = "PROVISIONSTATUSID";

	public Provisionstatus()
	{
		super();
		this.tableName = "PROVISIONSTATUS";
	}

	public Provisionstatus(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Provisionstatus> getProvisionstatusListByQuery(String query)
	{
		Provisionstatus provisionstatus = new Provisionstatus();
		List<Provisionstatus> provisionstatusList = new ArrayList<Provisionstatus>();
		List<Map<String,Object>> foundProvisionstatusList = provisionstatus.getRecordsByQuery(query);

		for (Map<String,Object> provisionstatusMap : foundProvisionstatusList)
		{
			Provisionstatus workProvisionstatus = new Provisionstatus(provisionstatusMap.get(PROVISIONSTATUSID).toString());
			provisionstatusList.add(workProvisionstatus);
		}
		return provisionstatusList;
	}

	@Override
	public void populateModel()
	{
		fields.put(ISDEFAULT, new Field(ISDEFAULT, Field.TYPE_NUMERIC));
		fields.put(CHANGETOCALLOUT, new Field(CHANGETOCALLOUT, Field.TYPE_VARCHAR));
		fields.put(CHANGEFROMCALLOUT, new Field(CHANGEFROMCALLOUT, Field.TYPE_VARCHAR));
		fields.put(PROVISIONSTATUS2METASTATUS, new Field(PROVISIONSTATUS2METASTATUS, Field.TYPE_NUMERIC));
		fields.put(PROVISIONSTATUS2COLOUR, new Field(PROVISIONSTATUS2COLOUR, Field.TYPE_NUMERIC));
		fields.put(PS2DIMENSIONOBJECT, new Field(PS2DIMENSIONOBJECT, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(PROVISIONSTATUSID, new Field(PROVISIONSTATUSID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(PROVISIONSTATUSID));
	}

	public void setIsdefault(String isdefault)
	{
		setField(ISDEFAULT,isdefault);
	}

	public String getIsdefault()
	{
		return getFieldAsString(ISDEFAULT);
	}

	public void setChangetocallout(String changetocallout)
	{
		setField(CHANGETOCALLOUT,changetocallout);
	}

	public String getChangetocallout()
	{
		return getFieldAsString(CHANGETOCALLOUT);
	}

	public void setChangefromcallout(String changefromcallout)
	{
		setField(CHANGEFROMCALLOUT,changefromcallout);
	}

	public String getChangefromcallout()
	{
		return getFieldAsString(CHANGEFROMCALLOUT);
	}

	public void setProvisionstatus2metastatus(String provisionstatus2metastatus)
	{
		setField(PROVISIONSTATUS2METASTATUS,provisionstatus2metastatus);
	}

	public String getProvisionstatus2metastatus()
	{
		return getFieldAsString(PROVISIONSTATUS2METASTATUS);
	}

	public void setProvisionstatus2colour(String provisionstatus2colour)
	{
		setField(PROVISIONSTATUS2COLOUR,provisionstatus2colour);
	}

	public String getProvisionstatus2colour()
	{
		return getFieldAsString(PROVISIONSTATUS2COLOUR);
	}

	public void setPs2dimensionobject(String ps2dimensionobject)
	{
		setField(PS2DIMENSIONOBJECT,ps2dimensionobject);
	}

	public String getPs2dimensionobject()
	{
		return getFieldAsString(PS2DIMENSIONOBJECT);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setProvisionstatusid(String provisionstatusid)
	{
		setField(PROVISIONSTATUSID,provisionstatusid);
	}

	public String getProvisionstatusid()
	{
		return getFieldAsString(PROVISIONSTATUSID);
	}
}