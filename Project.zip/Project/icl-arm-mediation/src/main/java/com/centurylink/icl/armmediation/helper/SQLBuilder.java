
package com.centurylink.icl.armmediation.helper;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



public class SQLBuilder
{
	private static final Log LOG = LogFactory.getLog(SQLBuilder.class);

	private static final String BEGIN = " WHERE ";
	private static final String AND = " AND ";
	private static final String EMPTY = "";
	private static final String EQ = " = ";
	private static final String SINGLEQUOTE = "'";
	private static final String SELECT = "SELECT ";
	private static final String FROM = " FROM ";
	private static final String ASTRIC = " * ";
	private static final String COMMA = ", ";
	private static final String NEWLINE = "\n";
	private static final String TAB = "\t";
	private static final String SPACE = " ";
	private static final String PERIOD = ".";
	private static final String IN = " IN ";
	private static final String UPDATE = "UPDATE ";
	private static final String SET = " SET ";
	private static final String OR = " OR ";
	private static final String CASE = "CASE";
	private static final String WHEN = "WHEN";
	private static final String THEN = "THEN";
	private static final String IS = "IS";
	private static final String NOT = "NOT";
	private static final String NULL = "NULL";
	private static final String ELSE = "ELSE";
	private static final String JOIN = "(+)";
	private static final String END = "END";
	private static final String UPPER = "UPPER";
	private static final String LIKE = "LIKE";
	private String clause = EMPTY;
	private String table = EMPTY;
	private String fields = ASTRIC;
	private String setFields = "";
	private static final String ORDERBY = "ORDER BY";
	private static final String CONCATENATE = " || ";
	private static final String AS = " AS ";

	public SQLBuilder(String table)
	{
		this.table = table;
	}

	public SQLBuilder(String table, String alias)
	{
		this(table + SPACE + alias);
	}

	private void appendClause()
	{
		if (EMPTY.equals(clause))
		{
			clause = BEGIN;
		} else
		{
			clause = clause + AND;
		}
	}

	private void appendClauseOR()
	{
		if (EMPTY.equals(clause))
		{
			clause = BEGIN;
		} else
		{
			clause = clause + OR;
		}
	}

	public SQLBuilder newClause()
	{
		this.clause = EMPTY;
		return this;
	}

	public SQLBuilder addTable(String table)
	{
		this.table = this.table + COMMA + table;
		return this;
	}

	public SQLBuilder addTable(String table, String alias)
	{
		addTable(table + SPACE + alias);
		return this;
	}

	public SQLBuilder addField(String name)
	{
		if (ASTRIC.equals(this.fields))
		{
			this.fields = name;
		} else
		{
			this.fields = this.fields + COMMA + name;
		}

		return this;
	}

	public SQLBuilder setField(String tableName, String columnName, String value)
	{
		if (this.setFields.isEmpty())
		{
			this.setFields = tableName + PERIOD + columnName + EQ + value;
		} else
		{
			this.setFields = this.setFields + COMMA + tableName + PERIOD + columnName + EQ + value;
		}

		return this;
	}

	public SQLBuilder addField(String name, String alias)
	{
		addField(name + SPACE + alias);
		return this;
	}

	public SQLBuilder addFieldFromTable(String table, String name)
	{
		addField(table + PERIOD + name);
		return this;
	}

	public SQLBuilder addFieldFromTable(String table, String name, String alias)
	{
		addField(table + PERIOD + name, alias);
		return this;
	}
	
	public SQLBuilder addConcatenatedFieldFromTable(String table, String name, String table1, String name1, String alias)
	{
		addField(table + PERIOD + name + CONCATENATE + table1 + PERIOD + name1 + AS + alias);
		return this;
	}

	private void addCondition(String rightSide, String operator, String leftSide)
	{
		appendClause();
		clause = clause + rightSide + operator + leftSide;
	}
	private void addCondition2(String rightSide, String operator, String leftSide,boolean isnullCheck)
	{
		appendClause();
		clause = clause + "(" +UPPER+"(" +rightSide +")"+ operator +leftSide + OR + rightSide + SPACE + IS + SPACE + NULL +")" ;
	}
	
	public SQLBuilder or(String name, String value)
	{
		if (name != null && value != null)
		{
			appendClauseOR();
			clause = clause + name + EQ + SINGLEQUOTE + value + SINGLEQUOTE;
		}
		return this;
	}

	public SQLBuilder eq(String name, String value)
	{
		if (name != null && value != null)
		{
			addCondition(name, EQ, SINGLEQUOTE + value + SINGLEQUOTE);
		}

		return this;
	}

	public SQLBuilder eq(String table, String name, String value)
	{
		eq(table + PERIOD + name, value);

		return this;
	}
	public SQLBuilder eq(String table, String name, String value, boolean isnullcheck)
	{
		addCondition2(table + PERIOD + name,  EQ, SINGLEQUOTE + value + SINGLEQUOTE,isnullcheck);

		return this;
	}
	
	public SQLBuilder eqInt(String name, int value)
	{
		if (name != null && value != 0)
		{
			addCondition(name, EQ, SINGLEQUOTE + value + SINGLEQUOTE);
		}

		return this;
	}

	public SQLBuilder eqInt(String table, String name, int value)
	{
		eqInt(table + PERIOD + name, value);

		return this;
	}

	public SQLBuilder eq(String table, String name, String table2, String name2)
	{
		addCondition(table + PERIOD + name, EQ, table2 + PERIOD + name2);

		return this;
	}

	public String getStatement()
	{
		final String response = SELECT + this.fields + FROM + this.table + this.clause;

		LOG.debug("SQLBuilder.getStatement: " + response);

		return response;
	}

	public String getUpdateStatement()
	{
		return UPDATE + this.table + SET + this.setFields + this.clause;
	}

	public String prettyPrint()
	{
		String formattedStatement = SELECT + this.fields + NEWLINE;
		formattedStatement = formattedStatement + TAB + FROM + this.table + NEWLINE;

		String formattedClause = this.clause.replaceAll("AND", "\n\t\tAND");

		formattedStatement = formattedStatement + TAB + formattedClause;

		return formattedStatement;
	}

	public SQLBuilder in(String table, String columnName, List<String> valueList)
	{
		if (table != null && columnName != null && valueList.size() > 0)
		{
			String valueString = "(";
			String delimeter = "";
			for (String value : valueList)
			{
				valueString = valueString + delimeter + "'" + value + "'";
				delimeter = ",";
			}
			valueString = valueString + ")";
			appendClause();
			clause = clause + table + PERIOD + columnName + IN + valueString;
		}

		return this;
	}

	public SQLBuilder or(String table1, String columnName1, String value1, String table2, String columnName2, String value2)
	{
		if (table1 != null && columnName1 != null && value1 != null && table2 != null && columnName2 != null && value2 != null)
		{
			appendClause();
			clause = clause + table1 + PERIOD + columnName1 + EQ + value1 + OR + table2 + PERIOD + columnName2 + EQ + value2;
		}

		return this;
	}

	public SQLBuilder or(String table1, String columnName1, String table2, String columnName2, String table3, String columnName3, String table4, String columnName4)
	{
		if (table1 != null && columnName1 != null && table2 != null && columnName2 != null && table3 != null && columnName3 != null && table4 != null && columnName4 != null)
		{
			appendClause();
			clause = clause + "(" + table1 + PERIOD + columnName1 + EQ + table2 + PERIOD + columnName2 + OR + table3 + PERIOD + columnName3 + EQ + table4 + PERIOD + columnName4 + ")";
		}

		return this;
	}

	public SQLBuilder or(String tableNew, String name, String value)
	{
		or(tableNew + PERIOD + name, value);
		return this;
	}

	public SQLBuilder joinFO(String table1, String columnName1, String table2, String columnName2)
	{
		addCondition(table1 + PERIOD + columnName1, EQ, table2 + PERIOD + columnName2 + JOIN);
		return this;
	}

	public SQLBuilder addCase(String table1, String columnName1, String table2, String columnName2, String table3, String columnName3, String caseName)
	{
		addField(CASE + SPACE + WHEN + SPACE + table1 + PERIOD + columnName1 + SPACE + IS + SPACE + NOT + SPACE + NULL + SPACE + THEN + SPACE + table2 + PERIOD + columnName2 + SPACE + ELSE + SPACE
				+ table3 + PERIOD + columnName3 + SPACE + END + SPACE + caseName);
		return this;
	}

	public SQLBuilder addCase(String table1, String columnName1, String table2, String columnName2, String caseName)
	{
		addField(CASE + SPACE + WHEN + SPACE + table1 + PERIOD + columnName1 + SPACE + IS + SPACE + NOT + SPACE + NULL + SPACE + THEN + SPACE + table1 + PERIOD + columnName1 + SPACE + ELSE + SPACE
				+ table2 + PERIOD + columnName2 + SPACE + END + SPACE + caseName);
		return this;
	}

	public SQLBuilder orClause(String[] tables, String[] columnNames, String[] values)
	{
		if (tables.length == columnNames.length && columnNames.length == values.length)
		{
			appendClause();
			clause = clause + "(";
			for (int i = 0; i < tables.length; i++)
			{
				String table = tables[i];
				String columnName = columnNames[i];
				String value = values[i];
				if (table != null && columnName != null && value != null)
				{

					clause = clause + table + PERIOD + columnName + EQ + SINGLEQUOTE + value + SINGLEQUOTE;
					if (i < tables.length - 1)
						clause = clause + OR;
				}
			}
		}
		clause = clause + ")";
		return this;
	}

	public SQLBuilder eqUpperCase(String name, String value)
	{
		if (name != null && value != null)
		{
			addCondition(UPPER + "(" + name + ")", EQ, SINGLEQUOTE + value.toUpperCase() + SINGLEQUOTE);
		}

		return this;
	}
	
	//wildCard Search
		public SQLBuilder orClausesLikeCase(String[] tables, String[] columnNames, String[] values)
		{
			if (tables.length == columnNames.length && columnNames.length == values.length)
			{
				appendClause();
				clause = clause + "(";
				for (int i = 0; i < tables.length; i++)
				{
					String table = tables[i];
					String columnName = columnNames[i];
					String value = values[i];
					if (table != null && columnName != null && value != null)
					{
						clause = clause + UPPER + "(" + table + PERIOD + columnName + ")" + SPACE + LIKE + SPACE + SINGLEQUOTE + value.toUpperCase() + SINGLEQUOTE;
						if (i < tables.length - 1)
							clause = clause + OR;
					}
				}
			}
			clause = clause + ")";
			return this;
		}
		
		public SQLBuilder like(String table,String name, String value)
	    {
	           if (name != null && value != null)
	           {
	                  addCondition(table + PERIOD + name+SPACE,LIKE+SPACE, SINGLEQUOTE + value + SINGLEQUOTE);
	           }

	           return this;
	    }
		
	
	public SQLBuilder eqUpperCase(String table, String name, String value)
	{
		eqUpperCase(table + PERIOD + name, value);

		return this;
	}
	public SQLBuilder orderBy(String[] tables, String[] columnNames)
	{
		if (tables.length == columnNames.length )
		{
			clause = clause + SPACE + ORDERBY + SPACE;
			for (int i = 0; i < tables.length; i++)
			{
				String table = tables[i];
				String columnName = columnNames[i];
				if (table != null && columnName != null )
				{
					clause = clause + table + PERIOD + columnName ;
					if (i < tables.length - 1)
						clause = clause + ",";
				}
			}
		}
		return this;
	}
	public SQLBuilder joinFOValue(String table1, String columnName1, String value)
	{
		addCondition(value, EQ, table1 + PERIOD + columnName1 + JOIN);
		return this;
	}
	public SQLBuilder orClausesUpperCase(String[] tables, String[] columnNames, String[] values)
	{
		if (tables.length == columnNames.length && columnNames.length == values.length)
		{
			appendClause();
			clause = clause + "(";
			for (int i = 0; i < tables.length; i++)
			{
				String table = tables[i];
				String columnName = columnNames[i];
				String value = values[i];
				if (table != null && columnName != null && value != null)
				{
					clause = clause + UPPER + "(" + table + PERIOD + columnName + ")" + EQ + SINGLEQUOTE + value.toUpperCase() + SINGLEQUOTE;
					if (i < tables.length - 1)
						clause = clause + OR;
				}
			}
		}
		clause = clause + ")";
		return this;
	}
}
