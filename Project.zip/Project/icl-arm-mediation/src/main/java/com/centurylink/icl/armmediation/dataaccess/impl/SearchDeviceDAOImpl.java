package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMNode;
import com.centurylink.icl.armmediation.armaccessobject.ARMOrderedNetworkRoleList;
import com.centurylink.icl.armmediation.armaccessobject.ARMPort;
import com.centurylink.icl.armmediation.armaccessobject.ARMSFP;
import com.centurylink.icl.armmediation.armaccessobject.ARMShelf;
import com.centurylink.icl.armmediation.armaccessobject.ARMSlot;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;

public class SearchDeviceDAOImpl implements SearchDeviceDAO
{

	private JdbcTemplate	jdbcTemplate;

	public SearchDeviceDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<ARMNode> getNodesList(String query) throws Exception
	{
		final List<ARMNode> nodeList = this.jdbcTemplate.query(query, new RowMapper<ARMNode>() 
		{
			public ARMNode mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMNode armNode = new ARMNode();
				armNode.setCommonName(rs.getString("NAME"));
				armNode.setAliasName(rs.getString("ALIAS1"));
				armNode.setAliasName2(rs.getString("ALIAS2"));
				armNode.setNodeId(rs.getLong("NODEID"));
				armNode.setProvisionStatus(rs.getString("PROVISIONSTATUS"));
				armNode.setResourceSubType(rs.getString("NODEDEFNAME"));
				armNode.setLocationClli(rs.getString("LOCATIONNAME"));
				armNode.setSnmpObjectId(rs.getString("SNMPOBJECTID"));
				armNode.setManufacturer(rs.getString("MANUFACTURER"));
				armNode.setResourceType(rs.getString("NODETYPENAME"));
				armNode.setClliCode(rs.getString("CLLI"));
				armNode.setChasisSerialNo(rs.getString("CHASSISSERIALNUMBER"));
				armNode.setSerialNumber(rs.getString("SERIALNUMBER"));
				armNode.setSoftwareVersion(rs.getString("SOFTWAREVERSION"));
				armNode.setFirmwareVersion(rs.getString("FIRMWAREVERSION"));
				armNode.setHardwareVersion(rs.getString("HARDWAREVERSION"));
				armNode.setNmsType(rs.getString("NMSTYPE"));
				armNode.setNmsHostName(rs.getString("NMSHOSTNAME"));
				armNode.setVendorPartNo(rs.getString("VENDORPARTNUMBER"));
				armNode.setVendorName(rs.getString("VENDORNAME"));
				armNode.setMacAddress(rs.getString("MACADDRESS"));
				armNode.setIpV4MgmRouterId(rs.getString("IPV4MGMROUTERID"));
				armNode.setIpV4Console1(rs.getString("IPV4CONSOLE1"));
				armNode.setIpV4Console2(rs.getString("IPV4CONSOLE2"));
				armNode.setIpV6MgmRouterId(rs.getString("IPV6MGMROUTERID"));
				armNode.setIpV6Console1(rs.getString("IPV6CONSOLE1"));
				armNode.setIpv6Console2(rs.getString("IPV6CONSOLE2"));
				armNode.setDiversed(rs.getString("IS_DIVERSE"));
				armNode.setSharedOrDedicated(rs.getString("SHARED_DEDICATED"));
				armNode.setRelativeName(rs.getString("RELATIVENAME"));
				armNode.setMgmtVlan(rs.getString("MGMTVLAN"));
				armNode.setNetworkName(rs.getString("NETWORKNAME"));
				armNode.setDescription(rs.getString("DESCRIPTION"));
				armNode.setFunctionalStatus(rs.getString("FUNCTIONALSTATUS"));
				armNode.setAutoIdentifyNID(rs.getString("AUTO_IDENTIFY_NID"));
				armNode.setRestrictedNotes(rs.getString("RESTRICTEDNOTES"));				
				armNode.setNwkNodeNumber(rs.getString("NWKNODENUMBER"));
				armNode.setMaxSubscriberBWOffered(rs.getString("MAXSUBSCRIBERBWOFFERED"));
				armNode.setPrismNosaCert(rs.getString("PRISMNOSACERT"));
				armNode.setOneGbpsIndicator(rs.getString("ONEGBPSINDICATOR"));
				armNode.setStackRingSeqNum(rs.getString("STACKRINGSEQNUM"));
				armNode.setStackRingShelfId(rs.getString("STACKRINGSHELFID"));
				armNode.setAerialORBuried(rs.getString("AERIALORBURIED"));
			
				armNode.setMaxDownStreamRate(rs.getString("MAXDOWNSTREAMRATE"));
				armNode.setMaxUpStreamRate(rs.getString("MAXUPSTREAMRATE"));
			
				
				armNode.setFiberINRange(rs.getString("FIBERINRANGE"));
				armNode.setFiberOUTRange(rs.getString("FIBEROUTRANGE"));
				armNode.setSplitterGrpNum(rs.getString("SPLITTERGRPNUM"));
				armNode.setSplitterGrpName(rs.getString("SPLITTERGRPNAME"));
				armNode.setSplitterStartPortNumber(rs.getString("SPLITTERSTARTPORTNUMBER"));
				armNode.setInstallDate(rs.getString("INSTALLDATE"));
				armNode.setInDoor(rs.getString("INDOOR"));
				armNode.setSelfORTechInstall(rs.getString("SELFORTECHINSTALL"));
				armNode.setRontaId(rs.getString("RONTAID"));
				armNode.setPowerSupply(rs.getString("POWERSUPPLY"));
				armNode.setOptiTap(rs.getString("OPTITAP"));
				armNode.setSapCode(rs.getString("SAPCODE"));
				armNode.setRestrictedStatus(rs.getString("RESTRICTEDSTATUS"));
				armNode.setRelayRackId(rs.getString("RELAYRACKID"));
				armNode.setRevision(rs.getString("REVISION"));
				armNode.setNetworkRoleObject2NetworkRole(rs.getString("ROLE"));
				return armNode;
			}
		});
		return nodeList;
	}

	@Override
	public List<ARMShelf> getShelfList(String query) throws Exception
	{
		final List<ARMShelf> shelfList = jdbcTemplate.query(query, new RowMapper<ARMShelf>() 
		{
			public ARMShelf mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMShelf armShelf = new ARMShelf();
				armShelf.setCommonName(rs.getString("NAME"));
				armShelf.setDescription(rs.getString("DESCRIPTION"));
				armShelf.setVersion(rs.getString("HARDWAREVERSION"));
				armShelf.setFirmwareVersion(rs.getString("FIRMWAREVERSION"));
				armShelf.setSoftwareVersion(rs.getString("SOFTWAREVERSION"));
				armShelf.setType(rs.getString("NOTES"));
				armShelf.setAliasName(rs.getString("ALIAS1"));
				armShelf.setAliasName2(rs.getString("ALIAS2"));
				armShelf.setSerialNumber(rs.getString("SHELFSERIALNUMBER"));
				armShelf.setRelayRackID(rs.getString("RELAYRACKID"));
				armShelf.setBayName(rs.getString("BAYNAME"));
				armShelf.setShelfID(rs.getLong("SHELFID"));

				return armShelf;
			}
		});
		return shelfList;
	}

	@Override
	public Map<Long, List<ARMSlot>> getSlotList(String query) throws Exception
	{
		final Map<Long, List<ARMSlot>> slot2ShelfMap = new HashMap<Long, List<ARMSlot>>();

		jdbcTemplate.query(query, new RowMapper<ARMSlot>() 
		{
			public ARMSlot mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMSlot armSlot = new ARMSlot();
				Long slot2Shelf = rs.getLong("SLOT2SHELF");
				armSlot.setCommonName(rs.getString("NAME"));
				armSlot.setSlodId(rs.getLong("SLOTID"));
				armSlot.setSlotNumber(rs.getInt("SLOTNUMBER"));
				armSlot.setSlot2Shelf(slot2Shelf);

				if (slot2ShelfMap.get(slot2Shelf) == null)
				{
					List<ARMSlot> slotList = new ArrayList<ARMSlot>();
					slotList.add(armSlot);
					slot2ShelfMap.put(slot2Shelf, slotList);
				} else
				{
					slot2ShelfMap.get(slot2Shelf).add(armSlot);
				}

				return armSlot;
			}
		});
		return slot2ShelfMap;
	}

	@Override
	public List<ARMCard> getCardList(String query) throws Exception
	{
		final Map<Long, ARMCard> parentChildCardsMap = new HashMap<Long, ARMCard>();
		
		final List<ARMCard> cardList = jdbcTemplate.query(query, new RowMapper<ARMCard>()
		{
			@Override
			public ARMCard mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMCard armCard = new ARMCard();
				
				long card2shelfslot = rs.getLong("CARD2SHELFSLOT");
				
				armCard.setCommonName(rs.getString("NAME"));
				armCard.setCardId(rs.getLong("CARDID"));
				armCard.setAliasName(rs.getString("ALIAS1"));
				armCard.setSubType(rs.getString("SUBTYPE"));
				armCard.setCard2ShelfSlot(card2shelfslot);
				armCard.setSlotId(rs.getLong("SLOTID"));
				armCard.setParentCardID(rs.getString("PARENTCARDID"));
				armCard.setSlotNumber(rs.getString("SLOTNUMBER"));
				
				if(parentChildCardsMap.get(card2shelfslot) == null)
				{
					parentChildCardsMap.put(card2shelfslot, armCard);
				}
				else if( parentChildCardsMap.get(card2shelfslot) != null && 
						 parentChildCardsMap.get(card2shelfslot).getCard2ShelfSlot() == card2shelfslot )
				{
					parentChildCardsMap.get(card2shelfslot).getChildCards().add(armCard);
				}
				
				return armCard;
			}
		});
		
		List<ARMCard> cardsWithInsideCards = new ArrayList<ARMCard>();
		Set<Long> keySet = parentChildCardsMap.keySet();
		for (Long key : keySet)
		{
			cardsWithInsideCards.add(parentChildCardsMap.get(key));
		}
		return cardsWithInsideCards;
	}

	@Override
	public List<ARMPort> getPortOnDeviceList(String query) throws Exception
	{
		final List<ARMPort> portList = jdbcTemplate.query(query, new RowMapper<ARMPort>()
		{
			@Override
			public ARMPort mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMPort armPort = new ARMPort();
				armPort.setCommonName(rs.getString("NAME"));
				armPort.setPortId(rs.getLong("PORTID"));
				armPort.setAliasName(rs.getString("ALIAS1"));
				armPort.setResourceType(rs.getString("PORTTYPENAME"));
				armPort.setPrStatus(rs.getString("STATUSNAME"));
				armPort.setPortFunction(rs.getString("PORTFUNCTION"));
				armPort.setIfNum(rs.getString("IFNUM"));				
				armPort.setWaveLength(rs.getString("WAVELENGTH"));
				armPort.setPluggableType(rs.getString("PLUGGABLETYPE"));
				armPort.setDPEA(rs.getString("DPEA"));
				armPort.setPort2Card(rs.getLong("PORT2CARD"));
				armPort.setReservationdId(rs.getString("ReservationID"));
				armPort.setPortNumber(rs.getString("PORTNUMBER"));				
				armPort.setTransmissionRate(rs.getString("BANDWIDTH_NAME"));
				armPort.setTransmissionRatePluggable(rs.getString("PLUGGABLE_TRANSMISSIONRATE"));
				if(rs.getString("PLUGGABLEPORTID") != null)
				{
					armPort.setResourceSubType("Pluggable");
					armPort.setIfName(rs.getString("PLUGGABLE_IF_NAME"));
				}
				else
				{
					armPort.setResourceSubType("Non-Pluggable");
					armPort.setIfName(rs.getString("TABLE_IF_NAME"));
				}
				
				return armPort;
			}

		});
		return portList;
	}

	@Override
	public Map<Long, List<ARMPort>> getPortList(String query) throws Exception
	{
		final Map<Long, List<ARMPort>> port2CardMap = new HashMap<Long, List<ARMPort>>();

		jdbcTemplate.query(query, new RowMapper<ARMPort>() 
		{
			@Override
			public ARMPort mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMPort armPort = new ARMPort();
				long port2card = rs.getLong("PORT2CARD");
				armPort.setCommonName(rs.getString("NAME"));
				armPort.setPortId(rs.getLong("PORTID"));
				armPort.setAliasName(rs.getString("ALIAS1"));
				armPort.setResourceType(rs.getString("PORTTYPENAME"));
				armPort.setPrStatus(rs.getString("STATUSNAME"));
				armPort.setPortFunction(rs.getString("PORTFUNCTION"));
				armPort.setIfNum(rs.getString("IFNUM"));
				armPort.setPLUGGABLEIFNUM(rs.getString("PLUGGABLEIFNUM"));				
				armPort.setWaveLength(rs.getString("WAVELENGTH"));
				armPort.setPluggableType(rs.getString("PLUGGABLETYPE"));
				armPort.setDPEA(rs.getString("DPEA"));
				armPort.setReservationdId(rs.getString("ReservationID"));
				armPort.setPortNumber(rs.getString("PORTNUMBER"));				
				armPort.setTransmissionRate(rs.getString("BANDWIDTH_NAME"));
				armPort.setTransmissionRatePluggable(rs.getString("PLUGGABLE_TRANSMISSIONRATE"));
				if(rs.getString("PLUGGABLEPORTID") != null)
				{
					armPort.setResourceSubType("Pluggable");
					armPort.setIfName(rs.getString("PLUGGABLE_IF_NAME"));
				}
				else
				{
					armPort.setResourceSubType("Non-Pluggable");
					armPort.setIfName(rs.getString("TABLE_IF_NAME"));
				}
				armPort.setPort2Card(port2card);
				
				if (port2CardMap.get(port2card) == null)
				{
					List<ARMPort> armPortList = new ArrayList<ARMPort>();
					armPortList.add(armPort);
					port2CardMap.put(port2card, armPortList);
				} else
				{
					port2CardMap.get(port2card).add(armPort);
				}

				return armPort;
			}
		});
		return port2CardMap;
	}

	@Override
	public List<ARMSFP> getSFPList(String query) throws Exception
	{
		final List<ARMSFP> sfpList = jdbcTemplate.query(query, new RowMapper<ARMSFP>() 
		{
			@Override
			public ARMSFP mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMSFP sfp = new ARMSFP();
				sfp.setSfpName(rs.getString("SFPNAME"));

				return sfp;
			}
		});
		return sfpList;
	}
	
	@Override
	public List<ARMLocation> getlocationList(String query)
	{
		final List<ARMLocation> armLocationList = this.jdbcTemplate.query(query, new RowMapper<ARMLocation>()
		{
			public ARMLocation mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMLocation armLocation = new ARMLocation();
				armLocation.setCommonName(rs.getString("NAME"));
				/*
				 * Commented by YVIKHE This is not required data is coming from clc 
				 * 
				 * armLocation.setDescription(rs.getString("FULLNAME"));
				armLocation.setStateOrProvince(rs.getString("STATE"));
				armLocation.setHcoordinate(rs.getString("HCOORDINATE"));
				armLocation.setVcoordinate(rs.getString("VCOORDINATE"));
				armLocation.setLata(rs.getString("LATA"));
				armLocation.setLocality(rs.getString("CITY"));
				armLocation.setPostcode(rs.getString("ZIP"));
				armLocation.setAddressLine1(rs.getString("ADDRESS1"));
				armLocation.setAddressLine2(rs.getString("ADDRESS2"));
				armLocation.setAddressLine3(rs.getString("ADDRESS3"));*/
				
				return armLocation;

			}
		});
		return armLocationList;
	}

	@Override
	public List<ARMDevice> getDeviceList(String query) throws Exception
	{
		final List<ARMDevice> deviceList = this.jdbcTemplate.query(query, new RowMapper<ARMDevice>() 
		{
			public ARMDevice mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMDevice armDevice = new ARMDevice();
				armDevice.setCommonName(rs.getString("NAME"));
				armDevice.setDescription(rs.getString("DESCRIPTION"));
				armDevice.setObjectID(rs.getString("OBJECTID"));
				armDevice.setClliCode(rs.getString("CLLI"));
				armDevice.setResourceType(rs.getString("RESOURCETYPE"));
				armDevice.setResourceSubType(rs.getString("RESOURCESUBTYPE"));
				armDevice.setMco(rs.getString("MCO"));
				armDevice.setUsageState(rs.getString("SHARED_DEDICATED"));
				armDevice.setManufacturer(rs.getString("MANUFACTURER"));
				armDevice.setPrStatus(rs.getString("STATUS"));
				armDevice.setModel(rs.getString("MODEL"));
				armDevice.setVendorName(rs.getString("VENDORNAME"));
                armDevice.setRole(rs.getString("ROLE"));
				armDevice.setLocationName(rs.getString("LOCATION_NAME"));
				armDevice.setLocationName(rs.getString("LOCATION_NAME"));
				armDevice.setCustomerName(rs.getString("CUSTOMERNAME"));
				armDevice.setCustomerFullName(rs.getString(Constants.FULL_NAME));
				armDevice.setCustomerId(rs.getString(Constants.SUBSCIBER_ID));
				armDevice.setIpV4MgmRouterId(rs.getString(Constants.IP_V4_MGM_ROUTER_ID));
				armDevice.setIpV4Console1(rs.getString("IPV4CONSOLE1"));
				armDevice.setIpV4Console2(rs.getString("IPV4CONSOLE2"));
				armDevice.setIpV6MgmRouterId(rs.getString(Constants.IP_V6_MGM_ROUTERID));
				armDevice.setIpV6Console1(rs.getString("IPV6CONSOLE1"));
				armDevice.setIpV6Console2(rs.getString("IPV6CONSOLE2"));
				armDevice.setMgmtVlan(rs.getString("MGMTVLAN"));
				armDevice.setNetworkName(rs.getString("NETWORKNAME"));
				armDevice.setFullName(rs.getString(Constants.FULL_NAME));
				armDevice.setMacAddress(rs.getString("MACADDRESS"));
				armDevice.setTtServiceType(rs.getString(Constants.TT_SERVICE_TYPE));
			
				
				return armDevice;
			}
		});
		return deviceList;
	}
	
	@Override
	public List<ARMLocation> getLocSubLocList(String query)
	{
		final List<ARMLocation> armLocationList = this.jdbcTemplate.query(query, new RowMapper<ARMLocation>()
		{
			public ARMLocation mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMLocation armLocation = new ARMLocation();
				armLocation.setObjectID(rs.getString("PARENT_LOC_ID"));
				armLocation.setChildLocId(rs.getString("CHILD_LOC_ID"));
				
				return armLocation;
			}
		});
		return armLocationList;
	}
	
	@Override
	public List<ARMDevice> getAllDeviceList(String query, final Boolean checkSubscriber) throws Exception
	{
		final List<ARMDevice> deviceList = this.jdbcTemplate.query(query, new RowMapper<ARMDevice>() 
		{
			public ARMDevice mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMDevice armDevice = new ARMDevice();
				armDevice.setCommonName(rs.getString("NAME"));
				armDevice.setDescription(rs.getString("FULLNAME"));
				armDevice.setFullName(rs.getString("FULLNAME"));
				armDevice.setCustomerName(rs.getString("RELATIVENAME"));
				armDevice.setRole(rs.getString("ROLE"));
				armDevice.setRoleId(rs.getString("NETWORKROLEID"));
				armDevice.setAlias1(rs.getString("ALIAS1"));
				armDevice.setAlias2(rs.getString("ALIAS2"));
				armDevice.setObjectID(rs.getString("NODEID"));
				armDevice.setSubType(rs.getString("SUBTYPE"));
				armDevice.setSubStatus(rs.getString("SUBSTATUS"));
                armDevice.setPrStatus(rs.getString("PROVISIONSTATUS"));
				armDevice.setFuncStatus(rs.getString("FUNCTIONALSTATUS"));
				armDevice.setManufacturer(rs.getString("MANUFACTURER"));
				armDevice.setVersion(rs.getString("VERSION"));
				armDevice.setMarkedForDelete(rs.getString("MARKEDFORDELETE"));
				armDevice.setSoftwareVersion(rs.getString("SOFTWAREVERSION"));
				armDevice.setHardwareVersion(rs.getString("HARDWAREVERSION"));
				armDevice.setFirmwareVersion(rs.getString("FIRMWAREVERSION"));
				armDevice.setSnmpObjectId(rs.getString("SNMPOBJECTID"));
				armDevice.setClliCode(rs.getString("CLLI"));
				armDevice.setChassisSerialNumber(rs.getString("CHASSISSERIALNUMBER"));
				armDevice.setSerialNumber(rs.getString("SERIALNUMBER"));
				armDevice.setRevision(rs.getString("REVISION"));
				armDevice.setNmsType(rs.getString("NMSTYPE"));
				armDevice.setNmsHostName(rs.getString("NMSHOSTNAME"));
				armDevice.setUsageState(rs.getString("SHARED_DEDICATED"));
				armDevice.setDisContinueDate(rs.getString("DISCONTINUEDATE"));
				armDevice.setDisContinueReason(rs.getString("DISCONTINUEREASON"));
				armDevice.setVendorPartNumber(rs.getString("VENDORPARTNUMBER"));
				armDevice.setVendorName(rs.getString("VENDORNAME"));
				armDevice.setManufacturerPartNumber(rs.getString("MANUFACTURERPARTNUMBER"));
				armDevice.setPartType(rs.getString("PARTTYPE"));
				armDevice.setMacAddress(rs.getString("MACADDRESS"));
				armDevice.setIpV6MgmRouterId(rs.getString("IPV6MGMROUTERID"));
				armDevice.setIpV6Console1(rs.getString("IPV6CONSOLE1"));
				armDevice.setIpV6Console2(rs.getString("IPV6CONSOLE2"));
				armDevice.setIpV4MgmRouterId(rs.getString("IPV4MGMROUTERID"));
				armDevice.setIpV4Console1(rs.getString("IPV4CONSOLE1"));
				armDevice.setIpV4Console2(rs.getString("IPV4CONSOLE2"));
				armDevice.setMgmtVlan(rs.getString("MGMTVLAN"));
				armDevice.setAutoIdentifyNID(rs.getString("AUTO_IDENTIFY_NID"));
				armDevice.setTtServiceType(rs.getString(Constants.TT_SERVICE_TYPE));
				armDevice.setResourceType(rs.getString("RESOURCETYPE"));
				armDevice.setResourceSubType(rs.getString("RESOURCESUBTYPE"));
				
				if(checkSubscriber==true)
				{
					armDevice.setCustomerId(rs.getString("CUST_ID"));
					armDevice.setCustomerFullName(rs.getString("CUST_FULLNAME"));
				}
				
				return armDevice;
			}
		});
		return deviceList;
	}
	
	private static final String QUERY_SQL = "select NODEID from NODE where RELATIVENAME = ?";
	@Override
	public List<Long> getDeviceIdsBySubscriber(String subscriber) throws Exception
	{
		final List<Long> longList = this.jdbcTemplate.query(QUERY_SQL, new Object[] {subscriber}, new RowMapper<Long>()
		{
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				Long id = rs.getLong("NODEID");
				return id;
			}
		});
		return longList;
	}
	
	@Override
	public List<String> getNetworkRole(String query) throws Exception
	{
		final List<String> armNetworkRoleListList = this.jdbcTemplate.query(query, new RowMapper<String>() 
		{
			public String mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				
								
				return rs.getString("NAME");
			}
		});
		return armNetworkRoleListList;
	}
	
	@Override
	public List<ARMOrderedNetworkRoleList> getOrderedNetworkRoleList(String query) throws Exception
	{
		final List<ARMOrderedNetworkRoleList> armNetworkRoleListList = this.jdbcTemplate.query(query, new RowMapper<ARMOrderedNetworkRoleList>() 
		{
			public ARMOrderedNetworkRoleList mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMOrderedNetworkRoleList armNetworkRoleList = new ARMOrderedNetworkRoleList();
				armNetworkRoleList.setDeviceRole(rs.getString("DEVICE_ROLE"));
								
				return armNetworkRoleList;
			}
		});
		return armNetworkRoleListList;
	}
	
	@Override
	public List<ARMDevice> getDeviceinTopology(String query) throws Exception
	{
		final List<ARMDevice> deviceList = this.jdbcTemplate.query(query, new RowMapper<ARMDevice>() 
		{
			public ARMDevice mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMDevice armDevice = new ARMDevice();
				armDevice.setCommonName(rs.getString("NAME"));
				armDevice.setRole(rs.getString("ALIAS1"));
				armDevice.setTopologyName(rs.getString("TOPOLOGY_NAME"));
				armDevice.setTopologyType(rs.getString("TOPOLOGY_TYPE"));
				return armDevice;
			}
		});
		return deviceList;
	}
}

