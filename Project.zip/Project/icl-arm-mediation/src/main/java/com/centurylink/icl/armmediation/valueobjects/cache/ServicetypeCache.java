package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Servicetype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class ServicetypeCache implements ValueObjectCache {
	
	private Map<String, Servicetype> cachedObjects = new HashMap<String, Servicetype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Servicetype newServicetype = new Servicetype(key);
			if (newServicetype.isInstanciated())
			{
				cachedObjects.put(key, newServicetype);
				return newServicetype;
			} else {
				return null;
			}
		}
	}

}
