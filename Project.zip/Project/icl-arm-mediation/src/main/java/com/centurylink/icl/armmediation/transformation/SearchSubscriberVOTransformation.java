package com.centurylink.icl.armmediation.transformation;

import com.centurylink.icl.armmediation.helper.CLCLookupServiceHelper;
import com.centurylink.icl.armmediation.valueobjects.objects.Subscriber;
import com.centurylink.icl.builder.cim2.CustomerAccountBuilder;
import com.centurylink.icl.builder.cim2.CustomerAgentBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.CustomerAgent;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.Party;

public class SearchSubscriberVOTransformation {

	protected static Customer buildCustomerFromSubscriber(Subscriber subscriber, String ban)
	{
		CustomerBuilder customerBuilder = new CustomerBuilder();
		CustomerAccountBuilder customerAccountBuilder = new CustomerAccountBuilder();
		
		customerBuilder.buildCustomer(subscriber.getName(), subscriber.getSubscriberid(), null, subscriber.getFullname(), "ARM", null);
		
		if (!StringHelper.isEmpty(ban))
		{
			customerAccountBuilder.buildCustomerAccount(ban, "BAN");
			customerBuilder.addCustomerPosseses(customerAccountBuilder.getCustomerAccount());
		}
		
		return customerBuilder.getCustomer();
	}
	
	protected static Customer getCLCCustomerFromSubscriber(Subscriber subscriber, String ban)throws Exception
	{
		Party party = CLCLookupServiceHelper.getCLCLookupService().getCustomerByName(subscriber.getName());
		return formatCLCCustomer(party,ban,subscriber.getName());	

	}
	protected static Customer getCLCCustomerFromReletive(String relativeName)throws Exception
	{
		Party party = CLCLookupServiceHelper.getCLCLookupService().getCustomerByName(relativeName);
		return formatCLCCustomer(party,null,relativeName);	

	}
	private static Customer formatCLCCustomer(Party clcCustomer,String ban, String armCustomerName) throws Exception
	{		
		CustomerBuilder customerBuilder=new CustomerBuilder();
		CustomerAccountBuilder customerAccountBuilder = new CustomerAccountBuilder();
		
		if(clcCustomer != null)
		{
			String acna=null;
			if(clcCustomer.getHasCustomerRoleList()!=null && clcCustomer.getHasCustomerRoleList().size()>0)
			{
				Customer customer= clcCustomer.getHasCustomerRoleList().get(0);
				if(customer!=null && customer.getACNA()!=null)
				{
					acna=customer.getACNA();
				}
			}
			customerBuilder.buildCustomer(armCustomerName, clcCustomer.getObjectID(), null, clcCustomer.getCommonName(), "CLC", null,acna,clcCustomer.getPartyId(),clcCustomer.getPartyType());
			if (!StringHelper.isEmpty(ban))
			{
				customerAccountBuilder.buildCustomerAccount(ban, "BAN");
				customerBuilder.addCustomerPosseses(customerAccountBuilder.getCustomerAccount());
			}			
		}		

		return customerBuilder.getCustomer();
	}

	protected static CustomerAgent buildCustomerAgentFromSubscriber(Subscriber subscriber)
	{
		CustomerAgentBuilder customerAgentBuilder = new CustomerAgentBuilder();
		
		customerAgentBuilder.buildCustomerAgent(subscriber.getFullname(), null);
		
		if(subscriber.getFullname()!=null || subscriber.getFirstname()!=null)
		{	
			customerAgentBuilder.addRootEntityDescribedBy("FullName", subscriber.getFullname());
			customerAgentBuilder.addRootEntityDescribedBy("FirstName", subscriber.getFirstname());
		}
		
		return customerAgentBuilder.getCustomerAgent();
	}

	protected static OwnsResourceDetails getCLCCustomerFromSubscriber(Subscriber subscriber) throws Exception
	{
		Party party = CLCLookupServiceHelper.getCLCLookupService().getCustomerByName(subscriber.getName());

		return formatCLCCustomer(party);
	}


	private static OwnsResourceDetails formatCLCCustomer(Party clcCustomer) throws Exception
	{
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder=new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder=new CustomerBuilder();
		if(clcCustomer != null)
		{
			String acna=null;
			if(clcCustomer.getHasCustomerRoleList()!=null && clcCustomer.getHasCustomerRoleList().size()>0)
			{
				Customer customer= clcCustomer.getHasCustomerRoleList().get(0);
			
				if(customer!=null && customer.getACNA()!=null)
				{
					acna=customer.getACNA();
				}
			}
			customerBuilder.buildCustomer(clcCustomer.getCommonName(), clcCustomer.getObjectID(), null, null, "CLC", null,acna,clcCustomer.getPartyId(),clcCustomer.getPartyType());
			ownsResourceDetailsBuilder.buildOwnsResourceDetails();
			ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
				
			
		}		

		return ownsResourceDetailsBuilder.getOwnsResourceDetails();
	}
}
