package com.centurylink.icl.armmediation.storedprocedures.pkglocation;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.AddToObjAttrListNumber;

public class SetParentLocation extends StoredProcedure
{

	private static final Log	LOG	= LogFactory.getLog(AddToObjAttrListNumber.class);

	public SetParentLocation(DataSource dataSource)
	{
		super(dataSource, "CRAMER.PKGLOCATION.SETPARENTLOCATION");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}

		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		declareParameter(new SqlParameter("i_location", Types.NUMERIC));
		declareParameter(new SqlParameter("i_parentlocation", Types.NUMERIC));

		compile();

	}

	public Map<String, Object> execute(BigDecimal i_location, BigDecimal i_parentlocation)
	{
		final Map<String, Object> in = new HashMap<String, Object>();

		in.put("i_location", i_location);
		in.put("i_parentlocation", i_parentlocation);

		return super.execute(in);
	}

}
