package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class ServiceSpecification extends AbstractReadOnlyTable {

	private static String SERVICE_SPECIFICATION_ID="SERVICE_SPECIFICATION_ID";
	private static String SERVICE_SPECIFICATION_CD="SERVICE_SPECIFICATION_CD";
	private static String PROTOCOL_BRIDGE_BLOCK="PROTOCOL_BRIDGE_BLOCK";
	private static String PROTOCOL_GARP_BLOCK="PROTOCOL_GARP_BLOCK";
	private static String PROTOCOL_ALL_LANS_BMG="PROTOCOL_ALL_LANS_BMG";
	
	public ServiceSpecification()
	{
		super();
		this.tableName = "SERVICE_SPECIFICATION";
	}
	
	public ServiceSpecification(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static ServiceSpecification getServiceSpecificationbject(String specCode)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(specCode))
		{
			query = SERVICE_SPECIFICATION_CD + " = '" +  specCode + "'";
			connector = " AND ";
		}
		return getServiceSpecificationByQuery(query);
	}

	public static ServiceSpecification getServiceSpecificationByQuery(String query)
	{
		ServiceSpecification serviceSpec = new ServiceSpecification();
		List<Map<String,Object>> foundServiceSpecList = serviceSpec.getRecordsByQuery(query);

		ServiceSpecification workserviceSpec=null;
		for (Map<String,Object> serviceSpecMap : foundServiceSpecList)
		{
			workserviceSpec = new ServiceSpecification(serviceSpecMap.get(SERVICE_SPECIFICATION_ID).toString());
			if(workserviceSpec != null)
				return workserviceSpec;
		}
		
		return workserviceSpec;
	}
	
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(SERVICE_SPECIFICATION_CD, new Field(SERVICE_SPECIFICATION_CD, Field.TYPE_VARCHAR));
		fields.put(PROTOCOL_BRIDGE_BLOCK, new Field(PROTOCOL_BRIDGE_BLOCK, Field.TYPE_VARCHAR));
		fields.put(PROTOCOL_GARP_BLOCK, new Field(PROTOCOL_GARP_BLOCK, Field.TYPE_VARCHAR));
		fields.put(PROTOCOL_ALL_LANS_BMG, new Field(PROTOCOL_ALL_LANS_BMG, Field.TYPE_VARCHAR));
		fields.put(SERVICE_SPECIFICATION_ID, new Field(SERVICE_SPECIFICATION_ID, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(SERVICE_SPECIFICATION_ID));
	}

	//TODO need to change the return type 
	public String getServiceSpecificationId() {
		return getFieldAsString(SERVICE_SPECIFICATION_ID);
	}

	public void setServiceSpecificationId(String serviceSpecificationId) {
		setField(SERVICE_SPECIFICATION_ID,serviceSpecificationId);
	}

	public String getServiceSpecificationCd() {
		return getFieldAsString(SERVICE_SPECIFICATION_CD);
	}

	public void setServiceSpecificationCd(String serviceSpecificationCd) {
		setField(SERVICE_SPECIFICATION_CD,serviceSpecificationCd);
	}

	public String getProtocolBridgeBlock() {
		return getFieldAsString(PROTOCOL_BRIDGE_BLOCK);
	}

	public  void setProtocolBridgeBlock(String protocolBridgeBlock) {
		setField(PROTOCOL_BRIDGE_BLOCK,protocolBridgeBlock);
	}

	public  String getProtocolGarpBlock() {
		return getFieldAsString(PROTOCOL_GARP_BLOCK);
	}

	public void setProtocolGarpBlock(String protocolGarpBlock) {
		setField(PROTOCOL_GARP_BLOCK,protocolGarpBlock);
	}

	public  String getProtocolAllLansBmg() {
		return getFieldAsString(PROTOCOL_ALL_LANS_BMG);
	}

	public  void setProtocolAllLansBmg(String protocolAllLansBmg) {
		setField(PROTOCOL_ALL_LANS_BMG,protocolAllLansBmg);
	}

}
