package com.centurylink.icl.armmediation.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.domainlayer.circuits.Circuit;
import com.centurylink.icl.arm.domainlayer.circuits.CircuitFactory;

import com.centurylink.icl.arm.persistancelayer.ARMTransactionContext;
import com.centurylink.icl.arm.persistancelayer.ARMTransactionManager;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;
import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;
import com.centurylink.icl.armmediation.armaccessobject.RouteToVlanSegment;

import com.centurylink.icl.armmediation.dataaccess.RouteDetailDAO;
import com.centurylink.icl.armmediation.dataaccess.RouteHeaderDAO;
import com.centurylink.icl.armmediation.dataaccess.RouteToVlanSegmentDAO;

import com.centurylink.icl.armmediation.service.TransportPathService;

import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CreateCircuitResponseBuilder;
import com.centurylink.icl.builder.cim2.CreateCircuitResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.DeleteCircuitResponseBuilder;
import com.centurylink.icl.builder.cim2.DeleteCircuitResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.RouteBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TopologicalLinkBuilder;
import com.centurylink.icl.builder.cim2.UpdateCircuitResponseBuilder;
import com.centurylink.icl.builder.cim2.UpdateCircuitResponseDocumentBuilder;

import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;

import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.DeleteCircuitRequestDocument;
import com.iclnbi.iclnbiV200.DeleteCircuitResponseDocument;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.Route;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UpdateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.UpdateCircuitResponseDocument;

import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;

public class TransportPathServiceImpl implements TransportPathService
{
	private static final Log LOG = LogFactory.getLog(TransportPathService.class);
	
	private static final String ASSET_OBJECT_DEVICE = "DEVICE";
	private static final String ASSET_OBJECT_CIRCUIT = "CIRCUIT";
	
	private static final String SOURCE_SYSTEM_ARM = "ARM";
	private static final String ASSET_TYPE_NID = "NID";
	private static final String ASSET_TYPE_NPE = "NPE";

	private static final String ROUTE_NAME_PREFIX = "RTE:";
	private static final String ROUTE_NAME_DELIMITER = "-";
	
	private static final String NIDDEVICENAME = "NIDDEVICENAME";
	
	private static final String SEQUENCE_NO = "SequenceNo";
	
	private RouteHeaderDAO routeHeaderDAO;
	private RouteDetailDAO routeDetailDAO;
	private RouteToVlanSegmentDAO routeToVlanSegmentDAO;

	public TransportPathServiceImpl(RouteHeaderDAO iRouteHeaderDAO, RouteDetailDAO iRouteDetailDAO, RouteToVlanSegmentDAO iRouteToVlanSegmentDAO)
	{
		this.routeHeaderDAO = iRouteHeaderDAO;
		this.routeDetailDAO = iRouteDetailDAO;
		this.routeToVlanSegmentDAO = iRouteToVlanSegmentDAO;
	}

	@Override
	public void insertRouteToVlanSegment(RouteToVlanSegment routeToVlanSegment)
	{
		this.routeToVlanSegmentDAO.insert(routeToVlanSegment);
	}
	
	public CreateCircuitResponseDocument createRoute(CreateCircuitRequestDocument requestDocument)
	{
		// Transform
		RouteHeader routeHeader = transformToRouteHeader(requestDocument.getCreateCircuitRequest().getCircuit().getRouteList().get(0));

		enrichRouteName(routeHeader);

		// TODO: wrap in transaction
		insertRoute(routeHeader);

		// Transform
		return transformToCim(routeHeader);
	}

	private void validateRouteData(RouteHeader routeHeader, Long routeHeaderId)
	{
/*
 * RouteHeaderId determines if a single route can exist with this NMI circuit in it.  null means no, otherwise
 * only with the indicated RouteHeaderId.		
 */
		if (null == routeHeader.getRouteDetailList() || routeHeader.getRouteDetailList().isEmpty())
			throw new ICLRequestValidationException("Route must contain a detail list");

		sortRouteDetailsBySeqNo(routeHeader.getRouteDetailList());
		
		int routeDetailCount = 0;
		for (RouteDetail routeDetail : routeHeader.getRouteDetailList())
		{
			if ((routeDetail.getAssetObject().equalsIgnoreCase(ASSET_OBJECT_DEVICE) && routeDetailCount % 2 == 0) ||
				(routeDetail.getAssetObject().equalsIgnoreCase(ASSET_OBJECT_CIRCUIT) && routeDetailCount % 2 != 0))
			{
				routeDetailCount++;
			}
			else
			{
				throw new ICLRequestValidationException("Route Detail list contains invalid Asset object " + routeDetail.getAssetObject() + " at Sequence " + routeDetailCount);
			}
		}

		if (routeDetailCount == 1)
		{
			throw new ICLRequestValidationException("Route Detail list only contains single Device");
		}
		else if (routeDetailCount % 2 == 0)
		{
			throw new ICLRequestValidationException("Route Detail list does not contain ending Device");
		}

		RouteDetail firstCircuit = routeHeader.getRouteDetailList().get(1);
		if (StringHelper.isEmpty(firstCircuit.getAssetValue()))
		{
			throw new ICLRequestValidationException("Route must have a value for the first circuit");
		}		
		else
		{
			List<RouteDetail> existingRouteDetailList = routeDetailDAO.lookupRouteDetailByFirstCircuitName(firstCircuit.getAssetValue());
			if (null != existingRouteDetailList && !existingRouteDetailList.isEmpty() &&
				(null == routeHeaderId || routeHeaderId.compareTo(existingRouteDetailList.get(0).getRouteHeaderId()) != 0))
			{
				throw new ICLRequestValidationException("First circuit is already used in existing route");
			}
		}
	}
	
	private static void sortRouteDetailsBySeqNo(List<RouteDetail> routeDetails)
	{
		Collections.sort(routeDetails, new Comparator<RouteDetail>()
		{
			public int compare(RouteDetail rd1, RouteDetail rd2)
			{
				return rd1.getSeqNo() - rd2.getSeqNo();
			}
		});
	}
	@Override
	public String createRouteName(String nidClli, String npeClli)
	{
		String routeName = ROUTE_NAME_PREFIX + nidClli + ROUTE_NAME_DELIMITER + npeClli + ROUTE_NAME_DELIMITER;
		return enrichRouteName(routeName);
	}
	
	@Override
	public void insertRoute(RouteHeader routeHeader)
	{		
		validateRouteData(routeHeader, null);
		// Insert Route Header
		this.routeHeaderDAO.insert(routeHeader);

		Long routeHeaderId = this.routeHeaderDAO.getRouteHeaderId(routeHeader.getRouteName());
		routeHeader.setRouteHeaderId(routeHeaderId);

		// Insert Route Details
		for(RouteDetail rd : routeHeader.getRouteDetailList())
		{
			this.routeDetailDAO.insert(rd);
		}
	}
	
	@Override
	public void linkToTransportPath(String newFirstCircuitName, String newFirstCircuitAssetType, String existingFirstDeviceName, String existingSecondDeviceName)
	{
		List<RouteDetail> routeDetailList = routeDetailDAO.lookupRouteDetailByFirstCircuitName(newFirstCircuitName);
		if(routeDetailList.size() > 0)
		{
			// newFirstCircuitName belongs to an existing route
			// If firstDevice, secondDevice, and AssetType of firstCircuit from input matches the DB, consider the call successful
			String firstDeviceValueInDB = getValueOfSeqNo(1, routeDetailList);
			if(!firstDeviceValueInDB.equalsIgnoreCase(existingFirstDeviceName))
				throw new ICLRequestValidationException("Input firstCircuit exists in route with a different first device");
			// The second device has a seqNo of 3 because it goes Device -> Circuit -> Device
			String secondDeviceValueInDb = getValueOfSeqNo(3, routeDetailList);
			if(!secondDeviceValueInDb.equalsIgnoreCase(existingSecondDeviceName))
				throw new ICLRequestValidationException("Input firstCircuit exists in route with a different second device");
			String firstCircuitAssetTypeInDB = routeDetailList.get(1).getAssetType();
			if(!firstCircuitAssetTypeInDB.equalsIgnoreCase(newFirstCircuitAssetType))
				throw new ICLRequestValidationException("Input firstCircuit exists with different AssetType");
			return;
		}
		
		RouteHeader existingRouteHeader = this.routeHeaderDAO.lookupRouteByNidDeviceName(existingFirstDeviceName, routeDetailDAO);
		
		// Can't copy route if one doesn't exist
		if(null == existingRouteHeader)
		{
			throw new ICLRequestValidationException("Input firstDevice does not have an existing route");
		}
		
		// Confirm second device on existing route is same as input
		String existingRouteSecondDeviceName = getValueOfSeqNo(3, existingRouteHeader.getRouteDetailList());
		if(!existingRouteSecondDeviceName.equalsIgnoreCase(existingSecondDeviceName))
		{
			throw new ICLRequestValidationException("Input first device exists in route with a different second device");
		}
		
		String newRouteName = createNewRouteNameFromExisting(existingRouteHeader.getRouteName());
		existingRouteHeader.setRouteName(newRouteName);
		
		updateFirstCircuitInRouteDetails(existingRouteHeader.getRouteDetailList(), newFirstCircuitAssetType, newFirstCircuitName);
		
		existingRouteHeader.setRouteHeaderId(null);
		
		insertRoute(existingRouteHeader);
	}
	
	private void updateFirstCircuitInRouteDetails(List<RouteDetail> routeDetails, String assetType, String assetValue)
	{
		routeDetails.get(1).setAssetType(assetType);
		routeDetails.get(1).setAssetValue(assetValue);
	}
	
	private String createNewRouteNameFromExisting(String existingRouteName)
	{
		existingRouteName = existingRouteName.replaceAll(ROUTE_NAME_PREFIX, "");
		String[] routeNameParts = existingRouteName.split(ROUTE_NAME_DELIMITER);
		return createRouteName(routeNameParts[0], routeNameParts[1]);
	}
	
	private String getValueOfType(String assetType, List<RouteDetail> routeDetailList)
	{
		for(RouteDetail routeDetail : routeDetailList)
		{
			if(routeDetail.getAssetType().equalsIgnoreCase(assetType))
			{
				return routeDetail.getAssetValue();
			}
		}
		
		return "";
	}
	
	private String getValueOfSeqNo(int seqNo, List<RouteDetail> routeDetailList)
	{
		RouteDetail routeDetailByIndex = routeDetailList.get(seqNo - 1);
		
		// If the details are ordered by SeqNo as expected this will be true and the fast way to get the data
		if(routeDetailByIndex.getSeqNo() == seqNo)
		{
			return routeDetailByIndex.getAssetValue();
		}
		
		// Just in case the details are not ordered, we will check all of them
		for(RouteDetail routeDetail : routeDetailList)
		{
			if(routeDetail.getSeqNo() == seqNo)
			{
				return routeDetail.getAssetValue();
			}
		}
		
		return "";
	}

	private void enrichRouteName(RouteHeader routeHeader)
	{
		String transformedRouteName = routeHeader.getRouteName();
		routeHeader.setRouteName(enrichRouteName(transformedRouteName));
	}
	
	private String enrichRouteName(String routeName)
	{
		List<String> likeRouteNames = this.routeHeaderDAO.getLikeRouteNames(routeName);
		int maxRouteNumber = 0;
		int currentRouteNumber;
		for(String existingRouteName : likeRouteNames)
		{
			String endingInt = existingRouteName.replaceAll(routeName, "");
			currentRouteNumber = Integer.parseInt(endingInt);
			if(currentRouteNumber > maxRouteNumber)
			{
				maxRouteNumber = currentRouteNumber;
			}
		}

		return routeName + (maxRouteNumber + 1);
	}

	private RouteHeader transformToRouteHeader(Route route)
	{
		PhysicalDevice firstAEndDevice = route.getTopologicalLinkListList().get(0).getAEndTpsList().get(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice();

		String nidDeviceName = firstAEndDevice.getCommonName();
		String firstAClli = firstAEndDevice.getCLLICode();
		int linkListSize = route.getTopologicalLinkListList().size();
		String lastZClli = route.getTopologicalLinkListList().get(linkListSize - 1).getZEndTpsList().get(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice().getCLLICode();

		RouteHeader routeHeader = new RouteHeader();
		routeHeader.setNidDeviceName(nidDeviceName);
		routeHeader.setRouteName(ROUTE_NAME_PREFIX + firstAClli + ROUTE_NAME_DELIMITER + lastZClli + ROUTE_NAME_DELIMITER);

		// Add first AEnd Device
		// Don't need to map subsequent AEnds because they should be previous ZEnds
		int currentSeqNo = 1;
		RouteDetail routeDetail = new RouteDetail();

		routeDetail.setAssetObject(ASSET_OBJECT_DEVICE);
		routeDetail.setAssetType(firstAEndDevice.getHasPhysicalDeviceRolesList().get(0).getCommonName());
		routeDetail.setAssetValue(firstAEndDevice.getCommonName());
		routeDetail.setSeqNo(currentSeqNo++);

		routeHeader.getRouteDetailList().add(routeDetail);

		for(TopologicalLink tl : route.getTopologicalLinkListList())
		{
			// Add Circuit
			routeDetail = new RouteDetail();

			routeDetail.setAssetObject(ASSET_OBJECT_CIRCUIT);
			routeDetail.setAssetType(tl.getResourceType());
			routeDetail.setAssetValue(tl.getCommonName());
			routeDetail.setSeqNo(currentSeqNo++);

			routeHeader.getRouteDetailList().add(routeDetail);

			// Add ZEnd Device
			routeDetail = new RouteDetail();

			PhysicalDevice zEndDevice = tl.getZEndTpsList().get(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice();

			routeDetail.setAssetObject(ASSET_OBJECT_DEVICE);
			routeDetail.setAssetType(zEndDevice.getHasPhysicalDeviceRolesList().get(0).getCommonName());
			routeDetail.setAssetValue(zEndDevice.getCommonName());
			routeDetail.setSeqNo(currentSeqNo++);

			routeHeader.getRouteDetailList().add(routeDetail);
		}

		return routeHeader;
	}

	private CreateCircuitResponseDocument transformToCim(RouteHeader routeHeader)
	{
		CreateCircuitResponseDocumentBuilder createCircuitResponseDocumentBuilder = new CreateCircuitResponseDocumentBuilder();
		CreateCircuitResponseBuilder createCircuitResponseBuilder = new CreateCircuitResponseBuilder();
		
		createCircuitResponseBuilder.buildCreateCircuitResponse();
		createCircuitResponseBuilder.addCircuit(transformToCircuit(routeHeader));
		createCircuitResponseDocumentBuilder.buildCreateCircuitResponseDocument(createCircuitResponseBuilder.getCreateCircuitResponse());
		
		return createCircuitResponseDocumentBuilder.getCreateCircuitResponseDocument();
	}

	private SubNetworkConnection transformToCircuit(RouteHeader routeHeader)
	{
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		subNetworkConnectionBuilder.buildSubNetworkConnection(routeHeader.getRouteName(), routeHeader.getRouteHeaderId().toString(), null, SOURCE_SYSTEM_ARM, null, null, null, null);
		
		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}
		
	public SearchResourceResponseDocument searchRoute(SearchResourceRequestDocument requestDocument) throws Exception
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		searchResourceResponseBuilder.buildSearchResourceResponse(null, null);
		
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		RouteBuilder routeBuilder = new RouteBuilder();
		TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder(); 
/*
 * Get the list of routes for the NID DeviceName and build a SubNetworkConnection for each (TransformToRouteHeaderList)
 */
		List<RouteHeader> routeHeaderList;
		if (StringHelper.isEmpty(requestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName()))
		{
			routeHeaderList = this.routeHeaderDAO.searchRouteByNid(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(requestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), NIDDEVICENAME), routeDetailDAO);
		}
		else
		{
			routeHeaderList = this.routeHeaderDAO.lookupRouteHeaderWithDetails(requestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName(), routeDetailDAO);
		}
/*
 * Ensure there is something to detail...		
 */
		if (routeHeaderList.isEmpty())
			throw new OSSDataNotFoundException();
/*
 * Build a circuit, route, topological list, aEnd, zEnd for the route details (TransformToCim)
 */
		for (RouteHeader routeHeader : routeHeaderList)
		{
			String[] clliCodes = routeHeader.getRouteName().replaceAll(ROUTE_NAME_PREFIX, "").split(ROUTE_NAME_DELIMITER);

			subNetworkConnectionBuilder.buildSubNetworkConnection(routeHeader.getRouteName(), routeHeader.getRouteHeaderId().toString(), null, SOURCE_SYSTEM_ARM, null, null, null, null);
			routeBuilder.buildRoute();
/*
 * For searchRoute, add termination points from Device/Circuit records.  The order is required to be NID DEVICE ...  CIRCUIT ..  DEVICE ... CIRCUIT ... NPE DEVICE		
 */
			validateRouteData(routeHeader, routeHeader.getRouteHeaderId());
			int routeDetailCount = 0;
			for (RouteDetail routeDetail : routeHeader.getRouteDetailList())
			{
				if (routeDetail.getAssetObject().equalsIgnoreCase(ASSET_OBJECT_DEVICE))
				{
					physicalDeviceRoleBuilder.buildPhysicalDeviceRole(routeDetail.getAssetType());
					physicalDeviceBuilder.buildPhysicalDevice(routeDetail.getAssetValue(), routeDetail.getRouteDetailId().toString(), null, null, null, null, null, null, null, null, null, null, null, null);
					if (routeDetail.getAssetType().equalsIgnoreCase(ASSET_TYPE_NID))
					{
						physicalDeviceBuilder.setCLLICodes(clliCodes[0], null);
					} 
					else if (routeDetail.getAssetType().equalsIgnoreCase(ASSET_TYPE_NPE))
					{
						physicalDeviceBuilder.setCLLICodes(clliCodes[1], null);
					}
					physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
					physicalDeviceBuilder.addResourceDescribedBy(SEQUENCE_NO, Integer.toString(routeDetail.getSeqNo()));
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
					connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
					connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					if (routeDetailCount != 0)
					{
						topologicalLinkBuilder.addZEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
						routeBuilder.addTopologicalLink(topologicalLinkBuilder.getTopologicalLink());
					}
				}
				else if (routeDetail.getAssetObject().equalsIgnoreCase(ASSET_OBJECT_CIRCUIT))
				{
					topologicalLinkBuilder.buildTopologicalLink(routeDetail.getAssetValue(), routeDetail.getRouteDetailId().toString(), null, null, routeDetail.getAssetType().toUpperCase(), null, null, null, null);
					topologicalLinkBuilder.addResourceDescribedBy(SEQUENCE_NO, Integer.toString(routeDetail.getSeqNo()));
					topologicalLinkBuilder.addAEndTps(connectionTerminationPointBuilder.getConnectionTerminationPoint());
				}
				routeDetailCount++;
			}
			subNetworkConnectionBuilder.addRoute(routeBuilder.getRoute());
			searchResponseDetailsBuilder.addCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
		}
		
		searchResourceResponseBuilder.addSearchResponseDetails(searchResponseDetailsBuilder.getSearchResponseDetails());
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}
	
	public DeleteCircuitResponseDocument deleteRoute(DeleteCircuitRequestDocument requestDocument) throws Exception
	{
/*
 * Get the RouteHeaderId from the routeName (TransformToRouteHeaderId)		
 */
		Long routeHeaderId = this.routeHeaderDAO.getRouteHeaderId(requestDocument.getDeleteCircuitRequest().getCircuit().getCommonName());
		if (routeHeaderId == null)
			throw new OSSDataNotFoundException();
		
		if (this.routeToVlanSegmentDAO.getSegmentCountForRouteHeaderId(routeHeaderId) > 0)
			throw new ICLRequestValidationException("Active VLAN Segments exist on route");
/*
 * Delete the Associated Route Details and Header
 */
		this.routeDetailDAO.deleteAll(routeHeaderId);
		this.routeHeaderDAO.delete(routeHeaderId);
/*
 * Build the response (TransformToCim)		
 */
		DeleteCircuitResponseDocumentBuilder deleteCircuitResponseDocumentBuilder = new DeleteCircuitResponseDocumentBuilder();
		DeleteCircuitResponseBuilder deleteCircuitResponseBuilder = new DeleteCircuitResponseBuilder();
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		subNetworkConnectionBuilder.buildSubNetworkConnection(requestDocument.getDeleteCircuitRequest().getCircuit().getCommonName(), routeHeaderId.toString(), null, SOURCE_SYSTEM_ARM, null, null, null, null);
		deleteCircuitResponseBuilder.buildDeleteCircuitResponse(null, subNetworkConnectionBuilder.getSubNetworkConnection(), null);
		deleteCircuitResponseDocumentBuilder.buildDeleteCircuitResponseDocument(deleteCircuitResponseBuilder.getDeleteCircuitResponse());
		
		return deleteCircuitResponseDocumentBuilder.getDeleteCircuitResponseDocument();
	}

	public UpdateCircuitResponseDocument updateRoute(UpdateCircuitRequestDocument requestDocument)
	{
		UpdateCircuitResponseDocumentBuilder updateCircuitResponseDocumentBuilder = new UpdateCircuitResponseDocumentBuilder();
		UpdateCircuitResponseBuilder updateCircuitResponseBuilder = new UpdateCircuitResponseBuilder();
		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
/*
 * Get the route to be updated	
 */
		RouteHeader fromRouteHeader = this.routeHeaderDAO.lookupRouteHeaderWithoutDetails(requestDocument.getUpdateCircuitRequest().getCircuit().getCommonName());
		if (fromRouteHeader == null)
			throw new OSSDataNotFoundException();
		LOG.info("Existing RouteHeaderId  " + fromRouteHeader.getRouteHeaderId() + " NID " + fromRouteHeader.getNidDeviceName());
/*
 * Transform Update Circuit to Route Header and use existing Route Header Id
 */
		RouteHeader routeHeader = transformToRouteHeader(requestDocument.getUpdateCircuitRequest().getCircuit().getRouteList().get(0));
		validateRouteData(routeHeader, fromRouteHeader.getRouteHeaderId());
		routeHeader.setRouteHeaderId(fromRouteHeader.getRouteHeaderId());
/*
 * From and To NID devices must be the same 		
 */
		if (!routeHeader.getNidDeviceName().equalsIgnoreCase(fromRouteHeader.getNidDeviceName()))
			throw new ICLException("From/To NID Device names must be the same");
/*
 * Get the existing NPE route Detail for this route (last detail)
 */
		int lastDevice = routeHeader.getRouteDetailList().size() - 1;
		RouteDetail routeDetailNPE = this.routeDetailDAO.getNPEForRoute(routeHeader.getRouteHeaderId(), routeHeader.getRouteDetailList().get(lastDevice).getAssetValue());
		if (routeDetailNPE == null)
		{
			enrichRouteName(routeHeader);
			LOG.info("Updating Route Name  " + routeHeader.getRouteName());
			this.routeHeaderDAO.update(routeHeader.getRouteName(), routeHeader.getNidDeviceName(), routeHeader.getRouteHeaderId());
		}
		else
		{
			routeHeader.setRouteName(fromRouteHeader.getRouteName());
		}
/*
 * Delete all existing Route Details		
 */
		LOG.info("Deleting Existing Route Details  " + routeHeader.getRouteName());
		this.routeDetailDAO.deleteAll(routeHeader.getRouteHeaderId());
/*
 * Add the new Route Details		
 */
		for (RouteDetail routeDetail : routeHeader.getRouteDetailList())
		{
			LOG.info("Adding New Route Detail  " + routeDetail.getAssetObject() + "-" + routeDetail.getAssetType() + "-" + routeDetail.getAssetValue());
			this.routeDetailDAO.insert(routeDetail);
		}
/*
 * Get the start and end ports from the routeDetail first/last Circuit Entries (nid/npe)		
 */
		Circuit nidCircuit = CircuitFactory.newCircuitInstance();
		Circuit npeCircuit = CircuitFactory.newCircuitInstance();
		try
		{
			int nid = 1;
			nidCircuit = (Circuit)nidCircuit.findByName(routeHeader.getRouteDetailList().get(nid).getAssetValue());
			int npe = routeHeader.getRouteDetailList().size() - 2;
			npeCircuit = (Circuit)npeCircuit.findByName(routeHeader.getRouteDetailList().get(npe).getAssetValue());
		}
		catch (Exception e)
		{
			LOG.info("Error Accessing NID/NPE Circuits in ARM...");
			LOG.info("Msg: " + e.getMessage());
			throw new ICLException("Error Accessing NID/NPE Circuit - " + e.getMessage());
		}
/*
 * Update the VLAN 2 Route Segments for the New Route		
 */
		ARMTransactionContext myARMTransactionContext = ARMTransactionManager.startTransaction("TransportPathService");

		List<RouteToVlanSegment> routeToVlanSegmentList = this.routeToVlanSegmentDAO.getVlanSegmentsForRouteHeaderId(routeHeader.getRouteHeaderId());
		
		for (RouteToVlanSegment routeToVlanSegment : routeToVlanSegmentList)
		{
			LOG.info("Processing VlanSegment " + routeToVlanSegment.getVlanSegments());
			try
			{
				Circuit vlanCircuit = CircuitFactory.newCircuitInstance();
				vlanCircuit = (Circuit)vlanCircuit.findByName(routeToVlanSegment.getVlanSegments());
				LOG.info("VlanSegment CircuitID " + vlanCircuit.properties().getCircuitId());
				List<Circuit> underlyingCircuitList = vlanCircuit.getUnderlyingCircuits();
				LOG.info("UnderlyingCircuit count " + underlyingCircuitList.size());
				for (Circuit underlyingCircuit : underlyingCircuitList)
				{
					LOG.info("Removing UnderLyingCircuit " + underlyingCircuit.properties().getCircuitId());
					vlanCircuit.removeUnderLyingCircuit(underlyingCircuit.properties().getCircuitId());
				}
				for (RouteDetail routeDetail : routeHeader.getRouteDetailList())
				{
					if (routeDetail.getAssetObject().equalsIgnoreCase(ASSET_OBJECT_CIRCUIT))
					{
						LOG.info("Processing Route Detail Circuit " + routeDetail.getAssetValue());
						Circuit newCircuit = CircuitFactory.newCircuitInstance();
						newCircuit = (Circuit)newCircuit.findByName(routeDetail.getAssetValue());
						LOG.info("Adding UnderLyingCircuit2RoutedCircuit " + newCircuit.properties().getCircuitId() + ", " + nidCircuit.properties().getCircuit2StartPort() + ", " + npeCircuit.properties().getCircuit2EndPort());
						vlanCircuit.addUnderlyingCircuit2RoutedCircuit(newCircuit.properties().getCircuitId(), nidCircuit.properties().getCircuit2StartPort(), npeCircuit.properties().getCircuit2EndPort());
					}
				}
				LOG.info("Before setResolutionStatus()");
				vlanCircuit.setResolutionStatus();
			}
			catch (Exception e)
			{
				LOG.info("Error processing VlanSegment " + routeToVlanSegment.getVlanSegments());
				LOG.info("Msg: " + e.getMessage());
				throw new ICLException("Error updating VlanCircuit - " + e.getMessage());
			}
		}
		
		myARMTransactionContext.commit();		
/*
 * Build the response (TransformToCim)
 */
		subNetworkConnectionBuilder.buildSubNetworkConnection(routeHeader.getRouteName(), routeHeader.getRouteHeaderId().toString(), null, SOURCE_SYSTEM_ARM, null, null, null, null);
		updateCircuitResponseBuilder.buildUpdateCircuitResponse(null, subNetworkConnectionBuilder.getSubNetworkConnection(), null);
		updateCircuitResponseDocumentBuilder.buildUpdateCircuitResponseDocument(updateCircuitResponseBuilder.getUpdateCircuitResponse());
		
		return updateCircuitResponseDocumentBuilder.getUpdateCircuitResponseDocument();
	}
}
