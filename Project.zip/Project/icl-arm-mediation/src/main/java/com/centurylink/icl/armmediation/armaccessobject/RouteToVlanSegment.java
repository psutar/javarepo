package com.centurylink.icl.armmediation.armaccessobject;

public class RouteToVlanSegment {

	private Long routeToVlanSegmentId;
	private Long routeHeaderId;
	private String vlanSegments;
	
	public Long getRouteToVlanSegmentId() {
		return routeToVlanSegmentId;
	}
	public void setRouteToVlanSegmentId(Long routeToVlanSegmentId) {
		this.routeToVlanSegmentId = routeToVlanSegmentId;
	}
	public Long getRouteHeaderId() {
		return routeHeaderId;
	}
	public void setRouteHeaderId(Long routeHeaderId) {
		this.routeHeaderId = routeHeaderId;
	}
	public String getVlanSegments() {
		return vlanSegments;
	}
	public void setVlanSegments(String vlanSegments) {
		this.vlanSegments = vlanSegments;
	}
}
