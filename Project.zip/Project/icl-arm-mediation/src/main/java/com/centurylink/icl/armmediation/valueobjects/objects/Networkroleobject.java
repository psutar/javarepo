package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;
import com.centurylink.icl.valueobjects.impl.ReferenceField;

public class Networkroleobject extends AbstractReadOnlyTable {

	private static final String RPPLANID = "RPPLANID";
	private static final String NETWORKROLEOBJECT2NETWORKROLE = "NETWORKROLEOBJECT2NETWORKROLE";
	private static final String NETWORKROLEOBJECT2DIMOBJECT = "NETWORKROLEOBJECT2DIMOBJECT";
	private static final String NETWORKROLEOBJECT2RELATION = "NETWORKROLEOBJECT2RELATION";
	private static final String NETWORKROLEOBJECT2OBJECT = "NETWORKROLEOBJECT2OBJECT";
	private static final String SEQUENCE = "SEQUENCE";
	private static final String NETWORKROLEOBJECTID = "NETWORKROLEOBJECTID";

	public Networkroleobject()
	{
		super();
		this.tableName = "NETWORKROLEOBJECT";
	}

	public Networkroleobject(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Networkroleobject> getNetworkroleobjectListByQuery(String query)
	{
		Networkroleobject networkroleobject = new Networkroleobject();
		List<Networkroleobject> networkroleobjectList = new ArrayList<Networkroleobject>();
		List<Map<String,Object>> foundNetworkroleobjectList = networkroleobject.getRecordsByQuery(query);

		for (Map<String,Object> networkroleobjectMap : foundNetworkroleobjectList)
		{
			Networkroleobject workNetworkroleobject = new Networkroleobject(networkroleobjectMap.get(NETWORKROLEOBJECTID).toString());
			networkroleobjectList.add(workNetworkroleobject);
		}
		return networkroleobjectList;
	}
	
	public static List<Networkroleobject> getNetworkroleobjectListByObject(String objectId, String dimObjectId)
	{
		String query = NETWORKROLEOBJECT2OBJECT + " = " + objectId + " AND " + NETWORKROLEOBJECT2DIMOBJECT + " = " + dimObjectId;
		return getNetworkroleobjectListByQuery(query);
	}
	
	@Override
	public void populateModel()
	{
		fields.put(NETWORKROLEOBJECT2NETWORKROLE, new ReferenceField(NETWORKROLEOBJECT2NETWORKROLE, Field.TYPE_NUMERIC, "NETWORKROLE", "ALIAS1", "NETWORKROLEID", this.getClass().getName()));

		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(NETWORKROLEOBJECT2DIMOBJECT, new Field(NETWORKROLEOBJECT2DIMOBJECT, Field.TYPE_NUMERIC));
		fields.put(NETWORKROLEOBJECT2RELATION, new Field(NETWORKROLEOBJECT2RELATION, Field.TYPE_NUMERIC));
		fields.put(NETWORKROLEOBJECT2OBJECT, new Field(NETWORKROLEOBJECT2OBJECT, Field.TYPE_NUMERIC));
		fields.put(SEQUENCE, new Field(SEQUENCE, Field.TYPE_NUMERIC));
		fields.put(NETWORKROLEOBJECTID, new Field(NETWORKROLEOBJECTID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(NETWORKROLEOBJECTID));
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setNetworkroleobject2networkrole(String networkroleobject2networkrole)
	{
		setField(NETWORKROLEOBJECT2NETWORKROLE,networkroleobject2networkrole);
	}

	public String getNetworkroleobject2networkrole()
	{
		return getFieldAsString(NETWORKROLEOBJECT2NETWORKROLE);
	}

	public void setNetworkroleobject2dimobject(String networkroleobject2dimobject)
	{
		setField(NETWORKROLEOBJECT2DIMOBJECT,networkroleobject2dimobject);
	}

	public String getNetworkroleobject2dimobject()
	{
		return getFieldAsString(NETWORKROLEOBJECT2DIMOBJECT);
	}

	public void setNetworkroleobject2relation(String networkroleobject2relation)
	{
		setField(NETWORKROLEOBJECT2RELATION,networkroleobject2relation);
	}

	public String getNetworkroleobject2relation()
	{
		return getFieldAsString(NETWORKROLEOBJECT2RELATION);
	}

	public void setNetworkroleobject2object(String networkroleobject2object)
	{
		setField(NETWORKROLEOBJECT2OBJECT,networkroleobject2object);
	}

	public String getNetworkroleobject2object()
	{
		return getFieldAsString(NETWORKROLEOBJECT2OBJECT);
	}

	public void setSequence(String sequence)
	{
		setField(SEQUENCE,sequence);
	}

	public String getSequence()
	{
		return getFieldAsString(SEQUENCE);
	}

	public void setNetworkroleobjectid(String networkroleobjectid)
	{
		setField(NETWORKROLEOBJECTID,networkroleobjectid);
	}

	public String getNetworkroleobjectid()
	{
		return getFieldAsString(NETWORKROLEOBJECTID);
	}
}
