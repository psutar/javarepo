package com.centurylink.icl.armmediation.transformation;

import com.centurylink.icl.armmediation.service.CreateDeviceClliRequest;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

public class CreateDeviceClliFromCim {

	public CreateDeviceClliRequest transfromFromCim(CreateDeviceRequestDocument createDeviceRequestDocuemt)
	{
		CreateDeviceClliRequest createDeviceClliRequest = new CreateDeviceClliRequest();
		
		String locationClli = createDeviceRequestDocuemt.getCreateDeviceRequest().getDeviceList().get(0).getLocationCLLI();
		String equipmentType = createDeviceRequestDocuemt.getCreateDeviceRequest().getDeviceList().get(0).getResourceSubType();
		createDeviceClliRequest.setLocationClli(locationClli);
		createDeviceClliRequest.setEquipmentType(equipmentType);
		
		return createDeviceClliRequest;
	}
}
