package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class CircuitValuesMaxNum extends AbstractReadOnlyTable {

	private static final long serialVersionUID = 1L;
	
	private static final String MAX_VALUE = "MAX_VALUE";
	private static final String MAX_COLUMN_NAME = "MAX_COLUMN_NAME";
	private static final String SERVICE_TYPE = "SERVICE_TYPE";
	private static final String CIRCUIT_VALUES_MAX_NUM_ID = "CIRCUIT_VALUES_MAX_NUM_ID";

	public CircuitValuesMaxNum()
	{
		super();
		this.tableName = "CIRCUIT_VALUES_MAX_NUM";
	}

	public CircuitValuesMaxNum(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<CircuitValuesMaxNum> getCircuitValuesMaxNumListByServiceType(String serviceType)
	{
		return getCircuitValuesMaxNumListByQuery(SERVICE_TYPE + " = '" + serviceType.toUpperCase() + "'");
	}
	
	public static List<CircuitValuesMaxNum> getCircuitValuesMaxNumListByQuery(String query)
	{
		CircuitValuesMaxNum circuitvaluesmaxnum = new CircuitValuesMaxNum();
		List<CircuitValuesMaxNum> circuitvaluesmaxnumList = new ArrayList<CircuitValuesMaxNum>();
		List<Map<String,Object>> foundCircuitValuesMaxNumList = circuitvaluesmaxnum.getRecordsByQuery(query);

		for (Map<String,Object> circuitvaluesmaxnumMap : foundCircuitValuesMaxNumList)
		{
			CircuitValuesMaxNum workCircuitValuesMaxNum = new CircuitValuesMaxNum(circuitvaluesmaxnumMap.get(CIRCUIT_VALUES_MAX_NUM_ID).toString());
			circuitvaluesmaxnumList.add(workCircuitValuesMaxNum);
		}
		return circuitvaluesmaxnumList;
	}

	@Override
	public void populateModel()
	{
		fields.put(MAX_VALUE, new Field(MAX_VALUE, Field.TYPE_NUMERIC));
		fields.put(MAX_COLUMN_NAME, new Field(MAX_COLUMN_NAME, Field.TYPE_VARCHAR));
		fields.put(SERVICE_TYPE, new Field(SERVICE_TYPE, Field.TYPE_VARCHAR));
		fields.put(CIRCUIT_VALUES_MAX_NUM_ID, new Field(CIRCUIT_VALUES_MAX_NUM_ID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CIRCUIT_VALUES_MAX_NUM_ID));
	}

	public void setMaxValue(String maxValue)
	{
		setField(MAX_VALUE,maxValue);
	}

	public String getMaxValue()
	{
		return getFieldAsString(MAX_VALUE);
	}

	public void setMaxColumnName(String maxColumnName)
	{
		setField(MAX_COLUMN_NAME,maxColumnName);
	}

	public String getMaxColumnName()
	{
		return getFieldAsString(MAX_COLUMN_NAME);
	}

	public void setServiceType(String serviceType)
	{
		setField(SERVICE_TYPE,serviceType);
	}

	public String getServiceType()
	{
		return getFieldAsString(SERVICE_TYPE);
	}

	public void setCircuitValuesMaxNumId(String circuitValuesMaxNumId)
	{
		setField(CIRCUIT_VALUES_MAX_NUM_ID,circuitValuesMaxNumId);
	}

	public String getCircuitValuesMaxNumId()
	{
		return getFieldAsString(CIRCUIT_VALUES_MAX_NUM_ID);
	}


}