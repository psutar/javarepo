package com.centurylink.icl.armmediation.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.dataaccess.SearchLocationDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.SearchLocationToCim;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.centurylink.icl.exceptions.ICLException;
public class SearchLocationService
{
	private static final Log LOG = LogFactory.getLog(SearchLocationService.class);
	private SearchLocationToCim searchLocationToCim;
	private SearchLocationDAO searchLocationDAO;

	public void setSearchLocationToCim(SearchLocationToCim searchLocationToCim)
	{
		this.searchLocationToCim = searchLocationToCim;
	}

	public void setSearchLocationDAO(SearchLocationDAO searchLocationDAO)
	{
		this.searchLocationDAO = searchLocationDAO;
	}

	public SearchResourceResponseDocument searchLocation(SearchResourceRequestDocument request)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Inside LookupLocation");
		}
		final List<String> clliList = MediationUtil.getRcv(request.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueListList(), Constants.CLLI);

		if (clliList == null || clliList.isEmpty())
		{
			return MediationUtil.getSearchResourceErrorResponse("1948", "ICLRequestValidationError", "Request validation failure due to invalid input xml", request);
		}
		if(clliList.get(0).length() != 8)
		{
			throw new ICLException("ICLRequestValidationError", "CLLI should only be 8 characters", "1948");
		}
		final List<ARMLocation> locationList = searchLocationDAO.searchLocation(buildLocationQuery(clliList));
		final SearchResourceResponseDocument response = searchLocationToCim.transformToCim(locationList, request);
		if (LOG.isInfoEnabled())
		{
			LOG.info(response.toString());
		}
		return response;
	}

	private String buildLocationQuery(List<String> clliList)
	{

		final SQLBuilder sql = new SQLBuilder(Constants.LOCATION);

		sql.addField("LOCATION.NAME", Constants.NAME);
		sql.addField("LOCATION.LOCATIONID", Constants.LOCATION_ID);
		sql.addField("LOCATION.FULLNAME", Constants.FULL_NAME);
		sql.addField("LOCATION.PROVINCE", Constants.PROVINCE);
		sql.addField("LOCATION.TOWNCITY", Constants.TOWNCITY);
		sql.addField("LOCATION.ZIP", Constants.ZIP);
		sql.addField("LOCATION.ADDRESS1", Constants.ADDRESS1);
		sql.addField("LOCATION.ADDRESS2", Constants.ADDRESS2);
		sql.addField("LOCATION.ADDRESS3", Constants.ADDRESS3);
		sql.addField("EXT_LOCATION_BUILDING_SITE.PHONESWITCHCLLI", Constants.PHONE_SWITCH_CLLI);
		sql.addField("EXT_LOCATION_BUILDING_SITE.HCOORDINATE", Constants.HCOORDINATE);
		sql.addField("EXT_LOCATION_BUILDING_SITE.VCOORDINATE", Constants.VCOORDINATE);
		sql.addField("EXT_LOCATION_BUILDING_SITE.LATA", Constants.LATA);
		sql.addField("EXT_LOCATION_BUILDING_SITE.NPA", Constants.NPA);
		sql.addField("EXT_LOCATION_BUILDING_SITE.NXX", Constants.NXX);
		sql.addField("LOCATIONTYPE.NAME", Constants.LOCATION_TYPE_NAME);
		sql.addField("EXT_LOCATION_BUILDING_SITE.CLLICODE", Constants.CLLI_CODE);

		sql.addTable(Constants.EXT_LOCATION_BUILDING_SITE);
		sql.addTable(Constants.LOCATION_TYPE);

		sql.eq(Constants.LOCATION, Constants.LOCATION_ID, Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID);
		sql.eq(Constants.LOCATION, Constants.LOCATION_2_LOCATION_TYPE, Constants.LOCATION_TYPE, Constants.LOCATION_TYPE_ID);
		sql.in(Constants.EXT_LOCATION_BUILDING_SITE, Constants.CLLI_CODE, clliList);

		final String query = sql.getStatement();

		if (LOG.isInfoEnabled())
		{
			LOG.info("Query for Search Location :: " + query);
		}

		return query;
	}
}
