package com.centurylink.icl.armmediation.armaccessobject;

import java.util.ArrayList;
import java.util.List;

public class RouteHeader {

	private String routeName;
	private Long routeHeaderId;
	private String nidDeviceName;
	
	private List<RouteDetail> routeDetailList = new ArrayList<RouteDetail>();
	
	public List<RouteDetail> getRouteDetailList() {
		return routeDetailList;
	}

	public void setRouteDetailList(List<RouteDetail> routeDetailList) {
		this.routeDetailList = routeDetailList;
	}

	public String getRouteName() {
		return routeName;
	}
	
	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}
	
	public Long getRouteHeaderId() {
		return routeHeaderId;
	}
	
	public void setRouteHeaderId(Long routeHeaderId) {
		this.routeHeaderId = routeHeaderId;
		
		// This assumes that all of the routeDetails have been added to the list
		// or any routeDetails added later will have the routeHeaderId set
		for(RouteDetail rd : routeDetailList)
		{
			rd.setRouteHeaderId(routeHeaderId);
		}
	}
	
	public String getNidDeviceName() {
		return nidDeviceName;
	}
	
	public void setNidDeviceName(String nidDeviceName) {
		this.nidDeviceName = nidDeviceName;
	}
}
