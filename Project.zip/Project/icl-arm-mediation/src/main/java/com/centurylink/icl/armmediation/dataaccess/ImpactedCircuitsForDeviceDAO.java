package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;

public interface ImpactedCircuitsForDeviceDAO 
{

	public List<ARMImpactedCircuits> getImpactedCircuitsForDevice(String query, Boolean funcStatus)throws Exception;

	public List<ARMImpactedCircuits> getImpactedServicesForDevice(String query, Boolean funcStatus) throws Exception;
	
	
	public List<ARMImpactedCircuits> getRelatedImpactedServicesForDevice(String query) throws Exception;
	
}
