package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.UpdateLocationResponseBuilder;
import com.centurylink.icl.builder.cim2.UpdateLocationResponseDocumentBuilder;
import com.iclnbi.iclnbiV200.UpdateLocationRequestDocument;
import com.iclnbi.iclnbiV200.UpdateLocationResponseDocument;

public class ARMUpdateLocationToCim {

	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final UpdateLocationResponseDocumentBuilder updateLocationResponseDocumentBuilder;
	private final UpdateLocationResponseBuilder		    updateLocationResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;
	private final AmericanPropertyAddressBuilder        americanPropertyAddressBuilder;
	public ARMUpdateLocationToCim()
	{
		updateLocationResponseBuilder = new UpdateLocationResponseBuilder();
		updateLocationResponseDocumentBuilder = new UpdateLocationResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
	}
	
	public UpdateLocationResponseDocument transformToCim(UpdateLocationRequestDocument updateRequest, String objectName, String objectid,String addressType)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("UpdateLocation : Transform to CIM");
		}

		americanPropertyAddressBuilder.buildAmericanPropertyAddress(objectName, objectid, null, null, null, null, null, null, null, null, null,addressType);
		
		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(updateRequest.getUpdateLocationRequest().getMessageElements().getMessageAddressing());
		updateLocationResponseBuilder.buildUpdateLocationResponse();
		updateLocationResponseBuilder.addAddressDetails(americanPropertyAddressBuilder.getAmericanPropertyAddress());
		updateLocationResponseDocumentBuilder.buildUpdateLocationResponseDocument(updateLocationResponseBuilder.getUpdateLocationResponse());
		return updateLocationResponseDocumentBuilder.getUpdateLocationResponseDocument();
	}
	
	public UpdateLocationResponseDocument transformErrorToCim(UpdateLocationRequestDocument updateRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("UpdateLocation : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(updateRequest.getUpdateLocationRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		updateLocationResponseBuilder.buildUpdateLocationResponse();
		updateLocationResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		updateLocationResponseDocumentBuilder.buildUpdateLocationResponseDocument(updateLocationResponseBuilder.getUpdateLocationResponse());
		return updateLocationResponseDocumentBuilder.getUpdateLocationResponseDocument();
	}
	
}
