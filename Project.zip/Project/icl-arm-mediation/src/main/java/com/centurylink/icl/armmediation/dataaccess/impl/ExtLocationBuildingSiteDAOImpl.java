package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;



import javax.sql.DataSource;


import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


import com.centurylink.icl.armmediation.armaccessobject.LocationBuildingSite;
import com.centurylink.icl.armmediation.dataaccess.ExtLocationBuildingSiteDAO;

public class ExtLocationBuildingSiteDAOImpl implements ExtLocationBuildingSiteDAO {

	private JdbcTemplate jdbcTemplate;
	private static final String QUERY_BY_CLLI = "SELECT * FROM EXT_LOCATION_BUILDING_SITE WHERE CLLICODE = ?";
	
	public ExtLocationBuildingSiteDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}	
	

	@Override
	public LocationBuildingSite getlocationClli(String clliCode)
	{
		try
		{
			return  this.jdbcTemplate.queryForObject(QUERY_BY_CLLI,new Object[] {clliCode}, new buildingSiteMapper());
			
		}
		catch (EmptyResultDataAccessException e)
		{
			return null;
		}
	 	 			
	 		 
	}	
	
	private class buildingSiteMapper implements RowMapper<LocationBuildingSite>
	{
		@Override
		public LocationBuildingSite mapRow(ResultSet rs, int rowNum) throws SQLException {
			LocationBuildingSite locationBuildingSite = new LocationBuildingSite();
			locationBuildingSite.setLocationID(rs.getLong("LOCATIONID"));
			locationBuildingSite.setLATA(rs.getLong("LATA"));
			locationBuildingSite.setClliCode(rs.getString("CLLICODE"));
			locationBuildingSite.setHCoordinate(rs.getLong("HCOORDINATE"));
			locationBuildingSite.setLabel(rs.getInt("LABEL"));
			locationBuildingSite.setNPA(rs.getInt("NPA"));
			locationBuildingSite.setVCoordinate(rs.getLong("VCOORDINATE"));
			locationBuildingSite.setPhoneSwithClli(rs.getString("PHONESWITCHCLLI"));
			locationBuildingSite.setCreationUser(rs.getString("CREATIONUSER"));
			locationBuildingSite.setIsVisible(rs.getInt("ISVISIBLE"));
			locationBuildingSite.setRPPlanId(rs.getInt("RPPLANID"));
			locationBuildingSite.setNXX(rs.getInt("NXX"));
			locationBuildingSite.setHVP(rs.getString("HVP"));
			
			return locationBuildingSite;
		}
	}
	
}