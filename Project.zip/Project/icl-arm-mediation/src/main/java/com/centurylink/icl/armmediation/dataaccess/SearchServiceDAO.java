package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

public interface SearchServiceDAO
{
	public List<Long> getServiceIdsBySubscriber(String subscriber) throws Exception;
}
