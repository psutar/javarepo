package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.centurylink.icl.querybuilder.interfaces.VariableAndValueProcessor;
import com.centurylink.icl.querybuilder.translator.MultipleFieldTranslator;
import com.centurylink.icl.querybuilder.translator.ValueListTranslator;
import com.centurylink.icl.querybuilder.translator.ValueTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.VariableTranslatorOnly;
import com.centurylink.icl.querybuilder.translator.value.ConvertToUpperCase;
import com.centurylink.icl.querybuilder.translator.value.ValueMapper;

public class DeviceVOService {
	
	private static final Log LOG = LogFactory.getLog(DeviceVOService.class);
	private QueryBuilder queryBuilder;

	public DeviceVOService()
	{
		Map<String, VariableAndValueProcessor> variableAndValueProcessorMap = new HashMap<String, VariableAndValueProcessor>();
		variableAndValueProcessorMap.put("NAME", new ValueTranslatorOnly("NODE.NAME", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("LOCATIONNAME", new ValueTranslatorOnly("LOCATION.NAME", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("DEVICETYPE", new VariableTranslatorOnly("NODETYPE.NAME"));
		variableAndValueProcessorMap.put("DEVICESUBTYPE", new VariableTranslatorOnly("NODEDEF.NAME"));
		variableAndValueProcessorMap.put("SUBSCRIBER", new ValueTranslatorOnly("NODE.RELATIVENAME", new ConvertToUpperCase()));
		variableAndValueProcessorMap.put("DEVICECLLI", new ValueTranslatorOnly("EXT_DEVICE_TYPE.CLLI", new ConvertToUpperCase()));
		
		//The shared or dedicated flag in ARM is stored with Camel Case vs all UpperCase, this little HACK will allow it to be case insensitive on the search
		Map<String, String> sharedDedicatedMap = new HashMap<String, String>();
		sharedDedicatedMap.put("SHARED", "Shared");
		sharedDedicatedMap.put("DEDICATED", "Dedicated");
		variableAndValueProcessorMap.put("SHAREDDEDICATED", new ValueTranslatorOnly("EXT_DEVICE_TYPE.SHARED_DEDICATED", new ValueMapper(sharedDedicatedMap)));
		
		Map<String, List<String>> statusMap = new HashMap<String, List<String>>();
		statusMap.put("ACTIVE", Arrays.asList("In Service","Planned","Configured","Pending Activation"));
		variableAndValueProcessorMap.put("STATUS", new ValueListTranslator("PROVISIONSTATUS.NAME", statusMap, true));
		
		variableAndValueProcessorMap.put("ROLE", new VariableTranslatorOnly("NETWORKROLE.ALIAS1"));
		
		variableAndValueProcessorMap.put("IPADDRESS", new MultipleFieldTranslator(Arrays.asList("EXT_DEVICE_TYPE.IPV4CONSOLE1",
																								"EXT_DEVICE_TYPE.IPV4MGMROUTERID",
																								"EXT_DEVICE_TYPE.IPV4CONSOLE2",
																								"EXT_DEVICE_TYPE.IPV4CONSOLE3",
																								"EXT_DEVICE_TYPE.IPV6CONSOLE1",
																								"EXT_DEVICE_TYPE.IPV6CONSOLE2",
																								"EXT_DEVICE_TYPE.IPV6CONSOLE3",
																								"EXT_DEVICE_TYPE.IPV6MGMROUTERID")
																								, new ConvertToUpperCase()));

				
		
		queryBuilder = new QueryBuilder(variableAndValueProcessorMap);
		//queryBuilder.setVariableValueTranslatorMap(variableValueTranslationMap);
	}
	
	public List<Node> getDevices(VOSearchHolder searchHolder) throws Exception {
		
		List<Node> nodes = new ArrayList<Node>();
		
		if (!StringHelper.isEmpty(searchHolder.getObjectID()))
		{
			Node node = new Node(searchHolder.getObjectID());
			if (node.isInstanciated())
			{
				nodes.add(node);
			} 
		} 
		else if (!StringHelper.isEmpty(searchHolder.getCommonName()) && searchHolder.getFilterCriteraList().get("ENTITYFILTER") != null)
		{
			String query = queryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("ENTITYFILTER"))+" AND NODE.NAME = '"+searchHolder.getCommonName().toUpperCase()+"'";
			LOG.info(query);
			nodes = Node.getNodeListByQuery(query);
		}
		else if (!StringHelper.isEmpty(searchHolder.getCommonName()))
		{
			String query = "NODE.NAME = '"+searchHolder.getCommonName().toUpperCase()+"'";
			LOG.info(query);
			nodes = Node.getNodeListByQuery(query);
		} else if (searchHolder.getFilterCriteraList().get("ENTITYFILTER") != null)
		{
			String query = queryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("ENTITYFILTER"));
			LOG.info(query);
			nodes = Node.getNodeListByQuery(query);
		} else {
			throw new ICLRequestValidationException("No Search Criteria Found in Request");
		}
		
		if (nodes.size() < 1)
		{
			throw new OSSDataNotFoundException();
		}
		
		return nodes;
	}
	
}
