package com.centurylink.icl.armmediation.transformation;

import java.util.HashMap;
import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CustomerAccountBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class ImpactedCircuitsForDeviceToCim
{
	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final SubNetworkConnectionBuilder subNetworkConnectionBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final CustomerAccountBuilder customerAccountBuilder;
	private final LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder;
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final IPAddressBuilder ipAddressBuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final TerminationPointBuilder terminationPointBuilder;
	private final SearchResourceResponseBuilder searchResourceResponseBuilder;
	private final SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder;

	public ImpactedCircuitsForDeviceToCim()
	{
		this.searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		this.subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		this.ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		this.customerBuilder = new CustomerBuilder();
		this.customerAccountBuilder = new CustomerAccountBuilder();
		this.logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		this.physicalDeviceBuilder = new PhysicalDeviceBuilder();
		this.ipAddressBuilder = new IPAddressBuilder();
		this.americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		this.terminationPointBuilder = new TerminationPointBuilder();
		this.searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		this.searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();

	}

	public SearchResourceResponseDocument transformImpactedCircuitsToCim(List<ARMImpactedCircuits> cktsList, List<ARMImpactedCircuits> serviceList)
	{

		HashMap<String,String> uniqueServiceMap=new HashMap<String,String>();
		HashMap<String,String> uniquesCktMap=new HashMap<String,String>();
		if (cktsList != null && cktsList.size() > 0 || serviceList != null && serviceList.size() > 0)
		{
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			if (cktsList != null && cktsList.size() > 0)
			{
				for (ARMImpactedCircuits ckts : cktsList)
				{
					if (null != ckts)
					{
						if(uniquesCktMap.get(ckts.getCktId()) == null){
							
						subNetworkConnectionBuilder.buildSubNetworkConnection(ckts.getCommonName(), ckts.getCktId(), null, "ARM", ckts.getResourceType(), ckts.getCktProvStatus(), null, null, ckts.getAlias1(), ckts.getAlias2(),  ckts.getCktFuncStatus(), null);
						if (ckts.getSubscriberName() != null)
						{
							ownsResourceDetailsBuilder.buildOwnsResourceDetails();
							String subscriberName = ckts.getSubscriberName();
							
							customerBuilder.buildCustomer(subscriberName, ckts.getSubscriberId(), null, ckts.getSubsciberfullname(), null, null,null);
							ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
							subNetworkConnectionBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
						}
						if(null != ckts.getCkt2StartNode() || null != ckts.getCkt2StartLoc())
						{
							terminationPointBuilder.buildTerminationPoint(null, null, null);
							if(null != ckts.getCkt2StartNode())
							{
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								physicalDeviceBuilder.buildPhysicalDevice(ckts.getStartDeviceName(), ckts.getStartDeviceObjectId(), ckts.getStartDeviceFullName(), "ARM", null, null, ckts.getDevicePrStatus(), ckts.getStartDeviceClli(), null, null, null, null, null, null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,ckts.getEmsHostName());
								if(ckts.getStartDeviceIpAddress4()!=null)
								{
									ipAddressBuilder.buildIPAddress(ckts.getStartDeviceIpAddress4(), null, null, null, null, "4");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								if(ckts.getStartDeviceIpAddress6()!=null)
								{
									ipAddressBuilder.buildIPAddress(ckts.getStartDeviceIpAddress6(), null, null, null, null, "6");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
								terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							}
							if (null != ckts.getCkt2StartLoc())
							{
								americanPropertyAddressBuilder.buildAmericanPropertyAddress(ckts.getStartLocationName(), null, null, null, null, ckts.getStartLoclocality(), ckts.getStartpostcode(), ckts.getStartLocAddressLine1(), ckts.getStartLocAddressLine2(), ckts.getStartLocAddressLine3(), ckts.getStartLocprovince(),null,ckts.getLocationClli());
								terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
							}
							subNetworkConnectionBuilder.addAEndTps(terminationPointBuilder.getTerminationPoint());
						}
						if(null != ckts.getCkt2EndNode() || null != ckts.getCkt2EndLoc())
						{
							terminationPointBuilder.buildTerminationPoint(null, null, null);
							if(null != ckts.getCkt2EndNode())
							{
								
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								physicalDeviceBuilder.buildPhysicalDevice(ckts.getEndDeviceName(), ckts.getEndDeviceObjectId(), ckts.getEndDeviceFullName(), "ARM", null, null, ckts.getDevicePrStatus(), ckts.getEndDeviceClli(), null, null, null, null, null, null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,ckts.getEmsHostName());
								if(ckts.getEndDeviceIpAddress4()!=null)
								{
									ipAddressBuilder.buildIPAddress(ckts.getEndDeviceIpAddress4(), null, null, null, null, "4");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								if(ckts.getEndDeviceIpAddress6()!=null)
								{
									ipAddressBuilder.buildIPAddress(ckts.getEndDeviceIpAddress6(), null, null, null, null, "6");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
								terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							}
							if (null != ckts.getCkt2EndLoc())
							{
								americanPropertyAddressBuilder.buildAmericanPropertyAddress(ckts.getEndLocationName(), null, null, null, null, ckts.getEndLoclocality(), ckts.getEndpostcode(), ckts.getEndLocAddressLine1(), ckts.getEndLocAddressLine2(), ckts.getEndLocAddressLine3(), ckts.getEndLocprovince(),null,ckts.getLocationClli());
								terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
							}
							subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder.getTerminationPoint());
						}
						if(ckts.getTtServiceTypeCircuit() != null)
						{
							subNetworkConnectionBuilder.addResourceDescribedBy("TtServiceType", ckts.getTtServiceTypeCircuit());
						}
						searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
						uniquesCktMap.put(ckts.getCktId(), ckts.getCktId());
					}
						
				}		

			}
				uniquesCktMap=null;
			}
			if (serviceList != null && serviceList.size() > 0)
			{
				for (ARMImpactedCircuits service : serviceList)
				{
					if (null != service)
					{
						if(uniqueServiceMap.get(service.getServiceID())==null)
						{
							subNetworkConnectionBuilder.buildSubNetworkConnection(service.getServiceName(), service.getServiceID(), null, "ARM", service.getServiceTypeName(), service.getServiceProvStatus(), null, null, service.getAlias1(), service.getAlias2(), service.getServiceFuncStatus(), null);
							if(service.getUniHpc()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator", service.getUniHpc());
							}
							if(service.getUniHpcExpDate()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate", service.getUniHpcExpDate());
							}
							if(service.getEnniHpc()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator", service.getEnniHpc());
							}
							if(service.getEnniHpcExpDate()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate", service.getEnniHpcExpDate());
							}
							if(service.getEvcHpc()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator", service.getEvcHpc());
							}
							if(service.getEvcHpcExpDate()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate", service.getEvcHpcExpDate());
							}
							if(service.getOvcHpc()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator", service.getOvcHpc());
							}
							if(service.getOvcHpcExpDate()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate", service.getOvcHpcExpDate());
							}
							if(service.getTtServiceTypeService()!=null)
							{
								subNetworkConnectionBuilder.addResourceDescribedBy("TtServiceType", service.getTtServiceTypeService());
							}
							if (service.getSubscriberName() != null)
							{
								ownsResourceDetailsBuilder.buildOwnsResourceDetails();
								String subscriberName = service.getSubscriberName();
								
								customerBuilder.buildCustomer(subscriberName, service.getSubscriberId(), null, service.getSubsciberfullname(), null, null,null);
								if(service.getBan()!=null)
				                {
									customerAccountBuilder.buildCustomerAccount(service.getBan(), "BAN");
				                    customerBuilder.addCustomerPosseses(customerAccountBuilder.getCustomerAccount());
				                 }
								ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
								subNetworkConnectionBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
							}
							terminationPointBuilder.buildTerminationPoint(null, null, null);
							if(null != service.getEndDeviceName())
							{
								logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
								physicalDeviceBuilder.buildPhysicalDevice(service.getEndDeviceName(), service.getEndDeviceObjectId(), service.getEndDeviceFullName(), "ARM", null, null,service.getDevicePrStatus() , service.getEndDeviceClli(), null, null, null, null, null, null
										,null,null,null,null,null,null,null,null,null,null,null,null,null,null,service.getEmsHostName());
								if(service.getEndDeviceIpAddress4()!=null)
								{
									ipAddressBuilder.buildIPAddress(service.getEndDeviceIpAddress4(), null, null, null, null, "4");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								if(service.getEndDeviceIpAddress6()!=null)
								{
									ipAddressBuilder.buildIPAddress(service.getEndDeviceIpAddress6(), null, null, null, null, "6");
									physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
								}
								logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
								terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
							}
							if (null != service.getEndLocationName() || null != service.getEndLocAddressLine1() || null != service.getEndLocAddressLine2() || null != service.getEndLocAddressLine3() || null != service.getEndLoclocality() || null != service.getEndLocprovince() || null != service.getEndpostcode())
							{
								americanPropertyAddressBuilder.buildAmericanPropertyAddress(service.getEndLocationName(), null, null, null, null, service.getEndLoclocality(), service.getEndpostcode(), service.getEndLocAddressLine1(), service.getEndLocAddressLine2(), service.getEndLocAddressLine3(), service.getEndLocprovince(),null,service.getLocationClli());
								terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
							}
							subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder.getTerminationPoint());
							searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
							uniqueServiceMap.put(service.getServiceID(),service.getServiceID());
						}
						
					}
				}
			}
			searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
			searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
			searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
			
			return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
		} 
		else
		{
			throw new OSSDataNotFoundException();
		}
	}

}
