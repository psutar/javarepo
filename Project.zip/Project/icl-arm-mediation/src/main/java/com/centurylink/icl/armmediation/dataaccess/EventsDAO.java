package com.centurylink.icl.armmediation.dataaccess;

import com.centurylink.icl.armmediation.armaccessobject.ARMEvent;

public interface EventsDAO
{

	public ARMEvent getNextEvent();
	
	public void deleteEvent(ARMEvent event);

}
