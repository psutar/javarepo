package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Nodetype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class NodetypeCache implements ValueObjectCache {
	
	private Map<String, Nodetype> cachedObjects = new HashMap<String, Nodetype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Nodetype newNodetype = new Nodetype(key);
			if (newNodetype.isInstanciated())
			{
				cachedObjects.put(key, newNodetype);
				return newNodetype;
			} else {
				return null;
			}
		}
	}

}
