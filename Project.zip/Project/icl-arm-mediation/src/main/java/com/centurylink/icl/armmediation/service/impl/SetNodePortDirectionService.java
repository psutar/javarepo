package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.PortDirection;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkggeneral.SetObjectAttributeVarchar;

public class SetNodePortDirectionService
{

	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private JDBCTempleteUtil jdbcTempleteUtil;
	private SetObjectAttributeVarchar setObjectAttributeVarchar;
	private SearchDeviceService searchDeviceService;

	public Object setPortDirection(HashMap<String, Object> iHashMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Starting Set Port Direction");
		}

		final String nodeId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.NODE_ID);
		final List<PortDirection> portList = jdbcTempleteUtil.getPortInfo(nodeId);
		/*Map<String, Object> map = null;
		for (PortDirection port : portList)
		{
			map = (HashMap<String, Object>) setObjectAttributeVarchar.execute(Constants.PORT_DIM_ID, port.getPortId(), Constants.PORT_ATT_DIRECTION, port.getPortDirection());
			final BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
			if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
			{
				final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
				if (LOG.isInfoEnabled())
				{
					LOG.info(o_Errormsg);
				}
				return MediationUtil.getCreateDeviceErrorResponse(String.valueOf(o_ErrorCode), o_Errormsg, "Set Port Function Failed", null);
			}
		} */

		String portDirection = MediationUtil.getValueFromMap(iHashMap, MDWConstants.PORTDIRECTION);
		String metaDataRequired = MediationUtil.getValueFromMap(iHashMap, MDWConstants.META_DATA_REQUIRED);
		String deviceName = MediationUtil.getValueFromMap(iHashMap, MDWConstants.DEVICE_NAME);
		String shelfClass = MediationUtil.getValueFromMap(iHashMap, MDWConstants.SHELFCLASS);
		
		if("NotFound" == deviceName)
		{	
			deviceName = jdbcTempleteUtil.getNodeName(nodeId);
			
		}
		
		if (deviceName == "NotFound")
		{	
			return MediationUtil.getCreateDeviceErrorResponse(Constants.ERROR_CODE_1948, Constants.ICL_REQUEST_VALIDATION_ERROR,
					"Request validation failure due to Device  not found", null);
		}



		if("NotFound".equals(metaDataRequired))
		{
			metaDataRequired = null;
		}
		if("NotFound".equals(portDirection))
		{
			portDirection = null;
		}
		if("NotFound".equals(shelfClass))
		{
			shelfClass = null;
		}

		return searchDeviceService.searchDevice(Constants.CREATE_DEVICE_RESPONSE, null, portDirection, metaDataRequired,shelfClass,deviceName);
	}

	public void setSearchDeviceService(SearchDeviceService searchDeviceService)
	{
		this.searchDeviceService = searchDeviceService;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeVarchar(SetObjectAttributeVarchar setObjectAttributeVarchar)
	{
		this.setObjectAttributeVarchar = setObjectAttributeVarchar;
	}

}
