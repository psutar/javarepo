package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class CardExtension  extends AbstractReadOnlyTable 
{
	private static final String CARDID = "CARDID";
	private static final String HARDWAREVERSION = "HARDWAREVERSION";
	private static final String IPV4CONSOLE1 = "IPV4CONSOLE1";
	private static final String IPV4MGMROUTERID = "IPV4MGMROUTERID";
	private static final String IPV6MGMROUTERID = "IPV6MGMROUTERID";
	private static final String IPV4CONSOLE2 = "IPV4CONSOLE2";
	private static final String IPV6CONSOLE1 = "IPV6CONSOLE1";
	private static final String IPV6CONSOLE2 = "IPV6CONSOLE2";
	private static final String IPV6CONSOLE3 = "IPV6CONSOLE3";
	private static final String IPV4CONSOLE3 = "IPV4CONSOLE3";
	private static final String RESTRICTEDNOTES = "RESTRICTEDNOTES";
	private static final String RESTRICTEDSTATUS="RESTRICTEDSTATUS";
	private static final String FIRMWAREVERSION = "FIRMWAREVERSION";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String SERIALNUMBER = "SERIALNUMBER";
	private static final String PROCESSORENGINESERIALNUMBER = "PROCESSORENGINESERIALNUMBER";
	private static final String SECONDARY_MGMT_ACCESS = "SECONDARY_MGMT_ACCESS";
	private static String USAGE = "USAGE";
	
	

	
	public CardExtension()
	{
		super();
	}
	
	public CardExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		this.getRecordByPrimaryKey();
	}
	@Override
	public void populateModel() {
		fields.put(CARDID, new Field(CARDID, Field.TYPE_NUMERIC));
		fields.put(HARDWAREVERSION, new Field(HARDWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE1, new Field(IPV4CONSOLE1, Field.TYPE_VARCHAR));
		fields.put(IPV4MGMROUTERID, new Field(IPV4MGMROUTERID, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(SERIALNUMBER, new Field(SERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(IPV6MGMROUTERID, new Field(IPV6MGMROUTERID, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE2, new Field(IPV4CONSOLE2, Field.TYPE_VARCHAR));
		fields.put(IPV6CONSOLE1, new Field(IPV6CONSOLE1, Field.TYPE_VARCHAR));
		fields.put(IPV6CONSOLE2, new Field(IPV6CONSOLE2, Field.TYPE_VARCHAR));
		fields.put(FIRMWAREVERSION, new Field(FIRMWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDNOTES, new Field(RESTRICTEDNOTES, Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDSTATUS, new Field(RESTRICTEDSTATUS, Field.TYPE_VARCHAR));
		fields.put(SECONDARY_MGMT_ACCESS, new Field(SECONDARY_MGMT_ACCESS, Field.TYPE_VARCHAR));
		fields.put(IPV6CONSOLE3, new Field(IPV6CONSOLE3, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE3, new Field(IPV4CONSOLE3, Field.TYPE_VARCHAR));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(PROCESSORENGINESERIALNUMBER, new Field(PROCESSORENGINESERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(USAGE, new Field(USAGE, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(CARDID));
		
	}
	
	public void setCardid(String cardid)
	{
		setField(CARDID,cardid);
	}

	public String getCardid()
	{
		return getFieldAsString(CARDID);
	}
	
	public void setHardwareversion(String hardwareversion)
	{
		setField(HARDWAREVERSION,hardwareversion);
	}

	public String getHardwareversion()
	{
		return getFieldAsString(HARDWAREVERSION);
	}
	
	public void setIpv4console1(String ipv4console1)
	{
		setField(IPV4CONSOLE1,ipv4console1);
	}

	public String getIpv4console1()
	{
		return getFieldAsString(IPV4CONSOLE1);
	}

	public void setIpv4mgmrouterid(String ipv4mgmrouterid)
	{
		setField(IPV4MGMROUTERID,ipv4mgmrouterid);
	}

	public String getIpv4mgmrouterid()
	{
		return getFieldAsString(IPV4MGMROUTERID);
	}
	
	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}
	
	public void setSerialnumber(String serialnumber)
	{
		setField(SERIALNUMBER,serialnumber);
	}

	public String getSerialnumber()
	{
		return getFieldAsString(SERIALNUMBER);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}
	
	public void setIpv6mgmrouterid(String ipv6mgmrouterid)
	{
		setField(IPV6MGMROUTERID,ipv6mgmrouterid);
	}

	public String getIpv6mgmrouterid()
	{
		return getFieldAsString(IPV6MGMROUTERID);
	}
	
	public void setIpv4console2(String ipv4console2)
	{
		setField(IPV4CONSOLE2,ipv4console2);
	}

	public String getIpv4console2()
	{
		return getFieldAsString(IPV4CONSOLE2);
	}
	
	public void setIpv6console1(String ipv6console1)
	{
		setField(IPV6CONSOLE1,ipv6console1);
	}

	public String getIpv6console1()
	{
		return getFieldAsString(IPV6CONSOLE1);
	}

	public void setIpv6console2(String ipv6console2)
	{
		setField(IPV6CONSOLE2,ipv6console2);
	}

	public String getIpv6console2()
	{
		return getFieldAsString(IPV6CONSOLE2);
	}

	public void setFirmwareversion(String firmwareversion)
	{
		setField(FIRMWAREVERSION,firmwareversion);
	}

	public String getFirmwareversion()
	{
		return getFieldAsString(FIRMWAREVERSION);
	}
	
	
	public void setIpv6console3(String ipv6console3)
	{
		setField(IPV6CONSOLE3,ipv6console3);
	}

	public String getIpv6console3()
	{
		return getFieldAsString(IPV6CONSOLE3);
	}

	public void setIpv4console3(String ipv4console3)
	{
		setField(IPV4CONSOLE3,ipv4console3);
	}

	public String getIpv4console3()
	{
		return getFieldAsString(IPV4CONSOLE3);
	}
	

	public void setSecondaryMgmtAccess(String secondaryMgmtAccess)
	{
		setField(SECONDARY_MGMT_ACCESS,secondaryMgmtAccess);
	}

	public String getSecondaryMgmtAccess()
	{
		return getFieldAsString(SECONDARY_MGMT_ACCESS);
	}
	
	public void setRestrictednotes(String restrictednotes)
	{
		setField(RESTRICTEDNOTES,restrictednotes);
	}

	public String getRestrictednotes()
	{
		return getFieldAsString(RESTRICTEDNOTES);
	}
	public String getRestrictedStatus() {
		return getFieldAsString(RESTRICTEDSTATUS);
	}

	public void setRestrictedStatus(String restrictedstatus) {
		setField(RESTRICTEDSTATUS,restrictedstatus);
	}
	
	public void setUsage(String usage) {
		setField(USAGE,usage);
	}
	public  String getUsage() {
		return getFieldAsString(USAGE);
	}
	
	public void setProcessorEngineSerialNumber(String processorEngineSerialNumber)
	{
		setField(PROCESSORENGINESERIALNUMBER,processorEngineSerialNumber);
	}

	public String getProcessorEngineSerialNumber()
	{
		return getFieldAsString(PROCESSORENGINESERIALNUMBER);
	}
	
	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	
	
}
