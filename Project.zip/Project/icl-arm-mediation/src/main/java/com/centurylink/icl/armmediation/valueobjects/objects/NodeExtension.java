package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;


public class NodeExtension extends AbstractReadOnlyTable {

	private static final String NODEID = "NODEID";
	private static final String MACADDRESS = "MACADDRESS";
	private static final String HARDWAREVERSION = "HARDWAREVERSION";
	private static final String DISCONTINUEDATE = "DISCONTINUEDATE";
	private static final String SHARED_DEDICATED = "SHARED_DEDICATED";
	private static final String IPV4CONSOLE1 = "IPV4CONSOLE1";
	private static final String IPV4MGMROUTERID = "IPV4MGMROUTERID";
	private static final String MANUFACTURERPARTNUMBER = "MANUFACTURERPARTNUMBER";
	private static final String NMSHOSTNAME = "NMSHOSTNAME";
	private static final String RPPLANID = "RPPLANID";
	private static final String CLLI = "CLLI";
	private static final String REVISION = "REVISION";
	private static final String DISCONTINUEREASON = "DISCONTINUEREASON";
	private static final String VENDORNAME = "VENDORNAME";
	private static final String VENDORPARTNUMBER = "VENDORPARTNUMBER";
	private static final String SERIALNUMBER = "SERIALNUMBER";
	private static final String LABEL = "LABEL";
	private static final String CHASSISSERIALNUMBER = "CHASSISSERIALNUMBER";
	private static final String IPV6MGMROUTERID = "IPV6MGMROUTERID";
	private static final String SNMPOBJECTID = "SNMPOBJECTID";
	private static final String IPV4CONSOLE2 = "IPV4CONSOLE2";
	private static final String PARTTYPE = "PARTTYPE";
	private static final String NMSTYPE = "NMSTYPE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String IPV6CONSOLE1 = "IPV6CONSOLE1";
	private static final String IPV6CONSOLE2 = "IPV6CONSOLE2";
	private static final String FIRMWAREVERSION = "FIRMWAREVERSION";
	private static final String MCO = "MCO";
	private static final String IPV6CONSOLE3 = "IPV6CONSOLE3";
	private static final String IPV4CONSOLE3 = "IPV4CONSOLE3";
	private static final String MGMTVLAN = "MGMTVLAN";
	private static final String RELAYRACKID = "RELAYRACKID";
	private static final String SECONDARY_MGMT_ACCESS = "SECONDARY_MGMT_ACCESS";
	private static final String IS_DIVERSE = "IS_DIVERSE";
	private static final String NETWORKNAME = "NETWORKNAME";
	private static String SOURCE_SYSTEM = "SOURCE_SYSTEM";
	private static String EXCEPTION_HANDLING_INFO = "EXCEPTION_HANDLING_INFO";
	private static String GBPSINDICATOR = "ONEGBPSINDICATOR";
	private static String POWERSUPPLY = "POWERSUPPLY";
	private static String FIBERINRANGE = "FIBERINRANGE";
	private static String OPTITAP = "OPTITAP";
	private static String SELFORTECHINSTALL = "SELFORTECHINSTALL";
	private static String FIBEROUTRANGE = "FIBEROUTRANGE";
	private static String STACKRINGSEQNUM = "STACKRINGSEQNUM";
	private static String AERIALORBURIED = "AERIALORBURIED";
	private static String INSTALLDATE = "INSTALLDATE";
	private static String RONTAID = "RONTAID";
	private static String PRISMNOSACERT = "PRISMNOSACERT";
	private static String SPLITTERGRPNUM = "SPLITTERGRPNUM";
	private static String STACKRINGSHELFID = "STACKRINGSHELFID";
	private static String SPLITTERSTARTPORTNUMBER = "SPLITTERSTARTPORTNUMBER";
	private static String SAPCODE = "SAPCODE";
	private static String SPLITTERGRPNAME = "SPLITTERGRPNAME";
	private static String MAXSUBSCRIBERBWOFFERED = "MAXSUBSCRIBERBWOFFERED";
	private static String INDOOR = "INDOOR";
	private static String NWKNODENUMBER = "NWKNODENUMBER";
	private static String RESTRICTEDNOTES = "RESTRICTEDNOTES";
	private static String RESTRICTEDSTATUS="RESTRICTEDSTATUS";


	private static String MAXDOWNSTREAMRATE ="MAXDOWNSTREAMRATE";
	private static String MAXUPSTREAMRATE ="MAXUPSTREAMRATE";		

	public NodeExtension()
	{
		super();
	}

	public NodeExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		this.getRecordByPrimaryKey();
	}

	@Override
	public void populateModel()
	{
		fields.put(NODEID, new Field(NODEID, Field.TYPE_NUMERIC));
		fields.put(MACADDRESS, new Field(MACADDRESS, Field.TYPE_VARCHAR));
		fields.put(HARDWAREVERSION, new Field(HARDWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(DISCONTINUEDATE, new Field(DISCONTINUEDATE, Field.TYPE_DATE));
		fields.put(SHARED_DEDICATED, new Field(SHARED_DEDICATED, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE1, new Field(IPV4CONSOLE1, Field.TYPE_VARCHAR));
		fields.put(IPV4MGMROUTERID, new Field(IPV4MGMROUTERID, Field.TYPE_VARCHAR));
		fields.put(MANUFACTURERPARTNUMBER, new Field(MANUFACTURERPARTNUMBER, Field.TYPE_VARCHAR));
		fields.put(NMSHOSTNAME, new Field(NMSHOSTNAME, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(CLLI, new Field(CLLI, Field.TYPE_VARCHAR));
		fields.put(REVISION, new Field(REVISION, Field.TYPE_VARCHAR));
		fields.put(DISCONTINUEREASON, new Field(DISCONTINUEREASON, Field.TYPE_VARCHAR));
		fields.put(VENDORNAME, new Field(VENDORNAME, Field.TYPE_VARCHAR));
		fields.put(VENDORPARTNUMBER, new Field(VENDORPARTNUMBER, Field.TYPE_VARCHAR));
		fields.put(SERIALNUMBER, new Field(SERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(CHASSISSERIALNUMBER, new Field(CHASSISSERIALNUMBER, Field.TYPE_VARCHAR));
		fields.put(IPV6MGMROUTERID, new Field(IPV6MGMROUTERID, Field.TYPE_VARCHAR));
		fields.put(SNMPOBJECTID, new Field(SNMPOBJECTID, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE2, new Field(IPV4CONSOLE2, Field.TYPE_VARCHAR));
		fields.put(PARTTYPE, new Field(PARTTYPE, Field.TYPE_VARCHAR));
		fields.put(NMSTYPE, new Field(NMSTYPE, Field.TYPE_VARCHAR));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(IPV6CONSOLE1, new Field(IPV6CONSOLE1, Field.TYPE_VARCHAR));
		fields.put(IPV6CONSOLE2, new Field(IPV6CONSOLE2, Field.TYPE_VARCHAR));
		fields.put(FIRMWAREVERSION, new Field(FIRMWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(MCO, new Field(MCO, Field.TYPE_VARCHAR));
		fields.put(IPV6CONSOLE3, new Field(IPV6CONSOLE3, Field.TYPE_VARCHAR));
		fields.put(IPV4CONSOLE3, new Field(IPV4CONSOLE3, Field.TYPE_VARCHAR));
		fields.put(MGMTVLAN, new Field(MGMTVLAN, Field.TYPE_NUMERIC));
		fields.put(RELAYRACKID, new Field(RELAYRACKID, Field.TYPE_VARCHAR));
		fields.put(SECONDARY_MGMT_ACCESS, new Field(SECONDARY_MGMT_ACCESS, Field.TYPE_VARCHAR));
		fields.put(IS_DIVERSE, new Field(IS_DIVERSE, Field.TYPE_VARCHAR));
		fields.put(NETWORKNAME, new Field(NETWORKNAME, Field.TYPE_VARCHAR));
		fields.put(EXCEPTION_HANDLING_INFO, new Field(EXCEPTION_HANDLING_INFO, Field.TYPE_VARCHAR));
		fields.put(SOURCE_SYSTEM, new Field(SOURCE_SYSTEM, Field.TYPE_VARCHAR));
		fields.put(GBPSINDICATOR, new Field("ONEGBPSINDICATOR", Field.TYPE_NUMERIC));
		fields.put(POWERSUPPLY, new Field(POWERSUPPLY, Field.TYPE_VARCHAR));
		fields.put(FIBERINRANGE, new Field(FIBERINRANGE, Field.TYPE_VARCHAR));
		fields.put(OPTITAP, new Field(OPTITAP, Field.TYPE_NUMERIC));
		fields.put(SELFORTECHINSTALL, new Field(SELFORTECHINSTALL, Field.TYPE_NUMERIC));
		fields.put(FIBEROUTRANGE, new Field(FIBEROUTRANGE, Field.TYPE_VARCHAR));
		fields.put(STACKRINGSEQNUM, new Field(STACKRINGSEQNUM, Field.TYPE_NUMERIC));
		fields.put(AERIALORBURIED, new Field(AERIALORBURIED, Field.TYPE_NUMERIC));

		fields.put(MAXDOWNSTREAMRATE, new Field(MAXDOWNSTREAMRATE, Field.TYPE_NUMERIC));
		fields.put(MAXUPSTREAMRATE, new Field(MAXUPSTREAMRATE, Field.TYPE_NUMERIC));

		fields.put(INSTALLDATE, new Field(INSTALLDATE, Field.TYPE_DATE));
		fields.put(RONTAID, new Field(RONTAID, Field.TYPE_NUMERIC));
		fields.put(PRISMNOSACERT, new Field(PRISMNOSACERT, Field.TYPE_NUMERIC));
		fields.put(SPLITTERGRPNUM, new Field(SPLITTERGRPNUM, Field.TYPE_NUMERIC));
		fields.put(STACKRINGSHELFID, new Field(STACKRINGSHELFID, Field.TYPE_NUMERIC));
		fields.put(SPLITTERSTARTPORTNUMBER, new Field(SPLITTERSTARTPORTNUMBER, Field.TYPE_NUMERIC));
		fields.put(SAPCODE, new Field(SAPCODE, Field.TYPE_VARCHAR));
		fields.put(SPLITTERGRPNAME, new Field(SPLITTERGRPNAME, Field.TYPE_VARCHAR));
		fields.put(MAXSUBSCRIBERBWOFFERED, new Field(MAXSUBSCRIBERBWOFFERED, Field.TYPE_VARCHAR));
		fields.put(INDOOR, new Field(INDOOR, Field.TYPE_NUMERIC));
		fields.put(NWKNODENUMBER, new Field(NWKNODENUMBER, Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDNOTES, new Field(RESTRICTEDNOTES, Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDSTATUS, new Field(RESTRICTEDSTATUS, Field.TYPE_VARCHAR));

		primaryKey = new PrimaryKey(fields.get(NODEID));
	}

	public void setNodeid(String nodeid)
	{
		setField(NODEID,nodeid);
	}

	public String getNodeid()
	{
		return getFieldAsString(NODEID);
	}

	public void setMacaddress(String macaddress)
	{
		setField(MACADDRESS,macaddress);
	}

	public String getMacaddress()
	{
		return getFieldAsString(MACADDRESS);
	}

	public void setHardwareversion(String hardwareversion)
	{
		setField(HARDWAREVERSION,hardwareversion);
	}

	public String getHardwareversion()
	{
		return getFieldAsString(HARDWAREVERSION);
	}

	public void setDiscontinuedate(String discontinuedate)
	{
		setField(DISCONTINUEDATE,discontinuedate);
	}

	public String getDiscontinuedate()
	{
		return getFieldAsString(DISCONTINUEDATE);
	}

	public void setSharedDedicated(String sharedDedicated)
	{
		setField(SHARED_DEDICATED,sharedDedicated);
	}

	public String getSharedDedicated()
	{
		return getFieldAsString(SHARED_DEDICATED);
	}

	public void setIpv4console1(String ipv4console1)
	{
		setField(IPV4CONSOLE1,ipv4console1);
	}

	public String getIpv4console1()
	{
		return getFieldAsString(IPV4CONSOLE1);
	}

	public void setIpv4mgmrouterid(String ipv4mgmrouterid)
	{
		setField(IPV4MGMROUTERID,ipv4mgmrouterid);
	}

	public String getIpv4mgmrouterid()
	{
		return getFieldAsString(IPV4MGMROUTERID);
	}

	public void setManufacturerpartnumber(String manufacturerpartnumber)
	{
		setField(MANUFACTURERPARTNUMBER,manufacturerpartnumber);
	}

	public String getManufacturerpartnumber()
	{
		return getFieldAsString(MANUFACTURERPARTNUMBER);
	}

	public void setNmshostname(String nmshostname)
	{
		setField(NMSHOSTNAME,nmshostname);
	}

	public String getNmshostname()
	{
		return getFieldAsString(NMSHOSTNAME);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setClli(String clli)
	{
		setField(CLLI,clli);
	}

	public String getClli()
	{
		return getFieldAsString(CLLI);
	}

	public void setRevision(String revision)
	{
		setField(REVISION,revision);
	}

	public String getRevision()
	{
		return getFieldAsString(REVISION);
	}

	public void setDiscontinuereason(String discontinuereason)
	{
		setField(DISCONTINUEREASON,discontinuereason);
	}

	public String getDiscontinuereason()
	{
		return getFieldAsString(DISCONTINUEREASON);
	}

	public void setVendorname(String vendorname)
	{
		setField(VENDORNAME,vendorname);
	}

	public String getVendorname()
	{
		return getFieldAsString(VENDORNAME);
	}

	public void setVendorpartnumber(String vendorpartnumber)
	{
		setField(VENDORPARTNUMBER,vendorpartnumber);
	}

	public String getVendorpartnumber()
	{
		return getFieldAsString(VENDORPARTNUMBER);
	}

	public void setSerialnumber(String serialnumber)
	{
		setField(SERIALNUMBER,serialnumber);
	}

	public String getSerialnumber()
	{
		return getFieldAsString(SERIALNUMBER);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setChassisserialnumber(String chassisserialnumber)
	{
		setField(CHASSISSERIALNUMBER,chassisserialnumber);
	}

	public String getChassisserialnumber()
	{
		return getFieldAsString(CHASSISSERIALNUMBER);
	}

	public void setIpv6mgmrouterid(String ipv6mgmrouterid)
	{
		setField(IPV6MGMROUTERID,ipv6mgmrouterid);
	}

	public String getIpv6mgmrouterid()
	{
		return getFieldAsString(IPV6MGMROUTERID);
	}

	public void setSnmpobjectid(String snmpobjectid)
	{
		setField(SNMPOBJECTID,snmpobjectid);
	}

	public String getSnmpobjectid()
	{
		return getFieldAsString(SNMPOBJECTID);
	}

	public void setIpv4console2(String ipv4console2)
	{
		setField(IPV4CONSOLE2,ipv4console2);
	}

	public String getIpv4console2()
	{
		return getFieldAsString(IPV4CONSOLE2);
	}

	public void setParttype(String parttype)
	{
		setField(PARTTYPE,parttype);
	}

	public String getParttype()
	{
		return getFieldAsString(PARTTYPE);
	}

	public void setNmstype(String nmstype)
	{
		setField(NMSTYPE,nmstype);
	}

	public String getNmstype()
	{
		return getFieldAsString(NMSTYPE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setIpv6console1(String ipv6console1)
	{
		setField(IPV6CONSOLE1,ipv6console1);
	}

	public String getIpv6console1()
	{
		return getFieldAsString(IPV6CONSOLE1);
	}

	public void setIpv6console2(String ipv6console2)
	{
		setField(IPV6CONSOLE2,ipv6console2);
	}

	public String getIpv6console2()
	{
		return getFieldAsString(IPV6CONSOLE2);
	}

	public void setFirmwareversion(String firmwareversion)
	{
		setField(FIRMWAREVERSION,firmwareversion);
	}

	public String getFirmwareversion()
	{
		return getFieldAsString(FIRMWAREVERSION);
	}

	public void setMco(String mco)
	{
		setField(MCO,mco);
	}

	public String getMco()
	{
		return getFieldAsString(MCO);
	}

	public void setIpv6console3(String ipv6console3)
	{
		setField(IPV6CONSOLE3,ipv6console3);
	}

	public String getIpv6console3()
	{
		return getFieldAsString(IPV6CONSOLE3);
	}

	public void setIpv4console3(String ipv4console3)
	{
		setField(IPV4CONSOLE3,ipv4console3);
	}

	public String getIpv4console3()
	{
		return getFieldAsString(IPV4CONSOLE3);
	}

	public void setMgmtvlan(String mgmtvlan)
	{
		setField(MGMTVLAN,mgmtvlan);
	}

	public String getMgmtvlan()
	{
		return getFieldAsString(MGMTVLAN);
	}

	public void setRelayrackid(String relayrackid)
	{
		setField(RELAYRACKID,relayrackid);
	}

	public String getRelayrackid()
	{
		return getFieldAsString(RELAYRACKID);
	}

	public void setSecondaryMgmtAccess(String secondaryMgmtAccess)
	{
		setField(SECONDARY_MGMT_ACCESS,secondaryMgmtAccess);
	}

	public String getSecondaryMgmtAccess()
	{
		return getFieldAsString(SECONDARY_MGMT_ACCESS);
	}

	public void setIsDiverse(String isDiverse)
	{
		setField(IS_DIVERSE,isDiverse);
	}

	public String getIsDiverse()
	{
		return getFieldAsString(IS_DIVERSE);
	}

	public void setNetworkname(String networkname)
	{
		setField(NETWORKNAME,networkname);
	}

	public String getNetworkname()
	{
		return getFieldAsString(NETWORKNAME);
	}

	public void setSourceSystem(String sourceSystem)
	{
		setField(SOURCE_SYSTEM,sourceSystem);
	}

	public String getSourceSystem()
	{
		return getFieldAsString(SOURCE_SYSTEM);
	}

	public void setExceptionHandlingInfo(String exceptionHandlingInfo)
	{
		setField(EXCEPTION_HANDLING_INFO,exceptionHandlingInfo);
	}

	public String getExceptionHandlingInfo()
	{
		return getFieldAsString(EXCEPTION_HANDLING_INFO);
	}

	public void setGbpsindicator(String gbpsindicator)
	{
		setField(GBPSINDICATOR,gbpsindicator);
	}

	public String getGbpsindicator()
	{
		return getFieldAsString(GBPSINDICATOR);
	}

	public void setPowersupply(String powersupply)
	{
		setField(POWERSUPPLY,powersupply);
	}

	public String getPowersupply()
	{
		return getFieldAsString(POWERSUPPLY);
	}

	public void setFiberinrange(String fiberinrange)
	{
		setField(FIBERINRANGE,fiberinrange);
	}

	public String getFiberinrange()
	{
		return getFieldAsString(FIBERINRANGE);
	}

	public void setOptitap(String optitap)
	{
		setField(OPTITAP,optitap);
	}

	public String getOptitap()
	{
		return getFieldAsString(OPTITAP);
	}

	public void setSelfortechinstall(String selfortechinstall)
	{
		setField(SELFORTECHINSTALL,selfortechinstall);
	}

	public String getSelfortechinstall()
	{
		return getFieldAsString(SELFORTECHINSTALL);
	}

	public void setFiberoutrange(String fiberoutrange)
	{
		setField(FIBEROUTRANGE,fiberoutrange);
	}

	public String getFiberoutrange()
	{
		return getFieldAsString(FIBEROUTRANGE);
	}

	public void setStackringseqnum(String stackringseqnum)
	{
		setField(STACKRINGSEQNUM,stackringseqnum);
	}

	public String getStackringseqnum()
	{
		return getFieldAsString(STACKRINGSEQNUM);
	}

	public void setAerialorburied(String aerialorburied)
	{
		setField(AERIALORBURIED,aerialorburied);
	}

	public String getAerialorburied()
	{
		return getFieldAsString(AERIALORBURIED);
	}

	public void setMaxDownStreamRate(String maxDownStreamRate)
	{
		setField(MAXDOWNSTREAMRATE,maxDownStreamRate);
	}

	public String getMaxDownStreamRate()
	{
		return getFieldAsString(MAXDOWNSTREAMRATE);
	}

	public void setMaxUpStreamRate(String maxUpStreamRate)
	{
		setField(MAXUPSTREAMRATE,maxUpStreamRate);
	}

	public String getMaxUpStreamRate()
	{
		return getFieldAsString(MAXUPSTREAMRATE);
	}

	public void setInstalldate(String installdate)
	{
		setField(INSTALLDATE,installdate);
	}

	public String getInstalldate()
	{
		return getFieldAsString(INSTALLDATE);
	}

	public void setRontaid(String rontaid)
	{
		setField(RONTAID,rontaid);
	}

	public String getRontaid()
	{
		if(getFieldAsString(RONTAID)!=null)
		{
			Long rontaId= Long.valueOf(getFieldAsString(RONTAID));

			if (rontaId!=null && rontaId.compareTo(10000000L) < 0)
			{
				return String.format("%10s", rontaId).replace(' ', '0');
			}
			return rontaId.toString();
		}
		else
			return null;
	}

	public void setPrismnosacert(String prismnosacert)
	{
		setField(PRISMNOSACERT,prismnosacert);
	}

	public String getPrismnosacert()
	{
		return getFieldAsString(PRISMNOSACERT);
	}

	public void setSplittergrpnum(String splittergrpnum)
	{
		setField(SPLITTERGRPNUM,splittergrpnum);
	}

	public String getSplittergrpnum()
	{
		return getFieldAsString(SPLITTERGRPNUM);
	}

	public void setStackringshelfid(String stackringshelfid)
	{
		setField(STACKRINGSHELFID,stackringshelfid);
	}

	public String getStackringshelfid()
	{
		return getFieldAsString(STACKRINGSHELFID);
	}

	public void setSplitterstartportnumber(String splitterstartportnumber)
	{
		setField(SPLITTERSTARTPORTNUMBER,splitterstartportnumber);
	}

	public String getSplitterstartportnumber()
	{
		return getFieldAsString(SPLITTERSTARTPORTNUMBER);
	}

	public void setSapcode(String sapcode)
	{
		setField(SAPCODE,sapcode);
	}

	public String getSapcode()
	{
		return getFieldAsString(SAPCODE);
	}

	public void setSplittergrpname(String splittergrpname)
	{
		setField(SPLITTERGRPNAME,splittergrpname);
	}

	public String getSplittergrpname()
	{
		return getFieldAsString(SPLITTERGRPNAME);
	}

	public void setMaxsubscriberbwoffered(String maxsubscriberbwoffered)
	{
		setField(MAXSUBSCRIBERBWOFFERED,maxsubscriberbwoffered);
	}

	public String getMaxsubscriberbwoffered()
	{
		return getFieldAsString(MAXSUBSCRIBERBWOFFERED);
	}

	public void setIndoor(String indoor)
	{
		setField(INDOOR ,indoor);
	}

	public String getIndoor()
	{
		return getFieldAsString(INDOOR);
	}

	public void setNwknodenumber(String nwknodenumber)
	{
		setField(NWKNODENUMBER,nwknodenumber);
	}

	public String getNwknodenumber()
	{
		return getFieldAsString(NWKNODENUMBER);
	}

	public void setRestrictednotes(String restrictednotes)
	{
		setField(RESTRICTEDNOTES,restrictednotes);
	}

	public String getRestrictednotes()
	{
		return getFieldAsString(RESTRICTEDNOTES);
	}
	public String getRestrictedStatus() {
		return getFieldAsString(RESTRICTEDSTATUS);
	}

	public void setRestrictedStatus(String restrictedstatus) {
		setField(RESTRICTEDSTATUS,restrictedstatus);
	}
}
