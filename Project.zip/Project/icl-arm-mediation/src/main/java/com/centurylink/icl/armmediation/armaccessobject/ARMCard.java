package com.centurylink.icl.armmediation.armaccessobject;

import java.util.ArrayList;
import java.util.List;

public class ARMCard
{
	private String commonName;
	private Long cardId;
	private String aliasName;
	private String subType;
	private long card2ShelfSlot;
	private String parentCardName;
	private String parentCardID;
	private String parentCardAliasName;
	private String parentSubType;
	private String parentSlotNumber;
	private String slotNumber;
	private String slotName;
	private Long slotId;
	private String portName;
	private String portId;
	private String portType;
	private String pluggableType;
	private String dpea;
	private String dpea1;
	private String portFunc;
	private String networkPortName;
	private String networkPortNumber; 
	private String legacyPortName; 
	private String transmissionRate;
	private String networkPortNamePluggable;
	private String transmissionRatePluggable;
	

	private List<ARMCard> childCards = new ArrayList<ARMCard>();

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public Long getCardId()
	{
		return cardId;
	}

	public void setCardId(Long cardId)
	{
		this.cardId = cardId;
	}

	public String getAliasName()
	{
		return aliasName;
	}

	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}

	public String getParentCardID()
	{
		return parentCardID;
	}

	public void setParentCardID(String parentCardID)
	{
		this.parentCardID = parentCardID;
	}

	public String getParentCardName()
	{
		return parentCardName;
	}

	public void setParentCardName(String parentCardName)
	{
		this.parentCardName = parentCardName;
	}

	public String getSubType()
	{
		return subType;
	}

	public void setSubType(String subType)
	{
		this.subType = subType;
	}

	public long getCard2ShelfSlot()
	{
		return card2ShelfSlot;
	}

	public void setCard2ShelfSlot(long card2ShelfSlot)
	{
		this.card2ShelfSlot = card2ShelfSlot;
	}

	public String getParentSlotNumber()
	{
		return parentSlotNumber;
	}

	public void setParentSlotNumber(String parentSlotNumber)
	{
		this.parentSlotNumber = parentSlotNumber;
	}

	public String getSlotNumber()
	{
		return slotNumber;
	}

	public void setSlotNumber(String slotNumber)
	{
		this.slotNumber = slotNumber;
	}

	public String getSlotName()
	{
		return slotName;
	}

	public void setSlotName(String slotName)
	{
		this.slotName = slotName;
	}

	public Long getSlotId()
	{
		return slotId;
	}

	public void setSlotId(Long slotId)
	{
		this.slotId = slotId;
	}

	public String getPortName()
	{
		return portName;
	}

	public void setPortName(String portName)
	{
		this.portName = portName;
	}

	public String getPortId()
	{
		return portId;
	}

	public void setPortId(String portId)
	{
		this.portId = portId;
	}

	public String getPortType()
	{
		return portType;
	}

	public void setPortType(String portType)
	{
		this.portType = portType;
	}

	public String getDpea()
	{
		return dpea;
	}

	public void setDpea(String dpea)
	{
		this.dpea = dpea;
	}

	public List<ARMCard> getChildCards()
	{
		return childCards;
	}

	public String getParentCardAliasName()
	{
		return parentCardAliasName;
	}

	public void setParentCardAliasName(String parentCardAliasName)
	{
		this.parentCardAliasName = parentCardAliasName;
	}

	public String getParentSubType()
	{
		return parentSubType;
	}

	public void setParentSubType(String parentSubType)
	{
		this.parentSubType = parentSubType;
	}

	public String getPortFunc()
	{
		return portFunc;
	}

	public void setPortFunc(String portFunc)
	{
		this.portFunc = portFunc;
	}

	public void setChildCards(List<ARMCard> childCards)
	{
		this.childCards = childCards;
	}

	public String getDpea1() {
		return dpea1;
	}

	public void setDpea1(String dpea1) {
		this.dpea1 = dpea1;
	}

	public String getPluggableType() {
		return pluggableType;
	}

	public void setPluggableType(String pluggableType) {
		this.pluggableType = pluggableType;
	}

	public String getNetworkPortName() {
		return networkPortName;
	}

	public void setNetworkPortName(String networkPortName) {
		this.networkPortName = networkPortName;
	}

	public String getNetworkPortNumber() {
		return networkPortNumber;
	}

	public void setNetworkPortNumber(String networkPortNumber) {
		this.networkPortNumber = networkPortNumber;
	}

	public String getLegacyPortName() {
		return legacyPortName;
	}

	public void setLegacyPortName(String legacyPortName) {
		this.legacyPortName = legacyPortName;
	}

	public String getTransmissionRate() {
		return transmissionRate;
	}

	public void setTransmissionRate(String transmissionRate) {
		this.transmissionRate = transmissionRate;
	}

	public String getNetworkPortNamePluggable() {
		return networkPortNamePluggable;
	}

	public void setNetworkPortNamePluggable(String networkPortNamePluggable) {
		this.networkPortNamePluggable = networkPortNamePluggable;
	}

	public String getTransmissionRatePluggable() {
		return transmissionRatePluggable;
	}

	public void setTransmissionRatePluggable(String transmissionRatePluggable) {
		this.transmissionRatePluggable = transmissionRatePluggable;
	}

}
