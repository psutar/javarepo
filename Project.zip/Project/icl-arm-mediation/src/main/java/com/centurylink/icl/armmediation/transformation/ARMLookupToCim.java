package com.centurylink.icl.armmediation.transformation;

import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMSubscriber;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.PartyBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class ARMLookupToCim
{

	final private SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	final private PhysicalDeviceBuilder physicalDeviceBuilder;
	final private AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	final private CustomerBuilder customerBuilder;
	final private ResourceRelationshipBuilder resourceRelationshipBuilder;
	final private Point2PointCircuitBuilder point2PointCircuitBuilder;
	final private Point2PointCircuitBuilder tempPoint2PointCircuitBuilder;
	final private PartyBuilder partyBuilder;
	final private SubNetworkConnectionBuilder subNetworkConnectionBuilder;

	private static final Log LOG = LogFactory.getLog(ARMLookupToCim.class);

	public ARMLookupToCim() throws Exception
	{
		physicalDeviceBuilder = new PhysicalDeviceBuilder();
		searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();
		americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();
		customerBuilder = new CustomerBuilder();
		resourceRelationshipBuilder=new ResourceRelationshipBuilder();
		point2PointCircuitBuilder=new Point2PointCircuitBuilder();
		tempPoint2PointCircuitBuilder=new Point2PointCircuitBuilder();
		partyBuilder=new PartyBuilder();
		subNetworkConnectionBuilder=new SubNetworkConnectionBuilder();
	}

	@SuppressWarnings("unchecked")
	public SearchResourceResponseDocument transformToCim(Object circuitList,SearchResourceRequestDocument request,Object relatedCircuits) throws Exception 
	{
		ClassLoader mainLoader = Thread.currentThread().getContextClassLoader();
		Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
		try
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("ARMLookupToCim: Circuit Entity");
			}
			if (circuitList == null || ((List<ARMCircuit>) circuitList).isEmpty())
			{
				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Circuit could not be found in ARM", request);
			}

			searchResponseDetailsBuilder.buildSearchResponseDetails();
			if(null!=circuitList && ((List<ARMCircuit>)circuitList).size()> 0)	
			{
				for(ARMCircuit circuit:(List<ARMCircuit>)circuitList)
				{
					if(null!=circuit)
					{
						point2PointCircuitBuilder.buildPoint2PointCircuit(circuit.getCommonName(), circuit.getObjectID(), null, null, circuit.getResourceType(), circuit.getStatus(), null, null, null);
						if(null != relatedCircuits && ((List<ARMCircuit>)relatedCircuits).size()> 0 )
						{
							for(ARMCircuit relatedCircuit:(List<ARMCircuit>)relatedCircuits)
							{
								if(null!=relatedCircuit)
								{
									resourceRelationshipBuilder.buildResourceRelationship(null,null,null,null,null);
									tempPoint2PointCircuitBuilder.buildPoint2PointCircuit(relatedCircuit.getCommonName(), relatedCircuit.getObjectID(), null, null, relatedCircuit.getResourceType(), relatedCircuit.getStatus(), null, null, null);
									resourceRelationshipBuilder.addCircuit(tempPoint2PointCircuitBuilder.getPoint2PointCircuit());
									point2PointCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
								}
							}

						}
						searchResponseDetailsBuilder.addP2PCircuit(point2PointCircuitBuilder.getPoint2PointCircuit());
					}
				}
			}


			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		}
		finally
		{
			Thread.currentThread().setContextClassLoader(mainLoader);
		}
	}

	@SuppressWarnings("unchecked")
	public SearchResourceResponseDocument transformToCim(Object response, SearchResourceRequestDocument request) throws Exception
	{
		final String entity = request.getSearchResourceRequest().getSearchResourceDetails().getEntity();
		final String entityType = MediationUtil.getRcv(request, Constants.ENTITY_TYPE);
		if (entity.equalsIgnoreCase(Constants.DEVICE))
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("ARMLookupToCim: Device Entity");
			}
			if (response == null || ((List<ARMDevice>) response).isEmpty())
			{
				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Device could not be found in ARM", request);
			}

			final Iterator<ARMDevice> deviceIterator = ((List<ARMDevice>) response).iterator();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			ARMDevice armDevice = null;
			while (deviceIterator.hasNext())
			{
				armDevice = deviceIterator.next();
				physicalDeviceBuilder.buildPhysicalDevice(armDevice.getCommonName(), armDevice.getObjectID(), armDevice.getDescription(), "ARM", armDevice.getResourceType(), null,
						armDevice.getPrStatus(), armDevice.getClliCode(), null, armDevice.getManufacturer(), armDevice.getModel(), null, armDevice.getVendorName(), null);
				physicalDeviceBuilder.addDetails(null, null, null, null, null, armDevice.getLocationClli(), null, null, null, null, null, null, null, null, null, null, null);
				searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());
			}

			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);

		}  
		else if(entity.equalsIgnoreCase(Constants.CIRCUIT) && !StringHelper.isEmpty(entityType) && entityType.equalsIgnoreCase("EVC")|| ("CE-VLAN".equalsIgnoreCase(entityType)  || "S-VLAN".equalsIgnoreCase(entityType))|| "LAG".equalsIgnoreCase(entityType))
		{
			return transformCLSToCim(response, request,null);
		}

		else if (entity.equalsIgnoreCase(Constants.CIRCUIT) && !StringHelper.isEmpty(entityType))
		{

			return transformToCim(response, request,null);

		}

		else if(entity.equalsIgnoreCase(Constants.CIRCUIT) && StringHelper.isEmpty(entityType))
		{
			return transformCLSToCim(response, request,null);
		}
		else if (entity.equalsIgnoreCase(Constants.LOCATION))
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("ARMLookupToCim: Location Entity");
			}
			if (response == null || ((List<ARMLocation>) response).isEmpty())
			{
				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Location could not be found in ARM", request);
			}

			Iterator<ARMLocation> locationIterator = ((List<ARMLocation>) response).iterator();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			ARMLocation location = null;
			while (locationIterator.hasNext())
			{
				location = locationIterator.next();
				americanPropertyAddressBuilder.buildAmericanPropertyAddress(location.getCommonName(), location.getObjectID(), null, location.getSourceSystem(), null, null, null, null, null, null,
						null);
				americanPropertyAddressBuilder.setAddtionalInformation(location.getClli(), null, null, null);
				searchResponseDetailsBuilder.addAddressDetails(americanPropertyAddressBuilder.getAmericanPropertyAddress());
			}

			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);

		} else if (entity.equalsIgnoreCase(Constants.HECIG_Code))
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("ARMLookupToCim: Hecig Entity");
			}
			if (response == null || ((List<ARMDevice>) response).isEmpty())
			{
				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Hecig could not be found in ARM", request);
			}

			final Iterator<ARMDevice> deviceIterator = ((List<ARMDevice>) response).iterator();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			ARMDevice device = null;
			while (deviceIterator.hasNext())
			{
				device = deviceIterator.next();
				physicalDeviceBuilder.buildPhysicalDevice(null, null, null, null, null, null, null, null, null, null, null, null,null,null);
				physicalDeviceBuilder.addResourceDescribedBy("ARMDeviceDefID", device.getCharacteristicValue());
				searchResponseDetailsBuilder.addDevice(physicalDeviceBuilder.getPhysicalDevice());
			}

			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);

		}
		else if("CUSTOMER".equalsIgnoreCase(entity))
		{
			if(response == null || ((List<ARMSubscriber>) response).isEmpty()){

				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "No subscriber for this UNIId could be found in ARM", request);
			}

			final Iterator<ARMSubscriber> subscriberIterator = ((List<ARMSubscriber>) response).iterator();
			searchResponseDetailsBuilder.buildSearchResponseDetails();
			ARMSubscriber subscriber = null;
			while(subscriberIterator.hasNext())
			{
				subscriber = subscriberIterator.next();
				partyBuilder.buildParty(null, null);
				if(null!=subscriber.getName() || null!=subscriber.getObjectId())
				{
					customerBuilder.buildCustomer(subscriber.getCommonName(), subscriber.getObjectId(), null, null, null, null);
				}
				partyBuilder.addHasCustomerRole(customerBuilder.getCustomer());
				searchResponseDetailsBuilder.addParty(partyBuilder.getParty());

				LOG.info("SUBSCRIBER COMMON NAME NAME : " + subscriber.getName());
				LOG.info("SUBSCRIBER OBJECT ID :   "+ subscriber.getObjectId() );

			}
			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		}
		else
		{
			throw new Exception("Entity not supported");
		}
	}
	//For LagCkts/VLAN/EVC 
	@SuppressWarnings("unchecked")
	public SearchResourceResponseDocument transformCLSToCim(Object circuitList,SearchResourceRequestDocument request,Object relatedCircuits) throws Exception 
	{
		ClassLoader mainLoader = Thread.currentThread().getContextClassLoader();
		Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());

		String entityType= MediationUtil.getRcv(request, "EntityType");
		boolean circuitsFound=false;

		try
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("ARMLookupToCim: Circuit Entity");
			}
			if (circuitList == null || ((List<ARMCircuit>) circuitList).isEmpty())
			{
				return MediationUtil.getSearchResourceErrorResponse("1951", "OSSDataNotFoundError", "Circuit could not be found in ARM", request);
			}
			
			searchResponseDetailsBuilder.buildSearchResponseDetails();		
			if(null!=circuitList && ((List<ARMCircuit>)circuitList).size()> 0)	
			{
				
				for(ARMCircuit circuit:(List<ARMCircuit>)circuitList)
				{

					if(null!=circuit)
					{
						if(null!=entityType && (entityType.equalsIgnoreCase("CE-VLAN")||entityType.equalsIgnoreCase("S-VLAN")))
						{
							if(circuit.getResourceType()!=null && circuit.getResourceType().equalsIgnoreCase("VLAN"))
							{
								if(circuit.getVlanFunction()!=null && circuit.getVlanFunction().equals(entityType))
								{
									subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getCommonName(), circuit.getObjectID(), null, null, circuit.getVlanFunction(), circuit.getStatus(), null, null);
									searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
									circuitsFound=true;
								}
								

							}
							else if(circuit.getResourceType()!=null && circuit.getResourceType().equals(entityType))
							{
								subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getCommonName(), circuit.getObjectID(), null, null, circuit.getResourceType(), circuit.getStatus(), null, null);
								searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
								circuitsFound=true;
							}
							
						}					
						else
						{
							subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getCommonName(), circuit.getObjectID(), null, null, circuit.getResourceType(), circuit.getStatus(), null, null);
							if(null != relatedCircuits && ((List<ARMCircuit>)relatedCircuits).size()> 0 )
							{
								for(ARMCircuit relatedCircuit:(List<ARMCircuit>)relatedCircuits)
								{
									if(null!=relatedCircuit)
									{
										resourceRelationshipBuilder.buildResourceRelationship(null,null,null,null,null);
										tempPoint2PointCircuitBuilder.buildPoint2PointCircuit(relatedCircuit.getCommonName(), relatedCircuit.getObjectID(), null, null, relatedCircuit.getResourceType(), relatedCircuit.getStatus(), null, null, null);
										resourceRelationshipBuilder.addCircuit(tempPoint2PointCircuitBuilder.getPoint2PointCircuit());
										subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
									}
								}

							}
							searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
							circuitsFound=true;
						}
					}
				}
			}
			if(!circuitsFound)
			{
				throw new OSSDataNotFoundException();
			}
			

			return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		}
		finally
		{
			Thread.currentThread().setContextClassLoader(mainLoader);
		}
	}

}
