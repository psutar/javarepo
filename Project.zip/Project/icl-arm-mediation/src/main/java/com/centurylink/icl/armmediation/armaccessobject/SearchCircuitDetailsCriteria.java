package com.centurylink.icl.armmediation.armaccessobject;

public class SearchCircuitDetailsCriteria {
	private String commonName;
	private String circuitSerialNumber;
	private String deviceName;
	private String circuitID;
	private String status;

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getCircuitSerialNumber() {
		return circuitSerialNumber;
	}

	public void setCircuitSerialNumber(String circuitSerialNumber) {
		this.circuitSerialNumber = circuitSerialNumber;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getCircuitID() {
		return circuitID;
	}

	public void setCircuitID(String circuitID) {
		this.circuitID = circuitID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
