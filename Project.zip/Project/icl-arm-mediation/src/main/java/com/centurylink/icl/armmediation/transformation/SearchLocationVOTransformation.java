package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.CLCLookupServiceHelper;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.service.impl.CLCLookupService;
import com.centurylink.icl.armmediation.valueobjects.objects.Location;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.EllipticBuilder;
import com.centurylink.icl.builder.cim2.ExchangeServiceAreaBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Elliptic;
import com.iclnbi.iclnbiV200.ExchangeServiceArea;

public class SearchLocationVOTransformation  {

	private static final Log LOG = LogFactory.getLog(SearchLocationVOTransformation.class);

	protected static AmericanPropertyAddress buildAddressFromLocaion(Location location)
	{
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();

		americanPropertyAddressBuilder.buildAmericanPropertyAddress(location.getName(), location.getLocationid(), location.getFullname(), null, null, location.getTowncity(), location.getZip(), location.getAddress1(), location.getAddress2(), location.getAddress3(), location.getProvince(), location.getLocation2locationtype());

		return americanPropertyAddressBuilder.getAmericanPropertyAddress();
	}

	protected static AmericanPropertyAddress getCLCAddressFromLocation(Location location) throws Exception
	{
		AmericanPropertyAddress clcAddress=null;
		if(location!=null){
			 clcAddress = CLCLookupServiceHelper.getCLCLookupService().getAddressByName(location.getName());
		}
		return formatCLCAddress(clcAddress);
	}
	
	// CLC attributes for InstalledAtAddress Details
	protected static AmericanPropertyAddress getCLCInstalledAddressFromLocation(
			Location location, String nodeName) throws Exception {

		AmericanPropertyAddress clcAddress = null;
		if (location != null) {
			clcAddress = CLCLookupServiceHelper.getCLCLookupService().getInstalledAddressByName(location.getName(), nodeName);
		}
		return formatCLCAddress(clcAddress);		
	}	

	protected static AmericanPropertyAddress getCLCServiceAddressFromName(String name) throws Exception
	{
		AmericanPropertyAddress clcAddress = CLCLookupServiceHelper.getCLCLookupService().getServiceAddressByName(name);

		return formatCLCAddress(clcAddress);
	}

	private static AmericanPropertyAddress formatCLCAddress(AmericanPropertyAddress clcAddress) throws Exception
	{
		AmericanPropertyAddressBuilder americanPropertyAddressBuilder = new AmericanPropertyAddressBuilder();

		if(clcAddress != null)
		{
			String fullName = null;

			for (CharacteristicValue cv : clcAddress.getRootEntityDescribedByList())
			{
				if (cv.getCharacteristicName().equalsIgnoreCase(Constants.LOCATIONFULLNAME))
				{
					fullName = cv.getCharacteristicValue();
				}
			}			

			americanPropertyAddressBuilder.buildAmericanPropertyAddress(clcAddress.getCommonName(), clcAddress.getObjectID(), fullName, clcAddress.getSourceSystem(), clcAddress.getStreetName(), clcAddress.getLocality(), clcAddress.getPostcode(), clcAddress.getAddressLine1(), clcAddress.getAddressLine2(), clcAddress.getAddressLine3(), clcAddress.getStateOrProvince(), null, clcAddress.getCLLI());

			americanPropertyAddressBuilder.setStreetInformation(clcAddress.getStreetNrFirst(), clcAddress.getStreetNrFirstSuffix(), clcAddress.getStreetNrFirstPrefix(), clcAddress.getStreetNamePrefix(), clcAddress.getStreetNameSuffix());
            americanPropertyAddressBuilder.setCoordinates(clcAddress.getLatitude(), clcAddress.getLongitude());

			
			if (clcAddress.getEllipticLocation() != null) {
				EllipticBuilder ellipticBuilder = new EllipticBuilder();
				ellipticBuilder.buildElliptic(clcAddress.getEllipticLocation().getHCoordinate(), 
						clcAddress.getEllipticLocation().getVCoordinate());
				americanPropertyAddressBuilder.setEllipticLocation(ellipticBuilder.getElliptic());
			}

			if (clcAddress.getExchangeServiceAreaList() != null
					&& clcAddress.getExchangeServiceAreaList().size() > 0) {
				for (ExchangeServiceArea area : clcAddress
						.getExchangeServiceAreaList()) {
					if (area.getAreaType().equalsIgnoreCase("LATA")
							&& !StringHelper.isEmpty(area.getCode())) {
						ExchangeServiceAreaBuilder exchangeServiceAreaBuilder = new  ExchangeServiceAreaBuilder();
						exchangeServiceAreaBuilder.buildExchangeServiceArea("LATA", null, area.getCode());
						americanPropertyAddressBuilder.addExchangeServiceArea(exchangeServiceAreaBuilder.getExchangeServiceArea());
						break;
					}
				}
			}	
			//code for HSIDetails
			for (CharacteristicValue cv : clcAddress.getRootEntityDescribedByList())
			{
				if (cv.getCharacteristicName().equalsIgnoreCase(Constants.SERVICEWIRECENTERCLLI))
				{
					americanPropertyAddressBuilder.addRootEntityDescribedBy(Constants.SERVICEWIRECENTERCLLI, cv.getCharacteristicValue());
				}
			}
			
			//code for Install Details
			for (CharacteristicValue cv : clcAddress.getRootEntityDescribedByList())
			{
				if (cv.getCharacteristicName().equalsIgnoreCase("TechAccessIndicator"))
					americanPropertyAddressBuilder.addRootEntityDescribedBy("TechAccessIndicator", cv.getCharacteristicValue());
				if (cv.getCharacteristicName().equalsIgnoreCase("ONTLocationOrientation"))
					americanPropertyAddressBuilder.addRootEntityDescribedBy("ONTLocationOrientation", cv.getCharacteristicValue());
				if (cv.getCharacteristicName().equalsIgnoreCase("ONTLocationRoom"))
					americanPropertyAddressBuilder.addRootEntityDescribedBy("ONTLocationRoom", cv.getCharacteristicValue());
				if (cv.getCharacteristicName().equalsIgnoreCase("OutsideRestrictions"))
					americanPropertyAddressBuilder.addRootEntityDescribedBy("OutsideRestrictions", cv.getCharacteristicValue());
				
				if (cv.getCharacteristicName().equalsIgnoreCase("InstallationRemarks")){
                    RemarkBuilder remarkBuilder = new RemarkBuilder();
                    remarkBuilder.buildRemark(cv.getCharacteristicValue(),"InstallationRemarks");
                    americanPropertyAddressBuilder.addRemark(remarkBuilder.getRemarks());
                    }

			}						
		}		

		return americanPropertyAddressBuilder.getAmericanPropertyAddress();
	}
}
