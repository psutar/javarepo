package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.service.MDWConstants;
import com.centurylink.icl.armmediation.storedprocedures.pkgnode.CreateNode;
import com.centurylink.icl.armmediation.transformation.ARMCreateDeviceToCim;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;

public class CreateDeviceService
{
	private static final Log LOG = LogFactory.getLog(CreateDeviceService.class);

	private CreateNode createNode;
	private ARMCreateDeviceToCim armCreateDeviceToCim;
	private SetObjectAttributeHelper setObjectAttributeHelper;

	private JDBCTempleteUtil jdbcTempleteUtil;

	public CreateDeviceResponseDocument createDevice(CreateDeviceRequestDocument requestObject, HashMap<String, Object> iHashMap) throws Exception
	{
		LOG.info("Starting Create Device");

		String deviceCLLI = requestObject.getCreateDeviceRequest().getDeviceList().get(0).getCLLICode();
		String deviceDefId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.DEVICE_DEF_ID);
		if (deviceDefId == null)
		{
			deviceDefId = getDeviceDefId(requestObject.getCreateDeviceRequest().getDeviceList().get(0).getHECIG());
		}

		String locationId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.LOCATION_ID);
		if (locationId == null)
		{
			locationId = getLocationId(deviceCLLI);
		}

		String commonName = buildDeviceName(deviceCLLI);
		HashMap<String, Object> map = (HashMap<String, Object>) createNode.execute(commonName, deviceDefId, locationId);

		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreateDeviceToCim.transformErrorToCim(requestObject, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}

		final BigDecimal nodeId = (BigDecimal) map.get("o_nodeid");

		HashMap<String, Object> attributeList = getDeviceattributeslist(deviceCLLI);

		map = (HashMap<String, Object>) setObjectAttributeHelper.execute("Node", nodeId, attributeList);

		o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreateDeviceToCim.transformErrorToCim(requestObject, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}

		CreateDeviceResponseDocument createDeviceResponse = armCreateDeviceToCim.transformToCim(requestObject, String.valueOf(nodeId), commonName);
		if (LOG.isInfoEnabled())
		{
			LOG.info(createDeviceResponse.toString());
		}
		return createDeviceResponse;

	}

	private HashMap<String, Object> getDeviceattributeslist(String in_deviceCLLI) throws Exception
	{

		HashMap<String, Object> attributeList = new HashMap<String, Object>();
		attributeList.put(Constants.CLLI, in_deviceCLLI);

		return attributeList;

	}

	private String buildDeviceName(String deviceCLLI)
	{
		return "NID" + "-" + deviceCLLI + "-" + "MOE";
	}

	private String getLocationId(String deviceCLLI)
	{
		return jdbcTempleteUtil.getLocationId(deviceCLLI.substring(0, 7));
	}

	private String getDeviceDefId(String hesig)
	{
		return jdbcTempleteUtil.getDeviceDefId(hesig);
	}

	public void setCreateNode(CreateNode createNode)
	{
		this.createNode = createNode;
	}

	public void setArmCreateDeviceToCim(ARMCreateDeviceToCim armCreateDeviceToCim)
	{
		this.armCreateDeviceToCim = armCreateDeviceToCim;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeHelper(SetObjectAttributeHelper setObjectAttributeHelper)
	{
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

}
