package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;

import com.centurylink.icl.armmediation.dataaccess.ImpactedCircuitsForDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;

public class ImpactedCircuitsForDeviceDAOImpl implements ImpactedCircuitsForDeviceDAO
{
	private JdbcTemplate jdbcTemplate;

	public ImpactedCircuitsForDeviceDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<ARMImpactedCircuits> getImpactedCircuitsForDevice(String query, final Boolean funcStatus) throws Exception
	{
		final List<ARMImpactedCircuits> cktList = this.jdbcTemplate.query(query, new RowMapper<ARMImpactedCircuits>()
				{
			public ARMImpactedCircuits mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMImpactedCircuits armCkt = new ARMImpactedCircuits();
				armCkt.setCommonName(rs.getString(Constants.NAME));
				armCkt.setObjectID(rs.getString("CKT_OBJECTID"));
				armCkt.setCktId(rs.getString(Constants.CIRCUIT_ID));
				armCkt.setCktfullName(rs.getString("FULLNAME"));
				armCkt.setAlias1(rs.getString("ALIAS1"));
				armCkt.setAlias2(rs.getString("ALIAS2"));
				armCkt.setResourceType(rs.getString("CIRCUITTYPE_NAME"));
				if(funcStatus==true)
					armCkt.setCktFuncStatus(rs.getString("CKT_FUNC_STATUS"));
				armCkt.setCktProvStatus(rs.getString("CKT_PROV_STATUS"));
				armCkt.setCkt2StartNode(rs.getString("CIRCUIT2STARTNODE"));
				armCkt.setCkt2EndNode(rs.getString("CIRCUIT2ENDNODE"));
				armCkt.setStartDeviceName(rs.getString("STARTNODE_NAME"));
				armCkt.setStartDeviceFullName(rs.getString("STARTNODE_FULLNAME"));
				armCkt.setStartDeviceObjectId(rs.getString("STARTNODE_OBJECTID"));
				armCkt.setStartDeviceClli(rs.getString("STARTNODE_CLLI"));
				armCkt.setStartDeviceIpAddress4(rs.getString("STARTNODE_IP"));
				armCkt.setStartDeviceIpAddress6(rs.getString("STARTNODE_IP_1"));
				armCkt.setEndDeviceName(rs.getString("ENDNODE_NAME"));
				armCkt.setEndDeviceFullName(rs.getString("ENDNODE_FULLNAME"));
				armCkt.setEndDeviceObjectId(rs.getString("ENDNODE_OBJECTID"));
				armCkt.setEndDeviceClli(rs.getString("ENDNODE_CLLI"));
				armCkt.setEndDeviceIpAddress4(rs.getString("ENDNODE_IP"));
				armCkt.setEndDeviceIpAddress6(rs.getString("ENDNODE_IP_1"));
				armCkt.setCkt2StartLoc(rs.getString("CIRCUIT2STARTLOCATION"));
				armCkt.setCkt2EndLoc(rs.getString("CIRCUIT2ENDLOCATION"));
				armCkt.setStartLocationName(rs.getString("STARTLOCATION_NAME"));
				armCkt.setStartLocAddressLine1(rs.getString("STARTLOCATION_ADDRESS1"));
				armCkt.setStartLocAddressLine2(rs.getString("STARTLOCATION_ADDRESS2"));
				armCkt.setStartLocAddressLine3(rs.getString("STARTLOCATION_ADDRESS3"));
				armCkt.setStartLoclocality(rs.getString("STARTLOCATION_TOWNCITY"));
				armCkt.setStartLocprovince(rs.getString("STARTLOCATION_PROVINCE"));
				armCkt.setStartpostcode(rs.getString("STARTLOCATION_ZIP"));
				armCkt.setEndLocationName(rs.getString("ENDLOCATION_NAME"));
				armCkt.setEndLocAddressLine1(rs.getString("ENDLOCATION_ADDRESS1"));
				armCkt.setEndLocAddressLine2(rs.getString("ENDLOCATION_ADDRESS2"));
				armCkt.setEndLocAddressLine3(rs.getString("ENDLOCATION_ADDRESS3"));
				armCkt.setEndLoclocality(rs.getString("ENDLOCATION_TOWNCITY"));
				armCkt.setEndLocprovince(rs.getString("ENDLOCATION_PROVINCE"));
				armCkt.setEndpostcode(rs.getString("ENDLOCATION_ZIP"));
				armCkt.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCkt.setSubsciberfullname(rs.getString(Constants.FULL_NAME));
				armCkt.setSubscriberId(rs.getString("subscriberId"));
				armCkt.setEmsHostName(rs.getString("NETWORKNAME"));
				armCkt.setDevicePrStatus(rs.getString("DEVICE_PROV_STATUS"));
				armCkt.setLocationClli(rs.getString(Constants.CLLI_CODE));
				armCkt.setTtServiceTypeCircuit(rs.getString(Constants.TT_SERVICE_TYPE));

				return armCkt;
			}
				});

		return cktList;
	}

	@Override
	public List<ARMImpactedCircuits> getImpactedServicesForDevice(String query, final Boolean funcStatus) throws Exception
	{
		final List<ARMImpactedCircuits> cktList = this.jdbcTemplate.query(query, new RowMapper<ARMImpactedCircuits>()
				{
			public ARMImpactedCircuits mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMImpactedCircuits armCkt = new ARMImpactedCircuits();
				armCkt.setServiceName(rs.getString(Constants.NAME));
				armCkt.setServiceID(rs.getString(Constants.SERVICE_ID));
				if(funcStatus==true)
					armCkt.setServiceFuncStatus(rs.getString("SERV_FUNC_STATUS"));
				armCkt.setServiceProvStatus(rs.getString("SERV_PROV_STATUS"));
				armCkt.setServiceTypeName(rs.getString("SERVICETYPENAME"));
				armCkt.setAlias1(rs.getString("ALIAS1"));
				armCkt.setAlias2(rs.getString("ALIAS2"));
				armCkt.setNodeID(rs.getString( Constants.NODE_ID));
				armCkt.setEndDeviceName(rs.getString("ENDNODE_NAME"));
				armCkt.setEndDeviceFullName(rs.getString("ENDNODE_FULLNAME"));
				armCkt.setEndDeviceObjectId(rs.getString("ENDNODE_OBJECTID"));
				armCkt.setEndDeviceClli(rs.getString("ENDNODE_CLLI"));
				armCkt.setEndDeviceIpAddress4(rs.getString("ENDNODE_IP"));
				armCkt.setEndDeviceIpAddress6(rs.getString("ENDNODE_IP_1"));
				armCkt.setEndLocationName(rs.getString("ENDLOCATION_NAME"));
				armCkt.setEndLocAddressLine1(rs.getString("ENDLOCATION_ADDRESS1"));
				armCkt.setEndLocAddressLine2(rs.getString("ENDLOCATION_ADDRESS2"));
				armCkt.setEndLocAddressLine3(rs.getString("ENDLOCATION_ADDRESS3"));
				armCkt.setEndLoclocality(rs.getString("ENDLOCATION_TOWNCITY"));
				armCkt.setEndLocprovince(rs.getString("ENDLOCATION_PROVINCE"));
				armCkt.setEndpostcode(rs.getString("ENDLOCATION_ZIP"));
				armCkt.setBan(rs.getString("UNIBAN"));
				armCkt.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCkt.setSubsciberfullname(rs.getString(Constants.FULL_NAME));
				armCkt.setSubscriberId(rs.getString("subscriberId"));
				armCkt.setUniHpc(rs.getString("UNI_HPC"));
				armCkt.setUniHpcExpDate(rs.getString("UNI_EPI_DATE"));
				armCkt.setEnniHpc(rs.getString("ENNI_HPC"));
				armCkt.setEnniHpcExpDate(rs.getString("ENNI_EPI_DATE"));
				armCkt.setEvcHpc(rs.getString("EVC_HPC"));
				armCkt.setEvcHpcExpDate(rs.getString("EVC_EPI_DATE"));
				armCkt.setOvcHpc(rs.getString("OVC_HPC"));
				armCkt.setOvcHpcExpDate(rs.getString("OVC_EPI_DATE"));
				armCkt.setEmsHostName(rs.getString("NETWORKNAME"));
				armCkt.setDevicePrStatus(rs.getString("DEVICE_PROV_STATUS"));
				armCkt.setLocationClli(rs.getString(Constants.CLLI_CODE));
				armCkt.setTtServiceTypeService(rs.getString(Constants.TT_SERVICE_TYPE));

				return armCkt;
			}
				});

		return cktList;
	}

	@Override
	public List<ARMImpactedCircuits> getRelatedImpactedServicesForDevice(String query) throws Exception
	{
		final List<ARMImpactedCircuits> serviceList = this.jdbcTemplate.query(query, new RowMapper<ARMImpactedCircuits>()
				{
			public ARMImpactedCircuits mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				ARMImpactedCircuits armCkt = new ARMImpactedCircuits();
				armCkt.setServiceName(rs.getString(Constants.NAME));
				armCkt.setServiceID(rs.getString(Constants.SERVICE_ID));
				armCkt.setServiceProvStatus(rs.getString("SERV_PROV_STATUS"));
				armCkt.setServiceTypeName(rs.getString("SERVICETYPENAME"));
				armCkt.setAlias1(rs.getString("ALIAS1"));
				armCkt.setAlias2(rs.getString("ALIAS2"));
				armCkt.setSubscriberName(rs.getString("CUSTOMER_NAME"));
				armCkt.setSubsciberfullname(rs.getString(Constants.FULL_NAME));
				armCkt.setSubscriberId(rs.getString("subscriberId"));

				if(rs.getString("SERVICETYPENAME")!=null)
				{
					if(rs.getString("SERVICETYPENAME").equalsIgnoreCase("MEF EVC")|| rs.getString("SERVICETYPENAME").equalsIgnoreCase("MEF OVC"))
					{
						armCkt.setEvcHpc(rs.getString("EVC_HPC"));
						armCkt.setEvcHpcExpDate(rs.getString("EVC_EPI_DATE"));
						armCkt.setOvcHpc(rs.getString("OVC_HPC"));
						armCkt.setOvcHpcExpDate(rs.getString("OVC_EPI_DATE"));
						armCkt.setTtServiceTypeService(rs.getString(Constants.TT_SERVICE_TYPE));
					}
					else if(rs.getString("SERVICETYPENAME").equalsIgnoreCase("MEF UNI")|| rs.getString("SERVICETYPENAME").equalsIgnoreCase("MEF ENNI"))
					{
						armCkt.setNodeID(rs.getString( Constants.NODE_ID));
						armCkt.setEndDeviceName(rs.getString("ENDNODE_NAME"));
						armCkt.setEndDeviceFullName(rs.getString("ENDNODE_FULLNAME"));
						armCkt.setEndDeviceObjectId(rs.getString("ENDNODE_OBJECTID"));
						armCkt.setEndDeviceClli(rs.getString("ENDNODE_CLLI"));
						armCkt.setEndDeviceIpAddress4(rs.getString("ENDNODE_IP"));
						armCkt.setEndDeviceIpAddress6(rs.getString("ENDNODE_IP_1"));
						armCkt.setEndLocationName(rs.getString("ENDLOCATION_NAME"));
						armCkt.setEndLocAddressLine1(rs.getString("ENDLOCATION_ADDRESS1"));
						armCkt.setEndLocAddressLine2(rs.getString("ENDLOCATION_ADDRESS2"));
						armCkt.setEndLocAddressLine3(rs.getString("ENDLOCATION_ADDRESS3"));
						armCkt.setEndLoclocality(rs.getString("ENDLOCATION_TOWNCITY"));
						armCkt.setEndLocprovince(rs.getString("ENDLOCATION_PROVINCE"));
						armCkt.setEndpostcode(rs.getString("ENDLOCATION_ZIP"));
						armCkt.setBan(rs.getString("UNIBAN"));
						armCkt.setUniHpc(rs.getString("UNI_HPC"));
						armCkt.setUniHpcExpDate(rs.getString("UNI_EPI_DATE"));
						armCkt.setEnniHpc(rs.getString("ENNI_HPC"));
						armCkt.setEnniHpcExpDate(rs.getString("ENNI_EPI_DATE"));
						armCkt.setEmsHostName(rs.getString("NETWORKNAME"));
						armCkt.setDevicePrStatus(rs.getString("DEVICE_PROV_STATUS"));
						armCkt.setLocationClli(rs.getString(Constants.CLLI_CODE));
						armCkt.setTtServiceTypeService(rs.getString(Constants.TT_SERVICE_TYPE));
					}
				}
                return armCkt;
			}
		});
		
		return serviceList;
	}

}
