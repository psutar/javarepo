package com.centurylink.icl.armmediation.valueobjects.objects;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;



public class DeviceModelDefaultParams extends AbstractReadOnlyTable {
	
	
	private static final long serialVersionUID = 1L;

	private static final Log LOG = LogFactory.getLog(DeviceModelDefaultParams.class);
	
	private static final String DEVICEMODEL_DEFAULT_PARAMS_ID = "DEVICEMODEL_DEFAULT_PARAMS_ID";
	private static final String NODEDEF_ID = "NODEDEF_ID";
	private static final String NODEDEF_NAME = "NODEDEF_NAME";
	private static final String EQUIPMENT_ROLE = "EQUIPMENT_ROLE";
	private static final String MAX_DOWNSTREAM_RATE = "MAX_DOWNSTREAM_RATE";
	private static final String MAX_UPSTREAM_RATE = "MAX_UPSTREAM_RATE";
	private static final String INDOOR = "INDOOR";
	private static final String MAX_NUMBER_OF_PON_CIRCUITS = "MAX_NUMBER_OF_PON_CIRCUITS";
	private static final String MAX_NUMBER_OF_CUSTOMERS = "MAX_NUMBER_OF_CUSTOMERS";
	private static final String MAX_SUBSCRIBER_BANDWIDTH = "MAX_SUBSCRIBER_BANDWIDTH";
	
	
	
	public DeviceModelDefaultParams()
	{
		super();
		this.tableName = "DeviceModel_Default_Params";
	}
	
	public DeviceModelDefaultParams(String portId)
	{
		this();
		primaryKey.setValue(DEVICEMODEL_DEFAULT_PARAMS_ID);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static Log getLog() {
		return LOG;
	}

	public static String getDevicemodelDefaultParamsId() {
		return DEVICEMODEL_DEFAULT_PARAMS_ID;
	}

	public static String getNodedefId() {
		return NODEDEF_ID;
	}

	public static String getNodedefName() {
		return NODEDEF_NAME;
	}

	public static String getEquipmentRole() {
		return EQUIPMENT_ROLE;
	}

	public static String getMaxDownstreamRate() {
		return MAX_DOWNSTREAM_RATE;
	}

	public static String getMaxUpstreamRate() {
		return MAX_UPSTREAM_RATE;
	}

	public static String getIndoor() {
		return INDOOR;
	}

	public static String getMaxNumberOfPonCircuits() {
		return MAX_NUMBER_OF_PON_CIRCUITS;
	}

	public static String getMaxNumberOfCustomers() {
		return MAX_NUMBER_OF_CUSTOMERS;
	}

	public static String getMaxSubscriberBandwidth() {
		return MAX_SUBSCRIBER_BANDWIDTH;
	}

	@Override
	public void populateModel() {
		
		fields.put(DEVICEMODEL_DEFAULT_PARAMS_ID, new Field(DEVICEMODEL_DEFAULT_PARAMS_ID, Field.TYPE_NUMERIC));
		fields.put(NODEDEF_ID, new Field(NODEDEF_ID, Field.TYPE_NUMERIC));
		fields.put(NODEDEF_NAME, new Field(NODEDEF_NAME, Field.TYPE_VARCHAR));
		fields.put(EQUIPMENT_ROLE, new Field(EQUIPMENT_ROLE, Field.TYPE_VARCHAR));
		fields.put(MAX_DOWNSTREAM_RATE, new Field(MAX_DOWNSTREAM_RATE, Field.TYPE_NUMERIC));
		fields.put(MAX_UPSTREAM_RATE, new Field(MAX_UPSTREAM_RATE, Field.TYPE_NUMERIC));
		fields.put(INDOOR, new Field(INDOOR, Field.TYPE_VARCHAR));
		fields.put(MAX_NUMBER_OF_PON_CIRCUITS, new Field(MAX_NUMBER_OF_PON_CIRCUITS, Field.TYPE_NUMERIC));
		fields.put(MAX_NUMBER_OF_CUSTOMERS, new Field(MAX_NUMBER_OF_CUSTOMERS, Field.TYPE_NUMERIC));
		fields.put(MAX_SUBSCRIBER_BANDWIDTH, new Field(MAX_SUBSCRIBER_BANDWIDTH, Field.TYPE_NUMERIC));
		
		
	}
	
	
	


}
