package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;
import com.centurylink.icl.valueobjects.impl.ReferenceField;

public class Location extends AbstractReadOnlyTable {

	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String RPPLANID = "RPPLANID";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LOCATION2RPBUILDTEMPLATE = "LOCATION2RPBUILDTEMPLATE";
	private static final String PHYSICALZ = "PHYSICALZ";
	private static final String PHYSICALY = "PHYSICALY";
	private static final String PHYSICALX = "PHYSICALX";
	private static final String LOCATION2PARENTLOCATION = "LOCATION2PARENTLOCATION";
	private static final String LOCATION2LOCATIONTYPE = "LOCATION2LOCATIONTYPE";
	private static final String LOCATION2FUNCTIONALSTATUS = "LOCATION2FUNCTIONALSTATUS";
	private static final String ADDRESS3 = "ADDRESS3";
	private static final String ADDRESS2 = "ADDRESS2";
	private static final String ADDRESS1 = "ADDRESS1";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String LOCATION2PROVISIONSTATUS = "LOCATION2PROVISIONSTATUS";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String NOTES = "NOTES";
	private static final String FAX = "FAX";
	private static final String TELEPHONE = "TELEPHONE";
	private static final String RESPONSIBLE = "RESPONSIBLE";
	private static final String ZIP = "ZIP";
	private static final String PROVINCE = "PROVINCE";
	private static final String TOWNCITY = "TOWNCITY";
	private static final String ADDRESS = "ADDRESS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String OBJECTID = "OBJECTID";
	private static final String ALIAS2 = "ALIAS2";
	private static final String ALIAS1 = "ALIAS1";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String NAME = "NAME";
	private static final String LOCATIONID = "LOCATIONID";

	public Location()
	{
		super();
		this.tableName = "LOCATION";
	}

	public Location(String locationId)
	{
		this();
		primaryKey.setValue(locationId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Location> getLocationListByQuery(String query)
	{
		Location location = new Location();
		List<Location> locationList = new ArrayList<Location>();
		List<Map<String,Object>> foundLocationList = location.getRecordsByQuery(query);

		for (Map<String,Object> locationMap : foundLocationList)
		{
			Location workLocation = new Location(locationMap.get(LOCATIONID).toString());
			locationList.add(workLocation);
		}
		return locationList;
	}

	@Override
	public void populateModel()
	{
		fields.put(LOCATION2LOCATIONTYPE, new ReferenceField(LOCATION2LOCATIONTYPE, Field.TYPE_NUMERIC, "LOCATIONTYPE", NAME, "LOCATIONTYPEID", this.getClass().getName()));

		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LOCATION2RPBUILDTEMPLATE, new Field(LOCATION2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(PHYSICALZ, new Field(PHYSICALZ, Field.TYPE_VARCHAR));
		fields.put(PHYSICALY, new Field(PHYSICALY, Field.TYPE_VARCHAR));
		fields.put(PHYSICALX, new Field(PHYSICALX, Field.TYPE_VARCHAR));
		fields.put(LOCATION2PARENTLOCATION, new Field(LOCATION2PARENTLOCATION, Field.TYPE_NUMERIC));
		fields.put(LOCATION2FUNCTIONALSTATUS, new Field(LOCATION2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(ADDRESS3, new Field(ADDRESS3, Field.TYPE_VARCHAR));
		fields.put(ADDRESS2, new Field(ADDRESS2, Field.TYPE_VARCHAR));
		fields.put(ADDRESS1, new Field(ADDRESS1, Field.TYPE_VARCHAR));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(LOCATION2PROVISIONSTATUS, new Field(LOCATION2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(FAX, new Field(FAX, Field.TYPE_VARCHAR));
		fields.put(TELEPHONE, new Field(TELEPHONE, Field.TYPE_VARCHAR));
		fields.put(RESPONSIBLE, new Field(RESPONSIBLE, Field.TYPE_VARCHAR));
		fields.put(ZIP, new Field(ZIP, Field.TYPE_VARCHAR));
		fields.put(PROVINCE, new Field(PROVINCE, Field.TYPE_VARCHAR));
		fields.put(TOWNCITY, new Field(TOWNCITY, Field.TYPE_VARCHAR));
		fields.put(ADDRESS, new Field(ADDRESS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(LOCATIONID, new Field(LOCATIONID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(LOCATIONID));
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLocation2rpbuildtemplate(String location2rpbuildtemplate)
	{
		setField(LOCATION2RPBUILDTEMPLATE,location2rpbuildtemplate);
	}

	public String getLocation2rpbuildtemplate()
	{
		return getFieldAsString(LOCATION2RPBUILDTEMPLATE);
	}

	public void setPhysicalz(String physicalz)
	{
		setField(PHYSICALZ,physicalz);
	}

	public String getPhysicalz()
	{
		return getFieldAsString(PHYSICALZ);
	}

	public void setPhysicaly(String physicaly)
	{
		setField(PHYSICALY,physicaly);
	}

	public String getPhysicaly()
	{
		return getFieldAsString(PHYSICALY);
	}

	public void setPhysicalx(String physicalx)
	{
		setField(PHYSICALX,physicalx);
	}

	public String getPhysicalx()
	{
		return getFieldAsString(PHYSICALX);
	}

	public void setLocation2parentlocation(String location2parentlocation)
	{
		setField(LOCATION2PARENTLOCATION,location2parentlocation);
	}

	public String getLocation2parentlocation()
	{
		return getFieldAsString(LOCATION2PARENTLOCATION);
	}

	public void setLocation2locationtype(String location2locationtype)
	{
		setField(LOCATION2LOCATIONTYPE,location2locationtype);
	}

	public String getLocation2locationtype()
	{
		return getFieldAsString(LOCATION2LOCATIONTYPE);
	}

	public void setLocation2functionalstatus(String location2functionalstatus)
	{
		setField(LOCATION2FUNCTIONALSTATUS,location2functionalstatus);
	}

	public String getLocation2functionalstatus()
	{
		return getFieldAsString(LOCATION2FUNCTIONALSTATUS);
	}

	public void setAddress3(String address3)
	{
		setField(ADDRESS3,address3);
	}

	public String getAddress3()
	{
		return getFieldAsString(ADDRESS3);
	}

	public void setAddress2(String address2)
	{
		setField(ADDRESS2,address2);
	}

	public String getAddress2()
	{
		return getFieldAsString(ADDRESS2);
	}

	public void setAddress1(String address1)
	{
		setField(ADDRESS1,address1);
	}

	public String getAddress1()
	{
		return getFieldAsString(ADDRESS1);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setLocation2provisionstatus(String location2provisionstatus)
	{
		setField(LOCATION2PROVISIONSTATUS,location2provisionstatus);
	}

	public String getLocation2provisionstatus()
	{
		return getFieldAsString(LOCATION2PROVISIONSTATUS);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setFax(String fax)
	{
		setField(FAX,fax);
	}

	public String getFax()
	{
		return getFieldAsString(FAX);
	}

	public void setTelephone(String telephone)
	{
		setField(TELEPHONE,telephone);
	}

	public String getTelephone()
	{
		return getFieldAsString(TELEPHONE);
	}

	public void setResponsible(String responsible)
	{
		setField(RESPONSIBLE,responsible);
	}

	public String getResponsible()
	{
		return getFieldAsString(RESPONSIBLE);
	}

	public void setZip(String zip)
	{
		setField(ZIP,zip);
	}

	public String getZip()
	{
		return getFieldAsString(ZIP);
	}

	public void setProvince(String province)
	{
		setField(PROVINCE,province);
	}

	public String getProvince()
	{
		return getFieldAsString(PROVINCE);
	}

	public void setTowncity(String towncity)
	{
		setField(TOWNCITY,towncity);
	}

	public String getTowncity()
	{
		return getFieldAsString(TOWNCITY);
	}

	public void setAddress(String address)
	{
		setField(ADDRESS,address);
	}

	public String getAddress()
	{
		return getFieldAsString(ADDRESS);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setLocationid(String locationid)
	{
		setField(LOCATIONID,locationid);
	}

	public String getLocationid()
	{
		return getFieldAsString(LOCATIONID);
	}
}