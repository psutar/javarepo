package com.centurylink.icl.armmediation.service;

public class CreateDeviceClliResponse
{
	private String deviceClli;
	private String equipmentType;
	private String servingWireCenter;
	
	public String getDeviceClli() {
		return deviceClli;
	}
	public void setDeviceClli(String deviceClli) {
		this.deviceClli = deviceClli;
	}
	public String getEquipmentType() {
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
	public String getServingWireCenter() {
		return servingWireCenter;
	}
	public void setServingWireCenter(String servingWireCenter) {
		this.servingWireCenter = servingWireCenter;
	}
}
