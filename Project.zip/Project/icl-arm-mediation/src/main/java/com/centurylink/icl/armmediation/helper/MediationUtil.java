package com.centurylink.icl.armmediation.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.builder.cim2.CreateDeviceResponseBuilder;
import com.centurylink.icl.builder.cim2.CreateDeviceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.MessageAddressingBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;
import com.iclnbi.iclnbiV200.CreatePartyRequestDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.ExchangeServiceArea;
import com.iclnbi.iclnbiV200.PartyRoleCategory;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.Remarks;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValueList;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.UpdateLocationRequestDocument;
import com.iclnbi.iclnbiV200.UpdatePartyRequestDocument;

public class MediationUtil
{

	final static private SearchResourceResponseDocumentBuilder	searchResourceResponseDocumentBuilder	= new SearchResourceResponseDocumentBuilder();
	final static private SearchResourceResponseBuilder			searchResourceResponseBuilder			= new SearchResourceResponseBuilder();
	final static private ErrorBuilder							errorBuilder							= new ErrorBuilder();
	final static private MessageElementsBuilder					messageElementsBuilder					= new MessageElementsBuilder();
	final static private CreateDeviceResponseDocumentBuilder	createDeviceResponseDocumentBuilder		= new CreateDeviceResponseDocumentBuilder();
	final static private CreateDeviceResponseBuilder			createDeviceResponseBuilder				= new CreateDeviceResponseBuilder();
	final static MessageAddressingBuilder mab = new MessageAddressingBuilder();
	public static String getValueFromMap(Map<String, Object> map, String key)
	{

		Object object = map.get(key);

		if (object != null && object instanceof String)
			return (String) object;
		else
			return "NotFound";

	}

	public static String getRcv(SearchResourceRequestDocument request, String characteristicName)
	{

		for (ResourceCharacteristicValue current : request.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return current.getCharacteristicValue();
			}
		}

		return null;
	}

	public static String getRcv(CreateLocationRequestDocument request, String charactristicName)
	{

		for (CharacteristicValue current : request.getCreateLocationRequest().getAddressDetails().getRootEntityDescribedByList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(charactristicName))
			{
				return current.getCharacteristicValue();
			}
		}

		return null;

	}
	
	public static String getRcv(UpdateLocationRequestDocument request, String characteristicName)
	{

		for (CharacteristicValue current : request.getUpdateLocationRequest().getAddressDetails().getRootEntityDescribedByList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return current.getCharacteristicValue();
			}
		}

		return null;
	}
	
	public static String getNotes(CreatePartyRequestDocument request, String notes) throws Exception
	{

		for (Remarks current : request.getCreatePartyRequest().getPartyDetails().getRemarksList())
		{
			/*if (current.getr.equalsIgnoreCase(notes))
			{*/
				return current.getText();
			//}
		}

		return null;
	}

	public static String getNotes(UpdatePartyRequestDocument request, String notes) throws Exception
	{

		for (Remarks current : request.getUpdatePartyRequest().getPartyDetails().getRemarksList())
		{
			/*if (current.getr.equalsIgnoreCase(notes))
			{*/
				return current.getText();
			//}
		}

		return null;
	}
	
	

	public static String getExchangeServiceArea(CreateLocationRequestDocument request, String areaType) throws Exception
	{

		for (ExchangeServiceArea current : request.getCreateLocationRequest().getAddressDetails().getExchangeServiceAreaList())
		{
			if (current.getAreaType().equalsIgnoreCase(areaType))
			{
				return current.getCode();
			}
		}

		return null;
	}
	
	public static String getExchangeServiceArea(UpdateLocationRequestDocument request, String areaType) throws Exception
	{

		for (ExchangeServiceArea current : request.getUpdateLocationRequest().getAddressDetails().getExchangeServiceAreaList())
		{
			if (current.getAreaType().equalsIgnoreCase(areaType))
			{
				return current.getCode();
			}
		}

		return null;
	}

	public static String getNpaNxx(UpdateLocationRequestDocument request, String areaType) throws Exception
	{

		for (ExchangeServiceArea current : request.getUpdateLocationRequest().getAddressDetails().getExchangeServiceAreaList())
		{
			if (current.getAreaType().equalsIgnoreCase(areaType))
			{
				return current.getCode();
			}
		}

		return null;
	}
	
	public static String rootEntityDescriberBy(CreatePartyRequestDocument request, String channel) throws Exception
	{

		for (Customer current : request.getCreatePartyRequest().getPartyDetails().getHasCustomerRoleList())
		{
			for(CharacteristicValue currentval : current.getRootEntityDescribedByList()){
				
				if (currentval.getCharacteristicName().equalsIgnoreCase(channel))
				{
					return currentval.getCharacteristicValue();
				}
			}
		}

		return null;
	}
	public static String rootEntityDescriberBy(UpdatePartyRequestDocument request, String channel) throws Exception
	{

		for (Customer current : request.getUpdatePartyRequest().getPartyDetails().getHasCustomerRoleList())
		{
			for(CharacteristicValue currentval : current.getRootEntityDescribedByList()){
				
				if (currentval.getCharacteristicName().equalsIgnoreCase(channel))
				{
					return currentval.getCharacteristicValue();
				}
			}
		}

		return null;
	}
	
	public static String getCategory(CreatePartyRequestDocument request, String category) throws Exception
	{

		for (Customer current : request.getCreatePartyRequest().getPartyDetails().getHasCustomerRoleList())
		{
			for(PartyRoleCategory currentval : current.getPartyRoleCategorizedUsingList()){
				
				/*if (currentval.getCategoryName().equalsIgnoreCase(category))
				{*/
					return currentval.getCategoryName();
				//}
			}
		}

		return null;
	}
	
	public static String getCategory(UpdatePartyRequestDocument request, String category) throws Exception
	{

		for (Customer current : request.getUpdatePartyRequest().getPartyDetails().getHasCustomerRoleList())
		{
			for(PartyRoleCategory currentval : current.getPartyRoleCategorizedUsingList()){
				
				/*if (currentval.getCategoryName().equalsIgnoreCase(category))
				{*/
					return currentval.getCategoryName();
				//}
			}
		}

		return null;
	}
	
	public static String getGeographicLocation(CreateLocationRequestDocument request, String location)
	{
			if ("HCoordinate".equalsIgnoreCase(location))
			{
				return request.getCreateLocationRequest().getAddressDetails().getEllipticLocation().getHCoordinate();
			}
			if ("VCoordinate".equalsIgnoreCase(location))
			{
				return request.getCreateLocationRequest().getAddressDetails().getEllipticLocation().getVCoordinate();
			}
	
		return null;
	}

	public static String getGeographicLocation(UpdateLocationRequestDocument request, String location)
	{
			if ("HCoordinate".equalsIgnoreCase(location))
			{
				return request.getUpdateLocationRequest().getAddressDetails().getEllipticLocation().getHCoordinate();
			}
			if ("VCoordinate".equalsIgnoreCase(location))
			{
				return request.getUpdateLocationRequest().getAddressDetails().getEllipticLocation().getVCoordinate();
			}
	
		return null;
	}
	
	public static SearchResourceResponseDocument getSearchResourceErrorResponse(String errorCode, String errorMessage, String errorText, SearchResourceRequestDocument request)
	{
		errorBuilder.buildError(errorCode, errorMessage, "FAILED", errorText, "ARM");
		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		if (request != null)
			messageElementsBuilder.setMessageAddressing(request.getSearchResourceRequest().getMessageElements().getMessageAddressing());
		searchResourceResponseBuilder.buildSearchResourceResponse(null, messageElementsBuilder.getMessageElements());
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	
	
	public static SearchResourceResponseDocument getSearchResourceSuccessResponse(SearchResponseDetails searchResponseDetails, SearchResourceRequestDocument request)
	{
		messageElementsBuilder.buildMessageElements("SUCCESS", "");
		if (request != null && request.getSearchResourceRequest().getMessageElements() != null)
			messageElementsBuilder.setMessageAddressing(request.getSearchResourceRequest().getMessageElements().getMessageAddressing());
		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetails, messageElementsBuilder.getMessageElements());
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}
	
	public static SearchResourceResponseDocument getSearchResourceDeviceResponse(SearchResponseDetails searchResponseDetails, SearchResourceRequestDocument request)
	{
		messageElementsBuilder.buildMessageElements("SUCCESS", "");
		
		mab.buildMessageAddressing("DSP", "ICL", "DSP2345", "SearchResource", "2008-09-29T07:19:45", "1234", "SearchResource", "3.0");
		messageElementsBuilder.setMessageAddressing(mab.getMessageAddressing());
		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetails, messageElementsBuilder.getMessageElements());
		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	public static CreateDeviceResponseDocument getCreateDeviceErrorResponse(String errorCode, String errorMessage, String errorText, SearchResourceRequestDocument request)
	{
		errorBuilder.buildError(errorCode, errorMessage, "FAILED", errorText, "ARM");
		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		if (request != null)
			messageElementsBuilder.setMessageAddressing(request.getSearchResourceRequest().getMessageElements().getMessageAddressing());
		createDeviceResponseBuilder.buildCreateDeviceResponse();
		createDeviceResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createDeviceResponseDocumentBuilder.buildCreateDeviceResponseDocument();
		createDeviceResponseDocumentBuilder.addCreateDeviceResponse(createDeviceResponseBuilder.getCreateDeviceResponse());
		return createDeviceResponseDocumentBuilder.getCreateDeviceResponseDocument();
	}

	public static CreateDeviceResponseDocument getCreateDeviceSuccessResponse(PhysicalDevice device, SearchResourceRequestDocument request)
	{
		messageElementsBuilder.buildMessageElements("SUCCESS", "");
		mab.buildMessageAddressing("DSP", "ICL", "DSP2345", "CreateDevice", "2008-09-29T07:19:45", "1234", "CreateDevice", "3.0");
		messageElementsBuilder.setMessageAddressing(mab.getMessageAddressing());
		createDeviceResponseBuilder.buildCreateDeviceResponse();
		createDeviceResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createDeviceResponseBuilder.addDevice(device);
		createDeviceResponseDocumentBuilder.buildCreateDeviceResponseDocument();
		createDeviceResponseDocumentBuilder.addCreateDeviceResponse(createDeviceResponseBuilder.getCreateDeviceResponse());
		return createDeviceResponseDocumentBuilder.getCreateDeviceResponseDocument();
	}

	public static List<String> getRcv(List<ResourceCharacteristicValueList> list, String characteristicName)
	{
		final List<String> clliList = new ArrayList<String>();
		for (ResourceCharacteristicValueList currentList : list)
		{
			for (ResourceCharacteristicValue current : currentList.getResourceCharacteristicValueList())
			{
				if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
				{
					clliList.add(current.getCharacteristicValue());
				}
			}
			return clliList;
		}

		return null;
	}
	public static String getAddress(UpdateLocationRequestDocument request, String characteristicName) throws Exception
	{

		for (CharacteristicValue current : request.getUpdateLocationRequest().getAddressDetails().getRootEntityDescribedByList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return current.getCharacteristicValue();
			}
		}

		return null;
	}
}
