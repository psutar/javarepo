package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMImpactedCircuits;
import com.centurylink.icl.armmediation.armaccessobject.SearchResourceCriteria;
import com.centurylink.icl.armmediation.dataaccess.TransportPathDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.transformation.TransportPathToCim;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.common.util.SQLBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchTransportPathService 

{

	private static final Log LOG = LogFactory.getLog(SearchTransportPathService.class);
	private String ND1="ND1";
	private String ND2="ND2";
	private String EXT_ND1="EXT_ND1";
	private String EXT_ND2="EXT_ND2";

	private TransportPathDAO transportPathDAO;
	private DiscoverTransportPathService discoverTransportPathService;

	public void setTransportPathDAO(TransportPathDAO transportPathDAO)
	{
		this.transportPathDAO = transportPathDAO;
	}

	public void setDiscoverTransportPathService(DiscoverTransportPathService discoverTransportPathService)
	{
		this.discoverTransportPathService = discoverTransportPathService;
	}

	public Object searchTransportPathService(SearchResourceRequestDocument request) throws Exception
	{

		TransportPathToCim transportPathToCim=new TransportPathToCim();

		SearchResourceCriteria searchResourceCriteria = new SearchResourceCriteria();
		searchResourceCriteria.setDeviceName(MediationUtil.getRcv(request, "NIDDeviceName"));
		searchResourceCriteria.setCircuitName(request.getSearchResourceRequest().getSearchResourceDetails().getCommonName());


		List<ARMImpactedCircuits> nminnicktList = new ArrayList<ARMImpactedCircuits>();
		List<ARMImpactedCircuits> transportPathCktList = new ArrayList<ARMImpactedCircuits>();
		List<String> lagCircuitsList=new ArrayList<String>();
		List<ARMImpactedCircuits> lagCktList=new ArrayList<ARMImpactedCircuits>();
		List<ARMImpactedCircuits> lagrelatedEBCircuitsList = new ArrayList<ARMImpactedCircuits>();

		if (!StringHelper.isEmpty(searchResourceCriteria.getDeviceName()) || !StringHelper.isEmpty(searchResourceCriteria.getCircuitName()))
		{
			String resourceType=null;
			//When DeviceName is passed 
			if(!StringHelper.isEmpty(searchResourceCriteria.getDeviceName())&& StringHelper.isEmpty(searchResourceCriteria.getCircuitName()))
			{
				//Get EB Circuits when DeviceName is passed 
				nminnicktList=discoverTransportPathService.getEbCktsByDevice(searchResourceCriteria);

				if(nminnicktList!=null && nminnicktList.size()>0)
				{
					for(ARMImpactedCircuits nmnnickt:nminnicktList)
					{
						//Check whether EB is part of a LAG or not,if yes get the LAG ckt Data from the LAG Circuit passed
						if(nmnnickt.getIsLagMember()!=null)
						{
							/*if(uniquesCktMap.get(nmnnickt.getIsLagMember())==null)
							{
								uniquesCktMap.put(nmnnickt.getIsLagMember(), nmnnickt.getIsLagMember());
							}*/

							lagCircuitsList.add(nmnnickt.getIsLagMember());

						}
					}
					if(lagCircuitsList!=null && lagCircuitsList.size()>0)
					{
						lagCktList=discoverTransportPathService.getLagCkts(lagCircuitsList);
					}
					//Get the Type of the Circuits we got
					if(lagCktList!=null && lagCktList.size()>0)
					{
						resourceType=lagCktList.get(0).getResourceType();
						lagrelatedEBCircuitsList=discoverTransportPathService.getTransportPathRelatedCircuits(lagCktList,resourceType);
						if(lagrelatedEBCircuitsList!=null && lagrelatedEBCircuitsList.size()>0)
						{
							for(ARMImpactedCircuits lagrelatedEBCircuit :lagrelatedEBCircuitsList)
							{
								lagCktList.add(lagrelatedEBCircuit);

							}
						}
						//Get TP Circuits for LAG Circuits 
						transportPathCktList=discoverTransportPathService.getTransportPathCircuits(lagCktList,resourceType);
						//Get TP Related EB or LAG Circuits and add the returned EB or LAG Circuits with the existing  LAG Circuit alongwith TP Circuit
						lagCktList=discoverTransportPathService.getTPandEBCircuits(transportPathCktList,lagCktList);

					}
					else
					{
						resourceType=nminnicktList.get(0).getResourceType();
						//Get TP Circuits for EB Circuits 
						transportPathCktList=discoverTransportPathService.getTransportPathCircuits(nminnicktList,resourceType);
						//Get TP Related EB or LAG Circuits and add the returned EB or LAG Circuits with the existing EB or LAG Circuit alongwith TP Circuit
						nminnicktList=discoverTransportPathService.getTPandEBCircuits(transportPathCktList,nminnicktList);
					}


				}	

			}
			// When Circuit Name is passed in Request
			else if(StringHelper.isEmpty(searchResourceCriteria.getDeviceName())&& !StringHelper.isEmpty(searchResourceCriteria.getCircuitName()))
			{
				List<ARMImpactedCircuits> tpCktList = new ArrayList<ARMImpactedCircuits>();
				//Get the TP Circuit Details for the Given TP Circuit 
				tpCktList=getTPCktsByDevice(searchResourceCriteria);

				if(tpCktList!=null && tpCktList.size()>0)
				{
					resourceType=tpCktList.get(0).getResourceType();	
					//Get TP Related EB Circuits
					nminnicktList=discoverTransportPathService.getTransportPathRelatedCircuits(tpCktList, resourceType);
					//Add TP Circuit to EB Circuits List we got 
					if(nminnicktList!=null && nminnicktList.size()>0)
					{
						for(ARMImpactedCircuits armckt:tpCktList)
						{
							nminnicktList.add(armckt);
						}
						for(ARMImpactedCircuits ckt:nminnicktList)
						{
							if(ckt!=null && ckt.getResourceType()!=null && ckt.getResourceType().equalsIgnoreCase("Link Aggregation Group"))
							{
								lagCktList.add(ckt);
								lagrelatedEBCircuitsList=discoverTransportPathService.getTransportPathRelatedCircuits(lagCktList,ckt.getResourceType());
								if(lagrelatedEBCircuitsList!=null && lagrelatedEBCircuitsList.size()>0)
								{
									for(ARMImpactedCircuits lagrelatedEBCircuit :lagrelatedEBCircuitsList)
									{
										lagCktList.add(lagrelatedEBCircuit);

									}
								}
							}
						}
					}
					if(lagCktList!=null && lagCktList.size()>0)
					{
						for(ARMImpactedCircuits armckt:tpCktList)
						{
							lagCktList.add(armckt);
						}
					}
				}	
			}
		}
		if(lagCktList!=null && lagCktList.size()>0)
		{
			SearchResponseDetailsBuilder searchResponseDetailsBuilder = transportPathToCim
					.transformTransportPathToCim(null,lagCktList);
			SearchResourceResponseDocument response=MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
			return response;
		}
		else if(nminnicktList!=null && nminnicktList.size()>0)
		{
			SearchResponseDetailsBuilder searchResponseDetailsBuilder = transportPathToCim
					.transformTransportPathToCim(nminnicktList,null);
			SearchResourceResponseDocument response=MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
			return response;
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}	
	protected List<ARMImpactedCircuits> getTPCktsByDevice(SearchResourceCriteria searchResourceCriteria) throws Exception
	{

		List<ARMImpactedCircuits> tpCktList = new ArrayList<ARMImpactedCircuits>();
		tpCktList=transportPathDAO
				.getTransportPathDAO(
						buildTransportPathQueryByCircuit(searchResourceCriteria),false,false);
		return tpCktList;
	}

	private String buildTransportPathQueryByCircuit(SearchResourceCriteria criteria)
	{

		SQLBuilder sql=new SQLBuilder(Constants.CIRCUIT);
		sql.addTable(Constants.CIRCUIT_TYPE);
		sql.addTable(Constants.PROVISION_STATUS,"CKT_PROVISION_STATUS");
		sql.addTable(Constants.PROVISION_STATUS,"DEVICE_PROVISION_STATUS");
		sql.addTable(Constants.NODE, ND1);
		sql.addTable(Constants.NODE, ND2);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND1);
		sql.addTable(Constants.EXT_DEVICE_TYPE, EXT_ND2);
		sql.addTable(Constants.SUBSCRIBER);
		sql.addTable(Constants.NODE_DEF);
		sql.addTable(Constants.NODE_TYPE);
		sql.addTable(Constants.NETWORKROLE,"NWROLE2");
		sql.addTable(Constants.NETWORKROLEOBJECT,"NWOBJ1");
		sql.addTable(Constants.NETWORKROLE,"NWROLE1");
		sql.addTable(Constants.NETWORKROLEOBJECT,"NWOBJ2");
		sql.addFieldFromTable("NWROLE1", "NETWORKROLEID","NETWORKROLEID1");
		sql.addFieldFromTable("NWROLE2", "NETWORKROLEID","NETWORKROLEID2");
		sql.addFieldFromTable("NWROLE1", Constants.ALIAS_1, "ROLE1");
		sql.addFieldFromTable("NWROLE2", Constants.ALIAS_1, "ROLE2");

		sql.addFieldFromTable(EXT_ND1,Constants.NETWORK_NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.NAME);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.CIRCUIT_ID);
		sql.addFieldFromTable(Constants.CIRCUIT, Constants.OBJECT_ID, "CKT_OBJECTID");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS1");
		sql.addFieldFromTable(Constants.CIRCUIT, "ALIAS2");
		sql.addFieldFromTable(Constants.CIRCUIT_TYPE, Constants.NAME, "CIRCUITTYPE_NAME");
		sql.addFieldFromTable("CKT_PROVISION_STATUS", Constants.NAME, "CKT_PROV_STATUS");
		sql.addFieldFromTable("DEVICE_PROVISION_STATUS", Constants.NAME, "DEVICE_PROV_STATUS");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTNODE");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDNODE");
		sql.addFieldFromTable(ND1, Constants.NAME, "STARTNODE_NAME");
		sql.addFieldFromTable(ND1, Constants.FULL_NAME, "STARTNODE_FULLNAME");
		sql.addFieldFromTable(ND1, Constants.OBJECT_ID, "STARTNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND1, Constants.CLLI, "STARTNODE_CLLI");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V4_MGM_ROUTER_ID, "STARTNODE_IP");
		sql.addFieldFromTable(EXT_ND1, Constants.IP_V6_MGM_ROUTERID, "STARTNODE_IP_1");
		sql.addFieldFromTable(ND2, Constants.NAME, "ENDNODE_NAME");
		sql.addFieldFromTable(ND2, Constants.FULL_NAME, "ENDNODE_FULLNAME");
		sql.addFieldFromTable(ND2, Constants.OBJECT_ID, "ENDNODE_OBJECTID");
		sql.addFieldFromTable(EXT_ND2, Constants.CLLI, "ENDNODE_CLLI");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V4_MGM_ROUTER_ID, "ENDNODE_IP");
		sql.addFieldFromTable(EXT_ND2, Constants.IP_V6_MGM_ROUTERID, "ENDNODE_IP_1");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2STARTLOCATION");
		sql.addFieldFromTable(Constants.CIRCUIT, "CIRCUIT2ENDLOCATION");
		sql.addFieldFromTable(Constants.NODE_DEF, "NAME", "NODEDEFNAME");
		sql.addFieldFromTable(Constants.NODE_TYPE, "NAME", "NODETYPENAME");

		sql.addFieldFromTable(Constants.CIRCUIT, Constants.RELATIVE_NAME, "CUSTOMER_NAME");
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.FULL_NAME);
		sql.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_CIRCUIT_TYPE, Constants.CIRCUIT_TYPE, Constants.CIRCUIT_TYPE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_PROVISION_STATUS, "CKT_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_START_NODE, ND1, Constants.NODE_ID);
		sql.eq(Constants.CIRCUIT, Constants.CIRCUIT_2_END_NODE, ND2, Constants.NODE_ID);	
		sql.eq(EXT_ND1, Constants.NODE_ID, ND1, Constants.NODE_ID);
		sql.eq(EXT_ND2, Constants.NODE_ID, ND2, Constants.NODE_ID);
		sql.eq("ND1",Constants.NODE_2_PROVISION_STATUS,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.eq("ND2",Constants.NODE_2_PROVISION_STATUS ,"DEVICE_PROVISION_STATUS", Constants.PROVISION_STATUS_ID);
		sql.joinFO(Constants.CIRCUIT, Constants.RELATIVE_NAME, Constants.SUBSCRIBER, Constants.NAME);
		sql.joinFO(ND1, "NODE2NODEDEF", Constants.NODE_DEF, "NODEDEFID");
		sql.joinFO(ND1, "NODE2NODETYPE", Constants.NODE_TYPE, "NODETYPEID");

		sql.joinFO(ND1, Constants.NODE_ID, "NWOBJ1","NETWORKROLEOBJECT2OBJECT");
		sql.joinFO("NWOBJ1", "NETWORKROLEOBJECT2NETWORKROLE", "NWROLE1","NETWORKROLEID");
		sql.joinFO(ND2, Constants.NODE_ID, "NWOBJ2","NETWORKROLEOBJECT2OBJECT");
		sql.joinFO("NWOBJ2", "NETWORKROLEOBJECT2NETWORKROLE", "NWROLE2","NETWORKROLEID");

		if(criteria!=null)
		{
			if(!StringHelper.isEmpty(criteria.getCircuitName()))
			{
				sql.eq(Constants.CIRCUIT,Constants.CIRCUIT_2_CIRCUIT_TYPE,"1900000007");
				sql.eq(Constants.CIRCUIT,Constants.NAME,criteria.getCircuitName());
			}

		}

		final String query = sql.getStatement();
		if (LOG.isInfoEnabled())
		{
			LOG.info("buildTransportPathQueryByCircuit :" + query);
		}

		return query;

	}
}
