package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.storedprocedures.pkgsubscriber.DeleteLocationFromSubscriber;
import com.centurylink.icl.armmediation.transformation.ARMDeleteLocationToCim;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.DeleteLocationRequestDocument;
import com.iclnbi.iclnbiV200.DeleteLocationResponseDocument;

public class DeleteLocationService {
	
	private static final Log LOG = LogFactory.getLog(DeleteLocationService.class);
	private ARMDeleteLocationToCim armDeleteLocationToCim;
	private JDBCTempleteUtil jdbcTempleteUtil;
	//private DeleteSubscriber deleteLocation;
	private SetObjectAttributeHelper setObjectAttributeHelper;
	private DeleteLocationFromSubscriber deleteLocationFromSubscriber;

	public void setArmDeleteLocationToCim(
			ARMDeleteLocationToCim armDeleteLocationToCim) {
		this.armDeleteLocationToCim = armDeleteLocationToCim;
	}

	public DeleteLocationResponseDocument deleteLocation(DeleteLocationRequestDocument deleteLocRequest) throws Exception
	
	{
		final int locationID;
		String commonId;
		String locationName=deleteLocRequest.getDeleteLocationRequest().getAddressDetails().getCommonName();
		if(locationName.isEmpty())
		{
			throw new ICLException("ICLRequestValidationError", "Please enter locationName", "1948");
		}
		//final String locationType = deleteLocRequest.getDeleteLocationRequest().getAddressDetails().getAddressType();
		LOG.info("Starting Delete Subscriber");
		
		commonId=getMarkForDelete(locationName);
		if(commonId!=null){
			
			throw new ICLException("ICLRequestValidationError", "Location already Deleted", "1948");
		}
		
		try{
			
			locationID=getDeleteLocationID(locationName);
		}
		catch(IndexOutOfBoundsException e)
		{
			throw new ICLException("ICLRequestValidationError", "Please enter a valid locationName", "1948");
			
		}
		HashMap<String, Object> attributeList = getLocationattributeslist(locationName, deleteLocRequest);
		
		Map <String, Object> map = setObjectAttributeHelper.execute("Location", new BigDecimal(locationID), attributeList);
	
		
		//Map<String, Object> map = deleteLocation.execute(locationID);
		
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armDeleteLocationToCim.transformErrorToCim(deleteLocRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		
		//Delete subscribers 
		List<Integer> subscribersToBeDeleted = getSubscriberToBeDeletedIds(Integer.toString(locationID));
		for (Integer subscriberId : subscribersToBeDeleted) {
			
			map = deleteLocationFromSubscriber.execute(BigDecimal.valueOf(subscriberId),locationID);
			o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
			if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
			{
				final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
				if (LOG.isInfoEnabled())
				{
					LOG.info(o_Errormsg);
				}
				return armDeleteLocationToCim.transformErrorToCim(deleteLocRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
			}
		}

		return armDeleteLocationToCim.transformToCim(deleteLocRequest, locationName);
	}
		
		
	private List<Integer> getSubscriberToBeDeletedIds(String locationId) throws Exception
	{
		return jdbcTempleteUtil.getSubscriberIdMultiple(buildSubscriberIdToBeDeleted(locationId),"SUBSCRIBERLOCATION2SUBSCRIBER");
	}
	
	private String buildSubscriberIdToBeDeleted(String locationId)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBERLOCATION);
		sqlBuilder.addField("SUBSCRIBERLOCATION2SUBSCRIBER");
		sqlBuilder.eq(Constants.SUBSCRIBERLOCATION,"subscriberlocation2location",locationId);
		String query = sqlBuilder.getStatement();
		LOG.info(query);
		return query;
	}
	

	private HashMap<String, Object> getLocationattributeslist(
			String locationType, DeleteLocationRequestDocument deleteLocRequest) {
		// TODO Auto-generated method stub
		
		final HashMap<String, Object> attributeList = new HashMap<String, Object>();
		attributeList.put(Constants.MARKED_FOR_DELETE, new BigDecimal(1));
		
		return attributeList;
	}

	private int	getDeleteLocationID(String locationName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addField(Constants.LOCATION_ID, Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.LOCATION, Constants.NAME, locationName);
		

		final int locationId = jdbcTempleteUtil.getDeleteLocationId(sqlBuilder.getStatement());
		return locationId;
	}
	
	private String	getMarkForDelete(String locationName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addFieldFromTable(Constants.LOCATION,Constants.MARKED_FOR_DELETE);
		sqlBuilder.eq(Constants.LOCATION, Constants.NAME, locationName);
		

		final String markForDelete = jdbcTempleteUtil.getMarkedForDelete(sqlBuilder.getStatement());
		
		return markForDelete;
	}
	
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil) {
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeHelper(
			SetObjectAttributeHelper setObjectAttributeHelper) {
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}
	
	public void setDeleteLocationFromSubscriber(
			DeleteLocationFromSubscriber deleteLocationFromSubscriber) {
		this.deleteLocationFromSubscriber = deleteLocationFromSubscriber;
	}

	
}
