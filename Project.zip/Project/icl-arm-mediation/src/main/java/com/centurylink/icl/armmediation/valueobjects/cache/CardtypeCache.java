package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.CardType;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class CardtypeCache implements ValueObjectCache {

	
	private Map<String, CardType> cachedObjects = new HashMap<String, CardType>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key) 
	{
		
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			CardType newCardtype = new CardType(key);
			if (newCardtype.isInstanciated())
			{
				cachedObjects.put(key, newCardtype);
				return newCardtype;
			} else {
				return null;
			}
		}
	}

}
