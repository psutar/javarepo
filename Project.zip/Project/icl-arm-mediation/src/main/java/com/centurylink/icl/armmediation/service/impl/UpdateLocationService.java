package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.storedprocedures.pkglocation.AddLocationToSubscriber;
import com.centurylink.icl.armmediation.storedprocedures.pkgsubscriber.DeleteLocationFromSubscriber;
import com.centurylink.icl.armmediation.transformation.ARMUpdateLocationToCim;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.UpdateLocationRequestDocument;
import com.iclnbi.iclnbiV200.UpdateLocationResponseDocument;

public class UpdateLocationService {
	
	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private JDBCTempleteUtil jdbcTempleteUtil;
	private SetObjectAttributeHelper setObjectAttributeHelper;
	private ARMUpdateLocationToCim armUpdateLocationToCim;
	private DeleteLocationFromSubscriber deleteLocationFromSubscriber;
	private AddLocationToSubscriber addLocationToSubscriber;
	
	public UpdateLocationResponseDocument UpdateLocation(UpdateLocationRequestDocument updateLocationReq) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Updating Location started");
		}
		
		final String locationType = updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressType();
		String locationId = updateLocationReq.getUpdateLocationRequest().getAddressDetails().getObjectID();
		String locationName = updateLocationReq.getUpdateLocationRequest().getAddressDetails().getCommonName();
		
		List<String> subscriberNames = new ArrayList<String>();
		if(updateLocationReq.getUpdateLocationRequest().getAddressDetails().getInvolvedPartyList() != null &&
				updateLocationReq.getUpdateLocationRequest().getAddressDetails().getInvolvedPartyList().size() > 0)
		{
			//Party party = updateLocationReq.getUpdateLocationRequest().getAddressDetails().getInvolvedPartyList().get(0);
			for (Party party:updateLocationReq.getUpdateLocationRequest().getAddressDetails().getInvolvedPartyList())
			{
				if(party != null && party.getHasCustomerRoleList() != null && party.getHasCustomerRoleList().size() > 0)
				{
					List<Customer> hasCustomerRoleList = party.getHasCustomerRoleList();
					for (Customer customer : hasCustomerRoleList) {
						/*
						if(!StringHelper.isEmpty(customer.getCommonName())){
							LOG.debug("Adding Subscriber : " + customer.getCommonName());
							subscriberNames.add(customer.getCommonName());
						} else */
						if (!StringHelper.isEmpty(customer.getACNA())) {
							LOG.debug("Adding Subscriber : " + customer.getACNA());
							subscriberNames.add(customer.getACNA());
						} else if (!StringHelper.isEmpty(customer.getID())) {
							LOG.debug("Adding Subscriber : " + customer.getID());
							subscriberNames.add(customer.getID());
						}
					}
				}
			}
		}
		
		if(StringHelper.isEmpty(locationId) && StringHelper.isEmpty(locationName))
		{
			throw new ICLException("ICLRequestValidationError", "Please enter LocationId or Commonname", "1948");
		}
		
		//if LocationID is empty then look it up by name
		if(StringHelper.isEmpty(locationId))
		{
			locationId = getLocationID(locationName);
		}
		
		//if LocationName is empty then look it up by ID
		if(StringHelper.isEmpty(locationName))
		{
			locationName = getLocationName(locationId);
		}
		
		//TODO:Mickey -- This could be redundant if either of the other two calls above were done so need to only do this if both values were passed in
		//also, if they are both passed, what do we do if they don't match?
		String locName = getLocationName(locationId);
		if(locName==null)
		{
			throw new ICLException("ICLRequestValidationError", "Location Does not exist", "1948");
		}
		
		String locationtypeid=getlocationtypeid(locationName);
		
		/*
		
		HashMap<String, Object> attributesList = getLocationattributeslist(updateLocationReq, locationId, locationName,locationtypeid);
		Map <String, Object>  map = setObjectAttributeHelper.execute("Location", new BigDecimal(locationId), attributesList);
		
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armUpdateLocationToCim.transformErrorToCim(updateLocationReq, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		*/

		//update subscriber to location.. For this, first delete the association and create again ...TODO : compare the name and delete only those which are updated
		
		//Delete subscribers 
		Map <String, Object> map = null;
		BigDecimal o_ErrorCode = null;
		
		LOG.debug("Deleting Associations");
		List<Integer> subscribersToBeDeleted = getSubscriberToBeDeletedIds(locationId);
		for (Integer subscriberId : subscribersToBeDeleted) {
			
			LOG.debug("Deleting Association for : " + locationId + " - " + subscriberId);
			
			map = deleteLocationFromSubscriber.execute(BigDecimal.valueOf(subscriberId),locationId);
			o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
			if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
			{
				final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
				if (LOG.isInfoEnabled())
				{
					LOG.info(o_Errormsg);
				}
				return armUpdateLocationToCim.transformErrorToCim(updateLocationReq, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
			}
		}
		
		//Add subscriber
		LOG.debug("Adding Associations ");
		if (subscriberNames != null && subscriberNames.size() > 0)
		{
			LOG.debug("Adding Associations " + subscriberNames.size());
			List<Integer> subscribers = getSubscriberIds(subscriberNames);
			
			for (Integer subscriberId : subscribers) {
				
				LOG.debug("Adding Association for : " + locationId + " - " + subscriberId);
				if( subscriberId != 0 && !Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
				{
					map = addLocationToSubscriber.execute(BigDecimal.valueOf(subscriberId),locationId);
					o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
				}
				if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
				{
					final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
					if (LOG.isInfoEnabled())
					{
						LOG.info(o_Errormsg);
					}
					return armUpdateLocationToCim.transformErrorToCim(updateLocationReq, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
				}
			}
		}
		
		
		
		return armUpdateLocationToCim.transformToCim(updateLocationReq, locationName,locationId,locationType);
		
	}

	private List<Integer> getSubscriberIds(List<String> subscriberNames) throws Exception
	{
		return jdbcTempleteUtil.getSubscriberIdMultiple(buildSubscriberNameToSubscriberId(subscriberNames),Constants.SUBSCIBER_ID);
	}
	
	private String buildSubscriberNameToSubscriberId(List<String> subscriberNames)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addField(Constants.SUBSCIBER_ID);
		sqlBuilder.in(Constants.SUBSCRIBER,Constants.NAME, subscriberNames);
		String query = sqlBuilder.getStatement();
		LOG.info(query);
		return query;
	}
	
	private List<Integer> getSubscriberToBeDeletedIds(String locationId) throws Exception
	{
		return jdbcTempleteUtil.getSubscriberIdMultiple(buildSubscriberIdToBeDeleted(locationId),"SUBSCRIBERLOCATION2SUBSCRIBER");
	}
	
	private String buildSubscriberIdToBeDeleted(String locationId)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBERLOCATION);
		sqlBuilder.addField("SUBSCRIBERLOCATION2SUBSCRIBER");
		sqlBuilder.eq(Constants.SUBSCRIBERLOCATION,"subscriberlocation2location",locationId);
		String query = sqlBuilder.getStatement();
		LOG.info(query);
		return query;
	}
	
	private String getlocationtypeid(String locationName) {
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addTable(Constants.LOCATIONTYPE);
		//sqlBuilder.addFieldFromTable(Constants.LOCATION, Constants.LOCATION_2_LOCATION_TYPE);
		sqlBuilder.addFieldFromTable(Constants.LOCATION_TYPE, Constants.NAME);
		sqlBuilder.eq(Constants.LOCATION, Constants.LOCATION_2_LOCATION_TYPE, Constants.LOCATION_TYPE, Constants.LOCATION_TYPE_ID);
		sqlBuilder.eq(Constants.LOCATION, Constants.NAME, locationName);
		final String locTypeiId = jdbcTempleteUtil.getLocationTypeId(sqlBuilder.getStatement());
		return locTypeiId;
		// TODO Auto-generated method stub
	}

	private String getLocationName(String locationId) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addFieldFromTable(Constants.LOCATION, Constants.NAME);
		sqlBuilder.eq(Constants.LOCATION, Constants.LOCATION_ID, locationId);
		

		final String name = jdbcTempleteUtil.getLocationName(sqlBuilder.getStatement());
		return name;
	}
	
	private String getLocationID(String locationName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.LOCATION);
		sqlBuilder.addField(Constants.LOCATION_ID, Constants.LOCATION_ID);
		sqlBuilder.eq(Constants.LOCATION, Constants.NAME, locationName);
		
		final int locationId = jdbcTempleteUtil.getDeleteLocationId(sqlBuilder.getStatement());
		return Integer.toString(locationId);
	}
	
	
	private HashMap<String, Object> getLocationattributeslist(UpdateLocationRequestDocument updateLocationReq, String locationid, String locationname,String locationType) throws Exception{
		final HashMap<String, Object> attributeList = new HashMap<String, Object>();
		
		if (Constants.BUILDING_SITE.equalsIgnoreCase(locationType))  // Building site
		{
			attributeList.put(Constants.DESCRIPTION, MediationUtil.getRcv(updateLocationReq, Constants.BUILDING_NAME));
			attributeList.put(Constants.PHONE_SWITCH_CLLI, MediationUtil.getRcv(updateLocationReq, Constants.SWITCH_LOCATION_CLLI));
			attributeList.put(Constants.VCOORDINATE, MediationUtil.getGeographicLocation(updateLocationReq, Constants.VCOORDINATE));
			attributeList.put(Constants.HCOORDINATE, MediationUtil.getGeographicLocation(updateLocationReq, Constants.HCOORDINATE));
			attributeList.put(Constants.PROVINCE, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getStateOrProvince());
			attributeList.put(Constants.LATA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.LATA));
			attributeList.put(Constants.CLLI_CODE, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getCLLI());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NXX));
			attributeList.put(Constants.TOWNCITY, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getLocality());
			attributeList.put(Constants.ZIP, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getPostcode());
			attributeList.put(Constants.ADDRESS1, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressLine1());
		}else if (Constants.CENTRAL_OFFICE.equalsIgnoreCase(locationType)) // central ofc
		{
			attributeList.put(Constants.DESCRIPTION, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		}else if(Constants.REMOTE_SITE.equalsIgnoreCase(locationType)) //remote site
		{
			attributeList.put(Constants.DESCRIPTION, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if (Constants.EQUIPMENT_SITE.equalsIgnoreCase(locationType)) //equipment site
		{	
			attributeList.put(Constants.DESCRIPTION, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if  (Constants.CUSTOMER_SITE.equalsIgnoreCase(locationType))//customer site
		{
			attributeList.put(Constants.DESCRIPTION, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(updateLocationReq, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if  (Constants.CITY.equalsIgnoreCase(locationType))//city
		{
			attributeList.put(Constants.PROVINCE, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getStateOrProvince());
			attributeList.put(Constants.TOWNCITY, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getLocality());
			attributeList.put(Constants.NAME, updateLocationReq.getUpdateLocationRequest().getAddressDetails().getLocality() + ", " + updateLocationReq.getUpdateLocationRequest().getAddressDetails().getStateOrProvince());
		}
		
		return attributeList;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil) {
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeHelper(
			SetObjectAttributeHelper setObjectAttributeHelper) {
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

	public void setArmUpdateLocationToCim(
			ARMUpdateLocationToCim armUpdateLocationToCim) {
		this.armUpdateLocationToCim = armUpdateLocationToCim;
	}

	public void setDeleteLocationFromSubscriber(
			DeleteLocationFromSubscriber deleteLocationFromSubscriber) {
		this.deleteLocationFromSubscriber = deleteLocationFromSubscriber;
	}

	public void setAddLocationToSubscriber(
			AddLocationToSubscriber addLocationToSubscriber) {
		this.addLocationToSubscriber = addLocationToSubscriber;
	}

	
}
