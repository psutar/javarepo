package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;


import com.centurylink.icl.armmediation.valueobjects.objects.Shelftype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class ShelftypeCache implements ValueObjectCache {
	
	private Map<String, Shelftype> cachedObjects = new HashMap<String, Shelftype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Shelftype newShelftype = new Shelftype(key);
			if (newShelftype.isInstanciated())
			{
				cachedObjects.put(key, newShelftype);
				return newShelftype;
			} else {
				return null;
			}
		}
	}

}
