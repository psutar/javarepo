package com.centurylink.icl.armmediation.armaccessobject;

import java.util.List;

public class ARMCircuit extends ARMObject
{

	private String	clliCode;
	private String	commonName;
	private String	description;
	private String	sourceSystem;
	private String	objectID;
	private String	resourceType;
	private String  status;
	private String  relativeName;
	private List<ARMCircuit> relatedCircuits;
	private String nodeName;
	private String bandwidthName;
	private String portName;
	private String portTypeName;
	private String nodeType;
	private String ncCode;
	private String nciCode;
	private String secNciCode;
	private String circuitName;
	private String circuitType;
	private String vlanFunction;
	
	
	
	
	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getClliCode()
	{
		return clliCode;
	}

	public void setClliCode(String clliCode)
	{
		this.clliCode = clliCode;
	}

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public String getObjectID()
	{
		return objectID;
	}

	public void setObjectID(String objectID)
	{
		this.objectID = objectID;
	}

	public String getResourceType()
	{
		return resourceType;
	}

	public void setResourceType(String resourceType)
	{
		this.resourceType = resourceType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getRelativeName()
	{
		return relativeName;
	}

	public void setRelativeName(String relativeName)
	{
		this.relativeName = relativeName;
	}

	public List<ARMCircuit> getRelatedCircuits() {
		return relatedCircuits;
	}

	public void setRelatedCircuits(List<ARMCircuit> relatedCircuits) {
		this.relatedCircuits = relatedCircuits;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getBandwidthName() {
		return bandwidthName;
	}

	public void setBandwidthName(String bandwidthName) {
		this.bandwidthName = bandwidthName;
	}

	public String getPortName() {
		return portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public String getPortTypeName() {
		return portTypeName;
	}

	public void setPortTypeName(String portTypeName) {
		this.portTypeName = portTypeName;
	}

	public String getNcCode() {
		return ncCode;
	}

	public void setNcCode(String ncCode) {
		this.ncCode = ncCode;
	}

	public String getNciCode() {
		return nciCode;
	}

	public void setNciCode(String nciCode) {
		this.nciCode = nciCode;
	}

	public String getSecNciCode() {
		return secNciCode;
	}

	public void setSecNciCode(String secNciCode) {
		this.secNciCode = secNciCode;
	}

	public String getCircuitName() {
		return circuitName;
	}

	public void setCircuitName(String circuitName) {
		this.circuitName = circuitName;
	}

	public String getCircuitType() {
		return circuitType;
	}

	public void setCircuitType(String circuitType) {
		this.circuitType = circuitType;
	}

	public String getVlanFunction() {
		return vlanFunction;
	}

	public void setVlanFunction(String vlanFunction) {
		this.vlanFunction = vlanFunction;
	}

}
