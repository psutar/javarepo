package com.centurylink.icl.armmediation.dataaccess.impl;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.centurylink.icl.armmediation.dataaccess.ExtDeviceTypeDAO;

public class ExtDeviceTypeDAOImpl implements ExtDeviceTypeDAO {

	private JdbcTemplate jdbcTemplate;
	private static final String QUERY_BY_DEVICE_CLLI_CODE = "SELECT COUNT(*) FROM EXT_DEVICE_TYPE  WHERE CLLI = ?";
	
	public ExtDeviceTypeDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public boolean doesClliExists(String deviceClliCode) {
		 
		int deviceCllCount=this.jdbcTemplate.queryForInt(QUERY_BY_DEVICE_CLLI_CODE, new Object[] {deviceClliCode});
		
		return deviceCllCount > 0;
	}

}
