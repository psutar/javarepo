package com.centurylink.icl.armmediation.armaccessobject;



public class LocationBuildingSite {
	private Long locationId;
	private Long lata;
	private String clliCode;
	private Long hCoordinate;
	private int label;
	private int npa;
	private Long vCoordinate;
	private String phoneSwithClli;
	private String creationUser;
	private int isVisible;
	private int rpPlanId;
	private int nxx;
	private String hvp;

	

public Long getLocationId()
{
	return locationId;
}

public void setLocationID(Long locationId)
{
	this.locationId = locationId;
}

public Long getLATA()
{
	return lata;
}

public void setLATA(Long lata)
{
	this.lata = lata;
}


public String getClliCode()
{
	return clliCode;
}

public void setClliCode(String clliCode)
{
	this.clliCode = clliCode;
}

public Long getHCoordinate()
{
	return hCoordinate;
}

public void setHCoordinate(Long hCoordinate)
{
	this.hCoordinate = hCoordinate;
}

public int getLabel()
{
	return label;
}

public void setLabel(int label)
{
	this.label = label;
}
public int getNPA()
{
	return npa;
}

public void setNPA(int npa)
{
	this.npa = npa;
}
public Long getVCoordinate()
{
	return vCoordinate;
}

public void setVCoordinate(Long vCoordinate)
{
	this.vCoordinate = vCoordinate;
}

public String getPhoneSwithClli()
{
	return phoneSwithClli;
}

public void setPhoneSwithClli(String phoneSwithClli)
{
	this.phoneSwithClli = phoneSwithClli;
}

public String getCreationUser()
{
	return creationUser;
}

public void setCreationUser(String creationUser)
{
	this.creationUser = creationUser;
}

public int getIsVisible()
{
	return isVisible;
}

public void setIsVisible(int isVisible)
{
	this.isVisible = isVisible;
}
public int getRPPlanId()
{
	return rpPlanId;
}

public void setRPPlanId(int rpPlanId)
{
	this.rpPlanId = rpPlanId;
}
public int getNXX()
{
	return nxx;
}

public void setNXX(int nxx)
{
	this.nxx = nxx;
}

public String getHVP()
{
	return hvp;
}

public void setHVP(String hvp)
{
	this.hvp = hvp;
}

}