package com.centurylink.icl.armmediation.dataaccess.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.ARMEvent;
import com.centurylink.icl.armmediation.dataaccess.EventsDAO;


public class EventsDAOImpl implements EventsDAO {

	private static final Log LOG = LogFactory.getLog(EventsDAOImpl.class);
	private JdbcTemplate jdbcTemplate;
	
	private static String STATEMENT = "SELECT * FROM ARM_LOGGING.ICL_CLC_SYNC WHERE STATUS = 'N' AND ROWNUM = 1 ORDER BY LASTMODIFIED ASC";
	//private static String DELETE_STATEMENT = "DELETE FROM ARM_LOGGING.ICL_CLC_SYNC WHERE ICL_CLC_SYNC_ID = ?";
	private static String UPDATE_STATEMENT = "UPDATE ARM_LOGGING.ICL_CLC_SYNC SET STATUS = 'C' , HOST = ? WHERE ICL_CLC_SYNC_ID = ?";
	private static final String GET_SERVICETYPE_STATEMENT = "SELECT SERVICETYPE.NAME NAME FROM SERVICETYPE,SERVICE WHERE SERVICE.SERVICE2SERVICETYPE = SERVICETYPE.SERVICETYPEID AND SERVICE.NAME = ?";
	private static final String SERVICE = "SERVICE";
	private static String hostName = "UNKNOWN"; //java.net.InetAddress.getLocalHost().getHostName().toLowerCase();
	
	
	public EventsDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		try 
		{
			hostName = java.net.InetAddress.getLocalHost().getHostName().toLowerCase();
		} catch (Exception e) {
			hostName = "ERRORFETCHING";
		}
	}
	
	@Override
	public ARMEvent getNextEvent() {
		
		ARMEvent event = null;

		try {
			Map<String, Object> recordMap = jdbcTemplate.queryForMap(STATEMENT);
			event = new ARMEvent();
			
			event.setIclClcSyncId((BigDecimal) recordMap.get("ICL_CLC_SYNC_ID"));
			event.setArmDimName((String) recordMap.get("ARMDIMENTITY"));
			event.setObjectAction((String) recordMap.get("ICLACTION"));
			event.setArmObjectId((BigDecimal) recordMap.get("ARM_OBJECT_ID")); 
			event.setCommonName((String) recordMap.get("ARMENTITYNAME"));
			event.setLastModified((Timestamp) recordMap.get("LASTMODIFIED"));
			
		
			//If it's service then set service type "MEF EVC" or "MEF UNI" etc
			if(SERVICE.equalsIgnoreCase(event.getArmDimName()))
			{
				event.setResourceSubtype(getServiceType(event.getCommonName()));
			}
			
			if(recordMap.get("ASSOCARMOBJECTDIMENTITY") != null && recordMap.get("ASSOCARMOBJECTDIMENTITY") instanceof String)
			{
				event.setAssociatedArmDimName((String)recordMap.get("ASSOCARMOBJECTDIMENTITY"));
			}
			if(recordMap.get("ASSOC_ARM_OBJECT_ID") != null && recordMap.get("ASSOC_ARM_OBJECT_ID") instanceof BigDecimal)
			{
				event.setAssociatedArmObjectId((BigDecimal) recordMap.get("ASSOC_ARM_OBJECT_ID"));
			}
			if(recordMap.get("ASSOCENTITYNAME") != null && recordMap.get("ASSOCENTITYNAME") instanceof String)
			{
				event.setAssociatedARMObjectName((String) recordMap.get("ASSOCENTITYNAME"));
			}
			if(SERVICE.equalsIgnoreCase(event.getAssociatedArmDimName()))
			{
				event.setAssociatedServiceType(getServiceType(event.getAssociatedARMObjectName()));
			}
			
			 // Only Service rename is included at this time. This will tell which attribute updated on service.
			/*if(("UPDATE".equalsIgnoreCase(event.getObjectAction()) || "DELETE".equalsIgnoreCase(event.getObjectAction())) 
					&& SERVICE.equalsIgnoreCase(event.getArmDimName()))
			{*/
				event.setUpdatedAttribute((String) recordMap.get("OBJECT_ATTRIBUTE"));
				event.setOldValue((String) recordMap.get("OBJECT_CURR_VAL"));
				event.setNewValue((String) recordMap.get("OBJECT_NEW_VAL"));
			//}

			LOG.debug(event.toString());
			
			
		} catch (EmptyResultDataAccessException erdae) {
			// no data found... so return null... 
		}
		
		return event;
	}

	@Override
	public void deleteEvent(ARMEvent event) {
		
		//jdbcTemplate.update(DELETE_STATEMENT, new Object[] {event.getIclClcSyncId()});
		jdbcTemplate.update(UPDATE_STATEMENT, new Object[] {hostName, event.getIclClcSyncId()});
	}
	

	private String getServiceType(final String commonName)
	{
		return jdbcTemplate.queryForObject(GET_SERVICETYPE_STATEMENT,new Object[]{commonName} ,new RowMapper<String>(){

			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				
				return rs.getString("NAME");
			}
			
		});
		
	}
}
