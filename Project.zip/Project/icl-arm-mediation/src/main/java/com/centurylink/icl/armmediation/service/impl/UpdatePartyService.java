package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.storedprocedures.pkgsubscriber.SetSubscriberDetails;
import com.centurylink.icl.armmediation.transformation.ARMUpdatePartyToCim;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;

import com.iclnbi.iclnbiV200.UpdatePartyRequestDocument;
import com.iclnbi.iclnbiV200.UpdatePartyResponseDocument;

public class UpdatePartyService {
	
	private JDBCTempleteUtil jdbcTempleteUtil;
	private SetObjectAttributeHelper setObjectAttributeHelper;
	private SetSubscriberDetails setSubscriberDetails;
	private ARMUpdatePartyToCim armUpdatePartyToCim;
	private static final Log LOG = LogFactory.getLog(UpdatePartyService.class);
	
	public UpdatePartyResponseDocument updateParty(UpdatePartyRequestDocument updatepartyreq) throws Exception{
	
		//final Integer subscriberId;
		final String subscriberType;
		final Long partyId;
		Map <String, Object>  map = null;
		String subscriberName=updatepartyreq.getUpdatePartyRequest().getPartyDetails().getCommonName();
		String partyType = updatepartyreq.getUpdatePartyRequest().getPartyDetails().getPartyType();
		//String subscriberId = updatepartyreq.getUpdatePartyRequest().getPartyDetails().getPartyId();
		
		if(StringHelper.isEmpty(subscriberName))
		{
			throw new ICLException("ICLRequestValidationError", "Please enter Subscribername", "1948");
		}
		
		int subscriberId  = getSubscriberId(subscriberName);
		
		subscriberType = getSubscriberType(Integer.toString(subscriberId));
		
		if(subscriberType==null) {
			
			throw new ICLException("ICLRequestValidationError", "Subscriber Not Present", "1948");
		}
		
		try
		{
			partyId = getPartyId(partyType);
			
		} catch (IndexOutOfBoundsException exception)
		{
			//final String o_Errormsg = "Could not find Party id against the requested Party Type";
			//return armCreatePartyToCim.transformErrorToCim(requestData, Constants.ERROR_CODE_1948, Constants.ICL_REQUEST_VALIDATION_ERROR, o_Errormsg);
			throw new ICLException("ICLRequestValidationError", "Incorrect party type", "1948");
		}
		
		if (!partyId.toString().equals(subscriberType))
		{
			setSubscriberDetails.execute(subscriberId, subscriberName, partyId);
		}
		
		HashMap<String, Object> attributesList = getPartyattributeslist(updatepartyreq, subscriberName,partyId.toString());
		map = setObjectAttributeHelper.execute("Subscriber", new BigDecimal(subscriberId), attributesList);
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armUpdatePartyToCim.transformErrorToCim(updatepartyreq, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		
		else{
			
			return armUpdatePartyToCim.transformToCim(updatepartyreq, Integer.toString(subscriberId),subscriberName);
		}
		
	}
	
	private HashMap<String, Object> getPartyattributeslist(UpdatePartyRequestDocument updatepartyreq, String subscriberName,String subscriberType) throws Exception {
			
			final HashMap<String, Object> attributeList = new HashMap<String, Object>();
			//For Subscriber table
			attributeList.put(Constants.FULL_NAME, updatepartyreq.getUpdatePartyRequest().getPartyDetails().getDescription() );
			attributeList.put(Constants.SUBTYPE, updatepartyreq.getUpdatePartyRequest().getPartyDetails().getPartySubType());
			attributeList.put(Constants.NOTES, MediationUtil.getNotes(updatepartyreq, Constants.NOTES));
			
			//For EXT_SUBSCRIBER_EXTERNAL OR EXT_SUBSCRIBER_INTERNAL table
			if(subscriberType.equals("1900000001") || subscriberType.equals("1900000000"))
			{
				attributeList.put(Constants.CHANNEL, MediationUtil.rootEntityDescriberBy(updatepartyreq, Constants.CHANNEL));
				attributeList.put(Constants.CATEGORY, MediationUtil.getCategory(updatepartyreq, Constants.CATEGORY));
				attributeList.put(Constants.MCO, MediationUtil.rootEntityDescriberBy(updatepartyreq,Constants.MCO));
				//for EXT_SUBSCRIBER_EXTERNAL table
				if(subscriberType.equals("1900000001"))
				{
					attributeList.put(Constants.ENTERPRISEACCOUNTID, MediationUtil.rootEntityDescriberBy(updatepartyreq, Constants.ENTERPRISE));
					attributeList.put(Constants.LEGACYNETWORK, updatepartyreq.getUpdatePartyRequest().getPartyDetails().getDataOwner());
				}
			}
			
		return attributeList;
	}

	private String getSubscriberType(String subscriberId) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCRIBER2SUBSCRIBERTYPE);
		sqlBuilder.eq(Constants.SUBSCRIBER, Constants.SUBSCIBER_ID, subscriberId);
		

		final String subscriberTypeId = jdbcTempleteUtil.getSubscriber2SubscriberTypeId(sqlBuilder.getStatement());
		return subscriberTypeId;
	}
	
	private long getPartyId(String partyType) {

		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBERTYPE);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBERTYPE,
				Constants.SUBSCRIBERTYPEID);
		sqlBuilder.eq(Constants.SUBSCRIBERTYPE, Constants.NAME, partyType);

		final int subscriberTypeId = jdbcTempleteUtil.getSubscriberTypeId(sqlBuilder.getStatement());
				//.getSubscriberTypeId(sqlBuilder.getStatement());
		return subscriberTypeId;
	}
	
	private int getSubscriberId(String subscriberName) throws Exception
	{
		return jdbcTempleteUtil.getSubscriberId(buildSubscriberNameToSubscriberId(subscriberName));
	}
	
	private String buildSubscriberNameToSubscriberId(String subscriberName)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addField(Constants.SUBSCIBER_ID);
		sqlBuilder.eq(Constants.NAME, subscriberName);
		String query = sqlBuilder.getStatement();
		LOG.info(query);
		return query;
	}
	
	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil) {
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeHelper(
			SetObjectAttributeHelper setObjectAttributeHelper) {
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

	public void setArmUpdatePartyToCim(ARMUpdatePartyToCim armUpdatePartyToCim) {
		this.armUpdatePartyToCim = armUpdatePartyToCim;
	}
	
	public void setSetSubscriberDetails(SetSubscriberDetails setSubscriberDetails)
	{
		this.setSubscriberDetails = setSubscriberDetails;
	}

}
