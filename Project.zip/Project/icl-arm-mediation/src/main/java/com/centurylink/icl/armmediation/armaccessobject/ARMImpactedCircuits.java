package com.centurylink.icl.armmediation.armaccessobject;

public class ARMImpactedCircuits extends ARMObject
{
	// Location
	private String ckt2StartLoc;
	private String startLocationId;
	private String startLocationName;
	private String startLocAddressLine1;
	private String startLocAddressLine3;
	private String startLocAddressLine2;
	private String startLocAddressType;
	private String startLoclocality;
	private String startLocprovince;
	private String startpostcode;
	private String ckt2EndLoc;
	private String endLocationId;
	private String endLocAddressLine1;
	private String endLocAddressLine3;
	private String endLocAddressLine2;
	private String endLocAddressType;
	private String endLoclocality;
	private String endLocprovince;
	private String endpostcode;
	private String endLocationName;
	private String locationClli;
	
	//Device
	private String nodeID;
	private String ckt2StartNode;
	private String startDeviceName;
	private String startDeviceFullName;
	private String startDeviceObjectId;
	private String startDeviceClli;
	private String startDeviceEmsName;
	private String startDeviceIpAddress4;
	private String startDeviceIpAddress6;
	private String startDevicePrStatus;
	private String ckt2EndNode;
	private String endDeviceName;
	private String endDeviceFullName;
	private String endDeviceObjectId;
	private String endDeviceEmsName;
	private String endDeviceIpAddress4;
	private String endDeviceIpAddress6;
	private String endDeviceClli;
	private String endDevicePrStatus;
	private String devicePrStatus;
	private String deviceResourceSubType;
	private String deviceResourceType;
	// Circuit
	private String commonName;
	private String sourceSystem;
	private String objectID;
	private String cktId;
	private String cktfullName;
	private String resourceType;
	private String cktFuncStatus;
	private String cktProvStatus;
	private String cktServiceType;
	private String isLagMember;
	private String relatedCktID;
	// Service
	private String serviceName;
	private String serviceID;
	private String serviceTypeName;
	private String ban;
	private String serviceFuncStatus;
	private String serviceProvStatus;
	private String uniHpc;
	private String enniHpc;
	private String evcHpc;
	private String ovcHpc;
	private String uniHpcExpDate;
	private String enniHpcExpDate;
	private String evcHpcExpDate;
	private String ovcHpcExpDate;
	//Subscriber
	private String subscriberName;
	private String subsciberfullname;
	private String subscriberId;
	private String emsHostName;
	
	private String sequence;
	private String startDevicerole;
	private String endDevicerole;
	private String ttServiceTypeCircuit;
	private String ttServiceTypeService;
	
	public String getEmsHostName() {
		return emsHostName;
	}
	public void setEmsHostName(String emsHostName) {
		this.emsHostName = emsHostName;
	}
	public String getCkt2StartLoc()
	{
		return ckt2StartLoc;
	}
	public void setCkt2StartLoc(String ckt2StartLoc)
	{
		this.ckt2StartLoc = ckt2StartLoc;
	}
	public String getStartLocationId()
	{
		return startLocationId;
	}
	public void setStartLocationId(String startLocationId)
	{
		this.startLocationId = startLocationId;
	}
	public String getStartLocationName()
	{
		return startLocationName;
	}
	public void setStartLocationName(String startLocationName)
	{
		this.startLocationName = startLocationName;
	}
	public String getStartLocAddressLine1()
	{
		return startLocAddressLine1;
	}
	public void setStartLocAddressLine1(String startLocAddressLine1)
	{
		this.startLocAddressLine1 = startLocAddressLine1;
	}
	public String getStartLocAddressLine3()
	{
		return startLocAddressLine3;
	}
	public void setStartLocAddressLine3(String startLocAddressLine3)
	{
		this.startLocAddressLine3 = startLocAddressLine3;
	}
	public String getStartLocAddressLine2()
	{
		return startLocAddressLine2;
	}
	public void setStartLocAddressLine2(String startLocAddressLine2)
	{
		this.startLocAddressLine2 = startLocAddressLine2;
	}
	public String getStartLocAddressType()
	{
		return startLocAddressType;
	}
	public void setStartLocAddressType(String startLocAddressType)
	{
		this.startLocAddressType = startLocAddressType;
	}
	public String getStartLoclocality()
	{
		return startLoclocality;
	}
	public void setStartLoclocality(String startLoclocality)
	{
		this.startLoclocality = startLoclocality;
	}
	public String getStartLocprovince()
	{
		return startLocprovince;
	}
	public void setStartLocprovince(String startLocprovince)
	{
		this.startLocprovince = startLocprovince;
	}
	public String getStartpostcode()
	{
		return startpostcode;
	}
	public void setStartpostcode(String startpostcode)
	{
		this.startpostcode = startpostcode;
	}
	public String getCkt2EndLoc()
	{
		return ckt2EndLoc;
	}
	public void setCkt2EndLoc(String ckt2EndLoc)
	{
		this.ckt2EndLoc = ckt2EndLoc;
	}
	public String getEndLocationId()
	{
		return endLocationId;
	}
	public void setEndLocationId(String endLocationId)
	{
		this.endLocationId = endLocationId;
	}
	public String getEndLocAddressLine1()
	{
		return endLocAddressLine1;
	}
	public void setEndLocAddressLine1(String endLocAddressLine1)
	{
		this.endLocAddressLine1 = endLocAddressLine1;
	}
	public String getEndLocAddressLine3()
	{
		return endLocAddressLine3;
	}
	public void setEndLocAddressLine3(String endLocAddressLine3)
	{
		this.endLocAddressLine3 = endLocAddressLine3;
	}
	public String getEndLocAddressLine2()
	{
		return endLocAddressLine2;
	}
	public void setEndLocAddressLine2(String endLocAddressLine2)
	{
		this.endLocAddressLine2 = endLocAddressLine2;
	}
	public String getEndLocAddressType()
	{
		return endLocAddressType;
	}
	public void setEndLocAddressType(String endLocAddressType)
	{
		this.endLocAddressType = endLocAddressType;
	}
	public String getEndLoclocality()
	{
		return endLoclocality;
	}
	public void setEndLoclocality(String endLoclocality)
	{
		this.endLoclocality = endLoclocality;
	}
	public String getEndLocprovince()
	{
		return endLocprovince;
	}
	public void setEndLocprovince(String endLocprovince)
	{
		this.endLocprovince = endLocprovince;
	}
	public String getEndpostcode()
	{
		return endpostcode;
	}
	public void setEndpostcode(String endpostcode)
	{
		this.endpostcode = endpostcode;
	}
	public String getEndLocationName()
	{
		return endLocationName;
	}
	public void setEndLocationName(String endLocationName)
	{
		this.endLocationName = endLocationName;
	}
	public String getNodeID()
	{
		return nodeID;
	}
	public void setNodeID(String nodeID)
	{
		this.nodeID = nodeID;
	}
	public String getCkt2StartNode()
	{
		return ckt2StartNode;
	}
	public void setCkt2StartNode(String ckt2StartNode)
	{
		this.ckt2StartNode = ckt2StartNode;
	}
	public String getStartDeviceName()
	{
		return startDeviceName;
	}
	public void setStartDeviceName(String startDeviceName)
	{
		this.startDeviceName = startDeviceName;
	}
	public String getStartDeviceFullName()
	{
		return startDeviceFullName;
	}
	public void setStartDeviceFullName(String startDeviceFullName)
	{
		this.startDeviceFullName = startDeviceFullName;
	}
	public String getStartDeviceObjectId()
	{
		return startDeviceObjectId;
	}
	public void setStartDeviceObjectId(String startDeviceObjectId)
	{
		this.startDeviceObjectId = startDeviceObjectId;
	}
	public String getStartDeviceClli()
	{
		return startDeviceClli;
	}
	public void setStartDeviceClli(String startDeviceClli)
	{
		this.startDeviceClli = startDeviceClli;
	}
	public String getStartDeviceEmsName()
	{
		return startDeviceEmsName;
	}
	public void setStartDeviceEmsName(String startDeviceEmsName)
	{
		this.startDeviceEmsName = startDeviceEmsName;
	}
	public String getStartDeviceIpAddress4()
	{
		return startDeviceIpAddress4;
	}
	public void setStartDeviceIpAddress4(String startDeviceIpAddress4)
	{
		this.startDeviceIpAddress4 = startDeviceIpAddress4;
	}
	public String getStartDeviceIpAddress6()
	{
		return startDeviceIpAddress6;
	}
	public void setStartDeviceIpAddress6(String startDeviceIpAddress6)
	{
		this.startDeviceIpAddress6 = startDeviceIpAddress6;
	}
	public String getCkt2EndNode()
	{
		return ckt2EndNode;
	}
	public void setCkt2EndNode(String ckt2EndNode)
	{
		this.ckt2EndNode = ckt2EndNode;
	}
	public String getEndDeviceName()
	{
		return endDeviceName;
	}
	public void setEndDeviceName(String endDeviceName)
	{
		this.endDeviceName = endDeviceName;
	}
	public String getEndDeviceFullName()
	{
		return endDeviceFullName;
	}
	public void setEndDeviceFullName(String endDeviceFullName)
	{
		this.endDeviceFullName = endDeviceFullName;
	}
	public String getEndDeviceObjectId()
	{
		return endDeviceObjectId;
	}
	public void setEndDeviceObjectId(String endDeviceObjectId)
	{
		this.endDeviceObjectId = endDeviceObjectId;
	}
	public String getEndDeviceEmsName()
	{
		return endDeviceEmsName;
	}
	public void setEndDeviceEmsName(String endDeviceEmsName)
	{
		this.endDeviceEmsName = endDeviceEmsName;
	}
	public String getEndDeviceIpAddress4()
	{
		return endDeviceIpAddress4;
	}
	public void setEndDeviceIpAddress4(String endDeviceIpAddress4)
	{
		this.endDeviceIpAddress4 = endDeviceIpAddress4;
	}
	public String getEndDeviceIpAddress6()
	{
		return endDeviceIpAddress6;
	}
	public void setEndDeviceIpAddress6(String endDeviceIpAddress6)
	{
		this.endDeviceIpAddress6 = endDeviceIpAddress6;
	}
	public String getEndDeviceClli()
	{
		return endDeviceClli;
	}
	public void setEndDeviceClli(String endDeviceClli)
	{
		this.endDeviceClli = endDeviceClli;
	}
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	public String getSourceSystem()
	{
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}
	public String getObjectID()
	{
		return objectID;
	}
	public void setObjectID(String objectID)
	{
		this.objectID = objectID;
	}
	public String getCktId()
	{
		return cktId;
	}
	public void setCktId(String cktId)
	{
		this.cktId = cktId;
	}
	public String getCktfullName()
	{
		return cktfullName;
	}
	public void setCktfullName(String cktfullName)
	{
		this.cktfullName = cktfullName;
	}
	public String getResourceType()
	{
		return resourceType;
	}
	public void setResourceType(String resourceType)
	{
		this.resourceType = resourceType;
	}
	public String getCktFuncStatus()
	{
		return cktFuncStatus;
	}
	public void setCktFuncStatus(String cktFuncStatus)
	{
		this.cktFuncStatus = cktFuncStatus;
	}
	public String getCktProvStatus()
	{
		return cktProvStatus;
	}
	public void setCktProvStatus(String cktProvStatus)
	{
		this.cktProvStatus = cktProvStatus;
	}
	public String getServiceName()
	{
		return serviceName;
	}
	public void setServiceName(String serviceName)
	{
		this.serviceName = serviceName;
	}
	public String getServiceID()
	{
		return serviceID;
	}
	public void setServiceID(String serviceID)
	{
		this.serviceID = serviceID;
	}
	public String getServiceTypeName()
	{
		return serviceTypeName;
	}
	public void setServiceTypeName(String serviceTypeName)
	{
		this.serviceTypeName = serviceTypeName;
	}
	public String getBan()
	{
		return ban;
	}
	public void setBan(String ban)
	{
		this.ban = ban;
	}
	public String getServiceFuncStatus()
	{
		return serviceFuncStatus;
	}
	public void setServiceFuncStatus(String serviceFuncStatus)
	{
		this.serviceFuncStatus = serviceFuncStatus;
	}
	public String getServiceProvStatus()
	{
		return serviceProvStatus;
	}
	public void setServiceProvStatus(String serviceProvStatus)
	{
		this.serviceProvStatus = serviceProvStatus;
	}
	public String getUniHpc()
	{
		return uniHpc;
	}
	public void setUniHpc(String uniHpc)
	{
		this.uniHpc = uniHpc;
	}
	public String getEnniHpc()
	{
		return enniHpc;
	}
	public void setEnniHpc(String enniHpc)
	{
		this.enniHpc = enniHpc;
	}
	public String getEvcHpc()
	{
		return evcHpc;
	}
	public void setEvcHpc(String evcHpc)
	{
		this.evcHpc = evcHpc;
	}
	public String getOvcHpc()
	{
		return ovcHpc;
	}
	public void setOvcHpc(String ovcHpc)
	{
		this.ovcHpc = ovcHpc;
	}
	public String getUniHpcExpDate()
	{
		return uniHpcExpDate;
	}
	public void setUniHpcExpDate(String uniHpcExpDate)
	{
		this.uniHpcExpDate = uniHpcExpDate;
	}
	public String getEnniHpcExpDate()
	{
		return enniHpcExpDate;
	}
	public void setEnniHpcExpDate(String enniHpcExpDate)
	{
		this.enniHpcExpDate = enniHpcExpDate;
	}
	public String getEvcHpcExpDate()
	{
		return evcHpcExpDate;
	}
	public void setEvcHpcExpDate(String evcHpcExpDate)
	{
		this.evcHpcExpDate = evcHpcExpDate;
	}
	public String getOvcHpcExpDate()
	{
		return ovcHpcExpDate;
	}
	public void setOvcHpcExpDate(String ovcHpcExpDate)
	{
		this.ovcHpcExpDate = ovcHpcExpDate;
	}
	public String getSubscriberName()
	{
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName)
	{
		this.subscriberName = subscriberName;
	}
	public String getSubsciberfullname()
	{
		return subsciberfullname;
	}
	public void setSubsciberfullname(String subsciberfullname)
	{
		this.subsciberfullname = subsciberfullname;
	}
	public String getSubscriberId()
	{
		return subscriberId;
	}
	public void setSubscriberId(String subscriberId)
	{
		this.subscriberId = subscriberId;
	}
	public String getDevicePrStatus() {
		return devicePrStatus;
	}
	public void setDevicePrStatus(String devicePrStatus) {
		this.devicePrStatus = devicePrStatus;
	}
	public String getLocationClli() {
		return locationClli;
	}
	public void setLocationClli(String locationClli) {
		this.locationClli = locationClli;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getCktServiceType() {
		return cktServiceType;
	}
	public void setCktServiceType(String cktServiceType) {
		this.cktServiceType = cktServiceType;
	}
	public String getDeviceResourceSubType() {
		return deviceResourceSubType;
	}
	public void setDeviceResourceSubType(String deviceResourceSubType) {
		this.deviceResourceSubType = deviceResourceSubType;
	}
	public String getDeviceResourceType() {
		return deviceResourceType;
	}
	public void setDeviceResourceType(String deviceResourceType) {
		this.deviceResourceType = deviceResourceType;
	}
	public String getStartDevicerole() {
		return startDevicerole;
	}
	public void setStartDevicerole(String startDevicerole) {
		this.startDevicerole = startDevicerole;
	}
	public String getEndDevicerole() {
		return endDevicerole;
	}
	public void setEndDevicerole(String endDevicerole) {
		this.endDevicerole = endDevicerole;
	}
	public String getIsLagMember() {
		return isLagMember;
	}
	public void setIsLagMember(String isLagMember) {
		this.isLagMember = isLagMember;
	}
	public String getRelatedCktID() {
		return relatedCktID;
	}
	public void setRelatedCktID(String relatedCktID) {
		this.relatedCktID = relatedCktID;
	}
	public String getTtServiceTypeCircuit() {
		return ttServiceTypeCircuit;
	}
	public void setTtServiceTypeCircuit(String ttServiceTypeCircuit) {
		this.ttServiceTypeCircuit = ttServiceTypeCircuit;
	}
	public String getTtServiceTypeService() {
		return ttServiceTypeService;
	}
	public void setTtServiceTypeService(String ttServiceTypeService) {
		this.ttServiceTypeService = ttServiceTypeService;
	}
	public String getStartDevicePrStatus() {
		return startDevicePrStatus;
	}
	public void setStartDevicePrStatus(String startDevicePrStatus) {
		this.startDevicePrStatus = startDevicePrStatus;
	}
	public String getEndDevicePrStatus() {
		return endDevicePrStatus;
	}
	public void setEndDevicePrStatus(String endDevicePrStatus) {
		this.endDevicePrStatus = endDevicePrStatus;
	}
	
}
