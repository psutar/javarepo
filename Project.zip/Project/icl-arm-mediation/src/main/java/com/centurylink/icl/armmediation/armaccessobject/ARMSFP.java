package com.centurylink.icl.armmediation.armaccessobject;

public class ARMSFP
{
	private String	sfpName;

	public String getSfpName()
	{
		return sfpName;
	}

	public void setSfpName(String sfpName)
	{
		this.sfpName = sfpName;
	}

}
