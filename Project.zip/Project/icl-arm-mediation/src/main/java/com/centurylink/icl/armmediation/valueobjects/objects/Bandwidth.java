package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Bandwidth extends AbstractReadOnlyTable{

	private static String BANDWIDTHID = "BANDWIDTHID";
	private static String NAME = "NAME";
	private static String KBPSVALUE="KBPSVALUE";
	

	public Bandwidth()
	{
		super();
		this.tableName = "BANDWIDTH";
	}
	
	public Bandwidth(String bandwidthId)
	{
		this();
		primaryKey.setValue(bandwidthId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		fields.put(BANDWIDTHID, new Field(BANDWIDTHID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(KBPSVALUE, new Field(KBPSVALUE, Field.TYPE_NUMERIC));
		

		primaryKey = new PrimaryKey(fields.get(BANDWIDTHID));
	}


	public String getBandwidthid() {
		return getFieldAsString(BANDWIDTHID);
	}


	public void setBandwidthid(String bandwidthid) {
		setField(BANDWIDTHID,bandwidthid);
	}


	public String getName() {
		return getFieldAsString(NAME);
	}


	public void setName(String name) {
		setField(NAME,name);
	}
	
	public String getKbpsValue() {
		return getFieldAsString(KBPSVALUE);
	}

	public void setKbpsValue(String kBPSVALUE) {
		setField(KBPSVALUE,kBPSVALUE);
	}

}
