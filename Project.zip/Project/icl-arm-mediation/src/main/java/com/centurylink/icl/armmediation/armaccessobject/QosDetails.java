package com.centurylink.icl.armmediation.armaccessobject;

public class QosDetails extends ARMObject 
{

	private String parameterDefinition;
	private String parameterClass;
	private String parameterDecimalValue;
	private String parameterStringValue;
	private String parameterDateValue;
	private String parameterObject;
	private String parameterDimObject;
	private String parameterIntegerValueForCIR;
	private String parameterIntegerValueForEIR;
	private String parameterIntegerValueForBW;
	private String parameterIntegerValueForCOS;
	private String parameterIntegerValueForCOSID;
	private String parameterStringValueForLOSName;
	private String parameterName;
	
	public String getParameterStringValueForLOSName() {
		return parameterStringValueForLOSName;
	}
	public void setParameterStringValueForLOSName(
			String parameterStringValueForLOSName) {
		this.parameterStringValueForLOSName = parameterStringValueForLOSName;
	}
	public String getParameterIntegerValueForCIR() {
		return parameterIntegerValueForCIR;
	}
	public void setParameterIntegerValueForCIR(String parameterIntegerValueForCIR) {
		this.parameterIntegerValueForCIR = parameterIntegerValueForCIR;
	}
	public String getParameterIntegerValueForEIR() {
		return parameterIntegerValueForEIR;
	}
	public void setParameterIntegerValueForEIR(String parameterIntegerValueForEIR) {
		this.parameterIntegerValueForEIR = parameterIntegerValueForEIR;
	}
	public String getParameterIntegerValueForBW() {
		return parameterIntegerValueForBW;
	}
	public void setParameterIntegerValueForBW(String parameterIntegerValueForBW) {
		this.parameterIntegerValueForBW = parameterIntegerValueForBW;
	}
	public String getParameterIntegerValueForCOS() {
		return parameterIntegerValueForCOS;
	}
	public void setParameterIntegerValueForCOS(String parameterIntegerValueForCOS) {
		this.parameterIntegerValueForCOS = parameterIntegerValueForCOS;
	}
	
	public String getParameterDefinition() {
		return parameterDefinition;
	}
	public void setParameterDefinition(String parameterDefinition) {
		this.parameterDefinition = parameterDefinition;
	}
	public String getParameterClass() {
		return parameterClass;
	}
	public void setParameterClass(String parameterClass) {
		this.parameterClass = parameterClass;
	}
	
	public String getParameterDecimalValue() {
		return parameterDecimalValue;
	}
	public void setParameterDecimalValue(String parameterDecimalValue) {
		this.parameterDecimalValue = parameterDecimalValue;
	}
	public String getParameterStringValue() {
		return parameterStringValue;
	}
	public void setParameterStringValue(String parameterStringValue) {
		this.parameterStringValue = parameterStringValue;
	}
	public String getParameterDateValue() {
		return parameterDateValue;
	}
	public void setParameterDateValue(String parameterDateValue) {
		this.parameterDateValue = parameterDateValue;
	}
	public String getParameterObject() {
		return parameterObject;
	}
	public void setParameterObject(String parameterObject) {
		this.parameterObject = parameterObject;
	}
	public String getParameterDimObject() {
		return parameterDimObject;
	}
	public void setParameterDimObject(String parameterDimObject) {
		this.parameterDimObject = parameterDimObject;
	}
	public String getParameterIntegerValueForCOSID() {
		return parameterIntegerValueForCOSID;
	}
	public void setParameterIntegerValueForCOSID(
			String parameterIntegerValueForCOSID) {
		this.parameterIntegerValueForCOSID = parameterIntegerValueForCOSID;
	}
	public String getParameterName() {
		return parameterName;
	}
	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}
}
