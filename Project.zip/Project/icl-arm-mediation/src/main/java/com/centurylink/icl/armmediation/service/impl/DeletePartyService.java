package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.transformation.ARMDeletePartyToCim;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.DeletePartyRequestDocument;
import com.iclnbi.iclnbiV200.DeletePartyResponseDocument;

public class DeletePartyService {

	private static final Log LOG = LogFactory.getLog(DeletePartyService.class);
	private ARMDeletePartyToCim armDeletePartyToCim;
	private JDBCTempleteUtil jdbcTempleteUtil;
	private SetObjectAttributeHelper setObjectAttributeHelper;
	
	
	public void setArmDeletePartyToCim(ARMDeletePartyToCim armDeletePartyToCim) {
		this.armDeletePartyToCim = armDeletePartyToCim;
	}

	public DeletePartyResponseDocument deleteParty(DeletePartyRequestDocument deletePartyRequest) throws Exception
	{
		
		final Integer subscriberId;
		String subscriberName = deletePartyRequest.getDeletePartyRequest().getPartyDetails().getCommonName();
		LOG.info("Starting Delete Subscriber");
		if(subscriberName.isEmpty())
		{
			throw new ICLException("ICLRequestValidationError", "Please enter SubscriberName", "1948");
		}
		
		subscriberId = getSubscriberId(subscriberName);
		
		if(subscriberId.equals(0)) {
			
			throw new ICLException("ICLRequestValidationError", "Please enter a valid subscriber", "1948");
		}
		
				
		String markForDeleteValue=getMarkForDelete(subscriberName);
		
		if(markForDeleteValue!=null){
			
			throw new ICLException("ICLRequestValidationError", "Subscriber already Deleted", "1948");
		}		
		
		HashMap<String, Object> attributeList = getSubscriberattributeslist();
		
		Map <String, Object> map = setObjectAttributeHelper.execute("Subscriber", new BigDecimal(subscriberId), attributeList);
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armDeletePartyToCim.transformErrorToCim(deletePartyRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		
		else{
			
			return armDeletePartyToCim.transformToCim(deletePartyRequest,String.valueOf(subscriberId), subscriberName);
		}
		
	}
	
	private HashMap<String, Object> getSubscriberattributeslist() {
		// TODO Auto-generated method stub
		
		final HashMap<String, Object> attributeList = new HashMap<String, Object>();
		attributeList.put(Constants.MARKED_FOR_DELETE, new BigDecimal(1));
		
		return attributeList;
	}
	
	private String	getMarkForDelete(String subscriberName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBER,Constants.MARKED_FOR_DELETE);
		sqlBuilder.eq(Constants.SUBSCRIBER, Constants.NAME, subscriberName);
		

		final String markForDelete = jdbcTempleteUtil.getMarkedForDelete(sqlBuilder.getStatement());
		
		return markForDelete;
	}
	
	private int	getSubscriberId(String subscriberName) throws Exception{
		
		final SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addFieldFromTable(Constants.SUBSCRIBER, Constants.SUBSCRIBER_ID);
		sqlBuilder.eq(Constants.SUBSCRIBER, Constants.NAME, subscriberName);
		

		final int subscriberId = jdbcTempleteUtil.getSubscriberId(sqlBuilder.getStatement());
		return subscriberId;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil) {
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setSetObjectAttributeHelper(
			SetObjectAttributeHelper setObjectAttributeHelper) {
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

	
}
