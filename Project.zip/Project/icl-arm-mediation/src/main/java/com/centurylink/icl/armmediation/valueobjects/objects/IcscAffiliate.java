package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class IcscAffiliate extends AbstractReadOnlyTable{
	
	private static String ICSC_AFFILIATE_ID = "ICSC_AFFILIATE_ID";
	private static String ICSC_CODE = "ICSC_CODE";
	private static String AFFILIATE_NAME="AFFILIATE_NAME";
	
	public IcscAffiliate()
	{
		super();
		this.tableName = "ICSC_AFFILIATE";
	}
	
	public IcscAffiliate(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		if(getIcscCode() != null)
		{
			this.instanciated = true;
		}
	}
	
	public static List<IcscAffiliate> getIcscAffiliateListByIcsc(String icsc)
	{
		return getIcscAffiliateListByQuery(ICSC_CODE + " = '" + icsc + "'");
	}
	
	public static List<IcscAffiliate> getIcscAffiliateListByQuery(String query)
	{
		IcscAffiliate icscAffiliate = new IcscAffiliate();
		List<IcscAffiliate> icscAffiliateList = new ArrayList<IcscAffiliate>();
		List<Map<String,Object>> foundIcscAffiliateList = icscAffiliate.getRecordsByQuery(query);

		for (Map<String,Object> icscAffiliateMap : foundIcscAffiliateList)
		{
			IcscAffiliate workicscAffiliate = new IcscAffiliate(icscAffiliateMap.get(ICSC_AFFILIATE_ID).toString());
			icscAffiliateList.add(workicscAffiliate);
		}
		return icscAffiliateList;
	}
	
	@Override
	public void populateModel() {
		fields.put(ICSC_AFFILIATE_ID, new Field(ICSC_AFFILIATE_ID, Field.TYPE_NUMERIC));
		fields.put(ICSC_CODE, new Field(ICSC_CODE, Field.TYPE_VARCHAR));
		fields.put(AFFILIATE_NAME, new Field(AFFILIATE_NAME, Field.TYPE_VARCHAR));
		
		primaryKey = new PrimaryKey(fields.get(ICSC_AFFILIATE_ID));
	}
	
	public String getIcscAffiliateId() {
		return getFieldAsString(ICSC_AFFILIATE_ID);
	}
	
	public void setIcscAffiliateId(String icscAffiliateId) {
		setField(ICSC_AFFILIATE_ID,icscAffiliateId);
	}
	
	public String getIcscCode() {
		return getFieldAsString(ICSC_CODE);
	}
	
	public void setIcscCode(String icscCode) {
		setField(ICSC_CODE,icscCode);
	}
	
	public String getAffiliateName() {
		return getFieldAsString(AFFILIATE_NAME);
	}
	
	public void setAffiliateName(String affiliateName) {
		setField(AFFILIATE_NAME,affiliateName);
	}
}
