package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.ComplexLinkedTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.LinkedTable;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Node extends AbstractReadOnlyTable {

	private static final long serialVersionUID = 1L;

	private static final Log LOG = LogFactory.getLog(Node.class);


	private static final String NODE2ASSETSTATUS = "NODE2ASSETSTATUS";
	private static final String OPERATIONALSTATUS = "OPERATIONALSTATUS";
	private static final String ADMINSTRATIVESTATUS = "ADMINSTRATIVESTATUS";
	private static final String ORIGINALCOST = "ORIGINALCOST";
	private static final String COSTCURRENCY = "COSTCURRENCY";
	private static final String POLLCOUNTER = "POLLCOUNTER";
	private static final String DIAGCOUNTER = "DIAGCOUNTER";
	private static final String NODE2TECHNICIAN = "NODE2TECHNICIAN";
	private static final String NODE2BE = "NODE2BE";
	private static final String SOFTWAREVERSION = "SOFTWAREVERSION";
	private static final String STORAGETOTAL = "STORAGETOTAL";
	private static final String STORAGEFREE = "STORAGEFREE";
	private static final String STORAGERAM = "STORAGERAM";
	private static final String NVSTORAGERAM = "NVSTORAGERAM";
	private static final String LIFETERM = "LIFETERM";
	private static final String LASTVALUE = "LASTVALUE";
	private static final String LASTCHECKED = "LASTCHECKED";
	private static final String NODE2DEVICEGROUP = "NODE2DEVICEGROUP";
	private static final String NODEID = "NODEID";
	private static final String NAME = "NAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String NODE2NODEDEF = "NODE2NODEDEF";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String NODE2LOCATION = "NODE2LOCATION";
	private static final String NODE2NODETYPE = "NODE2NODETYPE";
	private static final String NODE2PROVISIONSTATUS = "NODE2PROVISIONSTATUS";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String NODE2FUNCTIONALSTATUS = "NODE2FUNCTIONALSTATUS";
	private static final String NODE2CONTAINEDBY = "NODE2CONTAINEDBY";
	private static final String NODE2RPBUILDTEMPLATE = "NODE2RPBUILDTEMPLATE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";
	private static final String NODE2AGENT = "NODE2AGENT";
	private static final String OSVERSION = "OSVERSION";
	private static final String OS = "OS";
	private static final String EMSPRIORITY = "EMSPRIORITY";
	private static final String NODE2ACTIVATIONSTATUS = "NODE2ACTIVATIONSTATUS";
	private static final String NODE2SPSITE = "NODE2SPSITE";
	private static final String SITEPOSITIONX = "SITEPOSITIONX";
	private static final String SITEPOSITIONY = "SITEPOSITIONY";
	private static final String SITEROTATION = "SITEROTATION";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";
	private static final String ISASSET = "ISASSET";
	private static final String PROVISIONED = "PROVISIONED";
	private static final String ASSETTYPE = "ASSETTYPE";
	private static final String SERIALNO = "SERIALNO";
	private static final String CLEI = "CLEI";
	private static final String UPC = "UPC";
	private static final String CUSTOMERLOCATION = "CUSTOMERLOCATION";

	private List<Port> devicePorts = null;
	private List<Shelf> shelves = null;
	private Subscriber subscriber = null;
	private Nodetype nodetype = null;
	private Nodedef nodedef = null;
	private NodeExtension nodeExtension = null;
	private Location location = null;
	private List<Networkroleobject> networkroleobjects = null;
	private Provisionstatus provisionstatus = null;
	private Functionalstatus functionalstatus = null;
	private NodeInRackShelf nodeInRackShelf = null;
	private List<TTServiceType> ttserviceTypeList=null;
	private List<Circuit> circuitList=null;

	private List<Node> associatedDevices = null;

	public Node()
	{
		super();
		this.tableName = "NODE";
	}

	public Node(String nodeId)
	{
		this();
		primaryKey.setValue(nodeId);

		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public Node(Node template) {
		this();
		getRecordByTemplate(template);
		for (Field field : fields.values())
		{
			if (field.getValue() != null) {
				this.instanciated = true;
				break;
			}
		}		
	}

	public static List<Node> getNodeListByQuery(String query)
	{
		Node node = new Node();
		List<Node> nodeList = new ArrayList<Node>();
		List<Map<String,Object>> foundNodeList = node.getFullRecordsByQuery(query);

		for (Map<String,Object> nodeMap : foundNodeList)
		{
			Node workNode = new Node();
			workNode.instanciated = true;
			workNode.populateFields(nodeMap);
			nodeList.add(workNode);
		}

		return nodeList;
	}

	@Override
	public void populateModel()
	{
		fields.put(NODEID, new Field(NODEID, Field.TYPE_NUMERIC));

		/*
		fields.put(NODE2NODETYPE, new ReferenceField(NODE2NODETYPE, Field.TYPE_NUMERIC, "NODETYPE", "NAME", "NODETYPEID"));
		fields.put(NODE2NODEDEF, new ReferenceField(NODE2NODEDEF, Field.TYPE_NUMERIC, "NODEDEF", "NAME", "NODEDEFID"));
		 */
		fields.put(NODE2NODETYPE, new Field(NODE2NODETYPE, Field.TYPE_NUMERIC));
		fields.put(NODE2NODEDEF, new Field(NODE2NODEDEF, Field.TYPE_NUMERIC));

		//fields.put(NODE2PROVISIONSTATUS, new ReferenceField(NODE2PROVISIONSTATUS, Field.TYPE_NUMERIC, "PROVISIONSTATUS", "NAME", "PROVISIONSTATUSID"));
		//fields.put(NODE2FUNCTIONALSTATUS, new ReferenceField(NODE2FUNCTIONALSTATUS, Field.TYPE_NUMERIC, "FUNCTIONALSTATUS", "NAME", "FUNCTIONALSTATUSID"));
		fields.put(NODE2PROVISIONSTATUS, new Field(NODE2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(NODE2FUNCTIONALSTATUS, new Field(NODE2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));

		fields.put(NODE2ASSETSTATUS, new Field(NODE2ASSETSTATUS, Field.TYPE_NUMERIC));
		fields.put(OPERATIONALSTATUS, new Field(OPERATIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(ADMINSTRATIVESTATUS, new Field(ADMINSTRATIVESTATUS, Field.TYPE_NUMERIC));
		fields.put(ORIGINALCOST, new Field(ORIGINALCOST, Field.TYPE_NUMERIC));
		fields.put(COSTCURRENCY, new Field(COSTCURRENCY, Field.TYPE_VARCHAR));
		fields.put(POLLCOUNTER, new Field(POLLCOUNTER, Field.TYPE_NUMERIC));
		fields.put(DIAGCOUNTER, new Field(DIAGCOUNTER, Field.TYPE_NUMERIC));
		fields.put(NODE2TECHNICIAN, new Field(NODE2TECHNICIAN, Field.TYPE_NUMERIC));
		fields.put(NODE2BE, new Field(NODE2BE, Field.TYPE_NUMERIC));
		fields.put(SOFTWAREVERSION, new Field(SOFTWAREVERSION, Field.TYPE_VARCHAR));
		fields.put(STORAGETOTAL, new Field(STORAGETOTAL, Field.TYPE_NUMERIC));
		fields.put(STORAGEFREE, new Field(STORAGEFREE, Field.TYPE_NUMERIC));
		fields.put(STORAGERAM, new Field(STORAGERAM, Field.TYPE_NUMERIC));
		fields.put(NVSTORAGERAM, new Field(NVSTORAGERAM, Field.TYPE_NUMERIC));
		fields.put(LIFETERM, new Field(LIFETERM, Field.TYPE_NUMERIC));
		fields.put(LASTVALUE, new Field(LASTVALUE, Field.TYPE_NUMERIC));
		fields.put(LASTCHECKED, new Field(LASTCHECKED, Field.TYPE_DATE));
		fields.put(NODE2DEVICEGROUP, new Field(NODE2DEVICEGROUP, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(NODE2LOCATION, new Field(NODE2LOCATION, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(NODE2CONTAINEDBY, new Field(NODE2CONTAINEDBY, Field.TYPE_NUMERIC));
		fields.put(NODE2RPBUILDTEMPLATE, new Field(NODE2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(NODE2AGENT, new Field(NODE2AGENT, Field.TYPE_NUMERIC));
		fields.put(OSVERSION, new Field(OSVERSION, Field.TYPE_VARCHAR));
		fields.put(OS, new Field(OS, Field.TYPE_NUMERIC));
		fields.put(EMSPRIORITY, new Field(EMSPRIORITY, Field.TYPE_NUMERIC));
		fields.put(NODE2ACTIVATIONSTATUS, new Field(NODE2ACTIVATIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(NODE2SPSITE, new Field(NODE2SPSITE, Field.TYPE_NUMERIC));
		fields.put(SITEPOSITIONX, new Field(SITEPOSITIONX, Field.TYPE_NUMERIC));
		fields.put(SITEPOSITIONY, new Field(SITEPOSITIONY, Field.TYPE_NUMERIC));
		fields.put(SITEROTATION, new Field(SITEROTATION, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));
		fields.put(ISASSET, new Field(ISASSET, Field.TYPE_NUMERIC));
		fields.put(PROVISIONED, new Field(PROVISIONED, Field.TYPE_NUMERIC));
		fields.put(ASSETTYPE, new Field(ASSETTYPE, Field.TYPE_NUMERIC));
		fields.put(SERIALNO, new Field(SERIALNO, Field.TYPE_VARCHAR));
		fields.put(CLEI, new Field(CLEI, Field.TYPE_VARCHAR));
		fields.put(UPC, new Field(UPC, Field.TYPE_VARCHAR));
		fields.put(CUSTOMERLOCATION, new Field(CUSTOMERLOCATION, Field.TYPE_VARCHAR));

		primaryKey = new PrimaryKey(fields.get(NODEID));

		linkedTables.add(new LinkedTable("NODE", "LOCATION", NODE2LOCATION, "LOCATIONID", false));
		linkedTables.add(new LinkedTable("NODE", "NODETYPE", NODE2NODETYPE, "NODETYPEID", false));
		linkedTables.add(new LinkedTable("NODE", "NODEDEF", NODE2NODEDEF, "NODEDEFID", false));
		linkedTables.add(new LinkedTable("NODE", "EXT_DEVICE_TYPE", NODEID,NODEID,true));
		linkedTables.add(new LinkedTable("NODE", "PROVISIONSTATUS",NODE2PROVISIONSTATUS,"PROVISIONSTATUSID",false));
		ComplexLinkedTable clt1 = new ComplexLinkedTable("NODE", "NETWORKROLEOBJECT", NODEID, "NETWORKROLEOBJECT2OBJECT", true);
		clt1.addSubLink("NETWORKROLE", "NETWORKROLEOBJECT2NETWORKROLE", "NETWORKROLEID", true);
		linkedTables.add(clt1);

	}

	public void setNode2assetstatus(String node2assetstatus)
	{
		setField(NODE2ASSETSTATUS,node2assetstatus);
	}

	public String getNode2assetstatus()
	{
		return getFieldAsString(NODE2ASSETSTATUS);
	}

	public void setOperationalstatus(String operationalstatus)
	{
		setField(OPERATIONALSTATUS,operationalstatus);
	}

	public String getOperationalstatus()
	{
		return getFieldAsString(OPERATIONALSTATUS);
	}

	public void setAdminstrativestatus(String adminstrativestatus)
	{
		setField(ADMINSTRATIVESTATUS,adminstrativestatus);
	}

	public String getAdminstrativestatus()
	{
		return getFieldAsString(ADMINSTRATIVESTATUS);
	}

	public void setOriginalcost(String originalcost)
	{
		setField(ORIGINALCOST,originalcost);
	}

	public String getOriginalcost()
	{
		return getFieldAsString(ORIGINALCOST);
	}

	public void setCostcurrency(String costcurrency)
	{
		setField(COSTCURRENCY,costcurrency);
	}

	public String getCostcurrency()
	{
		return getFieldAsString(COSTCURRENCY);
	}

	public void setPollcounter(String pollcounter)
	{
		setField(POLLCOUNTER,pollcounter);
	}

	public String getPollcounter()
	{
		return getFieldAsString(POLLCOUNTER);
	}

	public void setDiagcounter(String diagcounter)
	{
		setField(DIAGCOUNTER,diagcounter);
	}

	public String getDiagcounter()
	{
		return getFieldAsString(DIAGCOUNTER);
	}

	public void setNode2technician(String node2technician)
	{
		setField(NODE2TECHNICIAN,node2technician);
	}

	public String getNode2technician()
	{
		return getFieldAsString(NODE2TECHNICIAN);
	}

	public void setNode2be(String node2be)
	{
		setField(NODE2BE,node2be);
	}

	public String getNode2be()
	{
		return getFieldAsString(NODE2BE);
	}

	public void setSoftwareversion(String softwareversion)
	{
		setField(SOFTWAREVERSION,softwareversion);
	}

	public String getSoftwareversion()
	{
		return getFieldAsString(SOFTWAREVERSION);
	}

	public void setStoragetotal(String storagetotal)
	{
		setField(STORAGETOTAL,storagetotal);
	}

	public String getStoragetotal()
	{
		return getFieldAsString(STORAGETOTAL);
	}

	public void setStoragefree(String storagefree)
	{
		setField(STORAGEFREE,storagefree);
	}

	public String getStoragefree()
	{
		return getFieldAsString(STORAGEFREE);
	}

	public void setStorageram(String storageram)
	{
		setField(STORAGERAM,storageram);
	}

	public String getStorageram()
	{
		return getFieldAsString(STORAGERAM);
	}

	public void setNvstorageram(String nvstorageram)
	{
		setField(NVSTORAGERAM,nvstorageram);
	}

	public String getNvstorageram()
	{
		return getFieldAsString(NVSTORAGERAM);
	}

	public void setLifeterm(String lifeterm)
	{
		setField(LIFETERM,lifeterm);
	}

	public String getLifeterm()
	{
		return getFieldAsString(LIFETERM);
	}

	public void setLastvalue(String lastvalue)
	{
		setField(LASTVALUE,lastvalue);
	}

	public String getLastvalue()
	{
		return getFieldAsString(LASTVALUE);
	}

	public void setLastchecked(String lastchecked)
	{
		setField(LASTCHECKED,lastchecked);
	}

	public String getLastchecked()
	{
		return getFieldAsString(LASTCHECKED);
	}

	public void setNode2devicegroup(String node2devicegroup)
	{
		setField(NODE2DEVICEGROUP,node2devicegroup);
	}

	public String getNode2devicegroup()
	{
		return getFieldAsString(NODE2DEVICEGROUP);
	}

	public void setNodeid(String nodeid)
	{
		setField(NODEID,nodeid);
	}

	public String getNodeid()
	{
		return getFieldAsString(NODEID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setNode2nodedef(String node2nodedef)
	{
		setField(NODE2NODEDEF,node2nodedef);
	}

	public String getNode2nodedef()
	{
		return getFieldAsString(NODE2NODEDEF);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setNode2location(String node2location)
	{
		setField(NODE2LOCATION,node2location);
	}

	public String getNode2location()
	{
		return getFieldAsString(NODE2LOCATION);
	}

	public void setNode2nodetype(String node2nodetype)
	{
		setField(NODE2NODETYPE,node2nodetype);
	}

	public String getNode2nodetype()
	{
		return getFieldAsString(NODE2NODETYPE);
	}

	public void setNode2provisionstatus(String node2provisionstatus)
	{
		setField(NODE2PROVISIONSTATUS,node2provisionstatus);
	}

	public String getNode2provisionstatus()
	{
		return getFieldAsString(NODE2PROVISIONSTATUS);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setNode2functionalstatus(String node2functionalstatus)
	{
		setField(NODE2FUNCTIONALSTATUS,node2functionalstatus);
	}

	public String getNode2functionalstatus()
	{
		return getFieldAsString(NODE2FUNCTIONALSTATUS);
	}

	public void setNode2containedby(String node2containedby)
	{
		setField(NODE2CONTAINEDBY,node2containedby);
	}

	public String getNode2containedby()
	{
		return getFieldAsString(NODE2CONTAINEDBY);
	}

	public void setNode2rpbuildtemplate(String node2rpbuildtemplate)
	{
		setField(NODE2RPBUILDTEMPLATE,node2rpbuildtemplate);
	}

	public String getNode2rpbuildtemplate()
	{
		return getFieldAsString(NODE2RPBUILDTEMPLATE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setNode2agent(String node2agent)
	{
		setField(NODE2AGENT,node2agent);
	}

	public String getNode2agent()
	{
		return getFieldAsString(NODE2AGENT);
	}

	public void setOsversion(String osversion)
	{
		setField(OSVERSION,osversion);
	}

	public String getOsversion()
	{
		return getFieldAsString(OSVERSION);
	}

	public void setOs(String os)
	{
		setField(OS,os);
	}

	public String getOs()
	{
		return getFieldAsString(OS);
	}

	public void setEmspriority(String emspriority)
	{
		setField(EMSPRIORITY,emspriority);
	}

	public String getEmspriority()
	{
		return getFieldAsString(EMSPRIORITY);
	}

	public void setNode2activationstatus(String node2activationstatus)
	{
		setField(NODE2ACTIVATIONSTATUS,node2activationstatus);
	}

	public String getNode2activationstatus()
	{
		return getFieldAsString(NODE2ACTIVATIONSTATUS);
	}

	public void setNode2spsite(String node2spsite)
	{
		setField(NODE2SPSITE,node2spsite);
	}

	public String getNode2spsite()
	{
		return getFieldAsString(NODE2SPSITE);
	}

	public void setSitepositionx(String sitepositionx)
	{
		setField(SITEPOSITIONX,sitepositionx);
	}

	public String getSitepositionx()
	{
		return getFieldAsString(SITEPOSITIONX);
	}

	public void setSitepositiony(String sitepositiony)
	{
		setField(SITEPOSITIONY,sitepositiony);
	}

	public String getSitepositiony()
	{
		return getFieldAsString(SITEPOSITIONY);
	}

	public void setSiterotation(String siterotation)
	{
		setField(SITEROTATION,siterotation);
	}

	public String getSiterotation()
	{
		return getFieldAsString(SITEROTATION);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public void setIsasset(String isasset)
	{
		setField(ISASSET,isasset);
	}

	public String getIsasset()
	{
		return getFieldAsString(ISASSET);
	}

	public void setProvisioned(String provisioned)
	{
		setField(PROVISIONED,provisioned);
	}

	public String getProvisioned()
	{
		return getFieldAsString(PROVISIONED);
	}

	public void setAssettype(String assettype)
	{
		setField(ASSETTYPE,assettype);
	}

	public String getAssettype()
	{
		return getFieldAsString(ASSETTYPE);
	}

	public void setSerialno(String serialno)
	{
		setField(SERIALNO,serialno);
	}

	public String getSerialno()
	{
		return getFieldAsString(SERIALNO);
	}

	public void setClei(String clei)
	{
		setField(CLEI,clei);
	}

	public String getClei()
	{
		return getFieldAsString(CLEI);
	}

	public void setUpc(String upc)
	{
		setField(UPC,upc);
	}

	public String getUpc()
	{
		return getFieldAsString(UPC);
	}

	public void setCustomerlocation(String customerlocation)
	{
		setField(CUSTOMERLOCATION,customerlocation);
	}

	public String getCustomerlocation()
	{
		return getFieldAsString(CUSTOMERLOCATION);
	}

	public Subscriber getSubscriber()
	{
		if (subscriber == null)
		{
			if (!StringHelper.isEmpty(getRelativename()))
			{
				Subscriber template = new Subscriber();
				template.setName(getRelativename());
				Subscriber sub = new Subscriber(template);
				if (sub.isInstanciated())
				{
					this.subscriber = sub;
				}
			}
		}

		return subscriber;
	}

	public List<Port> getDevicePorts()
	{
		return getDevicePorts(null);
	}

	public List<Port> getDevicePorts(String additionalConditions)
	{
		if (devicePorts == null)
		{
			String query = "port2node = " + fields.get(NODEID).getQueryValue() + " and port2card is null AND PORT.PARENTPORT2PORT IS NULL";
			if (!StringHelper.isEmpty(additionalConditions))
			{
				query += " AND " + additionalConditions;
			}
			devicePorts = Port.getPortListByQuery(query);
		}

		return devicePorts;
	}

	public List<Port> getDevicePorts(String additionalConditions,boolean applyPortFilter)
	{
		if (devicePorts == null)
		{
			String query = "port2node = " + fields.get(NODEID).getQueryValue() + " and port2card is null AND PORT.PARENTPORT2PORT IS NULL";

			if (!StringHelper.isEmpty(additionalConditions))
			{
				if ((!additionalConditions.contains("SHELF"))&& (!additionalConditions.contains("SLOT")))
				{
					query += " AND " + additionalConditions;
				}
			}
			devicePorts = Port.getPortListByQuery(query,applyPortFilter);
		}

		return devicePorts;
	}


	public List<Shelf> getShelves()
	{
		if (shelves == null)
		{
			shelves = Shelf.getShelfListByQuery("shelf2node = " + fields.get(NODEID).getQueryValue());
		}

		return shelves;
	}

	public List<Shelf> getShelves(String shelfNumber)
	{
		if (shelves == null)
		{
			if(shelfNumber!=null)
			{
				shelves = Shelf.getShelfListByQuery("shelf2node = " + fields.get(NODEID).getQueryValue()+" AND SHELF.SHELFNUMBER = "+shelfNumber);
			}
			else
			{
				shelves = Shelf.getShelfListByQuery("shelf2node = " + fields.get(NODEID).getQueryValue());
			}
		}

		return shelves;
	}
	
	public Nodetype getNodeType()
	{
		if (nodetype == null)
		{
			nodetype = (Nodetype) ValueObjectCacheAccessorFactory.getValueObjectCache("nodetype").getCacheObject(getField(NODE2NODETYPE).toString());
		}

		return nodetype;
	}

	public Nodedef getNodeDef()
	{
		if (nodedef == null)
		{
			nodedef = (Nodedef) ValueObjectCacheAccessorFactory.getValueObjectCache("nodedef").getCacheObject(this.getNode2nodedef());
		}

		return nodedef;
	}

	public NodeExtension getNodeExtension()
	{
		if (nodeExtension == null)
		{
			nodeExtension = new NodeExtension(fields.get(NODEID), getNodeType().getTablename());
		}

		return nodeExtension;
	}

	public Location getLocation()
	{
		if (location == null)
		{
			location = new Location(getField(NODE2LOCATION).toString());
		}

		return location;
	}

	public List<Networkroleobject> getNetworkroleobjects()
	{
		if (networkroleobjects == null)
		{
			networkroleobjects = Networkroleobject.getNetworkroleobjectListByObject(getField(NODEID).toString(), "1");
		}

		return networkroleobjects;
	}

	public Provisionstatus getProvisionstatus()
	{
		if (provisionstatus == null)
		{
			provisionstatus = (Provisionstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("provisionstatus").getCacheObject(getField(NODE2PROVISIONSTATUS).toString());
		}

		return provisionstatus;
	}

	public Functionalstatus getFunctionalstatus()
	{
		if (functionalstatus == null)
		{
			functionalstatus = (Functionalstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("functionalstatus").getCacheObject(this.getNode2functionalstatus());

			if (functionalstatus == null)
			{
				functionalstatus = new Functionalstatus();
			}
		}

		return functionalstatus;
	}

	public NodeInRackShelf getNodeInRackShelf()
	{
		if (nodeInRackShelf == null)
		{
			List<NodeInRackShelf> nodeInRackShelfList = NodeInRackShelf.getNodeInRackShelfList(getField(NODEID).toString(), null);
			if(nodeInRackShelfList.size()>0)
			nodeInRackShelf =  nodeInRackShelfList.get(0);
		}

		return nodeInRackShelf;
	}

	public List<Node> getAssociatedDevices()
	{
		if (associatedDevices == null)
		{
			associatedDevices = new ArrayList<Node>();
			List<NodeInRackShelf> nodeInRackShelfList = new ArrayList<NodeInRackShelf>();

			for(Shelf shelf : getShelves())
			{
				nodeInRackShelfList = NodeInRackShelf.getNodeInRackShelfListByRackShelf(shelf.getShelfid());

				for (NodeInRackShelf nodeInRackShelf: nodeInRackShelfList)
				{
					associatedDevices.add(new Node(nodeInRackShelf.getNirs2node()));
				}
			}
		}

		return associatedDevices;
	}

	public List<TTServiceType> getTTServiceTypeList()
	{
		if (ttserviceTypeList == null)
		{
			String query = "ARM_OBJECT_ID = " +this.getNodeDef().getNodedefid() + " AND ARM_OBJECT_TYPE='Node'";

			LOG.info("TTServiceType"+query);

			ttserviceTypeList = TTServiceType.getTTServiceTypeListByQuery(query);
		}

		return ttserviceTypeList;
	}


	public List<Circuit> getCircuitsList()
	{
		if (circuitList == null)
		{

			String query = "(CIRCUIT.CIRCUIT2STARTNODE = '" +this.getNodeid() + "' OR CIRCUIT.CIRCUIT2ENDNODE = '"+this.getNodeid()+"')";

			LOG.info("Circuit:"+query);

			circuitList = Circuit.getCircuitListByQuery(query);


		}
		return circuitList;
	}



	public List<String> getCompatibleONTModelsByQuery(String nodeDef,
			String downStreamBW, String upStreamBW) {
		VendorCompatibility vendorcompatibility = new VendorCompatibility();
		List<String> ontNodeDefNameList = vendorcompatibility.getVendorCompatibilityObject(nodeDef, downStreamBW , upStreamBW);
		return ontNodeDefNameList;
	}


	public  String getPreferredDeviceModelsByQuery(String nodeDef) {

		{
			PreferredDeviceModel preferreddeviceModel = new PreferredDeviceModel();
			String preferredDeviceModel = preferreddeviceModel.getPreferredDeviceModelObject(nodeDef);
			return preferredDeviceModel;

		}

	}
}



