package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.armaccessobject.RouteDetail;
import com.centurylink.icl.armmediation.dataaccess.RouteDetailDAO;

public class RouteDetailDaoImpl implements RouteDetailDAO {

	private JdbcTemplate jdbcTemplate;
	private static final String INSERT_SQL = "INSERT INTO ROUTE_DETAIL (ROUTE_HEADER_ID, SEQ_NO, ASSET_OBJECT, ASSET_TYPE, ASSET_VALUE) VALUES (?, ?, ?, ?, ?)";
	private static final String VALIDATE_ASSET_SQL = "SELECT COUNT(*) FROM ROUTE_DETAIL WHERE ASSET_TYPE = ? AND ASSET_VALUE=?";
	private static final String QUERY_BY_FIRST_CIRCUIT_NAME = "SELECT * FROM ROUTE_DETAIL WHERE ROUTE_HEADER_ID = (SELECT ROUTE_HEADER_ID FROM ROUTE_DETAIL WHERE SEQ_NO = 2 AND ASSET_VALUE = ?)";
	private static final String QUERY_BY_NPE = "SELECT * FROM ROUTE_DETAIL WHERE ROUTE_HEADER_ID=? AND ASSET_TYPE='NPE' AND ASSET_VALUE=? AND ROWNUM=1";
	private static final String QUERY_BY_ROUTE_HEADER_ID = "SELECT * FROM ROUTE_DETAIL WHERE ROUTE_HEADER_ID = ? ORDER BY SEQ_NO";
	private static final String DELETE_BY_ROUTE_HEADER_ID = "DELETE FROM ROUTE_DETAIL WHERE ROUTE_HEADER_ID = ?";
	
	public RouteDetailDaoImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void insert(RouteDetail routeDetail)
	{
		this.jdbcTemplate.update(INSERT_SQL, new Object[] {routeDetail.getRouteHeaderId(), routeDetail.getSeqNo(), routeDetail.getAssetObject(), routeDetail.getAssetType(), routeDetail.getAssetValue()});
	}

	@Override
	public int deleteAll(Long routeHeaderId)
	{
		return this.jdbcTemplate.update(DELETE_BY_ROUTE_HEADER_ID, new Object[] {routeHeaderId});
	}
	
	@Override
	public boolean validateRouteAsset(String assetType, String assetValue)
	{
		int assetCount = this.jdbcTemplate.queryForInt(VALIDATE_ASSET_SQL, new Object[] {assetType, assetValue});

		return assetCount > 0;
	}
	
	@Override
	public List<RouteDetail> lookupRouteDetailByFirstCircuitName(String firstCircuitName)
	{
		List<RouteDetail> routeDetailList = this.jdbcTemplate.query(QUERY_BY_FIRST_CIRCUIT_NAME, new Object[] {firstCircuitName}, new RouteDetailMapper());
		return routeDetailList;
	}
	
	@Override
	public RouteDetail getNPEForRoute(Long routeHeaderId, String npeValue)
	{
		try
		{
			return this.jdbcTemplate.queryForObject(QUERY_BY_NPE, new Object[] {routeHeaderId, npeValue}, new RouteDetailMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return null;			
		}
	}
	
	@Override
	public List<RouteDetail> lookupRouteDetailByRouteHeaderId(Long routeHeaderId)
	{
		List<RouteDetail> routeDetailList = this.jdbcTemplate.query(QUERY_BY_ROUTE_HEADER_ID, new Object[] {routeHeaderId}, new RouteDetailMapper());
		return routeDetailList;
	}
	
	private class RouteDetailMapper implements RowMapper<RouteDetail>
	{
		@Override
		public RouteDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
			RouteDetail routeDetail = new RouteDetail();
			routeDetail.setRouteDetailId(rs.getLong("ROUTE_DETAIL_ID"));
			routeDetail.setRouteHeaderId(rs.getLong("ROUTE_HEADER_ID"));
			routeDetail.setSeqNo(rs.getInt("SEQ_NO"));
			routeDetail.setAssetObject(rs.getString("ASSET_OBJECT"));
			routeDetail.setAssetType(rs.getString("ASSET_TYPE"));
			routeDetail.setAssetValue(rs.getString("ASSET_VALUE"));
			
			return routeDetail;
		}
	}
}
