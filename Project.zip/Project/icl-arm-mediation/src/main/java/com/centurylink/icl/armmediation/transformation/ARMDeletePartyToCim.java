package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.cim2.DeletePartyResponseBuilder;
import com.centurylink.icl.builder.cim2.DeletePartyResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.PartyBuilder;
import com.iclnbi.iclnbiV200.DeleteLocationRequestDocument;
import com.iclnbi.iclnbiV200.DeleteLocationResponseDocument;
import com.iclnbi.iclnbiV200.DeletePartyRequestDocument;
import com.iclnbi.iclnbiV200.DeletePartyResponseDocument;

public class ARMDeletePartyToCim {
	
	private static final Log							LOG	= LogFactory.getLog(SearchLocationToCim.class);
	private final DeletePartyResponseDocumentBuilder    deletePartyResponseDocumentBuilder;
	private final DeletePartyResponseBuilder			deletePartyResponseBuilder;
	private final MessageElementsBuilder				messageElementsBuilder;
	private final ErrorBuilder							errorBuilder;
	private final PartyBuilder                          partyBuilder;
	public ARMDeletePartyToCim()
	{
		deletePartyResponseBuilder = new DeletePartyResponseBuilder();
		deletePartyResponseDocumentBuilder = new DeletePartyResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
		partyBuilder=new PartyBuilder();
	}
	
	public DeletePartyResponseDocument transformToCim(DeletePartyRequestDocument createRequest, String objectID,String commonName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("DeleteSubscriber : Transform to CIM");
		}

		
		/*final Party party = (PartyBuilder) createRequest.getDeletePartyRequest().getPartyDetails();
		partyBuilder.buildParty(commonName, objectID);
		messageElementsBuilder.buildMessageElements("Success", "");
		messageElementsBuilder.setMessageAddressing(createRequest.getDeletePartyRequest().getMessageElements().getMessageAddressing());
*/
		deletePartyResponseDocumentBuilder.buildDeletePartyResponseDocumentBuilder();
		deletePartyResponseBuilder.buildDeletePartyResponse();
		partyBuilder.buildParty(commonName, null);
		deletePartyResponseBuilder.addParty(partyBuilder.getParty());
		deletePartyResponseDocumentBuilder.addDeletePartyResponse(deletePartyResponseBuilder.getDeletePartyResponse());
		//deletePartyResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		//deletePartyResponseBuilder.addParty(partyBuilder);
		//deletePartyResponseBuilder.addAddressDetails(addressDetails);
		//deletePartyResponseDocumentBuilder.buildDeletePartyResponseDocument(deletePartyResponseBuilder.getDeletePartyResponse());
		return deletePartyResponseDocumentBuilder.getDeletePartyResponseDocument();
	}
	
	public DeletePartyResponseDocument transformErrorToCim(DeletePartyRequestDocument deleteRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("DeleteSubscriber : Transform Error to CIM");
		}
        deletePartyResponseDocumentBuilder.buildDeletePartyResponseDocumentBuilder();
		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(deleteRequest.getDeletePartyRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		deletePartyResponseBuilder.buildDeletePartyResponse();
		deletePartyResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		deletePartyResponseDocumentBuilder.addDeletePartyResponse(deletePartyResponseBuilder.getDeletePartyResponse());
		//deletePartyResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		//deletePartyResponseDocumentBuilder.buildDeletePartyResponseDocument(deletePartyResponseBuilder.getDeletePartyResponse());
		System.out.println(deletePartyResponseDocumentBuilder.getDeletePartyResponseDocument());
		return deletePartyResponseDocumentBuilder.getDeletePartyResponseDocument();
	}
	


}
