package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

public interface GetRoutesForAssociatedCircuitDAO
{
	public List<String> getRoutes(String associatedCircuit);
}
