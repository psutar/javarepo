package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Nodedef extends AbstractReadOnlyTable {

	private static final String EXTERNALDEPTH = "EXTERNALDEPTH";
	private static final String EXTERNALWIDTH = "EXTERNALWIDTH";
	private static final String MAXCONNS = "MAXCONNS";
	private static final String LOCKINGMODE = "LOCKINGMODE";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String ORIENTATION = "ORIENTATION";
	private static final String PORTSTARTNUMBER = "PORTSTARTNUMBER";
	private static final String SHELFSIZE = "SHELFSIZE";
	private static final String NODEDEF2PORTTYPE = "NODEDEF2PORTTYPE";
	private static final String NODEDEF2NODETYPE = "NODEDEF2NODETYPE";
	private static final String SHELFSTARTNUMBER = "SHELFSTARTNUMBER";
	private static final String VERSION = "VERSION";
	private static final String MANUFACTURER = "MANUFACTURER";
	private static final String NAME = "NAME";
	private static final String NODEDEFID = "NODEDEFID";
	private static final String POWERUSED = "POWERUSED";
	private static final String POWERSUPPLIED = "POWERSUPPLIED";
	private static final String COOLINGUSED = "COOLINGUSED";
	private static final String COOLINGSUPPLIED = "COOLINGSUPPLIED";
	private static final String EXTERNALAREA = "EXTERNALAREA";
	private static final String EXTERNALHEIGHT = "EXTERNALHEIGHT";

	public Nodedef()
	{
		super();
		this.tableName = "NODEDEF";
	}

	public Nodedef(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Nodedef> getNodedefListByQuery(String query)
	{
		Nodedef nodedef = new Nodedef();
		List<Nodedef> nodedefList = new ArrayList<Nodedef>();
		List<Map<String,Object>> foundNodedefList = nodedef.getRecordsByQuery(query);

		for (Map<String,Object> nodedefMap : foundNodedefList)
		{
			Nodedef workNodedef = new Nodedef(nodedefMap.get(NODEDEFID).toString());
			nodedefList.add(workNodedef);
		}
		return nodedefList;
	}

	@Override
	public void populateModel()
	{
		fields.put(EXTERNALDEPTH, new Field(EXTERNALDEPTH, Field.TYPE_NUMERIC));
		fields.put(EXTERNALWIDTH, new Field(EXTERNALWIDTH, Field.TYPE_NUMERIC));
		fields.put(MAXCONNS, new Field(MAXCONNS, Field.TYPE_NUMERIC));
		fields.put(LOCKINGMODE, new Field(LOCKINGMODE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(ORIENTATION, new Field(ORIENTATION, Field.TYPE_NUMERIC));
		fields.put(PORTSTARTNUMBER, new Field(PORTSTARTNUMBER, Field.TYPE_NUMERIC));
		fields.put(SHELFSIZE, new Field(SHELFSIZE, Field.TYPE_NUMERIC));
		fields.put(NODEDEF2PORTTYPE, new Field(NODEDEF2PORTTYPE, Field.TYPE_NUMERIC));
		fields.put(NODEDEF2NODETYPE, new Field(NODEDEF2NODETYPE, Field.TYPE_NUMERIC));
		fields.put(SHELFSTARTNUMBER, new Field(SHELFSTARTNUMBER, Field.TYPE_NUMERIC));
		fields.put(VERSION, new Field(VERSION, Field.TYPE_VARCHAR));
		fields.put(MANUFACTURER, new Field(MANUFACTURER, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(NODEDEFID, new Field(NODEDEFID, Field.TYPE_NUMERIC));
		fields.put(POWERUSED, new Field(POWERUSED, Field.TYPE_NUMERIC));
		fields.put(POWERSUPPLIED, new Field(POWERSUPPLIED, Field.TYPE_NUMERIC));
		fields.put(COOLINGUSED, new Field(COOLINGUSED, Field.TYPE_NUMERIC));
		fields.put(COOLINGSUPPLIED, new Field(COOLINGSUPPLIED, Field.TYPE_NUMERIC));
		fields.put(EXTERNALAREA, new Field(EXTERNALAREA, Field.TYPE_NUMERIC));
		fields.put(EXTERNALHEIGHT, new Field(EXTERNALHEIGHT, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(NODEDEFID));
	}

	public void setExternaldepth(String externaldepth)
	{
		setField(EXTERNALDEPTH,externaldepth);
	}

	public String getExternaldepth()
	{
		return getFieldAsString(EXTERNALDEPTH);
	}

	public void setExternalwidth(String externalwidth)
	{
		setField(EXTERNALWIDTH,externalwidth);
	}

	public String getExternalwidth()
	{
		return getFieldAsString(EXTERNALWIDTH);
	}

	public void setMaxconns(String maxconns)
	{
		setField(MAXCONNS,maxconns);
	}

	public String getMaxconns()
	{
		return getFieldAsString(MAXCONNS);
	}

	public void setLockingmode(String lockingmode)
	{
		setField(LOCKINGMODE,lockingmode);
	}

	public String getLockingmode()
	{
		return getFieldAsString(LOCKINGMODE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setOrientation(String orientation)
	{
		setField(ORIENTATION,orientation);
	}

	public String getOrientation()
	{
		return getFieldAsString(ORIENTATION);
	}

	public void setPortstartnumber(String portstartnumber)
	{
		setField(PORTSTARTNUMBER,portstartnumber);
	}

	public String getPortstartnumber()
	{
		return getFieldAsString(PORTSTARTNUMBER);
	}

	public void setShelfsize(String shelfsize)
	{
		setField(SHELFSIZE,shelfsize);
	}

	public String getShelfsize()
	{
		return getFieldAsString(SHELFSIZE);
	}

	public void setNodedef2porttype(String nodedef2porttype)
	{
		setField(NODEDEF2PORTTYPE,nodedef2porttype);
	}

	public String getNodedef2porttype()
	{
		return getFieldAsString(NODEDEF2PORTTYPE);
	}

	public void setNodedef2nodetype(String nodedef2nodetype)
	{
		setField(NODEDEF2NODETYPE,nodedef2nodetype);
	}

	public String getNodedef2nodetype()
	{
		return getFieldAsString(NODEDEF2NODETYPE);
	}

	public void setShelfstartnumber(String shelfstartnumber)
	{
		setField(SHELFSTARTNUMBER,shelfstartnumber);
	}

	public String getShelfstartnumber()
	{
		return getFieldAsString(SHELFSTARTNUMBER);
	}

	public void setVersion(String version)
	{
		setField(VERSION,version);
	}

	public String getVersion()
	{
		return getFieldAsString(VERSION);
	}

	public void setManufacturer(String manufacturer)
	{
		setField(MANUFACTURER,manufacturer);
	}

	public String getManufacturer()
	{
		return getFieldAsString(MANUFACTURER);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setNodedefid(String nodedefid)
	{
		setField(NODEDEFID,nodedefid);
	}

	public String getNodedefid()
	{
		return getFieldAsString(NODEDEFID);
	}

	public void setPowerused(String powerused)
	{
		setField(POWERUSED,powerused);
	}

	public String getPowerused()
	{
		return getFieldAsString(POWERUSED);
	}

	public void setPowersupplied(String powersupplied)
	{
		setField(POWERSUPPLIED,powersupplied);
	}

	public String getPowersupplied()
	{
		return getFieldAsString(POWERSUPPLIED);
	}

	public void setCoolingused(String coolingused)
	{
		setField(COOLINGUSED,coolingused);
	}

	public String getCoolingused()
	{
		return getFieldAsString(COOLINGUSED);
	}

	public void setCoolingsupplied(String coolingsupplied)
	{
		setField(COOLINGSUPPLIED,coolingsupplied);
	}

	public String getCoolingsupplied()
	{
		return getFieldAsString(COOLINGSUPPLIED);
	}

	public void setExternalarea(String externalarea)
	{
		setField(EXTERNALAREA,externalarea);
	}

	public String getExternalarea()
	{
		return getFieldAsString(EXTERNALAREA);
	}

	public void setExternalheight(String externalheight)
	{
		setField(EXTERNALHEIGHT,externalheight);
	}

	public String getExternalheight()
	{
		return getFieldAsString(EXTERNALHEIGHT);
	}
}