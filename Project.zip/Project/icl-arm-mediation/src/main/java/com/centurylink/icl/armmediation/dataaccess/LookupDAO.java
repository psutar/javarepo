package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;
import java.util.Map;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMSubscriber;

/**
 * DAO for all lookup operations
 * 
 */
public interface LookupDAO
{

	public List<ARMDevice> lookupDevice(String query) throws Exception;

	public List<ARMCircuit> lookupCircuit(String query) throws Exception;

	public List<ARMDevice> lookupHecigCode(String query) throws Exception;

	public List<ARMLocation> lookupLocation(String query) throws Exception;

	public List<Map<String, Object>> lookupPort(String query) throws Exception;

	public List<Map<String, Object>> lookupDeviceMDW(String query) throws Exception;

	public List<Map<String, Object>> lookupLocationMDW(String query) throws Exception;

	public List<Map<String, Object>> lookupHecigMDW(String query) throws Exception;

	public List<Map<String, Object>> lookupCircuitNameMDW(String query) throws Exception;

	public List<Map<String, Object>> lookupServiceNameMDW(String query) throws Exception;

	public List<Map<String, Object>> lookupBandwidth(String query) throws Exception;

	public List<Map<String, Object>> lookupCircuitType(String query) throws Exception;

	public List<Map<String, Object>> lookupCircuitOnPort(String query) throws Exception;

	public List<Map<String, Object>> lookupServiceType(String query) throws Exception;

	public List<Map<String, Object>> lookupSubscriber(String query) throws Exception;

	public List<ARMCircuit> lookupService(String query) throws Exception;

	public List<Map<String, Object>> lookupStatus(String query) throws Exception;

	public List<ARMSubscriber> lookupSubscriberByUNIId(String query) throws Exception;
}
