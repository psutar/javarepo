package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;



import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.dvar.webservice.customermgmt.serviceTypes.DvarWebServiceResponseDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.centurylink.icl.armmediation.helper.DVARLookupServiceHelper;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.CircuitValuesMaxNum;
import com.centurylink.icl.armmediation.valueobjects.objects.Dimnumber;
import com.centurylink.icl.armmediation.valueobjects.objects.DimnumberExtension;
import com.centurylink.icl.armmediation.valueobjects.objects.Dimnumbertype;
import com.centurylink.icl.armmediation.valueobjects.objects.Enumeration;
import com.centurylink.icl.armmediation.valueobjects.objects.MEPExtension;
import com.centurylink.icl.armmediation.valueobjects.objects.NcNciBandwidth;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Numberobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Parameterdefinition;
import com.centurylink.icl.armmediation.valueobjects.objects.Parameterinstance;
import com.centurylink.icl.armmediation.valueobjects.objects.Parameterinstancevalue;
import com.centurylink.icl.armmediation.valueobjects.objects.Parameterset;
import com.centurylink.icl.armmediation.valueobjects.objects.Parametersetversion;
import com.centurylink.icl.armmediation.valueobjects.objects.PMMaxEVC;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.armmediation.valueobjects.objects.ServiceSpecification;
import com.centurylink.icl.armmediation.valueobjects.objects.SlaTargetTemplate;
import com.centurylink.icl.armmediation.valueobjects.objects.Subscriber;
import com.centurylink.icl.armmediation.valueobjects.objects.VPNExtension;
import com.centurylink.icl.builder.cim2.BandwidthProfileBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CosBundleBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.EVCCircuitBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.MaintenanceEndPointBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.UNICircuitBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.CoSBundle;
import com.iclnbi.iclnbiV200.ConnectionTerminationPoint;
import com.iclnbi.iclnbiV200.EVCCircuit;
import com.iclnbi.iclnbiV200.Point2PointCircuit;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TerminationPoint;
import com.iclnbi.iclnbiV200.UNICircuit;

public class SearchServiceVOTransformation {
	private static final Log LOG = LogFactory
			.getLog(SearchServiceVOTransformation.class);

	public static SearchResourceResponseDocument transformToCIM(
			List<Service> services, VOSearchHolder searchHolder)
			throws Exception {
		String entityType = null;
		if (searchHolder.getModifiers().containsKey("RESOURCETYPE")
				|| searchHolder.getModifiers().containsKey("ENTITYTYPE")) {
			String tempEntity = searchHolder.getModifiers().containsKey(
					"RESOURCETYPE") ? searchHolder.getModifiers().get(
					"RESOURCETYPE") : searchHolder.getModifiers().get(
					"ENTITYTYPE");
			if (tempEntity.equalsIgnoreCase("UNI")
					|| tempEntity.equalsIgnoreCase("ENNI") || tempEntity.equalsIgnoreCase("Probe UNI"))
				entityType = "UNI";
			else if (tempEntity.equalsIgnoreCase("EVC")
					|| tempEntity.equalsIgnoreCase("OVC"))
				entityType = "EVC";
			else if (tempEntity.equalsIgnoreCase("SERVICE"))
				entityType = "SERVICE";
			else if (tempEntity.equalsIgnoreCase("ENNI Link Service"))
				entityType = "ENNI Link Service";
		}

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder
				.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		boolean datafound = false;
		if (services != null && services.size() > 0) {
			for (Service service : services) {

				if (service != null) {
					
					if((service.getServicetype()!=null && service.getServicetype().getName()!=null && service.getServicetype().getName().equalsIgnoreCase("HSI")) ||(service.getServicetype()!=null && service.getServicetype().getName()!=null && service.getServicetype().getName().equalsIgnoreCase("IPTV")) || (service.getServicetype()!=null && service.getServicetype().getName()!=null && service.getServicetype().getName().equalsIgnoreCase("IPTV Unicast")))
					{
						searchResponseDetailsBuilder.addCircuit(HSIServiceDetailsVOTransformation.buildService(service,searchHolder));
						datafound=true;
					}
					else if (StringHelper.isEmpty(searchHolder.getModifiers().get(
							"RESOURCETYPE"))
							&& StringHelper.isEmpty(searchHolder.getModifiers()
									.get("ENTITYTYPE"))) {
						searchResponseDetailsBuilder.addCircuit(buildService(
								service, searchHolder.getLevel(),
								searchHolder.getScope(),
								searchHolder.getModifiers()));
						datafound = true;
					} else if (entityType != null) {
						if (entityType.equals("UNI")
								&& (service.getServicetype().getName().equals("MEF UNI") || 
									service.getServicetype().getName().equals("MEF ENNI") || 
									service.getServicetype().getName().equals("Probe UNI") ||
									service.getServicetype().getName().equals("ENNI Link Service"))) {
							searchResponseDetailsBuilder
									.addP2PCircuit(buildUNIService(service,
											searchHolder.getLevel(),
											searchHolder.getScope(),
											searchHolder.getModifiers()));
							datafound = true;
						} else if (entityType.equals("EVC")
								&& (service.getServicetype().getName()
										.equals("MEF EVC") || service
										.getServicetype().getName()
										.equals("MEF OVC"))) {
							searchResponseDetailsBuilder
									.addCircuit(buildEVCService(service,
											searchHolder.getLevel(),
											searchHolder.getScope(),
											searchHolder.getModifiers()));
							datafound = true;
						} 
						else if (entityType.equals("SERVICE")) {
							searchResponseDetailsBuilder
									.addCircuit(buildService(service,
											searchHolder.getLevel(),
											searchHolder.getScope(),
											searchHolder.getModifiers()));
							datafound = true;
						}else if(entityType.equals("ENNI Link Service") &&
								service.getServicetype().getName().equals("ENNI Link Service")){
							if (service.getAssociatedServices().size() > 0)
									 {
										for (Service EnniService : service.getAssociatedServices())
										{
											searchResponseDetailsBuilder.addP2PCircuit(buildUNIService(EnniService,searchHolder.getLevel(),
													searchHolder.getScope(),searchHolder.getModifiers()));
										}
										datafound = true;										
									 }									 
						}

					}
				}
			}
		}
		if (!datafound) {
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(
				searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder
				.addSearchResourceResponse(searchResourceResponseBuilder
						.getSearchResourceResponse());

		// System.out.println(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		if (LOG.isInfoEnabled()) {
			LOG.info(searchResourceResponseDocumentBuilder
					.getSearchResourceResponseDocument().toString());
		}

		return searchResourceResponseDocumentBuilder
				.getSearchResourceResponseDocument();
	}

	public static SearchResourceResponseDocument transformToCIM(
			Service service, VOSearchHolder searchHolder) throws Exception {
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder
				.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		searchResponseDetailsBuilder.addCircuit(buildService(service,
				searchHolder.getLevel(), searchHolder.getScope(),
				searchHolder.getModifiers()));

		searchResourceResponseBuilder.buildSearchResourceResponse(
				searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder
				.addSearchResourceResponse(searchResourceResponseBuilder
						.getSearchResourceResponse());

		if (LOG.isInfoEnabled()) {
			LOG.info(searchResourceResponseDocumentBuilder
					.getSearchResourceResponseDocument().toString());
		}

		return searchResourceResponseDocumentBuilder
				.getSearchResourceResponseDocument();
	}

	private static SubNetworkConnection buildService(Service service,
			String level, String scope, Map<String, String> modifiers)
			throws Exception {
		boolean includeRelationships = false;
		if (modifiers.containsKey("INCLUDERELATIONSHIPS")) {
			if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE")) {
				includeRelationships = true;
			}
		}

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();

		if (scope.equalsIgnoreCase("BASIC")) {
			subNetworkConnectionBuilder.buildSubNetworkConnection(service
					.getName(), service.getServiceid(), null, "ARM", service
					.getServicetype().getName(), service.getProvisionstatus()
					.getName(), null, null, null, null, service
					.getFunctionalstatus().getName(), null);
		} else {
			subNetworkConnectionBuilder
					.buildSubNetworkConnection(service.getName(), service
							.getServiceid(), null, "ARM", service
							.getServicetype().getName(), service
							.getProvisionstatus().getName(), null, null,
							service.getAlias1(), service.getAlias2(), service
									.getFunctionalstatus().getName(), null);

			subNetworkConnectionBuilder.addResourceDescribedBy(
					"CircuitIDFormat", "CLS");
			subNetworkConnectionBuilder.addResourceDescribedBy("MCO", service
					.getServiceExtension().getMco());
			subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse",
					service.getServiceExtension().getIsDiverse());
			subNetworkConnectionBuilder.addResourceDescribedBy("DiverseUNIID",
					service.getServiceExtension().getDiverseUniId());
			subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator",
					service.getServiceExtension().getHpc());
			subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate",
					service.getServiceExtension().getHpcexpirationdate());
			subNetworkConnectionBuilder.addResourceDescribedBy("STI", service
					.getServiceExtension().getSti());
			subNetworkConnectionBuilder.addResourceDescribedBy("TSP", service
					.getServiceExtension().getTSP());
			subNetworkConnectionBuilder.addResourceDescribedBy("FrameFormat",
					service.getServiceExtension().getFrameformat());
			subNetworkConnectionBuilder.addResourceDescribedBy("MTU", service
					.getServiceExtension().getEvcmtu());
			subNetworkConnectionBuilder.addResourceDescribedBy("MTU", service
					.getServiceExtension().getOvcmtu());
			subNetworkConnectionBuilder.addResourceDescribedBy("NCCode",
					service.getServiceExtension().getEvcovcnc());
			subNetworkConnectionBuilder.addResourceDescribedBy("COSID", service
					.getServiceExtension().getCosId());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"UnicastFrameDelivery", service.getServiceExtension()
							.getUnicastframedelivery());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"MulticastFrameDelivery", service.getServiceExtension()
							.getMulticastframedelivery());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"BroadcastFrameDelivery", service.getServiceExtension()
							.getBroadcastframedelivery());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"SVLANIDPreservation", service.getServiceExtension()
							.getSvlanidpreservation());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"SVLANIDCosPreservation", service.getServiceExtension()
							.getSvlancospreservation());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"ColorForwarding", service.getServiceExtension()
							.getColorforwarding());
			subNetworkConnectionBuilder.addResourceDescribedBy(
					"EVCOVCReference", service.getServiceExtension()
							.getEvcovcreference());
			//Start - Defect #3586
			List<Numberobject> numberObjectList = Numberobject.getNumberobjectListByObjectIdandDimObjectandRelationship(service.getServiceid(), "8", "1920000015");
			if(null != numberObjectList && numberObjectList.size()>0){
				subNetworkConnectionBuilder.addResourceDescribedBy("CVLANRange", numberObjectList.get(0).getDimnumber().getName());				
			}			
			//End - Defect #3586

			if(service.getServicetype()!=null && service.getServicetype().getName()!=null && (service.getServicetype().getName().equalsIgnoreCase("MEF EVC")||service.getServicetype().getName().equalsIgnoreCase("MEF OVC")))
			{
				if(service.getServiceExtension()!=null && service.getServiceExtension().getUsage()!=null)
				{
				subNetworkConnectionBuilder.addResourceDescribedBy(
						"Usage", service.getServiceExtension()
								.getUsage());
				}
				if(service.getAssociatedPorts()!=null && service.getAssociatedPorts().size()>0)
				{
					for(Port port:service.getAssociatedPorts())
					{
						if(port!=null && port.getPorttype()!=null && port.getPorttype().getName()!=null && port.getPorttype().getName().equalsIgnoreCase("VLAN Interface (T)"))
						{
							if(port.getNode()!=null && port.getNode().getNetworkroleobjects()!=null && port.getNode().getNetworkroleobjects().size()>0)
							{
								for(Networkroleobject networkroleObject:port.getNode().getNetworkroleobjects())
								{
									if(networkroleObject!=null && networkroleObject.getNetworkroleobject2networkrole()!=null && networkroleObject.getNetworkroleobject2networkrole().equalsIgnoreCase("BRAS"))
									{
										subNetworkConnectionBuilder
										.addAEndTps((TerminationPoint) buildTerminationPointFromPort(port.getTopLevelPort()
												));
									}
									
									//if(networkroleObject!=null && networkroleObject.getNetworkroleobject2networkrole()!=null && (networkroleObject.getNetworkroleobject2networkrole().equalsIgnoreCase("OLT")||((!(networkroleObject.getNetworkroleobject2networkrole()).equalsIgnoreCase("BRAS"))&&(!(networkroleObject.getNetworkroleobject2networkrole()).equalsIgnoreCase("OLT")))))
                                    if(networkroleObject!=null && networkroleObject.getNetworkroleobject2networkrole()!=null && (networkroleObject.getNetworkroleobject2networkrole().equalsIgnoreCase("OLT")))
                                    {
                                           subNetworkConnectionBuilder
                                           .addZEndTps((TerminationPoint) buildTerminationPointFromPort(port.getTopLevelPort()
                                                        ));
                                    }

								}
							}							
						}
					}
				}
			}


			else if (service.getServicetype()!=null && service.getServicetype().getName()!=null 
					&& ((!(service.getServicetype().getName()).equalsIgnoreCase("MEF EVC"))||(!(service.getServicetype().getName()).equalsIgnoreCase("MEF OVC"))))
			{
				if(service.getPort().isInstanciated())
				subNetworkConnectionBuilder.addZEndTps((TerminationPoint) buildTerminationPointFromPort(service.getPort()));
			}
			

			if (service.getSubscriber().isInstanciated()) {
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber(), service.getServiceExtension().getCustacctban()));
			}
			subNetworkConnectionBuilder
					.setOwnsResourceDetails(ownsResourceDetailsBuilder
							.getOwnsResourceDetails());

			if (includeRelationships) {
				if (service.getAssociatedServices().size() > 0
						|| service.getAssociatedCircuits().size() > 0) {
					ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();

					for (Service associatedService : service
							.getAssociatedServices()) {
						resourceRelationshipBuilder.buildResourceRelationship(
								null, null, null, null, null);
						resourceRelationshipBuilder
								.setCircuit(SearchServiceVOTransformation
										.buildServiceRelationship(associatedService));
						subNetworkConnectionBuilder
								.addResourceRelationship(resourceRelationshipBuilder
										.getResourceRelationship());
					}

					for (Circuit associatedCircuit : service
							.getAssociatedCircuits()) {
						resourceRelationshipBuilder.buildResourceRelationship(
								null, null, null, null, null);
						resourceRelationshipBuilder
								.setCircuit(SearchCircuitVOTransformation
										.buildCircuitRelationship(associatedCircuit));
						subNetworkConnectionBuilder
								.addResourceRelationship(resourceRelationshipBuilder
										.getResourceRelationship());
					}
				}
			}
		}

		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}

	private static UNICircuit buildUNIService(Service service, String level,
			String scope, Map<String, String> modifiers) throws Exception {
		boolean includeRelationships = false;
		boolean includeBanFromDwar = false;
		if(modifiers != null)
		{
			if (modifiers.containsKey("INCLUDERELATIONSHIPS") || modifiers.containsKey("IncludeBanFromDvar")) {
				
				/*if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE")) {
					includeRelationships = true;
				}
				if (modifiers.get("INCLUDEBANFROMDVAR").equalsIgnoreCase("TRUE"))
	            {
	                includeBanFromDwar = true;
	            }*/
				if("True".equalsIgnoreCase(modifiers.get("INCLUDERELATIONSHIPS")))
				{
					includeRelationships = true;
				}
				if("True".equalsIgnoreCase(modifiers.get("INCLUDEBANFROMDVAR")))
				{
					includeBanFromDwar = true;
				}
				if("True".equalsIgnoreCase(modifiers.get("IncludeBanFromDvar")))
				{
					includeBanFromDwar = true;
				}
			}
			
		}

		UNICircuitBuilder uniCircuitBuilder = new UNICircuitBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();

		if (scope.equalsIgnoreCase("BASIC")) {
			uniCircuitBuilder.buildUNICircuit(service.getName(), service
					.getServiceid(), null, "ARM", service.getServicetype()
					.getName(), service.getProvisionstatus().getName(), null,
					null, service.getFunctionalstatus().getName(), null, null,
					null, null, null, null, null, null, null, null, null);
		} else if(scope.equalsIgnoreCase("SUMMARY")){
			uniCircuitBuilder.buildUNICircuit(service.getName(), service.getServiceid(), null, "ARM", service.getServicetype().getName(),
					service.getProvisionstatus().getName(), null, null, service.getFunctionalstatus().getName(), 
					null, null, null, null, null,null, null, null, null, null, service.getServiceExtension().getBw(), null, null);
			if(service.getServiceExtension()!= null )
			uniCircuitBuilder.addResourceDescribedBy("ProtectRouting",(service.getServiceExtension().getProtectRouting()!=null)?service.getServiceExtension().getProtectRouting():"none");
			//Start -Call specific to serach ENNI and associated ENNI Link Service.			
			if(includeRelationships)
			{
				if (service.getAssociatedServices().size() > 0
						|| service.getAssociatedCircuits().size() > 0) {
					ResourceRelationshipBuilder enniLinkSvcresourceRelationshipBuilder=new ResourceRelationshipBuilder();
					for (Service associatedService : service
							.getAssociatedServices()) {
						
						if (associatedService.getService2servicetype().equals(
								"1900000004")) {
							enniLinkSvcresourceRelationshipBuilder
									.buildResourceRelationship(null, null,
											null, null, null);
							enniLinkSvcresourceRelationshipBuilder
									.setCircuit(buildServiceRelationship(associatedService));
							uniCircuitBuilder
									.addResourceRelationship(enniLinkSvcresourceRelationshipBuilder
											.getResourceRelationship());
						}
					}
				}

			}//End -Call specific to serach ENNI and associated ENNI Link Service.
				
			
		}
		else{
			uniCircuitBuilder.buildUNICircuit(service.getName(), service
					.getServiceid(), null, "ARM", service.getServicetype()
					.getName(), service.getProvisionstatus().getName(), null,
					null, service.getFunctionalstatus().getName(), service
							.getAlias1(), service.getAlias2(), service
							.getServiceExtension().getMco(), service
							.getServiceExtension().getServicemux(), service
							.getServiceExtension().getBundling(), service
							.getServiceExtension().getAllto1bundling(), service
							.getServiceExtension().getNccode(), service
							.getServiceExtension().getNcicode(), service
							.getServiceExtension().getSecncicode(), service
							.getServiceExtension().getSpeccode(), service
							.getServiceExtension().getBw(), service
							.getLastmodifieddate(), service.getCreateddate());
			// Get the service address location from CLC
			uniCircuitBuilder.addAddressDetails(SearchLocationVOTransformation.getCLCServiceAddressFromName(service.getName()));
			
			if(service.getServiceExtension()!= null )
				uniCircuitBuilder.addResourceDescribedBy("ProtectRouting",(service.getServiceExtension().getProtectRouting()!=null)?service.getServiceExtension().getProtectRouting():"none");

			NcNciBandwidth ncNciBandwidth =null;
			if(service != null && service.getServiceExtension() != null && (service.getServiceExtension().getNccode() != null || service.getServiceExtension().getNcicode() != null))
			{
				ncNciBandwidth=service.getNcNciBandwidth(service
					.getServiceExtension().getNccode(), service
					.getServiceExtension().getNcicode());
			}
			ServiceSpecification serviceSpecification = null;
			if (!StringHelper.isEmpty(service.getServiceExtension()
					.getSpeccode())) {
				serviceSpecification = service.getServiceSpecification(service
						.getServiceExtension().getSpeccode());
			}
			uniCircuitBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");
			uniCircuitBuilder.addResourceDescribedBy("MCO", service
					.getServiceExtension().getMco());
			uniCircuitBuilder.addResourceDescribedBy("CircuitSerialNumber",
					service.getServiceExtension().getCircuitserialnumber());
			uniCircuitBuilder.addResourceDescribedBy("CustomerSerialNumber",
					service.getServiceExtension().getCustomerserialnumber());
			uniCircuitBuilder.addResourceDescribedBy("FrameFormat", service
					.getServiceExtension().getFrameformat());
			uniCircuitBuilder.addResourceDescribedBy("IsDiverse", service
					.getServiceExtension().getIsDiverse());
			uniCircuitBuilder.addResourceDescribedBy("DiverseUNIID", service
					.getServiceExtension().getDiverseUniId());
			uniCircuitBuilder.addResourceDescribedBy("TSP", service
					.getServiceExtension().getTSP());

			uniCircuitBuilder.addResourceDescribedBy("HPCIndicator", service
					.getServiceExtension().getHpc());
			uniCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", service
					.getServiceExtension().getHpcexpirationdate());
			uniCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText",
					service.getServiceExtension().getExceptionHandlingInfo());
			uniCircuitBuilder.addResourceDescribedBy("ICO",
					service.getServiceExtension().getIco());
			uniCircuitBuilder.addResourceDescribedBy("OTC",
					service.getServiceExtension().getOtc());

			// Service type is probe type.
			uniCircuitBuilder.addResourceDescribedBy("ServiceType", service
					.getServiceExtension().getProbeType());
			if(!StringHelper.isEmpty(service.getServiceExtension().getMonitoringType()))
			{
				uniCircuitBuilder.addResourceDescribedBy("MonitoringType", service.getServiceExtension().getMonitoringType());
				PMMaxEVC pmMaxEvc=service.getPmMaxEvc(service.getServiceExtension().getMonitoringType().toUpperCase());
				if(pmMaxEvc != null && !StringHelper.isEmpty(pmMaxEvc.getMaxNumberOfEvcs()))
				{
					uniCircuitBuilder.addResourceDescribedBy("PMMaxEVC", pmMaxEvc.getMaxNumberOfEvcs());
				}
			}
			uniCircuitBuilder.addResourceDescribedBy("RateLimitType", service
					.getServiceExtension().getRatelimittype());
			uniCircuitBuilder.addResourceDescribedBy("FrameFormat", service
					.getServiceExtension().getFrameformat());
			uniCircuitBuilder.addResourceDescribedBy("FrameSize", service
					.getServiceExtension().getFramesize());
			if (ncNciBandwidth != null) {
				uniCircuitBuilder.addResourceDescribedBy(
						"BandwidthProfileType",
						ncNciBandwidth.getBandwidthProfileType());
				uniCircuitBuilder.addResourceDescribedBy("InterfaceType",
						ncNciBandwidth.getInterfaceType());
				uniCircuitBuilder.addResourceDescribedBy("PortType",
						ncNciBandwidth.getPortType());
				if (ncNciBandwidth.getBandwidthProfileType() != null
						&& ncNciBandwidth.getBandwidthProfileType()
								.equalsIgnoreCase("EwET")) {
					uniCircuitBuilder.addResourceDescribedBy("EWET", "Yes");
				}
			}
			if (serviceSpecification != null) {
				uniCircuitBuilder.addResourceDescribedBy(
						"Layer2ControlProtocolBridgeBlock",
						serviceSpecification.getProtocolBridgeBlock());
				uniCircuitBuilder.addResourceDescribedBy(
						"Layer2ControlProtocolGARPBlock",
						serviceSpecification.getProtocolGarpBlock());
				uniCircuitBuilder.addResourceDescribedBy(
						"Layer2ControlProtocolAllLANsBMG",
						serviceSpecification.getProtocolAllLansBmg());
			}
			if (service.getServiceExtension().getIsDiverse() != null
					&& service.getServiceExtension().getIsDiverse()
							.equalsIgnoreCase("Yes")) {
				uniCircuitBuilder.addResourceDescribedBy("DiversityType",
						"Circuit Diversity");
			}
			if(service != null && service.getPort()!=null && service.getPort().getTopLevelPort() != null)
				{
					Port topPort = service.getPort().getTopLevelPort();
					
					if(topPort !=null &&  topPort.getPort2porttype()!=null && topPort.getPort2porttype().equals("1900000003") && topPort.getPortExtension()!= null)
					{
						if (topPort.getPortExtension().getBandwidth() != null || topPort.getPortExtension().getFormfactor() != null) 
						{ 
							String transmissionRate="";
							if(topPort.getPortExtension().getBandwidth() != null)
								transmissionRate = transmissionRate	+ topPort.getPortExtension().getBandwidth();
						if(topPort.getPortExtension().getFormfactor()!=null)
								transmissionRate = transmissionRate + topPort.getPortExtension().getFormfactor();

							uniCircuitBuilder.addResourceDescribedBy("AllowablePortType",transmissionRate);
					}
					}
					else
					{
						if(topPort !=null && topPort.getBandwidthObject() != null && !StringHelper.isEmpty(topPort.getBandwidthObject().getName()))
							uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", topPort.getBandwidthObject().getName());
					}
				}
			uniCircuitBuilder.addResourceDescribedBy("Notes",
					service.getNotes());
			if (service.getName() != null && service.getName().length() > 5
					&& service.getName().length() >= 7) {
				if (service.getName().substring(5, 7).equalsIgnoreCase("GS")) {
					uniCircuitBuilder.addResourceDescribedBy("Jurisdiction",
							"Interstate");
				} else if (service.getName().substring(5, 7)
						.equalsIgnoreCase("FS")) {
					uniCircuitBuilder.addResourceDescribedBy("Jurisdiction",
							"Intrastate");
				}
			}
			/*
			 * 
			 * uniCircuitBuilder.addResourceDescribedBy("isPMFlag",service.
			 * getServiceExtension().getHpcexpirationdate());
			 */

			for (CircuitValuesMaxNum circuitValuesMaxNum : service.getCircuitValuesMaxNums())
			{
				uniCircuitBuilder.addResourceDescribedBy(circuitValuesMaxNum.getMaxColumnName(),circuitValuesMaxNum.getMaxValue());
			}
			
			if (service.getPort().isInstanciated()) 
			{
				uniCircuitBuilder.addZEndTps(buildTerminationPointFromPort(service.getPort()));
			}

			if (service.getSubscriber().isInstanciated())
			{				
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();					
				if(includeBanFromDwar)
				{
					String banFromDvar =  buildBanFromDvar(service.getName());						
					ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber(), banFromDvar));
				}
				else
				{
					ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber(), service.getServiceExtension().getCustacctban()));
				}
				if (includeRelationships)
					ownsResourceDetailsBuilder.addCustomerAgent(SearchSubscriberVOTransformation.buildCustomerAgentFromSubscriber(service.getSubscriber()));
			}
			uniCircuitBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder
					.getOwnsResourceDetails());

			double evcBandwidth = 0;
			if (includeRelationships) 
			{
				ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
				if (service.getAssociatedCircuits().size() > 0)
				{
					for (Circuit associatedCircuit : service.getAssociatedCircuits()) 
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setCircuit(SearchCircuitVOTransformation.buildCircuitRelationship(associatedCircuit));
						uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
				}
				if (service.getAssociatedServices().size() > 0
						|| service.getAssociatedCircuits().size() > 0) {
					for (Service associatedService : service
							.getAssociatedServices()) {
						if (!StringHelper.isEmpty(associatedService
								.getServiceExtension().getBw())) {
							evcBandwidth = evcBandwidth
									+ Double.parseDouble(associatedService
											.getServiceExtension().getBw());
						}
						//Main service is Probe UNI
						if(service.getService2servicetype().equals("1900000003"))
						{
							// associated service is not EVC/OVC
							 if (!associatedService.getService2servicetype().equals(
									"150030019") && !associatedService.getService2servicetype().equals(
											"150030018")) {
								resourceRelationshipBuilder
										.buildResourceRelationship(null, null,
												null, null, null);
								resourceRelationshipBuilder
										.setCircuit(buildServiceRelationship(associatedService));
								uniCircuitBuilder
										.addResourceRelationship(resourceRelationshipBuilder
												.getResourceRelationship());
							}
						}
						else{// When main service is not probe UNI
							
							//Associated service is probe UNI
							if (associatedService.getService2servicetype().equals(
									"1900000003")) {
								resourceRelationshipBuilder
										.buildResourceRelationship(null, null,
												null, null, null);
								resourceRelationshipBuilder
										.setCircuit(buildServiceRelationship(associatedService));
								uniCircuitBuilder
										.addResourceRelationship(resourceRelationshipBuilder
												.getResourceRelationship());
						}
						}
						//Code for adding associated Enni Link- Service 
						if (associatedService.getService2servicetype().equals( "1900000004"))
						{
							resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
							resourceRelationshipBuilder.setCircuit(buildServiceRelationship(associatedService,associatedService.getPort()));
							uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
						}
						// Associated service is EVC/OVC
						if(associatedService.getService2servicetype().equals( "150030019") || associatedService.getService2servicetype().equals( "150030018"))
						uniCircuitBuilder.addEVCCircuit(buildEVCCircuitRelationship(associatedService, service.getPort()));						
					}
				}

			}

			double uniBandwidth = 0;
			if (!StringHelper.isEmpty(service.getServiceExtension().getBw())) {
				uniBandwidth = Double.parseDouble(service
						.getServiceExtension().getBw());
			}
			double availableBandwidth=0;
			if(uniBandwidth != 0 && evcBandwidth != 0)
			 availableBandwidth = uniBandwidth - evcBandwidth;
			
			uniCircuitBuilder.addResourceDescribedBy("AvailableBandwidth",
					String.valueOf(availableBandwidth));
		}

		return uniCircuitBuilder.getUNICircuit();
	}

	private static EVCCircuit buildEVCService(Service service, String level,
			String scope, Map<String, String> modifiers) throws Exception {
		boolean includeRelationships = false;
		boolean includeBanFromDvar = false; 
				
		if (modifiers.containsKey("INCLUDERELATIONSHIPS")) {
			if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE")) {
				includeRelationships = true;
			}}
			
		if( modifiers.containsKey("CUSTOMERENTERPRISEOBJECTREFID")){
			includeBanFromDvar = true;
		}

		EVCCircuitBuilder evcCircuitBuilder = new EVCCircuitBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();

		if (scope.equalsIgnoreCase("BASIC")) {
			evcCircuitBuilder.buildEVCCircuit(service.getName(), service
					.getServiceid(), null, "ARM", service.getServicetype()
					.getName(), service.getProvisionstatus().getName(), null,
					null, null, null, service.getFunctionalstatus().getName(),
					null, null, null, null);
		} else {
			evcCircuitBuilder.buildEVCCircuit(service.getName(), service
					.getServiceid(), null, "ARM", service.getServicetype()
					.getName(), service.getProvisionstatus().getName(), null,
					null, service.getAlias1(), service.getAlias2(), service
							.getFunctionalstatus().getName(), service
							.getServiceExtension().getServicesubtype(), null,
					service.getServiceExtension().getCevlanidpreservation(),
					service.getServiceExtension().getCevlancospreservation(),
					service.getLastmodifieddate(), service.getCreateddate());

			evcCircuitBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");
			evcCircuitBuilder.addResourceDescribedBy("MCO", service
					.getServiceExtension().getMco());
			evcCircuitBuilder.addResourceDescribedBy("CircuitSerialNumber",
					service.getServiceExtension().getCircuitserialnumber());
			evcCircuitBuilder.addResourceDescribedBy("CustomerSerialNumber",
					service.getServiceExtension().getCustomerserialnumber());
			evcCircuitBuilder.addResourceDescribedBy("MTU", service
					.getServiceExtension().getEvcmtu());
			evcCircuitBuilder.addResourceDescribedBy("MTU", service
					.getServiceExtension().getOvcmtu());
			evcCircuitBuilder.addResourceDescribedBy("NCCode", service
					.getServiceExtension().getEvcovcnc());
			evcCircuitBuilder.addResourceDescribedBy("COSID", service
					.getServiceExtension().getCosId());
			evcCircuitBuilder.addResourceDescribedBy("UnicastFrameDelivery",
					service.getServiceExtension().getUnicastframedelivery());
			evcCircuitBuilder.addResourceDescribedBy("MulticastFrameDelivery",
					service.getServiceExtension().getMulticastframedelivery());
			evcCircuitBuilder.addResourceDescribedBy("BroadcastFrameDelivery",
					service.getServiceExtension().getBroadcastframedelivery());
			evcCircuitBuilder.addResourceDescribedBy("SVLANIDPreservation",
					service.getServiceExtension().getSvlanidpreservation());
			evcCircuitBuilder.addResourceDescribedBy("SVLANIDCosPreservation",
					service.getServiceExtension().getSvlancospreservation());
			evcCircuitBuilder.addResourceDescribedBy("ColorForwarding", service
					.getServiceExtension().getColorforwarding());
			evcCircuitBuilder.addResourceDescribedBy("EVCOVCReference", service
					.getServiceExtension().getEvcovcreference());
			evcCircuitBuilder.addResourceDescribedBy("HPCIndicator", service
					.getServiceExtension().getHpc());
			evcCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", service
					.getServiceExtension().getHpcexpirationdate());
			evcCircuitBuilder.addResourceDescribedBy("STI", service
					.getServiceExtension().getSti());
			/*evcCircuitBuilder.addResourceDescribedBy("VpnId", service
					.getServiceExtension().getVpnId());*/
			evcCircuitBuilder.addResourceDescribedBy("Asn", service
					.getServiceExtension().getAsn());
			evcCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText",
					service.getServiceExtension().getExceptionHandlingInfo());
			evcCircuitBuilder.addResourceDescribedBy("IsPMFlag", service
					.getServiceExtension().getIsPmFlag());
			evcCircuitBuilder.addResourceDescribedBy("Notes",
					service.getNotes());
			evcCircuitBuilder.addResourceDescribedBy("ControllingCompany",
					service.getServiceExtension().getControllingcompany());
			evcCircuitBuilder.addResourceDescribedBy("PMType",
					service.getServiceExtension().getPMType());
			evcCircuitBuilder.addResourceDescribedBy("AffiliateName",
					service.getServiceExtension().getRequestingAffiliate());
			//Adding VPN ID from serviceID
			List<Numberobject> numberobjectsList = service.getNumberObjectList();
			for (Numberobject numberObject : numberobjectsList)
			{
				Dimnumber dimNumber = numberObject.getDimnumber();
				List<Dimnumbertype> dimNumberType = Dimnumbertype.getDimNumberobjectList(dimNumber.getDimnumber2dimnumbertype());
				for (Dimnumbertype dimType : dimNumberType)
				{
					if (dimType.getName().equalsIgnoreCase("VPN-ID"))
					{							
						VPNExtension ext = new VPNExtension(dimNumber.getDimnumberid().toString());
						if(ext!=null)
							evcCircuitBuilder.addResourceDescribedBy("VPN-ID", dimNumber.getName());
					}
				}
			}

			SlaTargetTemplate slaTemplate = null;
			if (service.getServiceExtension().getSlaAgreementTemplate() != null) {
				slaTemplate = service.getSlaTargetTemplate(service
						.getServiceExtension().getSlaAgreementTemplate());
			}
			if (slaTemplate != null) {
				evcCircuitBuilder.addResourceDescribedBy("PmSlaTargetTemplate",
						slaTemplate.getTemplateName());
			}
			
			ResourceRelationshipBuilder relationshipBuilder = new ResourceRelationshipBuilder();
			relationshipBuilder.buildResourceRelationship(null, null, null,
					null, null);
						
			if (service.getAssociatedCircuits().size() > 0)
			{
				for (Circuit associatedCircuit : service.getAssociatedCircuits())
				{
					relationshipBuilder.buildResourceRelationship(null, null, null, null, null);
					relationshipBuilder.setCircuit(SearchCircuitVOTransformation.buildCircuitRelationship(associatedCircuit));
					evcCircuitBuilder.addResourceRelationship(relationshipBuilder.getResourceRelationship());
				}
			}
			
			for (CircuitValuesMaxNum circuitValuesMaxNum : service.getCircuitValuesMaxNums())
			{
				evcCircuitBuilder.addResourceDescribedBy(circuitValuesMaxNum.getMaxColumnName(),circuitValuesMaxNum.getMaxValue());
			}

			if (service.getSubscriber().isInstanciated())
			{
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(service.getSubscriber(), service.getServiceExtension().getCustacctban()));
				if (includeRelationships)
					ownsResourceDetailsBuilder.addCustomerAgent(SearchSubscriberVOTransformation.buildCustomerAgentFromSubscriber(service.getSubscriber()));
			}
			evcCircuitBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder
					.getOwnsResourceDetails());

			if (includeRelationships) {
				if (service.getAssociatedServices().size() > 0) {
					for (Service associatedService : service.getAssociatedServices()) {
						if (associatedService.getService2servicetype().equals(
								"150030010")
								|| associatedService.getService2servicetype()
										.equals("1900000003")
								|| associatedService.getService2servicetype()
										.equals("150030011"))
							evcCircuitBuilder.addComprisedOfUNICircuit(buildUNICircuitRelationship(associatedService, service,service.getAssociatedPorts(),includeBanFromDvar));
					}
				}
			}
		}

		return evcCircuitBuilder.getEVCCircuit();
	}

	private static ConnectionTerminationPoint buildTerminationPointFromPort(
			Port port) throws Exception {
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();

		connectionTerminationPointBuilder.buildConnectionTerminationPoint(null,
				null, null);
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null,
				null, null, null);

		logicalPhysicalResourceBuilder
				.addPhysicalDeviceAsDevice(SearchNodeVOTransformation
						.buildDeviceFromPort(port));
		connectionTerminationPointBuilder
				.addLogicalPhysicalResource(logicalPhysicalResourceBuilder
						.getLogicalPhysicalResource());
	connectionTerminationPointBuilder
				.addAccessPointAddress(SearchLocationVOTransformation
						.getCLCAddressFromLocation(port.getTopLevelPort()
								.getNode().getLocation()));

		return connectionTerminationPointBuilder
				.getConnectionTerminationPoint();
	}

	public static Point2PointCircuit buildServiceRelationship(Service service) {
		Point2PointCircuitBuilder point2PointCircuitBuilder = new Point2PointCircuitBuilder();

		point2PointCircuitBuilder.buildPoint2PointCircuit(service.getName(),
				service.getServiceid(), null, null, service.getServicetype()
						.getName(), service.getProvisionstatus().getName(),
				null, null, service.getServiceExtension().getBw(), service
						.getFunctionalstatus().getName(), service
						.getServiceExtension().getServicesubtype(), null, null,
				service.getCreateddate(), service.getLastmodifieddate());

		point2PointCircuitBuilder.addResourceDescribedBy("MCO", service
				.getServiceExtension().getMco());
		point2PointCircuitBuilder.addResourceDescribedBy("SpecCode", service
				.getServiceExtension().getSpeccode());
		point2PointCircuitBuilder.addResourceDescribedBy("NCCode", service
				.getServiceExtension().getNccode());
		point2PointCircuitBuilder.addResourceDescribedBy("NCICode", service
				.getServiceExtension().getNcicode());
		point2PointCircuitBuilder.addResourceDescribedBy("SECNCICode", service
				.getServiceExtension().getSecncicode());

		return point2PointCircuitBuilder.getPoint2PointCircuit();
	}
	
	//Overloaded method to add Associated port details for Associated services 
	public static Point2PointCircuit buildServiceRelationship(Service service,Port port)
	{
		Point2PointCircuitBuilder point2PointCircuitBuilder = new Point2PointCircuitBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder=new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder=new CustomerBuilder();

		point2PointCircuitBuilder.buildPoint2PointCircuit(service.getName(),service.getServiceid(), null, null, service.getServicetype().getName(),
				service.getProvisionstatus().getName(),	null, null, service.getServiceExtension().getBw(), service.getFunctionalstatus().getName(),
				service.getServiceExtension().getServicesubtype(), null, null,	service.getCreateddate(), service.getLastmodifieddate());

		point2PointCircuitBuilder.addResourceDescribedBy("MCO", service.getServiceExtension().getMco());
		point2PointCircuitBuilder.addResourceDescribedBy("SpecCode", service.getServiceExtension().getSpeccode());
		point2PointCircuitBuilder.addResourceDescribedBy("NCCode", service.getServiceExtension().getNccode());
		point2PointCircuitBuilder.addResourceDescribedBy("NCICode", service.getServiceExtension().getNcicode());
		point2PointCircuitBuilder.addResourceDescribedBy("SECNCICode", service.getServiceExtension().getSecncicode());

		if(service.getRelativename()!=null)
		{
			customerBuilder.buildCustomer(service.getRelativename(), null, null);
			ownsResourceDetailsBuilder.buildOwnsResourceDetails();
			ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
			point2PointCircuitBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
		}
		if (service.getPort().isInstanciated())
		{
			try
			{				
				point2PointCircuitBuilder.addZEndTps(buildTerminationPointFromPort(service.getPort()));
			} catch (Exception e) 
			{				
				LOG.info("Error in building Associated Port "+ e);
			}
		}
		return point2PointCircuitBuilder.getPoint2PointCircuit();
	}

	private static UNICircuit buildUNICircuitRelationship(Service uniService,Service evcService, 
			List<Port> evcServiceport, Boolean includeBanFromDvar) throws Exception {
		UNICircuitBuilder uniCircuitBuilder = new UNICircuitBuilder();
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();

		uniCircuitBuilder.buildUNICircuit(uniService.getName(), uniService.getServiceid(), null, null, uniService.getServicetype().getName(),
				uniService.getProvisionstatus().getName(), null,null, uniService.getFunctionalstatus().getName(), uniService.getAlias1(),
				uniService.getAlias2(), null, null, null,null, null, null, null, null, uniService.getServiceExtension().getBw(),
				uniService.getLastmodifieddate(), uniService.getCreateddate());

		if(uniService.getServiceExtension().getSpeccode()!=null)
			uniCircuitBuilder.addResourceDescribedBy("SpecCode", uniService.getServiceExtension().getSpeccode());
		if(uniService.getServiceExtension().getNccode()!=null)
			uniCircuitBuilder.addResourceDescribedBy("NCCode", uniService.getServiceExtension().getNccode());
		if(uniService.getServiceExtension().getNcicode()!=null)
			uniCircuitBuilder.addResourceDescribedBy("NCICode", uniService.getServiceExtension().getNcicode());
		if(uniService.getServiceExtension().getSecncicode()!=null)
			uniCircuitBuilder.addResourceDescribedBy("SECNCICode", uniService.getServiceExtension().getSecncicode());
		if(uniService.getServiceExtension().getMco()!=null)
			uniCircuitBuilder.addResourceDescribedBy("MCO", uniService.getServiceExtension().getMco());
		if(uniService.getServiceExtension().getHpc()!=null)
			uniCircuitBuilder.addResourceDescribedBy("HPCIndicator", uniService.getServiceExtension().getHpc());
		if(uniService.getServiceExtension().getHpcexpirationdate()!=null)
			uniCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", uniService.getServiceExtension().getHpcexpirationdate());
		if(uniService.getServiceExtension().getExceptionHandlingInfo()!=null)
			uniCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText",uniService.getServiceExtension().getExceptionHandlingInfo());
		if(uniService.getServiceExtension().getIco()!=null)
			uniCircuitBuilder.addResourceDescribedBy("ICO",uniService.getServiceExtension().getIco());
		if(uniService.getNotes()!=null)
			uniCircuitBuilder.addResourceDescribedBy("Notes", uniService.getNotes());

		if(uniService.getPort() != null && uniService.getPort().isInstanciated())
		{
			Port UniPort = uniService.getPort();		
			if( UniPort.getPort2porttype().equals("1900000003") && UniPort.getPortExtension()!= null)
			{
				if (UniPort.getPortExtension().getBandwidth() != null || UniPort.getPortExtension().getFormfactor() != null) 
				{ 
					String transmissionRate="";
					if(UniPort.getPortExtension().getBandwidth() != null)
						transmissionRate = transmissionRate + UniPort.getPortExtension().getBandwidth();
					if(UniPort.getPortExtension().getFormfactor()!=null)
						transmissionRate = transmissionRate + UniPort.getPortExtension().getFormfactor();

					uniCircuitBuilder.addResourceDescribedBy("AllowablePortType",transmissionRate);
			}
			}
			else
			{
				if(UniPort.getBandwidthObject() != null && !StringHelper.isEmpty(UniPort.getBandwidthObject().getName()))
					uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", UniPort.getBandwidthObject().getName());
			}
		}
		if (uniService.getSubscriber().isInstanciated())
		{	
			
			if(includeBanFromDvar)
			{
				String banFromDvar =  buildBanFromDvar(uniService.getName());
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(uniService.getSubscriber(), banFromDvar));
			}else{

				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(uniService.getSubscriber(), uniService.getServiceExtension().getCustacctban()));
			}			
		}
		
		uniCircuitBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());

		// Get the service address location from CLC
		//uniCircuitBuilder.addAddressDetails(SearchLocationVOTransformation.getCLCServiceAddressFromName(uniService.getName()));

		resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
		//Populating VLI Port info in  ConnectionTermnation point
		for (Port evcPort : evcServiceport)
		{			
			//Checking TopLevelPort of EVC is equal to physical port of UNi
			if(uniService.getPort().isInstanciated() && evcPort.isInstanciated())
			{
			if( uniService.getPort()!= null && evcPort.getTopLevelPort()!=null && uniService.getPort().getPortid().equals(evcPort.getTopLevelPort().getPortid()))
			{
				Port vlanPort = evcPort;				


				connectionTerminationPointBuilder.buildConnectionTerminationPoint(vlanPort.getName(), vlanPort.getDescription(), uniService
						.getFunctionalstatus().getName(), vlanPort.getCreateddate(), vlanPort.getLastmodifieddate());
				connectionTerminationPointBuilder.setResourceAlias(vlanPort.getAlias1(),vlanPort.getAlias2());

				remarkBuilder.buildRemark(vlanPort.getNotes(), "Notes");
				connectionTerminationPointBuilder.addRemarks(remarkBuilder.getRemarks());

				if(vlanPort != null && vlanPort.getPortExtension() != null)
				{
					connectionTerminationPointBuilder.addResourceDescribedBy("Function",vlanPort.getPortExtension().getFunction());
					connectionTerminationPointBuilder.addResourceDescribedBy("NCICode",vlanPort.getPortExtension().getEvcncicode());
					connectionTerminationPointBuilder.addResourceDescribedBy("Bandwidth",vlanPort.getPortExtension().getBw());
					connectionTerminationPointBuilder.addResourceDescribedBy("SLAAgreementTemplate", vlanPort.getPortExtension().getSlaAgreementTemplate());
					connectionTerminationPointBuilder.addResourceDescribedBy("MileageBetweenEndpoints", vlanPort.getPortExtension().getMilageBetweenEndpoints());
		}
				connectionTerminationPointBuilder.setlrStatus(vlanPort.getProvisionstatus().getName());

				if (uniService.getAssociatedServices().size() > 0)
				{
					for (Service associatedService : uniService.getAssociatedServices())
					{
						if (associatedService.getServiceid().equals(evcService.getServiceid())) 
						{
							for (CoSBundle coSBundle : buildQoSBandwidth(associatedService, uniService.getPort())) 
							{
								connectionTerminationPointBuilder.addQoSBandwidth(coSBundle);
					}
				}
			}
		}
		MaintenanceEndPointBuilder maintenanceEndPointBuilder = new MaintenanceEndPointBuilder();

				List<Numberobject> numbers = vlanPort.getNumberObjectList();
				for (Numberobject number : numbers)
				{
					Dimnumber dimNumber = number.getDimnumber();
					DimnumberExtension numExtn =dimNumber.getDimnumberExtension();
					List<Dimnumbertype> dimNumberType = Dimnumbertype.getDimNumberobjectList(dimNumber.getDimnumber2dimnumbertype());
						for (Dimnumbertype dimType : dimNumberType)
						{
							if (dimType.getName().equalsIgnoreCase("MEP - ID")) 
							{
								MEPExtension ext = new MEPExtension(dimNumber.getDimnumberid().toString());
								
								maintenanceEndPointBuilder.buildMepEndPoint(ext.getMegLevel(), ext.getPrimaryvlanid(),ext.getDirection(), ext.getMacaddress(),
										ext.getCcienabled(), ext.getCcmltmpriority(),ext.getLowestprioritydefect(),ext.getFaultalarmtime(), ext.getFaultresettime(),dimNumber.getName());
								connectionTerminationPointBuilder.addMaintenanceEndPoint(maintenanceEndPointBuilder.getMaintenanceEndPoint());
							} 
							else if (dimType.getName().equalsIgnoreCase("S-VLAN") || (!StringHelper.isEmpty( numExtn.getFunction()) 
											&& numExtn.getFunction().equalsIgnoreCase("S-VLAN") )) 
							{
								connectionTerminationPointBuilder.addResourceDescribedBy("S-VLAN", dimNumber.getName());
							} 
							else if (dimType.getName().equalsIgnoreCase("CE-VLAN") || (!StringHelper.isEmpty( numExtn.getFunction()) 
											&&	numExtn.getFunction().equalsIgnoreCase("CE-VLAN") ))
							{
								connectionTerminationPointBuilder.addResourceDescribedBy("CE-VLAN", dimNumber.getName());
							}
						}

				}
				resourceRelationshipBuilder.addTerminationPoint(connectionTerminationPointBuilder.getConnectionTerminationPoint());
				uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());

		}
		}
		}


		for (CircuitValuesMaxNum circuitValuesMaxNum : uniService.getCircuitValuesMaxNums())
		{
			uniCircuitBuilder.addResourceDescribedBy(circuitValuesMaxNum.getMaxColumnName(),circuitValuesMaxNum.getMaxValue());
		}

		if (uniService.getPort().isInstanciated()) {
			uniCircuitBuilder.addZEndTps(buildTerminationPointFromPort(uniService.getPort()));
		}

		return uniCircuitBuilder.getUNICircuit();
	}

	private static EVCCircuit buildEVCCircuitRelationship(Service service,
			Port uniPort) {
		EVCCircuitBuilder evcCircuitBuilder = new EVCCircuitBuilder();

		ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
		// MaintenanceEndPointBuilder maintenanceEndPointBuilder = new
		// MaintenanceEndPointBuilder();

		evcCircuitBuilder.buildEVCCircuit(service.getName(), service
				.getServiceid(), null, null,
				service.getServicetype().getName(), service
						.getProvisionstatus().getName(), null, null, service
						.getAlias1(), service.getAlias2(), service
						.getFunctionalstatus().getName(), service
						.getServiceExtension().getServicesubtype(), null, null,
				null, service.getLastmodifieddate(), service.getCreateddate());

		evcCircuitBuilder.addResourceDescribedBy("MCO", service
				.getServiceExtension().getMco());
		evcCircuitBuilder.addResourceDescribedBy("NCCode", service
				.getServiceExtension().getNccode());
		evcCircuitBuilder.addResourceDescribedBy("HPCIndicator", service
				.getServiceExtension().getHpc());
		evcCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", service
				.getServiceExtension().getHpcexpirationdate());
		/*evcCircuitBuilder.addResourceDescribedBy("VpnId", service
				.getServiceExtension().getVpnId());*/
		evcCircuitBuilder.addResourceDescribedBy("Asn", service
				.getServiceExtension().getAsn());
		evcCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText",
				service.getServiceExtension().getExceptionHandlingInfo());
		evcCircuitBuilder.addResourceDescribedBy("Notes", service.getNotes());
		resourceRelationshipBuilder.buildResourceRelationship(null, null, null,
				null, null);
		evcCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder
				.getResourceRelationship());

		// Adding VPNID from serviceId
		List<Numberobject> numberobjectsList = service.getNumberObjectList();
		for (Numberobject numberObject : numberobjectsList)
		{
			Dimnumber dimNumber = numberObject.getDimnumber();
			List<Dimnumbertype> dimNumberType = Dimnumbertype.getDimNumberobjectList(dimNumber.getDimnumber2dimnumbertype());
			for (Dimnumbertype dimType : dimNumberType)
			{
				if (dimType.getName().equalsIgnoreCase("VPN-ID"))
				{							
					VPNExtension ext = new VPNExtension(dimNumber.getDimnumberid().toString());
					if(ext!=null)
						evcCircuitBuilder.addResourceDescribedBy("VPN-ID", dimNumber.getName());
				}
			}
		}

		MaintenanceEndPointBuilder maintenanceEndPointBuilder = new MaintenanceEndPointBuilder();
		List<Port> port = service.getAssociatedPorts();
		for (Port p : port) {
			ConnectionTerminationPointBuilder connectionTerminationPointBuilder = buildCTP(
					service, p);
			for (CoSBundle coSBundle : buildQoSBandwidth(service, uniPort)) {
				connectionTerminationPointBuilder.addQoSBandwidth(coSBundle);

			}
			/*
			 * resourceRelationshipBuilder.addTerminationPoint(
			 * connectionTerminationPointBuilder
			 * .getConnectionTerminationPoint());
			 */

			List<Numberobject> numberobjectss = p.getNumberObjectList();
			for (Numberobject numberObject : numberobjectss) {
				Dimnumber dimNumber = numberObject.getDimnumber();
				List<Dimnumbertype> dimNumberType = Dimnumbertype
						.getDimNumberobjectList(dimNumber
								.getDimnumber2dimnumbertype());
				for (Dimnumbertype dimType : dimNumberType) {
					if (dimType.getName().equalsIgnoreCase("CE-VLAN")) {
						connectionTerminationPointBuilder
								.addResourceDescribedBy("CE-VLAN",
										dimNumber.getName());
					} else if (dimType.getName().equalsIgnoreCase("MEP - ID")) {
						MEPExtension ext = new MEPExtension(dimNumber
								.getDimnumberid().toString());
						maintenanceEndPointBuilder.buildMepEndPoint(
								ext.getMegLevel(), ext.getPrimaryvlanid(),
								ext.getDirection(), ext.getMacaddress(),
								ext.getCcienabled(), ext.getCcmltmpriority(),
								ext.getLowestprioritydefect(),
								ext.getFaultalarmtime(),
								ext.getFaultresettime());
						connectionTerminationPointBuilder
								.addMaintenanceEndPoint(maintenanceEndPointBuilder
										.getMaintenanceEndPoint());

					} else if (dimType.getName().equalsIgnoreCase("S-VLAN")) {
						connectionTerminationPointBuilder
								.addResourceDescribedBy("S-VLAN",
										dimNumber.getName());
					}

				}

			}
			resourceRelationshipBuilder
					.addTerminationPoint(connectionTerminationPointBuilder
							.getConnectionTerminationPoint());

		}

		evcCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder
				.getResourceRelationship());

		// /////////////
		for (CircuitValuesMaxNum circuitValuesMaxNum : service
				.getCircuitValuesMaxNums()) {
			evcCircuitBuilder.addResourceDescribedBy(
					circuitValuesMaxNum.getMaxColumnName(),
					circuitValuesMaxNum.getMaxValue());
		}

		return evcCircuitBuilder.getEVCCircuit();
	}

	private static List<CoSBundle> buildQoSBandwidth(Service evcService,
			Port uniPort) {

		CosBundleBuilder cosBundleABuilder = new CosBundleBuilder();
		CosBundleBuilder cosBundleBBuilder = new CosBundleBuilder();
		CosBundleBuilder cosBundleCBuilder = new CosBundleBuilder();
		CosBundleBuilder cosBundleDBuilder = new CosBundleBuilder();

		BandwidthProfileBuilder bandwidthProfileABuilder = new BandwidthProfileBuilder();
		BandwidthProfileBuilder bandwidthProfileBBuilder = new BandwidthProfileBuilder();
		BandwidthProfileBuilder bandwidthProfileCBuilder = new BandwidthProfileBuilder();
		BandwidthProfileBuilder bandwidthProfileDBuilder = new BandwidthProfileBuilder();

		List<CoSBundle> coSBundleList = new ArrayList<CoSBundle>();

		Boolean classA = false;
		Boolean classB = false;
		Boolean classC = false;
		Boolean classD = false;

		for (Port associatedPort : evcService.getAssociatedPorts()) {
			if (associatedPort.getTopLevelPort().getPortid()
					.equals(uniPort.getPortid())) {
				for (Parameterset parameterset : associatedPort
						.getParametersetList()) {
					for (Parametersetversion parametersetversion : parameterset
							.getParametersetversionList()) {
						for (Parameterinstance parameterinstance : parametersetversion
								.getParameterinstanceList()) {
							for (Parameterinstancevalue parameterinstancevalue : parameterinstance
									.getParameterinstancevalueList()) {
								String cosID = " ";
								if (parameterinstance.getParameterdefinition()
										.getName().equalsIgnoreCase("CoS ID")) {
									/*
									 * if(parameterinstancevalue.getIntegervalue(
									 * ).equals("0")) cosID="_"; else
									 * if(parameterinstancevalue
									 * .getIntegervalue().equals("1"))
									 * cosID="TOS"; else
									 * if(parameterinstancevalue
									 * .getIntegervalue().equals("2"))
									 * cosID="DSCP"; else
									 * if(parameterinstancevalue
									 * .getIntegervalue().equals("3"))
									 * cosID="COS";
									 */
									cosID = Enumeration.getCosIdValue(
											parameterinstance
													.getParameterdefinition()
													.getName().toUpperCase(),
											parameterinstancevalue
													.getIntegervalue());
								}
								if (parameterinstancevalue
										.getCompositesequence() != null) {
									if (parameterinstancevalue
											.getCompositesequence().equals("0")) {

										classA = true;
										if (cosBundleABuilder.getCoSBundle() == null) {
											cosBundleABuilder.buildCoSBundle(
													parameterset.getName(), null, null, null);
											bandwidthProfileABuilder
													.buildBandwidthProfile(
															null, null, null,
															null);

										}

										addCOSBundleValues(
												cosBundleABuilder,
												bandwidthProfileABuilder,
												parameterinstancevalue,
												parameterinstance
														.getParameterdefinition(),
												cosID);
									}
									if (parameterinstancevalue
											.getCompositesequence().equals("1")) {

										classB = true;
										if (cosBundleBBuilder.getCoSBundle() == null) {
											cosBundleBBuilder.buildCoSBundle(
													parameterset.getName(), null, null, null);
											bandwidthProfileBBuilder
													.buildBandwidthProfile(
															null, null, null,
															null);
										}
										addCOSBundleValues(
												cosBundleBBuilder,
												bandwidthProfileBBuilder,
												parameterinstancevalue,
												parameterinstance
														.getParameterdefinition(),
												cosID);
									}
									if (parameterinstancevalue
											.getCompositesequence().equals("2")) {
										classC = true;
										if (cosBundleCBuilder.getCoSBundle() == null) {
											cosBundleCBuilder.buildCoSBundle(
													parameterset.getName(), null, null, null);
											bandwidthProfileCBuilder
													.buildBandwidthProfile(
															null, null, null,
															null);
										}
										addCOSBundleValues(
												cosBundleCBuilder,
												bandwidthProfileCBuilder,
												parameterinstancevalue,
												parameterinstance
														.getParameterdefinition(),
												cosID);
									}
									if (parameterinstancevalue
											.getCompositesequence().equals("3")) {
										classD = true;
										if (cosBundleDBuilder.getCoSBundle() == null) {
											cosBundleDBuilder.buildCoSBundle(
													parameterset.getName(), null, null, null);
											bandwidthProfileDBuilder
													.buildBandwidthProfile(
															null, null, null,
															null);
										}
										addCOSBundleValues(
												cosBundleDBuilder,
												bandwidthProfileDBuilder,
												parameterinstancevalue,
												parameterinstance
														.getParameterdefinition(),
												cosID);

									}

								}
							}
						}
					}
				}
			}
		}

		if (classA) {
			cosBundleABuilder.addBandwidthProfile(bandwidthProfileABuilder
					.getBandwidthProfile());
			coSBundleList.add(cosBundleABuilder.getCoSBundle());
		}
		if (classB) {
			cosBundleBBuilder.addBandwidthProfile(bandwidthProfileBBuilder
					.getBandwidthProfile());
			coSBundleList.add(cosBundleBBuilder.getCoSBundle());
		}
		if (classC) {
			cosBundleCBuilder.addBandwidthProfile(bandwidthProfileCBuilder
					.getBandwidthProfile());
			coSBundleList.add(cosBundleCBuilder.getCoSBundle());
		}
		if (classD) {
			cosBundleDBuilder.addBandwidthProfile(bandwidthProfileDBuilder
					.getBandwidthProfile());
			coSBundleList.add(cosBundleDBuilder.getCoSBundle());
		}

		return coSBundleList;
	}

	private static CosBundleBuilder addCOSBundleValues(
			CosBundleBuilder cosBundleBuilder,
			BandwidthProfileBuilder bandwidthProfileBuilder,
			Parameterinstancevalue parameterinstancevalue,
			Parameterdefinition parameterdefinition, String cosID) {
		if (parameterdefinition.getName().equalsIgnoreCase("LOS Name"))
			cosBundleBuilder
					.setLOSName(parameterinstancevalue.getStringvalue());

		if (parameterdefinition.getName().equalsIgnoreCase("CoS Value"))
			cosBundleBuilder.setCosValue(parameterinstancevalue
					.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("CoS ID")) {
			if(cosID!=null)
			{
				if(cosID.equalsIgnoreCase("802.1p"))
				{
					cosBundleBuilder.setCosID("COS");
				}
				else
				{
					cosBundleBuilder.setCosID(cosID);
		}
			}

		}

		if (parameterdefinition.getName().equalsIgnoreCase("BW"))
			bandwidthProfileBuilder.setBandwidth(parameterinstancevalue
					.getStringvalue());

		if (parameterdefinition.getName().equalsIgnoreCase("CIR"))
			bandwidthProfileBuilder
					.setCommittedInformationRate(parameterinstancevalue
							.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("CBS"))
			bandwidthProfileBuilder
					.setCommittedBurstSize(parameterinstancevalue
							.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("EIR"))
			bandwidthProfileBuilder
					.setExcessInformationRate(parameterinstancevalue
							.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("EBS"))
			bandwidthProfileBuilder.setExcessBurstSize(parameterinstancevalue
					.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("Coupling Flag"))
			bandwidthProfileBuilder.setCouplingFlag(parameterinstancevalue
					.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("Color Mode"))
			bandwidthProfileBuilder.setColorMode(parameterinstancevalue
					.getIntegervalue());

		if (parameterdefinition.getName().equalsIgnoreCase("CoS"))
			bandwidthProfileBuilder.setCoS(parameterinstancevalue
					.getIntegervalue());

		return cosBundleBuilder;
	}

	private static ConnectionTerminationPointBuilder buildCTP(Service service,
			Port port) {
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		connectionTerminationPointBuilder.buildConnectionTerminationPoint(port
				.getName(), port.getDescription(), port.getFunctionalstatus()
				.getName(), port.getCreateddate(), port.getLastmodifieddate());
		connectionTerminationPointBuilder.setResourceAlias(port.getAlias1(),
				port.getAlias2());

		remarkBuilder.buildRemark(port.getNotes(), "Notes");
		connectionTerminationPointBuilder
				.addRemarks(remarkBuilder.getRemarks());

		connectionTerminationPointBuilder.addResourceDescribedBy("Function",
				port.getPortExtension().getFunction());
		connectionTerminationPointBuilder.addResourceDescribedBy("NCICode",
				port.getPortExtension().getEvcncicode());// need to confirm
		connectionTerminationPointBuilder.addResourceDescribedBy("Bandwidth",
				port.getPortExtension().getBw());
		connectionTerminationPointBuilder.addResourceDescribedBy(
				"SLAAgreementTemplate", port.getPortExtension()
						.getSlaAgreementTemplate());
		connectionTerminationPointBuilder.addResourceDescribedBy(
				"MileageBetweenEndpoints", port.getPortExtension()
						.getMilageBetweenEndpoints());
		connectionTerminationPointBuilder.setlrStatus(port.getProvisionstatus()
				.getName());// need to confirm

		return connectionTerminationPointBuilder;
	}

	public static SearchResourceResponseDocument transformToCIMForQueryServiceRouteForGPON(
			VOSearchHolder searchHolder) throws Exception {

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder
				.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		boolean datafound = false;

		searchHolder.getModifiers();
		String customerName = searchHolder.getModifiers().get("CUSTOMERNAME");
		String customerBAN = searchHolder.getModifiers().get("CUSTOMERBAN");
		String serviceName = searchHolder.getCommonName();
		String cVoIPTN = searchHolder.getModifiers().get("CVOIPTN");
		List<Service> services = null;
		String query = null;
		List<String> customerBANIDList = new ArrayList<String>();

		
		String serviceQuery = " 1=1 ";
		if (serviceName != null) {
			serviceQuery = serviceQuery + " AND SERVICE.name like '"
					+ serviceName + "'";
		}

		if (customerBAN != null) {
			customerBANIDList = getCustomerBANList(customerBAN);
		}

		if (customerName != null) {
			List<String> customerNameIdList = getCustomerBANListByCustName(customerName);
			customerBANIDList.addAll(customerNameIdList);
		}

		if (customerBANIDList != null && customerBANIDList.size() > 0) {

			String customerIdList = null;
			int i = 1;

			for (String customerBANId : customerBANIDList) {
				if (i == 1) {
					customerIdList = customerBANId;
					i++;
				} else {
					customerIdList = customerIdList + ", " + customerBANId;
				}
			}

			serviceQuery = serviceQuery
					+ " AND SERVICE.SERVICE2SUBSCRIBER IN ("
					+ customerIdList
					+ ") AND SERVICE.service2servicetype in (1920000002, 1920000001)";
		}

		if (cVoIPTN != null) {

			serviceQuery = serviceQuery
					+ " AND SERVICEID in (select serviceid from  EXT_HSI_SERVICE where CVOIP_TN ='"
					+ cVoIPTN + "')";
		}

		System.out.println("query : " + serviceQuery);

		services = Service.getServiceListByQuery(serviceQuery);

		if (cVoIPTN != null) {
			query = "SERVICEID in (select serviceid from  EXT_IPTV_SERVICE where DTN IN (select DTN from  EXT_HSI_SERVICE where CVOIP_TN like '"
					+ cVoIPTN + "'))";
			System.out.println("query : " + query);
			List<Service> iptpList = Service.getServiceListByQuery(query);

			if (iptpList != null) {
				services.addAll(iptpList);
			}

		}
		

		if (null != services && services.size() == 1) {
			return transformToCIM(services, searchHolder);
			//datafound = true;
		} else {
			for (Service service : services) {
				searchResponseDetailsBuilder
						.addCircuit(buildServiceForQueryServiceRouteForGPON(service));
				datafound = true;
			}
		}

		if (!datafound) {
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(
				searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder
				.addSearchResourceResponse(searchResourceResponseBuilder
						.getSearchResourceResponse());

		if (LOG.isInfoEnabled()) {
			LOG.info(searchResourceResponseDocumentBuilder
					.getSearchResourceResponseDocument().toString());
		}

		return searchResourceResponseDocumentBuilder
				.getSearchResourceResponseDocument();
	}

	public static List<String> getCustomerBANList(String customerBAN) {
		Subscriber customer = new Subscriber();
		String query = " name like '" + customerBAN + "'";
		List<String> customerList = customer.getSubscriberIdListByQuery(query);
		return customerList;
	}

	public static List<String> getCustomerBANListByCustName(String customerName) {
		// here need to call clc
		String customerBAN = null;
		return getCustomerBANList(customerBAN);

	}

	/*public static List<String> getcVoIPTNList(String cVoIPTN) {
		Subscriber customer = new Subscriber();
		String query = "SERVICEID in (select serviceid from  EXT_HSI_SERVICE where CVOIP_TN in '"
				+ cVoIPTN + "')";
		List<String> customerList = customer.getSubscriberIdListByQuery(query);

		return customerList;
	}*/

	private static SubNetworkConnection buildServiceForQueryServiceRouteForGPON(
			Service service) throws Exception {

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		subNetworkConnectionBuilder.buildSubNetworkConnection(
				service.getName(), null, null, "ARM", service.getServicetype()
						.getName(), null, null, null, null, null, null, null);
		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}
	
	private static String buildBanFromDvar(String circuitId) 
	{
		LOG.debug("Calling DVAR Service  for " + circuitId);		
		String banFromDvar = null;
		DvarWebServiceResponseDocument  generatedResponse;
		Object dvarRequest;	
		try
		{
			dvarRequest = DVARLookupServiceHelper.getDVARLookupService().callTransformFromSid(circuitId);			
			generatedResponse = (DvarWebServiceResponseDocument) DVARLookupServiceHelper.getDVARLookupService().callConnector(dvarRequest);			
			banFromDvar = extractBanFromDVARResponse(generatedResponse);
		}catch (Exception e) {
			LOG.info("Failed to Load ban from DVAR  " + e);

		}      

		return banFromDvar;
	} 

	private static String extractBanFromDVARResponse (Object dvarResponse) 
	{
		Customer customer=  ((Customer)((SearchResourceResponseDocumentBuilder) dvarResponse).getSearchResourceResponseDocument().getSearchResourceResponse().
				getSearchResponseDetailsArray(0).getPartyArray(0).getHasPartyRolesList().get(0));
		
		String ban = customer.getCustomerPossesesArray(0).getID();
		
			return ban;
	}	

}
