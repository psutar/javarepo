package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;



public class PreferredDeviceModel extends AbstractReadOnlyTable {

	

	private static final long serialVersionUID = 1L;

private static final Log LOG = LogFactory.getLog(DeviceModelDefaultParams.class);
	
	private static final String PREFERRED_DEVICE_MODEL_ID = "PREFERRED_DEVICE_MODEL_ID";
	private static final String START_DEVICE_NODEDEF = "START_DEVICE_NODEDEF";
	private static final String END_DEVICE_NODEDEF = "END_DEVICE_NODEDEF";
	
	
	
	
	public PreferredDeviceModel()
	{
		super();
		this.tableName = "PREFERRED_DEVICE_MODEL";
	}
	
	public PreferredDeviceModel(String PREFERRED_DEVICE_MODEL_ID)
	{
		this();
		primaryKey.setValue(PREFERRED_DEVICE_MODEL_ID);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	@Override
	public void populateModel() {
		fields.put(PREFERRED_DEVICE_MODEL_ID, new Field(PREFERRED_DEVICE_MODEL_ID, Field.TYPE_NUMERIC));
		fields.put(START_DEVICE_NODEDEF, new Field(START_DEVICE_NODEDEF, Field.TYPE_VARCHAR));
		fields.put(END_DEVICE_NODEDEF, new Field(END_DEVICE_NODEDEF, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(PREFERRED_DEVICE_MODEL_ID));
	}

	/*public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public static String getPreferredDeviceModelId() {
		return PREFERRED_DEVICE_MODEL_ID;
	}

	public static String getStartDeviceNodedef() {
		return START_DEVICE_NODEDEF;
	}

	public static String getEndDeviceNodedef() {
		return END_DEVICE_NODEDEF;
	}
	
	public String getPreferredDeviceModelObject(String nodeDef)
	{*/
		
	
	public void setPreferredDeviceModelId(String PreferredDeviceModelId)
	{
		setField(PREFERRED_DEVICE_MODEL_ID,PreferredDeviceModelId);
	}

	public String getPreferredDeviceModelId()
	{
		return getFieldAsString(PREFERRED_DEVICE_MODEL_ID);
	}
	
	public void setStartDeviceNodedef(String StartDeviceNodedef)
	{
		setField(START_DEVICE_NODEDEF,StartDeviceNodedef);
	}

	public String getStartDeviceNodedef()
	{
		return getFieldAsString(START_DEVICE_NODEDEF);
	}
	
	public void setEndDeviceNodedef(String EndDeviceNodedef)
	{
		setField(END_DEVICE_NODEDEF,EndDeviceNodedef);
	}

	public String getPreferredDeviceModelObject(String nodeDef)
	{
		/*return getFieldAsString(END_DEVICE_NODEDEF);
	}*/
		
		//String query = " START_NODEDEF_NAME   and  END_NODEDEF_NAME  in select NODEDEF_NAME from DeviceModel_Default_Params where  MAX_DOWNSTREAM_RATE =" + DownstreamBandwidth +" and  MAX_UPSTREAM_RATE =" + UpstreamBandwidth ;
		String query = "START_DEVICE_NODEDEF =  '"+ nodeDef + "'";
		System.out.println(query);
		return getPreferredDeviceModelByQuery(query);
	}

	public String getPreferredDeviceModelByQuery(String query)
	{		
		String ontModel = null;
		PreferredDeviceModel preferredDeviceModel = new PreferredDeviceModel();
		List<Map<String,Object>> PreferredDeviceModelList = preferredDeviceModel.getFullRecordsByQuery(query);
		
		if(null != PreferredDeviceModelList && PreferredDeviceModelList.size() > 0 ){
			for (Map<String,Object> preferredDeviceModelMap : PreferredDeviceModelList)
			{
				ontModel = preferredDeviceModelMap.get(END_DEVICE_NODEDEF).toString();				
				return ontModel;
			}
		}
		 
		return ontModel;
	}
}
