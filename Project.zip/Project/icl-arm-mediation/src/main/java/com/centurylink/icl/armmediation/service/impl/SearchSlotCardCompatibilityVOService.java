package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.centurylink.icl.armmediation.armaccessobject.ShelfDetails;
import com.centurylink.icl.armmediation.armaccessobject.SlotCardDetails;
import com.centurylink.icl.armmediation.armaccessobject.SlotDetails;
import com.centurylink.icl.armmediation.valueobjects.objects.CardCompatibility;
import com.centurylink.icl.armmediation.valueobjects.objects.CardType;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.builder.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValueList;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class SearchSlotCardCompatibilityVOService {

	private static final Log LOG = LogFactory.getLog(SearchSlotCardCompatibilityVOService.class);
	private static final String SHELF = "SHELF";
	private static final String CARDTYPE = "CARDTYPE";
	
	public SlotCardDetails getSlotCardCompatibilityDetails(SearchResourceRequestDocument requestObject,HashMap<String, Object> map )
	{
		SearchResourceDetails searchResourceDetails = requestObject.getSearchResourceRequest().getSearchResourceDetails();
		
		Node nodeTemplate = new Node();
		nodeTemplate.setName(searchResourceDetails.getCommonName());
		Node node = new Node(nodeTemplate);
		ResourceCharacteristicValueList resourceCharacteristicValueShelfList = null;
		ResourceCharacteristicValueList resourceCharacteristicValueCardTypeList = null;
		for(ResourceCharacteristicValueList resourceCharacteristicValueList :searchResourceDetails.getResourceCharacteristicValueListList())
		{
			if(SHELF.equalsIgnoreCase(resourceCharacteristicValueList.getResourceCharacteristicValueList().get(0).getCharacteristicName()))
				resourceCharacteristicValueShelfList = resourceCharacteristicValueList;
			else if(CARDTYPE.equalsIgnoreCase(resourceCharacteristicValueList.getResourceCharacteristicValueList().get(0).getCharacteristicName()))
				resourceCharacteristicValueCardTypeList = resourceCharacteristicValueList;
		}
		String cardTypeNames = null;
		List<String> cardTypeNamesList = new ArrayList<String>();
		SlotCardDetails slotCardDetails = new SlotCardDetails();
		slotCardDetails.setCommonName(searchResourceDetails.getCommonName());	
		if(null != resourceCharacteristicValueCardTypeList && resourceCharacteristicValueCardTypeList.sizeOfResourceCharacteristicValueArray() > 0)
		{
			for (ResourceCharacteristicValue resourceCharacteristicValue : resourceCharacteristicValueCardTypeList.getResourceCharacteristicValueList())
			{
				cardTypeNamesList.add("'"+resourceCharacteristicValue.getCharacteristicValue()+"'");
			}
			cardTypeNames = cardTypeNamesList.toString();
			cardTypeNames = cardTypeNames.substring(1, cardTypeNames.length() - 1);
		}
		ShelfDetails shelfDetails = null;
		List<ShelfDetails> shelfDetailsList = new ArrayList<ShelfDetails>();	
		for(com.iclnbi.iclnbiV200.ResourceCharacteristicValue resourceCharacteristicValue : resourceCharacteristicValueShelfList.getResourceCharacteristicValueList())
		{
			if(SHELF.equalsIgnoreCase(resourceCharacteristicValue.getCharacteristicName()))
			{
				shelfDetails = new ShelfDetails();
				shelfDetails.setCommonName(resourceCharacteristicValue.getCharacteristicValue());
				List<SlotDetails> slotDetailsList = new ArrayList<SlotDetails>();
				for(ResourceCharacteristicValue resourceCharValueReferences : resourceCharacteristicValue.getResourceCharValueReferencesList())
				{
					SlotDetails slotDetails = new SlotDetails();
					if(null != node.getCreateddate())
					{
						slotDetails.setCommonName(resourceCharValueReferences.getCharacteristicValue());
						if(!StringHelper.isEmpty(cardTypeNames))
						{
							cardTypeNamesList = getCardTypeNameList(node.getNodeid(), resourceCharacteristicValue.getCharacteristicValue(), resourceCharValueReferences.getCharacteristicValue(),cardTypeNames);
							slotDetails.setCardTypesList(cardTypeNamesList);
						}
						else
						{
							cardTypeNamesList = getCardTypeNameList(node.getNodeid(), resourceCharacteristicValue.getCharacteristicValue(), resourceCharValueReferences.getCharacteristicValue(),null);
							slotDetails.setCardTypesList(cardTypeNamesList);
						}
					}
					slotDetailsList.add(slotDetails);
				}
				shelfDetails.setSlotDetails(slotDetailsList);
			}
			shelfDetailsList.add(shelfDetails);
		}
		slotCardDetails.setShelfDetails(shelfDetailsList);
		
		return slotCardDetails;
	}
	
	private List<String> getCardTypeNameList(String nodeId,String shelfName,String slotName,String cardTypeNames)
	{
			Shelf shelfTemplate = new Shelf();
			shelfTemplate.setShelf2node(nodeId);
			shelfTemplate.setName(shelfName);
			Shelf shelf = new Shelf(shelfTemplate);
			if(null != shelf.getCreateddate())
			{
				return getDetailsFromShelf(shelf.getShelfid(),slotName,cardTypeNames);
			}
			return null;
	
	}
	
	private List<String> getDetailsFromShelf(String shelfId,String slotName,String cardTypeNames)
	{
		Slot slotTemplate = new Slot();
		slotTemplate.setSlot2shelf(shelfId);
		slotTemplate.setName(slotName);
		Slot slot = new Slot(slotTemplate);
		if(null != slot.getCreateddate())
		{
			return getDetailsFromSlot(slot.getSlot2slottype(),cardTypeNames);
		}
		return null;
	}
	

	private List<String> getDetailsFromSlot(String slot2slottype,String cardTypeNames)
	{
		CardCompatibility cardCompatibilityTemplate = new CardCompatibility();
		cardCompatibilityTemplate.setCardcompatibility2slottype(slot2slottype);
		CardCompatibility cardCompatibility = new CardCompatibility();
		@SuppressWarnings("static-access")
		List<CardCompatibility> cardCompatibilityList = cardCompatibility.getCardCompatibilityList(cardCompatibilityTemplate);
		
		if(null != cardCompatibilityList && cardCompatibilityList.size() > 0)
		{
			return getDetailsFromCardCompatibility(cardCompatibilityList,cardTypeNames);
		}
		return null;
	}
	
	private List<String> getDetailsFromCardCompatibility(List<CardCompatibility> cardCompatibilityList,String cardTypeNames)
	{
		List<String> cardcompatibility2cardtypeList = new ArrayList<String>();
		for(CardCompatibility workCardCompatibility : cardCompatibilityList)
		{
			cardcompatibility2cardtypeList.add(workCardCompatibility.getCardcompatibility2cardtype());
		}
		String cardTypeIds = cardcompatibility2cardtypeList.toString();
		cardTypeIds = cardTypeIds.substring(1, cardTypeIds.length() - 1);
		return getDetailsFromCardType(cardTypeIds, cardTypeNames);
	}
	
	private List<String> getDetailsFromCardType(String CartTypeIdsList,String cardTypeNames)
	{
		List<CardType> cardTypeList = null;
		if(!StringHelper.isEmpty(cardTypeNames))
		{
			cardTypeList = CardType.getCardTypeListByQuery("CARDTYPEID IN (" + CartTypeIdsList +") AND NAME IN ("+cardTypeNames + ")");
		}
		else
		{
			cardTypeList = CardType.getCardTypeListByQuery("CARDTYPEID IN (" + CartTypeIdsList + ")");
		}
		List<String> cardTypeNameList = new ArrayList<String>();
		for(CardType cardType :  cardTypeList)
		{
			cardTypeNameList.add(cardType.getName());
		}
		return cardTypeNameList;
	}
	
}
