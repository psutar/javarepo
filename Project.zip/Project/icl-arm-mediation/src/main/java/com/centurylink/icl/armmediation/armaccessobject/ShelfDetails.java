package com.centurylink.icl.armmediation.armaccessobject;

import java.util.List;

public class ShelfDetails {
	
	private String commonName; //Shelf Name
	private List<SlotDetails> slotDetails;
	
	public String getCommonName()
	{
		return commonName;
	}
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	
	public List<SlotDetails> getSlotDetails()
	{
		return slotDetails;
	}
	public void setSlotDetails(List<SlotDetails> slotDetails)
	{
		this.slotDetails = slotDetails;
	}

}
