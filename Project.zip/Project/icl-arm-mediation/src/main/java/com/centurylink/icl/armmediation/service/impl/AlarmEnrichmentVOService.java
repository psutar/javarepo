package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.transformation.AlarmEncrichmentVOTransformation;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.iclnbi.iclnbiV200.Card;
import com.iclnbi.iclnbiV200.CardOnCardDetails;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.Rack;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.Shelf;
import com.iclnbi.iclnbiV200.Slot;


public class AlarmEnrichmentVOService {
	private static final Log LOG = LogFactory.getLog(AlarmEnrichmentVOService.class);
	public AlarmEnrichmentVOService()
	{

	}

	public List<Circuit> getCircuits(SearchResourceRequestDocument request) throws Exception 
	{
		List<Circuit> circuits = new ArrayList<Circuit>();
		List<String> portIDList=new ArrayList<String>();
		PhysicalDevice device= getDevice(request);
		if(device!=null)
		{
			portIDList=getPortIDList(device);

		}

		if(portIDList!=null && portIDList.size()>0)
		{
			StringBuffer subQuery=new StringBuffer();
			int count=0; 
			for(String portId:portIDList)
			{
				if(count==0)
				{
					subQuery.append(portId);
				}
				else
				{
					subQuery.append(","+portId);
				}
				count++;
			}

			String query="(PORTA.PARENTPORT2PORT IN ("+subQuery.toString()+")"+"OR PORTZ.PARENTPORT2PORT IN ("+subQuery.toString()+")) AND CIRCUIT.CIRCUIT2CIRCUITTYPE=1900000003";
			circuits =Circuit.getCircuitListByQuery(query,true);
		}
		if(circuits!=null && circuits.size()>0)
		{
		LOG.info("CktList"+circuits.toString());
		}
		

		return circuits;
	}

	//change
	public List<Service> getServices(SearchResourceRequestDocument request) throws Exception 
	{
		List<Service> service = new ArrayList<Service>();
		List<String> portIDList=new ArrayList<String>();
		PhysicalDevice device= getDevice(request);
		if(device!=null)
		{
			portIDList=getPortIDList(device);

		}

		if(portIDList!=null && portIDList.size()>0)
		{
			StringBuffer subQuery=new StringBuffer();
			int count=0; 
			for(String portId:portIDList)
			{

				if(count==0)
				{
					subQuery.append(portId);
				}
				else
				{
					subQuery.append(","+portId);
				}
				count++;
			}

			String query="(SERVICEOBJECT.SERVICEOBJECT2OBJECT IN ("+subQuery.toString()+") and SERVICEOBJECT.SERVICEOBJECT2DIMOBJECT=4)";
			service =Service.getServiceListByQuery(query,true);

		}
		if(service!=null && service.size()>0)
		{
		LOG.info("ServiceList"+service.toString());
		}
		return service;
	}


	protected List<String> getPortIDList (PhysicalDevice device)
	{

		List<String> portIDList=new ArrayList<String>();
		Card card=null;

		if(device!=null)
		{
			//For Device Ports
			if((device.getConsistsOfRackList().size()==0 || (device.getConsistsOfRackList().size()>0 && device.getConsistsOfRackList().get(0).getConsistsOfShelfList().size()==0)) && device.getHasPortsList()!=null && device.getHasPortsList().size()>0 && device.getHasPortsList().get(0)!=null && device.getHasPortsList().get(0).getObjectID()!=null)
			{
				for (PhysicalPort hasPort : device.getHasPortsList())
					{
						portIDList.add(hasPort.getObjectID());
					}				
			}

			// For Card Ports
			else if(device.getConsistsOfRackList().size()>0)
			{

				for(Rack rack:device.getConsistsOfRackList())
				{
					if(rack.getConsistsOfShelfList()!=null && rack.getConsistsOfShelfList().size()>0)
					{
						for(Shelf shelf:rack.getConsistsOfShelfList())
						{
							if(shelf.getConsistsOfSlotList()!=null && shelf.getConsistsOfSlotList().size()>0)
							{
								for(Slot slot:shelf.getConsistsOfSlotList())
								{
									if(slot.getHasCard()!=null)
									{
										card=slot.getHasCard();
									}
									if(card!=null)
									{
										// When there is no Child Card
										if(card.getCardOnCardDetailsList().size()==0 && card.getPhysicalPortList() !=null && card.getPhysicalPortList().size()>0 && card.getPhysicalPortList().get(0)!=null && card.getPhysicalPortList().get(0).getObjectID()!=null)
										{				
											for (PhysicalPort physiaclPort : card.getPhysicalPortList())
											{
												portIDList.add(physiaclPort.getObjectID());
											}											
										}
										// When there is Child Card 
										else if(card.getCardOnCardDetailsList()!=null && card.getCardOnCardDetailsList().size()>0)
										{
											for(CardOnCardDetails childCard:card.getCardOnCardDetailsList())
											{
												if(childCard.getCardList()!=null)
												{
													for (Card childCard1 : childCard.getCardList())
													{
														for (PhysicalPort childCardPort : childCard1.getPhysicalPortList())
														{
															portIDList.add(childCardPort.getObjectID());
														}
													}													
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return portIDList;
	}
	protected PhysicalDevice getDevice(SearchResourceRequestDocument request) throws Exception {


		LOG.info("Transformed Request :"+request);
		VOSearchHolder searchHolder= new VOSearchHolder(request);
		DeviceVOService deviceVOService=new DeviceVOService();

		PhysicalDevice physicalDevice=AlarmEncrichmentVOTransformation.buildDevice(deviceVOService.getDevices(searchHolder).get(0), searchHolder);
		
		if(physicalDevice!=null)
		System.out.println(physicalDevice.toString());
		return physicalDevice;
		

	}
}
