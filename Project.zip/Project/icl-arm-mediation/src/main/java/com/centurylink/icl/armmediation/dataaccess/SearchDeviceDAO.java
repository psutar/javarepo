package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;
import java.util.Map;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.armaccessobject.ARMLocation;
import com.centurylink.icl.armmediation.armaccessobject.ARMNode;
import com.centurylink.icl.armmediation.armaccessobject.ARMOrderedNetworkRoleList;
import com.centurylink.icl.armmediation.armaccessobject.ARMPort;
import com.centurylink.icl.armmediation.armaccessobject.ARMSFP;
import com.centurylink.icl.armmediation.armaccessobject.ARMShelf;
import com.centurylink.icl.armmediation.armaccessobject.ARMSlot;

public interface SearchDeviceDAO
{

	List<ARMNode> getNodesList(String query) throws Exception;

	List<ARMShelf> getShelfList(String query) throws Exception;

	Map<Long, List<ARMSlot>> getSlotList(String query) throws Exception;

	List<ARMCard> getCardList(String query) throws Exception;

	Map<Long, List<ARMPort>> getPortList(String query) throws Exception;

	List<ARMSFP> getSFPList(String query) throws Exception;

	List<ARMPort> getPortOnDeviceList(String query) throws Exception;

	List<ARMLocation> getlocationList(String query) throws Exception;

	List<ARMDevice> getDeviceList(String query) throws Exception;
	
	List<ARMLocation> getLocSubLocList(String query) throws Exception;

	List<ARMDevice> getAllDeviceList(String query, Boolean checkSubscriber) throws Exception;
	
	List<Long> getDeviceIdsBySubscriber(String subscriber) throws Exception;
	
	List<String> getNetworkRole(String query) throws Exception;
	
	List<ARMOrderedNetworkRoleList> getOrderedNetworkRoleList(String query) throws Exception;

	List<ARMDevice> getDeviceinTopology(String query) throws Exception;
	
	//List<ARMCard> getSFPListForCards(String query) throws Exception;
}
