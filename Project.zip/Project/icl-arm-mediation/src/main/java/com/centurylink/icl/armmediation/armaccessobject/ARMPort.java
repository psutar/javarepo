package com.centurylink.icl.armmediation.armaccessobject;

public class ARMPort
{

	private long	portId;
	private String	portFunction;
	private String	ifNum;
	private String PLUGGABLEIFNUM;
	private String	bandWidth;
	private String	waveLength;
	private String	pluggableType;
	private long	port2Card;
	private String	commonName;
	private String	aliasName;
	private String	resourceSubType;
	private String	prStatus;
	private String	dPEA;
	private String  resourceType;
	private String reservationdId; 
	private String portNumber; 
	private String status;
	private String ifName;	
	private String transmissionRate;
	private String transmissionRatePluggable;
	
	public String getReservationdId() {
		return reservationdId;
	}

	public String getPLUGGABLEIFNUM() {
		return PLUGGABLEIFNUM;
	}

	public void setPLUGGABLEIFNUM(String pLUGGABLEIFNUM) {
		PLUGGABLEIFNUM = pLUGGABLEIFNUM;
	}

	public String getIfNum() {
		return ifNum;
	}

	public void setIfNum(String ifNum) {
		this.ifNum = ifNum;
	}

	public void setReservationdId(String reservationdId) {
		this.reservationdId = reservationdId;
	}

	public long getPortId()
	{
		return portId;
	}

	public void setPortId(long portId)
	{
		this.portId = portId;
	}

	public String getPortFunction()
	{
		return portFunction;
	}

	public void setPortFunction(String portFunction)
	{
		this.portFunction = portFunction;
	}

	public String getBandWidth()
	{
		return bandWidth;
	}

	public void setBandWidth(String bandWidth)
	{
		this.bandWidth = bandWidth;
	}

	public String getWaveLength()
	{
		return waveLength;
	}

	public void setWaveLength(String waveLength)
	{
		this.waveLength = waveLength;
	}

	public String getPluggableType()
	{
		return pluggableType;
	}

	public void setPluggableType(String pluggableType)
	{
		this.pluggableType = pluggableType;
	}

	public long getPort2Card()
	{
		return port2Card;
	}

	public void setPort2Card(long port2Card)
	{
		this.port2Card = port2Card;
	}

	public String getCommonName()
	{
		return commonName;
	}

	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}

	public String getAliasName()
	{
		return aliasName;
	}

	public void setAliasName(String aliasName)
	{
		this.aliasName = aliasName;
	}

	public String getResourceSubType()
	{
		return resourceSubType;
	}

	public void setResourceSubType(String resourceSubType)
	{
		this.resourceSubType = resourceSubType;
	}

	public String getPrStatus()
	{
		return prStatus;
	}

	public void setPrStatus(String prStatus)
	{
		this.prStatus = prStatus;
	}

	public String getDPEA()
	{
		return dPEA;
	}

	public void setDPEA(String dPEA)
	{
		this.dPEA = dPEA;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}
   
   public String getPortNumber() {
		return portNumber;
	}
	
   public void setPortNumber(String portNumber) 
   {
		this.portNumber = portNumber;
	}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getIfName() {
	return ifName;
}

public void setIfName(String ifName) {
	this.ifName = ifName;
}

public String getTransmissionRate() {
	return transmissionRate;
}

public void setTransmissionRate(String transmissionRate) {
	this.transmissionRate = transmissionRate;
}

public String getTransmissionRatePluggable() {
	return transmissionRatePluggable;
}

public void setTransmissionRatePluggable(String transmissionRatePluggable) {
	this.transmissionRatePluggable = transmissionRatePluggable;
}
   
   
}
