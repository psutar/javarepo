package com.centurylink.icl.armmediation.dataaccess.impl;


import javax.sql.DataSource;


import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;


import com.centurylink.icl.armmediation.dataaccess.LocationDeviceClliDao;



public class LocationDeviceClliDaoImpl implements LocationDeviceClliDao{
	private JdbcTemplate jdbcTemplate;
	
	private static final String LOOKUP_CLLI_SQL = "SELECT DEVICE_CLLI_SEQUENCE FROM LOCATION_CLLI_DEVICES WHERE ARM_LOCATION_CLLI = ?";
	private static final String INSERT_SQL = "INSERT INTO LOCATION_CLLI_DEVICES (DEVICE_CLLI_SEQUENCE,ARM_LOCATION_CLLI) VALUES (?, ?)";
	private static final String UPDATE_SQL = "UPDATE LOCATION_CLLI_DEVICES SET DEVICE_CLLI_SEQUENCE = ? WHERE ARM_LOCATION_CLLI = ?";
	
			
	public LocationDeviceClliDaoImpl(DataSource dataSource)
		{
				this.jdbcTemplate = new JdbcTemplate(dataSource);
		}
		
	
	public int LookupClliSequence(String locationCLLI)
	{
		int noClli = -1;
		try{
			
			int seqNo =  this.jdbcTemplate.queryForInt(LOOKUP_CLLI_SQL, new Object[] {locationCLLI});
			return seqNo;
		}
		catch(EmptyResultDataAccessException  exp) {
			
			return noClli;
		
		}
	}
	
	
	public void InsertClliSequence(int deviceClliSeq,String locationCLLI) {
		 this.jdbcTemplate.update(INSERT_SQL, new Object[] {deviceClliSeq,locationCLLI});
	}
	

	public void UpdateClliSequence(int deviceClliSeq,String locationCLLI) {
		 this.jdbcTemplate.update(UPDATE_SQL, new Object[] {deviceClliSeq,locationCLLI});
	}
}
