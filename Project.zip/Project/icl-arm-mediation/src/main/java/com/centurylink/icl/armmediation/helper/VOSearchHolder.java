package com.centurylink.icl.armmediation.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.ValidationRule;

public class VOSearchHolder {

	private String entity;
	private String level;
	private String scope;
	private String commonName;
	private String objectID;
	private Map<String, String> modifiers;
	private Map<String, ValidationRule> filterCriteraList;
	
	public VOSearchHolder() 
	{}
	
	public VOSearchHolder(SearchResourceRequestDocument request) throws Exception
	{
		SearchResourceDetails details = request.getSearchResourceRequest().getSearchResourceDetails();
		
		if (!StringHelper.isEmpty(details.getEntity()))
			this.entity = details.getEntity().toUpperCase();
		
		if (!StringHelper.isEmpty(details.getLevel()))
			this.level = details.getLevel().toUpperCase();
		
		if (StringHelper.isEmpty(details.getScope()))
			this.scope = "SUMMARY";
		else
			this.scope = details.getScope().toUpperCase();
		
		this.commonName = details.getCommonName();
		this.objectID = details.getObjectID();
		
		this.modifiers = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValueAsMap(details.getResourceCharacteristicValueList());
		
		parseFilterCriteria(details.getFilterCriteriaList());
	}
	
	private void parseFilterCriteria(List<ValidationRule> validationRuleList) {

		this.filterCriteraList = new HashMap<String, ValidationRule>();
		
		for	(ValidationRule rule:validationRuleList)
		{
			if (StringHelper.isEmpty(rule.getOperation()) || rule.getOperation().equalsIgnoreCase("ENTITYFILTER"))
			{
				if (this.filterCriteraList.containsKey("ENTITYFILTER"))
					throw new ICLRequestValidationException("Request can not contain more than 1 EntityFilter");
				else
					this.filterCriteraList.put("ENTITYFILTER", rule);
			} else {
				if (this.filterCriteraList.containsKey(rule.getOperation().toUpperCase()))
					throw new ICLRequestValidationException("Request can not contain more than 1 FilterCritera of the same type");
				else
					this.filterCriteraList.put(rule.getOperation().toUpperCase(), rule);
			}
		}
	}

	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public Map<String, String> getModifiers() {
		return modifiers;
	}
	public void setModifiers(Map<String, String> modifiers) {
		this.modifiers = modifiers;
	}
	public Map<String, ValidationRule> getFilterCriteraList() {
		return filterCriteraList;
	}
	public void setFilterCriteraList(Map<String, ValidationRule> filterCriteraList) {
		this.filterCriteraList = filterCriteraList;
	}
	
	@Override
	public String toString()
	{
		String response = "";
		
		response += "--------------------------\n";
		response += "Entity: " + this.entity + "\n";
		response += "Level: " + this.level + "\n";
		response += "Scope: " + this.scope + "\n";
		response += "CommonName: " + this.commonName + "\n";
		response += "ObjectId: " + this.objectID + "\n";
		response += "--------------------------\n";
		response += "\tMODIFIERS\n";
		for (String key : this.modifiers.keySet())
		{
			response += key + " = " + this.modifiers.get(key) + "\n";
		}
		response += "--------------------------\n";
		response += "\tFILTERCRITERIAS\n";
		for (String key : this.filterCriteraList.keySet())
		{
			response += key + "\n";
		}
		response += "--------------------------\n";
		
		return response;
	}
	
}
