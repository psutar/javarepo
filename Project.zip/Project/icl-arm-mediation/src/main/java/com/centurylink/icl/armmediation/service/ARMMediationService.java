package com.centurylink.icl.armmediation.service;

import java.util.HashMap;

import com.centurylink.icl.component.IConnector;

public interface ARMMediationService extends IConnector
{

	public Object call(HashMap<String, Object> map) throws Exception;
}
