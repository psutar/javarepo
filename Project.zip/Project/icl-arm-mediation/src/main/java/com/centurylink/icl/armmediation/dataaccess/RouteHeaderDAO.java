package com.centurylink.icl.armmediation.dataaccess;

import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.RouteHeader;

public interface RouteHeaderDAO 
{
	public void insert(RouteHeader routeHeader);
	public Long getRouteHeaderId(String routeName);
	public List<String> getLikeRouteNames(String routeName);
	public RouteHeader lookupRouteHeaderWithoutDetails(Long routeHeaderId);
	public RouteHeader lookupRouteHeaderWithoutDetails(String routeName);
	public RouteHeader lookupRouteByNidDeviceName(String nidDeviceName, RouteDetailDAO routeDetailDao);
	public List<RouteHeader> searchRouteByNid(String nidDeviceName, RouteDetailDAO routeDetailDao);
	public List<RouteHeader> lookupRouteHeaderWithDetails(String routeName, RouteDetailDAO routeDetailDao);
	public void delete(Long routeHeaderId);
	public void updateRouteName(String routeName, Long routeHeaderId);
	public void update(String routeName, String nidDeviceName, Long routeHeaderId);
}
