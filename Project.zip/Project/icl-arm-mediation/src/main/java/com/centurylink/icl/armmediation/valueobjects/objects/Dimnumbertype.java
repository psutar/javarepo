package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Dimnumbertype extends AbstractReadOnlyTable {

	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String CHILDRENALLOCATION = "CHILDRENALLOCATION";
	private static final String CHILDRENSORTING = "CHILDRENSORTING";
	private static final String UNIQUENESS = "UNIQUENESS";
	private static final String SPAN = "SPAN";
	private static final String PACKAGEPARMS = "PACKAGEPARMS";
	private static final String PACKAGENAME = "PACKAGENAME";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String CLASS = "CLASS";
	private static final String BEHAVIOUR = "BEHAVIOUR";
	private static final String DIMNUMBERTYPE2BROWSERBITMAP = "DIMNUMBERTYPE2BROWSERBITMAP";
	private static final String DIMNUMBERTYPE2GRAPHICSBITMAP = "DIMNUMBERTYPE2GRAPHICSBITMAP";
	private static final String TABLENAME = "TABLENAME";
	private static final String NAME = "NAME";
	private static final String DIMNUMBERTYPEID = "DIMNUMBERTYPEID";

	public Dimnumbertype()
	{
		super();
		this.tableName = "DIMNUMBERTYPE";
	}

	public Dimnumbertype(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Dimnumbertype> getDimnumbertypeListByQuery(String query)
	{
		Dimnumbertype dimnumbertype = new Dimnumbertype();
		List<Dimnumbertype> dimnumbertypeList = new ArrayList<Dimnumbertype>();
		List<Map<String,Object>> foundDimnumbertypeList = dimnumbertype.getRecordsByQuery(query);

		for (Map<String,Object> dimnumbertypeMap : foundDimnumbertypeList)
		{
			Dimnumbertype workDimnumbertype = new Dimnumbertype(dimnumbertypeMap.get(DIMNUMBERTYPEID).toString());
			dimnumbertypeList.add(workDimnumbertype);
		}
		return dimnumbertypeList;
	}

	public static List<Dimnumbertype> getDimNumberobjectList(String dim2NumberType)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(dim2NumberType))
		{
			query = DIMNUMBERTYPEID + " = '" +  dim2NumberType + "'";
			connector = " AND ";
		}
		
		
		return getDimnumbertypeListByQuery(query);
	}
	
	@Override
	public void populateModel()
	{
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(CHILDRENALLOCATION, new Field(CHILDRENALLOCATION, Field.TYPE_VARCHAR));
		fields.put(CHILDRENSORTING, new Field(CHILDRENSORTING, Field.TYPE_VARCHAR));
		fields.put(UNIQUENESS, new Field(UNIQUENESS, Field.TYPE_VARCHAR));
		fields.put(SPAN, new Field(SPAN, Field.TYPE_VARCHAR));
		fields.put(PACKAGEPARMS, new Field(PACKAGEPARMS, Field.TYPE_VARCHAR));
		fields.put(PACKAGENAME, new Field(PACKAGENAME, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(BEHAVIOUR, new Field(BEHAVIOUR, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBERTYPE2BROWSERBITMAP, new Field(DIMNUMBERTYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(DIMNUMBERTYPE2GRAPHICSBITMAP, new Field(DIMNUMBERTYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(DIMNUMBERTYPEID, new Field(DIMNUMBERTYPEID, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(DIMNUMBERTYPEID));
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setChildrenallocation(String childrenallocation)
	{
		setField(CHILDRENALLOCATION,childrenallocation);
	}

	public String getChildrenallocation()
	{
		return getFieldAsString(CHILDRENALLOCATION);
	}

	public void setChildrensorting(String childrensorting)
	{
		setField(CHILDRENSORTING,childrensorting);
	}

	public String getChildrensorting()
	{
		return getFieldAsString(CHILDRENSORTING);
	}

	public void setUniqueness(String uniqueness)
	{
		setField(UNIQUENESS,uniqueness);
	}

	public String getUniqueness()
	{
		return getFieldAsString(UNIQUENESS);
	}

	public void setSpan(String span)
	{
		setField(SPAN,span);
	}

	public String getSpan()
	{
		return getFieldAsString(SPAN);
	}

	public void setPackageparms(String packageparms)
	{
		setField(PACKAGEPARMS,packageparms);
	}

	public String getPackageparms()
	{
		return getFieldAsString(PACKAGEPARMS);
	}

	public void setPackagename(String packagename)
	{
		setField(PACKAGENAME,packagename);
	}

	public String getPackagename()
	{
		return getFieldAsString(PACKAGENAME);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setBehaviour(String behaviour)
	{
		setField(BEHAVIOUR,behaviour);
	}

	public String getBehaviour()
	{
		return getFieldAsString(BEHAVIOUR);
	}

	public void setDimnumbertype2browserbitmap(String dimnumbertype2browserbitmap)
	{
		setField(DIMNUMBERTYPE2BROWSERBITMAP,dimnumbertype2browserbitmap);
	}

	public String getDimnumbertype2browserbitmap()
	{
		return getFieldAsString(DIMNUMBERTYPE2BROWSERBITMAP);
	}

	public void setDimnumbertype2graphicsbitmap(String dimnumbertype2graphicsbitmap)
	{
		setField(DIMNUMBERTYPE2GRAPHICSBITMAP,dimnumbertype2graphicsbitmap);
	}

	public String getDimnumbertype2graphicsbitmap()
	{
		return getFieldAsString(DIMNUMBERTYPE2GRAPHICSBITMAP);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setDimnumbertypeid(String dimnumbertypeid)
	{
		setField(DIMNUMBERTYPEID,dimnumbertypeid);
	}

	public String getDimnumbertypeid()
	{
		return getFieldAsString(DIMNUMBERTYPEID);
	}


}