package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.centurylink.icl.armmediation.dataaccess.SearchServiceDAO;

public class SearchServiceDAOImpl implements SearchServiceDAO
{
	private JdbcTemplate jdbcTemplate;
	
	public SearchServiceDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public static final String QUERY_SQL = "select SERVICEID from SERVICE, SUBSCRIBER where SERVICE.SERVICE2SUBSCRIBER = SUBSCRIBER.SUBSCRIBERID and SUBSCRIBER.NAME = ?";
	@Override
	public List<Long> getServiceIdsBySubscriber(String subscriber) throws Exception
	{
		final List<Long> longList = this.jdbcTemplate.query(QUERY_SQL, new Object[] {subscriber}, new RowMapper<Long>()
		{
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				Long id = rs.getLong("SERVICEID");
				return id;
			}
		});
		return longList;
	}
   

}
