package com.centurylink.icl.armmediation.valueobjects.objects;


import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Shelftype extends AbstractReadOnlyTable {

	private static final String SHELFTYPEID = "SHELFTYPEID";
	private static final String NAME = "NAME";
	private static final String TABLENAME = "TABLENAME";
	private static final String SHELFTYPE2GRAPHICSBITMAP = "SHELFTYPE2GRAPHICSBITMAP";
	private static final String SHELFTYPE2BROWSERBITMAP = "SHELFTYPE2BROWSERBITMAP";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";

	public Shelftype()
	{
		super();
		this.tableName = "SHELFTYPE";
	}

	public Shelftype(String shelftypeId)
	{
		this();
		primaryKey.setValue(shelftypeId);
		
		getRecordByPrimaryKey();
		this.instanciated = true;
	}


	
	@Override
	public void populateModel()
	{
		fields.put(SHELFTYPEID, new Field(SHELFTYPEID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(SHELFTYPE2GRAPHICSBITMAP, new Field(SHELFTYPE2GRAPHICSBITMAP, Field.TYPE_NUMERIC));
		fields.put(SHELFTYPE2BROWSERBITMAP, new Field(SHELFTYPE2BROWSERBITMAP, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(SHELFTYPEID));
	}

	public void setShelftypeid(String shelftypeid)
	{
		setField(SHELFTYPEID,shelftypeid);
	}

	public String getShelftypeid()
	{
		return getFieldAsString(SHELFTYPEID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setTablename(String tablename)
	{
		setField(TABLENAME,tablename);
	}

	public String getTablename()
	{
		return getFieldAsString(TABLENAME);
	}

	public void setShelftype2graphicsbitmap(String shelftype2graphicsbitmap)
	{
		setField(SHELFTYPE2GRAPHICSBITMAP,shelftype2graphicsbitmap);
	}

	public String getShelftype2graphicsbitmap()
	{
		return getFieldAsString(SHELFTYPE2GRAPHICSBITMAP);
	}

	public void setShelftype2browserbitmap(String shelftype2browserbitmap)
	{
		setField(SHELFTYPE2BROWSERBITMAP,shelftype2browserbitmap);
	}

	public String getNodetype2browserbitmap()
	{
		return getFieldAsString(SHELFTYPE2BROWSERBITMAP);
	}
	
	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}
}