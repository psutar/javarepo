package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class NcNciBandwidth extends AbstractReadOnlyTable {

	private static String BANDWIDTH_PROFILE_TYPE="BANDWIDTH_PROFILE_TYPE";
	private static String BANDWIDTH_PROFILE_NM="BANDWIDTH_PROFILE_NM";
	private static String PORT_TYPE="PORT_TYPE";
	private static String INTERFACE_TYPE="INTERFACE_TYPE";
	private static String NC_CD="NC_CD";
	private static String NCI_CPE_CD="NCI_CPE_CD";
	private static String NCI_QWEST_CD="NCI_QWEST_CD";
	private static String NC_NCI_BANDWIDTH_ID="NC_NCI_BANDWIDTH_ID";
	
	public NcNciBandwidth()
	{
		super();
		this.tableName = "NC_NCI_BANDWIDTH";
	}
	
	public NcNciBandwidth(String key)
	{
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}
	
	public static NcNciBandwidth getNcNciObject(String ncCode,String nciCode)
	{
		String connector = "";
		String query = "";
		
		if (!StringHelper.isEmpty(ncCode))
		{
			query = NC_CD + " = '" +  ncCode + "'";
			connector = " AND ";
		}
		if(!StringHelper.isEmpty(nciCode)){
			query = "("+NCI_CPE_CD + " = '" +  nciCode + "'" +" OR " + NCI_QWEST_CD + " = '" +  nciCode + "')";
			connector = " AND ";
		}
		
		
		return getNcNciByQuery(query);
	}

	public static NcNciBandwidth getNcNciByQuery(String query)
	{
		NcNciBandwidth ncNciBandwidth = new NcNciBandwidth();
		List<NcNciBandwidth> ncNciBandwidthList = new ArrayList<NcNciBandwidth>();
		List<Map<String,Object>> foundNcNciBandwidthList = ncNciBandwidth.getRecordsByQuery(query);

		NcNciBandwidth workncNciBandwidth=null;
		for (Map<String,Object> ncNciBandwidthMap : foundNcNciBandwidthList)
		{
			workncNciBandwidth = new NcNciBandwidth(ncNciBandwidthMap.get(NC_NCI_BANDWIDTH_ID).toString());
			if(workncNciBandwidth != null)
				return workncNciBandwidth;
		}
		
		return workncNciBandwidth;
	}
	
	@Override
	public void populateModel() {
		// TODO Auto-generated method stub
		
		//TODO Need to  chnage the datta type
		fields.put(BANDWIDTH_PROFILE_TYPE, new Field(BANDWIDTH_PROFILE_TYPE, Field.TYPE_VARCHAR));
		fields.put(BANDWIDTH_PROFILE_NM, new Field(BANDWIDTH_PROFILE_NM, Field.TYPE_VARCHAR));
		fields.put(PORT_TYPE, new Field(PORT_TYPE, Field.TYPE_VARCHAR));
		fields.put(INTERFACE_TYPE, new Field(INTERFACE_TYPE, Field.TYPE_VARCHAR));
		fields.put(BANDWIDTH_PROFILE_TYPE, new Field(BANDWIDTH_PROFILE_TYPE, Field.TYPE_VARCHAR));
		fields.put(NC_CD, new Field(NC_CD, Field.TYPE_VARCHAR));
		fields.put(NCI_CPE_CD, new Field(NCI_CPE_CD, Field.TYPE_VARCHAR));
		fields.put(NCI_QWEST_CD, new Field(NCI_QWEST_CD, Field.TYPE_VARCHAR));
		fields.put(NC_NCI_BANDWIDTH_ID, new Field(NC_NCI_BANDWIDTH_ID, Field.TYPE_NUMERIC));
		
		primaryKey = new PrimaryKey(fields.get(NC_NCI_BANDWIDTH_ID));
	}

	public String getBandwidthProfileType() {
		return getFieldAsString(BANDWIDTH_PROFILE_TYPE);
	}

	public void setBandwidthProfileType(String bandwidthProfileType) {
		setField(BANDWIDTH_PROFILE_TYPE,bandwidthProfileType);
	}

	public String getBandwidthProfileNm() {
		return getFieldAsString(BANDWIDTH_PROFILE_NM);
	}

	public void setBandwidthProfileNm(String bandwidthProfileNm) {
		setField(BANDWIDTH_PROFILE_NM,bandwidthProfileNm);
	}

	public String getPortType() {
		return getFieldAsString(PORT_TYPE);
	}

	public void setPortType(String portType) {
		setField(PORT_TYPE,portType);
	}

	public String getInterfaceType() {
		return getFieldAsString(INTERFACE_TYPE);
	}

	public void setInterfaceType(String interfaceType) {
		setField(INTERFACE_TYPE,interfaceType);
	}

	public String getNcCd() {
		return getFieldAsString(NC_CD);
	}

	public void setNcCd(String ncCd) {
		setField(NC_CD,ncCd);
	}

	public String getNciCpeCd() {
		return getFieldAsString(NCI_CPE_CD);
	}

	public  void setNciCpeCd(String nciCpeCd) {
		setField(NCI_CPE_CD,nciCpeCd);
	}

	public String getNciQwestCd() {
		return getFieldAsString(NCI_QWEST_CD);
	}

	public void setNciQwestCd(String nciQwestCd) {
		setField(NCI_QWEST_CD,nciQwestCd);
	}

	public String getNcNciBandwidthId() {
		return getFieldAsString(NC_NCI_BANDWIDTH_ID);
	}

	public void setNcNciBandwidthId(String ncNciBandwidthId) {
		setField(NC_NCI_BANDWIDTH_ID,ncNciBandwidthId);
	}

}
