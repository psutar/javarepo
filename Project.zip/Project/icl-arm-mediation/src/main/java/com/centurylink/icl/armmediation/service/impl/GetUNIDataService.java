package com.centurylink.icl.armmediation.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMCircuit;
import com.centurylink.icl.armmediation.dataaccess.SearchCircuitDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.SearchCircuitToCim;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetUNIDataService {


	private SearchCircuitDAO searchCircuitDAO;
	private SearchCircuitToCim searchCircuitToCim;
	private static final Log LOG = LogFactory.getLog(GetUNIDataService.class);

	public Object getUNIAndRelatedData(SearchResourceRequestDocument searchResourceRequestDocument) throws Exception
	{
		//validate the request
		String returnEVCDetails = MediationUtil.getRcv(searchResourceRequestDocument, "returnEVCDetails");
		String returnOVCDetails = MediationUtil.getRcv(searchResourceRequestDocument, "returnOVCDetails");
		String entityType = MediationUtil.getRcv(searchResourceRequestDocument, "EntityType");
		String commonName = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		boolean invalidRequest = false;

		if(!("ENNI".equalsIgnoreCase(entityType)|| "UNI".equalsIgnoreCase(entityType)))
			invalidRequest = true;

		
		if(invalidRequest)
			throw new ICLException("ICLRequestValidationError", "Invalid request", "1948");

		List<ARMCircuit> circuits=null;
		List<ARMCircuit> relatedCircuits=null;
		//String resourceType=null;
		if(null!=commonName && (null==returnEVCDetails|| returnEVCDetails.equalsIgnoreCase("False")) && (null==returnOVCDetails|| returnOVCDetails.equalsIgnoreCase("False")))
		{
				
			circuits = searchCircuitDAO.getUniEnniCircuit(buildCircuitQuery(commonName,entityType));
		
		}
		else if(null!=commonName)
		{
			circuits = searchCircuitDAO.getUniEnniCircuit(buildCircuitQuery(commonName,entityType));
		}
			if(null!=entityType )
			{
				if(entityType.equals("UNI")&& ((null!=returnEVCDetails && returnEVCDetails.equalsIgnoreCase("True"))|| (null!=returnOVCDetails &&   returnOVCDetails.equalsIgnoreCase("True"))))
				{
					relatedCircuits =searchCircuitDAO.getUniEnniRelatedCircuits(buildRelatedCircuitsQueryForUNIENNI(commonName,entityType,returnEVCDetails,returnOVCDetails));
				}
				else if(entityType.equals("ENNI")&& null!=returnOVCDetails &&  returnOVCDetails.equalsIgnoreCase("True"))
				{
					relatedCircuits=searchCircuitDAO.getUniEnniRelatedCircuits(buildRelatedCircuitsQueryForUNIENNI(commonName,entityType,returnEVCDetails,returnOVCDetails));
				}
			}

		
		return searchCircuitToCim.transformUniEnniDataToCim(searchResourceRequestDocument, circuits, relatedCircuits);



	}

	private String buildCircuitQuery(String commonName,String entityType)
	{

		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SERVICE);
		sqlBuilder.addFieldFromTable(Constants.SERVICE, Constants.NAME,Constants.SERVICE_NAME);
		sqlBuilder.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID,Constants.SERVICE_ID);
		sqlBuilder.addFieldFromTable(Constants.NODE, Constants.NAME,Constants.NODE_NAME);
		sqlBuilder.addFieldFromTable(Constants.EXT_DEVICE_TYPE, Constants.CLLI,Constants.DEVICE_CILLI);
		//sqlBuilder.addFieldFromTable(Constants.EXT_MEF_UNI, "BW",Constants.BANDWIDTH);
		sqlBuilder.addFieldFromTable(Constants.PORTTYPE,Constants.NAME,Constants.PORTTYPE);
		sqlBuilder.addFieldFromTable(Constants.PORT, Constants.NAME,Constants.PORT);
		sqlBuilder.addFieldFromTable(Constants.SERVICE_TYPE, Constants.NAME, Constants.SERVICE_TYPE);
		sqlBuilder.addTable(Constants.SERVICEOBJECT,"service_obj");
		sqlBuilder.addTable(Constants.SERVICE_TYPE);
		sqlBuilder.addTable(Constants.PORT);
		sqlBuilder.addTable(Constants.NODE);	
		//sqlBuilder.addTable(Constants.EXT_MEF_UNI);
		sqlBuilder.addTable(Constants.PORTTYPE)	;
		sqlBuilder.addTable(Constants.EXT_DEVICE_TYPE)	;
		sqlBuilder.eq(Constants.SERVICE, Constants.NAME,commonName);
		sqlBuilder.eq("service_obj", "serviceobject2dimobject","4");
		sqlBuilder.eq("service_obj","serviceobject2object",Constants.PORT,Constants.PORT_ID);
		sqlBuilder.eq("service_obj","serviceobject2service",Constants.SERVICE,Constants.SERVICE_ID);
		sqlBuilder.eq(Constants.SERVICE,"service2servicetype",Constants.SERVICE_TYPE,Constants.SERVICE_TYPE_ID);
		if(null!=entityType && entityType.equalsIgnoreCase("UNI"))
		{
			sqlBuilder.addFieldFromTable(Constants.EXT_MEF_UNI, "BW",Constants.BANDWIDTH);
			sqlBuilder.addTable(Constants.EXT_MEF_UNI);
			sqlBuilder.eq(Constants.SERVICE_TYPE, Constants.NAME ,"MEF UNI");
			sqlBuilder.eq(Constants.EXT_MEF_UNI,Constants.SERVICE_ID,Constants.SERVICE,Constants.SERVICE_ID);
		}
		else if(null!=entityType && entityType.equalsIgnoreCase("ENNI"))
		{
			sqlBuilder.addFieldFromTable(Constants.EXT_MEF_ENNI, "BW",Constants.BANDWIDTH);
			sqlBuilder.addTable(Constants.EXT_MEF_ENNI);
			sqlBuilder.eq(Constants.SERVICE_TYPE, Constants.NAME,"MEF ENNI");
			sqlBuilder.eq(Constants.EXT_MEF_ENNI,Constants.SERVICE_ID,Constants.SERVICE,Constants.SERVICE_ID);
		}
		sqlBuilder.eq(Constants.PORT, Constants.PORT_2_NODE,Constants.NODE,Constants.NODE_ID);
		sqlBuilder.eq(Constants.NODE,Constants.NODE_ID,Constants.EXT_DEVICE_TYPE, Constants.NODE_ID);
		sqlBuilder.eq(Constants.PORT, "port2porttype",Constants.PORTTYPE,"porttypeid");
		//sqlBuilder.eq("EXT_MEF_UNI",Constants.SERVICE_ID,Constants.SERVICE,Constants.SERVICE_ID);
		String sql = sqlBuilder.getStatement(); 
		System.out.println(sql);
		LOG.info(sql);
		return sql;
	}

	private String buildRelatedCircuitsQueryForUNIENNI(String commonName,String entityType,String relatedEVC,String relatedOVC)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SERVICE);
		sqlBuilder.addFieldFromTable(Constants.SERVICE, Constants.SERVICE_ID,Constants.SERVICE_ID);
		sqlBuilder.addFieldFromTable(Constants.SERVICE, Constants.NAME,"UNI_SER_NAME");
		sqlBuilder.addFieldFromTable("EVC_OVC_SER", Constants.NAME, "EVC_OVC_SER_NAME");
		sqlBuilder.addFieldFromTable("EVC_OVC_SERVICETYPE", Constants.NAME, "EVC_OVC_SERVICETYPE");
		sqlBuilder.addFieldFromTable("DN", Constants.NAME, "DIM_NO_NAME");
		sqlBuilder.addFieldFromTable("DN_TYPE", Constants.NAME, "DIM_NO_TYPE_NAME");
		sqlBuilder.addFieldFromTable("UNI_ENNI_EXT", Constants.NC_CODE);
		sqlBuilder.addFieldFromTable("UNI_ENNI_EXT", Constants.NCI_CODE);
		sqlBuilder.addFieldFromTable("UNI_ENNI_EXT", Constants.SEC_NCI_CODE);

		sqlBuilder.addTable(Constants.SERVICE,"EVC_OVC_SER");
		sqlBuilder.addTable(Constants.SERVICE_TYPE,"EVC_OVC_SERVICETYPE");
		if(entityType.equals("UNI"))
		{
			sqlBuilder.addTable(Constants.EXT_MEF_UNI,"UNI_ENNI_EXT");
		}
		else if(entityType.equals("ENNI"))
		{
			sqlBuilder.addTable(Constants.EXT_MEF_ENNI,"UNI_ENNI_EXT");
		}
		sqlBuilder.addTable(Constants.SERVICE_OBJECT,"SO_SER");
		sqlBuilder.addTable(Constants.SERVICE_OBJECT,"SO_PORT");
		//.addTable("EXT_MEF_UNI")
		sqlBuilder.addTable(Constants.NUMBER_OBJECT,"NO");
		sqlBuilder.addTable(Constants.DIMNUMBER,"DN");
		sqlBuilder.addTable(Constants.DIMNUMBER_TYPE,"DN_TYPE");

		sqlBuilder.eq(Constants.SERVICE,Constants.SERVICE_ID,"UNI_ENNI_EXT",Constants.SERVICE_ID);
		sqlBuilder.eq(Constants.SERVICE,Constants.SERVICE_ID,"SO_SER",Constants.SERVICE_OBJECT_2_OBJECT);
		sqlBuilder.eq("EVC_OVC_SER",Constants.SERVICE_ID,"SO_SER",Constants.SERVICE_OBJECT_2_SERVICE);
		sqlBuilder.eq("EVC_OVC_SERVICETYPE",Constants.SERVICE_TYPE_ID,"EVC_OVC_SER",Constants.SERVICE_2_SERVICE_TYPE);

		List<String> relatedEVCOVCData= new ArrayList<String>();
		String onlyEVC=null;
		String onlyOVC=null;
		
			if(null!=relatedEVC && relatedEVC.equalsIgnoreCase("True") && (relatedOVC==null ||relatedOVC.equalsIgnoreCase("False")))
			{
				onlyEVC="MEF EVC";
				relatedEVCOVCData.add(onlyEVC);
				sqlBuilder.in("EVC_OVC_SERVICETYPE", Constants.NAME,relatedEVCOVCData);
			}
			else if(null!=relatedOVC && relatedOVC.equalsIgnoreCase("True") && (relatedEVC==null||relatedEVC.equalsIgnoreCase("False")))
			{
				onlyOVC="MEF OVC";
				relatedEVCOVCData.add(onlyOVC);
				sqlBuilder.in("EVC_OVC_SERVICETYPE", Constants.NAME,relatedEVCOVCData);
			}
			else if(null!=relatedEVC && null!=relatedOVC && relatedEVC.equalsIgnoreCase("True") && relatedOVC.equalsIgnoreCase("True"))
			{
				onlyEVC="MEF EVC";
				onlyOVC="MEF OVC";
				relatedEVCOVCData.add(onlyEVC);
				relatedEVCOVCData.add(onlyOVC);
				sqlBuilder.in("EVC_OVC_SERVICETYPE", Constants.NAME,relatedEVCOVCData);	
			}
		

		sqlBuilder.eq("EVC_OVC_SER",Constants.SERVICE_ID,"SO_PORT",Constants.SERVICE_OBJECT_2_SERVICE);
		sqlBuilder.eq("NO",Constants.NUMBER_OBJECT_2_OBJECT,"SO_PORT",Constants.SERVICE_OBJECT_2_OBJECT);
		sqlBuilder.eq("SO_PORT","SERVICEOBJECT2DIMOBJECT","4");	
		sqlBuilder.eq("DN", Constants.DIMNUMBER_ID,"NO",Constants.NUMBER_OBJECT_2_NUMBER);
		sqlBuilder.eq("DN",Constants.DIMNUMBER_2_NUMBER_TYPE,"DN_TYPE",Constants.DIMNUMBER_TYPE_ID);
		sqlBuilder.eq(Constants.SERVICE, Constants.NAME,commonName);
		String sql = sqlBuilder.getStatement();
		System.out.println(sql);
		LOG.info(sql);
		return sql;

	}


	public void setSearchCircuitDAO(SearchCircuitDAO searchCircuitDAO) {
		this.searchCircuitDAO = searchCircuitDAO;
	}

	public void setSearchCircuitToCim(SearchCircuitToCim searchCircuitToCim) {
		this.searchCircuitToCim = searchCircuitToCim;
	}


}
