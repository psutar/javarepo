package com.centurylink.icl.armmediation.service.impl;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.dataaccess.GetDeviceListForCLLIDAO;
import com.centurylink.icl.armmediation.dataaccess.SearchDeviceDAO;
import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.transformation.GetTopologyDetailsToCim;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class GetDeviceListForCLLIService {
	private static final Log LOG = LogFactory.getLog(GetDeviceListForCLLIService.class);
	private GetDeviceListForCLLIDAO getDeviceListForCLLIDAO;
	List<String> deviceNamesList = null;
	public void setGetDeviceListForCLLIDAO(GetDeviceListForCLLIDAO getDeviceListForCLLIDAO)
	{
		this.getDeviceListForCLLIDAO = getDeviceListForCLLIDAO;
	}

	public List<String> getDeviceListForCLLI(HashMap map) throws Exception
	{
		if(map != null && map.get("DeviceCLLI") != null){
			return getDeviceListForCLLIDAO.getDeviceListForCLLI(map.get("DeviceCLLI").toString());
		}
		return null;
	}
}
