package com.centurylink.icl.armmediation.service.impl;



import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.armaccessobject.LocationBuildingSite;
import com.centurylink.icl.armmediation.dataaccess.ExtDeviceTypeDAO;
import com.centurylink.icl.armmediation.dataaccess.ExtLocationBuildingSiteDAO;
import com.centurylink.icl.armmediation.dataaccess.LocationDeviceClliDao;
import com.centurylink.icl.armmediation.helper.CLCLookupServiceHelper;
import com.centurylink.icl.armmediation.service.CreateDeviceClliRequest;
import com.centurylink.icl.armmediation.service.CreateDeviceClliResponse;
import com.centurylink.icl.armmediation.transformation.CreateDeviceClliFromCim;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;


public class CreateDeviceClliImpl {

	private static final Log LOG = LogFactory.getLog(CreateDeviceClliImpl.class);
	
	private static final int STARTING_SEQUENCE_NUMBER = 20;
	private static final int MAX_SEQUENCE_NUMBER = 999;
	private LocationDeviceClliDao locationDeviceClliDAO;
	private ExtLocationBuildingSiteDAO extLocationBuildingSiteDAO;
	private ExtDeviceTypeDAO extDeviceTypeDAO;
	private CreateDeviceClliFromCim createDeviceClliFromCim;
	
	
	
	public CreateDeviceClliImpl(LocationDeviceClliDao ilocationDeviceClliDAO, ExtLocationBuildingSiteDAO iextLocationBuildingSiteDAO, ExtDeviceTypeDAO iextDeviceTypeDAO, CreateDeviceClliFromCim icreateDeviceClliFromCim)
	{
		locationDeviceClliDAO = ilocationDeviceClliDAO;
		extLocationBuildingSiteDAO = iextLocationBuildingSiteDAO;
		extDeviceTypeDAO = iextDeviceTypeDAO;
		createDeviceClliFromCim = icreateDeviceClliFromCim;
	}
	
	public CreateDeviceClliResponse createDeviceClli(CreateDeviceRequestDocument createDeviceRequestDoc)
	{
		CreateDeviceClliRequest createDeviceClliRequest = createDeviceClliFromCim.transfromFromCim(createDeviceRequestDoc);
		return createDeviceClli(createDeviceClliRequest);
	}
	
	public CreateDeviceClliResponse createDeviceClli(CreateDeviceClliRequest createDeviceClliRequest)
	{
		String locationClli = createDeviceClliRequest.getLocationClli();
		int currentSeqNumber = locationDeviceClliDAO.LookupClliSequence(locationClli);
		boolean existingSequence = true;
		String swc = null;
		
		if(MAX_SEQUENCE_NUMBER == currentSeqNumber)
		{
			throw new ICLException("Cannot Create Device CLLI for " + locationClli + ".  Sequence is at 999");
		}
		
		if(-1 == currentSeqNumber)
		{
			existingSequence = false;
			currentSeqNumber = STARTING_SEQUENCE_NUMBER;
		}
		else
		{
			currentSeqNumber++;
		}
		
		//String currentSeqNumberAsString = Integer.toString(currentSeqNumber);
		
		String candidateDevcieClli = locationClli + String.format("%03d", currentSeqNumber);//Integer.toString(currentSeqNumber).
		
		boolean candidateUsable = false;
		
		while(!candidateUsable)
		{
			if(extDeviceTypeDAO.doesClliExists(candidateDevcieClli))
			{
				if(MAX_SEQUENCE_NUMBER == currentSeqNumber)
				{
					throw new ICLException("Cannot Create Device CLLI for " + locationClli + ".  Sequence is at 999");
				}
				
				currentSeqNumber++;
				candidateDevcieClli = locationClli + String.format("%03d", currentSeqNumber);
			}
			else
			{
				candidateUsable = true;
			}
		}
		
		
		try {
			List<AmericanPropertyAddress> addresses = CLCLookupServiceHelper.getCLCLookupService().getServiceAddressListByBuildingCLLI(locationClli);
			for (AmericanPropertyAddress address:addresses)
			{
				swc = SearchResourceRequestDocumentReaderCIM2.getCharacteristicValue(address.getRootEntityDescribedByList(), "ServiceWireCenterCLLI");
				if (swc != null)
				{
					if (swc.length() > 8)
					{
						swc = swc.substring(0, 8);
					}
					LOG.debug("Found SWC " + swc + " from CLC for " + locationClli);
					break;
				}
			}
			if (swc == null)
			{
				LOG.warn("Unable to lookup SWC for CLLI:" + locationClli + " sending null instead");
			}
		} catch (Exception e) {
			LOG.warn("Unable to lookup SWC for CLLI:" + locationClli + " sending null instead");
		}
		/*
		LocationBuildingSite locationBuildingSite = extLocationBuildingSiteDAO.getlocationClli(locationClli);
		
		if(null != locationBuildingSite)
		{
			swc = locationBuildingSite.getPhoneSwithClli();				
			if(StringHelper.isEmpty(swc))
			{	 
				 	throw new ICLException("Cannot find Swc for locationClli " + locationClli + ". " );
			}	
			
		}
		else
		{
			throw new ICLException("No records available for locationClli " + locationClli + ". " );
		}
		*/	
		
		
		if(existingSequence)
		{
			locationDeviceClliDAO.UpdateClliSequence(currentSeqNumber, locationClli);
		}
		else
		{
			locationDeviceClliDAO.InsertClliSequence(currentSeqNumber, locationClli);
		}
		
		// Create response object...
		CreateDeviceClliResponse createDeviceClliResponse = new CreateDeviceClliResponse();
		createDeviceClliResponse.setDeviceClli(candidateDevcieClli);
		createDeviceClliResponse.setEquipmentType(createDeviceClliRequest.getEquipmentType());
		createDeviceClliResponse.setServingWireCenter(swc);
		
		return createDeviceClliResponse;
	}
}