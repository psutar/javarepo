package com.centurylink.icl.armmediation.transformation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.centurylink.icl.builder.cim2.CreatePartyResponseBuilder;
import com.centurylink.icl.builder.cim2.CreatePartyResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.ErrorBuilder;
import com.centurylink.icl.builder.cim2.MessageElementsBuilder;
import com.centurylink.icl.builder.cim2.PartyBuilder;
import com.iclnbi.iclnbiV200.CreatePartyRequestDocument;
import com.iclnbi.iclnbiV200.CreatePartyResponseDocument;

public class ARMCreatePartyToCim {
	
	private static final Log	LOG	= LogFactory.getLog(ARMCreatePartyToCim.class);
	private final CreatePartyResponseDocumentBuilder   createpartyResponseDocumentBuilder;
	private final CreatePartyResponseBuilder    	createPartyResponseBuilder;
	private final MessageElementsBuilder		messageElementsBuilder;
	private final ErrorBuilder					errorBuilder;
	private final PartyBuilder                  partyBuilder;
	
	public ARMCreatePartyToCim()
	{
		createPartyResponseBuilder = new CreatePartyResponseBuilder();
		createpartyResponseDocumentBuilder = new CreatePartyResponseDocumentBuilder();
		messageElementsBuilder = new MessageElementsBuilder();
		errorBuilder = new ErrorBuilder();
		partyBuilder=new PartyBuilder();
	}
	
	public CreatePartyResponseDocument transformToCim(CreatePartyRequestDocument createRequest, String objectID,String commonName)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Createsubscriber : Transform to CIM");
		}
		
		String partyId= createRequest.getCreatePartyRequest().getPartyDetails().getPartyId();
		String partyRoleType= createRequest.getCreatePartyRequest().getPartyDetails().getPartyRoleType();

		createpartyResponseDocumentBuilder.buildCreatePartyResponseDocumentBuilder();
		createPartyResponseBuilder.buildCreatePartyResponse();
		partyBuilder.buildParty(commonName, objectID, partyId, partyRoleType);
		createPartyResponseBuilder.addParty(partyBuilder.getParty());
		createpartyResponseDocumentBuilder.addCreatePartyResponse(createPartyResponseBuilder.getCreatePartyResponse());
		return createpartyResponseDocumentBuilder.getCreatePartyResponseDocument();
	}
	
	public CreatePartyResponseDocument transformErrorToCim(CreatePartyRequestDocument createRequest, String errorCode, String errorMsg, String errorText)
	{
		
		if (LOG.isInfoEnabled())
		{
			LOG.info("CreateLocation : Transform Error to CIM");
		}

		messageElementsBuilder.buildMessageElements("FAILURE", "");
		messageElementsBuilder.setMessageAddressing(createRequest.getCreatePartyRequest().getMessageElements().getMessageAddressing());
		errorBuilder.buildError(errorCode, errorMsg, "FAILED", errorText, "ARM");
		messageElementsBuilder.addErrorList(errorBuilder.getError());
		createPartyResponseBuilder.buildCreatePartyResponse();
		//createPartyResponseBuilder.addMessageElements();
		//createPartyResponseBuilder.addMessageElements(messageElementsBuilder.getMessageElements());
		createpartyResponseDocumentBuilder.buildCreatePartyResponseDocumentBuilder();
		return createpartyResponseDocumentBuilder.getCreatePartyResponseDocument();
	}
	

}
