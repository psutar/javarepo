package com.centurylink.icl.armmediation.storedprocedures.pkgtechnologymanager;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.centurylink.icl.armmediation.helper.Constants;

public class IsDSLAMPathResolved extends StoredProcedure{
	
	private static final Log LOG = LogFactory.getLog(IsDSLAMPathResolved.class);

	public IsDSLAMPathResolved(DataSource dataSource)
	{
		super(dataSource, "Customization.PkgTechnologyManager.IsDSLAMPathResolved");

		if (LOG.isInfoEnabled())
		{
			LOG.info("ProcName: " + this.getSql());
		}	
							
		declareParameter(new SqlParameter("I_DSLAM", Types.VARCHAR));
		declareParameter(new SqlParameter("I_IPVERSION", Types.VARCHAR));
		declareParameter(new SqlParameter("I_USAGE", Types.VARCHAR));
		declareParameter(new SqlParameter("I_PROTOCOLTYPE", Types.VARCHAR));
		declareParameter(new SqlParameter("I_HOSTSERVICENAME", Types.VARCHAR));
		
		declareParameter(new SqlOutParameter(Constants.O_ISVALID, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_CODE, Types.NUMERIC));
		declareParameter(new SqlOutParameter(Constants.O_ERROR_TEXT, Types.VARCHAR));
		
		compile();
	}

	public Map<String, Object> execute(String I_DSLAM,String I_IPVERSION,String I_USAGE,String I_PROTOCOLTYPE,String I_HOSTSERVICENAME)
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("IsDSLAMPathResolved input parametrs: " + I_DSLAM +" " + I_IPVERSION + " " + I_USAGE + " " + I_PROTOCOLTYPE + " " + I_HOSTSERVICENAME );
		}
		final Map<String, Object> in = new HashMap<String, Object>();

		in.put("I_DSLAM", I_DSLAM);
		in.put("I_IPVERSION", I_IPVERSION);
		in.put("I_USAGE", I_USAGE);
		in.put("I_PROTOCOLTYPE", I_PROTOCOLTYPE);
		in.put("I_HOSTSERVICENAME", I_HOSTSERVICENAME);
		
		return super.execute(in);
	}

}
