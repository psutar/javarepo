package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.centurylink.icl.armmediation.armaccessobject.ARMCard;
import com.centurylink.icl.armmediation.armaccessobject.ARMCircuitDetails;
import com.centurylink.icl.armmediation.armaccessobject.ARMEVCVlan;
import com.centurylink.icl.armmediation.armaccessobject.MaxNameValue;
import com.centurylink.icl.armmediation.armaccessobject.QosDetails;
import com.centurylink.icl.armmediation.armaccessobject.VlanDetails;
import com.centurylink.icl.armmediation.valueobjects.objects.NcNciBandwidth;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.builder.cim2.AmericanPropertyAddressBuilder;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.CosBundleBuilder;
import com.centurylink.icl.builder.cim2.CustomerAccountBuilder;
import com.centurylink.icl.builder.cim2.CustomerAgentBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.EVCCircuitBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.PriorityBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.builder.cim2.TopologicalLinkBuilder;
import com.centurylink.icl.builder.cim2.UNICircuitBuilder;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.Shelf;

public class SearchCircuitDetailsToCim 
{
	//private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	private final SubNetworkConnectionBuilder subNetworkConnectionBuilder;
	private final OwnsResourceDetailsBuilder ownsResourceDetailsBuilder;
	private final CustomerBuilder customerBuilder;
	private final CustomerAccountBuilder customerAccountBuilder;
	private final TerminationPointBuilder terminationPointBuilder;
	private final LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder;
	private final PhysicalDeviceBuilder physicalDeviceBuilder;
	private final PhysicalDeviceRoleBuilder physicaldevicerolebuilder;
	private final AmericanPropertyAddressBuilder americanPropertyAddressBuilder;
	private final IPAddressBuilder ipAddressBuilder;
	private final ShelfBuilder shelfBuilder;
	private final SlotBuilder slotBuilder;
	private final CardBuilder cardBuilder;
	private final PhysicalPortBuilder physicalPortBuilder;
	private final ResourceRelationshipBuilder resourceRelationshipBuilder;
	private final Point2PointCircuitBuilder point2pointCircuitBuilder;
	private final Point2PointCircuitBuilder temppoint2pointCircuitBuilder;
	private final ConnectionTerminationPointBuilder connectionTerminationpointBuilder;
	private final UNICircuitBuilder uniCircuitBuilder;
	private final CustomerAgentBuilder customerAgentBuilder;
	private final EVCCircuitBuilder evcCircuitBuilder;
	private final PriorityBuilder priorityBuilder;
	private final TopologicalLinkBuilder topologicalLinkBuilder;

	public SearchCircuitDetailsToCim()
	{
		//this.searchResponseDetailsBuilder=new SearchResponseDetailsBuilder();
		this.subNetworkConnectionBuilder=new SubNetworkConnectionBuilder();
		this.ownsResourceDetailsBuilder= new OwnsResourceDetailsBuilder();
		this.customerBuilder = new CustomerBuilder();
		this.customerAccountBuilder=new CustomerAccountBuilder();
		this.terminationPointBuilder=new TerminationPointBuilder();
		this.logicalPhysicalResourceBuilder=new LogicalPhysicalResourceBuilder();
		this.physicalDeviceBuilder=new PhysicalDeviceBuilder();
		this.physicaldevicerolebuilder = new PhysicalDeviceRoleBuilder();
		this.americanPropertyAddressBuilder=new AmericanPropertyAddressBuilder();
		this.ipAddressBuilder=new IPAddressBuilder();
		this.shelfBuilder=new ShelfBuilder();
		this.slotBuilder=new SlotBuilder();
		this.cardBuilder=new CardBuilder();
		this.physicalPortBuilder=new PhysicalPortBuilder();
		this.resourceRelationshipBuilder=new ResourceRelationshipBuilder();
		this.point2pointCircuitBuilder=new Point2PointCircuitBuilder();
		this.temppoint2pointCircuitBuilder=new Point2PointCircuitBuilder();
		this.connectionTerminationpointBuilder=new ConnectionTerminationPointBuilder();
		this.uniCircuitBuilder=new UNICircuitBuilder();
		this.customerAgentBuilder=new CustomerAgentBuilder();
		this.evcCircuitBuilder= new EVCCircuitBuilder();
		this.priorityBuilder=new PriorityBuilder();
		this.topologicalLinkBuilder=new TopologicalLinkBuilder();
	}

	public SearchResponseDetailsBuilder transformCircuitDetailsToCim(Map<String, Object> transformParms)
	{
		//SearchResourceRequestDocument request = (SearchResourceRequestDocument)transformParms.get("Request");

		@SuppressWarnings("unchecked")
		ARMCircuitDetails ckt = (ARMCircuitDetails) transformParms.get("ARMCktDetails");

		@SuppressWarnings("unchecked")
		List<ARMCircuitDetails> startPortDetailsList = (List<ARMCircuitDetails>) transformParms.get("StartNodeList");

		@SuppressWarnings("unchecked")
		List<ARMCircuitDetails> endPortDetailsList = (List<ARMCircuitDetails>) transformParms.get("EndNodeList");

		@SuppressWarnings("unchecked")
		ARMCircuitDetails serviceDetails = (ARMCircuitDetails) transformParms.get("ArmServiceDetails");

		@SuppressWarnings("unchecked")
		List<ARMCircuitDetails> relatedCircuitsDetailsList = (List<ARMCircuitDetails>) transformParms.get("RelatedCircuitDetails");

		@SuppressWarnings("unchecked")
		List<ARMCircuitDetails> relatedServiceDetailsList = (List<ARMCircuitDetails>) transformParms.get("RelatedServiceDetails");

		@SuppressWarnings("unchecked")
		HashMap<String ,List<QosDetails>> serviceQosMap = (HashMap<String, List<QosDetails>>) transformParms.get("ServiceidQOSMap");

		@SuppressWarnings("unchecked")
		List<VlanDetails> vlanDetailsList = (List<VlanDetails>) transformParms.get("VlanDetailsList");

		@SuppressWarnings("unchecked")
		List<VlanDetails> vlanRangeListForUNI = (List<VlanDetails>) transformParms.get("VlanRangeListForUNI");

		@SuppressWarnings("unchecked")
		List<VlanDetails> vlanRangeListForEVC = (List<VlanDetails>) transformParms.get("VlanRangeListForEVC");

		@SuppressWarnings("unchecked")
		List<VlanDetails> vpnIDListForEVC = (List<VlanDetails>) transformParms.get("VPNIDListForEVC");

		@SuppressWarnings("unchecked")
		List<VlanDetails> vpnIDListForUNI = (List<VlanDetails>) transformParms.get("VPNIDListForUNI");
		
		
		@SuppressWarnings("unchecked")
		HashMap<String ,List<VlanDetails>> serviceVlanMap = (HashMap<String, List<VlanDetails>>) transformParms.get("ServiceidVlanMap");

		@SuppressWarnings("unchecked")
		HashMap<String,List<ARMCircuitDetails>> serviceNodeDetailsMap = (HashMap<String, List<ARMCircuitDetails>>) transformParms.get("ServiceidNodeDetailsMap");

		@SuppressWarnings({ "unchecked" })
		HashMap<String,ArrayList<MaxNameValue>> maxValuesMap =(HashMap<String,ArrayList<MaxNameValue>>)transformParms.get("MaxValues");

		@SuppressWarnings({ "unchecked" })
		List<ARMEVCVlan> evcVlanList  =(List<ARMEVCVlan>)transformParms.get("EVCVlanList");
		SearchResponseDetailsBuilder  searchResponseDetailsBuilder=(SearchResponseDetailsBuilder)transformParms.get("responseBuilder");
		boolean requiredRelatedCircuits = false;
		if(transformParms.get("includeRelationship")!=null)
		{
			requiredRelatedCircuits=true;
		}

		String multicastFrameDelivery =null;
		String broadcastFrameDelivery =null;
		String ceVlanCosPreservation = null;
		String ceVlanIdPreservation = null;
		String unicastFrameDelivery =null;
		String aggregationProtocal=null;
		String serviceSubType = null;
		String protectiontype=null;
		String diverseCktId = null;
		String cktservType = null;
		String cktserviceId=null;
		String secNCICode = null;
		String tsp = null;
		String isDiverse = null;
		String bandwidth = null;
		String specCode = null;
		String nciCode = null;
		String evcovcnc =null;
		String lagnumber=null;
		String ncCode = null;
		String cktSrNo =null;
		String cosId = null;
		String hashing=null;
		String mco = null;
		String cktBw=null;
		String enniTSP=null;
		String uniTSP=null;
		Service service = new Service();
		NcNciBandwidth ncNciBandwidth = null;

		if(null!=ckt)
		{
			//ARMCircuitDetails ckt=cktsList.get(0);
			ARMCircuitDetails nodeDetails=null;
			//searchResponseDetailsBuilder.buildSearchResponseDetails();

			// Code for Main Circuit is NMI/LAG (DSP Case)
			if(requiredRelatedCircuits && ckt.getCircuitType()!=null && (ckt.getCircuitType().equalsIgnoreCase("Unrouted Ethernet Bearer") ||  ckt.getCircuitType().equalsIgnoreCase("Link Aggregation Group")))
			{
				System.out.println("Call to Code for Circuit Details for NMI/LAG Circuit (DSP Case)");
				if( ckt.getCircuitType().equalsIgnoreCase("Unrouted Ethernet Bearer"))
				{
					cktservType = ckt.getCktSerType(); bandwidth = ckt.getNmiBW(); isDiverse = ckt.getNmiIsDiverse(); diverseCktId = ckt.getNmiDiverseCktId();
				}
				if(ckt.getCircuitType().equalsIgnoreCase("Link Aggregation Group"))
				{
					cktservType = "LAG"; bandwidth = ckt.getLagBW(); isDiverse = ckt.getLagIsDiverse(); diverseCktId = ckt.getLagDiverseCktId();
					protectiontype=ckt.getProtectionType();lagnumber=ckt.getLagNumber();  hashing=ckt.getHashing(); aggregationProtocal=ckt.getAggregationProtocol();
				}
				point2pointCircuitBuilder.buildPoint2PointCircuit(ckt.getCommonName(), ckt.getObjectID(), null, "ARM", cktservType, ckt.getCktProStatus(), null, null, ckt.getBandwidth(), ckt.getCktFuncStatus(), null, ckt.getAlias1(),ckt.getAlias2());


				if(null!=ckt.getTsp())
				{
					point2pointCircuitBuilder.addResourceDescribedBy("TSP", ckt.getTsp());
				}
				if(null!=ckt.getIsLagMember())
				{
					point2pointCircuitBuilder.addResourceDescribedBy("IsLAGMember", ckt.getIsLagMember());
				}
				if(isDiverse!=null)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("IsDiverse", isDiverse);
				}
				if(null!=bandwidth)
					point2pointCircuitBuilder.addResourceDescribedBy("AvailableBandwidth",bandwidth);
				if(diverseCktId!=null)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("DiverseCircuitID", diverseCktId);
				}
				if(null!=ckt.getL1Technology())
				{
					point2pointCircuitBuilder.addResourceDescribedBy("L1Technology", ckt.getL1Technology());
				}
				if(null!=protectiontype)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("ProtectionType", protectiontype);
				}
				if(null!=lagnumber)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("LAGNumber", lagnumber);
				}
				if(null!=hashing)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("Hashing", hashing);
				}
				if(null!=aggregationProtocal)
				{
					point2pointCircuitBuilder.addResourceDescribedBy("AggregationProtocol", aggregationProtocal);	
				}
				if(null!=ckt.getExceptionHandlingText())
				{
					point2pointCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", ckt.getExceptionHandlingText());	
				}
				// Code for RelatedServices when Main Circuit is NMI/LAG (DSP Case)
				if(relatedServiceDetailsList!=null && relatedServiceDetailsList.size()>0)
				{
					System.out.println("Calling related Uni for NMI" + relatedServiceDetailsList);
					for(ARMCircuitDetails relatedServiceDetails: relatedServiceDetailsList)
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						if(null!=relatedServiceDetails && null!=relatedServiceDetails.getServiceType())
						{
							if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF UNI"))
							{
								secNCICode = relatedServiceDetails.getUniSecNCICode(); specCode = relatedServiceDetails.getUniSpecCode(); nciCode = relatedServiceDetails.getUniNCICode();
								ncCode = relatedServiceDetails.getUniNCCode(); mco = relatedServiceDetails.getUniMCO(); cktserviceId=relatedServiceDetails.getUniCktId(); cktBw=relatedServiceDetails.getUniBW();
							}
							if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
							{
								secNCICode = relatedServiceDetails.getEnniSecNCICode(); specCode = relatedServiceDetails.getEnniSpecCode(); nciCode = relatedServiceDetails.getEnniNCICode();
								ncCode = relatedServiceDetails.getEnniNCCode(); mco = relatedServiceDetails.getEnniMCO(); cktserviceId=relatedServiceDetails.getEnniCktId(); cktBw=relatedServiceDetails.getEnniBW();
							}
							temppoint2pointCircuitBuilder.buildPoint2PointCircuit(relatedServiceDetails.getServiceName(), cktserviceId, null, "ARM", relatedServiceDetails.getServiceType(), relatedServiceDetails.getServiceProStatus(), null, null, cktBw, relatedServiceDetails.getServiceFuncStatus(), serviceSubType);
							if(specCode!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("SpecCode", specCode);
							}
							if(ncCode!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("NCCode", ncCode);	
							}
							if(nciCode!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("NCICode", nciCode);
							}
							if(secNCICode!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("SECNCICode", secNCICode);
							}
							if(mco!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("MCO", mco);
							}
							if(relatedServiceDetails.getExceptionHandlingText()!=null)
							{
								temppoint2pointCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", relatedServiceDetails.getExceptionHandlingText());
							}
							resourceRelationshipBuilder.addCircuit(temppoint2pointCircuitBuilder.getPoint2PointCircuit());
							point2pointCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
						}
					}
				}
				//Code for Adding Customer Info
				if(ckt.getSubscriberName()!=null)
				{
					point2pointCircuitBuilder.addOwnsResourceDetails(addCustomerData(ckt, requiredRelatedCircuits));
				}
				// Code for Adding CircuitEndPoints
				if(startPortDetailsList!=null && startPortDetailsList.size()>0)
				{
					nodeDetails=startPortDetailsList.get(0);
					connectionTerminationpointBuilder.buildConnectionTerminationPoint(null, null, null);
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					if(nodeDetails.getLocationName()!=null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						connectionTerminationpointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
					connectionTerminationpointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					point2pointCircuitBuilder.addAEndTps(connectionTerminationpointBuilder.getConnectionTerminationPoint());
				}
				if(endPortDetailsList!=null && endPortDetailsList.size()>0)
				{
					nodeDetails=endPortDetailsList.get(0);
					connectionTerminationpointBuilder.buildConnectionTerminationPoint(null, null, null);
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					if(nodeDetails.getLocationName()!=null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						connectionTerminationpointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
					connectionTerminationpointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					point2pointCircuitBuilder.addZEndTps(connectionTerminationpointBuilder.getConnectionTerminationPoint());
				}
				searchResponseDetailsBuilder.addP2PCircuit(point2pointCircuitBuilder.getPoint2PointCircuit());
			}
			else
			{
				// Code for Circuit Details for NMI/LAG Circuit (NTM Case)
				System.out.println("Call to Code for Circuit Details for NMI/LAG Circuit (NTM Case)");
				if(null!=ckt)
				{
					if(ckt.getCircuitType().equalsIgnoreCase("Unrouted Ethernet Bearer"))
						cktservType = ckt.getCktSerType();
					else
						cktservType = ckt.getCircuitType();

					subNetworkConnectionBuilder.buildSubNetworkConnection(ckt.getCommonName(), ckt.getObjectID(), null, "ARM", cktservType, ckt.getCktStatus(), null, null, ckt.getAlias1(), ckt.getAlias2(), null, null);
				}
				if(ckt.getEthBearerMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", ckt.getEthBearerMCO());
				}
				if(ckt.getLagMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", ckt.getLagMCO());
				}
				if(ckt.getNmiIsDiverse()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse", ckt.getNmiIsDiverse());
				}
				if(ckt.getLagIsDiverse()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse", ckt.getLagIsDiverse());
				}
				if(ckt.getCircuitType()!=null)
				{
					if(ckt.getCircuitType().equalsIgnoreCase("Unrouted Ethernet Bearer")||ckt.getCircuitType().equalsIgnoreCase("Topology Virtual Connection"))
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("CircuitIDFormat", "CLF");
					}
					else if(ckt.getCircuitType().equalsIgnoreCase("Link Aggregation Group"))
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");
					}
				}
				if(ckt.getExceptionHandlingText()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", ckt.getExceptionHandlingText());
				}
				//Code for Adding Customer Info
				if(ckt.getSubscriberName()!=null)
				{
					subNetworkConnectionBuilder.addOwnsResourceDetails(addCustomerData(ckt, requiredRelatedCircuits));
				}
				// Code for Adding CircuitEndPoints
				if(startPortDetailsList!=null && startPortDetailsList.size()>0)
				{
					nodeDetails=startPortDetailsList.get(0);

					terminationPointBuilder.buildTerminationPoint(nodeDetails.getPortName(), null, nodeDetails.getInterfaceCategory());
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					if(nodeDetails.getMonitoredStatus()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("isMonitored", nodeDetails.getMonitoredStatus());
					}
					if(nodeDetails.getExceptionHandlingText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("ExceptionHandlingText", nodeDetails.getExceptionHandlingText());
					}
					if(nodeDetails.getMoveActivityText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("MoveActivityText", nodeDetails.getMoveActivityText());
					}
					if(nodeDetails.getLocationName()!=null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
					terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					subNetworkConnectionBuilder.addAEndTps(terminationPointBuilder.getTerminationPoint());
				}
				if(endPortDetailsList!=null && endPortDetailsList.size()>0)
				{
					nodeDetails=endPortDetailsList.get(0);

					terminationPointBuilder.buildTerminationPoint(nodeDetails.getPortName(), null, nodeDetails.getInterfaceCategory());
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					if(nodeDetails.getMonitoredStatus()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("isMonitored", nodeDetails.getMonitoredStatus());
					}
					if(nodeDetails.getExceptionHandlingText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("ExceptionHandlingText", nodeDetails.getExceptionHandlingText());
					}
					if(nodeDetails.getMoveActivityText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("MoveActivityText", nodeDetails.getMoveActivityText());
					}
					if(nodeDetails.getLocationName()!=null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
					terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder.getTerminationPoint());
				}
				searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
			}
			return searchResponseDetailsBuilder;//.getSearchResponseDetails();
			//return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		}
		else if(serviceDetails!=null)
		{
			//searchResponseDetailsBuilder.buildSearchResponseDetails();
			//			for(ARMCircuitDetails serviceDetails:serviceDetailsList)
			//			{
			ARMCircuitDetails nodeDetails=null;

			// Code for Service Details (DSP Case)
			if(requiredRelatedCircuits && serviceDetails.getServiceType()!=null)
			{
				//Code for Main UNI/ENNI Service (DSP Case)
				if(serviceDetails.getServiceType().equalsIgnoreCase("MEF UNI") || serviceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
				{
					System.out.println("Call to Code for Circuit Details for UNI/ENNI Service (DSP Case)");
					if(serviceDetails.getServiceType().equalsIgnoreCase("MEF UNI"))
					{
						mco = serviceDetails.getUniMCO(); ncCode = serviceDetails.getUniNCCode(); nciCode = serviceDetails.getUniNCICode(); secNCICode =  serviceDetails.getUniSecNCICode(); specCode =  serviceDetails.getUniSpecCode(); cktSrNo=serviceDetails.getUniCktSrNo(); bandwidth=serviceDetails.getUniBW();tsp=serviceDetails.getUniTSP();
						if(ncCode!=null||nciCode!=null)
						ncNciBandwidth = service.getNcNciBandwidth(ncCode, nciCode);
					}
					if(serviceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
					{
						mco = serviceDetails.getEnniMCO(); ncCode = serviceDetails.getEnniNCCode(); nciCode = serviceDetails.getEnniNCICode(); secNCICode =  serviceDetails.getEnniSecNCICode(); specCode =  serviceDetails.getEnniSpecCode();cktSrNo=serviceDetails.getEnniCktSrNo(); bandwidth=serviceDetails.getEnniBW();tsp=serviceDetails.getEnniTSP();
						if(ncCode!=null||nciCode!=null)
						ncNciBandwidth = service.getNcNciBandwidth(ncCode, nciCode);
					}
					uniCircuitBuilder.buildUNICircuit(serviceDetails.getServiceName(), serviceDetails.getServiceID(), null, "ARM", serviceDetails.getServiceType(), serviceDetails.getServiceProStatus(), null, null, serviceDetails.getServiceFuncStatus(), serviceDetails.getAlias1(), serviceDetails.getAlias2(), mco, serviceDetails.getServiceMux(), serviceDetails.getBundling(), serviceDetails.getAllToOneBundling(), ncCode, nciCode, secNCICode, specCode, bandwidth);
					if(cktSrNo!=null)
						uniCircuitBuilder.addResourceDescribedBy("CircuitSerialNumber", cktSrNo);
					if(serviceDetails.getCustomerSrNo()!=null)
						uniCircuitBuilder.addResourceDescribedBy("CustomerSerialNumber", serviceDetails.getCustomerSrNo());
					if(serviceDetails.getFrameFormat()!=null)
						uniCircuitBuilder.addResourceDescribedBy("FrameFormat", serviceDetails.getFrameFormat());
					if(serviceDetails.getUniIsDiverse()!=null)
						uniCircuitBuilder.addResourceDescribedBy("IsDiverse", serviceDetails.getUniIsDiverse());
					if(serviceDetails.getExceptionHandlingText()!=null)
						uniCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", serviceDetails.getExceptionHandlingText());
					//Added DiverseUNIID under DiversityCircuit for UNI/ENNI Service
					topologicalLinkBuilder.buildTopologicalLink(serviceDetails.getDiverseUniId(), null, null, null, null, null, null, null, null);
					uniCircuitBuilder.addDiversityCircuit(topologicalLinkBuilder.getTopologicalLink());
					
					if(ncNciBandwidth!=null&&ncNciBandwidth.getInterfaceType()!=null){
						uniCircuitBuilder.addResourceDescribedBy("InterfaceType", ncNciBandwidth.getInterfaceType());
					}
					if(tsp!=null)
						uniCircuitBuilder.addResourceDescribedBy("TSP", tsp);

					if(vlanRangeListForUNI!=null && vlanRangeListForUNI.size()>0 && vlanRangeListForUNI.get(0)!=null && vlanRangeListForUNI.get(0).getNumberType()!=null && vlanRangeListForUNI.get(0).getNumberType().equalsIgnoreCase("VLAN Range"))
						uniCircuitBuilder.addResourceDescribedBy("VLANRange", vlanRangeListForUNI.get(0).getNumberValue());
					
					
					//Code for Adding MaxValues
					if(maxValuesMap!=null)
					{
						if(serviceDetails.getServiceType().equalsIgnoreCase("MEF UNI"))
						{
							ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF UNI") ;
							if(null!=maxNameValues)
							{		
								for(MaxNameValue maxValue : maxNameValues)
								{
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumEVCs"))
									{
										uniCircuitBuilder.addResourceDescribedBy("MaxNumEVCs", maxValue.getMaxValue());
									}
								}
							}
						}
						if(serviceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
						{
							ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF ENNI") ;
							if(null!=maxNameValues)
							{
								for(MaxNameValue maxValue : maxNameValues)
								{	
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCs"))
									{
										uniCircuitBuilder.addResourceDescribedBy("MaxNumOVCs", maxValue.getMaxValue() );
									}
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCEndPointsPerOVCs"))
									{
										uniCircuitBuilder.addResourceDescribedBy("MaxNumOVCEndpointsPerOVC", maxValue.getMaxValue());
									}
								}
							}
						}
					}

					//Code for QosDetails for Main UNI/ENNI (DSP Case)
					@SuppressWarnings("unchecked")
					HashMap<String ,ArrayList<QosDetails>> uniQosMap=(HashMap<String ,ArrayList<QosDetails>>)transformParms.get("UNIQosDetailsMap");
					if(null!=uniQosMap && uniQosMap.size()>0)
					{
						Set<Map.Entry<String ,ArrayList<QosDetails>>> set= uniQosMap.entrySet();
						Iterator<Entry<String, ArrayList<QosDetails>>> uniQosIterate = set.iterator();
						while(uniQosIterate.hasNext())
						{
							addQosDetails(uniQosIterate.next().getValue(),evcVlanList);
						}
					}

					//Code for VLAN Details for Main UNI/ENNI (DSP Case)
					/*if(null!=vlanDetailsList && vlanDetailsList.size()>0)
					{
						addVlanDetails(vlanDetailsList);
					}*/

					//Code for RelatedServices and Circuits when Main Service is UNI/ENNI
					if((relatedServiceDetailsList!=null && relatedServiceDetailsList.size()>0) || (relatedCircuitsDetailsList!=null && relatedCircuitsDetailsList.size()>0))
					{

						//Code for RelatedServices when Main Service is UNI/ENNI
						if(relatedServiceDetailsList!=null && relatedServiceDetailsList.size()>0)
						{
							for(ARMCircuitDetails relatedServiceDetails: relatedServiceDetailsList)
							{
								String vlanNumber=null;
								if(null!=relatedServiceDetails && null!=relatedServiceDetails.getServiceType())
								{

									if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF EVC"))
									{
										serviceSubType = relatedServiceDetails.getEvcServiceSubType();mco = relatedServiceDetails.getEvcMCO();
										ncCode = relatedServiceDetails.getEvcNc();								
									}
									if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
									{
										serviceSubType = relatedServiceDetails.getOvcServiceSubType();mco = relatedServiceDetails.getOvcMCO();
										ncCode = relatedServiceDetails.getOvcNc();
									}
									evcCircuitBuilder.buildEVCCircuit(relatedServiceDetails.getServiceName(), relatedServiceDetails.getServiceID(), null, "ARM", relatedServiceDetails.getServiceType(), relatedServiceDetails.getServiceProStatus(), null, null, null, null, relatedServiceDetails.getServiceFuncStatus(), serviceSubType, null, null, null);
									if(null!=vlanDetailsList && vlanDetailsList.size()>0)
									{
										for(VlanDetails vlanDetails:vlanDetailsList)
										{
											if(vlanDetails!=null && relatedServiceDetails.getVlanPortId()!=null && vlanDetails.getVlanPortID()!=null && relatedServiceDetails.getVlanPortId().equals(vlanDetails.getVlanPortID()))
											{
												vlanNumber= vlanDetails.getNumberValue();

												if(vlanDetails.getNumberType()!=null && vlanDetails.getNumberType().equalsIgnoreCase("S-VLAN"))
													evcCircuitBuilder.addResourceDescribedBy("SVLAN", vlanNumber);

												if(vlanDetails.getNumberType()!=null && vlanDetails.getNumberType().equalsIgnoreCase("CE-VLAN"))
													evcCircuitBuilder.addResourceDescribedBy("CEVLAN", vlanNumber);

												if(vlanDetails.getNumberType()!=null && vlanDetails.getNumberType().equalsIgnoreCase("VLAN Range"))
													evcCircuitBuilder.addResourceDescribedBy("SubVLANRange", vlanNumber);

												if(vlanDetails.getNumberType()!=null && vlanDetails.getNumberType().equalsIgnoreCase("VLAN"))
												{
													if(vlanDetails.getVlanFunction()!=null)
													{
														if(vlanDetails.getVlanFunction().equalsIgnoreCase("S-VLAN"))
															evcCircuitBuilder.addResourceDescribedBy("SVLAN", vlanNumber);

														if(vlanDetails.getVlanFunction().equalsIgnoreCase("CE-VLAN"))
															evcCircuitBuilder.addResourceDescribedBy("CEVLAN", vlanNumber);



													}

												}

											}
										}
									}

									if(vpnIDListForUNI!=null && vpnIDListForUNI.size()>0)
									{
										for(VlanDetails vpnIDDetails:vpnIDListForUNI)
										{

											if(vpnIDDetails!=null)
											{
												if(vpnIDDetails.getNumberType()!=null && vpnIDDetails.getNumberType().equalsIgnoreCase("VPN-ID") && vpnIDDetails.getServiceID()!=null && relatedServiceDetails.getServiceID()!=null && vpnIDDetails.getServiceID().equals(relatedServiceDetails.getServiceID()))
												{
													evcCircuitBuilder.addResourceDescribedBy("VPN-ID", vpnIDDetails.getNumberValue());	
												}
											}
										}
									}

									if(null!=mco)
									{
										evcCircuitBuilder.addResourceDescribedBy("MCO", mco);
									}
									if(null!=ncCode)
									{
										evcCircuitBuilder.addResourceDescribedBy("NCCode", ncCode);
									}
									if(relatedServiceDetails.getHpc()!=null)
									{
										evcCircuitBuilder.addResourceDescribedBy("HPCIndicator", relatedServiceDetails.getHpc());
									}
									if(relatedServiceDetails.getHpcExpDate()!=null)
									{
										evcCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", relatedServiceDetails.getHpcExpDate());
									}

									/*if(relatedServiceDetails.getVpnId() !=null)
									{
										evcCircuitBuilder.addResourceDescribedBy("VpnId", relatedServiceDetails.getVpnId());
									}*/
									if(relatedServiceDetails.getAsn()!=null)
									{
										evcCircuitBuilder.addResourceDescribedBy("Asn", relatedServiceDetails.getAsn());
									}
									if(relatedServiceDetails.getExceptionHandlingText() != null)
									{
										evcCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", relatedServiceDetails.getExceptionHandlingText());
									}

									if(maxValuesMap!=null)
									{	
										if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
										{
											ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF OVC") ;
											if(null!=maxNameValues)
											{
												for(MaxNameValue maxValue : maxNameValues)
												{	
													if(maxValue.getMaxColName().equalsIgnoreCase("MaxNumUNIOVCEndPoints") && maxValue.getMaxColName()!=null)
													{
														evcCircuitBuilder.addResourceDescribedBy("MaxNumUNIOVCEndPoints", maxValue.getMaxValue());
													}
													if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumENNIOVCEndPoints"))
													{
														evcCircuitBuilder.addResourceDescribedBy("MaxNumENNIOVCEndPoints", maxValue.getMaxValue() );
													}
													if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCMembers"))
													{
														evcCircuitBuilder.addResourceDescribedBy("MaxNumOVCMembers", maxValue.getMaxValue() );
													}
												}
											}
										}
										if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF EVC"))
										{
											ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF EVC") ;
											if(null!=maxNameValues)
											{
												for(MaxNameValue maxValue : maxNameValues)
												{
													if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaximumUNIs"))
													{
														evcCircuitBuilder.addResourceDescribedBy("MaxUNI", maxValue.getMaxValue());
													}
												}
											}
										}
									}
									uniCircuitBuilder.addEVCCircuit(evcCircuitBuilder.getEVCCircuit());
								}
							}
						}
						//Code for RelatedCircuits when Main Service is UNI/ENNI
						if(relatedCircuitsDetailsList!=null && relatedCircuitsDetailsList.size()>0)
						{
							for(ARMCircuitDetails relatedCircuitDetails:relatedCircuitsDetailsList)
							{
								resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
								if(null!=relatedCircuitDetails && null!=relatedCircuitDetails.getCircuitType())
								{
									if( relatedCircuitDetails.getCircuitType().equalsIgnoreCase("Unrouted Ethernet Bearer"))
									{
										cktservType = relatedCircuitDetails.getCktSerType(); bandwidth = relatedCircuitDetails.getNmiBW();
									}
									if(relatedCircuitDetails.getCircuitType().equalsIgnoreCase("Link Aggregation Group"))
									{
										cktservType = "LAG"; bandwidth = relatedCircuitDetails.getLagBW();
									}
									temppoint2pointCircuitBuilder.buildPoint2PointCircuit(relatedCircuitDetails.getCommonName(), relatedCircuitDetails.getObjectID(), null, "ARM", cktservType, relatedCircuitDetails.getCktProStatus(), null, null, bandwidth, relatedCircuitDetails.getCktFuncStatus(), null);
									resourceRelationshipBuilder.addCircuit(temppoint2pointCircuitBuilder.getPoint2PointCircuit());
									uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
								}
							}
						}
					}

					//Code for Adding Customer Info for Service
					if(serviceDetails.getHpc()!=null)
					{
						uniCircuitBuilder.addResourceDescribedBy("HPCIndicator", serviceDetails.getHpc());
					}
					if(serviceDetails.getHpcExpDate()!=null)
					{
						uniCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", serviceDetails.getHpcExpDate());
					}
					if(serviceDetails.getSubscriberID()!=null ||  serviceDetails.getBan()!=null)
					{
						uniCircuitBuilder.addOwnsResourceDetails(addCustomerData(serviceDetails, requiredRelatedCircuits));
					}

					// Code for Adding UNI/ENNI ServiceEndPoints
					if(endPortDetailsList!=null && endPortDetailsList.size()>0)
					{
						nodeDetails=endPortDetailsList.get(0);
						connectionTerminationpointBuilder.buildConnectionTerminationPoint(null, null, null);
						logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);


						if(nodeDetails.getLocationName()!=null)
						{
							americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
							connectionTerminationpointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
						}
						logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
						connectionTerminationpointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
						uniCircuitBuilder.addZEndTps(connectionTerminationpointBuilder.getConnectionTerminationPoint());
						if(nodeDetails.getPortType()!=null)
						{
							if(nodeDetails.getPortType().equalsIgnoreCase("Pluggable") )
							{
								if(nodeDetails.getTransmissionRatePluggable() !=null)
									uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRatePluggable());
							}else 
							{								
								if(nodeDetails.getTransmissionRate()!=null)
									uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRate());
							}	
						}						
						
					}

					searchResponseDetailsBuilder.addP2PCircuit(uniCircuitBuilder.getUNICircuit());
				}
				//Code for Main EVC/OVC Service (DSP Case)
				if(serviceDetails.getServiceType().equalsIgnoreCase("MEF EVC") || serviceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
				{
					System.out.println("Call to Code for Circuit Details for EVC/OVC Service (DSP Case)");
					if(serviceDetails.getServiceType().equalsIgnoreCase("MEF EVC"))
					{
						serviceSubType = serviceDetails.getEvcServiceSubType(); mco = serviceDetails.getEvcMCO();
						ncCode = serviceDetails.getEvcNc(); cktSrNo = serviceDetails.getEvcCktSrNo(); cosId = serviceDetails.getEvcCosId();
						unicastFrameDelivery = serviceDetails.getEvcUnicastFrameDelivery(); multicastFrameDelivery = serviceDetails.getEvcMulticastFrameDelivery();
						broadcastFrameDelivery = serviceDetails.getEvcBroadcastFrameDelivery(); evcovcnc = serviceDetails.getEvcEvcOvcNc();
						ceVlanIdPreservation=serviceDetails.getEvcCeVlanIdPreservation(); ceVlanCosPreservation=serviceDetails.getEvcCeVlanCosPreservation();
					}
					if(serviceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
					{
						serviceSubType = serviceDetails.getOvcServiceSubType(); mco = serviceDetails.getOvcMCO();
						ncCode = serviceDetails.getOvcNc(); cktSrNo = serviceDetails.getOvcCktSrNo(); cosId = serviceDetails.getOvcCosId();
						unicastFrameDelivery = serviceDetails.getOvcUnicastFrameDelivery(); multicastFrameDelivery = serviceDetails.getOvcMulticastFrameDelivery();
						broadcastFrameDelivery = serviceDetails.getOvcBroadcastFrameDelivery(); evcovcnc = serviceDetails.getOvcEvcOvcNc();
						ceVlanIdPreservation=serviceDetails.getOvcCeVlanIdPreservation(); ceVlanCosPreservation=serviceDetails.getOvcCeVlanCosPreservation();
					}

					evcCircuitBuilder.buildEVCCircuit(serviceDetails.getServiceName(), serviceDetails.getServiceID(), null, "ARM", serviceDetails.getServiceType(), serviceDetails.getServiceProStatus(), null, null, serviceDetails.getAlias1(), serviceDetails.getAlias2(), serviceDetails.getServiceFuncStatus(), serviceSubType, null, ceVlanIdPreservation, ceVlanCosPreservation);
					if(cktSrNo!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("CircuitSerialNumber", cktSrNo);
					}
					if(mco!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("MCO", mco);
					}
					if(serviceDetails.getEvcMtu()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("MTU", serviceDetails.getEvcMtu());
					}
					if(evcovcnc!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("NCCode", evcovcnc);
					}
					if(cosId!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("COSID", cosId);
					}
					if(unicastFrameDelivery!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("UnicastFrameDelivery", unicastFrameDelivery);
					}
					if(multicastFrameDelivery!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("MulticastFrameDelivery", multicastFrameDelivery);
					}
					if(broadcastFrameDelivery!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("BroadcastFrameDelivery", broadcastFrameDelivery);
					}
					if(serviceDetails.getOvcMtu()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("MTU", serviceDetails.getOvcMtu());
					}
					if(serviceDetails.getsVlanIdPreservation()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("SVLANIDPreservation", serviceDetails.getsVlanIdPreservation());
					}
					if(serviceDetails.getsVlanCosPreservation()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("SVLANIDCosPreservation", serviceDetails.getsVlanCosPreservation());
					}
					if(serviceDetails.getColorForwarding()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("ColorForwarding", serviceDetails.getColorForwarding());
					}
					if(serviceDetails.getEvcOvcReference()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("EVCOVCReference", serviceDetails.getEvcOvcReference());
					}
					/*if(serviceDetails.getVpnId() != null)
					{
						evcCircuitBuilder.addResourceDescribedBy("VpnId", serviceDetails.getVpnId());
					}*/
					if(serviceDetails.getAsn() != null)
					{
						evcCircuitBuilder.addResourceDescribedBy("Asn", serviceDetails.getAsn());
					}
					if(serviceDetails.getExceptionHandlingText() != null)
					{
						evcCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", serviceDetails.getExceptionHandlingText());
					}

					//Code for Adding MaxValues
					if(maxValuesMap!=null)
					{
						if(serviceDetails.getServiceType().equalsIgnoreCase("MEF EVC"))
						{
							ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF EVC") ;
							if(null!=maxNameValues)
							{
								for(MaxNameValue maxValue : maxNameValues)
								{
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaximumUNIs"))
									{
										evcCircuitBuilder.addResourceDescribedBy("MaxUNI", maxValue.getMaxValue());
									}
								}
							}
						}
						if(serviceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
						{
							ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF OVC") ;
							if(null!=maxNameValues)
							{
								for(MaxNameValue maxValue : maxNameValues)
								{	
									if(maxValue.getMaxColName().equalsIgnoreCase("MaxNumUNIOVCEndPoints") && maxValue.getMaxColName()!=null)
									{
										evcCircuitBuilder.addResourceDescribedBy("MaxNumUNIOVCEndPoints", maxValue.getMaxValue());
									}
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumENNIOVCEndPoints"))
									{
										evcCircuitBuilder.addResourceDescribedBy("MaxNumENNIOVCEndPoints", maxValue.getMaxValue() );
									}
									if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCMembers"))
									{
										evcCircuitBuilder.addResourceDescribedBy("MaxNumOVCMembers", maxValue.getMaxValue() );
									}
								}
							}
						}

					}

					
					if(vpnIDListForEVC!=null && vpnIDListForEVC.size()>0 && vpnIDListForEVC.get(0)!=null && vpnIDListForEVC.get(0).getNumberType()!=null && vpnIDListForEVC.get(0).getNumberType().equalsIgnoreCase("VPN-ID"))
						evcCircuitBuilder.addResourceDescribedBy("VPN-ID", vpnIDListForEVC.get(0).getNumberValue());
					
					//Code for RelatedServices when Main Service is EVC/OVC
					if((null!=relatedServiceDetailsList && relatedServiceDetailsList.size()>0))
					{
						for(ARMCircuitDetails relatedServiceDetails:relatedServiceDetailsList)
						{
							if(null!=relatedServiceDetails)
							{
								if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF UNI"))
								{
									secNCICode = relatedServiceDetails.getUniSecNCICode(); specCode = relatedServiceDetails.getUniSpecCode(); 
									nciCode = relatedServiceDetails.getUniNCICode();ncCode = relatedServiceDetails.getUniNCCode(); 
									mco = relatedServiceDetails.getUniMCO();
								}
								if(	relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
								{
									secNCICode = relatedServiceDetails.getEnniSecNCICode(); specCode = relatedServiceDetails.getEnniSpecCode(); 
									nciCode = relatedServiceDetails.getEnniNCICode(); ncCode = relatedServiceDetails.getEnniNCCode();
									mco = relatedServiceDetails.getEnniMCO();
								}

								uniCircuitBuilder.buildUNICircuit(relatedServiceDetails.getServiceName(), relatedServiceDetails.getServiceID(), null, "ARM", relatedServiceDetails.getServiceType(), relatedServiceDetails.getServiceProStatus(), null, null,  relatedServiceDetails.getServiceFuncStatus(), null, null, null, null, null, null, null, null, null, null, bandwidth);
								/*resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
									connectionTerminationpointBuilder.buildConnectionTerminationPoint(null, null, null);*/

								enniTSP=relatedServiceDetails.getEnniTSP();
								uniTSP=relatedServiceDetails.getUniTSP();
								if(null!=enniTSP)
								{
									uniCircuitBuilder.addResourceDescribedBy("TSP", enniTSP);
								}
								if(null!=uniTSP)
								{
									uniCircuitBuilder.addResourceDescribedBy("TSP", uniTSP);
								}
								if(specCode!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("SpecCode", specCode);
								}
								if(ncCode!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("NCCode", ncCode);	
								}
								if(nciCode!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("NCICode", nciCode);
								}
								if(secNCICode!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("SECNCICode", secNCICode);
								}
								if(mco!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("MCO", mco);
								}
								if(relatedServiceDetails.getHpc()!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("HPCIndicator", relatedServiceDetails.getHpc());
								}
								if(relatedServiceDetails.getHpcExpDate()!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", relatedServiceDetails.getHpcExpDate());
								}
								if(relatedServiceDetails.getExceptionHandlingText()!=null)
								{
									uniCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", relatedServiceDetails.getExceptionHandlingText());
								}
									
								//Code for Adding MaxValues
								if(maxValuesMap!=null)
								{
									if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF UNI"))
									{
										ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF UNI") ;
										if(null!=maxNameValues)
										{
											for(MaxNameValue maxValue : maxNameValues)
											{
												if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumEVCs"))
												{
													uniCircuitBuilder.addResourceDescribedBy("MaxNumEVCs", maxValue.getMaxValue());
												}
											}
										}
									}
									if(relatedServiceDetails.getServiceType().equalsIgnoreCase("MEF ENNI"))
									{
										ArrayList<MaxNameValue> maxNameValues=(ArrayList<MaxNameValue>)maxValuesMap.get("MEF ENNI") ;
										if(null!=maxNameValues)
										{
											for(MaxNameValue maxValue : maxNameValues)
											{	
												if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCs"))
												{
													uniCircuitBuilder.addResourceDescribedBy("MaxNumOVCs", maxValue.getMaxValue() );
												}
												if(maxValue.getMaxColName()!=null && maxValue.getMaxColName().equalsIgnoreCase("MaxNumOVCEndPointsPerOVCs"))
												{
													uniCircuitBuilder.addResourceDescribedBy("MaxNumOVCEndpointsPerOVC", maxValue.getMaxValue());
												}
											}
										}
									}
								}
								if(null!=vlanRangeListForEVC && vlanRangeListForEVC.size()>0)
								{

									for(VlanDetails vlanDetails:vlanRangeListForEVC)
									{

										if(vlanDetails!=null)
										{
											if(vlanDetails.getNumberType()!=null && vlanDetails.getNumberType().equalsIgnoreCase("VLAN Range") && vlanDetails.getVlanPortID()!=null && relatedServiceDetails.getPortID()!=null && vlanDetails.getVlanPortID().equals(relatedServiceDetails.getPortID()))
											{
												uniCircuitBuilder.addResourceDescribedBy("VLANRange", vlanDetails.getNumberValue());	
											}
										}
									}
								}
								if(relatedServiceDetails.getServiceID()!=null)
								{
									List<QosDetails> qosDetailsForRelatedServiceList=serviceQosMap.get(relatedServiceDetails.getServiceID());
									if(null!=qosDetailsForRelatedServiceList && qosDetailsForRelatedServiceList.size()>0)
									{
										addQosDetails(qosDetailsForRelatedServiceList,null);
									}						

									List<VlanDetails> vlanDetailsForRelatedServiceList=serviceVlanMap.get(relatedServiceDetails.getServiceID());
									if(null!=vlanDetailsForRelatedServiceList && vlanDetailsForRelatedServiceList.size()>0)
									{
										addVlanDetails(vlanDetailsForRelatedServiceList);
									}
									List<ARMCircuitDetails> endnodeDetailsList=serviceNodeDetailsMap.get(relatedServiceDetails.getServiceID());
									if(null!=endnodeDetailsList && endnodeDetailsList.size()>0)
									{
										nodeDetails=endnodeDetailsList.get(0);
										connectionTerminationpointBuilder.buildConnectionTerminationPoint(null, null, null);
										logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
										if(nodeDetails.getLocationName()!=null)
										{
											americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
											connectionTerminationpointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
										}
										logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
										connectionTerminationpointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
										if(nodeDetails.getPortType()!=null)
										{
											if(nodeDetails.getPortType().equalsIgnoreCase("Pluggable") )
											{
												if(nodeDetails.getTransmissionRatePluggable() !=null)
													uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRatePluggable());
											}else 
											{								
												if(nodeDetails.getTransmissionRate()!=null)
													uniCircuitBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRate());
											}	
										}
										uniCircuitBuilder.addZEndTps(connectionTerminationpointBuilder.getConnectionTerminationPoint());
									}
								}
							}
							/*resourceRelationshipBuilder.addCTP(connectionTerminationpointBuilder.getConnectionTerminationPoint());
								uniCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());*/
							evcCircuitBuilder.addComprisedOfUNICircuit(uniCircuitBuilder.getUNICircuit());
						}
					}

					//Code for Adding Customer Info for Service
					if(serviceDetails.getHpc()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("HPCIndicator", serviceDetails.getHpc());
					}
					if(serviceDetails.getHpcExpDate()!=null)
					{
						evcCircuitBuilder.addResourceDescribedBy("HPCExpiryDate", serviceDetails.getHpcExpDate());
					}
					if(serviceDetails.getSubscriberID()!=null ||  serviceDetails.getBan()!=null)
					{
						evcCircuitBuilder.addOwnsResourceDetails(addCustomerData(serviceDetails, requiredRelatedCircuits));
					}

					searchResponseDetailsBuilder.addVoidCircuit(evcCircuitBuilder.getEVCCircuit());
				}
			}
			else
			{
				// Code for Service Details (NTM Case)
				if(null!=serviceDetails)
				{
					subNetworkConnectionBuilder.buildSubNetworkConnection(serviceDetails.getServiceName(), serviceDetails.getServiceID(), null, "ARM", serviceDetails.getServiceType(), serviceDetails.getServiceProStatus(), null, null, serviceDetails.getAlias1(), serviceDetails.getAlias2(), null, null);
				}
				if(serviceDetails.getUniMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", serviceDetails.getUniMCO());
				}
				if(serviceDetails.getEnniMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", serviceDetails.getEnniMCO());
				}
				if(serviceDetails.getEvcMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", serviceDetails.getEvcMCO());
				}
				if(serviceDetails.getOvcMCO()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MCO", serviceDetails.getOvcMCO());
				}
				if(serviceDetails.getUniIsDiverse()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse", serviceDetails.getUniIsDiverse());
				}
				if(serviceDetails.getDiverseUniId()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("DiverseUNIID", serviceDetails.getDiverseUniId());
				}
				if(serviceDetails.getMdsFlag()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("MDSFlag", serviceDetails.getMdsFlag());
				}
				if(serviceDetails.getServiceType()!=null)
				{
					if(serviceDetails.getServiceType().equalsIgnoreCase("MEF UNI")||serviceDetails.getServiceType().equalsIgnoreCase("MEF ENNI")||serviceDetails.getServiceType().equalsIgnoreCase("MEF EVC")||serviceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
					{
						subNetworkConnectionBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");
					}
				}
				if(serviceDetails.getExceptionHandlingText()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText",serviceDetails.getExceptionHandlingText());
				}

				// Code for Adding Customer Info
				if(serviceDetails.getHpc()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("HPCIndicator", serviceDetails.getHpc());
				}
				if(serviceDetails.getHpcExpDate()!=null)
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("HPCExpiryDate", serviceDetails.getHpcExpDate());
				}
				if(serviceDetails.getSubscriberID()!=null ||  serviceDetails.getBan()!=null)
				{
					subNetworkConnectionBuilder.addOwnsResourceDetails(addCustomerData(serviceDetails, requiredRelatedCircuits));
				}

				// Code for Adding ServiceEndPoints
				if(endPortDetailsList!=null && endPortDetailsList.size()>0 && !serviceDetails.getServiceType().equalsIgnoreCase("MEF EVC") && !serviceDetails.getServiceType().equalsIgnoreCase("MEF OVC"))
				{
					nodeDetails=endPortDetailsList.get(0);
					terminationPointBuilder.buildTerminationPoint(nodeDetails.getPortName(), null, nodeDetails.getInterfaceCategory());
					logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
					if(nodeDetails.getMonitoredStatus()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("isMonitored", nodeDetails.getMonitoredStatus());
					}
					if(nodeDetails.getExceptionHandlingText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("ExceptionHandlingText", nodeDetails.getExceptionHandlingText());
					}
					if(nodeDetails.getMoveActivityText()!=null)
					{
						terminationPointBuilder.addResourceDescribedBy("MoveActivityText", nodeDetails.getMoveActivityText());
					}
					if(nodeDetails.getLocationName()!=null)
					{
						americanPropertyAddressBuilder.buildAmericanPropertyAddress(nodeDetails.getLocationName(), null, null, null, null, null, null, null, null, null, null);
						terminationPointBuilder.addAccessPointAddress(americanPropertyAddressBuilder.getAmericanPropertyAddress());
					}
					logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(addNodeData(nodeDetails, requiredRelatedCircuits));
					terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
					subNetworkConnectionBuilder.addZEndTps(terminationPointBuilder.getTerminationPoint());
					if(nodeDetails.getPortType()!=null)
					{
						if(nodeDetails.getPortType().equalsIgnoreCase("Pluggable") )
						{
							if(nodeDetails.getTransmissionRatePluggable() !=null)
								subNetworkConnectionBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRatePluggable());
						}else 
						{								
							if(nodeDetails.getTransmissionRate()!=null)
								subNetworkConnectionBuilder.addResourceDescribedBy("AllowablePortType", nodeDetails.getTransmissionRate());
						}	
					}
				}
				searchResponseDetailsBuilder.addVoidCircuit(subNetworkConnectionBuilder.getSubNetworkConnection());
			}
			//	}
			return	searchResponseDetailsBuilder;//.getSearchResponseDetails();
			//return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
		}
		else
		{
			throw new OSSDataNotFoundException();
		}
	}

	private PhysicalDevice addNodeData(ARMCircuitDetails nodeDetails, Boolean requiredRelatedCircuits)
	{
		if(nodeDetails!=null)
		{
			//logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);
			//physicalDeviceBuilder.buildPhysicalDevice(nodeDetails.getDeviceName(), null, null, null, nodeDetails.getDeviceType(), null, nodeDetails.getDeviceStatus(), nodeDetails.getClli(), null, null, null, null, null, nodeDetails.getDevicesubType());
			physicalDeviceBuilder.buildPhysicalDevice(nodeDetails.getDeviceName(), null, null, null, nodeDetails.getDeviceType(), null, nodeDetails.getDeviceStatus(), nodeDetails.getClli(), null, null, null, null, null, nodeDetails.getDevicesubType(),
					null,null,null,null,null,null,null,null,null,null,null,null,null,null,nodeDetails.getNetworkName());
			if(nodeDetails.getMco()!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("MCO", nodeDetails.getMco());
			}
			if(nodeDetails.getLata()!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("LATA", nodeDetails.getLata());
			}
			if(nodeDetails.getPartType()!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("Model", nodeDetails.getPartType());
			}
			if(nodeDetails.getVendorName()!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("VendorName", nodeDetails.getVendorName());
			}
			if(nodeDetails.getStorageRAM()!=null)
			{
				physicalDeviceBuilder.addResourceDescribedBy("RAM", nodeDetails.getStorageRAM());
			}
			if(nodeDetails.getRole()!=null)
			{
				physicaldevicerolebuilder.buildPhysicalDeviceRole(nodeDetails.getRole());
				physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicaldevicerolebuilder.getPhysicaldevicerole());
			}
			if(nodeDetails.getRelayrackid()!=null || nodeDetails.getShelfName()!=null)
			{	
				physicalDeviceBuilder.addConsistsOfShelf(addShelfData(nodeDetails));
			}
			if(nodeDetails.getPortName()!=null && nodeDetails.getCardId()==null)
			{
				String portdpea;
				if(nodeDetails.getPortDpea()!=null)
				{
					portdpea=nodeDetails.getPortDpea();
				}
				else
				{
					portdpea=nodeDetails.getPortDpea1();	
				}
				physicalPortBuilder.buildPhysicalPort(nodeDetails.getPortName(), nodeDetails.getPortID(), null, null, portdpea, nodeDetails.getPluggableType(), null, null, nodeDetails.getLegacyPortName(), nodeDetails.getPortFuncT(), nodeDetails.getPortType(), null, nodeDetails.getFunctionalStatus(), null, null, null);				
				if(nodeDetails.getPortType()!=null)
				{
					if(nodeDetails.getPortType().equalsIgnoreCase("Pluggable") )
					{
						if(nodeDetails.getPluggableIfNum() != null)
							physicalPortBuilder.addResourceDescribedBy("IfNum", nodeDetails.getPluggableIfNum());

						if(nodeDetails.getNetworkPortNamePluggable()!=null)
							physicalPortBuilder.setVendorPortName(nodeDetails.getNetworkPortNamePluggable());

						if(nodeDetails.getTransmissionRatePluggable() !=null)
							physicalPortBuilder.addResourceDescribedBy("TransmissionRate", nodeDetails.getTransmissionRatePluggable());
					}else 
					{
						if(nodeDetails.getIfnum()!=null)
							physicalPortBuilder.addResourceDescribedBy("IfNum", nodeDetails.getIfnum());

						if(nodeDetails.getNetworkPortName() !=null)
							physicalPortBuilder.setVendorPortName(nodeDetails.getNetworkPortName());

						if(nodeDetails.getTransmissionRate()!=null)
							physicalPortBuilder.addResourceDescribedBy("TransmissionRate", nodeDetails.getTransmissionRate());
					}	
				}
				physicalPortBuilder.addResourceDescribedBy("TtServiceType", nodeDetails.getTtServiceType());
				physicalDeviceBuilder.addResourceDescribedBy("RelayRackId", nodeDetails.getRelayrackid());
				physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());
			}
			if(nodeDetails.getIpAddress()!=null || nodeDetails.getIpAddress1()!=null)
			{
				ipAddressBuilder.buildIPAddress(nodeDetails.getIpAddress(), "ManagementIP", null, null, null, "4");			
				physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
				ipAddressBuilder.buildIPAddress(nodeDetails.getIpAddress1(), "ManagementIP", null, null, null, "6");
				physicalDeviceBuilder.addIPAddress(ipAddressBuilder.getIPAddress());
			}
			if(requiredRelatedCircuits)
			{
				//DSP Case
				if(nodeDetails.getDeviceFullName()!=null)
				{
					physicalDeviceBuilder.addResourceDescribedBy("Fullname", nodeDetails.getDeviceFullName());
				}
				if(nodeDetails.getDeviceRelativeName()!=null)
				{
					ownsResourceDetailsBuilder.buildOwnsResourceDetails();
					customerBuilder.buildCustomer(nodeDetails.getDeviceRelativeName(), null, null,null , null, null,null);
					ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
					physicalDeviceBuilder.addOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
				}
			}
		}

		return physicalDeviceBuilder.getPhysicalDevice();
	}

	private Shelf addShelfData(ARMCircuitDetails portDetails )
	{
		ARMCard cardDetails = null;

		CardBuilder tempcardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();

		shelfBuilder.buildShelf(portDetails.getShelfName(), portDetails.getShelfId(), null, null, null, null, null, portDetails.getAlias1(), null, null, portDetails.getRelayrackid(), null);
		shelfBuilder.addResourceDescribedBy("ShelfNumber", portDetails.getShelfNumber());
		//Changes for CardOnCard
		if(portDetails.getStartNodeCards()!=null)
			cardDetails =portDetails.getStartNodeCards();
		else if(portDetails.getEndNodeCards()!=null)
			cardDetails =portDetails.getEndNodeCards();

		if(portDetails.getCardName()!=null)
		{
			slotBuilder.buildSlot(portDetails.getSlotName(), portDetails.getSlotId(), null, Integer.parseInt(portDetails.getSlotNumber()));
			if (cardDetails.getChildCards()!= null && cardDetails.getChildCards().size()>0)
			{
				ARMCard childcard = cardDetails.getChildCards().get(0);
				String portdpea;
				if(childcard.getParentCardName()!=null)
				{
					cardBuilder.buildCard(childcard.getParentCardName(), childcard.getParentCardID(), null, null, "ARM", null, null, childcard.getParentCardAliasName(), childcard.getParentSubType(), null);
					cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, String.valueOf(childcard.getSlotNumber()));
					tempcardBuilder.buildCard(childcard.getCommonName(), String.valueOf(childcard.getCardId()), null, null, null, null, null, childcard.getAliasName(), childcard.getSubType(), null);

					if(childcard.getDpea()!=null)
					{
						portdpea=childcard.getDpea();
					}
					else
					{
						portdpea=childcard.getDpea1();	
					}
					physicalPortBuilder.buildPhysicalPort(childcard.getPortName(), childcard.getPortId(), null, Integer.valueOf(portDetails.getPortNumber()),portdpea, childcard.getPluggableType(), null, null, childcard.getLegacyPortName(), childcard.getPortFunc(), childcard.getPortType(),null , null, null, null, null);
					if(childcard.getPortType()!=null)
					{
						if(childcard.getPortType().equalsIgnoreCase("Pluggable"))
						{
							if(childcard.getNetworkPortNamePluggable()!=null)	
								physicalPortBuilder.setVendorPortName(childcard.getNetworkPortNamePluggable());	

							if(childcard.getTransmissionRatePluggable() !=null)
								physicalPortBuilder.addResourceDescribedBy("TransmissionRate", childcard.getTransmissionRatePluggable());

						}else
						{
							if(childcard.getNetworkPortName() !=null)
								physicalPortBuilder.setVendorPortName(childcard.getNetworkPortName());		

							if(childcard.getTransmissionRate()!=null)
								physicalPortBuilder.addResourceDescribedBy("TransmissionRate", childcard.getTransmissionRate());
						}
					}					
					tempcardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
					cardOnCardDetailsBuilder.addCard(tempcardBuilder.getCard());
					cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
				}
				else
				{
					cardBuilder.buildCard(childcard.getCommonName(), String.valueOf(childcard.getCardId()), null, null, "ARM", null, null, childcard.getAliasName(), childcard.getSubType(), null);
					if(childcard.getDpea()!=null)
					{
						portdpea=childcard.getDpea();
					}
					else
					{
						portdpea=childcard.getDpea1();	
					}
					physicalPortBuilder.buildPhysicalPort(childcard.getPortName(), childcard.getPortId(), null, Integer.valueOf(portDetails.getPortNumber()), portdpea, childcard.getPluggableType(), null, null, childcard.getLegacyPortName(), childcard.getPortFunc(), childcard.getPortType(),null, null, null, null, null);
					if(childcard.getPortType()!=null)
					{
						if(childcard.getPortType().equalsIgnoreCase("Pluggable"))
						{
							if(childcard.getNetworkPortNamePluggable()!=null)	
								physicalPortBuilder.setVendorPortName(childcard.getNetworkPortNamePluggable());	

							if(childcard.getTransmissionRatePluggable() !=null)
								physicalPortBuilder.addResourceDescribedBy("TransmissionRate", childcard.getTransmissionRatePluggable());

						}else
						{
							if(childcard.getNetworkPortName() !=null)
								physicalPortBuilder.setVendorPortName(childcard.getNetworkPortName());		

							if(childcard.getTransmissionRate()!=null)
								physicalPortBuilder.addResourceDescribedBy("TransmissionRate", childcard.getTransmissionRate());
						}
					}
					cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
				}
			}
			slotBuilder.addHasCard(cardBuilder.getCard());
			shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
		}

		return shelfBuilder.getShelf();
	}

	private OwnsResourceDetails addCustomerData(ARMCircuitDetails ckt, Boolean requiredRelatedCircuits)
	{
		String subscriberName = ckt.getSubscriberName();
		ownsResourceDetailsBuilder.buildOwnsResourceDetails();
		customerBuilder.buildCustomer(subscriberName, ckt.getSubscriberID(), null, ckt.getSubscriberFullName(), null, null,null);
		if(ckt.getBan()!=null)
		{
			customerAccountBuilder.buildCustomerAccount(ckt.getBan(), "BAN");
			customerBuilder.addCustomerPosseses(customerAccountBuilder.getCustomerAccount());
		}
		ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
		if(requiredRelatedCircuits)
		{
			//DSP Case
			if(ckt.getSubscriberFullName()!=null)
			{
				customerAgentBuilder.buildCustomerAgent(ckt.getSubscriberFullName(), null);
				if(ckt.getSubscriberFullName()!=null || ckt.getSubscriberFirstName()!=null || ckt.getSubscriberLastName()!=null)
				{	
					customerAgentBuilder.addRootEntityDescribedBy("FullName", ckt.getSubscriberFullName());
					customerAgentBuilder.addRootEntityDescribedBy("FirstName", ckt.getSubscriberFirstName());
					customerAgentBuilder.addRootEntityDescribedBy("LastName", ckt.getSubscriberLastName());
				}
				ownsResourceDetailsBuilder.addCustomerAgent(customerAgentBuilder.getCustomerAgent());
			}
		}

		return ownsResourceDetailsBuilder.getOwnsResourceDetails();
	}

	private void addVlanDetails(List<VlanDetails> vlanDetailsForRelatedServiceList)
	{
		if(vlanDetailsForRelatedServiceList!=null && vlanDetailsForRelatedServiceList.size()>0 )
		{
			for(VlanDetails vlandetailsForRelatedService:vlanDetailsForRelatedServiceList)
			{

				if(vlandetailsForRelatedService.getNumberType()!=null && vlandetailsForRelatedService.getNumberType().equalsIgnoreCase("VLAN"))
				{
					if(vlandetailsForRelatedService.getVlanFunction()!=null)
					{
						if(vlandetailsForRelatedService.getVlanFunction().equalsIgnoreCase("S-VLAN"))
							uniCircuitBuilder.addResourceDescribedBy("SVLAN", vlandetailsForRelatedService.getNumberValue());

						else if(vlandetailsForRelatedService.getVlanFunction()!=null && vlandetailsForRelatedService.getVlanFunction().equalsIgnoreCase("CE-VLAN"))
							uniCircuitBuilder.addResourceDescribedBy("CEVLAN", vlandetailsForRelatedService.getNumberValue());
					}
				}
				if(vlandetailsForRelatedService.getNumberValue() !=null)
				{ 
					if(vlandetailsForRelatedService.getNumberType()!=null && vlandetailsForRelatedService.getNumberType().equalsIgnoreCase("S-VLAN"))
						uniCircuitBuilder.addResourceDescribedBy("SVLAN", vlandetailsForRelatedService.getNumberValue());
					if(vlandetailsForRelatedService.getNumberType()!=null && vlandetailsForRelatedService.getNumberType().equalsIgnoreCase("VLAN Range"))
						uniCircuitBuilder.addResourceDescribedBy("SubVLANRange", vlandetailsForRelatedService.getNumberValue());
					if(vlandetailsForRelatedService.getNumberType()!=null && vlandetailsForRelatedService.getNumberType().equalsIgnoreCase("CE-VLAN"))
						uniCircuitBuilder.addResourceDescribedBy("CEVLAN", vlandetailsForRelatedService.getNumberValue());
				}
			}
		}
	}

	private void addQosDetails(List<QosDetails> qosDetailsForRelatedServiceList,List<ARMEVCVlan> evcVlanList)
	{
		if(qosDetailsForRelatedServiceList!=null && qosDetailsForRelatedServiceList.size()>0)
		{
			CosBundleBuilder cosABundleBuilder= new CosBundleBuilder();
			CosBundleBuilder cosBBundleBuilder= new CosBundleBuilder();
			CosBundleBuilder cosCBundleBuilder= new CosBundleBuilder();
			CosBundleBuilder cosDBundleBuilder= new CosBundleBuilder();

			boolean cosADataExists=false; 
			boolean cosBDataExists=false;
			boolean cosCDataExists=false;
			boolean cosDDataExists=false;
			boolean cosAEVC=false; 
			boolean cosBEVC=false;
			boolean cosCEVC=false;
			boolean cosDEVC=false;
			for(QosDetails qosdetails:qosDetailsForRelatedServiceList)
			{
				if(qosdetails!=null)
				{
					if(qosdetails.getParameterClass()!=null )
					{
						String evcId=null;
						if(evcVlanList!=null && evcVlanList.size()>0)
						{
							for (ARMEVCVlan evcVlan :evcVlanList)
							{
								if(qosdetails.getParameterObject()!=null && evcVlan.getVlanPortID()!=null  
										&& qosdetails.getParameterObject().equals(evcVlan.getVlanPortID()))
								{
									evcId=evcVlan.getevcOvcID();
									break;
								}
							}
						}
						if(qosdetails.getParameterClass().equalsIgnoreCase("Class A"))
						{
							if(cosABundleBuilder.getCoSBundle() == null)
								cosABundleBuilder.buildCoSBundle(qosdetails.getParameterName(), null, null, null);

							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("CIR", qosdetails.getParameterIntegerValueForCIR());
								cosABundleBuilder.addP1(priorityBuilder.getPriority());
								cosADataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("EIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("EIR", qosdetails.getParameterIntegerValueForEIR());
								cosABundleBuilder.addP2(priorityBuilder.getPriority());
								cosADataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("BW"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("Bandwidth", qosdetails.getParameterIntegerValueForBW());
								cosABundleBuilder.addP3(priorityBuilder.getPriority());
								cosADataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CoS Value"))
							{
								cosABundleBuilder.addRootEntityDescribedBy("CoSValue", qosdetails.getParameterIntegerValueForCOS());
								cosADataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("LOS Name"));
							{
								cosABundleBuilder.addRootEntityDescribedBy("LoSName", qosdetails.getParameterStringValueForLOSName());
								cosADataExists=true;
							}

							if(evcId!=null && !cosAEVC)
							{	
								cosABundleBuilder.addRootEntityDescribedBy("EVCId", evcId);
								cosAEVC=true;
							}
						}
						if(qosdetails.getParameterClass().equalsIgnoreCase("Class B"))
						{
							if(cosBBundleBuilder.getCoSBundle() == null)
								cosBBundleBuilder.buildCoSBundle(qosdetails.getParameterName(), null, null, null);

							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("CIR", qosdetails.getParameterIntegerValueForCIR());
								cosBBundleBuilder.addP1(priorityBuilder.getPriority());
								cosBDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("EIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("EIR", qosdetails.getParameterIntegerValueForEIR());
								cosBBundleBuilder.addP2(priorityBuilder.getPriority());
								cosBDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("BW"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("Bandwidth", qosdetails.getParameterIntegerValueForBW());
								cosBBundleBuilder.addP3(priorityBuilder.getPriority());
								cosBDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CoS Value"))
							{
								cosBBundleBuilder.addRootEntityDescribedBy("CoSValue", qosdetails.getParameterIntegerValueForCOS());
								cosBDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("LoS Name"));
							{
								cosBBundleBuilder.addRootEntityDescribedBy("LoSName", qosdetails.getParameterStringValueForLOSName());
								cosBDataExists=true;
							}
							if(evcId!=null && !cosBEVC)
							{	
								cosBBundleBuilder.addRootEntityDescribedBy("EVCId", evcId);
								cosBEVC=true;
							}
						}
						if(qosdetails.getParameterClass().equalsIgnoreCase("Class C"))
						{
							if(cosCBundleBuilder.getCoSBundle() == null)
								cosCBundleBuilder.buildCoSBundle(qosdetails.getParameterName(), null, null, null);

							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("CIR", qosdetails.getParameterIntegerValueForCIR());
								cosCBundleBuilder.addP1(priorityBuilder.getPriority());						
								cosCDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("EIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("EIR", qosdetails.getParameterIntegerValueForEIR());
								cosCBundleBuilder.addP2(priorityBuilder.getPriority());
								cosCDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("BW"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("Bandwidth", qosdetails.getParameterIntegerValueForBW());
								cosCBundleBuilder.addP3(priorityBuilder.getPriority());
								cosCDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CoS Value"))
							{
								cosCBundleBuilder.addRootEntityDescribedBy("CoSValue", qosdetails.getParameterIntegerValueForCOS());
								cosCDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("LoS Name"));
							{
								cosCBundleBuilder.addRootEntityDescribedBy("LoSName", qosdetails.getParameterStringValueForLOSName());
								cosCDataExists=true;
							}
							if(evcId!=null && !cosCEVC)
							{	
								cosCBundleBuilder.addRootEntityDescribedBy("EVCId", evcId);
								cosCEVC=true;
							}
						}
						if(qosdetails.getParameterClass().equalsIgnoreCase("Class D"))
						{

							if(cosDBundleBuilder.getCoSBundle() == null)
								cosDBundleBuilder.buildCoSBundle(qosdetails.getParameterName(), null, null, null);

							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("CIR", qosdetails.getParameterIntegerValueForCIR());
								cosDBundleBuilder.addP1(priorityBuilder.getPriority());
								cosDDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("EIR"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("EIR", qosdetails.getParameterIntegerValueForEIR());
								cosDBundleBuilder.addP2(priorityBuilder.getPriority());
								cosDDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("BW"))
							{
								priorityBuilder.buildProirity(null, null, null, null);
								priorityBuilder.setNameValue("Bandwidth", qosdetails.getParameterIntegerValueForBW());
								cosDBundleBuilder.addP3(priorityBuilder.getPriority());
								cosDDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("CoS Value"))
							{
								cosDBundleBuilder.addRootEntityDescribedBy("CoSValue", qosdetails.getParameterIntegerValueForCOS());
								cosDDataExists=true;
							}
							if(qosdetails.getParameterDefinition().equalsIgnoreCase("LoS Name"));
							{
								cosDBundleBuilder.addRootEntityDescribedBy("LoSName", qosdetails.getParameterStringValueForLOSName());
								cosDDataExists=true;
							}
							if(evcId!=null && !cosDEVC)
							{	
								cosDBundleBuilder.addRootEntityDescribedBy("EVCId", evcId);
								cosDEVC=true;
							}
						}
					}
				}
			}
			if(cosADataExists)
				uniCircuitBuilder.addQoSBandwidth(cosABundleBuilder.getCoSBundle());
			if(cosBDataExists)
				uniCircuitBuilder.addQoSBandwidth(cosBBundleBuilder.getCoSBundle());

			if(cosDDataExists)
				uniCircuitBuilder.addQoSBandwidth(cosDBundleBuilder.getCoSBundle());
			if(cosCDataExists)
				uniCircuitBuilder.addQoSBandwidth(cosCBundleBuilder.getCoSBundle());
		}
	}
}