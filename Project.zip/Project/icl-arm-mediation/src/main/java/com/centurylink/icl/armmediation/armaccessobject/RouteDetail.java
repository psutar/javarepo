package com.centurylink.icl.armmediation.armaccessobject;

public class RouteDetail {
	private Long routeDetailId;
	private Long routeHeaderId;
	private int seqNo;
	private String assetObject;
	private String assetType;
	private String assetValue;
	
	public Long getRouteDetailId() {
		return routeDetailId;
	}
	public void setRouteDetailId(Long routeDetailId) {
		this.routeDetailId = routeDetailId;
	}
	public Long getRouteHeaderId() {
		return routeHeaderId;
	}
	public void setRouteHeaderId(Long routeHeaderId) {
		this.routeHeaderId = routeHeaderId;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getAssetObject() {
		return assetObject;
	}
	public void setAssetObject(String assetObject) {
		this.assetObject = assetObject;
	}
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getAssetValue() {
		return assetValue;
	}
	public void setAssetValue(String assetValue) {
		this.assetValue = assetValue;
	}
}
