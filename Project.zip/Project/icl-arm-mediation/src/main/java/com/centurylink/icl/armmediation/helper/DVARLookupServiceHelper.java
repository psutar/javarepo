package com.centurylink.icl.armmediation.helper;

import com.centurylink.icl.armmediation.service.impl.DVARLookupService;

/*
 * This class allow access to the CLCLookupService from a static context
 */

public class DVARLookupServiceHelper {
	
	private static DVARLookupService lookupService;

	public static DVARLookupService getDVARLookupService()
	{
		return lookupService;
	}

	public void setLookupService(DVARLookupService lookupService)
	{
		DVARLookupServiceHelper.lookupService = lookupService;
	}


}
