package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.service.MDWConstants;

public class UpdatePortSFPAttribute
{

	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private JDBCTempleteUtil jdbcTempleteUtil;
	private SetObjectAttributeHelper setObjectAttributeHelper;

	public Map<String, Object> updatePortSFPAttribute(HashMap<String, Object> iHashMap) throws Exception
	{
		if (LOG.isInfoEnabled())
		{
			LOG.info("Updating Port SFP Attribute");
		}

		final String SFPName = MediationUtil.getValueFromMap(iHashMap, MDWConstants.SFP_NAME);
		HashMap<String, Object> PortSfpAttr = null;
		try
		{
			PortSfpAttr = jdbcTempleteUtil.getSFPAttribute(SFPName);
		} catch (IndexOutOfBoundsException e)
		{
			if (LOG.isInfoEnabled())
			{
				LOG.info("Could not find object to be updated");
			}
			iHashMap.put(Constants.O_ERROR_CODE, new Integer(0));
			iHashMap.put(Constants.O_ERROR_TEXT, "Could not find object to be updated ");
			return iHashMap;
		}
		final String portId = MediationUtil.getValueFromMap(iHashMap, MDWConstants.PORT_ID);
		final Map<String, Object> map = setObjectAttributeHelper.execute("Port", new BigDecimal(portId), PortSfpAttr);
		final BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			iHashMap.put(MDWConstants.errorCode, o_ErrorCode);
			iHashMap.put(MDWConstants.errorMessage, o_Errormsg);
		}
		else
		{
			iHashMap.put(MDWConstants.errorCode, new Integer(0));
		}
		
		return iHashMap;
	}

	public void setSetObjectAttributeHelper(SetObjectAttributeHelper setObjectAttributeHelper)
	{
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

}
