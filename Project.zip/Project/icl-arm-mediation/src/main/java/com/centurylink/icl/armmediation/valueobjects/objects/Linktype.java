package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class Linktype extends AbstractReadOnlyTable {

	private static final String NAME = "NAME";
	private static final String TABLENAME = "TABLENAME";
	private static final String CLASS = "CLASS";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String LABEL = "LABEL";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LINKTYPEID = "LINKTYPEID";
	private static final String LINKTYPE2GRAPHICSBITMAP = "LINKTYPE2GRAPHICSBITMAP";
	private static final String LINKTYPE2BROWSERBITMAP = "LINKTYPE2BROWSERBITMAP";
	private static final String RESOLUTIONBEHAVIOUR = "RESOLUTIONBEHAVIOUR";
	private static final String LENGTHCALLOUT = "LENGTHCALLOUT";

	public Linktype() {
		super();
		this.tableName = "LINKTYPE";
	}

	public Linktype(String key) {
		this();
		primaryKey.setValue(key);
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Linktype> getLinktypeListByQuery(String query) {
		Linktype linktype = new Linktype();
		List<Linktype> linktypeList = new ArrayList<Linktype>();
		List<Map<String, Object>> foundLinktypeList = linktype
				.getRecordsByQuery(query);

		for (Map<String, Object> linktypeMap : foundLinktypeList) {
			Linktype workCircuittype = new Linktype(linktypeMap.get(LINKTYPEID)
					.toString());
			linktypeList.add(workCircuittype);
		}
		return linktypeList;
	}

	@Override
	public void populateModel() {

		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(CLASS, new Field(CLASS, Field.TYPE_VARCHAR));
		fields.put(TABLENAME, new Field(TABLENAME, Field.TYPE_VARCHAR));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(LINKTYPEID, new Field(LINKTYPEID, Field.TYPE_NUMERIC));
		fields.put(LINKTYPE2GRAPHICSBITMAP, new Field(LINKTYPE2GRAPHICSBITMAP,
				Field.TYPE_NUMERIC));
		fields.put(LINKTYPE2BROWSERBITMAP, new Field(LINKTYPE2BROWSERBITMAP,
				Field.TYPE_NUMERIC));
		fields.put(RESOLUTIONBEHAVIOUR, new Field(RESOLUTIONBEHAVIOUR,
				Field.TYPE_NUMERIC));
		fields.put(LENGTHCALLOUT, new Field(LENGTHCALLOUT, Field.TYPE_VARCHAR));

		primaryKey = new PrimaryKey(fields.get(LINKTYPEID));
	}

	public void setLabel(String label) {
		setField(LABEL, label);
	}

	public String getLabel() {
		return getFieldAsString(LABEL);
	}

	public void setIsvisible(String isvisible) {
		setField(ISVISIBLE, isvisible);
	}

	public String getIsvisible() {
		return getFieldAsString(ISVISIBLE);
	}

	public void setDescription(String description) {
		setField(DESCRIPTION, description);
	}

	public String getDescription() {
		return getFieldAsString(DESCRIPTION);
	}

	public void setTablename(String tablename) {
		setField(TABLENAME, tablename);
	}

	public String getTablename() {
		return getFieldAsString(TABLENAME);
	}

	public void setName(String name) {
		setField(NAME, name);
	}

	public String getName() {
		return getFieldAsString(NAME);
	}

	public void setLinktypeid(String linktypeid) {
		setField(LINKTYPEID, linktypeid);
	}

	public String getLinktypeid() {
		return getFieldAsString(LINKTYPEID);
	}

	public void setLinkType2GraphicsBitmap(String linkType2GraphicsBitmap) {
		setField(LINKTYPE2GRAPHICSBITMAP, linkType2GraphicsBitmap);
	}

	public String getLinkType2GraphicsBitmap() {
		return getFieldAsString(LINKTYPE2GRAPHICSBITMAP);
	}

	public void setLinkType2BrowserBitmap(String linkType2BrowserBitmap) {
		setField(LINKTYPE2BROWSERBITMAP, linkType2BrowserBitmap);
	}

	public String getLinkType2BrowserBitmap() {
		return getFieldAsString(LINKTYPE2BROWSERBITMAP);
	}

	public void setClass(String class1) {
		setField(CLASS, class1);
	}

	public String getClass1() {
		return getFieldAsString(CLASS);
	}

	public void setResolutionBehaviour(String resolutionBehaviour) {
		setField(RESOLUTIONBEHAVIOUR, resolutionBehaviour);
	}

	public String getResolutionBehaviour() {
		return getFieldAsString(RESOLUTIONBEHAVIOUR);
	}

	public void setLengthCallOut(String lengthCallOut) {
		setField(LENGTHCALLOUT, lengthCallOut);
	}

	public String getLengthCallOut() {
		return getFieldAsString(LENGTHCALLOUT);
	}

}