package com.centurylink.icl.armmediation.transformation;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuit;
import com.centurylink.icl.armmediation.valueobjects.objects.CircuitExtension;
import com.centurylink.icl.armmediation.valueobjects.objects.Circuitcircuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Link;
import com.centurylink.icl.armmediation.valueobjects.objects.LinkCircuit;
import com.centurylink.icl.armmediation.valueobjects.objects.Location;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.PluggableType;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Service;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.ConnectionTerminationPointBuilder;
import com.centurylink.icl.builder.cim2.LogicalPhysicalResourceBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.Point2PointCircuitBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.RouteBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.cim2.SubNetworkConnectionBuilder;
import com.centurylink.icl.builder.cim2.TerminationPointBuilder;
import com.centurylink.icl.builder.cim2.TopologicalLinkBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.ConnectionTerminationPoint;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.Point2PointCircuit;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TerminationPoint;
import com.iclnbi.iclnbiV200.TopologicalLink;

public class SearchCircuitVOTransformation {

	private static final Log LOG = LogFactory.getLog(SearchCircuitVOTransformation.class);

	public static SearchResourceResponseDocument transformToCIM(List<Circuit> circuits, VOSearchHolder searchHolder) throws Exception
	{
		String entityType = null;
		if (searchHolder.getModifiers().containsKey("RESOURCETYPE") || searchHolder.getModifiers().containsKey("ENTITYTYPE"))
		{
			String tempEntity = searchHolder.getModifiers().containsKey("RESOURCETYPE")?searchHolder.getModifiers().get("RESOURCETYPE"):searchHolder.getModifiers().get("ENTITYTYPE");
			if (tempEntity.equalsIgnoreCase("NMI"))
				entityType = "NMI";
			if(tempEntity.equalsIgnoreCase("NNI"))
				entityType = "NNI";
			if (tempEntity.equalsIgnoreCase("LAG"))
				entityType = "LAG";
			if (tempEntity.equalsIgnoreCase("PW Unrouted"))
				entityType = "PW Unrouted";
			else if(tempEntity.equalsIgnoreCase("CIRCUIT"))
				entityType="CIRCUIT";
		}

		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		boolean datafound =false;
		if(circuits!=null && circuits.size()>0)
		{
			for (Circuit circuit:circuits)
			{
				if(circuit!=null)
				{
					if (StringHelper.isEmpty(searchHolder.getModifiers().get("RESOURCETYPE")) && StringHelper.isEmpty(searchHolder.getModifiers().get("ENTITYTYPE")))
					{
						if (circuit.getCircuittype().getName().equals("PON Circuit (T)")) 
						{
							searchResponseDetailsBuilder.addCircuit(buildPonCircuit(circuit,searchHolder.getLevel(),searchHolder.getScope(),searchHolder.getModifiers()));
							datafound = true;
						} 
						else
						{
							searchResponseDetailsBuilder.addCircuit(buildCircuit(circuit, searchHolder.getLevel(), searchHolder.getScope(), searchHolder.getModifiers()));
							datafound =true;
						}
					}
					else if(entityType!=null)
					{
						if ((entityType.equals("NMI") && circuit.getCircuittype().getName().equals("Unrouted Ethernet Bearer") && circuit.getCircuitExtension().getCircuitservicetype().equalsIgnoreCase("NMI"))||(entityType.equals("NNI") && circuit.getCircuittype().getName().equals("Unrouted Ethernet Bearer") && circuit.getCircuitExtension().getCircuitservicetype().equalsIgnoreCase("NNI"))||(entityType.equals("LAG")&& circuit.getCircuittype().getName().equals("Link Aggregation Group"))||(entityType.equals("PW Unrouted"))&& circuit.getCircuittype().getName().equals("PW Unrouted"))
						{
							searchResponseDetailsBuilder.addP2PCircuit(buildNMICircuit(circuit, searchHolder.getLevel(), searchHolder.getScope(), searchHolder.getModifiers()));
							datafound =true;
						}
						else if (entityType.equals("CIRCUIT"))
						{
							searchResponseDetailsBuilder.addCircuit(buildCircuit(circuit, searchHolder.getLevel(), searchHolder.getScope(), searchHolder.getModifiers()));
							datafound =true;
						}
					}
				}
			}
		}	
		if(!datafound)
		{
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());

		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}


		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	public static SearchResourceResponseDocument transformToCIM(Circuit circuit, VOSearchHolder searchHolder) throws Exception
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		searchResponseDetailsBuilder.addCircuit(buildCircuit(circuit, searchHolder.getLevel(), searchHolder.getScope(), searchHolder.getModifiers()));

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());

		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}


		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	private static SubNetworkConnection buildPonCircuit(Circuit circuit,
			String level, String scope, Map<String, String> modifiers)
					throws Exception {
		boolean includeRelationships = false;
		boolean includeLocationDetails = false;
		if (modifiers.containsKey("INCLUDERELATIONSHIPS")) {
			if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE")) {
				includeRelationships = true;
			}
		}

		if (modifiers.containsKey("INCLUDECLCLOCATION")) {
			if (modifiers.get("INCLUDECLCLOCATION").equalsIgnoreCase("TRUE")) {
				includeLocationDetails = true;
			}
		}

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		RouteBuilder routeBuilder = new RouteBuilder();

		List<TopologicalLink> topologicalList = new ArrayList<TopologicalLink>();
		TopologicalLinkBuilder topologicalLinkBuilder = new TopologicalLinkBuilder();

		if (scope.equalsIgnoreCase("BASIC")) {
			subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null, null, null, circuit.getFunctionalstatus().getName(), null);
		} 
		else
		{

			if (circuit.getCircuittype() != null && circuit.getCircuittype().getName().equalsIgnoreCase("PON Circuit (T)"))
			{
				subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM",
						circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null,null, null, circuit.getFunctionalstatus().getName(),null);
				remarkBuilder.buildRemark(circuit.getCircuitExtension().getRestrictedNotes(), "RestrictedNotes");
				subNetworkConnectionBuilder.addRemark(remarkBuilder.getRemarks());
				subNetworkConnectionBuilder.addResourceDescribedBy("RestrictedStatus", circuit.getCircuitExtension().getrestrictedStatus());
				subNetworkConnectionBuilder.addResourceDescribedBy("MCO",  circuit.getCircuitExtension().getMco());
				subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse",  circuit.getCircuitExtension().getIsDiverse());
				subNetworkConnectionBuilder.addResourceDescribedBy("TSP",  circuit.getCircuitExtension().getTsp());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitRole", circuit.getCircuitExtension().getCircuitservicetype());
				subNetworkConnectionBuilder.addResourceDescribedBy("DiverseCircuitID", circuit.getCircuitExtension().getDiverseCircuitId());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitSerialNumber", circuit.getCircuitExtension().getCircuitserialnumber());
				subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
				subNetworkConnectionBuilder.addResourceDescribedBy("ModificationUserId", circuit.getCircuitExtension().getModificationUserId());
				subNetworkConnectionBuilder.addResourceDescribedBy("SRCSYS", circuit.getCircuitExtension().getsrcsys());



				List<Circuitcircuit> circuitcircuitList = new ArrayList<Circuitcircuit>();
				//			circuitcircuitList = Circuitcircuit.getCircuitcircuitListByUsedBy(circuit.getCircuitid());

				Circuitcircuit circuitCircuit=new Circuitcircuit();
				circuitcircuitList = circuitCircuit.getCircuitcircuitListPONByUsedBy(circuit.getCircuitid());



				if (circuitcircuitList != null && circuitcircuitList.size() > 0)
				{
					int circuitNumber = 1;
					String startNodeForNextLink = null;
					for (Circuitcircuit ckt : circuitcircuitList)
					{
						if (ckt != null)
						{
							String linkid = LinkCircuit.getLinkCircuit2LinkByCircuitid((ckt.getUses2circuit()).toString());

							//building Route
							routeBuilder.buildRoute();
							Link link = new Link(linkid);

							// Building topological Link
							topologicalLinkBuilder.buildTopologicalLink(link.getName(),link.getLinkid(), null, null,link.getLinktype().getName(),link.getProvisionstatus().getName(), null, null,null);
							remarkBuilder.buildRemark(link.getLinkExtension().getRestrictedNotes(),"RestrictedNotes");
							topologicalLinkBuilder.addRemark(remarkBuilder.getRemarks());
							topologicalLinkBuilder.addResourceDescribedBy("CableId", link.getLinkExtension().getCableid());
							topologicalLinkBuilder.addResourceDescribedBy("StrandId",link.getLinkExtension().getStrandid());
							topologicalLinkBuilder.addResourceDescribedBy("AerialOrBuried",link.getLinkExtension().getAerialorBuried());
							//topologicalLinkBuilder .addResourceDescribedBy("FunctionalStatus",link.getFunctionalstatus().getName());
							topologicalLinkBuilder .addResourceDescribedBy("RestrictedStatus",link.getLinkExtension().getrestrictedStatus());
							topologicalLinkBuilder.setFunctionalStatus(link.getFunctionalstatus().getName());
							Circuit uderlyingCircuit = new Circuit(ckt.getUses2circuit());
							Node startnode = new Node(uderlyingCircuit.getCircuit2startnode());
							Node endNode = new Node(uderlyingCircuit.getCircuit2endnode());
							// Start - To set link as per the route.
							if (null != startNodeForNextLink) {
								List<Networkroleobject> networkroleobjectList = endNode
										.getNetworkroleobjects();
								List<String> roleList = new ArrayList<String>();
								for(Networkroleobject  networkroleobject : networkroleobjectList)
								{
									String role = networkroleobject.getNetworkroleobject2networkrole();
									roleList.add(role);
								}
								if(!roleList.contains("ONT")){
									if (startNodeForNextLink == startnode.getNodeid()) {
										topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(startnode, link.getStartPort(), includeLocationDetails));
										topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(endNode, link.getEndPort(), includeLocationDetails));
										startNodeForNextLink = endNode.getNodeid();										
									} else if (startNodeForNextLink == endNode.getNodeid()) {
										topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(endNode, link.getEndPort(), includeLocationDetails));
										topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(startnode, link.getStartPort(), includeLocationDetails));
										startNodeForNextLink = startnode.getNodeid();										
									}
								}else{ 
									topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(endNode, link.getEndPort(), includeLocationDetails));
									topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(startnode, link.getStartPort(), includeLocationDetails));
								}
							}

							if (circuitNumber == 1) {
								List<Networkroleobject> networkroleobjectList = startnode
										.getNetworkroleobjects();
								List<String> roleList = new ArrayList<String>();

								if (null != networkroleobjectList
										&& networkroleobjectList.size() > 0) {
									for(Networkroleobject  networkroleobject : networkroleobjectList)
									{
										String role = networkroleobject.getNetworkroleobject2networkrole();
										roleList.add(role);
									}
									if (roleList.contains("OLT")) {
										topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(startnode, link.getStartPort(), includeLocationDetails));
										topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(endNode, link.getEndPort(), includeLocationDetails));
										startNodeForNextLink = endNode.getNodeid();										
									} else {
										topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(endNode, link.getEndPort(), includeLocationDetails));
										topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(startnode, link.getStartPort(), includeLocationDetails));
										startNodeForNextLink = startnode.getNodeid();										
									}
								}
							}
							circuitNumber++;

							// End - To set link as per the route.

							//topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(endNode,link.getEndPort()));
							//topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(startnode,link.getStartPort()));
							/*	topologicalLinkBuilder.addZEndTps(buildPhysicalDevice(endNode,uderlyingCircuit.getEndPort().getTopLevelPort()));
							topologicalLinkBuilder.addAEndTps(buildPhysicalDevice(startnode,uderlyingCircuit.getStartPort().getTopLevelPort()));
							 */
							topologicalList.add(topologicalLinkBuilder.getTopologicalLink());
						}
					}
				}
				for (TopologicalLink topologicalBuild : topologicalList) {
					routeBuilder.addTopologicalLink(topologicalBuild);
				}
				subNetworkConnectionBuilder.addRoute(routeBuilder.getRoute());

				subNetworkConnectionBuilder.addZEndTps(buildPhysicalDevice(circuit.getEndNode(), circuit.getEndPort().getTopLevelPort(), includeLocationDetails));
				subNetworkConnectionBuilder.addAEndTps(buildPhysicalDevice(circuit.getStartNode(), circuit.getStartPort().getTopLevelPort(), includeLocationDetails));
			}
		}


		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}

	private static ConnectionTerminationPoint buildPhysicalDevice(Node node,Port port, boolean includeLocationDetails) throws Exception {

		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();

		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		// Building Physical Device

		//physicalDeviceBuilder.buildPhysicalDevice(node.getName(),node.getNodeid(), null, null,node.getNodeType().getName(), null, node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), null, null, node.getNodeExtension().getParttype(), null, node.getNodeExtension().getVendorname(), null, null, node.getFunctionalstatus().getName(),null,node.getNodeExtension().getVendorname());
		physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, null, node.getNodeType().getName(), null, node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), null, null, node.getNodeExtension().getParttype(), null, node.getNodeExtension().getVendorname(), null, null, node.getFunctionalstatus().getName(), null, null, node.getSoftwareversion(), null, node.getNodeExtension().getSerialnumber(), null, node.getNodeExtension().getManufacturerpartnumber(), null, null, null, null, null, null);
		//(node.getName(), node.getNodeid(), null, null, node.getNodeType().getName(), null,node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), null, null, null, null, node.getNodeExtension().getVendorname(), null, null, node.getFunctionalstatus().getName());
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null,null, null, null);

		//logicalPhysicalResourceBuilder.addPhysicalDevice(physicalDeviceBuilder.getPhysicalDevice());
		remarkBuilder.buildRemark(node.getNodeExtension().getRestrictednotes(),"RestrictedNotes");
		physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
		//physicalDeviceBuilder.addResourceDescribedBy("FunctionalStatus", node.getFunctionalstatus().getName());
		physicalDeviceBuilder.addResourceDescribedBy("RestrictedStatus", node.getNodeExtension().getRestrictedStatus());

		for (Networkroleobject networkroleobject : node.getNetworkroleobjects())
		{
			physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
			physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
			physicalDeviceBuilder.getPhysicalResource().setModel(node.getNodeDef().getName());


			if (networkroleobject.getNetworkroleobject2networkrole().equals("ONT")) {
				remarkBuilder.buildRemark(node.getNodeExtension().getPowersupply(),"PowerSupply");
				physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
				//physicalDeviceBuilder.addResourceDescribedBy("PowerSupply",node.getNodeExtension().getPowersupply());
				physicalDeviceBuilder.addResourceDescribedBy("VendorPartNumber", node.getNodeExtension().getVendorpartnumber());
				physicalDeviceBuilder.addResourceDescribedBy("Vendor", node.getNodeExtension().getVendorname());
				//physicalDeviceBuilder.addResourceDescribedBy("SoftwareVersion",node.getSoftwareversion());
				//physicalDeviceBuilder.addResourceDescribedBy("SerialNo", node.getNodeExtension().getSerialnumber());
				physicalDeviceBuilder.addResourceDescribedBy("Indoor", node.getNodeExtension().getIndoor());
				physicalDeviceBuilder.addResourceDescribedBy("RONTAID", node.getNodeExtension().getRontaid());
				if (includeLocationDetails)
					physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));				
			}

			if (networkroleobject.getNetworkroleobject2networkrole().equals("OLT")) {
				//physicalDeviceBuilder.addResourceDescribedBy("NMSHostName",node.getNodeExtension().getNmshostname());
				physicalDeviceBuilder.setNMSHostName(node.getName());
				physicalDeviceBuilder.addResourceDescribedBy("NetworkNodeNumber", node.getNodeExtension().getNwknodenumber());
				//physicalDeviceBuilder.addResourceDescribedBy("NWKNodeNumber", node.getNodeExtension().getSplittergrpname());
				if (includeLocationDetails)
					physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));
			}

			if (networkroleobject.getNetworkroleobject2networkrole().equals("SPLITTER")) {
				physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupName",node.getNodeExtension().getSplittergrpname());
				physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupNumber",node.getNodeExtension().getSplittergrpnum());
				if (includeLocationDetails)				
					physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));
			}

			if (networkroleobject.getNetworkroleobject2networkrole().equals("FDP"))
			{
				Shelf shelfTemplate = new Shelf();
				Shelf shelfFDH=null;
				String nodeIdOfFDH=null;
				Node nodeTemplate=null;
				Node nodeFHD=null;
				if(node.getNodeInRackShelf()!=null)
				{
					shelfTemplate.setShelfid(node.getNodeInRackShelf().getNirs2rackshelf());
					shelfFDH = new Shelf(shelfTemplate);
					nodeIdOfFDH = shelfFDH.getShelf2node();
					nodeTemplate = new Node();
					nodeTemplate.setNodeid(nodeIdOfFDH);
					nodeFHD = new Node(nodeTemplate);
				}
				ResourceRelationshipBuilder resourceRelationshipBuilderForFDH = new ResourceRelationshipBuilder();
				resourceRelationshipBuilderForFDH.buildResourceRelationship(null, null, null, null, null);
				PhysicalDeviceBuilder physicalDeviceBuilderForFDH = new PhysicalDeviceBuilder();
				if(nodeFHD!=null){
				physicalDeviceBuilderForFDH.buildPhysicalDevice(nodeFHD.getName(),nodeFHD.getNodeid(), null, null,nodeFHD.getNodeType().getName(), null, nodeFHD.getProvisionstatus().getName(), nodeFHD.getNodeExtension().getClli(), null, null, nodeFHD.getNodeExtension().getParttype(), null, nodeFHD.getNodeExtension().getVendorname(), null, null, nodeFHD.getFunctionalstatus().getName());
				
				physicalDeviceBuilderForFDH.getPhysicalResource().setModel(nodeFHD.getNodeDef().getName());
				remarkBuilder.buildRemark(nodeFHD.getNodeExtension().getRestrictednotes(),"RestrictedNotes");
				physicalDeviceBuilderForFDH.addResourceDescribedBy("RestrictedStatus", nodeFHD.getNodeExtension().getRestrictedStatus());
				physicalDeviceBuilderForFDH.addRemark(remarkBuilder.getRemarks());
				resourceRelationshipBuilderForFDH.addAddressDetails(SearchLocationVOTransformation.getCLCAddressFromLocation(nodeFHD.getLocation()));				
				physicalDeviceBuilderForFDH.addResourceRelationship(resourceRelationshipBuilderForFDH.getResourceRelationship());				
				
				PhysicalDeviceBuilder fdhPhysicalDeviceBuilder = new PhysicalDeviceBuilder();
				for (Networkroleobject networkroleobjectFDH : nodeFHD.getNetworkroleobjects())
				{	
					physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobjectFDH.getNetworkroleobject2networkrole());
					physicalDeviceBuilderForFDH.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
				}
				resourceRelationshipBuilderForFDH.setDevice(physicalDeviceBuilderForFDH.getPhysicalDevice());
				physicalDeviceBuilder.addResourceRelationship(resourceRelationshipBuilderForFDH.getResourceRelationship());
				}
			}
		}
		// for getting physical port
		PluggableType pluggableType = new PluggableType();
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(),Integer.valueOf(port.getPortnumber()),null, port.getPortExtension().getPluggabletype(), null, null, port.getAlias1(), port.getPortExtension().getPortfunction(), port.getPorttype().getName(), null, null, null,null, null);
		physicalPortBuilder.addResourceDescribedBy("PortNameinMTOSI",port.getPortMTOSI(port.getPortid()));
		physicalPortBuilder.addResourceDescribedBy("PortDirection",port.getPortExtension().getPortfunction());
		physicalPortBuilder.addResourceDescribedBy("PluggableName",port.getSfpName(port.getPortid()));
		physicalPortBuilder.addResourceDescribedBy("PluggableType", pluggableType.pluggableTypeByPortId(port.getPortid()));

		if(port != null && port.getPort2porttype().equals("1900000003") && port.getPortExtension()!= null)
		{
			if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
				physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());
			if (port.getPortExtension().getBandwidth() != null || port.getPortExtension().getFormfactor() != null) 
			{ 
				String transmissionRate="";
				if(port.getPortExtension().getBandwidth() != null)
					transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
				if(port.getPortExtension().getFormfactor()!=null)
					transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();

				physicalPortBuilder.addResourceDescribedBy("TransmissionRate",transmissionRate);
			}
		}
		else 
		{	
			if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
				physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());			
			if(port.getBandwidthObject() != null && !StringHelper.isEmpty(port.getBandwidthObject().getName()))
				physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port.getBandwidthObject().getName());
		}

		Card card = port.getCard();
		Slot slot = card.getParentSlot();
		Shelf shelf = slot.getShelf();
		shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), null, null, node.getNodeExtension().getRelayrackid(), null);
		shelfBuilder.setRackInformation(node.getNodeExtension().getRelayrackid(), null);
		slotBuilder.buildSlot(slot.getName(),null, null, null);
		cardBuilder.buildCard(null, null,null);
		cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
		slotBuilder.addHasCard(cardBuilder.getCard());
		shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
		physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());

		logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(physicalDeviceBuilder.getPhysicalDevice());
		connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
		connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
		if(node.getLocation()!=null)
		{
			connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCInstalledAddressFromLocation(node.getLocation(), node.getName()));
		}

		return connectionTerminationPointBuilder.getConnectionTerminationPoint();
	}
	private static SubNetworkConnection buildCircuit(Circuit circuit, String level, String scope, Map<String, String> modifiers) throws Exception
	{
		boolean includeRelationships = false;
		if (modifiers.containsKey("INCLUDERELATIONSHIPS"))
		{
			if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE"))
			{
				includeRelationships = true;
			}
		}

		SubNetworkConnectionBuilder subNetworkConnectionBuilder = new SubNetworkConnectionBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		RemarkBuilder remarkBuilder=new RemarkBuilder();

		if (scope.equalsIgnoreCase("BASIC"))
		{
			subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null, null, null, circuit.getFunctionalstatus().getName(), null);
		} else {

			if(circuit.getCircuittype() != null && circuit.getCircuittype().getName().equalsIgnoreCase("PON Circuit (T)"))
			{
				subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null, circuit.getAlias1(), circuit.getAlias2(), circuit.getFunctionalstatus().getName(), "PON");
				subNetworkConnectionBuilder.addResourceDescribedBy("MCO",  circuit.getCircuitExtension().getMco());
				subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse",  circuit.getCircuitExtension().getIsDiverse());
				subNetworkConnectionBuilder.addResourceDescribedBy("TSP",  circuit.getCircuitExtension().getTsp());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitRole", circuit.getCircuitExtension().getCircuitservicetype());
				subNetworkConnectionBuilder.addResourceDescribedBy("Diverse Circuit ID", circuit.getCircuitExtension().getDiverseCircuitId());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitSerialNumber", circuit.getCircuitExtension().getCircuitserialnumber());
				subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
				subNetworkConnectionBuilder.addResourceDescribedBy("ModificationUserId", circuit.getCircuitExtension().getModificationUserId());

			}
			else if(circuit.getCircuittype() != null && circuit.getCircuittype().getName().equalsIgnoreCase("Optical Bearer"))
			{
				subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuittype().getName(), circuit.getProvisionstatus().getName(), null, null, circuit.getAlias1(), circuit.getAlias2(), circuit.getFunctionalstatus().getName(), "OB");

				remarkBuilder.buildRemark(circuit.getCircuitExtension().getRestrictedNotes(), "ResrictedNotes");
				subNetworkConnectionBuilder.addRemark(remarkBuilder.getRemarks());

				subNetworkConnectionBuilder.addResourceDescribedBy("RestrictedStatus", circuit.getCircuitExtension().getrestrictedStatus());
				subNetworkConnectionBuilder.addResourceDescribedBy("CIRCUITID",circuit.getCircuitExtension().getCircuitid());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitSerialNumber", circuit.getCircuitExtension().getCircuitserialnumber());
				subNetworkConnectionBuilder.addResourceDescribedBy("ModificationUserId", circuit.getCircuitExtension().getModificationUserId());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitRole", circuit.getCircuitExtension().getCircuitservicetype());
				subNetworkConnectionBuilder.addResourceDescribedBy("SRCSYS", circuit.getCircuitExtension().getsrcsys());
				subNetworkConnectionBuilder.addResourceDescribedBy("LABEL", circuit.getCircuitExtension().getLabel());
				subNetworkConnectionBuilder.addResourceDescribedBy("RPPLANID", circuit.getCircuitExtension().getRpplanid());
				subNetworkConnectionBuilder.addResourceDescribedBy("MCO", circuit.getCircuitExtension().getMco());
				subNetworkConnectionBuilder.addResourceDescribedBy("TSP", circuit.getCircuitExtension().getTsp());
				subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse",circuit.getCircuitExtension().getIsDiverse());
				subNetworkConnectionBuilder.addResourceDescribedBy("DiverseCircuitID",circuit.getCircuitExtension().getDiverseCircuitId());
				subNetworkConnectionBuilder.addResourceDescribedBy("ISVISIBLE", circuit.getCircuitExtension().getIsvisible());
				subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
			}
			else
			{
				subNetworkConnectionBuilder.buildSubNetworkConnection(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuitExtension().getCircuitservicetype(), circuit.getProvisionstatus().getName(), null, null, circuit.getAlias1(), circuit.getAlias2(), circuit.getFunctionalstatus().getName(), null);
				subNetworkConnectionBuilder.addResourceDescribedBy("MCO", circuit.getCircuitExtension().getMco());
				subNetworkConnectionBuilder.addResourceDescribedBy("IsDiverse", circuit.getCircuitExtension().getIsDiverse());
				subNetworkConnectionBuilder.addResourceDescribedBy("AvailableBandwidth", circuit.getCircuitExtension().getBw());
				subNetworkConnectionBuilder.addResourceDescribedBy("DiverseCircuitID", circuit.getCircuitExtension().getDiverseCircuitId());
				subNetworkConnectionBuilder.addResourceDescribedBy("TSP", circuit.getCircuitExtension().getTsp());
				subNetworkConnectionBuilder.addResourceDescribedBy("IsLAGMember", circuit.getCircuitExtension().getIsLagMember());
				subNetworkConnectionBuilder.addResourceDescribedBy("L1Technology", circuit.getCircuitExtension().getL1Technology());
				subNetworkConnectionBuilder.addResourceDescribedBy("ProtectionType", circuit.getCircuitExtension().getProtectiontype());
				subNetworkConnectionBuilder.addResourceDescribedBy("LAGNumber", circuit.getCircuitExtension().getLagnumber());
				subNetworkConnectionBuilder.addResourceDescribedBy("Hashing", circuit.getCircuitExtension().getHashing());
				subNetworkConnectionBuilder.addResourceDescribedBy("AggregationProtocol", circuit.getCircuitExtension().getAggregationprotocol());
				subNetworkConnectionBuilder.addResourceDescribedBy("CircuitSerialNumber", circuit.getCircuitExtension().getCircuitserialnumber());
				subNetworkConnectionBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
				subNetworkConnectionBuilder.addResourceDescribedBy("ModificationUserId", circuit.getCircuitExtension().getModificationUserId());

			}


			if(circuit.getCircuittype() != null)
			{
				if(circuit.getCircuittype().getName().equalsIgnoreCase("Unrouted Ethernet Bearer")||circuit.getCircuittype().getName().equalsIgnoreCase("Topology Virtual Connection"))
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("CircuitIDFormat", "CLF");

				}
				else if(circuit.getCircuittype().getName().equalsIgnoreCase("Link Aggregation Group"))
				{
					subNetworkConnectionBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");				

				}

			}

			if (circuit.getSubscriber() != null)
			{
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromReletive(circuit.getRelativename()));
				if(includeRelationships)
					ownsResourceDetailsBuilder.addCustomerAgent(SearchSubscriberVOTransformation.buildCustomerAgentFromSubscriber(circuit.getSubscriber()));
			}
			subNetworkConnectionBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
			if(circuit.getCircuittype() != null && circuit.getCircuittype().getName().equalsIgnoreCase("Optical Bearer"))
			{
				subNetworkConnectionBuilder.addZEndTps(buildTerminationPointFromPortForOB(circuit.getEndPort().getTopLevelPort(), circuit.getEndLocation(), includeRelationships));
				subNetworkConnectionBuilder.addAEndTps(buildTerminationPointFromPortForOB(circuit.getStartPort().getTopLevelPort(), circuit.getStartLocation(), includeRelationships));
			}
			else{
				subNetworkConnectionBuilder.addZEndTps(buildTerminationPointFromPort(circuit.getEndPort().getTopLevelPort(), circuit.getEndLocation(), includeRelationships));
				subNetworkConnectionBuilder.addAEndTps(buildTerminationPointFromPort(circuit.getStartPort().getTopLevelPort(), circuit.getStartLocation(), includeRelationships));
			}

			if (includeRelationships)
			{
				if (circuit.getAssociatedServices().size() > 0 || circuit.getAssociatedCircuits().size() > 0)
				{
					ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();

					for (Service service:circuit.getAssociatedServices())
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setCircuit(SearchServiceVOTransformation.buildServiceRelationship(service));
						subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}

					for (Circuit associatedCircuit:circuit.getAssociatedCircuits())
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setCircuit(buildCircuitRelationship(associatedCircuit));
						subNetworkConnectionBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
				}
			}
		}

		return subNetworkConnectionBuilder.getSubNetworkConnection();
	}

	private static Point2PointCircuit buildNMICircuit(Circuit circuit, String level, String scope, Map<String, String> modifiers) throws Exception
	{
		boolean includeRelationships = false;
		if (modifiers.containsKey("INCLUDERELATIONSHIPS"))
		{
			if (modifiers.get("INCLUDERELATIONSHIPS").equalsIgnoreCase("TRUE"))
			{
				includeRelationships = true;
			}
		}

		Point2PointCircuitBuilder point2PointCircuitBuilder = new Point2PointCircuitBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();

		if (scope.equalsIgnoreCase("BASIC"))
		{
			point2PointCircuitBuilder.buildPoint2PointCircuit(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuitExtension().getCircuitservicetype(), circuit.getProvisionstatus().getName(), null, null, null, circuit.getFunctionalstatus().getName(), null, null, null);
		} else {
			point2PointCircuitBuilder.buildPoint2PointCircuit(circuit.getName(), circuit.getCircuitid(), null, "ARM", circuit.getCircuitExtension().getCircuitservicetype(), circuit.getProvisionstatus().getName(), null, null, circuit.getBandwidth(), circuit.getFunctionalstatus().getName(), null, circuit.getAlias1(), circuit.getAlias2());

			point2PointCircuitBuilder.addResourceDescribedBy("MCO", circuit.getCircuitExtension().getMco());
			point2PointCircuitBuilder.addResourceDescribedBy("IsDiverse", circuit.getCircuitExtension().getIsDiverse());
			point2PointCircuitBuilder.addResourceDescribedBy("TSP", circuit.getCircuitExtension().getTsp());
			point2PointCircuitBuilder.addResourceDescribedBy("IsLAGMember", circuit.getCircuitExtension().getIsLagMember());
			point2PointCircuitBuilder.addResourceDescribedBy("AvailableBandwidth", circuit.getCircuitExtension().getBw());
			point2PointCircuitBuilder.addResourceDescribedBy("DiverseCircuitID", circuit.getCircuitExtension().getDiverseCircuitId());
			point2PointCircuitBuilder.addResourceDescribedBy("L1Technology", circuit.getCircuitExtension().getL1Technology());
			point2PointCircuitBuilder.addResourceDescribedBy("ProtectionType", circuit.getCircuitExtension().getProtectiontype());
			point2PointCircuitBuilder.addResourceDescribedBy("LAGNumber", circuit.getCircuitExtension().getLagnumber());
			point2PointCircuitBuilder.addResourceDescribedBy("Hashing", circuit.getCircuitExtension().getHashing());
			point2PointCircuitBuilder.addResourceDescribedBy("AggregationProtocol", circuit.getCircuitExtension().getAggregationprotocol());
			point2PointCircuitBuilder.addResourceDescribedBy("CircuitSerialNumber", circuit.getCircuitExtension().getCircuitserialnumber());
			point2PointCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
			point2PointCircuitBuilder.addResourceDescribedBy("ModificationUserId", circuit.getCircuitExtension().getModificationUserId());

			point2PointCircuitBuilder.addResourceDescribedBy("USAGE", circuit.getCircuitExtension().getUsage());
			point2PointCircuitBuilder.addResourceDescribedBy("DIVERSE_PW_ID", circuit.getCircuitExtension().getDiversePwId());
			point2PointCircuitBuilder.addResourceDescribedBy("ExceptionHandlingText", circuit.getCircuitExtension().getExceptionHandlingInfo());
			point2PointCircuitBuilder.addResourceDescribedBy("MODIFICATION_USER_ID", circuit.getCircuitExtension().getModificationUserId());
			if(circuit.getCircuittype() != null)
			{
				if(circuit.getCircuittype().getName().equalsIgnoreCase("Unrouted Ethernet Bearer")||circuit.getCircuittype().getName().equalsIgnoreCase("Topology Virtual Connection"))
				{
					point2PointCircuitBuilder.addResourceDescribedBy("CircuitIDFormat", "CLF");
				}
				else if(circuit.getCircuittype().getName().equalsIgnoreCase("Link Aggregation Group"))
				{
					point2PointCircuitBuilder.addResourceDescribedBy("CircuitIDFormat", "CLS");
				}
			}

			if (circuit.getSubscriber() !=null)
			{
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				ownsResourceDetailsBuilder.addCustomer(SearchSubscriberVOTransformation.getCLCCustomerFromReletive(circuit.getRelativename()));
				if(includeRelationships)
					ownsResourceDetailsBuilder.addCustomerAgent(SearchSubscriberVOTransformation.buildCustomerAgentFromSubscriber(circuit.getSubscriber()));
			}
			point2PointCircuitBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());

			point2PointCircuitBuilder.addZEndTps(buildConnectionTerminationPointFromPort(circuit.getEndPort().getTopLevelPort(), circuit.getEndLocation()));

			point2PointCircuitBuilder.addAEndTps(buildConnectionTerminationPointFromPort(circuit.getStartPort().getTopLevelPort(), circuit.getStartLocation()));

			if (includeRelationships)
			{
				if (circuit.getAssociatedServices().size() > 0 || circuit.getAssociatedCircuits().size() > 0)
				{
					ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();

					for (Service service:circuit.getAssociatedServices())
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setCircuit(SearchServiceVOTransformation.buildServiceRelationship(service));
						point2PointCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
					for (Circuit associatedCircuit:circuit.getAssociatedCircuits())
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setCircuit(buildCircuitRelationship(associatedCircuit));
						point2PointCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
				}
			}
		}

		return point2PointCircuitBuilder.getPoint2PointCircuit();
	}

	protected static TerminationPoint buildTerminationPointFromPort(Port port, Location location, Boolean includeRelationships) throws Exception
	{
		TerminationPointBuilder terminationPointBuilder = new TerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();

		if(includeRelationships==false)
			terminationPointBuilder.buildTerminationPoint(port.getTopLevelPort().getName(), null, null, port.getTopLevelPort().getInterface(), null, null);
		else
			terminationPointBuilder.buildTerminationPoint(null, null, null);
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);

		logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(SearchNodeVOTransformation.buildDeviceFromPort(port));
		terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
		terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(location));

		return terminationPointBuilder.getTerminationPoint();
	}

	protected static TerminationPoint buildTerminationPointFromPortForOB(Port port, Location location, Boolean includeRelationships) throws Exception
	{
		TerminationPointBuilder terminationPointBuilder = new TerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();

		if(includeRelationships==false)
			terminationPointBuilder.buildTerminationPoint(port.getTopLevelPort().getName(), null, null, port.getTopLevelPort().getInterface(), null, null);
		else
			terminationPointBuilder.buildTerminationPoint(null, null, null);
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);

		logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(SearchNodeVOTransformation.buildDeviceFromPortForOB(port, true));
		terminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
		terminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(location));

		return terminationPointBuilder.getTerminationPoint();
	}

	protected static ConnectionTerminationPoint buildConnectionTerminationPointFromPort(Port port, Location location) throws Exception
	{
		ConnectionTerminationPointBuilder connectionTerminationPointBuilder = new ConnectionTerminationPointBuilder();
		LogicalPhysicalResourceBuilder logicalPhysicalResourceBuilder = new LogicalPhysicalResourceBuilder();

		connectionTerminationPointBuilder.buildConnectionTerminationPoint(null, null, null);
		logicalPhysicalResourceBuilder.buildLogicalPhysicalResource(null, null, null, null, null);

		logicalPhysicalResourceBuilder.addPhysicalDeviceAsDevice(SearchNodeVOTransformation.buildDeviceFromPort(port));
		connectionTerminationPointBuilder.addLogicalPhysicalResource(logicalPhysicalResourceBuilder.getLogicalPhysicalResource());
		connectionTerminationPointBuilder.addAccessPointAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(location));

		return connectionTerminationPointBuilder.getConnectionTerminationPoint();
	}

	public static Point2PointCircuit buildCircuitRelationship(Circuit circuit)
	{
		Point2PointCircuitBuilder point2PointCircuitBuilder = new Point2PointCircuitBuilder();

		point2PointCircuitBuilder.buildPoint2PointCircuit(circuit.getName(), circuit.getCircuitid(), null, null, circuit.getCircuitExtension().getCircuitservicetype(), circuit.getProvisionstatus().getName(), null, null, circuit.getBandwidth(), circuit.getFunctionalstatus().getName(), null,null,null,circuit.getCreateddate(),circuit.getLastmodifieddate());
		return point2PointCircuitBuilder.getPoint2PointCircuit();
	}

}
