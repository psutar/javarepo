package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;

import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class VendorCompatibility extends AbstractReadOnlyTable {


	//private static final long serialVersionUID = 1L;

//@SuppressWarnings("unused")
private static final Log LOG = LogFactory.getLog(VendorCompatibility.class);
	
	private static final String VENDOR_COMPATIBILITY_ID = "VENDOR_COMPATIBILITY_ID";
	private static final String START_NODEDEF_NAME = "START_NODEDEF_NAME";
	private static final String END_NODEDEF_NAME = "END_NODEDEF_NAME";
	private static final String START_NODE_VENDOR = "START_NODE_VENDOR";
	private static final String END_NODE_VENDOR = "END_NODE_VENDOR";

	//private static final String DownstreamBandwidth = null;

	//private static final String UpstreamBandwidth = null;
	
	public VendorCompatibility()
	{
		super();
		System.out.println("11");
		this.tableName = "Vendor_Compatibility";
	}
	
	public VendorCompatibility(String portId)
	{
		this();
		primaryKey.setValue(VENDOR_COMPATIBILITY_ID);
		
		getRecordByPrimaryKey();
		this.instanciated = true;	
	}

	
	public static String getVendorCompatibilityId() {
		return VENDOR_COMPATIBILITY_ID;
	}

	public static String getStartNodedefName() {
		return START_NODEDEF_NAME;
	}

	public static String getEndNodedefName() {
		return END_NODEDEF_NAME;
	}

	public static String getStartNodeVendor() {
		return START_NODE_VENDOR;
	}

	public static String getEndNodeVendor() {
		return END_NODE_VENDOR;
	}

	@Override
	public void populateModel() {
		fields.put(VENDOR_COMPATIBILITY_ID, new Field(VENDOR_COMPATIBILITY_ID, Field.TYPE_NUMERIC));
		fields.put(START_NODEDEF_NAME, new Field(START_NODEDEF_NAME, Field.TYPE_VARCHAR));
		fields.put(END_NODEDEF_NAME, new Field(END_NODEDEF_NAME, Field.TYPE_VARCHAR));
		fields.put(START_NODE_VENDOR, new Field(START_NODE_VENDOR, Field.TYPE_VARCHAR));
		fields.put(END_NODE_VENDOR, new Field(END_NODE_VENDOR, Field.TYPE_VARCHAR));
		
		primaryKey = new PrimaryKey(fields.get(VENDOR_COMPATIBILITY_ID));
		 //linkedTables.add(new LinkedTable("Vendor_Compatibility", "DeviceModel_Default_Params", END_NODEDEF_NAME, "NODEDEF_NAME", false));

				
	}

	
	
	public List<String> getVendorCompatibilityObject(String nodeDef, String downStreamBW, String upStreamBW)
	{
		
		
		String query = " START_NODEDEF_NAME =  '"+ nodeDef + "'  AND END_NODEDEF_NAME  in (select NODEDEF_NAME from DeviceModel_Default_Params where  MAX_DOWNSTREAM_RATE >=" + downStreamBW +" and  MAX_UPSTREAM_RATE >=" + upStreamBW+")" ;
		
		return getVendorCompatibilityByQuery(query);
	}

	public List<String> getVendorCompatibilityByQuery(String query)
	{
		VendorCompatibility vendorcompatibility = new VendorCompatibility();
		//System.out.println("vendorcompatibility table :" + vendorcompatibility.tableName);
		//vendorcompatibility.tableName = "Vendor_Compatibility";
		//List<Map<String,Object>> vendorcompatibilityList = vendorcompatibility.getRecordsByQuery(query);
		List<Map<String,Object>> vendorcompatibilityList = vendorcompatibility.getFullRecordsByQuery(query);
		
		//System.out.println("2" +vendorcompatibility.getFieldAsString(END_NODEDEF_NAME));
        List<String> ontNodeDefNameList = new ArrayList<String>();
		String ontNodeDefName = null;
		for (Map<String,Object> vendorcompatibilityMap : vendorcompatibilityList)
		{
			ontNodeDefName = vendorcompatibilityMap.get(END_NODEDEF_NAME).toString();
			ontNodeDefNameList.add(ontNodeDefName);
		}
		 

		return ontNodeDefNameList;
	}
	
	

}
