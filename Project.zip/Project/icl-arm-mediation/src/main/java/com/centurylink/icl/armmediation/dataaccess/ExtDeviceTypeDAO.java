package com.centurylink.icl.armmediation.dataaccess;

public interface ExtDeviceTypeDAO {
	
	public boolean doesClliExists(String deviceClliCode);

}
