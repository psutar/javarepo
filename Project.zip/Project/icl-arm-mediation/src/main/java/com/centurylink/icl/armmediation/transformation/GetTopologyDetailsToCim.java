package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.List;

import com.centurylink.icl.armmediation.armaccessobject.ARMDevice;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.builder.cim2.End2EndCircuitBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class GetTopologyDetailsToCim
{
	private final End2EndCircuitBuilder end2EndCircuitBuilder;
	private final SearchResponseDetailsBuilder searchResponseDetailsBuilder;
	ResourceRelationshipBuilder resourceRelationshipBuilder;
	PhysicalDeviceBuilder physicalDeviceBuilder;

	public GetTopologyDetailsToCim()
	{
		end2EndCircuitBuilder = new End2EndCircuitBuilder();
		searchResponseDetailsBuilder= new SearchResponseDetailsBuilder();
		resourceRelationshipBuilder= new ResourceRelationshipBuilder();
		physicalDeviceBuilder =new PhysicalDeviceBuilder();

	}
	public SearchResourceResponseDocument transformToCim(List<ARMDevice> armDevices,SearchResourceRequestDocument request)
	{
		String topologyName=null; 
		//String toplologyType=null;
		ArrayList<String> topologyNameList=new ArrayList<String>();
		if(armDevices != null && armDevices.size() > 0)
		{
			topologyName=armDevices.get(0).getTopologyName();
			//toplologyType=armDevices.get(0).getTopologyType();
		}
		searchResponseDetailsBuilder.buildSearchResponseDetails();
		topologyNameList.add(topologyName);
		for(ARMDevice armDevice:armDevices)
		{
			if(!armDevice.getTopologyName().equalsIgnoreCase(topologyName))
			{ topologyNameList.add(armDevice.getTopologyName());
			   topologyName=armDevice.getTopologyName();
			}
		}

		for(String topName:topologyNameList)
		{
			end2EndCircuitBuilder.buildEnd2EndCircuit(topName, null, null, "ARM", null, null, null, null, null, null, null, null, null, null, null);
			end2EndCircuitBuilder.setAdditionInfo("Topology Details");
			for(ARMDevice Device:armDevices)
			{
				if(Device.getTopologyName().equalsIgnoreCase(topName)){
					resourceRelationshipBuilder.buildResourceRelationship(null, null, null);
					physicalDeviceBuilder.buildPhysicalDevice(Device.getCommonName(), null, null, null, null, null, null, null, null, null, null, null, null, null);
					physicalDeviceBuilder.setResourceTypes(Device.getRole(), null);
					resourceRelationshipBuilder.setDevice(physicalDeviceBuilder.getPhysicalDevice());
					end2EndCircuitBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					end2EndCircuitBuilder.setResourceTypes(Device.getTopologyType(), null);
				}
			}
			
			searchResponseDetailsBuilder.addCircuit(end2EndCircuitBuilder.getEND2ENDCIRCUIT());
		}
		
		return MediationUtil.getSearchResourceSuccessResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), request);
	}
}
