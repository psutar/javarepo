package com.centurylink.icl.armmediation.dataaccess.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;

import com.centurylink.icl.armmediation.dataaccess.GetRoutesForAssociatedCircuitDAO;

public class GetRoutesForAssociatedCircuitDAOImpl implements GetRoutesForAssociatedCircuitDAO
{
	private JdbcTemplate jdbcTemplate;
	
	private static final String GET_ROUTES_QUERY = "SELECT NAME FROM CIRCUIT WHERE CIRCUIT2CIRCUITTYPE = 1900000007 AND CIRCUITID IN (SELECT CC.USEDBY2CIRCUIT FROM CIRCUITCIRCUIT CC, CIRCUIT C WHERE C.NAME = ? AND C.CIRCUITID = CC.USES2CIRCUIT)";

	
	public GetRoutesForAssociatedCircuitDAOImpl(DataSource dataSource)
	{
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	@Override
	public List<String> getRoutes(String associatedCircuit)
	{
		final List<String> routes = this.jdbcTemplate.query(GET_ROUTES_QUERY, new Object[] {associatedCircuit}, new RowMapper<String>()
		{
			public String mapRow(ResultSet resultSet, int rowNum) throws SQLException
			{
				return resultSet.getString("NAME");
			}
		});
				
		return routes;
	}
}
