package com.centurylink.icl.armmediation.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.Constants;
import com.centurylink.icl.armmediation.helper.JDBCTempleteUtil;
import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.SQLBuilder;
import com.centurylink.icl.armmediation.helper.SetObjectAttributeHelper;
import com.centurylink.icl.armmediation.storedprocedures.pkglocation.AddLocationToSubscriber;
import com.centurylink.icl.armmediation.storedprocedures.pkglocation.CreateLocation;
import com.centurylink.icl.armmediation.transformation.ARMCreateLocationToCim;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;
import com.iclnbi.iclnbiV200.CreateLocationResponseDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.Party;

public class CreateLocationService
{

	private static final Log LOG = LogFactory.getLog(CreateLocationService.class);

	private CreateLocation createLocation;
	private ARMCreateLocationToCim armCreateLocationToCim;
	private SetObjectAttributeHelper setObjectAttributeHelper;
	private JDBCTempleteUtil jdbcTempleteUtil;
	private AddLocationToSubscriber addLocationToSubscriber;
	
	public CreateLocationResponseDocument createLocation(CreateLocationRequestDocument createLocRequest) throws Exception
	{
		LOG.info("Starting Create Location" + createLocRequest.toString());

		final String locationType = createLocRequest.getCreateLocationRequest().getAddressDetails().getAddressType();
		final String clli = createLocRequest.getCreateLocationRequest().getAddressDetails().getCLLI();
		List<String> subscriberNames = new ArrayList<String>();
		if(createLocRequest.getCreateLocationRequest().getAddressDetails().getInvolvedPartyList() != null &&
			createLocRequest.getCreateLocationRequest().getAddressDetails().getInvolvedPartyList().size() > 0)
		{
			//Party party = createLocRequest.getCreateLocationRequest().getAddressDetails().getInvolvedPartyList().get(0);
			for (Party party:createLocRequest.getCreateLocationRequest().getAddressDetails().getInvolvedPartyList())
			{
				if(party != null && party.getHasCustomerRoleList() != null && party.getHasCustomerRoleList().size() > 0)
				{
					List<Customer> hasCustomerRoleList = party.getHasCustomerRoleList();
					for (Customer customer : hasCustomerRoleList) {
						
						if(!StringHelper.isEmpty(customer.getCommonName())){
							subscriberNames.add(customer.getCommonName());
						}
					}
				}
			}
		}
		
		LOG.info("CLLI >>>>> "+clli);
		
		if(!Constants.CITY.equalsIgnoreCase(locationType) && clli != null && clli.length() != 8)
		{
			throw new ICLException("ICLRequestValidationError", "CLLI should only be 8 characters", "1948");
		}
		
		String cityName = createLocRequest.getCreateLocationRequest().getAddressDetails().getLocality().toUpperCase();
		String stateName=createLocRequest.getCreateLocationRequest().getAddressDetails().getStateOrProvince().toUpperCase();

		final String commonName;
		if (createLocRequest.getCreateLocationRequest().getAddressDetails().getCommonName() == null || Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
		{
			if (Constants.CITY.equalsIgnoreCase(locationType))
			{
				commonName = cityName + ", " + stateName;
			} else {
				commonName = buildLocationName(locationType, clli);
			}
		} else {
				commonName = createLocRequest.getCreateLocationRequest().getAddressDetails().getCommonName();
		}
		
		final int locationTypeId = buildLocationType(locationType);
		Map<String, Object> map = createLocation.execute(commonName, locationTypeId);
		final BigDecimal locationId = (BigDecimal) map.get("o_locationid");
		BigDecimal o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreateLocationToCim.transformErrorToCim(createLocRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}

		/*
		HashMap<String, Object> attributeList = getLocationattributeslist(locationType, createLocRequest);
		map = setObjectAttributeHelper.execute("Location", locationId, attributeList);
		o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);

		if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
		{
			final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
			if (LOG.isInfoEnabled())
			{
				LOG.info(o_Errormsg);
			}
			return armCreateLocationToCim.transformErrorToCim(createLocRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
		}
		*/

		//relate the subscriber
		if (subscriberNames != null && subscriberNames.size() > 0)
		{
			List<Integer> subscribers = getSubscriberIds(subscriberNames);
			LOG.debug(StringHelper.makeFormattedString("Subscribers", subscribers));
			for (Integer subscriberId : subscribers) {
				
				if( subscriberId != 0) // && !Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
				{
					LOG.debug("Associating location " + locationId + " to subscriber " + subscriberId);
					map = addLocationToSubscriber.execute(BigDecimal.valueOf(subscriberId),locationId);
					o_ErrorCode = (BigDecimal) map.get(Constants.O_ERROR_CODE);
					
					if ((o_ErrorCode != null) && (o_ErrorCode.intValue() != 0))
					{
						final String o_Errormsg = (String) map.get(Constants.O_ERROR_TEXT);
						if (LOG.isInfoEnabled())
						{
							LOG.info(o_Errormsg);
						}
						return armCreateLocationToCim.transformErrorToCim(createLocRequest, Constants.ERROR_CODE_1947, Constants.ICL_INTERNAL_ERROR, o_Errormsg);
					}
				}
			}
		}
		
		
		CreateLocationResponseDocument createLocResponse = armCreateLocationToCim.transformToCim(createLocRequest, String.valueOf(locationId), commonName);

		if (LOG.isInfoEnabled())
		{
			LOG.info(createLocResponse.toString());
		}
		return createLocResponse;
	}

	private int buildLocationType(String locationType)
	{
		if (Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
			return Constants.LOC_BUILDING_TYPE_ID;
		else if (Constants.CITY.equalsIgnoreCase(locationType))
			return Constants.LOC_CITY_TYPE_ID;
		else
			return getLocationId(locationType);
	}

	private String buildLocationName(String locationType, String clli) throws Exception
	{
		if (Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
		{
			return clli;
		} else
		{
			final SQLBuilder sqlBuilder = new SQLBuilder(Constants.EXT_LOCATION_BUILDING_SITE);
			sqlBuilder.addTable(Constants.LOCATION);

			sqlBuilder.addField("count(*)", "count");

			sqlBuilder.eq(Constants.LOCATION, Constants.LOCATION_2_LOCATION_TYPE, String.valueOf(getLocationId(locationType)));
			sqlBuilder.eq(Constants.EXT_LOCATION_BUILDING_SITE, Constants.CLLI_CODE, clli);
			sqlBuilder.eq(Constants.EXT_LOCATION_BUILDING_SITE, Constants.LOCATION_ID, Constants.LOCATION, Constants.LOCATION_2_PARENT_LOCATION);

			final int count = jdbcTempleteUtil.getCount(sqlBuilder.getStatement()) + 1;

			return clli + "-" + getCode(locationType) + "-" + count;
		}

	}

	private List<Integer> getSubscriberIds(List<String> subscriberNames) throws Exception
	{
		return jdbcTempleteUtil.getSubscriberIdMultiple(buildSubscriberNameToSubscriberId(subscriberNames),Constants.SUBSCIBER_ID);
	}
	
	private String buildSubscriberNameToSubscriberId(List<String> subscriberNames)
	{
		SQLBuilder sqlBuilder = new SQLBuilder(Constants.SUBSCRIBER);
		sqlBuilder.addField(Constants.SUBSCIBER_ID);
		sqlBuilder.in(Constants.SUBSCRIBER,Constants.NAME, subscriberNames);
		String query = sqlBuilder.getStatement();
		LOG.info(query);
		return query;
	}

	private HashMap<String, Object> getLocationattributeslist(String locationType, CreateLocationRequestDocument createRequest) throws Exception
	{
		final HashMap<String, Object> attributeList = new HashMap<String, Object>();
		if (Constants.BUILDING_SITE.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.DESCRIPTION, MediationUtil.getRcv(createRequest, Constants.BUILDING_NAME));
			attributeList.put(Constants.PHONE_SWITCH_CLLI, MediationUtil.getRcv(createRequest, Constants.SWITCH_LOCATION_CLLI));
			attributeList.put(Constants.VCOORDINATE, MediationUtil.getGeographicLocation(createRequest, Constants.VCOORDINATE));
			attributeList.put(Constants.HCOORDINATE, MediationUtil.getGeographicLocation(createRequest, Constants.HCOORDINATE));
			attributeList.put(Constants.PROVINCE, createRequest.getCreateLocationRequest().getAddressDetails().getStateOrProvince());
			attributeList.put(Constants.LATA, MediationUtil.getExchangeServiceArea(createRequest, Constants.LATA));
			attributeList.put(Constants.CLLI_CODE, createRequest.getCreateLocationRequest().getAddressDetails().getCLLI());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(createRequest, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(createRequest, Constants.NXX));
			attributeList.put(Constants.TOWNCITY, createRequest.getCreateLocationRequest().getAddressDetails().getLocality());
			attributeList.put(Constants.ZIP, createRequest.getCreateLocationRequest().getAddressDetails().getPostcode());
			attributeList.put(Constants.ADDRESS1, createRequest.getCreateLocationRequest().getAddressDetails().getAddressLine1());
		} else if (Constants.CENTRAL_OFFICE.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.DESCRIPTION, createRequest.getCreateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(createRequest, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(createRequest, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, createRequest.getCreateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if (Constants.REMOTE_SITE.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.DESCRIPTION, createRequest.getCreateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(createRequest, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(createRequest, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, createRequest.getCreateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if (Constants.EQUIPMENT_SITE.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.DESCRIPTION, createRequest.getCreateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(createRequest, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(createRequest, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, createRequest.getCreateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if (Constants.CUSTOMER_SITE.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.DESCRIPTION, createRequest.getCreateLocationRequest().getAddressDetails().getDescription());
			attributeList.put(Constants.NPA, MediationUtil.getExchangeServiceArea(createRequest, Constants.NPA));
			attributeList.put(Constants.NXX, MediationUtil.getExchangeServiceArea(createRequest, Constants.NXX));
			attributeList.put(Constants.ADDRESS2, createRequest.getCreateLocationRequest().getAddressDetails().getAddressLine2());
			attributeList.put(Constants.CREATION_USER, "ICL");
		} else if (Constants.CITY.equalsIgnoreCase(locationType))
		{
			attributeList.put(Constants.PROVINCE, createRequest.getCreateLocationRequest().getAddressDetails().getStateOrProvince());
			attributeList.put(Constants.TOWNCITY, createRequest.getCreateLocationRequest().getAddressDetails().getLocality());
		}
		return attributeList;

	}

	private int getLocationId(String locationType)
	{
		int locTypeId = 0;

		if (Constants.CENTRAL_OFFICE.equalsIgnoreCase(locationType))
		{
			locTypeId = Constants.LOC_CENTRAL_OFFICE_TYPE_ID;
		}
		if (Constants.REMOTE_SITE.equalsIgnoreCase(locationType))
		{
			locTypeId = Constants.LOC_REMOTE_TYPE_ID;
		}
		if (Constants.EQUIPMENT_SITE.equalsIgnoreCase(locationType))
		{
			locTypeId = Constants.LOC_EQUIPMENT_LOCATION_TYPE_ID;
			
		}
		if (Constants.EQUIPMENT_LOCATION.equalsIgnoreCase(locationType))
		{
			
			locTypeId = Constants.LOC_EQUIPMENT_LOCATION_TYPE_ID;
			
		}
		if (Constants.CUSTOMER_SITE.equalsIgnoreCase(locationType))
		{
			locTypeId = Constants.LOC_CUSTOMER_TYPE_ID;
		}
		return locTypeId;
	}

	private String getCode(String locationType)
	{
		String code = "";

		if (Constants.CENTRAL_OFFICE.equalsIgnoreCase(locationType))
		{
			code = "CO";
		}
		if (Constants.REMOTE_SITE.equalsIgnoreCase(locationType))
		{
			code = "RS";
		}
		if (Constants.EQUIPMENT_SITE.equalsIgnoreCase(locationType))
		{
			code = "ES";
		}
		if (Constants.CUSTOMER_SITE.equalsIgnoreCase(locationType))
		{
			code = "CS";
		}
		return code;
	}

	public void setCreateLocation(CreateLocation createLocation)
	{
		this.createLocation = createLocation;
	}

	public void setArmCreateLocationToCim(ARMCreateLocationToCim armCreateLocationToCim)
	{
		this.armCreateLocationToCim = armCreateLocationToCim;
	}

	public void setSetObjectAttributeHelper(SetObjectAttributeHelper setObjectAttributeHelper)
	{
		this.setObjectAttributeHelper = setObjectAttributeHelper;
	}

	public void setJdbcTempleteUtil(JDBCTempleteUtil jdbcTempleteUtil)
	{
		this.jdbcTempleteUtil = jdbcTempleteUtil;
	}

	public void setAddLocationToSubscriber(
			AddLocationToSubscriber addLocationToSubscriber) {
		this.addLocationToSubscriber = addLocationToSubscriber;
	}
	

}

