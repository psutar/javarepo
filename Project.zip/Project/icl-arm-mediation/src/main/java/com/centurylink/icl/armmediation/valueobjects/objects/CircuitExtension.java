package com.centurylink.icl.armmediation.valueobjects.objects;

import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;

public class CircuitExtension extends AbstractReadOnlyTable {

	private static final String BW = "BW";
	private static final String CIRCUITID = "CIRCUITID";
	private static final String HASHING = "HASHING";
	private static final String CIRCUITSERVICETYPE = "CIRCUITSERVICETYPE";
	private static final String L1_TECHNOLOGY = "L1_TECHNOLOGY";
	private static final String RPPLANID = "RPPLANID";
	private static final String PROTECTIONTYPE = "PROTECTIONTYPE";
	private static final String ADAPTIVE_MODULATION = "ADAPTIVE_MODULATION";
	private static final String BC = "BC";
	private static final String BE = "BE";
	private static final String IS_DIVERSE = "IS_DIVERSE";
	private static final String AGGREGATIONPROTOCOL = "AGGREGATIONPROTOCOL";
	private static final String CHANNEL_SPACING = "CHANNEL_SPACING";
	private static final String ATPC_AUTOMATIC_THRESHOLD = "ATPC_AUTOMATIC_THRESHOLD";
	private static final String DIVERSE_CIRCUIT_ID = "DIVERSECIRCID";
	private static final String ATPC = "ATPC";
	private static final String EIR = "EIR";
	private static final String ATPC_MAX_THRESHOLD = "ATPC_MAX_THRESHOLD";
	private static final String LABEL = "LABEL";
	private static final String ASSURED_MODULATION = "ASSURED_MODULATION";
	private static final String ATPC_RX_THRESHOLD = "ATPC_RX_THRESHOLD";
	private static final String MCO = "MCO";
	private static final String ATPC_MIN_THRESHOLD = "ATPC_MIN_THRESHOLD";
	private static final String MANUAL_TPC = "MANUAL_TPC";
	private static final String IS_LAG_MEMBER = "IS_LAG_MEMBER";
	private static final String TSP = "TSP";
	private static final String POLARIZATION = "POLARIZATION";
	private static final String LAGNUMBER = "LAGNUMBER";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String CIR = "CIR";
	private static final String CIRCUITSERIALNUMBER = "CIRCSERIALNO";
	private static final String EXCEPTION_HANDLING_INFO = "EXCEPTIONHDLINFO";
	private static final String MODIFICATION_USER_ID = "MODIFICATIONUSERID";
	private static String USAGE = "USAGE";
	private static String DIVERSE_PW_ID="DIVERSE_PW_ID";
	
	private static final String RESTRICTEDNOTES = "RESTRICTEDNOTES";
	private static String RESTRICTEDSTATUS = "RESTRICTEDSTATUS";
	private static String SRCSYS="SRCSYS";


	public CircuitExtension()
	{
		super();
	}

	public CircuitExtension(Field key, String tableName)
	{
		this();
		this.tableName = tableName;
		primaryKey.setValue(key.getValue());
		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	@Override
	public void populateModel()
	{
		fields.put(BW, new Field(BW, Field.TYPE_VARCHAR));
		fields.put(CIRCUITID, new Field(CIRCUITID, Field.TYPE_NUMERIC));
		fields.put(HASHING, new Field(HASHING, Field.TYPE_VARCHAR));
		fields.put(CIRCUITSERVICETYPE, new Field(CIRCUITSERVICETYPE, Field.TYPE_VARCHAR));
		fields.put(L1_TECHNOLOGY, new Field(L1_TECHNOLOGY, Field.TYPE_VARCHAR));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(PROTECTIONTYPE, new Field(PROTECTIONTYPE, Field.TYPE_VARCHAR));
		fields.put(ADAPTIVE_MODULATION, new Field(ADAPTIVE_MODULATION, Field.TYPE_NUMERIC));
		fields.put(BC, new Field(BC, Field.TYPE_NUMERIC));
		fields.put(BE, new Field(BE, Field.TYPE_NUMERIC));
		fields.put(IS_DIVERSE, new Field(IS_DIVERSE, Field.TYPE_VARCHAR));
		fields.put(AGGREGATIONPROTOCOL, new Field(AGGREGATIONPROTOCOL, Field.TYPE_VARCHAR));
		fields.put(CHANNEL_SPACING, new Field(CHANNEL_SPACING, Field.TYPE_NUMERIC));
		fields.put(ATPC_AUTOMATIC_THRESHOLD, new Field(ATPC_AUTOMATIC_THRESHOLD, Field.TYPE_NUMERIC));
		fields.put(DIVERSE_CIRCUIT_ID, new Field(DIVERSE_CIRCUIT_ID, Field.TYPE_VARCHAR));
		fields.put(ATPC, new Field(ATPC, Field.TYPE_NUMERIC));
		fields.put(EIR, new Field(EIR, Field.TYPE_NUMERIC));
		fields.put(ATPC_MAX_THRESHOLD, new Field(ATPC_MAX_THRESHOLD, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(ASSURED_MODULATION, new Field(ASSURED_MODULATION, Field.TYPE_NUMERIC));
		fields.put(ATPC_RX_THRESHOLD, new Field(ATPC_RX_THRESHOLD, Field.TYPE_NUMERIC));
		fields.put(MCO, new Field(MCO, Field.TYPE_VARCHAR));
		fields.put(ATPC_MIN_THRESHOLD, new Field(ATPC_MIN_THRESHOLD, Field.TYPE_NUMERIC));
		fields.put(MANUAL_TPC, new Field(MANUAL_TPC, Field.TYPE_NUMERIC));
		fields.put(IS_LAG_MEMBER, new Field(IS_LAG_MEMBER, Field.TYPE_VARCHAR));
		fields.put(TSP, new Field(TSP, Field.TYPE_NUMERIC));
		fields.put(POLARIZATION, new Field(POLARIZATION, Field.TYPE_NUMERIC));
		fields.put(LAGNUMBER, new Field(LAGNUMBER, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(CIR, new Field(CIR, Field.TYPE_NUMERIC));

		fields.put(CIRCUITSERIALNUMBER, new Field(CIRCUITSERIALNUMBER, Field.TYPE_NUMERIC));
		fields.put(USAGE, new Field(USAGE, Field.TYPE_VARCHAR));
		fields.put(DIVERSE_PW_ID, new Field(DIVERSE_PW_ID, Field.TYPE_VARCHAR));
		fields.put(EXCEPTION_HANDLING_INFO, new Field(EXCEPTION_HANDLING_INFO, Field.TYPE_VARCHAR));
		fields.put(MODIFICATION_USER_ID, new Field(MODIFICATION_USER_ID, Field.TYPE_VARCHAR));
		
		
		fields.put(RESTRICTEDNOTES, new Field(RESTRICTEDNOTES, Field.TYPE_VARCHAR));
		fields.put(RESTRICTEDSTATUS, new Field(RESTRICTEDSTATUS, Field.TYPE_NUMERIC));
		fields.put(SRCSYS, new Field(SRCSYS, Field.TYPE_VARCHAR));
		primaryKey = new PrimaryKey(fields.get(CIRCUITID));
	}

	public void setBw(String bw)
	{
		setField(BW,bw);
	}

	public String getBw()
	{
		return getFieldAsString(BW);
	}

	public void setCircuitid(String circuitid)
	{
		setField(CIRCUITID,circuitid);
	}

	public String getCircuitid()
	{
		return getFieldAsString(CIRCUITID);
	}

	public void setHashing(String hashing)
	{
		setField(HASHING,hashing);
	}

	public String getHashing()
	{
		return getFieldAsString(HASHING);
	}

	public void setCircuitservicetype(String circuitservicetype)
	{
		setField(CIRCUITSERVICETYPE,circuitservicetype);
	}

	public String getCircuitservicetype()
	{
		return getFieldAsString(CIRCUITSERVICETYPE);
	}

	public void setL1Technology(String l1Technology)
	{
		setField(L1_TECHNOLOGY,l1Technology);
	}

	public String getL1Technology()
	{
		return getFieldAsString(L1_TECHNOLOGY);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setProtectiontype(String protectiontype)
	{
		setField(PROTECTIONTYPE,protectiontype);
	}

	public String getProtectiontype()
	{
		return getFieldAsString(PROTECTIONTYPE);
	}

	public void setAdaptiveModulation(String adaptiveModulation)
	{
		setField(ADAPTIVE_MODULATION,adaptiveModulation);
	}

	public String getAdaptiveModulation()
	{
		return getFieldAsString(ADAPTIVE_MODULATION);
	}

	public void setBc(String bc)
	{
		setField(BC,bc);
	}

	public String getBc()
	{
		return getFieldAsString(BC);
	}

	public void setBe(String be)
	{
		setField(BE,be);
	}

	public String getBe()
	{
		return getFieldAsString(BE);
	}

	public void setIsDiverse(String isDiverse)
	{
		setField(IS_DIVERSE,isDiverse);
	}

	public String getIsDiverse()
	{
		return getFieldAsString(IS_DIVERSE);
	}

	public void setAggregationprotocol(String aggregationprotocol)
	{
		setField(AGGREGATIONPROTOCOL,aggregationprotocol);
	}

	public String getAggregationprotocol()
	{
		return getFieldAsString(AGGREGATIONPROTOCOL);
	}

	public void setChannelSpacing(String channelSpacing)
	{
		setField(CHANNEL_SPACING,channelSpacing);
	}

	public String getChannelSpacing()
	{
		return getFieldAsString(CHANNEL_SPACING);
	}

	public void setAtpcAutomaticThreshold(String atpcAutomaticThreshold)
	{
		setField(ATPC_AUTOMATIC_THRESHOLD,atpcAutomaticThreshold);
	}

	public String getAtpcAutomaticThreshold()
	{
		return getFieldAsString(ATPC_AUTOMATIC_THRESHOLD);
	}

	public void setDiverseCircuitId(String diverseCircuitId)
	{
		setField(DIVERSE_CIRCUIT_ID,diverseCircuitId);
	}

	public String getDiverseCircuitId()
	{
		return getFieldAsString(DIVERSE_CIRCUIT_ID);
	}

	public void setAtpc(String atpc)
	{
		setField(ATPC,atpc);
	}

	public String getAtpc()
	{
		return getFieldAsString(ATPC);
	}

	public void setEir(String eir)
	{
		setField(EIR,eir);
	}

	public String getEir()
	{
		return getFieldAsString(EIR);
	}

	public void setAtpcMaxThreshold(String atpcMaxThreshold)
	{
		setField(ATPC_MAX_THRESHOLD,atpcMaxThreshold);
	}

	public String getAtpcMaxThreshold()
	{
		return getFieldAsString(ATPC_MAX_THRESHOLD);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setAssuredModulation(String assuredModulation)
	{
		setField(ASSURED_MODULATION,assuredModulation);
	}

	public String getAssuredModulation()
	{
		return getFieldAsString(ASSURED_MODULATION);
	}

	public void setAtpcRxThreshold(String atpcRxThreshold)
	{
		setField(ATPC_RX_THRESHOLD,atpcRxThreshold);
	}

	public String getAtpcRxThreshold()
	{
		return getFieldAsString(ATPC_RX_THRESHOLD);
	}

	public void setMco(String mco)
	{
		setField(MCO,mco);
	}

	public String getMco()
	{
		return getFieldAsString(MCO);
	}

	public void setAtpcMinThreshold(String atpcMinThreshold)
	{
		setField(ATPC_MIN_THRESHOLD,atpcMinThreshold);
	}

	public String getAtpcMinThreshold()
	{
		return getFieldAsString(ATPC_MIN_THRESHOLD);
	}

	public void setManualTpc(String manualTpc)
	{
		setField(MANUAL_TPC,manualTpc);
	}

	public String getManualTpc()
	{
		return getFieldAsString(MANUAL_TPC);
	}

	public void setIsLagMember(String isLagMember)
	{
		setField(IS_LAG_MEMBER,isLagMember);
	}

	public String getIsLagMember()
	{
		return getFieldAsString(IS_LAG_MEMBER);
	}

	public void setTsp(String tsp)
	{
		setField(TSP,tsp);
	}

	public String getTsp()
	{
		return getFieldAsString(TSP);
	}

	public void setPolarization(String polarization)
	{
		setField(POLARIZATION,polarization);
	}

	public String getPolarization()
	{
		return getFieldAsString(POLARIZATION);
	}

	public void setLagnumber(String lagnumber)
	{
		setField(LAGNUMBER,lagnumber);
	}

	public String getLagnumber()
	{
		return getFieldAsString(LAGNUMBER);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setCir(String cir)
	{
		setField(CIR,cir);
	}

	public String getCir()
	{
		return getFieldAsString(CIR);
	}

	public void setCircuitserialnumber(String circuitserialnumber)
	{
		setField(CIRCUITSERIALNUMBER,circuitserialnumber);
	}

	public String getCircuitserialnumber()
	{
		return getFieldAsString(CIRCUITSERIALNUMBER);
	}

	public void setUsage(String usage) {
		setField(USAGE,usage);
	}
	public  String getUsage() {
		return getFieldAsString(USAGE);
	}
	public void setDiversePwId(String diversePwId) {
		setField(DIVERSE_PW_ID,diversePwId);
	}
	public  String getDiversePwId() {
		return getFieldAsString(DIVERSE_PW_ID);
	}
	public void setExceptionHandlingInfo(String exceptionHandlingInfo) {
		setField(EXCEPTION_HANDLING_INFO,exceptionHandlingInfo);
	}
	public  String getExceptionHandlingInfo() {
		return getFieldAsString(EXCEPTION_HANDLING_INFO);
	}
	public void setModificationUserId(String modificationUserId) {
		setField(MODIFICATION_USER_ID,modificationUserId);
	}
	public  String getModificationUserId() {
		return getFieldAsString(MODIFICATION_USER_ID);
	}
	
	
	
	
	
	public void setRestrictedNotes(String RestrictedNotes) {
		setField(RESTRICTEDNOTES,RestrictedNotes);
	}
	public  String getRestrictedNotes() {
		return getFieldAsString(RESTRICTEDNOTES);
	
	}
	
	public void setrestrictedStatus(String restrictedStatus) {
		setField(RESTRICTEDSTATUS,restrictedStatus);
	}
	public  String getrestrictedStatus() {
		return getFieldAsString(RESTRICTEDSTATUS);
	}
	
	public void setsrcsys(String srcsys) {
		setField(SRCSYS,SRCSYS);
	}
	public  String getsrcsys() {
		return getFieldAsString(SRCSYS);
	}
	
	
	
	
	
	
	
	
}
