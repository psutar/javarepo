package com.centurylink.icl.armmediation.transformation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.armmediation.helper.MediationUtil;
import com.centurylink.icl.armmediation.helper.VOSearchHolder;
import com.centurylink.icl.armmediation.service.impl.PortVOService;
import com.centurylink.icl.armmediation.service.impl.SearchDeviceService;
import com.centurylink.icl.armmediation.valueobjects.objects.Card;
import com.centurylink.icl.armmediation.valueobjects.objects.Networkroleobject;
import com.centurylink.icl.armmediation.valueobjects.objects.Node;
import com.centurylink.icl.armmediation.valueobjects.objects.Port;
import com.centurylink.icl.armmediation.valueobjects.objects.Shelf;
import com.centurylink.icl.armmediation.valueobjects.objects.Slot;
import com.centurylink.icl.builder.cim2.CardBuilder;
import com.centurylink.icl.builder.cim2.CardOnCardDetailsBuilder;
import com.centurylink.icl.builder.cim2.CustomerBuilder;
import com.centurylink.icl.builder.cim2.IPAddressBuilder;
import com.centurylink.icl.builder.cim2.OwnsResourceDetailsBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceBuilder;
import com.centurylink.icl.builder.cim2.PhysicalDeviceRoleBuilder;
import com.centurylink.icl.builder.cim2.PhysicalPortBuilder;
import com.centurylink.icl.builder.cim2.RackBuilder;
import com.centurylink.icl.builder.cim2.RemarkBuilder;
import com.centurylink.icl.builder.cim2.ResourceRelationshipBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseBuilder;
import com.centurylink.icl.builder.cim2.SearchResourceResponseDocumentBuilder;
import com.centurylink.icl.builder.cim2.SearchResponseDetailsBuilder;
import com.centurylink.icl.builder.cim2.ShelfBuilder;
import com.centurylink.icl.builder.cim2.SlotBuilder;
import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.centurylink.icl.querybuilder.QueryBuilder;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.IPAddress;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchNodeVOTransformation {
	
	private static final Log LOG = LogFactory.getLog(SearchDeviceService.class);
	
	private static QueryBuilder portQueryBuilder = PortVOService.getQueryBuilder();

	public static SearchResourceResponseDocument transformToCIM(List<Node> nodes, VOSearchHolder searchHolder) throws Exception
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		boolean deviceFound = false;

		for (Node node:nodes)
		{
			PhysicalDevice device = buildDevice(node, searchHolder);
			if (device != null)
			{
				searchResponseDetailsBuilder.addDevice(device);
				deviceFound = true;
			}
		}

		if (!deviceFound)
		{
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		
		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}
		
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}
	
	public static CreateDeviceResponseDocument transformToCIMForCreateDevice(List<Node> nodes, VOSearchHolder searchHolder) throws Exception
	{			
		if ((nodes != null && nodes.size() > 0))
		{
			PhysicalDevice physicalDevice = buildDevice(nodes.get(0), searchHolder);
			return MediationUtil.getCreateDeviceSuccessResponse(physicalDevice, null);			
		}
		else
		{
			throw new OSSDataNotFoundException();
		}		
	}

	
	public static SearchResourceResponseDocument transformToCIM(Node node, VOSearchHolder searchHolder) throws Exception
	{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		PhysicalDevice device = buildDevice(node, searchHolder);
		if (device != null)
			searchResponseDetailsBuilder.addDevice(device);
		else
			throw new OSSDataNotFoundException();

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		
		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}
		
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();
	}

	protected static PhysicalDevice buildDevice(Node node, VOSearchHolder searchHolder) throws Exception
	{
		Map<String, String> modifiers = searchHolder.getModifiers();
		boolean includeRelatedDevice = false;
		if (modifiers.containsKey("INCLUDERELATEDDEVICE"))
		{
			if (modifiers.get("INCLUDERELATEDDEVICE").equalsIgnoreCase("TRUE"))
			{
				includeRelatedDevice = true;
			}
		}
		
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		PhysicalPortBuilder physicalPortBuilder = new PhysicalPortBuilder();
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		CardOnCardDetailsBuilder tempcardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();		
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();
		
		boolean applyPortFilter = false;
		boolean nodeHasPorts = false;
		String shelfNumber=null;
		String slotNumber=null;
		
		List<Condition> conditions=new ArrayList<Condition>();
		String portAdditionalQuery = null;
		if (searchHolder.getFilterCriteraList().get("PORTFILTER") != null && searchHolder.getLevel().equalsIgnoreCase("PORT"))
		{
			portAdditionalQuery = portQueryBuilder.buildQuery(searchHolder.getFilterCriteraList().get("PORTFILTER"));
			applyPortFilter = true;
			conditions =searchHolder.getFilterCriteraList().get("PORTFILTER").getValidationConditionList().get(0).getEqualConditionList();
		}
		for(Condition condition: conditions)
		{
			if(condition.getVariableName()!=null)
			{
				if(condition.getVariableName().equals("ShelfNumber"))
				{
					shelfNumber=condition.getValue();
				}
				else if(condition.getVariableName().equals("SlotNumber"))
				{
					slotNumber=condition.getValue();
				}
				else if(condition.getVariableName().equals("PortId"))
				{
					String card2ShelfSlot=null;
					Slot slot=null;
					String slot2Shelf=null;
					 for(Shelf s:node.getShelves())
					 {
						 
						for(Slot sl:s.getSlots())
						{
							
							for(Card cd:sl.getCards())
							{
								for(Port pt:cd.getCardPorts(portAdditionalQuery))
								{
									card2ShelfSlot=pt.getCard().getCard2shelfslot();
									slot= new Slot(card2ShelfSlot);
									slot2Shelf=slot.getSlot2shelf();
									slotNumber=slot.getSlotnumber();
									shelfNumber=new Shelf(slot2Shelf).getShelfnumber();
								}
								for(Slot crdSlot:cd.getCardSlots())
								{
									for(Card crd:crdSlot.getCards())
									{
										for(Port prt:crd.getCardPorts(portAdditionalQuery))
										{
											card2ShelfSlot=prt.getCard().getCard2shelfslot();
											slot= new Slot(card2ShelfSlot);
											slot2Shelf=slot.getSlot2shelf();
											slotNumber=slot.getSlotnumber();
											shelfNumber=new Shelf(slot2Shelf).getShelfnumber();
										}
									}
								}
							}
						}
					 }
				}
				
			}
		}
		if (searchHolder.getScope().equalsIgnoreCase("BASIC"))
		{
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), null, null, null, null, null, null, node.getNodeDef().getName(), null, null,null);
		} else {

			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), node.getDescription(), "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), node.getNodeExtension().getClli(), node.getAlias1(), node.getNodeDef().getManufacturer(), null, null, node.getNodeExtension().getVendorname(), node.getNodeDef().getName(),node.getNodeExtension().getMco(), node.getFunctionalstatus().getName(),node.getNodeExtension().getNetworkname());
			//rackBuilder.buildRack(node.getNodeExtension().getRelayrackid(), null, null, null, null, null, null, null);
			//physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			physicalDeviceBuilder.addDetails(node.getNodeDef().getVersion(), node.getNodeExtension().getFirmwareversion(), node.getSoftwareversion(), node.getAlias2(), node.getNodeExtension().getSharedDedicated(), null, null, node.getSerialno(), null, node.getNodeExtension().getVendorpartnumber(), node.getObjectid(), null, node.getNodeExtension().getNmstype(), node.getNodeExtension().getNmshostname(), null, node.getNodeExtension().getSnmpobjectid(), node.getNodeExtension().getChassisserialnumber());
			remarkBuilder.buildRemark(node.getNodeExtension().getRestrictednotes(),"RestrictedNotes");
			physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
			  remarkBuilder.buildRemark(node.getNodeExtension().getRestrictedStatus(),"RestrictedStatus");
		      physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());            		
			if(node.getNodeExtension().getMgmtvlan() != null)
				physicalDeviceBuilder.addResourceDescribedBy("ManagementVLAN", node.getNodeExtension().getMgmtvlan());	
		
			if(node.getNodeExtension().getMacaddress() != null)
			physicalDeviceBuilder.addResourceDescribedBy("MACAddress", node.getNodeExtension().getMacaddress());
			
			
			physicalDeviceBuilder.addResourceDescribedBy("1GbpsIndicator", node.getNodeExtension().getGbpsindicator());
						
			if(node.getNodeExtension().getSelfortechinstall() != null)
				physicalDeviceBuilder.addResourceDescribedBy("InstallationIndicator", node.getNodeExtension().getSelfortechinstall());
			if(node.getNodeExtension().getNwknodenumber() != null)
				physicalDeviceBuilder.addResourceDescribedBy("NetworkNodeNumber", node.getNodeExtension().getNwknodenumber());			
			
                        if(node.getSubstatus() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("SubStatus", node.getSubstatus());
			if(node.getMarkedfordelete() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("MarkedForDeletion", node.getMarkedfordelete());
			if(node.getNodeExtension().getRevision() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("Revision", node.getNodeExtension().getRevision());
			if(node.getNodeExtension().getDiscontinuedate() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("DiscontinueDate", node.getNodeExtension().getDiscontinuedate());
			if(node.getNodeExtension().getManufacturerpartnumber() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("ManufacturerPartNumber", node.getNodeExtension().getManufacturerpartnumber());
			if(node.getNodeExtension().getParttype() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("PartType", node.getNodeExtension().getParttype());
			
			physicalDeviceBuilder.addResourceDescribedBy("IsSharedOrDedicated", node.getNodeExtension().getSharedDedicated());
			physicalDeviceBuilder.addResourceDescribedBy("IsDiversed", node.getNodeExtension().getIsDiverse());
			
			if(node.getFullname() !=null)
				physicalDeviceBuilder.addResourceDescribedBy("FullName", node.getFullname());			

			if (node.getSubscriber() != null)
			{
				physicalDeviceBuilder.setOwnsResourceDetails(SearchSubscriberVOTransformation.getCLCCustomerFromSubscriber(node.getSubscriber()));
			}	

			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console1()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console1(), "Console 1"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console2()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console2(), "Console 2"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console3()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console3(), "Console 3"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4mgmrouterid()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4mgmrouterid(), "Mgm Router Id"));

			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv6console1()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv6console1(), "Console 1","6"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv6console2()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv6console2(), "Console 2","6"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv6console3()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv6console3(), "Console 3","6"));
			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv6mgmrouterid()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv6mgmrouterid(), "Mgm Router Id","6"));

			if (!StringHelper.isEmpty(node.getNodeExtension().getMacaddress()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getMacaddress(), "MAC Address",null));

			
			if(node.getNodeExtension().getHardwareversion()!=null)
				physicalDeviceBuilder.addResourceDescribedBy("HardwareVersion", node.getNodeExtension().getHardwareversion());
			
			
			
			String role = null;
			for (Networkroleobject networkroleobject : node.getNetworkroleobjects())
			{
				physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
				physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicalDeviceRole());
				if("ONT".equalsIgnoreCase(networkroleobject.getNetworkroleobject2networkrole())){
                    role = "ONT";
                }				
			}
                        
			physicalDeviceBuilder.addResourceDescribedBy("OLTID", node.getNodeExtension().getNwknodenumber());
			physicalDeviceBuilder.addResourceDescribedBy("MaximumSubscriberOfferedBW", node.getNodeExtension().getMaxsubscriberbwoffered());
						
			physicalDeviceBuilder.addResourceDescribedBy("NOSACertification", node.getNodeExtension().getPrismnosacert());
						
			physicalDeviceBuilder.addResourceDescribedBy("StackRingSeqNum", node.getNodeExtension().getStackringseqnum());
			physicalDeviceBuilder.addResourceDescribedBy("StackRingShelfID", node.getNodeExtension().getStackringshelfid());			
						
			physicalDeviceBuilder.addResourceDescribedBy("AerialOrBuried", node.getNodeExtension().getAerialorburied());
						
			physicalDeviceBuilder.addResourceDescribedBy("IsIndoor", node.getNodeExtension().getIndoor());
			physicalDeviceBuilder.addResourceDescribedBy("MaxDownStreamRate", node.getNodeExtension().getMaxDownStreamRate());
			physicalDeviceBuilder.addResourceDescribedBy("MaxUpStreamRate", node.getNodeExtension().getMaxUpStreamRate());
			
			
			physicalDeviceBuilder.addResourceDescribedBy("FiberINRange", node.getNodeExtension().getFiberinrange());
			physicalDeviceBuilder.addResourceDescribedBy("FiberOUTRange", node.getNodeExtension().getFiberoutrange());
			physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupNumber", node.getNodeExtension().getSplittergrpnum());
			physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupName", node.getNodeExtension().getSplittergrpname());
			physicalDeviceBuilder.addResourceDescribedBy("StartPortNumber", node.getNodeExtension().getSplitterstartportnumber());
			//physicalDeviceBuilder.addResourceDescribedBy("NetworkNodeNumber", node.getNodeExtension().getNwknodenumber());
			physicalDeviceBuilder.addResourceDescribedBy("InstallDate", node.getNodeExtension().getInstalldate());
			
			//physicalDeviceBuilder.addResourceDescribedBy("InstallationIndicator", node.getNodeExtension().getSelfortechinstall());
			physicalDeviceBuilder.addResourceDescribedBy("RONTAID", node.getNodeExtension().getRontaid());
			physicalDeviceBuilder.addResourceDescribedBy("PowerSupply", node.getNodeExtension().getPowersupply());
			physicalDeviceBuilder.addResourceDescribedBy("Opti-tap", node.getNodeExtension().getOptitap());
			physicalDeviceBuilder.addResourceDescribedBy("SAPCode", node.getNodeExtension().getSapcode());
			physicalDeviceBuilder.addResourceDescribedBy("SerialNo", node.getNodeExtension().getSerialnumber());
			
			//physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));
			
			if(null != role && role.equalsIgnoreCase("ONT") )
			{
				physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCInstalledAddressFromLocation(node.getLocation(), node.getName()));
			}
			else{
			    physicalDeviceBuilder.addInstalledAtAddress(SearchLocationVOTransformation.getCLCAddressFromLocation(node.getLocation()));
			}
			
			boolean shelfHasPorts;
			boolean slotHasPorts;
			boolean cardHasPorts;
			boolean cardCardHasPorts;
			List<String> sfpOnDevice = new ArrayList<String>();
			List<String> sfpOnCard = new ArrayList<String>();

			if (searchHolder.getLevel().equalsIgnoreCase("PORT"))
			{
				HashSet<String> slots=new HashSet<String>();
				int shelfSize=node.getShelves(shelfNumber).size();
					
				// Case when There are no Shelf/Slot/Card on a device And ShelfNumber is passed in Filter	
				if(shelfNumber!= null && shelfSize == 0)
				{
					throw new OSSDataNotFoundException();
				}	
				if (shelfSize > 0)
				{
					rackBuilder.buildRack(node.getNodeExtension().getRelayrackid(), null, null, null, null, null, null, null);
					for (Shelf shelf:node.getShelves(shelfNumber))
					{ 
						shelfHasPorts = false;
						if(shelf!=null)
						{
							shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, null, null);
							shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
						}

						for (Slot slot:shelf.getSlots(slotNumber))
						{				
							slotHasPorts = false;
							if(slot!=null)
							{
								slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber())); 
							}

							for (Card card:slot.getCards(slotNumber)) {
								cardHasPorts = false;
								if(card!=null)
								{
									cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, "ARM", null, null, card.getAlias1(), card.getCardtype().getName(), null);
								}

								for (Port port:card.getCardPorts(portAdditionalQuery,applyPortFilter))
								{
									nodeHasPorts = true;
									shelfHasPorts = true;
									slotHasPorts = true;
									cardHasPorts = true;
									if(port!=null)
									{	
										String networkPortName=null;
										if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
										{
											networkPortName=port.getPortExtension().getIfName();
										}
										
										physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), null, null, port.getPortExtension().getBandwidth(),null,port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,port.getFunctionalstatus().getName(),null,null,null,networkPortName);
										//Checking for pluggable port
										if(port != null && port.getPort2porttype().equals("1900000003") && port.getPortExtension()!= null)
										{
											if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
												physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());
											if (port.getPortExtension().getBandwidth() != null || port.getPortExtension().getFormfactor() != null) 
											{ 
												String transmissionRate="";
												if(port.getPortExtension().getBandwidth() != null)
													transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
												if(port.getPortExtension().getFormfactor()!=null)
													transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();

												physicalPortBuilder.addResourceDescribedBy("TransmissionRate",transmissionRate);
											}
										}
										else 
										{	
											if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
												physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());			
											if(port.getBandwidthObject() != null && !StringHelper.isEmpty(port.getBandwidthObject().getName()))
												physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port.getBandwidthObject().getName());
										}
										if(port.getPortExtension().getIfnum()!=null)
										{
										physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
										}
										String  reservation = port.getPortReservationByQuery(port.getPortid(), "4");
										physicalPortBuilder.addResourceDescribedBy("ReservationFlag", reservation);

										cardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
                                                                                String sfpName = port.getSfpName(port.getPortid());											
										if(null != sfpName){											
											sfpOnCard.add(sfpName);
										}								
									}

								}

                                                                if (sfpOnCard != null && !sfpOnCard.isEmpty())
								{
									cardOnCardDetailsBuilder.buildCardOnCardDetails();
									for (String sfpName : sfpOnCard)
									{
										cardOnCardDetailsBuilder.addCard(sfpName);
									}
									cardBuilder.addAllowableCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
								}

								for (Slot cardSlot:card.getCardSlots())
								{
									cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
									for (Card slotCard:cardSlot.getCards())
									{
										cardCardHasPorts = false;
										if(slotCard!=null)
										{		
											embededCardBuilder.buildCard(slotCard.getName(), slotCard.getCardid(), slotCard.getProvisionstatus().getName(), null, "ARM", null, null, slotCard.getAlias1(), slotCard.getCardtype().getName(), null);
										}										
										for (Port port:slotCard.getCardPorts(portAdditionalQuery))
										{

											nodeHasPorts = true;
											shelfHasPorts = true;
											slotHasPorts = true;
											cardHasPorts = true;
											cardCardHasPorts = true;
											if(port!=null)
											{
												String networkPortName=null;
												if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
												{
													networkPortName=port.getPortExtension().getIfName();
												}
												physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), port.getPortExtension().getBandwidth(),port.getPortExtension().getWavelength(),port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,port.getFunctionalstatus().getName(),null,null,null,networkPortName);
												//Checking for pluggable port
												if(port != null && port.getPort2porttype().equals("1900000003") && port.getPortExtension()!= null)
												{
													if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
														physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());
													if (port.getPortExtension().getBandwidth() != null || port.getPortExtension().getFormfactor() != null) 
													{ 
														String transmissionRate="";
														if(port.getPortExtension().getBandwidth() != null)
															transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
														if(port.getPortExtension().getFormfactor()!=null)
															transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();

														physicalPortBuilder.addResourceDescribedBy("TransmissionRate",transmissionRate);
													}
												}
												else 
												{	
													if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
														physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());			
													if(port.getBandwidthObject() != null && !StringHelper.isEmpty(port.getBandwidthObject().getName()))
														physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port.getBandwidthObject().getName());
												}
												if(null!=port.getPortExtension().getIfnum())
												{
												physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
												}
												String  reservation = port.getPortReservationByQuery(port.getPortid(), "4");
											physicalPortBuilder.addResourceDescribedBy("ReservationFlag", reservation);
												embededCardBuilder.addPhysicalPort(physicalPortBuilder.getPhysicalPort());
												
											}
										}
										if (!applyPortFilter || cardCardHasPorts)
											cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
									}
									if (!applyPortFilter || cardHasPorts)
										if(cardOnCardDetailsBuilder.getCardOnCardDetails().getCardList().size()>0)
										{
											cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
										}
								}
								if (!applyPortFilter || cardHasPorts)
								{
									if(card.getCard2shelfslot().equals(slot.getSlotid()))
										slotBuilder.addHasCard(cardBuilder.getCard());
								}
							}
							if (!applyPortFilter || slotHasPorts)
							{
								if(shelfBuilder.getShelf()!=null && slot.getSlot2shelf().equals(shelf.getShelfid())
										&& !slots.contains(slotBuilder.getSlot().getObjectID()))
								{
									shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
									slots.add(slotBuilder.getSlot().getObjectID());
								}
							}
						}
						if (!applyPortFilter || shelfHasPorts)
						{
							if(shelfBuilder.getShelf()!=null)
							{
								rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
							}
						}
					}
					physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
				}
				
				if (node.getDevicePorts(portAdditionalQuery,false) != null && node.getDevicePorts(portAdditionalQuery,false).size() > 0)
				{
					for (Port port:node.getDevicePorts(portAdditionalQuery,false))
					{
						nodeHasPorts = true;
						String networkPortName=null;
						if(port.getPortExtension() != null && port.getPortExtension().getIfName() != null)
						{
							networkPortName=port.getPortExtension().getIfName();
						}
																		
						physicalPortBuilder.buildPhysicalPort(port.getName(), port.getPortid(), port.getProvisionstatus().getName(), Integer.valueOf(port.getPortnumber()), port.getPortExtension().getDpea(), port.getPortExtension().getPluggabletype(), port.getPortExtension().getBandwidth(),port.getPortExtension().getWavelength(),port.getAlias1(),port.getPortExtension().getPortfunction(),port.getPorttype().getName(),null,port.getFunctionalstatus().getName(),null,null,null,networkPortName);
						//Checking for pluggable port
						if(port != null && port.getPort2porttype().equals("1900000003") && port.getPortExtension()!= null)
						{
							if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
								physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());
							if (port.getPortExtension().getBandwidth() != null || port.getPortExtension().getFormfactor() != null) 
							{ 
								String transmissionRate="";
								if(port.getPortExtension().getBandwidth() != null)
									transmissionRate=transmissionRate+port.getPortExtension().getBandwidth();
								if(port.getPortExtension().getFormfactor()!=null)
									transmissionRate=transmissionRate+port.getPortExtension().getFormfactor();

								physicalPortBuilder.addResourceDescribedBy("TransmissionRate",transmissionRate);
							}
						}
						else 
						{	
							if(!StringHelper.isEmpty(port.getPortExtension().getIfnum()))
								physicalPortBuilder.addResourceDescribedBy("IfNum", port.getPortExtension().getIfnum());			
							if(port.getBandwidthObject() != null && !StringHelper.isEmpty(port.getBandwidthObject().getName()))
								physicalPortBuilder.addResourceDescribedBy("TransmissionRate", port.getBandwidthObject().getName());
						}
						if(port.getPortExtension().getIfnum()!=null)
						{
						physicalPortBuilder.addResourceDescribedBy("SNMPId", port.getPortExtension().getIfnum());
						}
						String  reservation = port.getPortReservationByQuery(port.getPortid(), "4");
						physicalPortBuilder.addResourceDescribedBy("ReservationFlag", reservation);

						physicalDeviceBuilder.addHasPorts(physicalPortBuilder.getPhysicalPort());

                                                String sfpName = port.getSfpName(port.getPortid());	
						
						if(null !=sfpName){							
						sfpOnDevice.add(sfpName);
						}
					}

                                        if (sfpOnDevice != null && !sfpOnDevice.isEmpty())
					{
						cardBuilder.buildCard(null, null, null);
						cardOnCardDetailsBuilder.buildCardOnCardDetails();
						for (String sfpName : sfpOnDevice)
						{
							tempcardOnCardDetailsBuilder.buildCardOnCardDetails(sfpName, null, null, null);
							cardBuilder.addCardOnCardDetails(tempcardOnCardDetailsBuilder.getCardOnCardDetails());
						}
						cardOnCardDetailsBuilder.addCard(cardBuilder.getCard());
						physicalDeviceBuilder.addAllowableSFPDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
					}

				}
			}
			
			if (includeRelatedDevice)
			{
				if (node.getAssociatedDevices().size() > 0)
				{
					ResourceRelationshipBuilder resourceRelationshipBuilder = new ResourceRelationshipBuilder();
	
					for (Node associatedDevice:node.getAssociatedDevices())
					{
						resourceRelationshipBuilder.buildResourceRelationship(null, null, null, null, null);
						resourceRelationshipBuilder.setDevice(SearchNodeVOTransformation.buildDeviceRelationship(associatedDevice));
						physicalDeviceBuilder.addResourceRelationship(resourceRelationshipBuilder.getResourceRelationship());
					}
				}
			}
		
		}

		if (!applyPortFilter || nodeHasPorts)
			return physicalDeviceBuilder.getPhysicalDevice();
		else
			return null;
	}

	protected static PhysicalDevice buildDeviceFromPort(Port port, String scope)
	{
		return buildDeviceFromPort(port, true, scope);
	}
	protected static PhysicalDevice buildDeviceFromPort(Port port)
	{
		return buildDeviceFromPort(port, true);
	}

	protected static PhysicalDevice buildDeviceFromPortForOB(Port port, boolean includePort)
	{
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();
		RemarkBuilder remarkBuilder = new RemarkBuilder();

		Port topPort = port.getTopLevelPort();

		Node node = port.getNode();

		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node, "SUMMARY");
		remarkBuilder.buildRemark(node.getNodeExtension().getRestrictednotes(),"RestrictedNotes");
		physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks());
		remarkBuilder.buildRemark(node.getNodeExtension().getRestrictedStatus(),"RestrictedStatus");
	    physicalDeviceBuilder.addRemark(remarkBuilder.getRemarks()); 
		physicalDeviceBuilder.addResourceDescribedBy("AerialOrBuried", node.getNodeExtension().getAerialorburied());
		physicalDeviceBuilder.addResourceDescribedBy("FiberINRange", node.getNodeExtension().getFiberinrange());
		physicalDeviceBuilder.addResourceDescribedBy("FiberOUTRange", node.getNodeExtension().getFiberoutrange());
		physicalDeviceBuilder.addResourceDescribedBy("StartPortNumber", node.getNodeExtension().getSplitterstartportnumber());
		physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupNumber", node.getNodeExtension().getSplittergrpnum());
		physicalDeviceBuilder.addResourceDescribedBy("SplitterGroupName", node.getNodeExtension().getSplittergrpname());
		physicalDeviceBuilder.addResourceDescribedBy("EMSOrCMSNodeId", node.getObjectid());
		physicalDeviceBuilder.addResourceDescribedBy("ONTID", node.getAlias1());
		physicalDeviceBuilder.addResourceDescribedBy("IsIndoor", node.getNodeExtension().getIndoor());
		physicalDeviceBuilder.addResourceDescribedBy("MaximumSubscriberOfferedBW", node.getNodeExtension().getMaxsubscriberbwoffered());
		physicalDeviceBuilder.addResourceDescribedBy("MaxDownStreamRate", node.getNodeExtension().getMaxDownStreamRate());
		physicalDeviceBuilder.addResourceDescribedBy("MaxUpStreamRate", node.getNodeExtension().getMaxUpStreamRate());
		physicalDeviceBuilder.addResourceDescribedBy("NetworkNodeNumber", node.getNodeExtension().getNwknodenumber());
		physicalDeviceBuilder.addResourceDescribedBy("InstallDate", node.getNodeExtension().getInstalldate());
		physicalDeviceBuilder.addResourceDescribedBy("InstallationIndicator", node.getNodeExtension().getSelfortechinstall());
		physicalDeviceBuilder.addResourceDescribedBy("RONTAID", node.getNodeExtension().getRontaid());
		physicalDeviceBuilder.addResourceDescribedBy("PowerSupply", node.getNodeExtension().getPowersupply());
		physicalDeviceBuilder.addResourceDescribedBy("Opti-tap", node.getNodeExtension().getOptitap());
		physicalDeviceBuilder.addResourceDescribedBy("SAPCode", node.getNodeExtension().getSapcode());
		physicalDeviceBuilder.addResourceDescribedBy("SerialNo", node.getNodeExtension().getSerialnumber());
		physicalDeviceBuilder.addResourceDescribedBy("Revision", node.getNodeExtension().getRevision());
		physicalDeviceBuilder.addResourceDescribedBy("PartNumber", node.getNodeExtension().getVendorpartnumber());
		physicalDeviceBuilder.addResourceDescribedBy("SoftwareVersion", node.getSoftwareversion());
		
		if (!topPort.isOnCard())
		{
			if (includePort)
			{
				physicalDeviceBuilder.addHasPorts(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				shelfBuilder.buildShelf(null, null, null);
				shelfBuilder.setRackInformation(node.getNodeExtension().getRelayrackid(), null);
				physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
			}
		} else {
			if (topPort.getCard().getParentSlot().isOnCard())
			{
				Card cardCard = topPort.getCard();
				Slot cardSlot = cardCard.getParentSlot();
				Card card = cardSlot.getParentCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(null, null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
				embededCardBuilder.buildCard(cardCard.getName(), cardCard.getCardid(), cardCard.getCard2provisionstatus(), null, null, null, null, cardCard.getAlias1(), cardCard.getCardtype().getName(), null);
				if (includePort)
				{
					embededCardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				}
				cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
				cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			} else {
				Card card = topPort.getCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(null, null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				if (includePort)
				{
					cardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				}
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			}
		}

		return physicalDeviceBuilder.getPhysicalDevice();
	}

	protected static PhysicalDevice buildDeviceFromPort(Port port, boolean includePort)
	{
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();

		Port topPort = port.getTopLevelPort();

		Node node = port.getNode();

		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node, "SUMMARY");
                                  

		if (!topPort.isOnCard())
		{
			if (includePort)
			{
				physicalDeviceBuilder.addHasPorts(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				shelfBuilder.buildShelf(null, null, null);
				shelfBuilder.setRackInformation(node.getNodeExtension().getRelayrackid(), null);
				physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
			}
		} else {
			if (topPort.getCard().getParentSlot().isOnCard())
			{
				Card cardCard = topPort.getCard();
				Slot cardSlot = cardCard.getParentSlot();
				Card card = cardSlot.getParentCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(shelf.getShelfExtension().getRelayrackid(), null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
				embededCardBuilder.buildCard(cardCard.getName(), cardCard.getCardid(), cardCard.getCard2provisionstatus(), null, null, null, null, cardCard.getAlias1(), cardCard.getCardtype().getName(), null);
				if (includePort)
				{
					embededCardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				}
				cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
				cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			} else {
				Card card = topPort.getCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(shelf.getShelfExtension().getRelayrackid(), null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				if (includePort)
				{
					cardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, "BASIC"));
				}
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			}
		}

		return physicalDeviceBuilder.getPhysicalDevice();
	}
	protected static PhysicalDevice buildDeviceFromPort(Port port, boolean includePort, String scope)
	{
		RackBuilder rackBuilder = new RackBuilder();
		ShelfBuilder shelfBuilder = new ShelfBuilder();
		SlotBuilder slotBuilder = new SlotBuilder();
		CardBuilder cardBuilder = new CardBuilder();
		CardBuilder embededCardBuilder = new CardBuilder();
		CardOnCardDetailsBuilder cardOnCardDetailsBuilder = new CardOnCardDetailsBuilder();

		Port topPort = port.getTopLevelPort();

		Node node = port.getNode();

		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node, scope);

		if (!topPort.isOnCard())
		{
			if (includePort)
			{
				physicalDeviceBuilder.addHasPorts(SearchPortVOTransformation.transformPortToCIM(topPort, scope));
				shelfBuilder.buildShelf(null, null, null);
				shelfBuilder.setRackInformation(node.getNodeExtension().getRelayrackid(), null);
				physicalDeviceBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
			}
		} else {
			if (topPort.getCard().getParentSlot().isOnCard())
			{
				Card cardCard = topPort.getCard();
				Slot cardSlot = cardCard.getParentSlot();
				Card card = cardSlot.getParentCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(null, null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				cardOnCardDetailsBuilder.buildCardOnCardDetails(null, null, null, null, cardSlot.getSlotnumber());
				embededCardBuilder.buildCard(cardCard.getName(), cardCard.getCardid(), cardCard.getCard2provisionstatus(), null, null, null, null, cardCard.getAlias1(), cardCard.getCardtype().getName(), null);
				if (includePort)
				{
					embededCardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, scope));
				}
				cardOnCardDetailsBuilder.addCard(embededCardBuilder.getCard());
				cardBuilder.addCardOnCardDetails(cardOnCardDetailsBuilder.getCardOnCardDetails());
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			} else {
				Card card = topPort.getCard();
				Slot slot = card.getParentSlot();
				Shelf shelf = slot.getShelf();
				rackBuilder.buildRack(null, null, null, null, null, null, null, null);
				shelfBuilder.buildShelf(shelf.getName(), shelf.getShelfid(), null, null, null, null, null, shelf.getAlias1(), shelf.getAlias2(), null, node.getNodeExtension().getRelayrackid(), null);
				shelfBuilder.addResourceDescribedBy("shelfNumber", shelf.getShelfnumber());
				slotBuilder.buildSlot(slot.getName(), slot.getSlotid(), null, Integer.valueOf(slot.getSlotnumber()));
				cardBuilder.buildCard(card.getName(), card.getCardid(), card.getProvisionstatus().getName(), null, null, null, null, card.getAlias1(), card.getCardtype().getName(), null);
				if (includePort)
				{
					cardBuilder.addPhysicalPort(SearchPortVOTransformation.transformPortToCIM(topPort, scope));
				}
				slotBuilder.addHasCard(cardBuilder.getCard());
				shelfBuilder.addConsistsOfSlot(slotBuilder.getSlot());
				rackBuilder.addConsistsOfShelf(shelfBuilder.getShelf());
				physicalDeviceBuilder.addConsistsOfRack(rackBuilder.getRack());
			}
		}

		return physicalDeviceBuilder.getPhysicalDevice();
	}

	private static PhysicalDeviceBuilder buildBasicDevice(Node node, String scope)
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		OwnsResourceDetailsBuilder ownsResourceDetailsBuilder = new OwnsResourceDetailsBuilder();
		CustomerBuilder customerBuilder = new CustomerBuilder();
		PhysicalDeviceRoleBuilder physicalDeviceRoleBuilder = new PhysicalDeviceRoleBuilder();
		
		if (scope.equalsIgnoreCase("BASIC"))
		{
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", node.getNodeType().getName(), null, node.getProvisionstatus().getName(), null, null, null, null, null, null, node.getNodeDef().getName(), null, null);
		} else {

			String resourceType=null;
			String functionalStatus=null;
			String resourceSubType=null;
			String prStatus=null;
			if(node != null)
			{
				if(node.getNodeType() != null && node.getNodeType().getName() != null)
					resourceType=node.getNodeType().getName();
				if(node.getFunctionalstatus() != null && node.getFunctionalstatus().getName() != null)
					functionalStatus=node.getFunctionalstatus().getName();
				if(node.getNodeDef()!=null && node.getNodeDef().getName() != null)
					resourceSubType=node.getNodeDef().getName();
				if(node.getProvisionstatus() != null && node.getProvisionstatus().getName() != null)
					prStatus=node.getProvisionstatus().getName();
			}
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", resourceType, null, prStatus, node.getNodeExtension().getClli(), node.getAlias1(), null, node.getNodeExtension().getParttype(), null, node.getNodeExtension().getVendorname(), resourceSubType, node.getNodeExtension().getMco(), functionalStatus);
			physicalDeviceBuilder.addDetails(null, null, null, node.getAlias2(), null, null, null, null, null, node.getNodeExtension().getVendorpartnumber(), null, null, null, null, null, null, null);

			if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4mgmrouterid()))
				physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4mgmrouterid(), "Mgm Router Id"));

			physicalDeviceBuilder.addResourceDescribedBy("Fullname", node.getFullname());
			physicalDeviceBuilder.addResourceDescribedBy("IsSharedOrDedicated", node.getNodeExtension().getSharedDedicated());
			physicalDeviceBuilder.addResourceDescribedBy("IsDiversed", node.getNodeExtension().getIsDiverse());
			physicalDeviceBuilder.addResourceDescribedBy("MCO", node.getNodeExtension().getMco());
			/*physicalDeviceBuilder.addResourceDescribedBy("Model", node.getNodeExtension().getParttype());*/
			physicalDeviceBuilder.addResourceDescribedBy("VendorName", node.getNodeExtension().getVendorname());
			physicalDeviceBuilder.addResourceDescribedBy("RAM", node.getStorageram());

			if (node.getSubscriber() != null)
			{
				ownsResourceDetailsBuilder.buildOwnsResourceDetails();
				customerBuilder.buildCustomer(node.getSubscriber().getName(), node.getSubscriber().getSubscriberid(), null, node.getSubscriber().getFullname(), null, null);
				ownsResourceDetailsBuilder.addCustomer(customerBuilder.getCustomer());
				physicalDeviceBuilder.setOwnsResourceDetails(ownsResourceDetailsBuilder.getOwnsResourceDetails());
			}
			
			if (scope.equalsIgnoreCase("DETAILED"))
			{
				if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console1()))
					physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console1(), "Console 1"));
				if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console2()))
					physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console2(), "Console 2"));
				if (!StringHelper.isEmpty(node.getNodeExtension().getIpv4console3()))
					physicalDeviceBuilder.addIPAddress(buildIPAddress(node.getNodeExtension().getIpv4console3(), "Console 3"));
			}
		}
		if(node.getNetworkroleobjects() != null )
			for (Networkroleobject networkroleobject : node.getNetworkroleobjects()) {
				if(networkroleobject.getNetworkroleobject2networkrole()!= null){
				physicalDeviceRoleBuilder.buildPhysicalDeviceRole(networkroleobject.getNetworkroleobject2networkrole());
				physicalDeviceBuilder.addHasPhysicalDeviceRoles(physicalDeviceRoleBuilder.getPhysicaldevicerole());
				}
			}	
		if(node.getNodeExtension() != null && node.getNodeExtension().getRelayrackid()!= null){
			physicalDeviceBuilder.addResourceDescribedBy("RelayRackId", node.getNodeExtension().getRelayrackid());
		}

		return physicalDeviceBuilder;
	}

	private static IPAddress buildIPAddress(String address, String type)
	{
		return buildIPAddress(address, type, "4");
	}

	private static IPAddress buildIPAddress(String address, String type, String version)
	{
		IPAddressBuilder ipAddressBuilder = new IPAddressBuilder();

		ipAddressBuilder.buildIPAddress(address, type, null, null, null, version);

		return ipAddressBuilder.getIPAddress();
	}
	
	private static PhysicalDevice buildDeviceRelationship(Node node)
	{
		PhysicalDeviceBuilder physicalDeviceBuilder = buildBasicDevice(node, "BASIC");
		
		physicalDeviceBuilder.addResourceDescribedBy("ContainerRackShelfId", node.getNodeInRackShelf().getNirs2rackshelf());
		//physicalDeviceBuilder.addResourceDescribedBy("DevicePositioninRackDevice-XPOS", node.getNodeInRackShelf().getXpos());
		//physicalDeviceBuilder.addResourceDescribedBy("DevicePositioninRackDevice-YPOS", node.getNodeInRackShelf().getYpos());
		//physicalDeviceBuilder.addResourceDescribedBy("DevicePositioninRackDevice-ZPOS", node.getNodeInRackShelf().getZpos());

		return physicalDeviceBuilder.getPhysicalDevice();
	}

	public static Object transformToCIMForPreferredCompatibleONTModels(
			List<Node> nodes, VOSearchHolder searchHolder) throws Exception{
		SearchResourceResponseDocumentBuilder searchResourceResponseDocumentBuilder = new SearchResourceResponseDocumentBuilder();
		SearchResourceResponseBuilder searchResourceResponseBuilder = new SearchResourceResponseBuilder();
		SearchResponseDetailsBuilder searchResponseDetailsBuilder = new SearchResponseDetailsBuilder();

		searchResourceResponseDocumentBuilder.buildSearchResourceResponseDocument();
		searchResponseDetailsBuilder.buildSearchResponseDetails();

		boolean deviceFound = false;

		for (Node node:nodes)
		{
			PhysicalDevice device = buildDeviceForPreferredCompatibleONTModels(node, searchHolder);
			if (device != null)
			{
				searchResponseDetailsBuilder.addDevice(device);
				deviceFound = true;
			}
		}

		if (!deviceFound)
		{
			throw new OSSDataNotFoundException();
		}

		searchResourceResponseBuilder.buildSearchResourceResponse(searchResponseDetailsBuilder.getSearchResponseDetails(), null);
		searchResourceResponseDocumentBuilder.addSearchResourceResponse(searchResourceResponseBuilder.getSearchResourceResponse());
		
		if (LOG.isInfoEnabled())
		{
			LOG.info(searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument().toString());
		}
		
		return searchResourceResponseDocumentBuilder.getSearchResourceResponseDocument();

	}

	private static PhysicalDevice buildDeviceForPreferredCompatibleONTModels(
			Node node, VOSearchHolder searchHolder) {
		boolean applyPortFilter = false;
		boolean nodeHasPorts = false;
		String portAdditionalQuery = null;
		
		PhysicalDeviceBuilder physicalDeviceBuilder = new PhysicalDeviceBuilder();
		
		
		if (searchHolder.getScope().equalsIgnoreCase("Summary"))
		{
			physicalDeviceBuilder.buildPhysicalDevice(node.getName(), node.getNodeid(), null, "ARM", null, null, null, null, null, null, null, null, null, null, null, null,null);
		}
		
		
		Map<String, String> modifiers = searchHolder.getModifiers();
		String downStreamBW = modifiers.get("DOWNSTREAMBANDWIDTH");
		String upStreamBW = modifiers.get("UPSTREAMBANDWIDTH");
		String nodeDef = node.getNodeDef().getName();
		
		 		
		     		
		        List<String>  vendorcompatibilityList = node.getCompatibleONTModelsByQuery(nodeDef, downStreamBW, upStreamBW);
				
				for(String vendorcompatibility : vendorcompatibilityList){
					physicalDeviceBuilder.addResourceDescribedBy("CompatibleONTModel", vendorcompatibility);
				}
								  
				String preferredDevice = node.getPreferredDeviceModelsByQuery(nodeDef);
					
				
					if(vendorcompatibilityList.contains(preferredDevice)){
						physicalDeviceBuilder.addResourceDescribedBy("PreferredONTModel", preferredDevice);
					}
					
									 
		

			
				return physicalDeviceBuilder.getPhysicalDevice();
	}

}
