package com.centurylink.icl.armmediation.valueobjects.objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.dataaccess.ValueObjectCacheAccessorFactory;
import com.centurylink.icl.valueobjects.impl.ComplexLinkedTable;
import com.centurylink.icl.valueobjects.impl.Field;
import com.centurylink.icl.valueobjects.impl.PrimaryKey;


public class Card extends AbstractReadOnlyTable {

	private static final long serialVersionUID = 1L;


	private static final Log LOG = LogFactory.getLog(Node.class);

	private static final String CARDID = "CARDID";
	private static final String NAME = "NAME";
	private static final String FULLNAME = "FULLNAME";
	private static final String RELATIVENAME = "RELATIVENAME";
	private static final String ALIAS1 = "ALIAS1";
	private static final String ALIAS2 = "ALIAS2";
	private static final String OBJECTID = "OBJECTID";
	private static final String SUBTYPE = "SUBTYPE";
	private static final String SUBSTATUS = "SUBSTATUS";
	private static final String CARD2CARDTYPE = "CARD2CARDTYPE";
	private static final String DESCRIPTION = "DESCRIPTION";
	private static final String NOTES = "NOTES";
	private static final String CREATEDDATE = "CREATEDDATE";
	private static final String LASTMODIFIEDDATE = "LASTMODIFIEDDATE";
	private static final String CREATEDBY2DIMUSER = "CREATEDBY2DIMUSER";
	private static final String LASTMODIFIEDBY2DIMUSER = "LASTMODIFIEDBY2DIMUSER";
	private static final String CARD2PROVISIONSTATUS = "CARD2PROVISIONSTATUS";
	private static final String MARKEDFORDELETE = "MARKEDFORDELETE";
	private static final String INUSE = "INUSE";
	private static final String CARD2FUNCTIONALSTATUS = "CARD2FUNCTIONALSTATUS";
	private static final String CARD2NODE = "CARD2NODE";
	private static final String CARD2LOCATION = "CARD2LOCATION";
	private static final String PROTECTIONSTATUS = "PROTECTIONSTATUS";
	private static final String CARD2PROTECTIONTYPE = "CARD2PROTECTIONTYPE";
	private static final String CARD2SHELFSLOT = "CARD2SHELFSLOT";
	private static final String CARD2RPBUILDTEMPLATE = "CARD2RPBUILDTEMPLATE";
	private static final String ISVISIBLE = "ISVISIBLE";
	private static final String LABEL = "LABEL";
	private static final String RPPLANID = "RPPLANID";
	private static final String ISCOMPLETEINPLAN = "ISCOMPLETEINPLAN";

	private List<Port> cardPorts;
	private List<Slot> cardSlots;
	private List<TTServiceType> ttserviceTypeList=null;
	
	private CardExtension cardExtension=null;
	private CardType cardType=null;

	private Slot parentSlot;

	private Provisionstatus provisionstatus = null;

	public Card()
	{
		super();
		this.tableName = "CARD";
	}

	public Card(String cardId)
	{
		this();
		primaryKey.setValue(cardId);

		getRecordByPrimaryKey();
		this.instanciated = true;
	}

	public static List<Card> getCardListByQuery(String query)
	{
		Card card = new Card();
		List<Card> cardList = new ArrayList<Card>();
		List<Map<String,Object>> foundCardList = card.getFullRecordsByQuery(query);

		for (Map<String,Object> cardMap : foundCardList)
		{
			Card workCard = new Card();
			workCard.instanciated = true;
			workCard.populateFields(cardMap);
			cardList.add(workCard);
		}

		return cardList;
	}

	@Override
	public void populateModel()
	{
		fields.put(CARD2PROVISIONSTATUS, new Field(CARD2PROVISIONSTATUS, Field.TYPE_NUMERIC));
		//Cache the CardType
		//fields.put(CARD2CARDTYPE, new ReferenceField(CARD2CARDTYPE, Field.TYPE_NUMERIC, "CARDTYPE", NAME, "CARDTYPEID"));
		fields.put(CARD2CARDTYPE, new Field(CARD2CARDTYPE, Field.TYPE_NUMERIC));

		fields.put(CARDID, new Field(CARDID, Field.TYPE_NUMERIC));
		fields.put(NAME, new Field(NAME, Field.TYPE_VARCHAR));
		fields.put(FULLNAME, new Field(FULLNAME, Field.TYPE_VARCHAR));
		fields.put(RELATIVENAME, new Field(RELATIVENAME, Field.TYPE_VARCHAR));
		fields.put(ALIAS1, new Field(ALIAS1, Field.TYPE_VARCHAR));
		fields.put(ALIAS2, new Field(ALIAS2, Field.TYPE_VARCHAR));
		fields.put(OBJECTID, new Field(OBJECTID, Field.TYPE_VARCHAR));
		fields.put(SUBTYPE, new Field(SUBTYPE, Field.TYPE_VARCHAR));
		fields.put(SUBSTATUS, new Field(SUBSTATUS, Field.TYPE_VARCHAR));
		fields.put(DESCRIPTION, new Field(DESCRIPTION, Field.TYPE_VARCHAR));
		fields.put(NOTES, new Field(NOTES, Field.TYPE_VARCHAR));
		fields.put(CREATEDDATE, new Field(CREATEDDATE, Field.TYPE_DATE));
		fields.put(LASTMODIFIEDDATE, new Field(LASTMODIFIEDDATE, Field.TYPE_DATE));
		fields.put(CREATEDBY2DIMUSER, new Field(CREATEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(LASTMODIFIEDBY2DIMUSER, new Field(LASTMODIFIEDBY2DIMUSER, Field.TYPE_NUMERIC));
		fields.put(MARKEDFORDELETE, new Field(MARKEDFORDELETE, Field.TYPE_NUMERIC));
		fields.put(INUSE, new Field(INUSE, Field.TYPE_NUMERIC));
		fields.put(CARD2FUNCTIONALSTATUS, new Field(CARD2FUNCTIONALSTATUS, Field.TYPE_NUMERIC));
		fields.put(CARD2NODE, new Field(CARD2NODE, Field.TYPE_NUMERIC));
		fields.put(CARD2LOCATION, new Field(CARD2LOCATION, Field.TYPE_NUMERIC));
		fields.put(PROTECTIONSTATUS, new Field(PROTECTIONSTATUS, Field.TYPE_NUMERIC));
		fields.put(CARD2PROTECTIONTYPE, new Field(CARD2PROTECTIONTYPE, Field.TYPE_NUMERIC));
		fields.put(CARD2SHELFSLOT, new Field(CARD2SHELFSLOT, Field.TYPE_NUMERIC));
		fields.put(CARD2RPBUILDTEMPLATE, new Field(CARD2RPBUILDTEMPLATE, Field.TYPE_NUMERIC));
		fields.put(ISVISIBLE, new Field(ISVISIBLE, Field.TYPE_NUMERIC));
		fields.put(LABEL, new Field(LABEL, Field.TYPE_NUMERIC));
		fields.put(RPPLANID, new Field(RPPLANID, Field.TYPE_NUMERIC));
		fields.put(ISCOMPLETEINPLAN, new Field(ISCOMPLETEINPLAN, Field.TYPE_NUMERIC));

		primaryKey = new PrimaryKey(fields.get(CARDID));

		ComplexLinkedTable clt = new ComplexLinkedTable("CARD", "CARDINSLOT", CARDID, "CARDINSLOT2CARD", true);
		clt.addSubLink("SLOT", "CARDINSLOT2SLOT", "SLOTID", true);
		linkedTables.add(clt);
	}

	public void setCardid(String cardid)
	{
		setField(CARDID,cardid);
	}

	public String getCardid()
	{
		return getFieldAsString(CARDID);
	}

	public void setName(String name)
	{
		setField(NAME,name);
	}

	public String getName()
	{
		return getFieldAsString(NAME);
	}

	public void setFullname(String fullname)
	{
		setField(FULLNAME,fullname);
	}

	public String getFullname()
	{
		return getFieldAsString(FULLNAME);
	}

	public void setRelativename(String relativename)
	{
		setField(RELATIVENAME,relativename);
	}

	public String getRelativename()
	{
		return getFieldAsString(RELATIVENAME);
	}

	public void setAlias1(String alias1)
	{
		setField(ALIAS1,alias1);
	}

	public String getAlias1()
	{
		return getFieldAsString(ALIAS1);
	}

	public void setAlias2(String alias2)
	{
		setField(ALIAS2,alias2);
	}

	public String getAlias2()
	{
		return getFieldAsString(ALIAS2);
	}

	public void setObjectid(String objectid)
	{
		setField(OBJECTID,objectid);
	}

	public String getObjectid()
	{
		return getFieldAsString(OBJECTID);
	}

	public void setSubtype(String subtype)
	{
		setField(SUBTYPE,subtype);
	}

	public String getSubtype()
	{
		return getFieldAsString(SUBTYPE);
	}

	public void setSubstatus(String substatus)
	{
		setField(SUBSTATUS,substatus);
	}

	public String getSubstatus()
	{
		return getFieldAsString(SUBSTATUS);
	}

	public void setCard2cardtype(String card2cardtype)
	{
		setField(CARD2CARDTYPE,card2cardtype);
	}

	public String getCard2cardtype()
	{
		return getFieldAsString(CARD2CARDTYPE);
	}

	public void setDescription(String description)
	{
		setField(DESCRIPTION,description);
	}

	public String getDescription()
	{
		return getFieldAsString(DESCRIPTION);
	}

	public void setNotes(String notes)
	{
		setField(NOTES,notes);
	}

	public String getNotes()
	{
		return getFieldAsString(NOTES);
	}

	public void setCreateddate(String createddate)
	{
		setField(CREATEDDATE,createddate);
	}

	public String getCreateddate()
	{
		return getFieldAsString(CREATEDDATE);
	}

	public void setLastmodifieddate(String lastmodifieddate)
	{
		setField(LASTMODIFIEDDATE,lastmodifieddate);
	}

	public String getLastmodifieddate()
	{
		return getFieldAsString(LASTMODIFIEDDATE);
	}

	public void setCreatedby2dimuser(String createdby2dimuser)
	{
		setField(CREATEDBY2DIMUSER,createdby2dimuser);
	}

	public String getCreatedby2dimuser()
	{
		return getFieldAsString(CREATEDBY2DIMUSER);
	}

	public void setLastmodifiedby2dimuser(String lastmodifiedby2dimuser)
	{
		setField(LASTMODIFIEDBY2DIMUSER,lastmodifiedby2dimuser);
	}

	public String getLastmodifiedby2dimuser()
	{
		return getFieldAsString(LASTMODIFIEDBY2DIMUSER);
	}

	public void setCard2provisionstatus(String card2provisionstatus)
	{
		setField(CARD2PROVISIONSTATUS,card2provisionstatus);
	}

	public String getCard2provisionstatus()
	{
		return getFieldAsString(CARD2PROVISIONSTATUS);
	}

	public void setMarkedfordelete(String markedfordelete)
	{
		setField(MARKEDFORDELETE,markedfordelete);
	}

	public String getMarkedfordelete()
	{
		return getFieldAsString(MARKEDFORDELETE);
	}

	public void setInuse(String inuse)
	{
		setField(INUSE,inuse);
	}

	public String getInuse()
	{
		return getFieldAsString(INUSE);
	}

	public void setCard2functionalstatus(String card2functionalstatus)
	{
		setField(CARD2FUNCTIONALSTATUS,card2functionalstatus);
	}

	public String getCard2functionalstatus()
	{
		return getFieldAsString(CARD2FUNCTIONALSTATUS);
	}

	public void setCard2node(String card2node)
	{
		setField(CARD2NODE,card2node);
	}

	public String getCard2node()
	{
		return getFieldAsString(CARD2NODE);
	}

	public void setCard2location(String card2location)
	{
		setField(CARD2LOCATION,card2location);
	}

	public String getCard2location()
	{
		return getFieldAsString(CARD2LOCATION);
	}

	public void setProtectionstatus(String protectionstatus)
	{
		setField(PROTECTIONSTATUS,protectionstatus);
	}

	public String getProtectionstatus()
	{
		return getFieldAsString(PROTECTIONSTATUS);
	}

	public void setCard2protectiontype(String card2protectiontype)
	{
		setField(CARD2PROTECTIONTYPE,card2protectiontype);
	}

	public String getCard2protectiontype()
	{
		return getFieldAsString(CARD2PROTECTIONTYPE);
	}

	public void setCard2shelfslot(String card2shelfslot)
	{
		setField(CARD2SHELFSLOT,card2shelfslot);
	}

	public String getCard2shelfslot()
	{
		return getFieldAsString(CARD2SHELFSLOT);
	}

	public void setCard2rpbuildtemplate(String card2rpbuildtemplate)
	{
		setField(CARD2RPBUILDTEMPLATE,card2rpbuildtemplate);
	}

	public String getCard2rpbuildtemplate()
	{
		return getFieldAsString(CARD2RPBUILDTEMPLATE);
	}

	public void setIsvisible(String isvisible)
	{
		setField(ISVISIBLE,isvisible);
	}

	public String getIsvisible()
	{
		return getFieldAsString(ISVISIBLE);
	}

	public void setLabel(String label)
	{
		setField(LABEL,label);
	}

	public String getLabel()
	{
		return getFieldAsString(LABEL);
	}

	public void setRpplanid(String rpplanid)
	{
		setField(RPPLANID,rpplanid);
	}

	public String getRpplanid()
	{
		return getFieldAsString(RPPLANID);
	}

	public void setIscompleteinplan(String iscompleteinplan)
	{
		setField(ISCOMPLETEINPLAN,iscompleteinplan);
	}

	public String getIscompleteinplan()
	{
		return getFieldAsString(ISCOMPLETEINPLAN);
	}

	public List<Port> getCardPorts()
	{
		return getCardPorts(null);
	}

	public List<Port> getCardPorts(String additionalConditions)
	{
		if (cardPorts == null)
		{
			String query = "PORT.PORT2CARD = " + fields.get(CARDID).getQueryValue() + " AND PORT.PARENTPORT2PORT IS NULL";
			if (!StringHelper.isEmpty(additionalConditions))
			{
				query += " AND " + additionalConditions;
			}
			cardPorts = Port.getPortListByQuery(query);
		}

		return cardPorts;
	}

	public List<Port> getCardPorts(String additionalConditions,boolean applyPortFilter)
	{
		if (cardPorts == null)
		{
			String query = "PORT.PORT2CARD = " + fields.get(CARDID).getQueryValue() + " AND PORT.PARENTPORT2PORT IS NULL";
			if (!StringHelper.isEmpty(additionalConditions))
			{
				query += " AND " + additionalConditions;
			}

			cardPorts = Port.getPortListByQuery(query,applyPortFilter);


		}

		return cardPorts;
	}

	public List<Slot> getCardSlots()
	{
		if (cardSlots == null)
		{

			cardSlots = Slot.getSlotListByQuery("SLOT.SLOT2CONTAININGCARD = " + fields.get(CARDID).getQueryValue());

		}

		return cardSlots;
	}
	public List<Slot> getCardSlots(String slotNumber)
	{
		if (cardSlots == null)
		{
			if(slotNumber!=null)
			{
				cardSlots = Slot.getSlotListByQuery("SLOT.SLOT2CONTAININGCARD = " + fields.get(CARDID).getQueryValue()+"AND SLOT.SLOTNUMBER="+slotNumber);
			}
			else 
			{
				cardSlots = Slot.getSlotListByQuery("SLOT.SLOT2CONTAININGCARD = " + fields.get(CARDID).getQueryValue());
			}
		}

		return cardSlots;
	}

	public Slot getParentSlot()
	{
		if (parentSlot == null)
		{
			String slotQuery = "CARDINSLOT.CARDINSLOT2CARD = " + fields.get(CARDID).getQueryValue();
			List<Slot> slots = Slot.getSlotListByQuery(slotQuery);
			if (slots.size() > 1)
			{
				throw new ICLException("Data Constraint Error - Card is in more than one slot");
			} else if (slots.size() < 1)
			{
				parentSlot = new Slot();
			} else {
				parentSlot = slots.get(0);
			}
		}

		return parentSlot;
	}

	public Provisionstatus getProvisionstatus()
	{
		if (provisionstatus == null)
		{
			provisionstatus = (Provisionstatus) ValueObjectCacheAccessorFactory.getValueObjectCache("provisionstatus").getCacheObject(getField(CARD2PROVISIONSTATUS).toString());
		}

		return provisionstatus;
	}
	public List<TTServiceType> getTTServiceTypeList()
	{
		if (ttserviceTypeList == null)
		{
			String query = "ARM_OBJECT_ID = " +this.getCard2cardtype() + " AND ARM_OBJECT_TYPE='Card'";

			LOG.info("TTServiceType"+query);

			ttserviceTypeList = TTServiceType.getTTServiceTypeListByQuery(query);
		}

		return ttserviceTypeList;
	}
	
	public CardType getCardtype()
	{
		if (cardType == null)
		{
			cardType = (CardType) ValueObjectCacheAccessorFactory.getValueObjectCache("cardtype").getCacheObject(getField(CARD2CARDTYPE).toString());
		}
		
		return cardType;
	}
	
	public CardExtension getCardExtension()
	{
		if (cardExtension == null)
		{
			cardExtension = new CardExtension(fields.get(CARDID), getCardtype().getTablename());
		}
		
		return cardExtension;
	}
}