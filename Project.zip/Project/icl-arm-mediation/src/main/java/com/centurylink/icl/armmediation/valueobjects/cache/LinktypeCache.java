package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Linktype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class LinktypeCache implements ValueObjectCache {
	
	private Map<String, Linktype> cachedObjects = new HashMap<String, Linktype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Linktype newLinktype = new Linktype(key);
			if (newLinktype.isInstanciated())
			{
				cachedObjects.put(key, newLinktype);
				return newLinktype;
			} else {
				return null;
			}
		}
	}

}
