package com.centurylink.icl.armmediation.armaccessobject;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class ARMEvent {
	
	private BigDecimal armObjectId;
	private String objectAction;
	private Timestamp lastModified;
	private String commonName;
	private String armDimName;
	
	private String associatedARMObjectName;
	private String associatedArmDimName;
	private BigDecimal associatedArmObjectId;
	private String associatedServiceType;
	private String updatedAttribute;
	private String oldValue;
	private String newValue;
	private BigDecimal iclClcSyncId;
	private String resourceSubtype;
	
		
	public static String ADD = "ADD";
	public static String UPDATE = "UPDATE";
	public static String DELETE = "DELETE";
	
	
	public BigDecimal getArmObjectId() {
		return armObjectId;
	}
	public void setArmObjectId(BigDecimal armObjectId) {
		this.armObjectId = armObjectId;
	}
	public String getObjectAction() {
		return objectAction;
	}
	public void setObjectAction(String objectAction) {
		this.objectAction = objectAction;
	}
	public Timestamp getLastModified() {
		return lastModified;
	}
	public void setLastModified(Timestamp lastModified) {
		this.lastModified = lastModified;
	}
	
	public void setCommonName(String commonName)
	{
		this.commonName = commonName;
	}
	
	public String getCommonName()
	{
		return this.commonName;
	}
	
	
	
	public String getUpdatedAttribute() {
		return updatedAttribute;
	}
	public void setUpdatedAttribute(String updatedAttribute) {
		this.updatedAttribute = updatedAttribute;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}

	public BigDecimal getIclClcSyncId() {
		return iclClcSyncId;
	}
	public void setIclClcSyncId(BigDecimal iclClcSyncId) {
		this.iclClcSyncId = iclClcSyncId;
	}
	
	public String getArmDimName() {
		return armDimName;
	}
	public void setArmDimName(String armDimName) {
		this.armDimName = armDimName;
	}
	
	public BigDecimal getAssociatedArmObjectId() {
		return associatedArmObjectId;
	}
	public void setAssociatedArmObjectId(BigDecimal associatedArmObjectId) {
		this.associatedArmObjectId = associatedArmObjectId;
	}
	public String getAssociatedARMObjectName() {
		return associatedARMObjectName;
	}
	public void setAssociatedARMObjectName(String associatedARMObjectName) {
		this.associatedARMObjectName = associatedARMObjectName;
	}
	public String getAssociatedArmDimName() {
		return associatedArmDimName;
	}
	public void setAssociatedArmDimName(String associatedArmDimName) {
		this.associatedArmDimName = associatedArmDimName;
	}
	
	public String getResourceSubtype() {
		return resourceSubtype;
	}
	public void setResourceSubtype(String resourceSubtype) {
		this.resourceSubtype = resourceSubtype;
	}
	public String getAssociatedServiceType() {
		return associatedServiceType;
	}
	public void setAssociatedServiceType(String associatedServiceType) {
		this.associatedServiceType = associatedServiceType;
	}
	
	
	@Override
	public String toString() {
		return "ARMEvent [armObjectId=" + armObjectId + ", objectAction="
				+ objectAction + ", lastModified=" + lastModified
				+ ", commonName=" + commonName + ", armDimName=" + armDimName
				+ ", associatedARMObjectName=" + associatedARMObjectName
				+ ", associatedArmDimName=" + associatedArmDimName
				+ ", associatedArmObjectId=" + associatedArmObjectId
				+ ", associatedServiceType=" + associatedServiceType
				+ ", updatedAttribute=" + updatedAttribute + ", oldValue="
				+ oldValue + ", newValue=" + newValue + ", iclClcSyncId="
				+ iclClcSyncId + ", resourceSubtype=" + resourceSubtype + "]";
	}

	
}
