package com.centurylink.icl.armmediation.valueobjects.cache;

import java.util.HashMap;
import java.util.Map;

import com.centurylink.icl.armmediation.valueobjects.objects.Dimnumbertype;
import com.centurylink.icl.valueobjects.abs.AbstractReadOnlyTable;
import com.centurylink.icl.valueobjects.cached.ValueObjectCache;

public class DimnumbertypeCache implements ValueObjectCache {
	
	private Map<String, Dimnumbertype> cachedObjects = new HashMap<String, Dimnumbertype>();
	
	@Override
	public AbstractReadOnlyTable getCacheObject(String key)
	{
		if (cachedObjects.containsKey(key))
		{
			return cachedObjects.get(key);
		} else {
			Dimnumbertype newDimnumbertype = new Dimnumbertype(key);
			if (newDimnumbertype.isInstanciated())
			{
				cachedObjects.put(key, newDimnumbertype);
				return newDimnumbertype;
			} else {
				return null;
			}
		}
	}

}
