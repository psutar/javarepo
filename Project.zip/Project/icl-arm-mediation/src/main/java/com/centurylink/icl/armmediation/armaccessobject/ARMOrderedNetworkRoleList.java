package com.centurylink.icl.armmediation.armaccessobject;

public class ARMOrderedNetworkRoleList {
	
	private Long orderedNetworkRoleListId;
	private String deviceRole;
	private Long priority;
	
	public Long getOrderedNetworkRoleListId() {
		return orderedNetworkRoleListId;
	}
	public void setOrderedNetworkRoleListId(Long orderedNetworkRoleListId) {
		this.orderedNetworkRoleListId = orderedNetworkRoleListId;
	}
	public String getDeviceRole() {
		return deviceRole;
	}
	public void setDeviceRole(String deviceRole) {
		this.deviceRole = deviceRole;
	}
	public Long getPriority() {
		return priority;
	}
	public void setPriority(Long priority) {
		this.priority = priority;
	}	
}
