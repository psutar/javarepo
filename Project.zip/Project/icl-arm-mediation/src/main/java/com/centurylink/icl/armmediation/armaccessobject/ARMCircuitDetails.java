package com.centurylink.icl.armmediation.armaccessobject;

public class ARMCircuitDetails extends ARMObject {
	// Location
	private String locationName;
	private String locationID;
	private String locationObjectID;
	private String stateOrProvince;
	private String locality;
	private String postcode;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String startLocationName;
	private String startLocationObjectID;
	private String startLocationStateOrProvince;
	private String startLocationLocality;
	private String startLocationPostcode;
	private String startLocationAddressLine1;
	private String startLocationAddressLine2;
	private String startLocationAddressLine3;
	private String endLocationName;
	private String endLocationObjectID;
	private String endLocationStateOrProvince;
	private String endLocationLocality;
	private String endLocationPostcode;
	private String endLocationAddressLine1;
	private String endLocationAddressLine2;
	private String endLocationAddressLine3;
	private String description;
	// Device
	private String deviceName;
	private String deviceFullName;
	private String deviceRelativeName;
	private String deviceId;
	private String deviceObjectId;
	private String clli;
	private String deviceStatus;
	private String deviceFuncStatus;
	private String deviceType;
	private String devicesubType;
	private String deviceConfigType;
	private String mco;
	private String lata;
	private String role;
	private String vendorName;
	private String partType;
	private String ipAddress;
	private String ipAddress1;
	private String relayrackid;
	private String storageRAM;
	private String portFuncT;
	private String pluggableType;
	private String shelfName;
	private String shelfId;
	private String shelfNumber;
	private String slotName;
	private String slotId;
	private String slotNumber;
	private String cardName;
	private String cardId;
	private ARMCard startNodeCards;
	private ARMCard endNodeCards;
	private String portName;
	private String portType;
	private String startPort;
	private String endPort;
	private String portID;
	private String portNumber;
	private String interfaceCategory;
	private String portDpea;
	private String portDpea1;
	private String networkName;
	private String functionalStatus;
	private String ifnum;
	private String pluggableIfNum;
	private String ttServiceType;
	private String networkPortNamePluggable;
	private String transmissionRatePluggable;
	private String networkPortName;
	private String networkPortNumber; 
	private String legacyPortName; 
	private String transmissionRate;
		
	// Circuit
	private String commonName;
	private String objectID;
	private String cktObjectId;
	private String resourceType;
	private String circuitType;
	private String relativeName;
	private String sourceSystem;
	private String cktStatus;
	private String cktProStatus;
	private String cktFuncStatus;
	private String monitoredStatus;
	private String ckt2StartLocation;
	private String ckt2EndLocation;
	private String mdsFlag;
	private String exceptionHandlingText;
	private String moveActivityText;
	private String bandwidth;
	
	private String cktSerType;
	private String ethBearerMCO;
	private String tsp;
	private String isLagMember;
	private String l1Technology;
	private String nmiIsDiverse;
	private String nmiDiverseCktId;
	private String nmiBW;
	// LAG
	private String lagMCO;
	private String protectionType;
	private String lagNumber;
	private String aggregationProtocol;
	private String hashing;
	private String lagIsDiverse;
	private String lagDiverseCktId;
	private String lagBW;
	// Service
	private String serviceName;
	private String serviceID;
	private String serviceType;
	private String serviceStatus;
	private String serviceProStatus;
	private String serviceFuncStatus;
	private String serviceObject2object;
	private String hpcExpDate;
	private String hpc;
	private String vlanPortId;
	// UNI
	private String ban;
	private String serviceMux;
	private String bundling;
	private String allToOneBundling;
	private String maxNumEvcs;
	private String customerSrNo;
	private String diverseUniId;
	private String uniMCO;
	private String uniSpecCode;
	private String uniNCCode;
	private String uniNCICode;
	private String uniSecNCICode;
	private String uniBW;
	private String uniIsDiverse;
	private String uniCktSrNo;
	private String uniCktId;
	private String uniTSP;
	// ENNI
	private String frameFormat;
	private String maxNumOvcs;
	private String maxNumOvcEndpointsPerOvc;
	private String enniMCO;
	private String enniSpecCode;
	private String enniNCCode;
	private String enniNCICode;
	private String enniSecNCICode;
	private String enniBW;
	private String enniCktSrNo;
	private String enniCktId;
	private String enniTSP;
	// EVC
	private String evcMtu;
	private String maximumUnis;
	private String evcMCO;
	private String evcServiceSubType;
	private String evcNc;
	private String evcCeVlanIdPreservation;
	private String evcCeVlanCosPreservation;
	private String evcUnicastFrameDelivery;
	private String evcMulticastFrameDelivery;
	private String evcBroadcastFrameDelivery;
	private String evcEvcOvcNc;
	private String evcCosId;
	private String evcCktSrNo;
	private String evcLosName;
	private String evcCosValue;
	private String asn;
	private String vpnId;
	// OVC
	private String maxNumUniOvcEndpoints;
	private String maxNumEnnniOvcEndpoints;
	private String ovcMtu;
	private String sVlanIdPreservation;
	private String sVlanCosPreservation;
	private String colorForwarding;
	private String evcOvcReference;
	private String ovcMCO;
	private String ovcServiceSubType;
	private String ovcNc;
	private String ovcCeVlanIdPreservation;
	private String ovcCeVlanCosPreservation;
	private String ovcUnicastFrameDelivery;
	private String ovcMulticastFrameDelivery;
	private String ovcBroadcastFrameDelivery;
	private String ovcEvcOvcNc;
	private String ovcCosId;
	private String ovcLosName;
	private String ovcCosValue;
	private String ovcCktSrNo;
	// Subscriber
	private String subscriberName;
	private String subscriberID;
	private String subscriberObjectId;
	private String subscriberFullName;
	private String subscriberFirstName;
	private String subscriberLastName;

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getLocationID() {
		return locationID;
	}

	public void setLocationID(String locationID) {
		this.locationID = locationID;
	}

	public String getLocationObjectID() {
		return locationObjectID;
	}

	public void setLocationObjectID(String locationObjectID) {
		this.locationObjectID = locationObjectID;
	}

	public String getStateOrProvince() {
		return stateOrProvince;
	}

	public void setStateOrProvince(String stateOrProvince) {
		this.stateOrProvince = stateOrProvince;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getStartLocationName() {
		return startLocationName;
	}

	public void setStartLocationName(String startLocationName) {
		this.startLocationName = startLocationName;
	}

	public String getStartLocationObjectID() {
		return startLocationObjectID;
	}

	public void setStartLocationObjectID(String startLocationObjectID) {
		this.startLocationObjectID = startLocationObjectID;
	}

	public String getStartLocationStateOrProvince() {
		return startLocationStateOrProvince;
	}

	public void setStartLocationStateOrProvince(
			String startLocationStateOrProvince) {
		this.startLocationStateOrProvince = startLocationStateOrProvince;
	}

	public String getStartLocationLocality() {
		return startLocationLocality;
	}

	public void setStartLocationLocality(String startLocationLocality) {
		this.startLocationLocality = startLocationLocality;
	}

	public String getStartLocationPostcode() {
		return startLocationPostcode;
	}

	public void setStartLocationPostcode(String startLocationPostcode) {
		this.startLocationPostcode = startLocationPostcode;
	}

	public String getStartLocationAddressLine1() {
		return startLocationAddressLine1;
	}

	public void setStartLocationAddressLine1(String startLocationAddressLine1) {
		this.startLocationAddressLine1 = startLocationAddressLine1;
	}

	public String getStartLocationAddressLine2() {
		return startLocationAddressLine2;
	}

	public void setStartLocationAddressLine2(String startLocationAddressLine2) {
		this.startLocationAddressLine2 = startLocationAddressLine2;
	}

	public String getStartLocationAddressLine3() {
		return startLocationAddressLine3;
	}

	public void setStartLocationAddressLine3(String startLocationAddressLine3) {
		this.startLocationAddressLine3 = startLocationAddressLine3;
	}

	public String getEndLocationName() {
		return endLocationName;
	}

	public void setEndLocationName(String endLocationName) {
		this.endLocationName = endLocationName;
	}

	public String getEndLocationObjectID() {
		return endLocationObjectID;
	}

	public void setEndLocationObjectID(String endLocationObjectID) {
		this.endLocationObjectID = endLocationObjectID;
	}

	public String getEndLocationStateOrProvince() {
		return endLocationStateOrProvince;
	}

	public void setEndLocationStateOrProvince(String endLocationStateOrProvince) {
		this.endLocationStateOrProvince = endLocationStateOrProvince;
	}

	public String getEndLocationLocality() {
		return endLocationLocality;
	}

	public void setEndLocationLocality(String endLocationLocality) {
		this.endLocationLocality = endLocationLocality;
	}

	public String getEndLocationPostcode() {
		return endLocationPostcode;
	}

	public void setEndLocationPostcode(String endLocationPostcode) {
		this.endLocationPostcode = endLocationPostcode;
	}

	public String getEndLocationAddressLine1() {
		return endLocationAddressLine1;
	}

	public void setEndLocationAddressLine1(String endLocationAddressLine1) {
		this.endLocationAddressLine1 = endLocationAddressLine1;
	}

	public String getEndLocationAddressLine2() {
		return endLocationAddressLine2;
	}

	public void setEndLocationAddressLine2(String endLocationAddressLine2) {
		this.endLocationAddressLine2 = endLocationAddressLine2;
	}

	public String getEndLocationAddressLine3() {
		return endLocationAddressLine3;
	}

	public void setEndLocationAddressLine3(String endLocationAddressLine3) {
		this.endLocationAddressLine3 = endLocationAddressLine3;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDeviceFullName() {
		return deviceFullName;
	}

	public void setDeviceFullName(String deviceFullName) {
		this.deviceFullName = deviceFullName;
	}

	public String getDeviceRelativeName() {
		return deviceRelativeName;
	}

	public void setDeviceRelativeName(String deviceRelativeName) {
		this.deviceRelativeName = deviceRelativeName;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceObjectId() {
		return deviceObjectId;
	}

	public void setDeviceObjectId(String deviceObjectId) {
		this.deviceObjectId = deviceObjectId;
	}

	public String getClli() {
		return clli;
	}

	public void setClli(String clli) {
		this.clli = clli;
	}

	public String getDeviceStatus() {
		return deviceStatus;
	}

	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

	public String getDeviceFuncStatus() {
		return deviceFuncStatus;
	}

	public void setDeviceFuncStatus(String deviceFuncStatus) {
		this.deviceFuncStatus = deviceFuncStatus;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDevicesubType() {
		return devicesubType;
	}

	public void setDevicesubType(String devicesubType) {
		this.devicesubType = devicesubType;
	}

	public String getDeviceConfigType() {
		return deviceConfigType;
	}

	public void setDeviceConfigType(String deviceConfigType) {
		this.deviceConfigType = deviceConfigType;
	}

	public String getMco() {
		return mco;
	}

	public void setMco(String mco) {
		this.mco = mco;
	}

	public String getLata() {
		return lata;
	}

	public void setLata(String lata) {
		this.lata = lata;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getIpAddress1() {
		return ipAddress1;
	}

	public void setIpAddress1(String ipAddress1) {
		this.ipAddress1 = ipAddress1;
	}

	public String getRelayrackid() {
		return relayrackid;
	}

	public void setRelayrackid(String relayrackid) {
		this.relayrackid = relayrackid;
	}

	public String getStorageRAM() {
		return storageRAM;
	}

	public void setStorageRAM(String storageRAM) {
		this.storageRAM = storageRAM;
	}

	public String getPortFuncT() {
		return portFuncT;
	}

	public void setPortFuncT(String portFuncT) {
		this.portFuncT = portFuncT;
	}

	public String getPluggableType() {
		return pluggableType;
	}

	public void setPluggableType(String pluggableType) {
		this.pluggableType = pluggableType;
	}

	public String getShelfName() {
		return shelfName;
	}

	public void setShelfName(String shelfName) {
		this.shelfName = shelfName;
	}

	public String getShelfId() {
		return shelfId;
	}

	public void setShelfId(String shelfId) {
		this.shelfId = shelfId;
	}
	
	public String getShelfNumber() {
	  return shelfNumber;
	}

	public void setShelfNumber(String shelfNumber) {
	  this.shelfNumber = shelfNumber;
	}

	public String getSlotName() {
		return slotName;
	}

	public void setSlotName(String slotName) {
		this.slotName = slotName;
	}

	public String getSlotId() {
		return slotId;
	}

	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public ARMCard getStartNodeCards() {
		return startNodeCards;
	}

	public void setStartNodeCards(ARMCard startNodeCards) {
		this.startNodeCards = startNodeCards;
	}

	public ARMCard getEndNodeCards() {
		return endNodeCards;
	}

	public void setEndNodeCards(ARMCard endNodeCards) {
		this.endNodeCards = endNodeCards;
	}

	public String getPortName() {
		return portName;
	}

	public void setPortName(String portName) {
		this.portName = portName;
	}

	public String getPortType() {
		return portType;
	}

	public void setPortType(String portType) {
		this.portType = portType;
	}

	public String getStartPort() {
		return startPort;
	}

	public void setStartPort(String startPort) {
		this.startPort = startPort;
	}

	public String getEndPort() {
		return endPort;
	}

	public void setEndPort(String endPort) {
		this.endPort = endPort;
	}

	public String getPortID() {
		return portID;
	}

	public void setPortID(String portID) {
		this.portID = portID;
	}
	
	public String getPortNumber() {
	  return portNumber;
	}

	public void setPortNumber(String portNumber) {
	  this.portNumber = portNumber;
	}

	public String getInterfaceCategory() {
		return interfaceCategory;
	}

	public void setInterfaceCategory(String interfaceCategory) {
		this.interfaceCategory = interfaceCategory;
	}

	public String getPortDpea() {
		return portDpea;
	}

	public void setPortDpea(String portDpea) {
		this.portDpea = portDpea;
	}

	public String getPortDpea1() {
		return portDpea1;
	}

	public void setPortDpea1(String portDpea1) {
		this.portDpea1 = portDpea1;
	}

	public String getCommonName() {
		return commonName;
	}

	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}

	public String getObjectID() {
		return objectID;
	}

	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}

	public String getCktObjectId() {
		return cktObjectId;
	}

	public void setCktObjectId(String cktObjectId) {
		this.cktObjectId = cktObjectId;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getCircuitType() {
		return circuitType;
	}

	public void setCircuitType(String circuitType) {
		this.circuitType = circuitType;
	}

	public String getRelativeName() {
		return relativeName;
	}

	public void setRelativeName(String relativeName) {
		this.relativeName = relativeName;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getCktStatus() {
		return cktStatus;
	}

	public void setCktStatus(String cktStatus) {
		this.cktStatus = cktStatus;
	}

	public String getCktProStatus() {
		return cktProStatus;
	}

	public void setCktProStatus(String cktProStatus) {
		this.cktProStatus = cktProStatus;
	}

	public String getCktFuncStatus() {
		return cktFuncStatus;
	}

	public void setCktFuncStatus(String cktFuncStatus) {
		this.cktFuncStatus = cktFuncStatus;
	}

	public String getMonitoredStatus() {
		return monitoredStatus;
	}

	public void setMonitoredStatus(String monitoredStatus) {
		this.monitoredStatus = monitoredStatus;
	}

	public String getCkt2StartLocation() {
		return ckt2StartLocation;
	}

	public void setCkt2StartLocation(String ckt2StartLocation) {
		this.ckt2StartLocation = ckt2StartLocation;
	}

	public String getCkt2EndLocation() {
		return ckt2EndLocation;
	}

	public void setCkt2EndLocation(String ckt2EndLocation) {
		this.ckt2EndLocation = ckt2EndLocation;
	}

	public String getMdsFlag() {
		return mdsFlag;
	}

	public void setMdsFlag(String mdsFlag) {
		this.mdsFlag = mdsFlag;
	}

	public String getExceptionHandlingText() {
		return exceptionHandlingText;
	}

	public void setExceptionHandlingText(String exceptionHandlingText) {
		this.exceptionHandlingText = exceptionHandlingText;
	}

	public String getMoveActivityText() {
		return moveActivityText;
	}

	public void setMoveActivityText(String moveActivityText) {
		this.moveActivityText = moveActivityText;
	}

	public String getCktSerType() {
		return cktSerType;
	}

	public void setCktSerType(String cktSerType) {
		this.cktSerType = cktSerType;
	}

	public String getEthBearerMCO() {
		return ethBearerMCO;
	}

	public void setEthBearerMCO(String ethBearerMCO) {
		this.ethBearerMCO = ethBearerMCO;
	}

	public String getTsp() {
		return tsp;
	}

	public void setTsp(String tsp) {
		this.tsp = tsp;
	}

	public String getIsLagMember() {
		return isLagMember;
	}

	public void setIsLagMember(String isLagMember) {
		this.isLagMember = isLagMember;
	}

	public String getL1Technology() {
		return l1Technology;
	}

	public void setL1Technology(String l1Technology) {
		this.l1Technology = l1Technology;
	}

	public String getNmiIsDiverse() {
		return nmiIsDiverse;
	}

	public void setNmiIsDiverse(String nmiIsDiverse) {
		this.nmiIsDiverse = nmiIsDiverse;
	}

	public String getNmiDiverseCktId() {
		return nmiDiverseCktId;
	}

	public void setNmiDiverseCktId(String nmiDiverseCktId) {
		this.nmiDiverseCktId = nmiDiverseCktId;
	}

	public String getNmiBW() {
		return nmiBW;
	}

	public void setNmiBW(String nmiBW) {
		this.nmiBW = nmiBW;
	}

	public String getLagMCO() {
		return lagMCO;
	}

	public void setLagMCO(String lagMCO) {
		this.lagMCO = lagMCO;
	}

	public String getProtectionType() {
		return protectionType;
	}

	public void setProtectionType(String protectionType) {
		this.protectionType = protectionType;
	}

	public String getLagNumber() {
		return lagNumber;
	}

	public void setLagNumber(String lagNumber) {
		this.lagNumber = lagNumber;
	}

	public String getAggregationProtocol() {
		return aggregationProtocol;
	}

	public void setAggregationProtocol(String aggregationProtocol) {
		this.aggregationProtocol = aggregationProtocol;
	}

	public String getHashing() {
		return hashing;
	}

	public void setHashing(String hashing) {
		this.hashing = hashing;
	}

	public String getLagIsDiverse() {
		return lagIsDiverse;
	}

	public void setLagIsDiverse(String lagIsDiverse) {
		this.lagIsDiverse = lagIsDiverse;
	}

	public String getLagDiverseCktId() {
		return lagDiverseCktId;
	}

	public void setLagDiverseCktId(String lagDiverseCktId) {
		this.lagDiverseCktId = lagDiverseCktId;
	}

	public String getLagBW() {
		return lagBW;
	}

	public void setLagBW(String lagBW) {
		this.lagBW = lagBW;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceID() {
		return serviceID;
	}

	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public String getServiceProStatus() {
		return serviceProStatus;
	}

	public void setServiceProStatus(String serviceProStatus) {
		this.serviceProStatus = serviceProStatus;
	}

	public String getServiceFuncStatus() {
		return serviceFuncStatus;
	}

	public void setServiceFuncStatus(String serviceFuncStatus) {
		this.serviceFuncStatus = serviceFuncStatus;
	}

	public String getServiceObject2object() {
		return serviceObject2object;
	}

	public void setServiceObject2object(String serviceObject2object) {
		this.serviceObject2object = serviceObject2object;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getServiceMux() {
		return serviceMux;
	}

	public void setServiceMux(String serviceMux) {
		this.serviceMux = serviceMux;
	}

	public String getBundling() {
		return bundling;
	}

	public void setBundling(String bundling) {
		this.bundling = bundling;
	}

	public String getAllToOneBundling() {
		return allToOneBundling;
	}

	public void setAllToOneBundling(String allToOneBundling) {
		this.allToOneBundling = allToOneBundling;
	}

	public String getMaxNumEvcs() {
		return maxNumEvcs;
	}

	public void setMaxNumEvcs(String maxNumEvcs) {
		this.maxNumEvcs = maxNumEvcs;
	}

	public String getCustomerSrNo() {
		return customerSrNo;
	}

	public void setCustomerSrNo(String customerSrNo) {
		this.customerSrNo = customerSrNo;
	}

	public String getDiverseUniId() {
		return diverseUniId;
	}

	public void setDiverseUniId(String diverseUniId) {
		this.diverseUniId = diverseUniId;
	}

	public String getUniMCO() {
		return uniMCO;
	}

	public void setUniMCO(String uniMCO) {
		this.uniMCO = uniMCO;
	}

	public String getUniSpecCode() {
		return uniSpecCode;
	}

	public void setUniSpecCode(String uniSpecCode) {
		this.uniSpecCode = uniSpecCode;
	}

	public String getUniNCCode() {
		return uniNCCode;
	}

	public void setUniNCCode(String uniNCCode) {
		this.uniNCCode = uniNCCode;
	}

	public String getUniNCICode() {
		return uniNCICode;
	}

	public void setUniNCICode(String uniNCICode) {
		this.uniNCICode = uniNCICode;
	}

	public String getUniSecNCICode() {
		return uniSecNCICode;
	}

	public void setUniSecNCICode(String uniSecNCICode) {
		this.uniSecNCICode = uniSecNCICode;
	}

	public String getUniBW() {
		return uniBW;
	}

	public void setUniBW(String uniBW) {
		this.uniBW = uniBW;
	}

	public String getUniIsDiverse() {
		return uniIsDiverse;
	}

	public void setUniIsDiverse(String uniIsDiverse) {
		this.uniIsDiverse = uniIsDiverse;
	}

	public String getUniCktSrNo() {
		return uniCktSrNo;
	}

	public void setUniCktSrNo(String uniCktSrNo) {
		this.uniCktSrNo = uniCktSrNo;
	}

	public String getUniCktId() {
		return uniCktId;
	}

	public void setUniCktId(String uniCktId) {
		this.uniCktId = uniCktId;
	}

	public String getFrameFormat() {
		return frameFormat;
	}

	public void setFrameFormat(String frameFormat) {
		this.frameFormat = frameFormat;
	}

	public String getMaxNumOvcs() {
		return maxNumOvcs;
	}

	public void setMaxNumOvcs(String maxNumOvcs) {
		this.maxNumOvcs = maxNumOvcs;
	}

	public String getMaxNumOvcEndpointsPerOvc() {
		return maxNumOvcEndpointsPerOvc;
	}

	public void setMaxNumOvcEndpointsPerOvc(String maxNumOvcEndpointsPerOvc) {
		this.maxNumOvcEndpointsPerOvc = maxNumOvcEndpointsPerOvc;
	}

	public String getEnniMCO() {
		return enniMCO;
	}

	public void setEnniMCO(String enniMCO) {
		this.enniMCO = enniMCO;
	}

	public String getEnniSpecCode() {
		return enniSpecCode;
	}

	public void setEnniSpecCode(String enniSpecCode) {
		this.enniSpecCode = enniSpecCode;
	}

	public String getEnniNCCode() {
		return enniNCCode;
	}

	public void setEnniNCCode(String enniNCCode) {
		this.enniNCCode = enniNCCode;
	}

	public String getEnniNCICode() {
		return enniNCICode;
	}

	public void setEnniNCICode(String enniNCICode) {
		this.enniNCICode = enniNCICode;
	}

	public String getEnniSecNCICode() {
		return enniSecNCICode;
	}

	public void setEnniSecNCICode(String enniSecNCICode) {
		this.enniSecNCICode = enniSecNCICode;
	}

	public String getEnniBW() {
		return enniBW;
	}

	public void setEnniBW(String enniBW) {
		this.enniBW = enniBW;
	}

	public String getEnniCktSrNo() {
		return enniCktSrNo;
	}

	public void setEnniCktSrNo(String enniCktSrNo) {
		this.enniCktSrNo = enniCktSrNo;
	}

	public String getEnniCktId() {
		return enniCktId;
	}

	public void setEnniCktId(String enniCktId) {
		this.enniCktId = enniCktId;
	}

	public String getEvcMtu() {
		return evcMtu;
	}

	public void setEvcMtu(String evcMtu) {
		this.evcMtu = evcMtu;
	}

	public String getMaximumUnis() {
		return maximumUnis;
	}

	public void setMaximumUnis(String maximumUnis) {
		this.maximumUnis = maximumUnis;
	}

	public String getEvcMCO() {
		return evcMCO;
	}

	public void setEvcMCO(String evcMCO) {
		this.evcMCO = evcMCO;
	}

	public String getEvcServiceSubType() {
		return evcServiceSubType;
	}

	public void setEvcServiceSubType(String evcServiceSubType) {
		this.evcServiceSubType = evcServiceSubType;
	}

	public String getEvcNc() {
		return evcNc;
	}

	public void setEvcNc(String evcNc) {
		this.evcNc = evcNc;
	}

	public String getEvcCeVlanIdPreservation() {
		return evcCeVlanIdPreservation;
	}

	public void setEvcCeVlanIdPreservation(String evcCeVlanIdPreservation) {
		this.evcCeVlanIdPreservation = evcCeVlanIdPreservation;
	}

	public String getEvcCeVlanCosPreservation() {
		return evcCeVlanCosPreservation;
	}

	public void setEvcCeVlanCosPreservation(String evcCeVlanCosPreservation) {
		this.evcCeVlanCosPreservation = evcCeVlanCosPreservation;
	}

	public String getEvcUnicastFrameDelivery() {
		return evcUnicastFrameDelivery;
	}

	public void setEvcUnicastFrameDelivery(String evcUnicastFrameDelivery) {
		this.evcUnicastFrameDelivery = evcUnicastFrameDelivery;
	}

	public String getEvcMulticastFrameDelivery() {
		return evcMulticastFrameDelivery;
	}

	public void setEvcMulticastFrameDelivery(String evcMulticastFrameDelivery) {
		this.evcMulticastFrameDelivery = evcMulticastFrameDelivery;
	}

	public String getEvcBroadcastFrameDelivery() {
		return evcBroadcastFrameDelivery;
	}

	public void setEvcBroadcastFrameDelivery(String evcBroadcastFrameDelivery) {
		this.evcBroadcastFrameDelivery = evcBroadcastFrameDelivery;
	}

	public String getEvcEvcOvcNc() {
		return evcEvcOvcNc;
	}

	public void setEvcEvcOvcNc(String evcEvcOvcNc) {
		this.evcEvcOvcNc = evcEvcOvcNc;
	}

	public String getEvcCosId() {
		return evcCosId;
	}

	public void setEvcCosId(String evcCosId) {
		this.evcCosId = evcCosId;
	}

	public String getEvcCktSrNo() {
		return evcCktSrNo;
	}

	public void setEvcCktSrNo(String evcCktSrNo) {
		this.evcCktSrNo = evcCktSrNo;
	}

	public String getEvcLosName() {
		return evcLosName;
	}

	public void setEvcLosName(String evcLosName) {
		this.evcLosName = evcLosName;
	}

	public String getEvcCosValue() {
		return evcCosValue;
	}

	public void setEvcCosValue(String evcCosValue) {
		this.evcCosValue = evcCosValue;
	}

	public String getMaxNumUniOvcEndpoints() {
		return maxNumUniOvcEndpoints;
	}

	public void setMaxNumUniOvcEndpoints(String maxNumUniOvcEndpoints) {
		this.maxNumUniOvcEndpoints = maxNumUniOvcEndpoints;
	}

	public String getMaxNumEnnniOvcEndpoints() {
		return maxNumEnnniOvcEndpoints;
	}

	public void setMaxNumEnnniOvcEndpoints(String maxNumEnnniOvcEndpoints) {
		this.maxNumEnnniOvcEndpoints = maxNumEnnniOvcEndpoints;
	}

	public String getOvcMtu() {
		return ovcMtu;
	}

	public void setOvcMtu(String ovcMtu) {
		this.ovcMtu = ovcMtu;
	}

	public String getsVlanIdPreservation() {
		return sVlanIdPreservation;
	}

	public void setsVlanIdPreservation(String sVlanIdPreservation) {
		this.sVlanIdPreservation = sVlanIdPreservation;
	}

	public String getsVlanCosPreservation() {
		return sVlanCosPreservation;
	}

	public void setsVlanCosPreservation(String sVlanCosPreservation) {
		this.sVlanCosPreservation = sVlanCosPreservation;
	}

	public String getColorForwarding() {
		return colorForwarding;
	}

	public void setColorForwarding(String colorForwarding) {
		this.colorForwarding = colorForwarding;
	}

	public String getEvcOvcReference() {
		return evcOvcReference;
	}

	public void setEvcOvcReference(String evcOvcReference) {
		this.evcOvcReference = evcOvcReference;
	}

	public String getOvcMCO() {
		return ovcMCO;
	}

	public void setOvcMCO(String ovcMCO) {
		this.ovcMCO = ovcMCO;
	}

	public String getOvcServiceSubType() {
		return ovcServiceSubType;
	}

	public void setOvcServiceSubType(String ovcServiceSubType) {
		this.ovcServiceSubType = ovcServiceSubType;
	}

	public String getOvcNc() {
		return ovcNc;
	}

	public void setOvcNc(String ovcNc) {
		this.ovcNc = ovcNc;
	}

	public String getOvcCeVlanIdPreservation() {
		return ovcCeVlanIdPreservation;
	}

	public void setOvcCeVlanIdPreservation(String ovcCeVlanIdPreservation) {
		this.ovcCeVlanIdPreservation = ovcCeVlanIdPreservation;
	}

	public String getOvcCeVlanCosPreservation() {
		return ovcCeVlanCosPreservation;
	}

	public void setOvcCeVlanCosPreservation(String ovcCeVlanCosPreservation) {
		this.ovcCeVlanCosPreservation = ovcCeVlanCosPreservation;
	}

	public String getOvcUnicastFrameDelivery() {
		return ovcUnicastFrameDelivery;
	}

	public void setOvcUnicastFrameDelivery(String ovcUnicastFrameDelivery) {
		this.ovcUnicastFrameDelivery = ovcUnicastFrameDelivery;
	}

	public String getOvcMulticastFrameDelivery() {
		return ovcMulticastFrameDelivery;
	}

	public void setOvcMulticastFrameDelivery(String ovcMulticastFrameDelivery) {
		this.ovcMulticastFrameDelivery = ovcMulticastFrameDelivery;
	}

	public String getOvcBroadcastFrameDelivery() {
		return ovcBroadcastFrameDelivery;
	}

	public void setOvcBroadcastFrameDelivery(String ovcBroadcastFrameDelivery) {
		this.ovcBroadcastFrameDelivery = ovcBroadcastFrameDelivery;
	}

	public String getOvcEvcOvcNc() {
		return ovcEvcOvcNc;
	}

	public void setOvcEvcOvcNc(String ovcEvcOvcNc) {
		this.ovcEvcOvcNc = ovcEvcOvcNc;
	}

	public String getOvcCosId() {
		return ovcCosId;
	}

	public void setOvcCosId(String ovcCosId) {
		this.ovcCosId = ovcCosId;
	}

	public String getOvcLosName() {
		return ovcLosName;
	}

	public void setOvcLosName(String ovcLosName) {
		this.ovcLosName = ovcLosName;
	}

	public String getOvcCosValue() {
		return ovcCosValue;
	}

	public void setOvcCosValue(String ovcCosValue) {
		this.ovcCosValue = ovcCosValue;
	}

	public String getOvcCktSrNo() {
		return ovcCktSrNo;
	}

	public void setOvcCktSrNo(String ovcCktSrNo) {
		this.ovcCktSrNo = ovcCktSrNo;
	}

	public String getSubscriberName() {
		return subscriberName;
	}

	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}

	public String getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getSubscriberObjectId() {
		return subscriberObjectId;
	}

	public void setSubscriberObjectId(String subscriberObjectId) {
		this.subscriberObjectId = subscriberObjectId;
	}

	public String getSubscriberFullName() {
		return subscriberFullName;
	}

	public void setSubscriberFullName(String subscriberFullName) {
		this.subscriberFullName = subscriberFullName;
	}

	public String getSubscriberFirstName() {
		return subscriberFirstName;
	}

	public void setSubscriberFirstName(String subscriberFirstName) {
		this.subscriberFirstName = subscriberFirstName;
	}

	public String getSubscriberLastName() {
		return subscriberLastName;
	}

	public String getSlotNumber() {
		return slotNumber;
	}

	public void setSlotNumber(String slotNumber) {
		this.slotNumber = slotNumber;
	}

	public void setSubscriberLastName(String subscriberLastName) {
		this.subscriberLastName = subscriberLastName;
	}

	public String getHpcExpDate() {
		return hpcExpDate;
	}

	public void setHpcExpDate(String hpcExpDate) {
		this.hpcExpDate = hpcExpDate;
	}

	public String getHpc() {
		return this.hpc;
	}

	public void setHpc(String hpc) {
		this.hpc = hpc;
	}

	public String getVlanPortId() {
		return vlanPortId;
	}

	public void setVlanPortId(String vlanPortId) {
		this.vlanPortId = vlanPortId;
	}

	public String getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(String bandwidth) {
		this.bandwidth = bandwidth;
	}

	public String getUniTSP() {
		return uniTSP;
	}

	public void setUniTSP(String uniTSP) {
		this.uniTSP = uniTSP;
	}

	public String getEnniTSP() {
		return enniTSP;
	}

	public void setEnniTSP(String enniTSP) {
		this.enniTSP = enniTSP;
	}
	public String getAsn() {
		return asn;
	}

	public void setAsn(String asn) {
		this.asn = asn;
	}

	public String getVpnId() {
		return vpnId;
	}

	public void setVpnId(String vpnId) {
		this.vpnId = vpnId;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public String getFunctionalStatus() {
		return functionalStatus;
	}

	public void setFunctionalStatus(String functionalStatus) {
		this.functionalStatus = functionalStatus;
	}

	public String getIfnum() {
		return ifnum;
	}

	public void setIfnum(String ifnum) {
		this.ifnum = ifnum;
	}

	public String getTtServiceType() {
		return ttServiceType;
	}

	public void setTtServiceType(String ttServiceType) {
		this.ttServiceType = ttServiceType;
	}

	public String getPluggableIfNum() {
		return pluggableIfNum;
	}

	public void setPluggableIfNum(String pluggableIfNum) {
		this.pluggableIfNum = pluggableIfNum;
	}

	public String getNetworkPortNamePluggable() {
		return networkPortNamePluggable;
	}

	public void setNetworkPortNamePluggable(String networkPortNamePluggable) {
		this.networkPortNamePluggable = networkPortNamePluggable;
	}

	public String getTransmissionRatePluggable() {
		return transmissionRatePluggable;
	}

	public void setTransmissionRatePluggable(String transmissionRatePluggable) {
		this.transmissionRatePluggable = transmissionRatePluggable;
	}
	
	public String getNetworkPortName() {
		return networkPortName;
	}

	public void setNetworkPortName(String networkPortName) {
		this.networkPortName = networkPortName;
	}

	public String getNetworkPortNumber() {
		return networkPortNumber;
	}

	public void setNetworkPortNumber(String networkPortNumber) {
		this.networkPortNumber = networkPortNumber;
	}

	public String getLegacyPortName() {
		return legacyPortName;
	}

	public void setLegacyPortName(String legacyPortName) {
		this.legacyPortName = legacyPortName;
	}

	public String getTransmissionRate() {
		return transmissionRate;
	}

	public void setTransmissionRate(String transmissionRate) {
		this.transmissionRate = transmissionRate;
	}

}
