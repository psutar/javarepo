package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.predicates.IsArmImpactedCircuitForDeviceRequest;

public class ARMCircuitSummaryServiceRoute extends RouteBuilder{
	
	
	@Override
	public void configure() throws Exception
	{
		from("direct:armCircuitSummaryServiceRoute")
		 .routeId("armCircuitSummaryServiceRoute")
		 .choice()		    		    
		 	.when(new IsArmImpactedCircuitForDeviceRequest())
		 		.to("direct:armNtmDeviceWithAffectedCircuitRoute")
		 	.otherwise()
		 		.to("direct:armCircuitSummaryRoute")
	    .end();			
	}

}
