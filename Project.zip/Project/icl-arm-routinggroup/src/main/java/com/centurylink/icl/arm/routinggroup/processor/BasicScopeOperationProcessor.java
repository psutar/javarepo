package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class BasicScopeOperationProcessor implements Processor
{
	final ProducerTemplate producerTemplate;
	
	public BasicScopeOperationProcessor(CamelContext ctx)
	{
		this.producerTemplate = ctx.createProducerTemplate();	
	}

	@Override
	public void process(Exchange exchg) throws Exception 
	{
		SearchResourceRequestDocument in = (SearchResourceRequestDocument)exchg
											.getIn().getBody();
		List<ResourceCharacteristicValue> rcvList = in.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		boolean entityTypeFound = false;
		String entityType = null;
		boolean ccnaFound = false;
		boolean circuitIDFound = false;
		boolean returnRelatedCircuitsFound = false;		
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName()
					.equalsIgnoreCase(ARMRoutingConstants.ENTITY_TYPE) == true)
			{
				entityTypeFound = true;
				entityType = rcv.getCharacteristicValue();
			}
			
			else if(rcv.getCharacteristicName()
					.equalsIgnoreCase(ARMRoutingConstants.CCNA) == true )
				ccnaFound = true;
			
			else if(rcv.getCharacteristicName()
					.equalsIgnoreCase(ARMRoutingConstants.CIRCUITID) == true)
				circuitIDFound = true;	
			
			else if(rcv.getCharacteristicName()
					.equalsIgnoreCase(ARMRoutingConstants.RETURNRELATEDCIRCUITS) == true)
				returnRelatedCircuitsFound = true;		
			
		}
		
		if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.EVC))
			this.producerTemplate.send("direct:ValidateEVCECCKTRoute",exchg);
		else if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.VLAN))
			this.producerTemplate.send("direct:ValidateVLANRoute",exchg);
		else if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.UNI))
			this.producerTemplate.send("direct:ValidateECCKTNotInRUIDRoute",exchg);
		else if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.LAG)
				&& ccnaFound)
			this.producerTemplate.send("direct:ValidateLAGIdRoute",exchg);	
		else if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.LAG)
				&& returnRelatedCircuitsFound)
			this.producerTemplate.send("direct:ValidateLAGExistsRoute",exchg);
		else 
			if(entityTypeFound && entityType.equalsIgnoreCase(ARMRoutingConstants.LAG)
				&& circuitIDFound)
			this.producerTemplate.send("direct:ValidateCircuitPartOfLAGRoute",exchg);
		
	}

}
