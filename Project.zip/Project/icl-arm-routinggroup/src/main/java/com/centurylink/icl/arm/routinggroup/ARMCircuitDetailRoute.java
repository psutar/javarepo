package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.predicates.IsHSIIPTVPONServiceRequest;

public class ARMCircuitDetailRoute extends RouteBuilder{
	private static final Log LOG = LogFactory.getLog(ARMCircuitDetailRoute.class);
	
	@Override
	public void configure() throws Exception {
		from("direct:ARMBasicCircuitDetailedRoute")
		.id("ARMBasicCircuitDetailedRoute")
		.choice()
		.when(new IsHSIIPTVPONServiceRequest())
		.to("direct:searchHSIPONIPTVServices")
		.otherwise()
		.to("direct:armCircuitCircuitDetailedServiceRoute")
		.end();
	}

}
