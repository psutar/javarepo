package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Elliptic;
import com.iclnbi.iclnbiV200.ExchangeServiceArea;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UNICircuit;

public class CircuitDetailCLCLocationResponseProcessor implements Processor {
	private static final Log LOG = LogFactory.getLog(CircuitDetailResponseProcessor.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		SearchResourceResponseDocument armResp = (SearchResourceResponseDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_RESPONSE);
		//LOG.info("armResp is >>>>>>>>>>>>>" + armResp);

		if (exchg != null && exchg.getException() == null) {
			Object temp = exchg.getIn().getBody();

			if (temp != null && temp instanceof SearchResourceResponseDocument) {
				//LOG.info("CLC Customer Response : " + temp);
				SearchResourceResponseDocument clcResp = (SearchResourceResponseDocument) temp;

				if (armResp.getSearchResourceResponse()
						.getSearchResponseDetailsList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getP2PCircuitList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getP2PCircuitArray(0) != null) {

					AmericanPropertyAddress clcRespAddrDetForP2P = clcResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getAddressDetailsArray(0);
					//LOG.info("CLC RespAddrDet Response : "+ clcRespAddrDetForP2P);
					aggregate(armResp, clcRespAddrDetForP2P);
				}

			}
		} 
		else {
			exchg.setException(null);
			exchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			exchg.getIn().setBody(armResp);
		}

		exchg.getOut().setBody(armResp);
	}

	private void aggregate(SearchResourceResponseDocument armResp,
			AmericanPropertyAddress clcRespAddrDet) throws Exception {

		TopologicalLink TopologicalLink = armResp.getSearchResourceResponse()
				.getSearchResponseDetailsArray(0).getP2PCircuitArray(0);

		UNICircuit uniCircuit = UNICircuit.Factory.newInstance();
		uniCircuit = UNICircuit.Factory.parse(TopologicalLink.xmlText());

		AmericanPropertyAddress armAddressDetails = uniCircuit.addNewAddressDetails();
		//LOG.info("armAddressDetails1:::: " + armAddressDetails1);
		if (clcRespAddrDet.getCommonName() != null) {
			//LOG.info("CommonName from CLC : "+ clcRespAddrDet.getCommonName());
			armAddressDetails.setCommonName(clcRespAddrDet.getCommonName());
		}
		
		
		List<CharacteristicValue> addrList = clcRespAddrDet.getRootEntityDescribedByList();
		int size = addrList.size();

		CharacteristicValue cvNew = null;
		
		if (size > 0) {
			for (CharacteristicValue current : addrList) {
				if (current.getCharacteristicName() != null ) {
					if(current.getCharacteristicName().equalsIgnoreCase(ARMRoutingConstants.SWC) || 
							current.getCharacteristicName().equalsIgnoreCase("LocationFullName")) {
					cvNew = CharacteristicValue.Factory.newInstance();
					cvNew.setCharacteristicName(current.getCharacteristicName());
					cvNew.setCharacteristicValue( current.getCharacteristicValue());
					armAddressDetails.getRootEntityDescribedByList().add(cvNew);
					}
				}				
			}
	   	}
					

		if (clcRespAddrDet.getStateOrProvince() != null) {
			//LOG.info("StateOrProvince in  clc : "+ clcRespAddrDet.getStateOrProvince());
			armAddressDetails.setStateOrProvince(clcRespAddrDet.getStateOrProvince());
		}

		if (clcRespAddrDet.getCLLI() != null)
			armAddressDetails.setCLLI(clcRespAddrDet.getCLLI());

		if (clcRespAddrDet.getLocality() != null)
			armAddressDetails.setLocality(clcRespAddrDet.getLocality());

		if (clcRespAddrDet.getPostcode() != null)
			armAddressDetails.setPostcode(clcRespAddrDet.getPostcode());

		if (clcRespAddrDet.getEllipticLocation() != null) {
			Elliptic elliptic = Elliptic.Factory.newInstance();
			elliptic.setHCoordinate(clcRespAddrDet.getEllipticLocation()
					.getHCoordinate());
			elliptic.setVCoordinate(clcRespAddrDet.getEllipticLocation()
					.getVCoordinate());
			armAddressDetails.setEllipticLocation(elliptic);
		}

		if (clcRespAddrDet.getExchangeServiceAreaList() != null
				&& clcRespAddrDet.getExchangeServiceAreaList().size() > 0) {
			for (ExchangeServiceArea area : clcRespAddrDet
					.getExchangeServiceAreaList()) {
				if (area.getAreaType().equalsIgnoreCase("LATA")
						&& !StringHelper.isEmpty(area.getCode())) {
					armAddressDetails.addNewExchangeServiceArea();
					armAddressDetails.getExchangeServiceAreaList().get(0).setAreaType("LATA");
					armAddressDetails.getExchangeServiceAreaList().get(0).setCode(area.getCode());
					break;
				}
			}
		}

		if (clcRespAddrDet.getAddressLine1() != null)
			armAddressDetails.setAddressLine1(clcRespAddrDet.getAddressLine1());

		if (clcRespAddrDet.getAddressLine2() != null)
			armAddressDetails.setAddressLine2(clcRespAddrDet.getAddressLine2());

		if (clcRespAddrDet.getAddressLine3() != null)
			armAddressDetails.setAddressLine3(clcRespAddrDet.getAddressLine3());

		//LOG.info("inside arm after clc aggregation>>>>>>> : "+ armAddressDetails1);

	}

}
