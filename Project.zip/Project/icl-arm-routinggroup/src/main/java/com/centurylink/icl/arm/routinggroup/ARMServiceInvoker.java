package com.centurylink.icl.arm.routinggroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Header;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.util.tracker.ServiceTracker;
import org.springframework.dao.DataAccessException;

import com.centurylink.icl.clc.connector.data.InventoryAssetRequest;
import com.centurylink.icl.component.IConnector;
import com.centurylink.icl.component.IRoutingGroupService;
import com.centurylink.icl.component.ITransformationEngine;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.ConsumeNumberObjectResponseDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.CreateLocationResponseDocument;
import com.iclnbi.iclnbiV200.DeleteCircuitResponseDocument;
import com.iclnbi.iclnbiV200.DeleteDeviceResponseDocument;
import com.iclnbi.iclnbiV200.ReleaseNumberObjectResponseDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.UpdateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.UpdateDeviceResponseDocument;
import com.iclnbi.iclnbiV200.UpdateTerminationPointResponseDocument;

public class ARMServiceInvoker {
	
	private ServiceTracker connectorTracker;
	private ServiceTracker clcServiceTracker;
	private ServiceTracker inventoryAssetServiceTracker;
	private ServiceTracker engineTracker;
	private ServiceTracker armServiceTracker;
	private ServiceTracker armServiceTrackerMDW;
	
	private ServiceTracker losdbConnectorTracker;
	private ServiceTracker losdbEngineTracker;
	private ServiceTracker clcConnectorTracker;
	private ServiceTracker trafxEngineTracker;
	private ServiceTracker trafxConnectorTracker;
	
	private ServiceTracker dvarConnectorTracker;
	private ServiceTracker dvarEngineTracker;
	private ServiceTracker qctrlServiceTracker;
	private ServiceTracker integratorServiceTracker;
	
	private static final Log LOG = LogFactory.getLog(ARMServiceInvoker.class);
	private static final String METHODNAME	= "methodName";
	private static final String FROM_SID_TYPE = "FromSidType";
	private static final String OPERATIONNAME	= "OPERATIONNAME";
	

	
	public ARMServiceInvoker(BundleContext bundleContext) throws InvalidSyntaxException
	{
		super();
		Filter filterConnector = bundleContext.createFilter("(&(name=armConnector))");
		connectorTracker = new ServiceTracker(bundleContext, filterConnector, null);
		connectorTracker.open();
		
		Filter filterTransformationEngine = bundleContext.createFilter("(&(name=armTransformationEngine))");
		engineTracker = new ServiceTracker(bundleContext, filterTransformationEngine, null);
		engineTracker.open();
		
		Filter filter = bundleContext.createFilter("(&(name=CLCService))");
		clcServiceTracker = new ServiceTracker(bundleContext, filter, null);
		clcServiceTracker.open();
		
		Filter filterInventoryAssetServiceTracker = bundleContext.createFilter("(&(name=inventoryAssetConnector))");
		inventoryAssetServiceTracker = new ServiceTracker(bundleContext, filterInventoryAssetServiceTracker, null);
		inventoryAssetServiceTracker.open();
		
		Filter filterArmServiceTracker = bundleContext.createFilter("(&(name=armService))");
		armServiceTracker = new ServiceTracker(bundleContext, filterArmServiceTracker, null);
		armServiceTracker.open();
		
		Filter filterMDW = bundleContext.createFilter("(&(alias=IlmMdwService))");
		armServiceTrackerMDW = new ServiceTracker(bundleContext, filterMDW, null);
		armServiceTrackerMDW.open();
		
		filter = bundleContext.createFilter("(&(name=losdbTransformationEngine))");
		losdbEngineTracker = new ServiceTracker(bundleContext, filter, null);
		losdbEngineTracker.open();
		
		filter = bundleContext.createFilter("(&(name=losdbConnector))");
		losdbConnectorTracker = new ServiceTracker(bundleContext, filter, null);
		losdbConnectorTracker.open();
		
		Filter filterCLC = bundleContext.createFilter("(&(name=clcConnector))");
    	clcConnectorTracker = new ServiceTracker(bundleContext, filterCLC, null);
    	clcConnectorTracker.open();
    	
    	filter = bundleContext.createFilter("(&(name=trafxTransformationengine))");
    	trafxEngineTracker = new ServiceTracker(bundleContext, filter, null);
    	trafxEngineTracker.open();
		
		filter = bundleContext.createFilter("(&(name=trafxConnector))");
		trafxConnectorTracker = new ServiceTracker(bundleContext, filter, null);
		trafxConnectorTracker.open();
		
		filter = bundleContext.createFilter("(&(name=dvarConnector))");
    	dvarConnectorTracker = new ServiceTracker(bundleContext, filter, null);
    	dvarConnectorTracker.open();
    	
    	 filter = bundleContext.createFilter("(&(name=dvarTransformationEngine))");
    	dvarEngineTracker = new ServiceTracker(bundleContext, filter, null);
    	dvarEngineTracker.open();
    	
    	filter = bundleContext.createFilter("(&(name=QControlService))");
    	qctrlServiceTracker = new ServiceTracker(bundleContext, filter, null);
    	qctrlServiceTracker.open();
    	
    	filter = bundleContext.createFilter("(&(name=IntegratorService))");
		integratorServiceTracker = new ServiceTracker(bundleContext, filter, null);
		integratorServiceTracker.open();
		
	}
	
	public void close()
	{
		connectorTracker.close();
		engineTracker.close();
		clcServiceTracker.close();
		armServiceTracker.close();
		armServiceTrackerMDW.close();
		inventoryAssetServiceTracker.close();
		clcConnectorTracker.close();
		trafxEngineTracker.close();
		trafxConnectorTracker.close();
		dvarConnectorTracker.close();
		dvarEngineTracker.close();
		qctrlServiceTracker.close();
		integratorServiceTracker.close();
	}
	
	public Object callConnector(Object in,@Header(METHODNAME) String methodName) throws Exception {
		
		LOG.debug("Calling ARM Connector :" + methodName);
		IConnector connector  = (IConnector)connectorTracker.getService();
		
		if(null != connector)
		{
			HashMap<String, Object> iHashMap = new HashMap<String, Object>();
			iHashMap.put(METHODNAME, methodName);
			return connector.call(in,iHashMap);
		}
		else
		{
			throw new ICLException("Connector not running");
		}	
		
	}
	
	public Object callDVARConnector(Exchange exchange) throws Exception{
		LOG.info("Calling DVAR Connector");
		IConnector connector = (IConnector)dvarConnectorTracker.getService();
		if(connector!=null)
		{			
			return connector.call(exchange.getIn().getBody(), null);
		}
		else
		{
			throw new ICLException("DVAR Connector not running");
		}
	}
	
	public Object callDVARTransformFromCim(Exchange exchange) throws Exception 
	{
		LOG.info("callDVARTransformFromCIM");
		ITransformationEngine engine = (ITransformationEngine)dvarEngineTracker.getService();
		
		if(null != engine)
		{
			return engine.transformFromCim(exchange.getIn().getBody(), null);
		}
		else
		{
			throw new ICLException("DVAR Engine not running");
		}
	}
	
	public Object callDVARTransformToCim(Exchange exchange) throws Exception
	{
		LOG.info("callDVARTransformToCim");
		ITransformationEngine engine = (ITransformationEngine)dvarEngineTracker.getService();
		
		if(null != engine)
		{
			return engine.transformToCim(exchange.getIn().getBody(), null);
		}
		else
		{
			throw new ICLException("DVAR Engine not running");
		}
	}
	
	public Object callTrafxConnector(Exchange exchange) throws Exception {
		LOG.info("callTrafxConnector");
		IConnector connector = (IConnector)trafxConnectorTracker.getService();
		
		if(null != connector)
		{
			Object in = exchange.getIn().getBody();			
			HashMap<String, Object> params = new HashMap<String, Object>();
			params.put("Host", exchange.getProperty("host") != null ? exchange.getProperty("host") : null);
			params.put("Port", exchange.getProperty("port") != null ? exchange.getProperty("port") : null);			
			
			return connector.call(in, params);
		}
		else
		{
			throw new ICLException("Connector not running");
		}	
	}
	
	public Object callTrafxTransformFromCim(Object in) throws Exception {
		LOG.info("callTrafxTransformFromCim");
		ITransformationEngine engine = (ITransformationEngine)trafxEngineTracker.getService();
		
		if(null != engine)
		{
			return engine.transformFromCim(in, null);
		}
		else
		{
			throw new ICLException("Engine not running");
		}	
	}
	
	public Object callTrafxTransformToCim(Exchange exchange) throws Exception 
	{
		LOG.info("callTrafxTransformToCim");
		ITransformationEngine engine = (ITransformationEngine)trafxEngineTracker.getService();
		
		if(null != engine)
		{
			Object in = exchange.getIn().getBody();			
			HashMap<String, Object> params = new HashMap<String, Object>();
			params.put("SIDREQUEST", exchange.getProperty("TRAFXREQUEST") != null ? exchange.getProperty("TRAFXREQUEST") : null);
			
			return engine.transformToCim(in, params);
		}
		else
		{
			throw new ICLException("Engine not running");
		}	
	}
	
	
	public  Object callTransformFromCim(Object in, @Header(METHODNAME) String methodName) throws Exception
	{
		LOG.debug("callTransformFromSid");
		ITransformationEngine engine = (ITransformationEngine)engineTracker.getService();
		
		if(null != engine)
		{
			HashMap<String,Object> ihashMap =  new HashMap<String,Object>();
			ihashMap.put(FROM_SID_TYPE, methodName);
			return engine.transformFromCim(in, ihashMap);
						
		}
		else
		{
			throw new ICLException("TransformationEngine not running");
		}	
	}	
		
	public void callCLCOp(Exchange exchg) throws Exception
	{
		IRoutingGroupService routingGroupService = (IRoutingGroupService)clcServiceTracker.getService();
		LOG.debug("Before : " + routingGroupService);
		if(null != routingGroupService)
		{
			// Update target route on exchange
			exchg.setProperty("TargetRoute", "direct:CLCSearch");
			routingGroupService.invokeRoute(exchg);		
		}
		LOG.debug("After");
	}
	
	
	
	public void callCLCSearchLocationOp(Exchange exchg) throws Exception
	{
		IRoutingGroupService routingGroupService = (IRoutingGroupService)clcServiceTracker.getService();
		
		if(null != routingGroupService)
		{
			// Update target route on exchange
			exchg.setProperty("TargetRoute", "direct:CLCSearchLocation");
			routingGroupService.invokeRoute(exchg);		
		}
		
	}
	
	public void callCLCSearchCustomerOp(Exchange exchg) throws Exception
	{
		IRoutingGroupService routingGroupService = (IRoutingGroupService)clcServiceTracker.getService();
		
		if(null != routingGroupService)
		{
			// Update target route on exchange
			exchg.setProperty("TargetRoute", "direct:CLCSearchCustomer");
			routingGroupService.invokeRoute(exchg);			
			
			/* Vadsule: Not sure why this code is required here. Commenting it for now. */
			/*if(exchg.getException() != null){
				exchg.setException(null);
				exchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			}*/
			//LOG.info("exchg in Invoker >>>>>>>>>: " + exchg);
		}
		
	}
	
	public void getCLCNtmDeviceLocation(Exchange exchg) throws Exception
	{
		IRoutingGroupService routingGroupService = (IRoutingGroupService)clcServiceTracker.getService();
		
		if(null != routingGroupService)
		{
			// Update target route on exchange
			exchg.setProperty("TargetRoute", "direct:clcNtmDeviceLocationRoute");
			routingGroupService.invokeRoute(exchg);		
		}
	}
	
 public Object callConnectorInternalArmMediation(Exchange exchange,@Header(METHODNAME) String methodName) throws Exception {
		
		LOG.debug("Calling mediation layer for "+ methodName);
		try
		{
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(METHODNAME, methodName);
			map.put("DEVICE_NAME", exchange.getProperty("DEVICE_NAME") != null ? exchange.getProperty("DEVICE_NAME") : null);
			IConnector armMediationService = (IConnector)armServiceTracker.getService();
			Object object = armMediationService.call(exchange.getIn().getBody(), map);
			
			LOG.debug("Mediation call completed....");
			
			return object;
		}
		catch(DataAccessException e)
		{
			LOG.error("Exception from arm medition ", e);
			//wrap any data access exception as ICL internal exception; 
			throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
		}
		
	}
 
 public Object callArmMediationPortSyncAuditService(Exchange exchange,@Header(METHODNAME) String methodName) throws Exception {
		
		LOG.debug("Calling mediation layer for "+ methodName);
		try
		{
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put(METHODNAME, methodName);
			map.put("PORTSTATUS", exchange.getProperty("PORTSTATUS") != null ? exchange.getProperty("PORTSTATUS") : null);
			map.put("PORT_NAME", exchange.getProperty("PORT_NAME") != null ? exchange.getProperty("PORT_NAME") : null);
			map.put("DEVICE_NAME", exchange.getProperty("DEVICE_NAME") != null ? exchange.getProperty("DEVICE_NAME") : null);
			map.put("action", exchange.getProperty("action") != null ? exchange.getProperty("action") : null);
			IConnector armMediationService = (IConnector)armServiceTracker.getService();
			Object object = armMediationService.call(exchange.getIn().getBody(), map);
			
			LOG.debug("Mediation call completed....");
			
			return object;
		}
		catch(DataAccessException e)
		{
			LOG.error("Exception from arm medition ", e);
			//wrap any data access exception as ICL internal exception; 
			throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
		}
		
	}
	
	public Object callARMHSIService(Exchange exchange,@Header(METHODNAME) String methodName)throws Exception{
        LOG.debug("Calling mediation layer for HSIService: "+ methodName);
        try
        {
           HashMap<String, Object> map = new HashMap<String, Object>();
           map.put(METHODNAME, methodName);
           map.put("VLANNumber", exchange.getProperty("VLANNumber") != null ? exchange.getProperty("VLANNumber") : null);
           map.put("DeviceName", exchange.getProperty("DeviceName") != null ? exchange.getProperty("DeviceName") : null);
           
           IConnector armMediationService = (IConnector)armServiceTracker.getService();
           Object object = armMediationService.call(exchange.getIn().getBody(), map);
           
           LOG.debug("Mediation call completed....");
           
           
           return object;
        }
        catch(DataAccessException e)
        {
               LOG.error("Exception from arm medition ", e);
               //wrap any data access exception as ICL internal exception; 
               throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
        }
	}
	
	public Object callARMGetDeviceListForCLLIService(Exchange exchange,@Header(METHODNAME) String methodName)throws Exception{
        LOG.debug("Calling mediation layer for getting device List : "+ methodName);
        try
        {
           HashMap<String, Object> map = new HashMap<String, Object>();
           map.put(METHODNAME, methodName);
           map.put("DeviceCLLI", exchange.getProperty("DeviceCLLI") != null ? exchange.getProperty("DeviceCLLI") : null);
           
           IConnector armMediationService = (IConnector)armServiceTracker.getService();
           Object object = armMediationService.call(exchange.getIn().getBody(), map);
           
           LOG.debug("Mediation call completed....");
           
           if(object != null)
           {
	           @SuppressWarnings("unchecked")
	           List<String> deviceNamesList = (List<String>)object;
	           if(deviceNamesList != null && deviceNamesList.size() == 0)
	           {
	        	   throw new ICLException("No devices found for the device CLLI : "+map.get("DeviceCLLI"));
	           }
           }
           return object;
        }
        catch(DataAccessException e)
        {
               LOG.error("Exception from arm medition ", e);
               //wrap any data access exception as ICL internal exception; 
               throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
        }
	}
	
	public Object callARMGetRoutesForAssociatedCircuitService(Exchange exchange,@Header(METHODNAME) String methodName)throws Exception{
        LOG.debug("Calling mediation layer for getting Routes List : "+ methodName);
        try
        {
           HashMap<String, Object> map = new HashMap<String, Object>();
           map.put(METHODNAME, methodName);
           map.put("AssociatedCircuit", exchange.getProperty("AssociatedCircuit") != null ? exchange.getProperty("AssociatedCircuit") : null);
           
           IConnector armMediationService = (IConnector)armServiceTracker.getService();
           Object object = armMediationService.call(exchange.getIn().getBody(), map);
           
           LOG.debug("Mediation call completed....");
           
           if(object != null)
           {
	           @SuppressWarnings("unchecked")
	           List<String> routesList = (List<String>)object;
	           if(routesList != null && routesList.size() == 0)
	           {
	        	   throw new ICLException("No Routes found for the Associated Circuit : "+map.get("AssociatedCircuit"));
	           }
           }
           return object;
        }
        catch(DataAccessException e)
        {
               LOG.error("Exception from arm medition ", e);
               //wrap any data access exception as ICL internal exception; 
               throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
        }
	}

	public Object callSlotCardCompatibilityService(Exchange exchange,@Header(METHODNAME) String methodName)throws Exception{
        LOG.debug("Calling mediation layer for SlotCardCompatibilityService: "+ methodName);
        try
        {
           HashMap<String, Object> map = new HashMap<String, Object>();
           map.put(METHODNAME, methodName);
            
           IConnector armMediationService = (IConnector)armServiceTracker.getService();
           Object object = armMediationService.call(exchange.getIn().getBody(), map);
           
           LOG.debug("Mediation call completed....");
           
           return object;
        }
        catch(DataAccessException e)
        {
               LOG.error("Exception from arm medition ", e);
               //wrap any data access exception as ICL internal exception; 
               throw new ICLException("ICLInternalError","Could not access ARM data for requested service (" + e.getMostSpecificCause() + ")","1947");
        }
	}
	
	public Object callConnectorMDW(Object in,@Header(METHODNAME) String methodName) throws Exception {
		
		LOG.debug("Calling mediation layer for "+ methodName);
		
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(METHODNAME, methodName);
		IConnector armMediationService = (IConnector)armServiceTrackerMDW.getService();
		Object object = armMediationService.call(in, map);
		
		//MDW will return the response in String so converting it to object.
		
		LOG.debug("Mediation call completed....");
		return getResponseFromString(methodName,object);
		
	}

	@SuppressWarnings("unchecked")
	public Object callInventoryAssetConnector(Object in) throws Exception {
		
		IConnector connector  = (IConnector)inventoryAssetServiceTracker.getService();
		
		List<InventoryAssetRequest> assetRequests = (List<InventoryAssetRequest>) in;
		if(null != connector)
		{
			for (InventoryAssetRequest assetRequest:assetRequests)
			{
				try {
					connector.call(assetRequest, null);
				} catch (Exception e) {
					//If it fails to add the association it's ok so just ignore it and try the next one
					LOG.info(e.getMessage());
				}
			}
		}
		else
		{
			throw new ICLException("Connector not running");
		}
		
		return null;
	}
	
	
	public Object callLosdbConnector(Object in) throws Exception {
		
		IConnector connector  = (IConnector)losdbConnectorTracker.getService();
		
		if(null != connector)
		{
			return connector.call(in, null);
		}
		else
		{
			throw new ICLException("Connector not running");
		}	 
		
	}
	
	public Object callLosdbTransformToCim(Object in) throws Exception
	{
		ITransformationEngine engine = (ITransformationEngine) losdbEngineTracker.getService();

		if (null != engine) {
			return engine.transformToCim(in, null);
		} else {
			throw new ICLException("Engine not running");
		}
	}
	
	 
    public Object callConnectorCLC(Object in,@Header(METHODNAME) String methodName) throws Exception
    {
    	LOG.debug("Calling CLC Connector for "+ methodName);
    	
    	IConnector connector = (IConnector)clcConnectorTracker.getService();
    	HashMap<String, Object> iHashMap = new HashMap<String, Object>();
		iHashMap.put(OPERATIONNAME, methodName);
		
    	return connector.call(in, iHashMap);
		}
	
	public void callClcContactDetails(Exchange exchg)throws Exception{
		
		IRoutingGroupService routingGroupService = (IRoutingGroupService)clcServiceTracker.getService();
		
		if(null != routingGroupService)
		{
			exchg.setProperty("TargetRoute", "direct:CLCSearchContact");
			routingGroupService.invokeRoute(exchg);
		}
		else throw new ICLException("CLCService not running");
	}
	
	public void callQCtrlService(Exchange exchange)throws Exception
	{
		IRoutingGroupService routingGroupService = (IRoutingGroupService)qctrlServiceTracker.getService();
		if(routingGroupService!=null)
		{
			exchange.setProperty("TargetRoute", "direct:QControlCustomertAccounts");
			exchange.setProperty("ToSidType","Cim2");
			routingGroupService.invokeRoute(exchange);
		}
		else throw new ICLException("QControl Service not running");
	}
	
	private Object getResponseFromString(String methodName,Object responseFromMdw) throws Exception
	{
		if(ARMServiceRoute.CreateLocationMDW.equals(methodName))
		{
			return CreateLocationResponseDocument.Factory.parse((String)responseFromMdw);
		}
		else if(ARMServiceRoute.CreateDeviceMDW.equals(methodName))
		{
			return CreateDeviceResponseDocument.Factory.parse((String)responseFromMdw);
		}
		else if(ARMServiceRoute.SearchLocationMDW.equals(methodName))
		{
			return SearchResourceResponseDocument.Factory.parse((String)responseFromMdw);
		}
		else if(ARMServiceRoute.UpdateDeviceMDW.equals(methodName))
		{
			return UpdateDeviceResponseDocument.Factory.parse((String)responseFromMdw);	
		}
		else if(ARMServiceRoute.DeleteDeviceMDW.equals(methodName))
		{
			return DeleteDeviceResponseDocument.Factory.parse((String)responseFromMdw);	
		}
		else if(ARMServiceRoute.UpdateCircuitMDW.equals(methodName) || TransportPathRoute.UPDATE_ROUTE.equals(methodName))
		{
			return UpdateCircuitResponseDocument.Factory.parse((String)responseFromMdw);	
		}
		else if(ARMServiceRoute.CreateCircuitMDW.equals(methodName) || TransportPathRoute.CREATE_ROUTE.equals(methodName))
		{
			return CreateCircuitResponseDocument.Factory.parse((String)responseFromMdw);	
		}
		else if(ARMServiceRoute.DeleteCircuitMDW.equals(methodName) || TransportPathRoute.DELETE_ROUTE.equals(methodName))
		{
			return DeleteCircuitResponseDocument.Factory.parse((String)responseFromMdw);	
		}
		else if(ARMServiceRoute.UpdateTerminationPointMDW.equals(methodName))
		{
			return UpdateTerminationPointResponseDocument.Factory.parse((String)responseFromMdw);
		}
		else if(ARMServiceRoute.ConsumeNumberObjMDW.equals(methodName))
		{
			return ConsumeNumberObjectResponseDocument.Factory.parse((String)responseFromMdw);
		}
		else if(ARMServiceRoute.ReleaseNumberObjMDW.equals(methodName))
		{
			return ReleaseNumberObjectResponseDocument.Factory.parse((String)responseFromMdw);
		}
		return null;
	}
	
	public Object callConnectorForUpdateAddressCLC(Exchange exchange) throws Exception
	{
		LOG.info("callConnectorForupdateAddressCLC");
		IConnector connector = (IConnector)clcConnectorTracker.getService();
		//IConnector connector = (IConnector)clcServiceTracker.getService();
	
		if(null != connector)
		{			
			HashMap<String, Object> ihashMap = (HashMap<String, Object>)exchange.getProperty("map");
			
			if(null != ihashMap && ihashMap.size() > 0){		
			return connector.call(new Object(), ihashMap);
			}else{
				return null;
			}
		}
		else
		{
			throw new Exception("Connector not running");
		}	
	}
	
   public void callIntegratorService(Exchange exchg)throws Exception{
		
	   LOG.info("callIntegrator");
		IRoutingGroupService routingGroupService = (IRoutingGroupService) integratorServiceTracker.getService();
		LOG.info("IntegratorService...."+routingGroupService);
		
		if(null != routingGroupService)
		{
			// Update target route on exchange
			//exchange.setProperty("TargetRoute", "direct:QControlCustomertAccounts");
			routingGroupService.invokeRoute(exchg);
		}
		else{
			throw new Exception("Integrator not running");
		}
	}
}
