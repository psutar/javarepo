package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class CircuitDetailResponseProcessor implements Processor {
	private static final Log LOG = LogFactory.getLog(CircuitDetailResponseProcessor.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		SearchResourceResponseDocument armResp = (SearchResourceResponseDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_RESPONSE);

		if (exchg != null && exchg.getException() == null) {
			Object temp = exchg.getIn().getBody();
			if (temp != null && temp instanceof SearchResourceResponseDocument) {
				// LOG.info("CLC Customer Response : " + temp);
				SearchResourceResponseDocument clcResp = (SearchResourceResponseDocument) temp;
				Party party = clcResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getPartyArray(0);
				
				if (armResp.getSearchResourceResponse()
						.getSearchResponseDetailsList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getCircuitList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getCircuitArray(0).getOwnsResourceDetails() != null
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getCircuitArray(0).getOwnsResourceDetails()
								.getCustomerList().size() > 0) {
					
					Customer cust = armResp.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getOwnsResourceDetails()
							.getCustomerArray(0);
					
					cust.setCommonName(party.getCommonName());					
					cust.setObjectID(party.getObjectID());
					if (!StringHelper.isEmpty(party.getPartyId())){
						cust.setID(party.getPartyId());
					}

					getHPCCLCDetails(cust, party);
					addExceptionHandlingText(cust, party);
					
				}else if (armResp.getSearchResourceResponse()
						.getSearchResponseDetailsList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getP2PCircuitList().size() > 0
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getP2PCircuitArray(0).getOwnsResourceDetails() != null
						&& armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getP2PCircuitArray(0).getOwnsResourceDetails()
								.getCustomerList().size() > 0) {
					
					Customer cust = armResp.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getOwnsResourceDetails()
							.getCustomerArray(0);
					cust.setCommonName(party.getCommonName());					
					cust.setObjectID(party.getObjectID());					
					if (!StringHelper.isEmpty(party.getPartyId())){
						cust.setID(party.getPartyId());
					}

					getHPCCLCDetails(cust, party);
					addExceptionHandlingText(cust, party);
				}
			}
		}
		else if (exchg != null && exchg.getException() != null){			
			exchg.setException(null);
			exchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			exchg.getIn().setBody(armResp);
		}
		
		exchg.getOut().setBody(armResp);
	}

	private void getHPCCLCDetails(Customer cust, Party party) {
		
		String hpcCustomerCodeValue = null;
		String hpcExpiryDateValue = null;
		
		if (party.getHasCustomerRoleList().size() > 0) {
			Customer customer = party.getHasCustomerRoleArray(0);					

			for (CharacteristicValue current : customer.getRootEntityDescribedByList()) {
				String characteristicName = current.getCharacteristicName();
				if (characteristicName.equalsIgnoreCase("HPCCustomerCode")) {
					hpcCustomerCodeValue = current.getCharacteristicValue();
				}else if (characteristicName.equalsIgnoreCase("HPCExpirationDate")) {
					hpcExpiryDateValue = current.getCharacteristicValue();
				}
			}
			
			if (!StringHelper.isEmpty(customer.getACNA())){
				cust.setACNA(customer.getACNA());
			}			
		}	
				
		if (!StringHelper.isEmpty(hpcCustomerCodeValue)) {
			CharacteristicValue characteristicHPCIndicator = cust.addNewRootEntityDescribedBy();
			characteristicHPCIndicator.setCharacteristicName("HPCIndicator");
			characteristicHPCIndicator.setCharacteristicValue(hpcCustomerCodeValue);
		}

		if (!StringHelper.isEmpty(hpcExpiryDateValue)) {
			CharacteristicValue characteristicHPCExpiryDate = cust.addNewRootEntityDescribedBy();
			characteristicHPCExpiryDate.setCharacteristicName("HPCExpiryDate");
			characteristicHPCExpiryDate.setCharacteristicValue(hpcExpiryDateValue);
		}
		
	}
	
	
	private void addExceptionHandlingText(Customer cust,Party party)
	{
		String exceptionText  = null;
		if (party.getHasCustomerRoleList().size() > 0) {
			Customer customer = party.getHasCustomerRoleArray(0);					

			for (CharacteristicValue current : customer.getRootEntityDescribedByList()) {
				String characteristicName = current.getCharacteristicName();
				if ("ExceptionHandlingText".equalsIgnoreCase(characteristicName)) {
					exceptionText = current.getCharacteristicValue();
				}
			}
		}
		
		if (!StringHelper.isEmpty(exceptionText)) {
			CharacteristicValue characteristicHPCIndicator = cust.addNewRootEntityDescribedBy();
			characteristicHPCIndicator.setCharacteristicName("ExceptionHandlingText");
			characteristicHPCIndicator.setCharacteristicValue(exceptionText);
		}
	}
}
