package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsHSIServiceRequest implements Predicate{
	private static final Log LOG = LogFactory.getLog(IsHSIServiceRequest.class);
	private static final String HSI_SERVICE = "7635131111-HSI";
	
	@Override
	public boolean matches(Exchange exchange) {
		SearchResourceRequestDocument requestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		SearchResourceDetails resourceDetails = requestDocument.getSearchResourceRequest().getSearchResourceDetails();
		if(resourceDetails!=null && resourceDetails.getCommonName().equalsIgnoreCase(HSI_SERVICE)){
			return true;
		}
		else {
		return false;
		}
	}
}
