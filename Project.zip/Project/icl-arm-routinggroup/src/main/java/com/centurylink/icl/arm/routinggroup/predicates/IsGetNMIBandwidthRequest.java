package com.centurylink.icl.arm.routinggroup.predicates;


import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;


public class IsGetNMIBandwidthRequest implements Predicate {
	@Override
	public boolean matches(Exchange exchg) {
		
		SearchResourceRequestDocument in = 
				((SearchResourceRequestDocument)exchg.getIn().getBody());
		
		
		boolean deviceName = checkRcv(in, "DeviceName");
		boolean includeRelationship = checkRcv(in, "Include Relationships");
		
		if(deviceName && !includeRelationship)
		{
			return true;			
		}
	
		return false;
	}
	
	
	private static boolean checkRcv(SearchResourceRequestDocument request, String characteristicName)
	{

		for (ResourceCharacteristicValue current : request.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return true;
			}
		}

		return false;
	}

}

