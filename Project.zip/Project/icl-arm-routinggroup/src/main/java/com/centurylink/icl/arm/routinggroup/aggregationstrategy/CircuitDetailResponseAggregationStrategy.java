package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Elliptic;
import com.iclnbi.iclnbiV200.ExchangeServiceArea;
import com.iclnbi.iclnbiV200.SearchResourceResponse;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.Error;

public class CircuitDetailResponseAggregationStrategy implements
		AggregationStrategy {
	private static final Log LOG = LogFactory
			.getLog(CircuitDetailResponseAggregationStrategy.class);

	@Override
	public Exchange aggregate(Exchange oldExchg, Exchange newExchg) {
		SearchResourceResponseDocument oldResp = null;
		SearchResourceResponseDocument newResp = null;

		if (newExchg.getException() != null) {
			newExchg.setException(null);
			newExchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			newExchg.getIn().setBody(newExchg.getProperty(ARMRoutingConstants.ARM_RESPONSE));
			return newExchg;
		}

		if (null == oldExchg) {
			oldResp = (SearchResourceResponseDocument) newExchg
					.getProperty(ARMRoutingConstants.ARM_RESPONSE);
			if (((Boolean) newExchg.getProperty("CamelSplitComplete")) != true) {

				if (oldResp.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getCircuitList()
						.size() != 0) {
					AmericanPropertyAddress armRespAEndCkt = oldResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasAEndTpsArray(0)
							.getAccessPointAddressArray(0);
					
					newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
					//LOG.info("AEnd CLC Location Resp : " + newResp);
					AmericanPropertyAddress clcRespAddrDet = newResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getAddressDetailsArray(0);

					aggregate(armRespAEndCkt, clcRespAddrDet);
					newExchg.getIn().setBody(oldResp);
					oldResp = null;
				} else if (oldResp.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitList()
						.size() != 0) {
					AmericanPropertyAddress armRespAEndCkt = oldResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getAEndTpsArray(0)
							.getAccessPointAddressArray(0);

					newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
					AmericanPropertyAddress clcRespAddrDet = newResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getAddressDetailsArray(0);

					aggregate(armRespAEndCkt, clcRespAddrDet);
					newExchg.getIn().setBody(oldResp);
					oldResp = null;
				}
			} else {
				if (oldResp.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getCircuitList()
						.size() != 0) {
					AmericanPropertyAddress armRespZEndCkt = oldResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasZEndTpsArray(0)
							.getAccessPointAddressArray(0);

					newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
					// LOG.info("ZEnd CLC Location Resp : " + newResp);
					AmericanPropertyAddress clcRespAddrDet = newResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getAddressDetailsArray(0);

					aggregate(armRespZEndCkt, clcRespAddrDet);
					newExchg.getIn().setBody(oldResp);
				} else if (oldResp.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitList()
						.size() != 0) {
					AmericanPropertyAddress armRespZEndCkt = oldResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getZEndTpsArray(0)
							.getAccessPointAddressArray(0);

					newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
					AmericanPropertyAddress clcRespAddrDet = newResp
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getAddressDetailsArray(0);

					aggregate(armRespZEndCkt, clcRespAddrDet);
					newExchg.getIn().setBody(oldResp);
				}
			}

			return newExchg;
		}

		if (oldExchg.getException() != null) {
			SearchResourceResponseDocument responseDoc = SearchResourceResponseDocument.Factory
					.newInstance();
			responseDoc.addNewSearchResourceResponse().addNewMessageElements();
			createError(oldExchg.getException(Throwable.class),	responseDoc.getSearchResourceResponse());
			oldExchg.setException(null);
			oldExchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			oldExchg.getIn().setBody(responseDoc);
		}

		LOG.info(newExchg.getProperty("CamelSplitIndex", String.class));

		if (oldExchg != null
				&& oldExchg.getException() == null
				&& oldExchg.getIn().getBody() instanceof SearchResourceResponseDocument) {
			oldResp = (SearchResourceResponseDocument) oldExchg.getIn().getBody();
		}

		if (newExchg != null
				&& newExchg.getIn().getBody() instanceof SearchResourceResponseDocument) {
			newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
		}

		if (oldResp != null && newResp != null) {
			if (oldResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getCircuitList().size() != 0) {
				AmericanPropertyAddress armRespZEndCkt = oldResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getCircuitArray(0)
						.getSncHasZEndTpsArray(0).getAccessPointAddressArray(0);

				newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
				AmericanPropertyAddress clcRespAddrDet = newResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0)
						.getAddressDetailsArray(0);

				aggregate(armRespZEndCkt, clcRespAddrDet);
				oldExchg.getIn().setBody(oldResp);
			} else if (oldResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getP2PCircuitList()
					.size() != 0) {
				AmericanPropertyAddress armRespZEndCkt = oldResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
						.getZEndTpsArray(0).getAccessPointAddressArray(0);

				newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
				AmericanPropertyAddress clcRespAddrDet = newResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0)
						.getAddressDetailsArray(0);

				aggregate(armRespZEndCkt, clcRespAddrDet);
				oldExchg.getIn().setBody(oldResp);
			}

		} else if (oldResp != null && newExchg.getException() != null) {
			createError(newExchg.getException(Throwable.class),oldResp.getSearchResourceResponse());
			newExchg.setException(null);
			newExchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
			oldExchg.getOut().setBody(oldResp);
		}
		return oldExchg;
	}

	private void aggregate(AmericanPropertyAddress armRespXEndCk,
			AmericanPropertyAddress clcRespAddrDet) {
		if (clcRespAddrDet.getCommonName() != null)
			armRespXEndCk.setCommonName(clcRespAddrDet.getCommonName());
			
		List<CharacteristicValue> addrList = clcRespAddrDet.getRootEntityDescribedByList();
		int size = addrList.size();

		CharacteristicValue cvNew = null;
		
		if (size > 0) {
			for (CharacteristicValue current : addrList) {
				if (current.getCharacteristicName() != null ) {
					if(current.getCharacteristicName().equalsIgnoreCase(ARMRoutingConstants.SWC) || 
							current.getCharacteristicName().equalsIgnoreCase("LocationFullName") ||
							 "ExceptionHandlingText".equalsIgnoreCase(current.getCharacteristicName())) {
					cvNew = CharacteristicValue.Factory.newInstance();
					cvNew.setCharacteristicName(current.getCharacteristicName());
					cvNew.setCharacteristicValue( current.getCharacteristicValue());
					armRespXEndCk.getRootEntityDescribedByList().add(cvNew);
					}
				}				
			}
		}
		
		if (clcRespAddrDet.getObjectID() != null)
			armRespXEndCk.setObjectID(clcRespAddrDet.getObjectID());
		if (clcRespAddrDet.getCLLI() != null)
			armRespXEndCk.setCLLI(clcRespAddrDet.getCLLI());
		if (clcRespAddrDet.getStateOrProvince() != null)
			armRespXEndCk.setStateOrProvince(clcRespAddrDet
					.getStateOrProvince());
		if (clcRespAddrDet.getLocality() != null)
			armRespXEndCk.setLocality(clcRespAddrDet.getLocality());
		if (clcRespAddrDet.getPostcode() != null)
			armRespXEndCk.setPostcode(clcRespAddrDet.getPostcode());
		
		if (clcRespAddrDet.getEllipticLocation() != null) {
			Elliptic elliptic = Elliptic.Factory.newInstance();
			elliptic.setHCoordinate(clcRespAddrDet.getEllipticLocation()
					.getHCoordinate());
			elliptic.setVCoordinate(clcRespAddrDet.getEllipticLocation()
					.getVCoordinate());
			armRespXEndCk.setEllipticLocation(elliptic);
		}
		if (clcRespAddrDet.getExchangeServiceAreaList() != null
				&& clcRespAddrDet.getExchangeServiceAreaList().size() > 0) {
			for (ExchangeServiceArea area : clcRespAddrDet
					.getExchangeServiceAreaList()) {
				if (area.getAreaType().equalsIgnoreCase("LATA")
						&& !StringHelper.isEmpty(area.getCode())) {
					armRespXEndCk.addNewExchangeServiceArea();
					armRespXEndCk.getExchangeServiceAreaList().get(0).setAreaType("LATA");
					armRespXEndCk.getExchangeServiceAreaList().get(0).setCode(area.getCode());
					break;
				}
			}
		}
		if (clcRespAddrDet.getAddressLine1() != null)
			armRespXEndCk.setAddressLine1(clcRespAddrDet.getAddressLine1());
		if (clcRespAddrDet.getAddressLine2() != null)
			armRespXEndCk.setAddressLine2(clcRespAddrDet.getAddressLine2());
		if (clcRespAddrDet.getAddressLine3() != null)
			armRespXEndCk.setAddressLine3(clcRespAddrDet.getAddressLine3());
		
		if(clcRespAddrDet.getSourceSystem() != null)
			armRespXEndCk.setSourceSystem(clcRespAddrDet.getSourceSystem());
	}

	private void createError(Throwable throwable,
			SearchResourceResponse searchResourceResponse) {
		String errorCode = "1947";
		String errorMessage = throwable.getMessage();
		String errorStatus = "F";
		String errorText = "ICLInternalError";

		// if the top level exception is not an ICLException, check to see if
		// there is one in the chain
		ICLException iclException = throwable instanceof ICLException ? (ICLException) throwable
				: ICLException.getICLException(throwable);

		if (iclException != null) {
			errorMessage = iclException.getMessage();
			errorCode = iclException.getErrorCode();
			errorText = iclException.getErrorText();
		}
		Error error = Error.Factory.newInstance();
		error.setErrorCode(errorCode);
		error.setErrorMessage(errorMessage);
		error.setErrorStatus(errorStatus);
		error.setErrorText(errorText);

		if (null == searchResourceResponse.getMessageElements()
				|| searchResourceResponse.getMessageElements()
						.sizeOfErrorListArray() < 1) {
			searchResourceResponse.addNewMessageElements();
		}

		searchResourceResponse.getMessageElements().getErrorListList()
				.add(error);
	}
}
