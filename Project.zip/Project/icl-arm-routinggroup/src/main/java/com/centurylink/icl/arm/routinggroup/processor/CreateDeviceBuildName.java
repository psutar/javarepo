package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.PhysicalDevice;

public class CreateDeviceBuildName implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		CreateDeviceRequestDocument createDeviceRequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
		PhysicalDevice device = createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0);
		
		String deviceCLLI = device.getCLLICode();
		String rack = device.getConsistsOfRackList().get(0).getCommonName();
		
		device.setCommonName(deviceCLLI + "-" + rack);
		
		exchange.getIn().setBody(createDeviceRequest);
	}

}
