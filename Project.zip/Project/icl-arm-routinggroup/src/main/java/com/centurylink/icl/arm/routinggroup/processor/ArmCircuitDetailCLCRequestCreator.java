package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmCircuitDetailCLCRequestCreator implements Processor {

	private static final Log LOG = LogFactory
			.getLog(CircuitDetailCLCCustomerRequestCreator.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_REQUEST);
		SearchResourceDetails srd = searchResourceRequestDocument
				.getSearchResourceRequest().getSearchResourceDetails();

		srd.getResourceCharacteristicValueList().clear();
		srd.setEntity(ARMRoutingConstants.LOCATION);
		srd.setLevel(ARMRoutingConstants.LOCATION);
		srd.setScope(ARMRoutingConstants.SUMMARY);
		srd.setSourceSystem(ARMRoutingConstants.CLC);
		Condition locationRole = srd.addNewFilterCriteria()
				.addNewValidationCondition().addNewEqualCondition();
		locationRole.setVariableName("ASSETVALUE");
		locationRole.setValue(srd.getCommonName());
		srd.setCommonName(null);
		// LOG.info("CLC Request for Get Circuit detail >>>>>>> " +
		// searchResourceRequestDocument);
		exchg.getIn().setBody(searchResourceRequestDocument);

	}
}
