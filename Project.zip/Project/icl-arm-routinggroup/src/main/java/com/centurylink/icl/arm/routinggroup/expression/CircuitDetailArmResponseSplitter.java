package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class CircuitDetailArmResponseSplitter implements Expression {
	private static final Log LOG = LogFactory
			.getLog(CircuitDetailArmResponseSplitter.class);

	@SuppressWarnings("unchecked")
	@Override
	public <T> T evaluate(Exchange exchg, Class<T> arg1) {
		SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) exchg
				.getIn().getBody();
		//LOG.info("searchResourceResponseDocument Resp>>>>>>>> : "+ searchResourceResponseDocument);
		exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE,searchResourceResponseDocument);
		List<String> clliList = new ArrayList<String>();

		if (searchResourceResponseDocument.getSearchResourceResponse()
				.getSearchResponseDetailsArray(0).getCircuitList().size() != 0) {

			if (searchResourceResponseDocument.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getCircuitArray(0)
					.getSncHasAEndTpsList() != null
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasAEndTpsList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasAEndTpsArray(0)
							.getAccessPointAddressList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasAEndTpsArray(0)
							.getAccessPointAddressArray(0).getCommonName() != null) {
				clliList.add(searchResourceResponseDocument
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getCircuitArray(0)
						.getSncHasAEndTpsArray(0).getAccessPointAddressArray(0)
						.getCommonName());
			}

			if (searchResourceResponseDocument.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getCircuitArray(0)
					.getSncHasZEndTpsList() != null
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasZEndTpsList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasZEndTpsArray(0)
							.getAccessPointAddressList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getSncHasZEndTpsArray(0)
							.getAccessPointAddressArray(0).getCommonName() != null) {
				clliList.add(searchResourceResponseDocument
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getCircuitArray(0)
						.getSncHasZEndTpsArray(0).getAccessPointAddressArray(0)
						.getCommonName());
			}
		}

		else if (searchResourceResponseDocument.getSearchResourceResponse()
				.getSearchResponseDetailsArray(0).getP2PCircuitList().size() != 0) {
			if (searchResourceResponseDocument.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
					.getAEndTpsList() != null
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getAEndTpsList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getAEndTpsArray(0)
							.getAccessPointAddressList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getAEndTpsArray(0)
							.getAccessPointAddressArray(0).getCommonName() != null) {
				clliList.add(searchResourceResponseDocument
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
						.getAEndTpsArray(0).getAccessPointAddressArray(0)
						.getCommonName());
			}

			if (searchResourceResponseDocument.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
					.getZEndTpsList() != null
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getZEndTpsList().size() != 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getZEndTpsArray(0)
							.getAccessPointAddressList().size() > 0
					&& searchResourceResponseDocument
							.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getZEndTpsArray(0)
							.getAccessPointAddressArray(0).getCommonName() != null) {
				clliList.add(searchResourceResponseDocument
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
						.getZEndTpsArray(0).getAccessPointAddressArray(0)
						.getCommonName());
			}
		}

		return (T) clliList;
	}

}
