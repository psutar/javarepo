package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.arm.routinggroup.predicates.PredicateHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class DiscoverTransportPathValidator implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();
		if(!PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, ARMRoutingConstants.DEVICE_NAME) && !PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, ARMRoutingConstants.CIRCUIT_NAME))
		{
			throw new ICLRequestValidationException("Device Name or Circuit Name is Required");
		}
	}

}
