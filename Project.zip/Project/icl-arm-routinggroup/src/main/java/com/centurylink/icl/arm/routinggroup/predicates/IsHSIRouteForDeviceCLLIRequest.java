package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsHSIRouteForDeviceCLLIRequest implements Predicate{
	private static final Log LOG = LogFactory.getLog(IsHSIRouteForDeviceCLLIRequest.class);
	private static final String DEVICE_CLLI_SERVICE = "DeviceCLLI";
	
	@Override
	public boolean matches(Exchange exchange) {
		SearchResourceRequestDocument requestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		SearchResourceDetails resourceDetails = requestDocument.getSearchResourceRequest().getSearchResourceDetails();
		if(resourceDetails!=null){
			List<ResourceCharacteristicValue> resourceCharacteristicValueList= resourceDetails.getResourceCharacteristicValueList();
			boolean isDeviceCLLIService = false;
			for(ResourceCharacteristicValue resourceCharacteristicValue : resourceCharacteristicValueList) {
				String characteristicName = resourceCharacteristicValue.getCharacteristicName();
				if(!StringHelper.isEmpty(characteristicName) && characteristicName.equalsIgnoreCase(DEVICE_CLLI_SERVICE)) {
					isDeviceCLLIService = true;
					break;
				}
			}
			return isDeviceCLLIService;
		}
		else {
			return false;
		}
	}

}
