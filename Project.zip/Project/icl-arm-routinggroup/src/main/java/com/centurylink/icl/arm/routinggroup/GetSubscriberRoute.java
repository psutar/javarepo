package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

public class GetSubscriberRoute extends RouteBuilder{

	private static final String getSubscriber  = "getSubscriber";
	@Override
	public void configure() throws Exception {
	
		from("direct:GetSubscriberRoute")
		.routeId("GetSubscriberRoute")
		.setHeader(methodName,constant(getSubscriber))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.removeHeader(getSubscriber);
	}

}
