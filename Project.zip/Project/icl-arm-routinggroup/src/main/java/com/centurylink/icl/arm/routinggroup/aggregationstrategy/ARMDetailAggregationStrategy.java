package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class ARMDetailAggregationStrategy implements AggregationStrategy {

	private static final Log LOG = LogFactory.getLog(ARMDetailAggregationStrategy.class);

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		SearchResourceResponseDocument armResp = null;
		if (newExchange.getException() != null) {
			newExchange.setException(null);
			newExchange.removeProperty(Exchange.EXCEPTION_CAUGHT);
			armResp = (SearchResourceResponseDocument) newExchange
					.getProperty(ARMRoutingConstants.ARM_RESPONSE);
			newExchange.getIn().setBody(armResp);
			return newExchange;
		}

		// LOG.info("CamelSplitIndex >>>>>>"+newExchange.getProperty("CamelSplitIndex",Integer.class));

		if (newExchange != null
				&& newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {

			SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) newExchange
					.getIn().getBody();
			SearchResponseDetails srd = searchResourceResponseDocument
					.getSearchResourceResponse().getSearchResponseDetailsArray(0);
			AmericanPropertyAddress clcAddress = srd.getAddressDetailsArray(0);
			//LOG.info("clcAddress in clc Resp:>>>>>>>>>" + clcAddress);

			if (oldExchange == null)
				armResp = (SearchResourceResponseDocument) newExchange
						.getProperty(ARMRoutingConstants.ARM_RESPONSE);
			else
				armResp = (SearchResourceResponseDocument) oldExchange.getIn().getBody();

			//LOG.info("armResp is:>>>>>>>>>" + armResp);
			int i = newExchange.getProperty("CamelSplitIndex", Integer.class);
			AmericanPropertyAddress apa = armResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getDeviceArray(i)
					.getInstalledAtAddress();

			if (clcAddress.getCommonName() != null)
				apa.setCommonName(clcAddress.getCommonName());

			List<CharacteristicValue> addrList = clcAddress.getRootEntityDescribedByList();
			int size = addrList.size();

			String cValue = null;
			if (size >= 1) {
				for (CharacteristicValue current : addrList) {

					if (current.getCharacteristicName() != null
							&& current.getCharacteristicName()
									.equalsIgnoreCase(ARMRoutingConstants.SWC)) {
						cValue = current.getCharacteristicValue();
					}

				}
			}

			CharacteristicValue cvNew = CharacteristicValue.Factory.newInstance();
			if (cValue != null) {
				cvNew.setCharacteristicName(ARMRoutingConstants.SWC);
				cvNew.setCharacteristicValue(cValue);
			}
			apa.getRootEntityDescribedByList().add(cvNew);

			if (clcAddress.getCLLI() != null)
				apa.setCLLI(clcAddress.getCLLI());

			if (clcAddress.getStateOrProvince() != null)
				apa.setStateOrProvince(clcAddress.getStateOrProvince());
			if (clcAddress.getLocality() != null)
				apa.setLocality(clcAddress.getLocality());
			if (clcAddress.getPostcode() != null)
				apa.setPostcode(clcAddress.getPostcode());
			if (clcAddress.getAddressLine1() != null)
				apa.setAddressLine1(clcAddress.getAddressLine1());
			if (clcAddress.getAddressLine2() != null)
				apa.setAddressLine2(clcAddress.getAddressLine2());

			newExchange.getIn().setBody(armResp);
			// LOG.info("newExchange aftere aggregation is:>>>>>>>>>"+newExchange.getIn().getBody());
		}

		return newExchange;

	}

}
