package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class GetDevicesByBuildingClliAggregationStrategy implements AggregationStrategy {

	private static final Log LOG = LogFactory.getLog(GetDevicesByBuildingClliAggregationStrategy.class);

	@SuppressWarnings("unused")
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		SearchResourceResponseDocument oldResp = null;
		SearchResourceResponseDocument newResp = null;

		if (null == oldExchange) 
		{
			return newExchange;
		}
		
		if (newExchange != null	&& newExchange.getException() == null && newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) 
		{
			newResp = (SearchResourceResponseDocument) newExchange.getIn().getBody();
			//LOG.info("Here 1");
		}

		if (oldExchange != null	&& oldExchange.getException() == null && oldExchange.getIn().getBody() instanceof SearchResourceResponseDocument) 
		{
			oldResp = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
			//LOG.info("Here 2");
		}

		if (oldResp != null && newResp != null) 
		{
			List<PhysicalDevice> DeviceList = ((SearchResourceResponseDocument) newExchange
					.getIn().getBody()).getSearchResourceResponse()
					.getSearchResponseDetailsList().get(0).getDeviceList();
			
			SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
			searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().addAll(DeviceList);
			oldExchange.getIn().setBody(searchResourceResponseDocument);
			//LOG.info("Here 3");
		}
		else if (oldResp != null && newExchange.getException() != null) 
		{
			oldExchange.getIn().setBody(oldResp);
		}	
		else if (newResp != null && oldExchange.getException() != null) 
		{
			newExchange.getIn().setBody(newResp);
			return newExchange;
		}
		else 
		{
			oldExchange.setException(new OSSDataNotFoundException());
			oldExchange.setProperty(Exchange.EXCEPTION_CAUGHT,new OSSDataNotFoundException());
			oldExchange.getIn().setBody(null);
			oldExchange.getOut().setBody(null);
		}		

		return oldExchange;
	}	

}
