package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.predicates.IsSystemTypeFound;

public class ARMGetPortStatsTrafxRoute extends RouteBuilder {	
	
	private String host;
	private String port;
	
	public ARMGetPortStatsTrafxRoute(String host, String port)
	{
		this.host = host;
		this.port = port;		
	}
	
	@Override
	public void configure() throws Exception 
	{		
		//Get Port stat from TRAFX		
		from("direct:ARMGetPortStatistics")
		.routeId("ARMGetPortStatisticsTrafx")
		.processRef("storeOrigionalRequestProcessor")
		.to("getPortStatsRequestValidator")
		.setHeader(methodName, constant("GetDeviceByPortVO"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.to("getPortStatsResponseProcessor")
		.beanRef("getPortStatsTrafx", "getSystemType")
		.choice()
			.when(new IsSystemTypeFound())
				.to("direct:GetPortStatsFromTRAFX")
		.end()
		;	
		
		from("direct:GetPortStatsFromTRAFX")
		.setProperty("host", constant(host))
		.setProperty("port", constant(port))
		.to("getPortStatsTrafxRequest")
		.beanRef(armServiceInvoker, "callTrafxTransformFromCim")
		.beanRef(armServiceInvoker, "callTrafxConnector")
		.beanRef(armServiceInvoker, "callTrafxTransformToCim")
		.beanRef("getPortStatsTrafx", "mergeMandatoryHelpTextInTrafx")
		;
		
	}

}
