package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import com.iclnbi.iclnbiV200.CreateCircuitRequest;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;

public class IsCallToCLCSearchLocation implements Predicate {

	@Override
	public boolean matches(Exchange exchange) {
		CreateCircuitRequestDocument createCircuitRequestDocument = (CreateCircuitRequestDocument)exchange.getIn().getBody();
		
		CreateCircuitRequest createCircuitRequest = createCircuitRequestDocument.getCreateCircuitRequest();
			
		if (createCircuitRequest!=null && createCircuitRequest.getCircuit()!=null
				&& createCircuitRequest.getCircuit().getResourceType().equalsIgnoreCase("HSI")){
			return true;
			}
		
		else {
		return false;
		}
	}

}
