package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetDevicesByBuildingClliRequestCreator implements Processor {

	private static final Log LOG = LogFactory.getLog(GetDevicesByBuildingClliRequestCreator.class);

	@Override
	public void process(Exchange exchange) throws Exception {

		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange
				.getProperty(ARMRoutingConstants.ARM_REQUEST);
		SearchResourceDetails srd = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();

		if (exchange.getProperty("BuildingCLLIAvailable") != null
				&& exchange.getProperty("BuildingCLLIAvailable", Boolean.class)) {

			srd.setEntity(ARMRoutingConstants.LOCATION);
			srd.setLevel(ARMRoutingConstants.LOCATION);
			srd.setScope(ARMRoutingConstants.SUMMARY);
			srd.setSourceSystem(ARMRoutingConstants.CLC);

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							ARMRoutingConstants.BUILDINGCLLI))) {
				Condition condBuildingCLLI = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condBuildingCLLI.setVariableName("BuildingCLLI");
				condBuildingCLLI
						.setValue(SearchResourceRequestDocumentReaderCIM2
								.getResourceCharacteristicValue(
										searchResourceRequestDocument
												.getSearchResourceRequest()
												.getSearchResourceDetails()
												.getResourceCharacteristicValueList(),
										"BuildingCLLI"));
			}

			Condition locationRole = srd.addNewFilterCriteria()
					.addNewValidationCondition().addNewEqualCondition();
			locationRole.setVariableName("LocationRole");
			locationRole.setValue("ES");

			//LOG.info("CLC request byBuildingCLLI for LocationName >>>>>>> "+ searchResourceRequestDocument);
			exchange.getIn().setBody(searchResourceRequestDocument);
		}

		else if (exchange.getProperty("AddressDetailsAvailable") != null
				&& exchange.getProperty("AddressDetailsAvailable",Boolean.class)) {

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"AddressNumberPrefix"))) {
				Condition condAddrNumPrfx = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condAddrNumPrfx
						.setVariableName(ARMRoutingConstants.ADDRESSNUMBERPREFIX);
				condAddrNumPrfx
						.setValue(SearchResourceRequestDocumentReaderCIM2
								.getResourceCharacteristicValue(
										searchResourceRequestDocument
												.getSearchResourceRequest()
												.getSearchResourceDetails()
												.getResourceCharacteristicValueList(),
										"AddressNumberPrefix"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"AddressNumber"))) {
				Condition condAddrNum = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condAddrNum.setVariableName(ARMRoutingConstants.ADDRESSNUMBER);
				condAddrNum.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"AddressNumber"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"AddressNumberSuffix"))) {
				Condition condAddrNumSufx = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condAddrNumSufx
						.setVariableName(ARMRoutingConstants.ADDRESSNUMBERSUFFIX);
				condAddrNumSufx
						.setValue(SearchResourceRequestDocumentReaderCIM2
								.getResourceCharacteristicValue(
										searchResourceRequestDocument
												.getSearchResourceRequest()
												.getSearchResourceDetails()
												.getResourceCharacteristicValueList(),
										"AddressNumberSuffix"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"StreetDirectionalPrefix"))) {
				Condition condStreetDirPrfx = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condStreetDirPrfx
						.setVariableName(ARMRoutingConstants.STREETDIRECTIONALPREFIX);
				condStreetDirPrfx
						.setValue(SearchResourceRequestDocumentReaderCIM2
								.getResourceCharacteristicValue(
										searchResourceRequestDocument
												.getSearchResourceRequest()
												.getSearchResourceDetails()
												.getResourceCharacteristicValueList(),
										"StreetDirectionalPrefix"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"StreetName"))) {
				Condition condStreetName = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condStreetName.setVariableName(ARMRoutingConstants.STREETNAME);
				condStreetName.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"StreetName"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"StreetType"))) {
				Condition condStreetType = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condStreetType.setVariableName(ARMRoutingConstants.STREETTYPE);
				condStreetType.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"StreetType"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"StreetDirectionalSuffix"))) {
				Condition condStreetDirSufx = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condStreetDirSufx
						.setVariableName(ARMRoutingConstants.STREETDIRECTIONALSUFFIX);
				condStreetDirSufx
						.setValue(SearchResourceRequestDocumentReaderCIM2
								.getResourceCharacteristicValue(
										searchResourceRequestDocument
												.getSearchResourceRequest()
												.getSearchResourceDetails()
												.getResourceCharacteristicValueList(),
										"StreetDirectionalSuffix"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"City"))) {
				Condition condCity = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condCity.setVariableName(ARMRoutingConstants.CITY);
				condCity.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"City"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"State"))) {
				Condition condState = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condState.setVariableName(ARMRoutingConstants.STATE);
				condState.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"State"));
			}

			if (!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2
					.getResourceCharacteristicValue(
							searchResourceRequestDocument
									.getSearchResourceRequest()
									.getSearchResourceDetails()
									.getResourceCharacteristicValueList(),
							"Zip"))) {
				Condition condZip = srd.addNewFilterCriteria()
						.addNewValidationCondition().addNewEqualCondition();
				condZip.setVariableName(ARMRoutingConstants.ZIP);
				condZip.setValue(SearchResourceRequestDocumentReaderCIM2
						.getResourceCharacteristicValue(
								searchResourceRequestDocument
										.getSearchResourceRequest()
										.getSearchResourceDetails()
										.getResourceCharacteristicValueList(),
								"Zip"));
			}

			Condition locationRole = srd.addNewFilterCriteria()
					.addNewValidationCondition().addNewEqualCondition();
			locationRole.setVariableName("LocationRole");
			locationRole.setValue("ES");

			srd.setEntity(ARMRoutingConstants.LOCATION);
			srd.setLevel(ARMRoutingConstants.LOCATION);
			srd.setScope(ARMRoutingConstants.SUMMARY);
			srd.setSourceSystem(ARMRoutingConstants.CLC);
			//LOG.info("CLC request byAddressDetail for LocationName >>>>>>> "+ searchResourceRequestDocument);
			exchange.getIn().setBody(searchResourceRequestDocument);

		}
	}

}
