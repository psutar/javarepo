package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;

import com.iclnbi.iclnbiV200.DeleteCircuitRequestDocument;

public class DeleteTransportPathValidator implements Processor
{	
	
//	private static final Log LOG = LogFactory.getLog(DeleteTransportPathValidator.class);
	
	@Override
	public void process(Exchange exchange) throws Exception 
{		
		DeleteCircuitRequestDocument deleteCircuitRequestDocument = (DeleteCircuitRequestDocument) exchange.getIn().getBody();
		
		if(StringHelper.isEmpty(deleteCircuitRequestDocument.getDeleteCircuitRequest().getCircuit().getCommonName()))
			throw new ICLRequestValidationException("At least one Common Name is required for this request");
	}	
}
