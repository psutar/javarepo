package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;



public class TransportRouteSplitter implements Expression{

	private static final Log LOG = LogFactory.getLog(TransportRouteSplitter.class);

  @SuppressWarnings("unchecked")
  @Override
  public <T> T evaluate(Exchange exchg, Class<T> arg1) {
	  
    SearchResourceRequestDocument searchResourceRequestDocument;
    List<SearchResourceRequestDocument> individualDeviceRequestList = new ArrayList<SearchResourceRequestDocument>();
    SearchResourceDetails searchResourceDetails;
    
    List<String> body = (List<String>) exchg.getIn().getBody();
    for (String route : body) {
    
    	searchResourceRequestDocument = SearchResourceRequestDocument.Factory.newInstance();
    	SearchResourceRequest  searchResourceRequest = searchResourceRequestDocument.addNewSearchResourceRequest();
    	searchResourceRequest.addNewMessageElements();
    	searchResourceDetails = searchResourceRequest.addNewSearchResourceDetails();

    	searchResourceDetails.setScope("DETAILED");

    	searchResourceDetails.setSourceSystem("ARM");

    	searchResourceDetails.setLevel("Route");
    	
    	searchResourceDetails.setCommonName(route);

    	

    	individualDeviceRequestList.add(searchResourceRequestDocument);
    	
    }
    LOG.debug("individualDeviceRequestList : " + individualDeviceRequestList.size());
    return (T)individualDeviceRequestList;
  }



}
