package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.PhysicalDevice;

public class CreateDeviceClliValidator implements Processor{	
	
	@Override
	public void process(Exchange exchange) throws Exception {		
		CreateDeviceRequestDocument createDeviceRequestDocument = (CreateDeviceRequestDocument) exchange.getIn().getBody();
		
		PhysicalDevice physicalDevice = createDeviceRequestDocument.getCreateDeviceRequest().getDeviceList().get(0);
		
		if(null == physicalDevice)
		{
			throw new ICLRequestValidationException("Device is required for this request");
		}
		
		String locationClli = physicalDevice.getLocationCLLI();
		
		if(locationClli == null || locationClli.length() < 1)
			throw new ICLRequestValidationException("Location Clli is required for this operation");
		if(locationClli.length() != 8)
			throw new ICLRequestValidationException("Location Clli must be 8 characters in length");
		
		String resourceSubType = physicalDevice.getResourceSubType();
		if(resourceSubType == null || resourceSubType.length() < 1)
			throw new ICLRequestValidationException("Resource Sub Type is required for this operation");
		
	}	
}
