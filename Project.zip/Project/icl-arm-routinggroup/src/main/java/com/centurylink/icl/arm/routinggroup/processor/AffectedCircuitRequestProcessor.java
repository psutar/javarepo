package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class AffectedCircuitRequestProcessor implements Processor
{
	private static final Log LOG = LogFactory.getLog(AffectedCircuitRequestProcessor.class);
	@Override
	public void process(Exchange exchg) throws Exception 
	{	
		exchg.setProperty(ARMRoutingConstants.ARM_REQUEST, exchg.getIn().getBody());
		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg.getIn().getBody();
		String deviceName = null;
		String deviceClliValue= null;
		
		deviceName = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), ARMRoutingConstants.DEVICE_NAME);		
		deviceClliValue = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), ARMRoutingConstants.DEVICE_CLLI);
		
		if(StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(deviceClliValue))
		{
			throw new ICLRequestValidationException("Device Name or DeviceCLLI Required");
		}
	}

}
