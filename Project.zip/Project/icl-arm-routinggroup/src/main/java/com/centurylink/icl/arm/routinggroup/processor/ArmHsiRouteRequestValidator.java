package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmHsiRouteRequestValidator implements Processor{
	private static final Log LOG=LogFactory.getLog(ArmHsiRouteRequestValidator.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		
		String deviceName = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "DeviceName");
		String sVlan = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "SVLAN");
		String deviceCLLI = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "DeviceCLLI");
		
		SearchResourceDetails resourceDetails = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		if(resourceDetails!=null){
			List<ResourceCharacteristicValue> resourceCharacteristicValueList= resourceDetails.getResourceCharacteristicValueList();
			for(ResourceCharacteristicValue resourceCharacteristicValue : resourceCharacteristicValueList) {
				String characteristicName = resourceCharacteristicValue.getCharacteristicName();
				if(!StringHelper.isEmpty(characteristicName) && characteristicName.equalsIgnoreCase("DeviceCLLI")
						&& StringHelper.isEmpty(deviceCLLI)) {
					throw new ICLRequestValidationException("DeviceCLLI value cannot be null or empty when DeviceCLLI is mentioned in the request.");
				}
			}
		}
		
				
		if(!StringHelper.isEmpty(deviceCLLI)){
			exchange.setProperty("DeviceCLLI", deviceCLLI);
		}else {
			if(StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(sVlan)){
				throw new ICLRequestValidationException("DeviceName and SVLAN are required");
			}				
			exchange.setProperty("VLANNumber", sVlan);
			exchange.setProperty("DeviceName", deviceName);		
		}
	}
}
