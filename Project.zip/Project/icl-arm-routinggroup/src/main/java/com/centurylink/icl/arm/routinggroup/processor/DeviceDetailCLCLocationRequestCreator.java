package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;

import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class DeviceDetailCLCLocationRequestCreator implements Processor
{
	private static final Log LOG = LogFactory.getLog(DeviceDetailCLCLocationRequestCreator.class);

	@Override
	public void process(Exchange exchg) throws Exception 
	{
		PhysicalDevice pd = (PhysicalDevice)exchg.getIn().getBody();
		
		/*
		 * TODO: We need a better way of handling this but have stuck this 'Hack' in for now to get around a production 
		 * issue. Basically I'm making a copy of the original request rather than using the origRequest strait from the exchange 
		 * because during a split where you have parellelProcessing it still only has a single exchange so the objects that are 
		 * stored in the properties are the same objects. Changing it in one "Split Process" actually updates it in all Split Processes. 
		 * This was causing very inconsistent issues in this class so please don't remove this. 
		 */
		SearchResourceRequestDocument origRequest = (SearchResourceRequestDocument)exchg.getProperty(ARMRoutingConstants.ARM_REQUEST);
		SearchResourceRequestDocument searchResourceRequestDocument = SearchResourceRequestDocument.Factory.parse(origRequest.toString());
		
		SearchResourceDetails srd = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		srd.setCommonName(pd.getInstalledAtAddress().getCommonName());
		srd.setEntity(ARMRoutingConstants.LOCATION);
		srd.setLevel(ARMRoutingConstants.LOCATION);		
		srd.setScope(ARMRoutingConstants.DETAILED);
		srd.setSourceSystem(ARMRoutingConstants.CLC);
		LOG.info("CLLI request for Device detail >>>>>>> " + searchResourceRequestDocument);
		exchg.getIn().setBody(searchResourceRequestDocument);
	}
	
	
}
