package com.centurylink.icl.arm.routinggroup.expression;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;

import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class CircuitOrDeviceSplitter implements Expression{

	@Override
	public <T> T evaluate(Exchange exchange, Class<T> arg1) {
		
		SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) exchange.getIn().getBody();
		Set<String> uniqueCustomers = new HashSet<String>();
		if( searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().size() > 0 )
		{
			List<SubNetworkConnection> circuitList = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList();
			if(circuitList != null && circuitList.size() > 0)
			{
				for (SubNetworkConnection subNetworkConnection : circuitList) {
					
					OwnsResourceDetails ownsResourceDetails = subNetworkConnection.getOwnsResourceDetails();
					if(ownsResourceDetails != null && ownsResourceDetails.getCustomerList() != null && ownsResourceDetails.getCustomerList().size() > 0)
					{
						List<Customer> customerList = ownsResourceDetails.getCustomerList();
						if(customerList != null && customerList.size() > 0 )
							uniqueCustomers.add(customerList.get(0).getCommonName());
					}
					
				}
				return (T)uniqueCustomers;
			}
		
			List<PhysicalDevice> deviceList = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList();
			if(deviceList != null && deviceList.size() > 0)
			{
				
				for (PhysicalDevice physicalDevice : deviceList) {
					
					OwnsResourceDetails ownsResourceDetails = physicalDevice.getOwnsResourceDetails();
					if(ownsResourceDetails != null && ownsResourceDetails.getCustomerList() != null && ownsResourceDetails.getCustomerList().size() > 0)
					{
						List<Customer> customerList = ownsResourceDetails.getCustomerList();
						if(customerList != null && customerList.size() > 0 )
							uniqueCustomers.add(customerList.get(0).getCommonName());
					}
					
				}
				return (T)uniqueCustomers;
			}
		}
		
		return (T)uniqueCustomers; // return the blank Set<String> if no circuits / devices found in the response
	}
}

