package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.lang3.EnumUtils;
import java.util.ArrayList;
import java.util.List;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

public class IsDeviceNameNotFound implements Predicate {

    private enum GPON_DEVICE_ROLES {
       ONT, OLT, SPLITTER, MST, FDP, FDH, MDU 
    }

	@Override
	public boolean matches(Exchange exchange) {
		CreateDeviceRequestDocument createDeviceRequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
		
		//Start - Added for GPON
		int resourceDescribedBySize = 0;
		List<String> deviceRoleList = new ArrayList<String>();
		if(createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList() != null && 
		    createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList().size()> 0)
		{
		    resourceDescribedBySize =
            createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList().size();
		}
        for (int i = 0; i < resourceDescribedBySize; i++) {
          deviceRoleList.add(createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList()
              .get(i).getCommonName());
        }
		boolean isGPONDevice = checkIfGponDevice(deviceRoleList);
		
		if(isGPONDevice){
		    return false;
		}
		//End - Added for GPON
		
		if (StringHelper.isEmpty(createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getCommonName()))
			return true;
		else
			return false;
	}
	
	public boolean checkIfGponDevice(List<String> deviceRoles) {
    for (String role : deviceRoles) {
      if (EnumUtils.isValidEnum(GPON_DEVICE_ROLES.class, role)) {
        return true;
      }
    }
    return false;
  }

}
