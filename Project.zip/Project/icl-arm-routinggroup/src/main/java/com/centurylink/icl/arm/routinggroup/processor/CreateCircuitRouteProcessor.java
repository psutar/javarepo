package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;

import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;

public class CreateCircuitRouteProcessor implements Processor 
{
	final ProducerTemplate producerTemplate;
	
	public CreateCircuitRouteProcessor(CamelContext ctx)
	{
		this.producerTemplate = ctx.createProducerTemplate();	
	}

	@Override
	public void process(Exchange exchg) throws Exception 
	{
		CreateCircuitRequestDocument in = (CreateCircuitRequestDocument)
				exchg.getIn().getBody();
		
		if(in.getCreateCircuitRequest().getP2PCircuitList().get(0).getResourceType()
				.equalsIgnoreCase("NMI"))
			producerTemplate.send("direct:ARMCreateLAG_NMIRoute",exchg);
		else if(in.getCreateCircuitRequest().getP2PCircuitList().get(0).getResourceType()
				.equalsIgnoreCase("UNI/ENNI"))
			producerTemplate.send("direct:ARMCreateUNI_ENNIRoute",exchg);		
		else if(in.getCreateCircuitRequest().getP2PCircuitList().get(0).getResourceType()
				.equalsIgnoreCase("EVC/OVC"))
			producerTemplate.send("direct:ARMCreateEvcOvcRoute",exchg);
			
	}

}
