package com.centurylink.icl.arm.routinggroup.predicates;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class PredicateHelper {


	public static String getNVP(SearchResourceRequestDocument request,String characteristicName)
	{
		
		for (ResourceCharacteristicValue current : request.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return current.getCharacteristicValue();
			}
		}
		return null;
	}
	
	public static boolean checkCharacteristicName(SearchResourceRequestDocument request,String characteristicName)
	{
		
		for (ResourceCharacteristicValue current : request.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return true;
			}
		}
		return false;
	}

}
