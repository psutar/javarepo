package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;


public class CreateDeviceValidationProcessor implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		
		CreateDeviceRequestDocument createDeviceRequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
		String locationname= createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getInstalledAtAddress().getCommonName();
		
		if(StringHelper.isEmpty(locationname))
			throw new ICLRequestValidationException("Locationame value is mandatory in the request");
		
	}

}
