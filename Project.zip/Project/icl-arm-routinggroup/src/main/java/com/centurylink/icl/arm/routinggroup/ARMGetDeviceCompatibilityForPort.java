package com.centurylink.icl.arm.routinggroup;

import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.util.tracker.ServiceTracker;

import com.centurylink.icl.arm.domainlayer.devices.Device;
import com.centurylink.icl.arm.domainlayer.devices.DeviceFactory;
import com.centurylink.icl.arm.exception.ARMException;
import com.centurylink.icl.arm.exception.ARMInventoryException;
import com.centurylink.icl.arm.persistancelayer.ARMTransactionContext;
import com.centurylink.icl.arm.persistancelayer.ARMTransactionManager;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.xref.connector.interfaces.XrefLookupServiceInterface;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class ARMGetDeviceCompatibilityForPort {
private ServiceTracker xrefTracker;
    
    private static final Log LOG = LogFactory.getLog(ARMGetDeviceCompatibilityForPort.class);
    
    public ARMGetDeviceCompatibilityForPort(BundleContext bundleContext) throws Exception
    {
		Filter filter = bundleContext.createFilter("(&(name=xrefLookupService))");
		xrefTracker = new ServiceTracker(bundleContext, filter, null);
		
		xrefTracker.open();
    }
    
    public void close()
    {
    	xrefTracker.close();
    }
     
    public void updateForDualInventoried(Exchange exchange) throws Exception
 {
		String nodeDefName = exchange.getProperty("NODE_DEF_NAME", String.class);

		if (xrefTracker == null)
			throw new ICLException("Xref Service Tracker is not Running");
		
		/*Insert into network role*/
		//LOG.info("Before Network role update");
		ARMTransactionContext ctx = ARMTransactionManager.startTransaction("ctx");
    	Device device = DeviceFactory.newDevice();
		try {
			device.createNetworkRole("MSAP");
			ctx.commit();
		} catch (ARMException e) {
			e.printStackTrace();
			ctx.rollback();
		} catch (ARMInventoryException e) {
			e.printStackTrace();
			ctx.rollback();
		}
		//LOG.info("After Network role update");

		XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
		String msapStaus = (String) exchange.getProperty("MSAP_ELIGIBLE");
		String allowableRole = (String) exchange.getProperty("ALLOWABLE_ROLE");
		LOG.info(" MSAP_ELIGIBLE status: "+msapStaus+"   ALLOWABLE_ROLE : "+allowableRole);
		if (!"Y".equalsIgnoreCase(msapStaus)) {
			lookupService.updateRow("DEVICE_COMPATIBILITY", "MSAP_ELIGIBLE",
					"Y", "NODE_DEF_NAME", nodeDefName);
		}
		if (!allowableRole.contains("MSAP")) {
			allowableRole = allowableRole + ",MSAP";
			lookupService.updateRow("DEVICE_COMPATIBILITY", "ALLOWABLE_ROLE",
					allowableRole, "NODE_DEF_NAME", nodeDefName);
		}
		// exchange.setProperty("DeviceDualInventory",
		// (String)rowData.get("MSAP_ELIGIBLE"));

	}
    
    public void fetchDeviceParams(Exchange exchange) throws Exception
    {
    	LOG.info("###inside fetchDeviceParams() method ###");
    	
    	
    	String deviceQuery = buildQuery(exchange);
    	LOG.info("###deviceQuery : "+deviceQuery);
    	
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	String node2NodeDef = null;
    	Map<String, String> rowDataDevice = lookupService.getDetails(deviceQuery);
    	LOG.info("rowDataDevice   :"+ rowDataDevice);
    	if(rowDataDevice != null && rowDataDevice.size() >0){
    		//node2NodeDef = (String)rowDataDevice.get("NODE2NODEDEF");
    		//deviceName = (String)rowDataDevice.get("NAME");
    		LOG.info("NODE2NODEDEF : "+rowDataDevice.get("NODE2NODEDEF")+"  DEVICE_NAME  :"+rowDataDevice.get("NAME"));
    		exchange.setProperty("NODE2NODEDEF", (String)rowDataDevice.get("NODE2NODEDEF") != null ? (String)rowDataDevice.get("NODE2NODEDEF") : null);
    		exchange.setProperty("DEVICE_NAME", (String)rowDataDevice.get("NAME") != null ? (String)rowDataDevice.get("NAME") : null);
    	}else{
    		
    		throw new ICLException("Device Not Found"); //Prateek : Added if device not existing
    	}
    }
    
    public void checkDeviceCompatibility(Exchange exchange) throws Exception
    {
    	LOG.info("###inside checkDeviceCompatibility method ###");
    	
    	Boolean deviceCompStatus = false;
    	
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	
    	String node2NodeDef = null;
    	if(exchange.getProperty("NODE2NODEDEF") != null && !StringHelper.isEmpty(exchange.getProperty("NODE2NODEDEF", String.class))){
    		node2NodeDef = exchange.getProperty("NODE2NODEDEF", String.class) ;
	    	LOG.info("node2NodeDef :"+node2NodeDef);
	    }
    	   	
    	
    	if(node2NodeDef != null){
    	String query = "select DEVICE_COMPATIBILITY_ID,MSAP_ELIGIBLE,ALLOWABLE_ROLE,NODE_DEF_NAME from DEVICE_COMPATIBILITY where node_def_id='"+node2NodeDef+"'";
    	
    	Map<String, String> rowData = lookupService.getDetails(query);
    	    	
    	LOG.info("rowData: " + rowData);
    	if(rowData != null && rowData.size() >0){
	    		deviceCompStatus = true;    		
	    		exchange.setProperty("MSAP_ELIGIBLE", (String)rowData.get("MSAP_ELIGIBLE") != null ? (String)rowData.get("MSAP_ELIGIBLE") : null);
	    		exchange.setProperty("ALLOWABLE_ROLE", (String)rowData.get("ALLOWABLE_ROLE") != null ? (String)rowData.get("ALLOWABLE_ROLE") : null);  
	    		exchange.setProperty("NODE_DEF_NAME", (String)rowData.get("NODE_DEF_NAME") != null ? (String)rowData.get("NODE_DEF_NAME") : null);
    		}
    	}
    	LOG.info("Device compatibility Status  :"+deviceCompStatus);
    	exchange.setProperty("deviceCompStatus", deviceCompStatus);
    	
    }
    
    public void checkIsDeviceDualInventoried(Exchange exchange)
    {
    	String nodeDefName = null;
    	
    	if(exchange.getProperty("DEVICE_NAME")!=null && !StringHelper.isEmpty((String)exchange.getProperty("DEVICE_NAME")))
    		nodeDefName = (String)exchange.getProperty("DEVICE_NAME");
    		
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	
    	String query = "select dc.DEVICE_COMPATIBILITY_ID,dc.MSAP_ELIGIBLE,dc.ALLOWABLE_ROLE,dc.NODE_DEF_NAME from DEVICE_COMPATIBILITY dc, NODE n where n.node2nodedef=dc.node_def_id and n.NAME='"+nodeDefName+"'";
    	
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	Map<String, String> rowData = lookupService.getDetails(query);
    	    	
    	LOG.info("rowData: " + rowData);
    	if(rowData != null && rowData.size() >0){
    		if(!StringHelper.isEmpty((String)rowData.get("MSAP_ELIGIBLE")) 
    				&& ((String)rowData.get("MSAP_ELIGIBLE")).equalsIgnoreCase("Y")){
    			exchange.setProperty("DeviceDualInventory",(String)rowData.get("MSAP_ELIGIBLE"));
    		}
	      }
    }
    
    public void forNonCompatibleDevice(Exchange exchange){
    	throw new ICLException("Node_Def not found in Device_Compatibility");
    }
    
   String buildQuery(Exchange exchange){
	   String deviceName = null;
		String deviceCLLI = null;
		String alias1 = null;
		String alias2 = null;
		String networkName = null;
		
		String query = "select n.name,n.node2nodedef from node n, ext_device_type edt where n.nodeid = edt.nodeid ";
		
	    if(exchange.getProperty("DEVICE_NAME") != null && !StringHelper.isEmpty(exchange.getProperty("DEVICE_NAME", String.class))){
	    	deviceName = exchange.getProperty("DEVICE_NAME", String.class) ;
	    	LOG.info("deviceName :"+deviceName);
	    	query = query+"  and n.name ='"+deviceName+"'";
	    }
	    if(exchange.getProperty("DEVICE_CLLI") != null && !StringHelper.isEmpty(exchange.getProperty("DEVICE_CLLI", String.class))){
	    	deviceCLLI = exchange.getProperty("DEVICE_CLLI", String.class);	   
	    	LOG.info("deviceCLLI :"+deviceCLLI);
	    	query = query+"  and edt.clli ='"+deviceCLLI+"'";
	    }
		if(exchange.getProperty("ALIAS1") != null  && !StringHelper.isEmpty( exchange.getProperty("ALIAS1", String.class))){
			alias1 = exchange.getProperty("ALIAS1", String.class);
			LOG.info("alias1 :"+alias1);
			query = query+"  and n.alias1 ='"+alias1+"'";
		}
		if(exchange.getProperty("ALIAS2") != null  && !StringHelper.isEmpty( exchange.getProperty("ALIAS1", String.class))){
			alias2 = exchange.getProperty("ALIAS2", String.class); 
			LOG.info("alias2 :"+alias2);
			query = query+"  and n.alias2 ='"+alias2+"'";
		}
		if(exchange.getProperty("NETWORK_NAME") != null  && !StringHelper.isEmpty( exchange.getProperty("ALIAS1", String.class))){
			networkName = exchange.getProperty("NETWORK_NAME", String.class); 
			LOG.info("networkName :"+networkName);
			query = query+"  and edt.networkname ='"+networkName+"'";
		}
		
		return query;
    	
    }
    
    
}

