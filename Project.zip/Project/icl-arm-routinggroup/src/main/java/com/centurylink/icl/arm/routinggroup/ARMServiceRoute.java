package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.exchangeProperty;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.EnrichCreateCircuitWithCLCLocationResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.DeviceResponseAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.EnrichCreateDeviceWithCLCLocationResponse;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.EnrichCreateDeviceWithGeneratedCLLI;
import com.centurylink.icl.arm.routinggroup.expression.DeviceNamesSplitter;
import com.centurylink.icl.arm.routinggroup.predicates.CheckConsumerForPortSync;
import com.centurylink.icl.arm.routinggroup.predicates.CheckDeviceCompatibilityForPortSync;
import com.centurylink.icl.arm.routinggroup.predicates.IsCreateCityRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceCLLINotFound;
import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceNameNotFound;
import com.centurylink.icl.arm.routinggroup.predicates.IsHSIRouteForDeviceCLLIRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsHSIServiceRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsIPTVServiceRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsPONServiceRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsCallToCLCSearchLocation;
import com.iclnbi.iclnbiV200.UpdateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.UpdateDeviceResponseDocument;

public class ARMServiceRoute extends RouteBuilder {
	
	private static final Log LOG = LogFactory.getLog(ARMServiceRoute.class);

	
	 static final String CreateLocationMDW					= "ArmCreateLocation";
	 static final String CreateDeviceMDW					= "ArmCreateDevice";
	 static final String SearchLocationMDW					= "ArmSeachLocation";
	 static final String UpdateDeviceMDW					= "ArmUpdateDevice";
	 static final String DeleteDeviceMDW					= "ArmDeleteDevice";
	 static final String UpdateCircuitMDW					= "ArmUpdateCircuit";
	 static final String CreateCircuitMDW					= "ArmCreateCircuit";
	 static final String DeleteCircuitMDW					= "ArmDeleteCircuit";
	 static final String SearchLocForEquipment				= "SEARCHLOCATIONFOREQUIPMENT";
	 static final String UpdateTerminationPointMDW			= "ArmUpdateTerminationPoint";
	 private static final String UpdateDevice				= "UpdateDevice";
	 private static final String DeleteDevice				= "DeleteDevice";
	 private static final String ArmLookup					= "ArmLookup";	
     private static final String CREATE_DEVICE_INSTALL_DETAIL					= "CREATEDEVICEINSTALLDETAIL";	 
	 
	 static final String SEARCH_LOCATION_ROUTE   			= "direct:SearchLocationARM";
	 static final String CREATE_LOCATION_ROUTE  			= "direct:CreateLocationARM";
	 static final String LOOKUP_ARM_ROUTE					= "direct:LookupARM";
	 static final String DELETE_LOCATION_ROUTE              = "direct:DeleteLocationARM";
	 static final String UPDATE_LOCATION_ROUTE              = "direct:UpdateLocationARM";
	 static final String CREATE_PARTY_ROUTE  		      	= "direct:CreatePartyARM";
	 static final String DELETE_PARTY_ROUTE                 = "direct:DeletePartyARM";
	 static final String UPDATE_PARTY_ROUTE                 = "direct:UpdatePartyARM";
	 static final String ConsumeNumberObjMDW                = "ArmConsumeNumberObject";
	 static final String ReleaseNumberObjMDW                = "ArmReleaseNumberObject";
	 
	 private Integer maxConcurrentConsumers = null;
	 
public void setMaxConcurrentConsumers(Integer maxConcurrentConsumers) {
	this.maxConcurrentConsumers = maxConcurrentConsumers;
}	 
	   
	@Override
	public void configure() throws Exception 
	{					
		from("direct:SearchDeviceRoute")
		.routeId("SearchDeviceRoute")
		.to("bean:searchDeviceOperationProcessor");
		
		
		//Create Bulk Devices
		
		from("activemq:queue:icl.bulkdeviceRequest.in")
				.log("Got bulk device request in")
				.id("CreateBulkDeviceListionerRoute")
				.wireTap("direct:bulkDeviceSplitterRoute")
		.end();
		
		from("direct:bulkDeviceSplitterRoute")
			.id("bulkDeviceSplitterRoute")
			.split().method("CreateBulkDevicesplitter", "splitDevices")
			.to("direct:CreateBuildDeviceProcessorRoute")
		.end();
		 
		 from("direct:CreateBuildDeviceProcessorRoute")
		 		.id("CreateBuildDeviceProcessorRoute")
		 		.log("Received message here" + System.currentTimeMillis())
		 		.processRef("bulkCreateDeviceRequestProcessor")
		 		.to("direct:ARMDeviceCreate")
		 		.log("Completed single device create")
		 		.to("activemq:queue:icl.bulkdeviceResponse.out")
		 		.log("Completed adding to .out queue")
		.end();
		
			
		
		
		//Create single Device
		from("direct:ARMDeviceCreate")
			.id("CreateDevice")
			.to("CreateDeviceValidationProcessor")
			.enrich("direct:SearchLocationInCLC", new EnrichCreateDeviceWithCLCLocationResponse())
			.choice()
				.when(new IsDeviceCLLINotFound())
					.beanRef("validateDeviceForAutoCreate", "isAutoCreateCLLI")
					.enrich("direct:CreateDeviceClliPostValidation", new EnrichCreateDeviceWithGeneratedCLLI())
			.end()
			.choice()
				.when(new IsDeviceNameNotFound())
					.processRef("createDeviceBuildName")
			.end()
			.setHeader(methodName, constant(CreateDeviceMDW))
			.to("bean:createDeviceRequestValidatorProcessor")
			.choice()
				.when(property("REQUEST_TYPE").isEqualTo("BULKDEVICE"))
					.log("about to send device create to arm ml")
					.beanRef("armMlServiceInvoker", "invokeAmlService")
				.otherwise()
					.log("about to send device create to mdw")
					.beanRef(armServiceInvoker, "callConnectorMDW")
			.end()
			.log("at the end of ARMDeviceCreate")
		.end();
		
		from("direct:SearchLocationInCLC")
		.setHeader(methodName, constant(SearchLocForEquipment))
		.beanRef("CLCSearchLocRequestCreator")
		.beanRef("armServiceInvoker", "callConnectorCLC")
		.end();
				
		/*from("direct:UpdateDeviceARM")
		.id(UpdateDevice)
		.setHeader(methodName, constant(UpdateDeviceMDW))
		.process(setRequestInExchangePropertyForPortSync) // Added for portSync
		.beanRef(armServiceInvoker, "callConnectorMDW")
		.to("direct:portSyncAuditLogInsert")
		.end();*/
		
		from("direct:UpdateDeviceARM")
              .id(UpdateDevice)    
              .processRef("storeOrigionalRequestProcessor")
              .processRef("createMapToUpdateInvDetails")
              .to("direct:UpdateLocationInCLC")
              .processRef("storeOrigionalRequestProcessorForCLC")
              .beanRef("armGetDeviceCompatibilityForPort","fetchDeviceParams")//Fetches the device parameters and strores in exchange
              .choice()
              .when(new CheckConsumerForPortSync()) //checks if req from ISYS
               .beanRef("armGetDeviceCompatibilityForPort","checkDeviceCompatibility") //Checks device compatibility and stores values & Flags
	           .to("direct:UpdateDeviceForISYS") //route for isys specific devices
              .otherwise()
               .to("direct:callUpdateDeviceARM") // route for non isys specific devices DSP,OV
              .end();
            
             from("direct:UpdateDeviceForISYS")
             .id("UpdateDeviceForISYS")
             .choice()
	              .when(new CheckDeviceCompatibilityForPortSync()) //Checks for the compatible flag set earlier
	               .beanRef("armGetDeviceCompatibilityForPort","updateForDualInventoried")
	               .to("direct:callUpdateDeviceARM") //Specific route for ISYS/port sync devices which sets values in invoker
	              .otherwise()
	               .beanRef("armGetDeviceCompatibilityForPort","forNonCompatibleDevice")
	          .end();
             
			
			from("direct:callUpdateDeviceARM")//
			.id("callUpdateDeviceARM")
              .setHeader(methodName, constant(UpdateDeviceMDW))             
              .process(setRequestInExchangePropertyForPortSync) // Added for portSync           
              .beanRef(armServiceInvoker, "callConnectorMDW")        
              .to("direct:portSyncAuditLogInsert")            
              .end();
              
		
              from("direct:UpdateLocationInCLC")
              .routeId("UpdateLocationInCLC")          
              .setHeader(methodName, constant(CREATE_DEVICE_INSTALL_DETAIL))                           
              .beanRef("armServiceInvoker", "callConnectorForUpdateAddressCLC")
              .end();
		
		//Delete Device
		from("direct:DeleteDeviceARM")
		.id(DeleteDevice)
		.setHeader(methodName, constant(DeleteDeviceMDW))
		.beanRef(armServiceInvoker, "callConnectorMDW")
		.end();
		
		//Create Circuit
		from("direct:CreateCircuitARM")
			.routeId("ARMCreateCircuit")
			.processRef("storeOrigionalRequestProcessor")
			.to("bean:createCircuitRequestValidationProcessor")
				.choice()     
					.when(new IsCallToCLCSearchLocation())
					.enrich("direct:SearchLocationInCLC", new EnrichCreateCircuitWithCLCLocationResponse())
				.end()
			.setHeader(methodName, constant(CreateCircuitMDW))
			.beanRef(armServiceInvoker, "callConnectorMDW")
			.wireTap("direct:AddCircuitContactAndLocation")							
		.end();
		
		from("direct:AddCircuitContactAndLocation")
		 .routeId("AddCircuitContactAndLocation")
			.multicast()
				.to("direct:AddCircuitContacts", "direct:CallAddCircuitLocation")
		.end();
		
		from("direct:CallAddCircuitLocation")
		 .routeId("CallAddCircuitLocation")
			.choice()	
				.when(property("IsUNIENNIRequest").isEqualTo(Boolean.TRUE))
					.to("direct:AddCircuitLocation")
			.end()
		.end();		
		
		from("direct:AddCircuitLocation")
		 .routeId("AddCircuitLocation")
			.processRef("createInvAssetLocationRequest")
			.beanRef(armServiceInvoker, "callInventoryAssetConnector")
		.end();
		
		from("direct:DeleteCircuitLocation")
		 .routeId("DeleteCircuitLocation")
			.processRef("updateInvAssetLocationRequest")
			.beanRef(armServiceInvoker, "callInventoryAssetConnector")
		.end();
		
		from("direct:UpdateCircuitLocation")
		 .routeId("UpdateCircuitLocation")
			.multicast()
			.to("direct:DeleteCircuitLocation", "direct:AddCircuitLocation");
		
		from("direct:DeleteCircuitContacts")
			.routeId("DeleteCircuitContacts")
			.processRef("updateInvAssetContactRequest")
			.beanRef(armServiceInvoker, "callInventoryAssetConnector")
			.end();

		from("direct:AddCircuitContacts")
			.routeId("AddCircuitContacts")
			.processRef("createInvAssetContactRequest")
			.beanRef(armServiceInvoker, "callInventoryAssetConnector")
			.end();
			
		from("direct:UpdateCircuitContacts")
			.routeId("UpdateCircuitContacts")
			.multicast()
			.to("direct:DeleteCircuitContacts", "direct:AddCircuitContacts");
		
		from("direct:CallUpdateCircuitLocation")
		 .routeId("CallUpdateCircuitLocation")
			.choice()	
				.when(property("IsUpdateUNIENNIRequest").isEqualTo(Boolean.TRUE))
					.to("direct:UpdateCircuitLocation")
				.when(property("IsDisconnectUNIENNIRequest").isEqualTo(Boolean.TRUE))
					.to("direct:DeleteCircuitLocation")					
			.end()
		.end();		
		
		from("direct:UpdateCircuitContactAndLocation")
		 .routeId("UpdateCircuitContactAndLocation")
			.multicast()
				.to("direct:UpdateCircuitContacts", "direct:CallUpdateCircuitLocation")
		.end();		
		
		//Update Circuit
		from("direct:UpdateCircuitARM")
		 .routeId("direct:UpdateCircuitARM")
			.processRef("validateUNIENNIRequestProcessor")
			.setHeader(methodName, constant(UpdateCircuitMDW))
			.beanRef(armServiceInvoker, "callConnectorMDW")
			.wireTap("direct:UpdateCircuitContactAndLocation")			
		.end()
		;
		
		//Delete Circuit
		from("direct:DeleteCircuitARM")
		.routeId("DeleteCircuit")
		.setHeader(methodName, constant(DeleteCircuitMDW))
		.beanRef(armServiceInvoker, "callConnectorMDW");
		
		from("direct:ARMDetailedScopeRoute")
		.routeId("ARMDetailedScope")
		.to("bean:detailedScopeRouteProcessor");
		
		//Search Location
		from(SEARCH_LOCATION_ROUTE)
		.id("SearchLocation")
		.setHeader(methodName,constant("SearchLocation"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.end();
				
		//Create Location
		from(CREATE_LOCATION_ROUTE)
		.id("CreateLocation")
		.choice()
			.when(new IsCreateCityRequest())
				.setHeader(methodName, constant("CreateLocation"))
				.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
			.otherwise()
				.setHeader(methodName, constant(CreateLocationMDW))
				.beanRef(armServiceInvoker, "callConnectorMDW")
		.end();
		
		//Delete Location
		from(DELETE_LOCATION_ROUTE)
		.id("DeleteLocation")
		.setHeader(methodName, constant("DeleteLocation"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
		
		//Update Location
		from(UPDATE_LOCATION_ROUTE)
		.id("UpdateLocation")
		.setHeader(methodName, constant("UpdateLocation"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
				
		//Lookup -- Device,Location
		from(LOOKUP_ARM_ROUTE)
		.id(ArmLookup)
		.setHeader(methodName,constant(ArmLookup))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
	
		//Get UNI related EVC from internal ARM Mediation layer
		from("direct:GetUNIRelatedEVCDetailsRoute")
		.id("GetUNIRelatedEVCDetailsRoute")
		.setHeader(methodName,constant("GetUNIRelatedEVCDetails"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.removeHeader("GetUNIRelatedEVCDetails")
		.end();	
		
		//Create Party
		from(CREATE_PARTY_ROUTE)
		.id("CreateParty")
		.setHeader(methodName, constant("CreateParty"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
		
		//Delete Party
		from(DELETE_PARTY_ROUTE)
		.id("DeleteParty")
		.setHeader(methodName, constant("DeleteParty"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
		
		//Update Party
		from(UPDATE_PARTY_ROUTE)
		.id("UpdateParty")
		.setHeader(methodName, constant("UpdateParty"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
				
		
		//Remove Asset Location relationship from CLC. This will be called from event.From here it will be taken care by InventoryAssetConnector
		
		from("direct:removeAssetToLocationRelationship")
		 .routeId("RemoveAssetToLocationRelationship")
			.processRef("updateInvAssetLocationRequest")
			.beanRef(armServiceInvoker, "callInventoryAssetConnector")
		.end();
		
		//Update Termination Point
		from("direct:UpdateTerminationPointARM")
		 .routeId("direct:UpdateTerminationPointARM")
			.setHeader(methodName, constant(UpdateTerminationPointMDW))
			.beanRef(armServiceInvoker, "callConnectorMDW")			
		.end()
		;
		
		
		
		from("direct:ArmGetHSIRoute")
	 	 .routeId("ArmGetHSIRoute")
	 	 .processRef("armHsiRouteRequestValidator")
 		 .choice()
 		 .when(new IsHSIRouteForDeviceCLLIRequest())
 	 	 	.setHeader(methodName, constant("GetDeviceListForCLLIService"))
 	 	 	.beanRef(armServiceInvoker, "callARMGetDeviceListForCLLIService")
			.to("direct:getHSIRouteDetailsForEachDevice")
 	 	 .otherwise()
 	 	 	.setHeader(methodName, constant("HSIRouteVOService"))
 	 	 	.beanRef(armServiceInvoker, "callARMHSIService")
		.end();
		
		from("direct:getHSIRouteDetailsForEachDevice")
		.split(new DeviceNamesSplitter(), new DeviceResponseAggregationStrategy())
		.parallelProcessing()
		.to("direct:ArmGetHSIRoute")
		.end();
		
		
		from("direct:searchHSIPONIPTVServices")
		.id("searchHSIPONIPTVServices")
		.choice()
		.when(new IsHSIServiceRequest())
		.beanRef("stubService", "callHSIService")
		.when(new IsPONServiceRequest())
		.beanRef("stubService", "callPONService")
		.when(new IsIPTVServiceRequest())
		.beanRef("stubService", "callIPTVService")
		.end();
		
		//PortSync Audit Log
		from("direct:portSyncAuditLogInsert")
		.id("portSyncAuditLogInsert")
		.setHeader(methodName,constant("PortSyncAuditLog"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.end();	
		
		from("direct:portSyncAuditLogInsertForISYS")
		.id("portSyncAuditLogInsertForISYS")
		.setHeader(methodName,constant("PortSyncAuditLog"))
		.beanRef("armServiceInvoker", "callArmMediationPortSyncAuditService")
		.end();	
		
		from("direct:GetImpactedDeviceByDeviceRoute")
		.routeId("GetImpactedDeviceByDeviceRoute")
		.to("bean:getImpactedDeviceByDeviceValidator")
		.setHeader(methodName, constant("GetimpactedDeviceByDeviceVoService"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation") 
		.end();
		
		from("direct:GetTopologyDetailed")
		.id("getTopologyDetailed")
		.setHeader(methodName,constant("GetTopologyDetailsService"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.end();	
		
		from("direct:ConsumeNumberObject")
		.id("ConsumeNumberObject")
		.processRef("storeOrigionalRequestProcessor")
		.setHeader(methodName, constant(ConsumeNumberObjMDW))             
        .beanRef(armServiceInvoker, "callConnectorMDW") 
        .processRef("storeOrigionalRequestProcessor")
		.end();	
		
		from("direct:ReleaseNumberObject")
		.id("ReleaseNumberObject")
		.processRef("storeOrigionalRequestProcessor")
		.setHeader(methodName, constant(ReleaseNumberObjMDW))             
        .beanRef(armServiceInvoker, "callConnectorMDW") 
		.end();	
	}
	/**
	 * //TODO XXX : Laukik: Not a best way to set the request in exchange as property. This is specific situation where request xml is not needed to enrich or aggregate the stuff
	 * but request xml is needed when Consume/Release process failed. In case of failure, we need to make an entry in Audit Log table.While making an entry in Audit log table,
	 * we will have only UpdateDeviceResponseDocument with Failure status. In this case, there is no way to get the device name and port name for which the process is failed.
	 * If we have request xml at that place then we can extract the device name, port name from it and error text from UpdateDeviceResponse.
	 */
	private static final Processor setRequestInExchangePropertyForPortSync = new Processor() {
		
		
		@Override
		public void process(Exchange exchange) throws Exception {
		
			//UpdateDeviceRequestDocument requestDocument = exchange.getIn().getBody(UpdateDeviceRequestDocument.class);
			UpdateDeviceRequestDocument requestDocument = exchange.getProperty("UpdateDeviceRequestDocument", UpdateDeviceRequestDocument.class);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("UpdateDeviceRequestPortSync", requestDocument);
			exchange.setProperty(exchangeProperty, map);
		}
	};
}
