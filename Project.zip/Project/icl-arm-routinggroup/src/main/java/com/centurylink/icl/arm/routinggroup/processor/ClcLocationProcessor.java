package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.arm.routinggroup.builder.CLCRequestBuilder;

public class ClcLocationProcessor implements Processor
{
	@Override
	public void process(Exchange exchg) throws Exception 
	{		
		exchg.getIn().setBody(CLCRequestBuilder.buildRequest(exchg,"Location"));
	}

}
