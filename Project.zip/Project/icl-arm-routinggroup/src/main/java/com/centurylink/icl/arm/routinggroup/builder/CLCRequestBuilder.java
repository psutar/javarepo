package com.centurylink.icl.arm.routinggroup.builder;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.xmlbeans.XmlException;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class CLCRequestBuilder 
{
	public static SearchResourceRequestDocument buildRequest(Exchange exchg, String type) throws XmlException
	{
		SearchResourceRequestDocument clcInp = 
				SearchResourceRequestDocument.Factory
				.parse(((SearchResourceRequestDocument)exchg
						.getProperty(ARMRoutingConstants.ARM_REQUEST)).xmlText());
		SearchResourceRequest clcReq = clcInp.getSearchResourceRequest();
		
		clcReq.getMessageElements().getMessageAddressing().setAction("SearchResource");
		SearchResourceDetails clcSRD = clcReq.getSearchResourceDetails();
		clcSRD.setCommonName(null);
		clcSRD.setObjectID(null);
		clcSRD.setSourceSystem(null);
		clcSRD.setScope(null);
		
		List<ResourceCharacteristicValue> rcvList = null;
		
		if(type.equalsIgnoreCase("Customer"))
		{
			clcSRD.setEntity("CUSTOMER");
			clcSRD.setLevel("CUSTOMER");			
			
			rcvList = clcSRD.getResourceCharacteristicValueList();
			rcvList.clear();
			ResourceCharacteristicValue rcv = 
					ResourceCharacteristicValue.Factory.newInstance();
			rcv.setCharacteristicName("CustomerName");
			rcv.setCharacteristicValue("DES MOINES GENERAL");
			rcvList.add(rcv);
			
			rcv = ResourceCharacteristicValue.Factory.newInstance();
			rcv.setCharacteristicName("SourceSystem");
			rcv.setCharacteristicValue("CLC");
			rcvList.add(rcv);		
		}
		else 
		{
			clcSRD.setEntity("LOCATION");
			clcSRD.setLevel("LOCATION");			
			
			rcvList = clcSRD.getResourceCharacteristicValueList();
			rcvList.clear();
			ResourceCharacteristicValue rcv = 
					ResourceCharacteristicValue.Factory.newInstance();
			rcv.setCharacteristicName("LocationId");
			rcv.setCharacteristicValue("1295318");
			rcvList.add(rcv);
			
			rcv = ResourceCharacteristicValue.Factory.newInstance();
			rcv.setCharacteristicName("SourceSystem");
			rcv.setCharacteristicValue("CLC");
			rcvList.add(rcv);
		}
			
		return clcInp;
	}
}
