package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Elliptic;
import com.iclnbi.iclnbiV200.ExchangeServiceArea;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class DeviceWithMetadataAggregationStrategy implements AggregationStrategy{
	
	private static final Log LOG = LogFactory.getLog(DeviceWithMetadataAggregationStrategy.class);
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		SearchResourceResponseDocument oldResponse = null;//ARM
		SearchResourceResponseDocument newResponse = null;//CLC
		
		if(oldExchange == null)
		{
			oldExchange=newExchange.copy();
			oldExchange.setException(null);
			oldExchange.getIn().setBody(newExchange.getProperty(ARMRoutingConstants.ARM_RESPONSE));
		}
		
		if(oldExchange.getException() == null && oldExchange.getIn().getBody() != null){
			oldResponse = (SearchResourceResponseDocument)oldExchange.getIn().getBody();
		}
		if(newExchange.getException() == null && newExchange.getIn().getBody() != null){
			newResponse = (SearchResourceResponseDocument)newExchange.getIn().getBody();
		}
		if(oldResponse!=null && newResponse!=null)
		{
			try
			{
				oldExchange.getIn().setBody(aggregateLocationDetails(oldResponse,newResponse));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (oldResponse != null && newExchange.getException() != null) {
			 oldExchange.setProperty(Exchange.EXCEPTION_CAUGHT,null);
			 oldExchange.setException(null);
			 oldExchange.getIn().setBody(oldResponse);
	    }
		
		return oldExchange;
	}
	
	private SearchResourceResponseDocument aggregateLocationDetails(SearchResourceResponseDocument armResponse,SearchResourceResponseDocument clcResponse){
		AmericanPropertyAddress armRespDevice=null;
		AmericanPropertyAddress clcRespDevice=null;
		
		if(armResponse.getSearchResourceResponse()!=null 
				&& armResponse.getSearchResourceResponse().getSearchResponseDetailsList()!=null
				&& armResponse.getSearchResourceResponse().getSearchResponseDetailsList().size()>0
				&& armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList()!=null
				&& armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().size()>0
				&& armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().get(0).getInstalledAtAddress()!=null){
			armRespDevice = armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().get(0).getInstalledAtAddress();
		}
		
		if(clcResponse.getSearchResourceResponse()!=null 
				&& clcResponse.getSearchResourceResponse().getSearchResponseDetailsList()!=null
				&& clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().size()>0
				&& clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList()!=null){
			clcRespDevice = clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().get(0);
		}
		
		armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).
		getDeviceList().get(0).setInstalledAtAddress(SetCLCResInToARN(armRespDevice,clcRespDevice));
		
		return armResponse;
	}
	
	private AmericanPropertyAddress SetCLCResInToARN(
			AmericanPropertyAddress armRespDevice,
			AmericanPropertyAddress clcRespDevice) {

		if (clcRespDevice.getExchangeServiceAreaList() != null
				&& clcRespDevice.getExchangeServiceAreaList().size() > 0) {
			for (ExchangeServiceArea area : clcRespDevice
					.getExchangeServiceAreaList()) {
				if (area.getAreaType().equalsIgnoreCase("LATA")
						&& !StringHelper.isEmpty(area.getCode())) {
					armRespDevice.addNewExchangeServiceArea();
					armRespDevice.getExchangeServiceAreaList().get(0).setAreaType("LATA");
					armRespDevice.getExchangeServiceAreaList().get(0).setCode(area.getCode());
					break;
				}
			}
		}

		
		List<CharacteristicValue> addrList = clcRespDevice
				.getRootEntityDescribedByList();
				
		if ( clcRespDevice
				.getRootEntityDescribedByList()!= null &&  clcRespDevice
						.getRootEntityDescribedByList().size() > 0) {
			for (CharacteristicValue current : addrList) {

				if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("LocationFullName")) {
					CharacteristicValue cvNew = CharacteristicValue.Factory.newInstance();
					cvNew.setCharacteristicName(current.getCharacteristicName());
					cvNew.setCharacteristicValue( current.getCharacteristicValue());

					armRespDevice.getRootEntityDescribedByList().add(cvNew);
				}
			}
		}

		if (clcRespDevice.getStateOrProvince() != null)
			armRespDevice.setStateOrProvince(clcRespDevice.getStateOrProvince());

		if (clcRespDevice.getEllipticLocation() != null) {
			Elliptic elliptic = Elliptic.Factory.newInstance();
			elliptic.setHCoordinate(clcRespDevice.getEllipticLocation()
					.getHCoordinate());
			elliptic.setVCoordinate(clcRespDevice.getEllipticLocation()
					.getVCoordinate());
			armRespDevice.setEllipticLocation(elliptic);
		}

		
		if (clcRespDevice.getLocality() != null)
			armRespDevice.setLocality(clcRespDevice.getLocality());

		if (clcRespDevice.getPostcode() != null)
			armRespDevice.setPostcode(clcRespDevice.getPostcode());

		
		if (clcRespDevice.getAddressLine1() != null)
			armRespDevice.setAddressLine1(clcRespDevice.getAddressLine1());

		if (clcRespDevice.getAddressLine2() != null) {
			armRespDevice.setAddressLine2(clcRespDevice.getAddressLine2());

		}
		if (clcRespDevice.getAddressLine3() != null) {

			armRespDevice.setAddressLine3(clcRespDevice.getAddressLine3());
		}
		return armRespDevice;

	}

}
