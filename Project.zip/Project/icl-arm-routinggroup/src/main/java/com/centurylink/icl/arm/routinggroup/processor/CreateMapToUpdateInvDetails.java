package com.centurylink.icl.arm.routinggroup.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.clc.connector.data.InventoryAssetRequest;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.CustomerAgent;
import com.iclnbi.iclnbiV200.InvolvementRole;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UpdateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.UpdateDeviceRequestDocument;
import com.qwest.util.StringUtil;

public class CreateMapToUpdateInvDetails implements Processor {
	
	public static final Log LOG = LogFactory.getLog(CreateMapToUpdateInvDetails.class);

	@Override
	public void process(Exchange exchange) throws Exception {

		HashMap<String, Object> ihashMap = new HashMap<String, Object>();

		UpdateDeviceRequestDocument requestDocument = (UpdateDeviceRequestDocument) exchange
				.getIn().getBody();
		String fromConsumer = requestDocument.getUpdateDeviceRequest().getMessageElements().getMessageAddressing().getFrom();
		String actionTag = requestDocument.getUpdateDeviceRequest().getMessageElements().getMessageAddressing().getAction();
		
		String deviceName = null;
		String deviceCLLI = null;
		String alias1 = null;
		String alias2 = null;
		String networkName = null;
		if(requestDocument != null 
				&& requestDocument.getUpdateDeviceRequest() != null 
				&& requestDocument.getUpdateDeviceRequest().getDevice() != null )
		{
			deviceName = requestDocument.getUpdateDeviceRequest().getDevice().getCommonName();
			if (StringHelper.isEqualIgnoreCase(actionTag, "SWAPDevice") && 
					requestDocument.getUpdateDeviceRequest().getDevice().getResourceRelationshipList()!=null
					&& requestDocument.getUpdateDeviceRequest().getDevice().getResourceRelationshipList().size()>0
					&& requestDocument.getUpdateDeviceRequest().getDevice().getResourceRelationshipList().get(0).getDevice()!=null){
				deviceName = requestDocument.getUpdateDeviceRequest().getDevice().getResourceRelationshipList().get(0).getDevice().getCommonName();
			}
			deviceCLLI = requestDocument.getUpdateDeviceRequest().getDevice().getCLLICode();
			alias1 = requestDocument.getUpdateDeviceRequest().getDevice().getAliasName();
			alias2 = requestDocument.getUpdateDeviceRequest().getDevice().getAliasName2();
			networkName = requestDocument.getUpdateDeviceRequest().getDevice().getEMSHostName();
			
		}
		
		if (null != requestDocument.getUpdateDeviceRequest().getDevice()
                           .getInstalledAtAddress()) {
			List<CharacteristicValue> charList = requestDocument
					.getUpdateDeviceRequest().getDevice()
					.getInstalledAtAddress().getRootEntityDescribedByList();

			if (null != charList && charList.size() > 0) {
				for (CharacteristicValue pair : charList) {
					ihashMap.put(pair.getCharacteristicName().toUpperCase(),
							pair.getCharacteristicValue());
				}
			}

			String installationRemarks = null;

			if (null != requestDocument.getUpdateDeviceRequest().getDevice()
					.getInstalledAtAddress().getRemarksList()
					&& requestDocument.getUpdateDeviceRequest().getDevice()
							.getInstalledAtAddress().getRemarksList().size() > 0) {
				installationRemarks = requestDocument.getUpdateDeviceRequest()
						.getDevice().getInstalledAtAddress().getRemarksList()
						.get(0).getText();
			}

			if(null != installationRemarks){
                           ihashMap.put("INSTALLATIONREMARKS", installationRemarks);
                     }
                     
                     if(null != ihashMap && ihashMap.size() > 0){
                           ihashMap.put("OPERATIONNAME", "CREATEDEVICEINSTALLDETAIL");
                         ihashMap.put("DEVICE_NAME", deviceName);
                         ihashMap.put("FROM", "OmniVue");
                         exchange.setProperty("map", ihashMap);
                     }  		
		}
		if(StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(deviceCLLI) && StringHelper.isEmpty(alias1) && StringHelper.isEmpty(alias2) && StringHelper.isEmpty(networkName)){
			throw new ICLRequestValidationException("DEVICE NAME or DEVICE CLLI or ALIAS1 or ALIAS2 or NETWORK NAME not found in Request.");
		}
		
		exchange.setProperty("DEVICE_CLLI", deviceCLLI );
		exchange.setProperty("ALIAS1", alias1);
		exchange.setProperty("ALIAS2", alias2);
		exchange.setProperty("NETWORK_NAME", networkName);
		exchange.setProperty("DEVICE_NAME", deviceName);
		LOG.info("Inside CreateMapToUpdateInvDetails"+"deviceCLLI :"+deviceCLLI+" alias1:"+alias1+" alias2:"+alias2+" networkName:"+networkName+" deviceName:"+deviceName);
		exchange.setProperty("actionTag", actionTag);
		exchange.setProperty("UpdateDeviceRequestDocument", requestDocument);
		exchange.setProperty("fromConsumer", fromConsumer);
		exchange.setProperty("ORIGREQUEST", exchange.getIn().getBody()
				.toString());
	}
}
