package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceDetailByBuildingCLLICallRequired;
import com.centurylink.icl.arm.routinggroup.predicates.PredicateHelper;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ARMDeviceServiceRoute extends RouteBuilder{
	
	private static final Log LOG = LogFactory.getLog(ARMDeviceServiceRoute.class);
	
	@Override
	public void configure() throws Exception
	{
		from("direct:armDeviceServiceSourceFinderRoute")
		 .routeId("armDeviceServiceSourceFinderRoute")
		 .choice()
		    .when(isGetEVCSPrequest)
		    	.to("direct:GetEVCSPRoute")	
		    .when(new IsDeviceDetailByBuildingCLLICallRequired())
		    	.to("direct:GetDevicesByBuildingClliRoute")
		 	.otherwise()
		 		.to("direct:armNtmDeviceDetailRoute")
	    .end();
	    
	}
	
	
	private static final Predicate  isGetEVCSPrequest = new Predicate()
	{

		@Override
		public boolean matches(Exchange exchange) {
			
			return  null != PredicateHelper.getNVP((SearchResourceRequestDocument)exchange.getIn().getBody(), "RUID");
		
		}
		
	};

}
