package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmNtmCircuitDetailRequestValidatorProcessor implements Processor 
{
	private static final Log LOG = LogFactory.getLog(ArmNtmCircuitDetailRequestValidatorProcessor.class);

	@Override
	public void process(Exchange exchg) throws Exception 
	{
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg.getIn().getBody();

		exchg.setProperty(ARMRoutingConstants.ARM_REQUEST, searchResourceRequestDocument);

		String circuitName = null;
		String srNumber = null;
		String deviceName = null;
		String circuitId = null;
		List<ResourceCharacteristicValue> rcvLst = null;

		circuitName = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		//LOG.info("circuitId in Arm request>>>"+ circuitName);

		rcvLst = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList();
		int size = rcvLst.size();
		
		/*if(circuitId == null || circuitId.length() == 0)
		{
			throw new ICLRequestValidationException("Circuit Id Mandatory");
		}*/

	    if (size > 0) {
			for (ResourceCharacteristicValue current : rcvLst) {				
				
			  if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("CircuitSerialNumber"))
				{
					srNumber = current.getCharacteristicValue();	 
				}
				else if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("DeviceName")) 
				{
					deviceName = current.getCharacteristicValue();			
				}	
				else if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("CircuitId")) 
				{
					circuitId = current.getCharacteristicValue();			
				}	


			}
		}
	    
	    if(StringHelper.isEmpty(circuitName) && StringHelper.isEmpty(srNumber)  && StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(circuitId))
		{
			throw new ICLRequestValidationException("Circuit Name or Sr Number or Device Name or circuitId is Required");
		}

		
	}
}
