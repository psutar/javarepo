package com.centurylink.icl.arm.routinggroup;

public class ARMRoutingConstants {

	static final String armServiceInvoker 		= "armServiceInvoker";
	static final String callTransformFromCim    = "callTransformFromCim";
	static final String callConnector			= "callConnector";
	static final String callTransformToCim	  	= "callTransformToCim";
	static final String stubService				= "stubService";
	static final String methodName				= "methodName";
	
	static final String BASIC_FINDER_RESULT = "";
	
	public static final String ENTITY_TYPE = "EntityType";
	public static final String EVC = "EVC";
	public static final String CCNA = "CCNA";
	public static final String CIRCUITID = "CircuitID";
	public static final String LAG = "LAG";
	public static final String UNI = "UNI";
	public static final String VLAN = "S-VLAN/CE-VLAN";
	public static final String RETURNRELATEDCIRCUITS = "ReturnRelatedCircuits";
	public static final String RETURNRELATEDEVC = "ReturnRelatedEVC";
	public static final String EVCID = "EVCId";
	public static final String RUID = "RUID";
	public static final String ARM_REQUEST = "ARM_Request";
	public static final String RESPONSE = "Response";
	public static final String COMMON_NAME = "CommonName";
	public static final String HAS_LAG = "HasLAG";
	public static final String LOCATION = "LOCATION";
	public static final String SUMMARY = "SUMMARY";
	public static final String DETAILED = "Detailed";
	public static final String CLC = "CLC";
	public static final String ARM_RESPONSE = "ARM_RESPONSE";
	public static final String ARMONSE = "ARM_RESPONSE";
	public static final String SWC = "ServiceWireCenterCLLI";
	public static final String DEVICE_NAME = "DeviceName";
	public static final String DEVICE_CLLI = "DeviceCLLI";
	public static final String LOCATION_DESIGNATOR1 = "LocationDesignator1";
	public static final String LOCATION_DESIGNATOR1_VALUE = "LocationDesignator1Value";
	public static final String LOCATION_DESIGNATOR2 = "LocationDesignator2";
	public static final String LOCATION_DESIGNATOR2_VALUE = "LocationDesignator2Value";
	public static final String LOCATION_DESIGNATOR3 = "LocationDesignator3";
	public static final String LOCATION_DESIGNATOR3_VALUE = "LocationDesignator3Value";
	public static final String CUSTOMER = "CUSTOMER";
	public static final String ACNA = "ACNA";
	public static final String CUST_ID = "CustomerId";
	public static final String ADDRESSNUMBERPREFIX		= "AddressNumberPrefix";
	public static final String ADDRESSNUMBER		= "AddressNumber";
	public static final String ADDRESSNUMBERSUFFIX		= "AddressNumberSuffix";
	public static final String STREETDIRECTIONALPREFIX		= "StreetDirectionalPrefix";
	public static final String STREETNAME		= "StreetName";
	public static final String STREETTYPE		= "StreetType";
	public static final String STREETDIRECTIONALSUFFIX		="StreetDirectionalSuffix";
	public static final String CITY		="City";
	public static final String STATE	="State";
	public static final String ZIP	="Zip";	
	public static final String BUILDINGCLLI	="BuildingCLLI";	
	public static final String DEVICE	="Device";
	public static final String ARM	="ARM";
	public static final String LOCATIONNAME	="LOCATIONNAME";
	public static final String CIRCUIT_NAME = "CircuitName";
	static final String exchangeProperty        = "exchangePropertyFromARMRoutingGroup";
	
	public static final String SHELF = "Shelf";
	public static final String SLOT = "Slot";
	public static final String CARDTYPE = "CardType";
}
