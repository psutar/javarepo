package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.exceptions.OSSDataNotFoundException;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class DeviceResponseAggregationStrategy implements AggregationStrategy {

	private static final Log LOG = LogFactory.getLog(DeviceResponseAggregationStrategy.class);
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		if(oldExchange == null && newExchange.getException() != null && (Boolean)(newExchange.getProperty(Exchange.SPLIT_COMPLETE)))
		{
			return newExchange;
		}
		else if(oldExchange == null && newExchange != null && ! (newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) )
		{
			return oldExchange;
		}
		else if(oldExchange == null && newExchange != null && newExchange.getException() == null)
		{
			return newExchange;
		}
		else if(oldExchange != null && oldExchange.getException() == null
				&& oldExchange.getIn().getBody() instanceof SearchResourceResponseDocument && newExchange.getException() != null)
		{
			return oldExchange;
		}
		else
		{
			try {
				SearchResourceResponseDocument newSearchResourceResponseDocument = (SearchResourceResponseDocument) newExchange.getIn().getBody();
				List<SubNetworkConnection> subNetworkConnectionsList = newSearchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList();
				SearchResourceResponseDocument oldSearchResourceResponseDocument = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
				SearchResponseDetails searchResponseDetails = oldSearchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
	
				for(SubNetworkConnection currentSubNetworkConnection : subNetworkConnectionsList)
				{
					int circuitListSize = searchResponseDetails.getCircuitList().size();
					searchResponseDetails.addNewCircuit();
					searchResponseDetails.setCircuitArray(circuitListSize, currentSubNetworkConnection);
				}
	
				oldExchange.getIn().setBody(oldSearchResourceResponseDocument);
			}catch(Exception e) {
				e.printStackTrace();
			}

			return oldExchange;
		}	
	}

}
