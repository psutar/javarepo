package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsGetUNIAndRelatedEVCRequest implements Predicate{

	@Override
	public boolean matches(Exchange exchange) {
		
		SearchResourceRequestDocument in = 
				((SearchResourceRequestDocument)exchange.getIn().getBody());
		
		List<ResourceCharacteristicValue> rcvList = in.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		boolean entityTypeFound = false;
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName().equalsIgnoreCase("EntityType"))
			{
				entityTypeFound = true;
				break;
			}
		}
		return entityTypeFound;
	}

	
}
