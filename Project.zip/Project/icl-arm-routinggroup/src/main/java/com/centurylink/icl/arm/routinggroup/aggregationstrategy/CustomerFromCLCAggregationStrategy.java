package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class CustomerFromCLCAggregationStrategy implements AggregationStrategy{

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		 //initialize the oldExchange when it's empty
			if (oldExchange == null)
			{
				oldExchange = newExchange.copy();
				oldExchange.setException(null);
				oldExchange.getIn().setBody(new HashMap<String, Party>());
			}
			
			//Skip all Exceptions
			if (newExchange != null && newExchange.getException() != null)
			{
				return oldExchange;
			}
			
			if (newExchange != null	&& newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
				String commonName = newExchange.getProperty("ARMCustomerIDForCLC",String.class);
				if(commonName != null)
				{
				SearchResourceResponseDocument responseDoc = (SearchResourceResponseDocument) newExchange.getIn().getBody();
				oldExchange.getIn().setBody(fillCustomerMap(commonName,responseDoc, (Map<String, Party>) oldExchange.getIn().getBody()));
				}
			}
			
			return oldExchange;
	}
	
	private Map<String, Party> fillCustomerMap(String commonName,SearchResourceResponseDocument searchResourceResponseDocument, Map<String, Party> customerMap)
	{
		SearchResponseDetails searchResponseDetails = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
		if(searchResponseDetails != null  && searchResponseDetails.getPartyList() != null) 
		{
			List<Party> partyList = searchResponseDetails.getPartyList();
			if(partyList != null && partyList.size() > 0)
			{
				Party party = partyList.get(0);
				customerMap.put(commonName, party);
			}
			
		}

		return customerMap;
	}

}
