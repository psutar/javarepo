package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceRequest;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class CLCSearchLocationRequestCreator implements Processor{
	
	@Override
	public void process(Exchange exchange) throws Exception {
		String commonName=null;
		SearchResourceRequestDocument searchResourceRequestDocument = SearchResourceRequestDocument.Factory.newInstance();
		SearchResourceRequest resourceRequest = searchResourceRequestDocument.addNewSearchResourceRequest();
		if(exchange.getIn().getBody() instanceof CreateDeviceRequestDocument){
			CreateDeviceRequestDocument createDeviceRequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
			CreateDeviceRequest crd = createDeviceRequest.getCreateDeviceRequest();
			commonName=crd.getDeviceList().get(0).getInstalledAtAddress().getCommonName();
			resourceRequest.setMessageElements(crd.getMessageElements());
		}
		else if(exchange.getIn().getBody() instanceof CreateCircuitRequestDocument){
			CreateCircuitRequestDocument crd =(CreateCircuitRequestDocument)exchange.getIn().getBody();		
			commonName=crd.getCreateCircuitRequest().getCircuit().getAddressDetailsArray(0).getCommonName();
			resourceRequest.setMessageElements(crd.getCreateCircuitRequest().getMessageElements());	
		}	
		resourceRequest.addNewMessageElements();
		SearchResourceDetails srd = resourceRequest.addNewSearchResourceDetails();
		
		srd.setSourceSystem(ARMRoutingConstants.CLC);
		srd.setEntity(ARMRoutingConstants.LOCATION);
		srd.setLevel(ARMRoutingConstants.LOCATION);
		srd.setScope(ARMRoutingConstants.SUMMARY);
			
		Condition locationname =srd.addNewFilterCriteria().addNewValidationCondition().addNewEqualCondition();
		locationname.setVariableName(ARMRoutingConstants.LOCATIONNAME);
		locationname.setValue(commonName);		
		exchange.getIn().setBody(searchResourceRequestDocument);
	}
	

}
