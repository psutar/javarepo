package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

public class ARMHSIDetailRoute extends RouteBuilder{
	private static final Log LOG=LogFactory.getLog(ARMHSIDetailRoute.class);
	
	static final String HSI_DETAILS="HSIRouteVOService";
	@Override
	public void configure() throws Exception {
		
		from("direct:ARMSearchHSIDetails")
		.routeId("ARMSearchHSIDetails")
		.processRef("armHSIDetailRequestProcessor")
		.setHeader(methodName, constant(HSI_DETAILS))
		.beanRef("armServiceInvoker", "callARMHSIService")
		.end();
		
	}
}
