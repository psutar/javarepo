package com.centurylink.icl.arm.routinggroup.bean;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Body;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.util.tracker.ServiceTracker;

import org.apache.commons.lang3.EnumUtils;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.centurylink.icl.xref.connector.interfaces.XrefLookupServiceInterface;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

public class ValidateDeviceForAutoCreate {
    private ServiceTracker xrefTracker;
    
    private static final Log LOG = LogFactory.getLog(ValidateDeviceForAutoCreate.class);
    
	/**
   * DEVICE_CLLI_CREATION_NOT_ALLOWED
   */
  private enum DEVICE_CLLI_CREATION_NOT_ALLOWED {
    ONT, SPLITTER, MST, FDP, MDU 
  }
	
    public ValidateDeviceForAutoCreate(BundleContext bundleContext) throws Exception
    {
		Filter filter = bundleContext.createFilter("(&(name=xrefLookupService))");
		xrefTracker = new ServiceTracker(bundleContext, filter, null);
		
		xrefTracker.open();
    }
    
    public void close()
    {
    	xrefTracker.close();
    }
    
    public void isAutoCreateCLLI(@Body CreateDeviceRequestDocument request)
    {
    	String deviceType = request.getCreateDeviceRequest().getDeviceList().get(0).getResourceSubType();
    	
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	
    	String autoCreateCLLIFlag = lookupService.getFieldValue("DEVICE_COMPATIBILITY", "NODE_DEF_NAME", deviceType, "AUTO_CREATE_CLLI");
    	
    	LOG.info("autoCreateCLLIFlag:: " + autoCreateCLLIFlag);
    	
    	ArrayList<String> deviceRoleList = new ArrayList<String>();
    	if(null != request.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList() &&
            request.getCreateDeviceRequest().getDeviceList().get(0).getHasPhysicalDeviceRolesList().size() > 0){
			
    		for (int i = 0; i < request.getCreateDeviceRequest().getDeviceList().get(0)
    	            .getHasPhysicalDeviceRolesList().size(); i++) {
    	          deviceRoleList.add(request.getCreateDeviceRequest().getDeviceList().get(0)
    	              .getHasPhysicalDeviceRolesList().get(i).getCommonName());
    	        }
		}			
    	if (checkClliCreationAllowed(deviceRoleList)) {
		    LOG.info("auto CLLI Create is allowed for given device role");
    		if (StringHelper.isEmpty(autoCreateCLLIFlag) || !(autoCreateCLLIFlag.equalsIgnoreCase("Y") || autoCreateCLLIFlag.equalsIgnoreCase("T")))
					  throw new ICLRequestValidationException("DeviceSubType " + deviceType + " does not allow auto creation of the DeviceCLLI");
		}		
	}    
    
	private boolean checkClliCreationAllowed(List<String> deviceRoles) {
		if (null != deviceRoles && deviceRoles.size() > 0) {
		    LOG.info("Validating for auto CLLI Creation given device role list");
			for (String role : deviceRoles) {
				if (EnumUtils.isValidEnum(DEVICE_CLLI_CREATION_NOT_ALLOWED.class, role)) {
					return false;
				}
			}
			return true;
		}
		return true;
	}
}
