package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class SearchServiceAggregationStrategy implements AggregationStrategy{
	private static final Log LOG = LogFactory.getLog(SearchServiceAggregationStrategy.class);
	
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		SearchResourceResponseDocument oldResponse=null;
		SearchResourceResponseDocument newResponse=null;
		if(oldExchange == null)
		{
			return newExchange;
		}
		if (newExchange != null&& newExchange.getException() == null && newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			newResponse = (SearchResourceResponseDocument) newExchange.getIn().getBody();
		}
		if (oldExchange != null && oldExchange.getException() == null && oldExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			oldResponse = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
		}
		
		if(oldResponse !=null && newResponse !=null)
		{
			Customer customer=  ((Customer)((SearchResourceResponseDocument)newExchange.getIn().getBody()).getSearchResourceResponse().
					getSearchResponseDetailsArray(0).getPartyArray(0).getHasPartyRolesList().get(0));
			
			String BAN = customer.getCustomerPossesesArray(0).getID();
			SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument)oldExchange.getIn().getBody();
			searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getP2PCircuitList().get(0).getOwnsResourceDetails().getCustomerList().get(0).getCustomerPossesesList().get(0).setID(BAN);
			oldExchange.getIn().setBody(searchResourceResponseDocument);		
		}
		else if (oldResponse != null && newExchange.getException() != null) 							
			oldExchange.getIn().setBody(oldResponse);
	
		return oldExchange;
	}

}
