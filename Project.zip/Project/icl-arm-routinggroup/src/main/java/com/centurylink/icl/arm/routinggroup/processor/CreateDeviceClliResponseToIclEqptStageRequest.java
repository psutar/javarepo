package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.armmediation.service.CreateDeviceClliResponse;
import com.centurylink.icl.losdb.connector.data.ICLEqptStageRequest;

public class CreateDeviceClliResponseToIclEqptStageRequest implements Processor{	
	
	@Override
	public void process(Exchange exchange) throws Exception {		
		CreateDeviceClliResponse createDeviceClliResponse = (CreateDeviceClliResponse) exchange.getIn().getBody();
		
		
		ICLEqptStageRequest iclEqptStageRequest = new ICLEqptStageRequest();
		
		iclEqptStageRequest.setActionCd("A");
		iclEqptStageRequest.setEqptType(createDeviceClliResponse.getEquipmentType());
		iclEqptStageRequest.setIclEqptCd(createDeviceClliResponse.getDeviceClli());
		iclEqptStageRequest.setServingWireCenter(createDeviceClliResponse.getServingWireCenter());
		
		exchange.getIn().setBody(iclEqptStageRequest);
	}	
}
