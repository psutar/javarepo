package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetDeviceDtlsByLocationRequestCreator implements Processor {

	private static final Log LOG = LogFactory.getLog(GetDeviceDtlsByLocationRequestCreator.class);

	@Override
	public void process(Exchange exchange) throws Exception {

		String locationName = exchange.getIn().getBody(String.class);
		String origRequest = (String) exchange.getProperty("ORIGREQUEST");
		SearchResourceRequestDocument searchResourceRequestDocument = SearchResourceRequestDocument.Factory.parse(origRequest);				
		SearchResourceDetails srd = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();		
		ResourceCharacteristicValue rcv = srd.addNewResourceCharacteristicValue();
		rcv.setCharacteristicName("LocationName");
		rcv.setCharacteristicValue(locationName);
		
		//LOG.info("ARM request for Device dtls by LocationName >>>>>>> "+ searchResourceRequestDocument);
		exchange.getIn().setBody(searchResourceRequestDocument);		
	}

}
