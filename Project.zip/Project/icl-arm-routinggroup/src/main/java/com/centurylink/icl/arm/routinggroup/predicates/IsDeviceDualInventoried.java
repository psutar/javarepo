package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.common.util.StringHelper;

public class IsDeviceDualInventoried implements Predicate{

	@Override
	public boolean matches(Exchange exchange) {
		String deviceDualInventory = exchange.getProperty("DeviceDualInventory",String.class);
		
		if (!StringHelper.isEmpty(deviceDualInventory))
			return true;
		else
			return false;
	}

}
