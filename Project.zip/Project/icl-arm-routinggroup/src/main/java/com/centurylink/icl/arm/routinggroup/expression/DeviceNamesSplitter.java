package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;

import java.util.List;
import org.apache.camel.Body;
import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.MessageElements;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;



public class DeviceNamesSplitter implements Expression{

	private static final Log LOG = LogFactory.getLog(DeviceNamesSplitter.class);

  @SuppressWarnings("unchecked")
  @Override
  public <T> T evaluate(Exchange exchg, Class<T> arg1) {
	  
    SearchResourceRequestDocument searchResourceRequestDocument;
    List<SearchResourceRequestDocument> individualDeviceRequestList = new ArrayList<SearchResourceRequestDocument>();
    SearchResourceDetails searchResourceDetails;
    ResourceCharacteristicValue resourceCharacteristicValue;
    List<String> body = (List<String>) exchg.getIn().getBody();
    for (String deviceName : body) {
    
    	searchResourceRequestDocument = SearchResourceRequestDocument.Factory.newInstance();
    	SearchResourceRequest  searchResourceRequest = searchResourceRequestDocument.addNewSearchResourceRequest();
    	searchResourceRequest.addNewMessageElements();
    	searchResourceDetails = searchResourceRequest.addNewSearchResourceDetails();

    	searchResourceDetails.setScope("DETAILED");

    	searchResourceDetails.setSourceSystem("ARM");

    	searchResourceDetails.setLevel("HSI");

    	resourceCharacteristicValue = searchResourceDetails.addNewResourceCharacteristicValue();

    	resourceCharacteristicValue.setCharacteristicName("DeviceName");

    	resourceCharacteristicValue.setCharacteristicValue(deviceName);

    	individualDeviceRequestList.add(searchResourceRequestDocument);
    	
    }

    LOG.debug("individualDeviceRequestList : " + individualDeviceRequestList.size());
    return (T)individualDeviceRequestList;
  }



}
