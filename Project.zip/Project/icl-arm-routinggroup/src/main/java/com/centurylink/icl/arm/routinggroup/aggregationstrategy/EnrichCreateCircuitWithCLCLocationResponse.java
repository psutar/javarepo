package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import com.centurylink.icl.exceptions.ICLException;

public class EnrichCreateCircuitWithCLCLocationResponse implements AggregationStrategy{
	
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		
		if(newExchange.getException() != null){
			oldExchange.setException(new ICLException("CLC Search Location failed for the Locationname Value in the request"));	
			oldExchange.setProperty(Exchange.EXCEPTION_CAUGHT,new ICLException("CLC Search Location failed for the Locationname Value in the request"));
			oldExchange.getIn().setBody(null);
			oldExchange.getOut().setBody(null);
			}
		return oldExchange;
	}

}
