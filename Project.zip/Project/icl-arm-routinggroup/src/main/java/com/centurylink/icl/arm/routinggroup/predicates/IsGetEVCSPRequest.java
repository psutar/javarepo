package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsGetEVCSPRequest implements Predicate {
	@Override
	public boolean matches(Exchange exchg) {
		
		SearchResourceRequestDocument in = 
				((SearchResourceRequestDocument)exchg.getIn().getBody());
		
		List<ResourceCharacteristicValue> rcvList = in.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		boolean ruIDFound = false;
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName().equalsIgnoreCase("RUID"))
			{
				ruIDFound = true;
				break;
			}
		}
		return ruIDFound;
	}

}
