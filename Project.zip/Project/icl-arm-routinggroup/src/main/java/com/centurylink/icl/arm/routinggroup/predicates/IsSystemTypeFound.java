package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.lang3.EnumUtils;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

public class IsSystemTypeFound implements Predicate{

	@Override
	public boolean matches(Exchange exchange) {
		
		Object obj = exchange.getProperty("SYSTEM_TYPE");
		
		if (obj!= null && !StringHelper.isEmpty((String)obj))
			return true;
		else
			return false;
	}

}
