package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsIncludeBANFromDVARRequired implements Predicate{

	@Override
	public boolean matches(Exchange exchange) {
		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		if(PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "IncludeBanFromDvar") && PredicateHelper.getNVP(searchResourceRequestDocument, "IncludeBanFromDvar").equalsIgnoreCase("true"))
		{
			exchange.setProperty("IncludeBanFromDvar", true);
			return true;
		}
		return false;
	}

}
