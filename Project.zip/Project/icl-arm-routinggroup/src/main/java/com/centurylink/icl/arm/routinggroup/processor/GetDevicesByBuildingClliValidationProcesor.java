package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class GetDevicesByBuildingClliValidationProcesor implements Processor {
	
	private static final Log LOG = LogFactory.getLog(GetDevicesByBuildingClliValidationProcesor.class);

	@Override
	public void process(Exchange exchange) throws Exception {
		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();
		
		boolean invalidRequest = false ;		
		
		if(exchange.getProperty("BuildingCLLIAvailable") != null  && exchange.getProperty("BuildingCLLIAvailable", Boolean.class) && 
			StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "BuildingCLLI"))	)
		{
			invalidRequest = true;
			
		}else if(exchange.getProperty("AddressDetailsAvailable") != null && exchange.getProperty("AddressDetailsAvailable", Boolean.class))
		{
			String AddressNumPrefix= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "AddressNumberPrefix");
			String AddressNumber= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "AddressNumber");
			String AddressNumberSuffix= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "AddressNumberSuffix");
			String StreetDirectionalPrefix= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "StreetDirectionalPrefix");
			String StreetName= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "StreetName");
			String StreetType= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "StreetType");
			String StreetDirectionalSuffix= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "StreetDirectionalSuffix");
			String City= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "City");
			String State= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "State");
			String Zip= SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "Zip");
			
//			LOG.info("Address Deatils values in request >>>AddressNumPrefix: " + AddressNumPrefix + "AddressNumber: " + AddressNumber + "AddressNumberSuffix: " + AddressNumberSuffix + "StreetDirectionalPrefix: " + StreetDirectionalPrefix
//					+ "StreetName: " + StreetName + "StreetType: " + StreetType + "StreetDirectionalSuffix: " + StreetDirectionalSuffix + "City: " + City + "State: " + State + "Zip: " + Zip );
			 
			if((StringHelper.isEmpty(AddressNumPrefix)) && (StringHelper.isEmpty(AddressNumber)) && (StringHelper.isEmpty(AddressNumberSuffix)) && (StringHelper.isEmpty(StreetDirectionalPrefix))
				&& (StringHelper.isEmpty(StreetName)) && (StringHelper.isEmpty(StreetType)) && (StringHelper.isEmpty(StreetDirectionalSuffix)) && (StringHelper.isEmpty(City))
				&& (StringHelper.isEmpty(State)) && (StringHelper.isEmpty(Zip))){
			
				invalidRequest = true;
			}
		}
		
		if(invalidRequest)
		{
			throw new ICLRequestValidationException("Building CLLI or Address Details is Required");
		}else
		{
			exchange.setProperty(ARMRoutingConstants.ARM_REQUEST, searchResourceRequestDocument);
		}
		
	}	

}
