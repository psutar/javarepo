package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.CamelContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import com.centurylink.icl.component.RoutingGroupServiceBase;

public class ARMService extends RoutingGroupServiceBase {

	private static final Log LOG = LogFactory.getLog(ARMService.class);
	
	public ARMService(CamelContext context, BundleContext bundleContext, String xmlConfigurationLocation, String serviceName) throws Exception
	{
		super(context, bundleContext, serviceName, xmlConfigurationLocation, LOG);
	}
}
