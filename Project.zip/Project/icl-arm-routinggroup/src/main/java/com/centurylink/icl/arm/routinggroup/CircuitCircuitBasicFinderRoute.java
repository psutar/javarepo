package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;

public class CircuitCircuitBasicFinderRoute extends RouteBuilder {

		
	@Override
	public void configure() throws Exception {

		/*from("direct:circuitCircuitBasicFinderRouteTODO") // Don't use this route until ARM ML Api is ready
		.routeId("circuitCircuitBasicFinderRoute")
		//.filter(new ValidCircuitCircuitBasicRequest())
		.choice()
			.when(isValidateEVCECCKTRequest)
				.to("direct:ValidateEVCECCKTRoute").log("Going to : direct:ValidateEVCECCKTRoute")
			.when(isValidateVLANRequest)
				.to("direct:ValidateVLANRoute").log("Going to : direct:ValidateVLANRoute")
			.when(isValidateLAGExistsRequest)
				.to("direct:ValidateLAGExistsRoute").log("Going to : direct:ValidateLAGExistsRoute")
			.when(isValidateLAGIdRequest)
				.to("direct:ValidateLAGIdRoute").log("Going to : direct:ValidateLAGIdRoute")
			.when(isValidateECCKTNotInRUIDRequest)
				.to("direct:ValidateECCKTNotInRUIDRoute").log("Going to : direct:ValidateECCKTNotInRUIDRoute")
			.when(isValidateCircuitIsPartOfLAGRequest)
				.to("direct:ValidateCircuitPartOfLAGRoute").log("Going to : direct:ValidateCircuitPartOfLAGRoute")
			.when(isCLSCircuitIDLookupRequest)
				.to("direct:CLSCircuitIDLookupRoute").log("Going to :  direct:CLSCircuitIDLookupRoute")
		.endChoice()	
		.end();*/
		
		//Lookup -- Device,Location		//NIC Ordering
		
		from("direct:circuitCircuitBasicFinderRoute")
			.routeId("circuitCircuitBasicFinderRoute")
			.setHeader(methodName,constant("ArmLookup"))
			.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.end();
		
	}
	
	
	
	private static final Predicate  isValidateEVCECCKTRequest = new Predicate()
	{

		@Override
		public boolean matches(Exchange exchange) {

			return exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
				   ARMRoutingConstants.EVC.equals(exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE));
		
		}
		
	};
	
	private static final Predicate isValidateVLANRequest = new Predicate(){
		
		@Override
		public boolean matches(Exchange exchange) {
				
			Object entityType = exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE);
			return exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
				   ("S-VLAN".equals(entityType) || "CE-VLAN".equals(entityType)) &&								   
					exchange.getIn().getHeader(ARMRoutingConstants.EVCID) != null &&
					exchange.getIn().getHeader(ARMRoutingConstants.RUID) != null;
		}
	};
	
	private static final Predicate isValidateLAGExistsRequest = new Predicate() {
		
		@Override
		public boolean matches(Exchange exchange) {
			Object returnRelatedCircuits = exchange.getIn().getHeader(ARMRoutingConstants.RETURNRELATEDCIRCUITS);
			return exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
					ARMRoutingConstants.LAG.equals(exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE)) &&
					("True".equals(returnRelatedCircuits) || "False".equals(returnRelatedCircuits));
					
		}
	};
	
	
	private static final Predicate isValidateLAGIdRequest = new Predicate()
	{
		@Override
		public boolean matches(Exchange exchange) {
			
			return exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
					ARMRoutingConstants.LAG.equals(exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE)) &&
					ARMRoutingConstants.CCNA.equals(exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE)); 
					
		}
	};
	
	
	private static final Predicate isValidateECCKTNotInRUIDRequest = new Predicate() {
		
		@Override
		public boolean matches(Exchange exchange) {
			Object returnRelatedEvc = exchange.getIn().getHeader(ARMRoutingConstants.RETURNRELATEDEVC);
			return 	exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
					ARMRoutingConstants.UNI.equals(exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE)) &&
					("True".equals(returnRelatedEvc) || "False".equals(returnRelatedEvc));
		}
	};
	
	private static final Predicate isValidateCircuitIsPartOfLAGRequest = new Predicate() {
		
		@Override
		public boolean matches(Exchange exchange) {
			Object hasLAG = exchange.getIn().getHeader(ARMRoutingConstants.HAS_LAG);
			return 	exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
					("True".equals(hasLAG) || "False".equals(hasLAG));
		}
	};
	
	private static final Predicate isCLSCircuitIDLookupRequest = new Predicate() {
		
		@Override
		public boolean matches(Exchange exchange) {
			
			return 	exchange.getIn().getHeader(ARMRoutingConstants.COMMON_NAME) != null &&
					null == exchange.getIn().getHeader(ARMRoutingConstants.ENTITY_TYPE);
		}
	};
	
	
}	
 
