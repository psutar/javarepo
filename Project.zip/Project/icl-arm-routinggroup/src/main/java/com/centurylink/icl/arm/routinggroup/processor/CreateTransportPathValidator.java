package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;

public class CreateTransportPathValidator implements Processor
{	
	private static final Log LOG = LogFactory.getLog(CreateTransportPathValidator.class);
	
	@Override
	public void process(Exchange exchange) throws Exception
	{
		LOG.info("Entering CreateTransportPathValidator");
		CreateCircuitRequestDocument createCircuitRequestDocument = (CreateCircuitRequestDocument) exchange.getIn().getBody();
		
		TransportPathRouteValidator.validateRouteList(createCircuitRequestDocument.getCreateCircuitRequest().getCircuit().getRouteList());
		LOG.info("Leaving CreateTransportPathValidator");
	}	
}
