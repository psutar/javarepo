package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.CircuitDetailResponseAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.expression.CircuitDetailArmResponseSplitter;
import com.centurylink.icl.arm.routinggroup.predicates.IsIncludeClcCustomerFlag;
import com.centurylink.icl.arm.routinggroup.predicates.IsIncludeClcLocationFlag;


public class ARMNtmCircuitDetailRoute extends RouteBuilder {
	
	 static final String CIRCUIT_DETAIL_ARMCLC_ROUTE		= "direct:GetCircuitDetailARMCLC";
	 static final String CIRCUIT_DETAIL_ARM_ROUTE			= "direct:GetCircuitDetailARM";
	 static final String CIRCUIT_DETAIL_CLCCUSTOMER_ROUTE	= "direct:clcCustomer";
	 static final String CIRCUIT_DETAIL_CLLOCATION_ROUTE	= "direct:clcLocation";
	 
	 private static final String CircuitDetailARMCLC		= "CircuitDetailARMCLC";
	 private static final String CIRCUIT_DETAIL_AML 		= "GetCircuitDetail";
	 
	@Override
	public void configure() throws Exception
	{
		from(CIRCUIT_DETAIL_ARMCLC_ROUTE)
		.id(CircuitDetailARMCLC)
		.to("bean:armNtmCircuitDetailRequestValidatorProcessor")
		.setHeader(methodName, constant(CIRCUIT_DETAIL_AML))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.choice()						
		    .when(new IsIncludeClcCustomerFlag())
		    	.to("bean:circuitDetailCLCCustomerRequestCreator")
		    	.beanRef("armServiceInvoker","callCLCSearchCustomerOp")
		    	.to("bean:circuitDetailResponseProcessor")
		 .end()
		.choice()
		    .when(new IsIncludeClcLocationFlag())
				.split(new CircuitDetailArmResponseSplitter(), new CircuitDetailResponseAggregationStrategy())
				.parallelProcessing()
				.beanRef("circuitDetailCLCLocationRequestCreator")
				.beanRef("armServiceInvoker","callCLCSearchLocationOp")				
		 .end();	
	}
   }
