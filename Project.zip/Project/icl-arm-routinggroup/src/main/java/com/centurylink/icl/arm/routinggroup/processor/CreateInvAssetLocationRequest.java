package com.centurylink.icl.arm.routinggroup.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xmlbeans.XmlException;

import com.centurylink.icl.clc.connector.data.InventoryAssetRequest;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.CustomerAgent;
import com.iclnbi.iclnbiV200.InvolvementRole;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UNICircuit;
import com.iclnbi.iclnbiV200.UpdateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.UpdateCircuitResponseDocument;

public class CreateInvAssetLocationRequest implements Processor {
	
	private static final Log LOG = LogFactory.getLog(CreateInvAssetLocationRequest.class);

	@Override
	public void process(Exchange exchange) throws Exception {
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();
		
		List<TopologicalLink> p2pCircuitList = new ArrayList<TopologicalLink>();
		List<TopologicalLink> p2pResponse = new ArrayList<TopologicalLink>();
		String user = "";
		
		if (exchange.getIn().getBody() instanceof CreateCircuitResponseDocument)
		{
			CreateCircuitResponseDocument createCircuitResponseDocument = (CreateCircuitResponseDocument) exchange.getIn().getBody();
			p2pResponse = createCircuitResponseDocument.getCreateCircuitResponse().getP2PCircuitList();
			
			String origRequest = (String) exchange.getProperty("ORIGREQUEST");
			CreateCircuitRequestDocument createCircuitRequestDocument = CreateCircuitRequestDocument.Factory.parse(origRequest);
			
			p2pCircuitList = createCircuitRequestDocument.getCreateCircuitRequest().getP2PCircuitList();
			user = createCircuitRequestDocument.getCreateCircuitRequest().getMessageElements().getMessageAddressing().getFrom();
		}
		else 
		{
			UpdateCircuitResponseDocument updateCircuitResponseDocument = (UpdateCircuitResponseDocument) exchange.getIn().getBody();
			p2pResponse.add(updateCircuitResponseDocument.getUpdateCircuitResponse().getP2PCircuit());
			
			String origRequest = (String) exchange.getProperty("ORIGREQUEST");
			UpdateCircuitRequestDocument updateCircuitRequestDocument = UpdateCircuitRequestDocument.Factory.parse(origRequest);
			
			p2pCircuitList.add(updateCircuitRequestDocument.getUpdateCircuitRequest().getP2PCircuit());
			user = updateCircuitRequestDocument.getUpdateCircuitRequest().getMessageElements().getMessageAddressing().getFrom();
		}
		
		if (p2pCircuitList.size() > 0)
		{
			assetRequests = extractAssetsFromP2PCircuitList(p2pCircuitList, user);
			assetRequests = enrichWithNativeId(p2pResponse, assetRequests);
		} 
		
		exchange.getIn().setBody(assetRequests);
	}
	
	private List<InventoryAssetRequest> enrichWithNativeId(List<TopologicalLink> p2pResponse, List<InventoryAssetRequest> assetRequests)
	{
		for (TopologicalLink circuit: p2pResponse)
		{
			String circuitId = circuit.getCommonName();
			String objectId = circuit.getObjectID();
			
			for (InventoryAssetRequest assetRequest:assetRequests)
			{
				if (assetRequest.getAssetName().equalsIgnoreCase(circuitId))
				{
					assetRequest.setAssetId(objectId);
				}
			}
		}
		
		return assetRequests;
	}	
	
	private List<InventoryAssetRequest> extractAssetsFromP2PCircuitList(List<TopologicalLink> p2pCircuitList, String user) throws XmlException
	{
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();
		
		for (TopologicalLink p2pCircuit: p2pCircuitList)
		{
			String circuitName = null;
			String sourceSystem = null;
			
			circuitName = p2pCircuit.getCommonName();
			sourceSystem = p2pCircuit.getSourceSystem();
			
			assetRequests.addAll(buildAssetRequest(UNICircuit.Factory.parse(p2pCircuit.xmlText()), circuitName, "SERVICE", sourceSystem, user));
		}
		
		return assetRequests;
	}

	private List<InventoryAssetRequest> buildAssetRequest(UNICircuit uniCircuit, String circuitName, String type, String sourceSystem, String user)
	{
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();

		String locationName = null;		

		List<AmericanPropertyAddress> addrDtlsLst = uniCircuit.getAddressDetailsList();
		
		for (AmericanPropertyAddress addressDtls: addrDtlsLst)
		{
			locationName = addressDtls.getCommonName();
			
			if (!StringHelper.isEmpty(circuitName) &&
					!StringHelper.isEmpty(locationName) &&					
					!StringHelper.isEmpty(type) &&
					!StringHelper.isEmpty(sourceSystem) 
					)
			{
				InventoryAssetRequest iar = new InventoryAssetRequest();
				iar.createAddLocationToAssetRequest(null, locationName, circuitName, null, sourceSystem, type, user);				
				assetRequests.add(iar);
			}
		}
		
		return assetRequests;
	}
}
