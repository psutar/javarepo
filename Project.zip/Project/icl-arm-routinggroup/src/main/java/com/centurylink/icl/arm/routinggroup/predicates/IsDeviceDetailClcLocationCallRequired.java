package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsDeviceDetailClcLocationCallRequired implements Predicate {

	@Override
	public boolean matches(Exchange exchg) {
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_REQUEST);

		List<ResourceCharacteristicValue> rcvList = searchResourceRequestDocument
				.getSearchResourceRequest().getSearchResourceDetails()
				.getResourceCharacteristicValueList();
		String includeCLCLocationValue = null;

		for (ResourceCharacteristicValue rcv : rcvList) {
			if (rcv.getCharacteristicName().equalsIgnoreCase("IncludeCLCLocation"))
				includeCLCLocationValue = rcv.getCharacteristicValue();
		}

		if (!StringHelper.isEmpty(includeCLCLocationValue) && includeCLCLocationValue.equalsIgnoreCase("true"))
			return true;
		else
			return false;
	}

}
