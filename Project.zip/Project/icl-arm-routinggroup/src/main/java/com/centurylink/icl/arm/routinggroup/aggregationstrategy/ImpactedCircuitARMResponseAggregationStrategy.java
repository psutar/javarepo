package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class ImpactedCircuitARMResponseAggregationStrategy implements AggregationStrategy{
	private static final Log LOG = LogFactory.getLog(ImpactedCircuitARMResponseAggregationStrategy.class);
	
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		SearchResourceResponseDocument oldResp = null;
		SearchResourceResponseDocument newResp = null;
		if(oldExchange==null){
			return newExchange;
		}
		
		if (newExchange != null&& newExchange.getException() == null && newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			newResp = (SearchResourceResponseDocument) newExchange.getIn().getBody();
		}

		if (oldExchange != null && oldExchange.getException() == null && oldExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			oldResp = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
		}
		
		if(oldResp!=null && newResp!=null){
			oldExchange.getIn().setBody(aggregateLocationDetails(oldExchange,newExchange));
		}
		else if (oldResp != null && newExchange.getException() != null) {
			 oldExchange.getIn().setBody(oldResp);
	    }

	  else if (newResp != null && oldExchange.getException() != null) {
			newExchange.getIn().setBody(newResp);
		return newExchange;
	 } 
	
	   return oldExchange;	
	}
	
	private SearchResourceResponseDocument aggregateLocationDetails(Exchange oldExchange, Exchange newExchange){
		SearchResourceResponseDocument clcCustomerResponse = (SearchResourceResponseDocument)oldExchange.getIn().getBody();
		SearchResourceResponseDocument clcLocationResponse = (SearchResourceResponseDocument)newExchange.getIn().getBody();
		
		if(clcLocationResponse.getSearchResourceResponse().getSearchResponseDetailsList()!=null &&
				clcLocationResponse.getSearchResourceResponse().getSearchResponseDetailsList().size()>0 &&
				clcLocationResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList()!=null
			&& clcLocationResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().size()>0){
			
			List<AmericanPropertyAddress> clcAddressList = clcLocationResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList();
			for(AmericanPropertyAddress clcAddress:clcAddressList){
				
		if (clcCustomerResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0).getCircuitList()!=null &&
				clcCustomerResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0).getCircuitList().size() > 0) {

			List<SubNetworkConnection> circuitList = clcCustomerResponse.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0).getCircuitList();

	for (SubNetworkConnection circuit : circuitList) {		
			if (circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList() != null
					&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().size() > 0
					&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
						String deviceLocationAEnd = circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();
						if(clcAddress.getCommonName().equalsIgnoreCase(deviceLocationAEnd)){
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().remove(0);
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().add(clcAddress);
						}
					}
			if (circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList() != null
					&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().size() > 0
					&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
						String deviceLocationZEnd =circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();
						if(clcAddress.getCommonName().equalsIgnoreCase(deviceLocationZEnd)){
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().remove(0);
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().add(clcAddress);
						}
					  }
				   }
				}
			}
		}
		return clcCustomerResponse;
	}

}
