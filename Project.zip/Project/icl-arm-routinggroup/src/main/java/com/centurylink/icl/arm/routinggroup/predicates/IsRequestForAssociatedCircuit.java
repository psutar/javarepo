package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsRequestForAssociatedCircuit implements Predicate {

	private static final Log LOG = LogFactory.getLog(IsRequestForAssociatedCircuit.class);
	
  @Override
  public boolean matches(Exchange exchange) {
	  SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();
		
		
		if(PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "AssociatedCircuit"))
		{
			exchange.setProperty("GetAssociatedCircuit", true);
			return true;
		}
	return false;	
  }	
}
