package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;

import java.util.List;
import org.apache.camel.Body;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.MessageElements;
import com.iclnbi.iclnbiV200.PhysicalDevice;



public class CreateBulkDevicesplitter {

	private static final Log LOG = LogFactory.getLog(CreateBulkDevicesplitter.class);

  public List<CreateDeviceRequestDocument> splitDevices(@Body String body) throws Exception {
	  
    CreateDeviceRequestDocument deviceRequestDocument;
    List<CreateDeviceRequestDocument> splitDevices = new ArrayList<CreateDeviceRequestDocument>();

    deviceRequestDocument = CreateDeviceRequestDocument.Factory.parse(body);


    MessageElements elements = deviceRequestDocument.getCreateDeviceRequest().getMessageElements();
    for (PhysicalDevice device : deviceRequestDocument.getCreateDeviceRequest().getDeviceList()) {
    
 
    	splitDevices.add(buildPhysicalDevice(device, elements));
    	
    }

    LOG.info("split bulk device request into : " + splitDevices.size());
    return splitDevices;
  }

  private static CreateDeviceRequestDocument buildPhysicalDevice(PhysicalDevice device, MessageElements elements) {
    CreateDeviceRequestDocument document = CreateDeviceRequestDocument.Factory.newInstance();
    try {
    	
    	document.addNewCreateDeviceRequest().setMessageElements(elements);
      document.getCreateDeviceRequest().setDeviceArray(new PhysicalDevice[] {device});

    } catch (Exception e) {
      e.printStackTrace();
    }
   
    return document;
  }
}
