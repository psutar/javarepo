package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;


public class DeviceWithMetadatResponseProcessor implements Processor{
	private static final Log LOG = LogFactory.getLog(DeviceWithMetadatResponseProcessor.class);
	@Override
	public void process(Exchange exchg) throws Exception {
		
		boolean isCLCCallRequired = false;

		Object SearchResourceResDoc = exchg.getIn().getBody();

		if (SearchResourceResDoc instanceof SearchResourceResponseDocument) {

			SearchResourceResponseDocument srrd = (SearchResourceResponseDocument) exchg
					.getIn().getBody();
			exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE, exchg.getIn()
					.getBody());
			
		if (srrd.getSearchResourceResponse()!=null && srrd.getSearchResourceResponse().getSearchResponseDetailsList()!=null 
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList()!=null
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().size()>0
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList()!=null
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().size()>0
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().get(0).
				getInstalledAtAddress()!=null){
			
				String locatioName = srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).
									 getDeviceList().get(0).
									 getInstalledAtAddress().getCommonName();
				
				if(!StringHelper.isEmpty(locatioName))
				isCLCCallRequired = true;							
			}
			exchg.setProperty("isCLCCallRequired", isCLCCallRequired);
		} 
	} 
}

