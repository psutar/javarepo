package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class DVARSearchRequestProcessor implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		SearchResourceDetails searchResourceDetails = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		String commonName = searchResourceDetails.getCommonName();
		if(!StringHelper.isEmpty(commonName))
		{
			ResourceCharacteristicValue rcv= searchResourceDetails.addNewResourceCharacteristicValue();
			rcv.setCharacteristicName("CircuitId");
			rcv.setCharacteristicValue(commonName);
		}
		else if(StringHelper.isEmpty(commonName))
		{
			Condition condition = searchResourceDetails.getFilterCriteriaArray(0).getValidationConditionArray(0).getEqualConditionArray(0);
		    
			if(condition!=null && condition.getVariableName().equalsIgnoreCase("NAME"))
			{
				ResourceCharacteristicValue rcv= searchResourceDetails.addNewResourceCharacteristicValue();
				rcv.setCharacteristicName("CircuitId");
				rcv.setCharacteristicValue(condition.getValue());	
			}
		}
		exchange.getIn().setBody(searchResourceRequestDocument);
	}

}
