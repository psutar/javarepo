package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.centurylink.icl.exceptions.ICLException;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.CreateDeviceResponseDocument;

public class EnrichCreateDeviceWithGeneratedCLLI implements AggregationStrategy {

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		Object oldBody = oldExchange.getIn().getBody();
		Object newBody = newExchange.getIn().getBody();
		
		if (!(oldBody instanceof CreateDeviceRequestDocument))
			throw new ICLException("Error Creating DeviceCLLI");
		if (!(newBody instanceof CreateDeviceResponseDocument))
			throw new ICLException("Error Creating DeviceCLLI");
		
		CreateDeviceRequestDocument request = (CreateDeviceRequestDocument) oldBody;
		CreateDeviceResponseDocument response = (CreateDeviceResponseDocument) newBody;
		
		request.getCreateDeviceRequest().getDeviceList().get(0).setCLLICode(response.getCreateDeviceResponse().getDeviceList().get(0).getCLLICode());
		
		oldExchange.getIn().setBody(request);
		
		return oldExchange;
	}

}
