package com.centurylink.icl.arm.routinggroup.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class GetDevicesByBuildingClliResponseProcessor implements Processor {

	private static final Log LOG = LogFactory.getLog(GetDevicesByBuildingClliResponseProcessor.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		Object temp = exchg.getIn().getBody();

		if (temp != null && temp instanceof SearchResourceResponseDocument) {
			//LOG.info("CLC Customer Response : " + temp);
			SearchResourceResponseDocument clcResp = (SearchResourceResponseDocument) temp;

			if (clcResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getAddressDetailsList()
					.size() > 0) {
				List<AmericanPropertyAddress> addrrLst = clcResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0)
						.getAddressDetailsList();

				List<String> locationValueLst = new ArrayList<String>();
								
				for (AmericanPropertyAddress addrr : addrrLst) {
					locationValueLst.add(addrr.getCommonName());					
				}

				if (locationValueLst.size() == 0) {
					throw new ICLRequestValidationException("No Location returned from CLC");
				} else if (locationValueLst.size() > 1) {
					throw new ICLRequestValidationException("Multiple Location returned from CLC");
				} else {
					SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg
							.getProperty(ARMRoutingConstants.ARM_REQUEST);
					SearchResourceDetails srd = searchResourceRequestDocument
							.getSearchResourceRequest()
							.getSearchResourceDetails();
					srd.setEntity(ARMRoutingConstants.DEVICE);
					srd.setLevel(ARMRoutingConstants.DEVICE);
					srd.setScope(ARMRoutingConstants.DETAILED);
					srd.setSourceSystem(ARMRoutingConstants.ARM);
					ResourceCharacteristicValue rcv = searchResourceRequestDocument
							.getSearchResourceRequest()
							.getSearchResourceDetails()
							.addNewResourceCharacteristicValue();
					rcv.setCharacteristicName("LocationName");
					rcv.setCharacteristicValue(locationValueLst.get(0));
					srd.setFilterCriteriaArray(0, null);
					srd.setFilterCriteriaArray(1, null);					
					//LOG.info("ARM FINAL REQUEST >>>>>>> "+ searchResourceRequestDocument);
					exchg.getIn().setBody(searchResourceRequestDocument);

				}
			}

		}

	}

}
