package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class DeviceDetailResponseProcessor implements Processor {

	private static final Log LOG = LogFactory
			.getLog(DeviceDetailResponseProcessor.class);

	@Override
	public void process(Exchange exchg) throws Exception {
		SearchResourceResponseDocument armResp = (SearchResourceResponseDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_RESPONSE);

		Object temp = exchg.getIn().getBody();
		
		if (temp != null && temp instanceof SearchResourceResponseDocument) {
			//LOG.info("CLC Customer Response : " + temp);
			SearchResourceResponseDocument clcResp = 
					(SearchResourceResponseDocument)temp;
				
			Customer customer = armResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getDeviceArray(0)
					.getOwnsResourceDetails().getCustomerArray(0);
			
			Party party = clcResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getPartyArray(0);
			
			customer.setCommonName(party.getCommonName());					
			customer.setObjectID(party.getObjectID());
			customer.setPartyType(party.getPartyType());
			
			if (!StringHelper.isEmpty(party.getPartyId())){
				customer.setID(party.getPartyId());
			}
			
			if (party.getHasCustomerRoleList().size() > 0) {
				Customer cust = party.getHasCustomerRoleArray(0);					
				
				if (!StringHelper.isEmpty(cust.getACNA())){
					customer.setACNA(cust.getACNA());
				}			
			}			
			
		}

		exchg.getOut().setBody(armResp);

	}

}
