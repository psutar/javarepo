package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.lang3.EnumUtils;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;

public class IsDeviceCLLINotFound implements Predicate{

	private enum DEVICE_CLLI_CREATION_NOT_ALLOWED {
	    ONT, SPLITTER, MST, FDP, MDU 
	  }
	
	@Override
	public boolean matches(Exchange exchange) {
		CreateDeviceRequestDocument createDeviceRequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
		
		if(null != createDeviceRequest.getCreateDeviceRequest()
				.getDeviceList().get(0).getHasPhysicalDeviceRolesList() &&
				createDeviceRequest.getCreateDeviceRequest()
				.getDeviceList().get(0).getHasPhysicalDeviceRolesList().size() > 0){
			String deviceRole = createDeviceRequest.getCreateDeviceRequest()
					.getDeviceList().get(0).getHasPhysicalDeviceRolesList().get(0)
					.getCommonName();
			if (EnumUtils.isValidEnum(DEVICE_CLLI_CREATION_NOT_ALLOWED.class,
					deviceRole)) {
				return false;
			}
		}
				
		if (StringHelper.isEmpty(createDeviceRequest.getCreateDeviceRequest().getDeviceList().get(0).getCLLICode()))
			return true;
		else
			return false;
	}

}
