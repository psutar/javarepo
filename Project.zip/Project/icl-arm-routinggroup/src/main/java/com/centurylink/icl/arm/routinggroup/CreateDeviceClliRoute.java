package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;
import org.apache.camel.builder.RouteBuilder;

public class CreateDeviceClliRoute extends RouteBuilder {
	
	private static final String CREATE_DEVICE_CLLI = "CreateDeviceClli";
	
	@Override
	public void configure() throws Exception {
		from("direct:CreateDeviceClli")		
		.routeId("CreateDeviceClli")
			.to("bean:createDeviceClliValidator")
			.beanRef("validateDeviceForAutoCreate", "isAutoCreateCLLI")
			.to("direct:CreateDeviceClliPostValidation")
			;
		
		from("direct:CreateDeviceClliPostValidation")
			.routeId("CreateDeviceClliPostValidation")
			.setHeader(methodName, constant(CREATE_DEVICE_CLLI))
			.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
			.to("bean:createDeviceClliResponseToIclEqptStageRequest")
			.beanRef("armServiceInvoker", "callLosdbConnector")
			.beanRef("armServiceInvoker", "callLosdbTransformToCim")
			;
	}
}