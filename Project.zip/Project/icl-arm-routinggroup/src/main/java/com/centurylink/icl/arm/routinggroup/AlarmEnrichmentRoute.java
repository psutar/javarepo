package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.CustomerFromCLCAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.EnrichSearchResourceResponseWithCLCCustomer;
import com.centurylink.icl.arm.routinggroup.expression.CircuitOrDeviceSplitter;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.ValidationCondition;

public class AlarmEnrichmentRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {

				//Alarm Enrichment
				from("direct:AlarmEnrichment")
		        .routeId("AlarmEnrichment")
		        .setHeader(methodName,constant("GetAlarmEnrichmentVO"))
		        .beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		        .enrich("direct:getCustomerDataFromCLC",new EnrichSearchResourceResponseWithCLCCustomer())
		        .end();  

				
				
				from("direct:getCustomerDataFromCLC")
					.split(new CircuitOrDeviceSplitter(),new CustomerFromCLCAggregationStrategy())
					.parallelProcessing()
					.choice().when(new IsCLCCustomerRequest())
					.beanRef("armServiceInvoker","callCLCSearchCustomerOp")
		       .end();
		
		
	}
	
	
	
	private final class IsCLCCustomerRequest implements Predicate {
		
		@Override
		public boolean matches(Exchange exchange) {
			

			
			String commonName = exchange.getIn().getBody(String.class);
			SearchResourceRequestDocument srrd = SearchResourceRequestDocument.Factory.newInstance();
			SearchResourceDetails srd = srrd.addNewSearchResourceRequest().addNewSearchResourceDetails();
			
			if(commonName != null)
			{
				srd.setEntity(ARMRoutingConstants.CUSTOMER);
				srd.setLevel(ARMRoutingConstants.CUSTOMER);
				srd.setScope(ARMRoutingConstants.SUMMARY);
				srd.setSourceSystem(ARMRoutingConstants.CLC);		
						
				ValidationCondition valCond =  srd.addNewFilterCriteria().addNewValidationCondition();
				valCond.setOperator("OR");
				Condition cond1 = valCond.addNewEqualCondition();
				cond1.setVariableName(ARMRoutingConstants.ACNA);
				cond1.setValue(commonName);
			
				Condition cond2 = valCond.addNewEqualCondition();
				cond2.setVariableName(ARMRoutingConstants.CUST_ID);
				cond2.setValue(commonName);
				exchange.setProperty("ARMCustomerIDForCLC", commonName);
				System.out.println(srrd);
				exchange.getIn().setBody(srrd);
				return true;
			}
			else 
			{
				exchange.getIn().setBody(null);
				return false;
			}
			
		
		}
	};
	
	

}
