package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.predicates.IsGetNMIBandwidthRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsGetUNIAndRelatedEVCRequest;

public class ARMCircuitCircuitDetailedServiceRoute extends RouteBuilder{
	
	private static final Log LOG = LogFactory.getLog(ARMCircuitCircuitDetailedServiceRoute.class);
	
	@Override
	public void configure() throws Exception
	{
		from("direct:armCircuitCircuitDetailedServiceRoute")
		 .routeId("ARMCircuitCircuitDetailedServiceRoute")
		 .choice()
		    .when(new IsGetNMIBandwidthRequest())
		    	.to("direct:GetNMIAndBandwidthByDeviceRoute")
		    .when(new IsGetUNIAndRelatedEVCRequest())
		    	.to("direct:GetUNIRelatedEVCDetailsRoute")
		    .otherwise()
		 		.to("direct:GetCircuitDetailARMCLC")		 		
	    .end();			
	}

}
