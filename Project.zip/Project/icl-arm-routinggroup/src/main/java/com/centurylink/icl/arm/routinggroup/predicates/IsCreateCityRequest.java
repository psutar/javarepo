package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.CreateLocationRequestDocument;

public class IsCreateCityRequest implements Predicate {

	@Override
	public boolean matches(Exchange exchange) {
		CreateLocationRequestDocument createLocationRequest = (CreateLocationRequestDocument)exchange.getIn().getBody();
		
		AmericanPropertyAddress addressDetails = createLocationRequest.getCreateLocationRequest().getAddressDetails();
		String type = addressDetails.getAddressType();
		
		if ("CITY".equalsIgnoreCase(type))
			return true;
		
		return false;
	}

}
