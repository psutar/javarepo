package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Card;
import com.iclnbi.iclnbiV200.CardOnCardDetails;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.Rack;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.Shelf;


public class ARMSearchDeviceByPortIDResponseProcessor implements Processor{
	private static final Log LOG = LogFactory.getLog(ARMSearchDeviceByPortIDResponseProcessor.class);
	@Override
	public void process(Exchange exchange) throws Exception {
		SearchResourceResponseDocument responseDocument = (SearchResourceResponseDocument)exchange.getIn().getBody();
		
		if(responseDocument!=null && responseDocument.getSearchResourceResponse()!=null 
				&& responseDocument.getSearchResourceResponse().getSearchResponseDetailsList()!=null
				&& responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().size()>0){
			
			exchange.setProperty(ARMRoutingConstants.ARM_RESPONSE, responseDocument);
			SearchResponseDetails responseDetails = responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
			String nodeDefName = null;
			String portName = null;
			String portStatus = null;
			
			if(exchange.getProperty("PORTSTATUS")!=null && StringHelper.isEmpty((String)exchange.getProperty("PORTSTATUS"))){
				portStatus = (String)exchange.getProperty("PORTSTATUS");
			}
			
			if(responseDetails!=null && responseDetails.getDeviceList()!=null && responseDetails.getDeviceList().size()>0){
				
				nodeDefName = responseDetails.getDeviceList().get(0).getCommonName();
				if(!StringHelper.isEmpty(nodeDefName))
				exchange.setProperty("DEVICE_NAME",nodeDefName);
				
				List<PhysicalDevice> deviceList= responseDetails.getDeviceList();
				if(deviceList != null && deviceList.size() != 0){
					for(PhysicalDevice physicalDevice : deviceList){
			   if(physicalDevice.getHasPortsList() != null  && physicalDevice.getHasPortsList().size() > 0){
					PhysicalPort  physicalPort = physicalDevice.getHasPortsList().get(0);				
							if(physicalPort != null){
								portName = physicalPort.getCommonName();
								if(StringHelper.isEmpty(portStatus)){
									portStatus = physicalPort.getPrStatus();
								}
							}
						}
				if(StringHelper.isEmpty(portName)){
				if(physicalDevice.getConsistsOfRackList() != null && physicalDevice.getConsistsOfRackList().size() > 0){
					Rack rack = physicalDevice.getConsistsOfRackList().get(0);
					if(rack.getConsistsOfShelfList() != null && rack.getConsistsOfShelfList().size() > 0 ){
						Shelf shelf = rack.getConsistsOfShelfList().get(0);
					if(shelf.getConsistsOfSlotList() != null  && shelf.getConsistsOfSlotList().size() > 0){
						Card card = shelf.getConsistsOfSlotArray(0).getHasCard();
					if(card.getPhysicalPortList() != null  && card.getPhysicalPortList().size() > 0){
					   PhysicalPort physicalPort = card.getPhysicalPortArray(0);
						if(physicalPort != null){
								portName = physicalPort.getCommonName();
								if(StringHelper.isEmpty(portStatus)){
									portStatus = physicalPort.getPrStatus();
								}
					  }
					}
				if(StringHelper.isEmpty(portName)){
				if(card.getCardOnCardDetailsList() !=null && card.getCardOnCardDetailsList().size()>0){
					for(CardOnCardDetails cardOnCardDetails:card.getCardOnCardDetailsList()){
						if(cardOnCardDetails.getCardList()!=null && cardOnCardDetails.getCardList().size()>0){
						for(Card childCard:cardOnCardDetails.getCardList()){
					    if(childCard.getPhysicalPortList() != null  && childCard.getPhysicalPortList().size() > 0){
							PhysicalPort physicalPort = childCard.getPhysicalPortArray(0);
							if(physicalPort != null){
								portName = physicalPort.getCommonName();
								if(StringHelper.isEmpty(portStatus)){
									portStatus = physicalPort.getPrStatus();
								}
	                           }
							 }
						   }
			              }
						}
					  }
					}
				  }						
				}
			  }
			}						
		  }
	     }
		}
			if(!StringHelper.isEmpty(portName))
			exchange.setProperty("PORT_NAME",portName);
			if(!StringHelper.isEmpty(portStatus))
			exchange.setProperty("PORTSTATUS",portStatus);
	}
 }
}
