package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.arm.routinggroup.processor.CustomerInfo;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class ImpactedCircuitResponseAggregationStrategy implements AggregationStrategy {
	private static final Log LOG = LogFactory.getLog(ImpactedCircuitResponseAggregationStrategy.class);

	@SuppressWarnings("unchecked")
	@Override
	public Exchange aggregate(Exchange oldExchg, Exchange newExchg) {

		SearchResourceResponseDocument oldResp = null;
		SearchResourceResponseDocument newResp = null;

		if (oldExchg != null && oldExchg.getException() == null
				&& oldExchg.getIn().getBody() instanceof SearchResourceResponseDocument) {
			oldResp = (SearchResourceResponseDocument) oldExchg.getIn().getBody();
		}else if (null == oldExchg) {
			oldResp = (SearchResourceResponseDocument) newExchg.getProperty(ARMRoutingConstants.ARM_RESPONSE);
		}

		if (newExchg != null) {
			if (newExchg.getException() != null) {
				newExchg.setException(null);
				newExchg.removeProperty(Exchange.EXCEPTION_CAUGHT);
				newExchg.getIn().setBody(oldResp);
				return newExchg;
			} else if (newExchg.getException() == null
					&& newExchg.getIn().getBody() instanceof SearchResourceResponseDocument) {
				newResp = (SearchResourceResponseDocument) newExchg.getIn().getBody();
			}
		}

		//LOG.info("CamelSplitIndex >>>>>> "+ newExchg.getProperty("CamelSplitIndex", String.class));
		//LOG.info("CamelSplitComplete >>>>>> "+ newExchg.getProperty("CamelSplitComplete"));

		if (oldResp != null && newResp != null) {

			Map<String, List<String>> cktToCustMap = (Map<String, List<String>>) newExchg
					.getProperty("CircuitToCustMap");

			if (newResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getPartyList().size() > 0) {
				CustomerInfo customerInfo = new CustomerInfo();
				Party party = newResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getPartyArray(0);
				String subScrName = party.getPartyId() ;
				String hpcIndicator = null;
				String hpcExpiryDateValue = null;

				customerInfo.setName(party.getCommonName());
				customerInfo.setCustId(subScrName);
				
				if (party.getHasCustomerRoleList().size() > 0) {
					Customer customer = party.getHasCustomerRoleArray(0);					

					for (CharacteristicValue current : customer.getRootEntityDescribedByList()) {

						String characteristicName = current.getCharacteristicName();
						if (characteristicName.equalsIgnoreCase("HPCCustomerCode")) {
							hpcIndicator = current.getCharacteristicValue();
						} else if (characteristicName.equalsIgnoreCase("HPCExpirationDate")) {
							hpcExpiryDateValue = current.getCharacteristicValue();
						}
					}
					
					customerInfo.setAcna(customer.getACNA());					
					customerInfo.setHpcIndicator(hpcIndicator);
					customerInfo.setHpcExpirationDate(hpcExpiryDateValue);
					
					if (StringHelper.isEmpty(subScrName) && !StringHelper.isEmpty(customer.getACNA())) {
						subScrName = customer.getACNA();
					}
				}
				
				if (cktToCustMap.containsKey(subScrName)) {
					List<String> cktLst = cktToCustMap.get(subScrName);
					addCLCCustomerDetails (cktLst, customerInfo, oldResp
									.getSearchResourceResponse()
									.getSearchResponseDetailsArray(0)
									.getCircuitList());
					
				}				
			}
			
			newExchg.getIn().setBody(oldResp);
		}

		return newExchg;
	}

	private void addCLCCustomerDetails(List<String> cktNameLst, CustomerInfo customerInfo,
			List<SubNetworkConnection> cktLst) {

		for (SubNetworkConnection circuit : cktLst) {
			if (cktNameLst.contains(circuit.getCommonName())) {
				if (circuit.getOwnsResourceDetails().getCustomerList().size() > 0) {
					Customer cust = circuit.getOwnsResourceDetails().getCustomerArray(0);
					
					cust.setCommonName(customerInfo.getName());
					
					if (!StringHelper.isEmpty(customerInfo.getAcna())){
						cust.setACNA(customerInfo.getAcna());
					}
					if (!StringHelper.isEmpty(customerInfo.getCustId())){
						cust.setID(customerInfo.getCustId());
					}					
					if (!StringHelper.isEmpty(customerInfo.getHpcIndicator())){
						CharacteristicValue characteristicHPCIndicator = cust.addNewRootEntityDescribedBy();
						characteristicHPCIndicator.setCharacteristicName("HPCIndicator");
						characteristicHPCIndicator.setCharacteristicValue(customerInfo.getHpcIndicator());
					}
					if (!StringHelper.isEmpty(customerInfo.getHpcExpirationDate())){
						CharacteristicValue characteristicHPCExpiryDate = cust.addNewRootEntityDescribedBy();
						characteristicHPCExpiryDate.setCharacteristicName("HPCExpiryDate");
						characteristicHPCExpiryDate.setCharacteristicValue(customerInfo.getHpcExpirationDate());
					}
				}
			}
		}
	}

}