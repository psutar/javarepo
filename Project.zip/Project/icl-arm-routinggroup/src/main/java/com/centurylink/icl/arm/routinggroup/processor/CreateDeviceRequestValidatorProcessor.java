package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.CreateDeviceRequestDocument;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;

public class CreateDeviceRequestValidatorProcessor implements Processor{

	private static final String PORT_DIRECTION = "PortDirection";
	private static final String META_DATA_REQUIRED = "MetaDataRequired";
		
	@Override
	public void process(Exchange exchange) throws Exception {

		CreateDeviceRequestDocument createDevicerequest = (CreateDeviceRequestDocument)exchange.getIn().getBody();
		
		final String portDirectionCreateDevice = getRcv(createDevicerequest, PORT_DIRECTION);
		final String metaDataRequiredCreateDevice = getRcv(createDevicerequest, META_DATA_REQUIRED);
				
		if(metaDataRequiredCreateDevice!= null && (!("True".equalsIgnoreCase(metaDataRequiredCreateDevice)  || "False".equalsIgnoreCase(metaDataRequiredCreateDevice))))
		{
			throw new ICLRequestValidationException("Incorrect value of field 'MetadataRequired'");
		}
		if(portDirectionCreateDevice!= null && (!("NF".equalsIgnoreCase(portDirectionCreateDevice)  || "CF".equalsIgnoreCase(portDirectionCreateDevice))))
		{
			throw new ICLRequestValidationException("Incorrect value of field 'PortDirection'");
		}
		
	}

	public static String getRcv(CreateDeviceRequestDocument request, String characteristicName)
	{

		for (ResourceCharacteristicValue current : request.getCreateDeviceRequest().getDeviceList().get(0).getResourceDescribedByList())
		{
			if (current.getCharacteristicName().equalsIgnoreCase(characteristicName))
			{
				return current.getCharacteristicValue();
			}
		}

		return null;
	}
}
