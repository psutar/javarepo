package com.centurylink.icl.arm.routinggroup.predicates;


import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsEntityTypeForRouteRequest implements Predicate {

	private static final Log LOG = LogFactory.getLog(IsEntityTypeForRouteRequest.class);
	
  @Override
  public boolean matches(Exchange exchange) {
	  SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();

	  String version = null;
	  String entity = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getEntity();
	  if(searchResourceRequestDocument.getSearchResourceRequest().getMessageElements() != null
			  && searchResourceRequestDocument.getSearchResourceRequest().getMessageElements().getMessageAddressing() != null 
			  && searchResourceRequestDocument.getSearchResourceRequest().getMessageElements().getMessageAddressing().getServiceVersion() != null)
	  version = searchResourceRequestDocument.getSearchResourceRequest().getMessageElements().getMessageAddressing().getServiceVersion();

	  boolean entityType = false;
	  LOG.info("<<<<<<<<<<<<<<<<version Value>>>>>>>>>>>>>>>>>>>>>>>>>>>"+version);
	  LOG.info("<<<<<<<<<<<<<<<<Entity Value>>>>>>>>>>>>>>>>>>>>>>>>>>>"+entity);
	  if("Route".equalsIgnoreCase(entity) && "3.1".equalsIgnoreCase(version))
		  entityType = true;           
	  return entityType;
	 }
}
