package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsIncludeClcLocationFlag implements Predicate {

	@Override
	public boolean matches(Exchange exchg) 
	{
		SearchResourceRequestDocument in = (SearchResourceRequestDocument)exchg
				.getProperty(ARMRoutingConstants.ARM_REQUEST);
		
		if(exchg.getProperty(ARMRoutingConstants.ARM_RESPONSE) == null)
			exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE, exchg.getIn().getBody());
		
		List<ResourceCharacteristicValue> rcvList = 
				in.getSearchResourceRequest().getSearchResourceDetails()
				.getResourceCharacteristicValueList();
		
		boolean includeCLCLocation = false;
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName().equalsIgnoreCase("IncludeCLCLocation"))
				includeCLCLocation = Boolean.parseBoolean(rcv.getCharacteristicValue());					
		}		
		return includeCLCLocation;
	}

}
