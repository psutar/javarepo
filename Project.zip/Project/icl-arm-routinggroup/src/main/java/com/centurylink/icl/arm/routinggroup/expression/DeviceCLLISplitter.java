package com.centurylink.icl.arm.routinggroup.expression;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class DeviceCLLISplitter implements Expression 
{
	@SuppressWarnings("unchecked")
	@Override
	public <T> T evaluate(Exchange exchange, Class<T> arg1) 
	{
		exchange.setProperty(ARMRoutingConstants.ARM_RESPONSE, exchange.getIn().getBody());
		return (T) ((SearchResourceResponseDocument)exchange.getIn().getBody())
				.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList();
	}

}
