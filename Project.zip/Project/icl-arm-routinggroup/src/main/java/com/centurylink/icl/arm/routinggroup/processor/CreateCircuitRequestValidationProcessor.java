package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;

public class CreateCircuitRequestValidationProcessor implements Processor {
	
	private static final Log LOG = LogFactory.getLog(CreateCircuitRequestValidationProcessor.class);
	private static final String IsDiverse = "Is Diverse";
	private static final String ProtectRouting = "Protect Routing";

	@Override
	public void process(Exchange exchange) throws Exception {

		CreateCircuitRequestDocument createCircuitRequest = (CreateCircuitRequestDocument) exchange
				.getIn().getBody();

		final String isDiverseValue = getRcv(createCircuitRequest, IsDiverse);
		final String protectRoutingValue = getRcv(createCircuitRequest,	ProtectRouting);

		if (isDiverseValue != null && !isDiverseValue.equalsIgnoreCase("Yes")
				&& !isDiverseValue.equalsIgnoreCase("No")) {
			throw new ICLRequestValidationException("Incorrect IsDiverse Value in Request");
		}
		else if (protectRoutingValue != null
				&& !protectRoutingValue.equalsIgnoreCase("Active-Active")
				&& !protectRoutingValue.equalsIgnoreCase("Active-Standby")) {
			throw new ICLRequestValidationException("Incorrect ProtectRouting Value in Request");
		}		
		
		if(createCircuitRequest.getCreateCircuitRequest().getP2PCircuitList().size() > 0)
		{
			String resourceType = createCircuitRequest.getCreateCircuitRequest().getP2PCircuitList().get(0).getResourceType();
			if(resourceType.equalsIgnoreCase("UNI") || resourceType.equalsIgnoreCase("ENNI"))
			{
				exchange.setProperty("IsUNIENNIRequest", Boolean.TRUE);
			}
			else
			{
				exchange.setProperty("IsUNIENNIRequest", Boolean.FALSE);
			}
		}
		
	}

	private String getRcv(CreateCircuitRequestDocument request,String characteristicName) {

		if (request.getCreateCircuitRequest().getP2PCircuitList().size() > 0) {
			for (ResourceCharacteristicValue current : request
					.getCreateCircuitRequest().getP2PCircuitList().get(0)
					.getResourceDescribedByList()) {
				if (current.getCharacteristicName().equalsIgnoreCase(characteristicName)) {
					return current.getCharacteristicValue();
				}
			}
		}

		return null;
	}

}
