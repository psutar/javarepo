package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class IsPortNotUpdatedbyISYS implements Predicate{
	private static final Log LOG = LogFactory.getLog(IsPortNotUpdatedbyISYS.class);
	@Override
	public boolean matches(Exchange exchange) {
		List<Map<String, String>> auditLogDetails = (List<Map<String, String>>)exchange.getIn().getBody();
		String userName = null;
		if(auditLogDetails!=null && auditLogDetails.size()>0){
			Map<String,String> record = auditLogDetails.get(0);
			if(record!=null && !record.isEmpty()){
				userName = (String)record.get("USERNAME");
			}
		}
		
		/*if ((!StringHelper.isEmpty(userName) && !userName.equalsIgnoreCase("ISYS") && !userName.equalsIgnoreCase("Integrator"))
				|| (auditLogDetails == null || auditLogDetails.size() == 0))
		{
			if(userName.contains("_")){
				String prevPortStatus = userName.substring(userName.lastIndexOf("_") + 1);
				if(!exchange.getProperty("PORTSTATUS").toString().equalsIgnoreCase(prevPortStatus)){
					exchange.getIn().setBody((SearchResourceResponseDocument)exchange.getProperty(ARMRoutingConstants.ARM_RESPONSE));
					return true;
				}
				else
					return false;
			}
			exchange.getIn().setBody((SearchResourceResponseDocument)exchange.getProperty(ARMRoutingConstants.ARM_RESPONSE));
			return true;
		}*/
		if ((!StringHelper.isEmpty(userName) && !userName.equalsIgnoreCase("Integrator"))
				|| (auditLogDetails == null || auditLogDetails.size() == 0))
		{
			exchange.getIn().setBody((SearchResourceResponseDocument)exchange.getProperty(ARMRoutingConstants.ARM_RESPONSE));
			return true;
		}
		else
			return false;
	}

}
