package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;

import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class LocationSplitterForDeviceMetadata implements Expression{

	@Override
	public <T> T evaluate(Exchange exchange, Class<T> type) {
		SearchResourceResponseDocument srrd = (SearchResourceResponseDocument) exchange
				.getIn().getBody();
		
		List<String> locationList = new ArrayList<String>();
		
		if (srrd.getSearchResourceResponse()!=null && srrd.getSearchResourceResponse().getSearchResponseDetailsList()!=null 
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList()!=null
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().size()>0
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList()!=null
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().size()>0
				&& srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList().get(0).
				getInstalledAtAddress()!=null) {
			
			String locatioName = srrd.getSearchResourceResponse().getSearchResponseDetailsList().get(0).
								 getDeviceList().get(0).
								 getInstalledAtAddress().getCommonName();
			locationList.add(locatioName);
			exchange.setProperty("locationList", locationList);
		}

		return (T) locationList;
	}

}
