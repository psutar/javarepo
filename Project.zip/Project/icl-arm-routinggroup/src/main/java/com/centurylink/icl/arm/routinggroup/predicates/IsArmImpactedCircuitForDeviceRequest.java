package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsArmImpactedCircuitForDeviceRequest implements Predicate {

private static final Log LOG = LogFactory.getLog(IsArmImpactedCircuitForDeviceRequest.class);	
	
	@Override
	public boolean matches(Exchange exchange) {
		
		SearchResourceRequestDocument in = 
				((SearchResourceRequestDocument)exchange.getIn().getBody());
		
		List<ResourceCharacteristicValue> rcvList = in.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		boolean returnRelatedCircuitsFound = false;
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName().equalsIgnoreCase("ReturnRelatedCircuits") && rcv.getCharacteristicValue().equalsIgnoreCase("true"))
			{
				returnRelatedCircuitsFound = true;
				break;
			}
		}
		LOG.info("value of returnRelatedCircuitsFound"+returnRelatedCircuitsFound);
		return returnRelatedCircuitsFound;
	}
}
