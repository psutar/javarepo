package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.ValidationCondition;

public class DeviceDetailCLCCustomerRequestCreator implements Processor {

	private static final Log LOG = LogFactory
			.getLog(DeviceDetailCLCCustomerRequestCreator.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		SearchResourceResponseDocument armResponse = (SearchResourceResponseDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_RESPONSE);
		SearchResponseDetails searchResponseDetails = null;
		String custName = null;
		if (armResponse != null) {
			searchResponseDetails = armResponse.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0);
			custName = searchResponseDetails.getDeviceArray(0)
					.getOwnsResourceDetails().getCustomerArray(0).getCommonName();
		}

		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_REQUEST);
		SearchResourceDetails srd = searchResourceRequestDocument
				.getSearchResourceRequest().getSearchResourceDetails();

		srd.setCommonName(null);
		srd.setEntity(ARMRoutingConstants.CUSTOMER);
		srd.setLevel(ARMRoutingConstants.CUSTOMER);
		srd.setScope(ARMRoutingConstants.SUMMARY);
		srd.setSourceSystem(ARMRoutingConstants.CLC);

		ValidationCondition valCond =  srd.addNewFilterCriteria().addNewValidationCondition();
		valCond.setOperator("OR");
		Condition cond1 = valCond.addNewEqualCondition();
		cond1.setVariableName(ARMRoutingConstants.ACNA);
		cond1.setValue(custName);
	
		Condition cond2 = valCond.addNewEqualCondition();
		cond2.setVariableName(ARMRoutingConstants.CUST_ID);
		cond2.setValue(custName);	

		//LOG.info("CLC customer request for Device detail >>>>>>> "+ searchResourceRequestDocument);
		exchg.getIn().setBody(searchResourceRequestDocument);
	}

}
