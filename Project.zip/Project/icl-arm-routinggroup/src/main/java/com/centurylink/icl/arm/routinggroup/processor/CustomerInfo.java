package com.centurylink.icl.arm.routinggroup.processor;

public class CustomerInfo {
	
	private String name;
	private String acna;
	private String custId;
	private String hpcIndicator;
	private String hpcExpirationDate;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAcna() {
		return acna;
	}
	public void setAcna(String acna) {
		this.acna = acna;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getHpcIndicator() {
		return hpcIndicator;
	}
	public void setHpcIndicator(String hpcIndicator) {
		this.hpcIndicator = hpcIndicator;
	}
	public String getHpcExpirationDate() {
		return hpcExpirationDate;
	}
	public void setHpcExpirationDate(String hpcExpirationDate) {
		this.hpcExpirationDate = hpcExpirationDate;
	}	

}
