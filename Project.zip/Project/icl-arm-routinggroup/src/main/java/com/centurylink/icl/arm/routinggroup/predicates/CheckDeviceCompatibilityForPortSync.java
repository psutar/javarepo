package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMGetDeviceCompatibilityForPort;
import com.centurylink.icl.builder.util.StringHelper;

public class CheckDeviceCompatibilityForPortSync implements Predicate{
	
	 private static final Log LOG = LogFactory.getLog(ARMGetDeviceCompatibilityForPort.class);

	@Override
	public boolean matches(Exchange exchange) {
		
		Boolean deviceCompStatus =  exchange.getProperty("deviceCompStatus",Boolean.class);
		LOG.info("####deviceCompStatus in CheckDeviceCompatibilityForPortSync    :"+deviceCompStatus);
		if(deviceCompStatus){
			return true;
		}
		else{
		return false;
		}
	}

}
