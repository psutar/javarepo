package com.centurylink.icl.arm.routinggroup;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.BANAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.CircuitServiceAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.SearchServiceAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.predicates.IsEVCRequest;
import com.centurylink.icl.arm.routinggroup.predicates.IsIncludeBANFromDVARRequired;

public class ARMValueObjectRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {

		from("direct:SearchDeviceVO")
			.id("SearchDeviceVO")
			.setHeader(ARMRoutingConstants.methodName,constant("GetDeviceVO"))
			.beanRef(ARMRoutingConstants.armServiceInvoker, "callConnectorInternalArmMediation")
			.end();

		from("direct:SearchPortVO")
			.id("SearchPortVO")
			.setHeader(ARMRoutingConstants.methodName,constant("GetPortVO"))
			.beanRef(ARMRoutingConstants.armServiceInvoker, "callConnectorInternalArmMediation")
			.end();
		
		from("direct:SearchCircuitServiceVO")
			.id("SearchCircuitServiceVO")
			.multicast(new CircuitServiceAggregationStrategy())
				.parallelProcessing()
				.to("direct:SearchCircuitVO", "direct:SearchServiceVO")			
			.end()
			;
	
		from("direct:SearchCircuitVO")
			.id("SearchCircuitVO")
			.setHeader(ARMRoutingConstants.methodName,constant("GetCircuitVO"))
			.beanRef(ARMRoutingConstants.armServiceInvoker, "callConnectorInternalArmMediation")
			.end();
	
		
		from("direct:SearchServiceVO")
		.id("SearchServiceVO")
		.choice()
		.when(new IsIncludeBANFromDVARRequired())
		.to("direct:BANLookUpFromDVAR")
		.when(new IsEVCRequest())
		.to("direct:BANLookUpFromARMandQCTRL")
		.otherwise()
		.to("direct:ARMSearchServiceVO")
		.end();
		
		from("direct:BANLookUpFromARMandQCTRL")
		.id("BANLookUpFromARMandQCTRL")
		.processRef("storeOrigionalRequestProcessor")
		.multicast(new BANAggregationStrategy())
		.parallelProcessing()
		.to("direct:ARMSearchServiceVO","direct:QControlService")
		.end();
		
		from("direct:QControlService")
		.id("QControlService")
		.processRef("qControlRequestProcessor")
		.beanRef(ARMRoutingConstants.armServiceInvoker,"callQCtrlService")
		.end();
		
		from("direct:BANLookUpFromDVAR")
		.id("BANLookUpFromDVAR")
		.multicast(new SearchServiceAggregationStrategy())
		.parallelProcessing()
		.to("direct:ARMSearchServiceVO","direct:DVARSearchService")
		.end();
	
	from("direct:ARMSearchServiceVO")
	.id("ARMSearchServiceVO")
	.setHeader(ARMRoutingConstants.methodName, constant("GetServiceVO"))
	.beanRef(ARMRoutingConstants.armServiceInvoker,"callConnectorInternalArmMediation")
	.end();
	
	from("direct:DVARSearchService")
	.id("DVARSearchService")
	.processRef("dvarSearchRequestProcessor")
	.beanRef(ARMRoutingConstants.armServiceInvoker,"callDVARTransformFromCim")
	.beanRef(ARMRoutingConstants.armServiceInvoker,"callDVARConnector")
	.beanRef(ARMRoutingConstants.armServiceInvoker,"callDVARTransformToCim")
	.end();
	
    from("direct:SearchPreferredCompatibleONTModelsVO")
	.id("SearchPreferredCompatibleONTModelsVO")
	.setHeader(ARMRoutingConstants.methodName,constant("FetchPreferredCompatibleONTModelsVO"))
	.beanRef(ARMRoutingConstants.armServiceInvoker, "callConnectorInternalArmMediation")
	.end();	
    
    from("direct:QueryServiceRouteVO")
	.id("QueryServiceRouteForGPONVO")
	.setHeader(ARMRoutingConstants.methodName,constant("QueryServiceRouteForGPONVO"))
	.beanRef(ARMRoutingConstants.armServiceInvoker, "callConnectorInternalArmMediation")
	.end();	
    
	}

}
