package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.EnrichSearchResourceResponseWithCLCCustomer;
import com.centurylink.icl.builder.util.SearchResourceRequestDocumentHelper;
import com.centurylink.icl.common.Constants;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.MessageAddressing;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class ARMCircuitSummaryRoute extends RouteBuilder {

	static final String GetCircuitSummary = "GetCircuitSummary";
	private static final Log LOG = LogFactory.getLog(ARMCircuitSummaryRoute.class);
	private static final String customerId = "customerId";
	private static final String REQUEST_HOLDER = "IclRequestHolder";
	
	@Override
	public void configure() throws Exception {

		from("direct:armCircuitSummaryRoute")
		.routeId("ARMCircuitSummaryRoute")
		.choice()
			.when(isCLCCustomerIDPresent)
				.to("direct:circuitSummaryByCustomerId")
			 .otherwise()
			 	.to("direct:armCircuitSummary")
		.end();

		
		
		from("direct:circuitSummaryByCustomerId")
		.routeId("circuitSummaryByCustomerId")
		.process(createCLCCustomerRequest)
		.beanRef("armServiceInvoker","callCLCSearchCustomerOp")
		.process(createARMCircuitSummaryRequest)
		.to("direct:armCircuitSummary")
		.end();
		
		
		from("direct:armCircuitSummary")
		.to("bean:armCircuitSummaryValidationProcessor")
		.setHeader(methodName, constant(GetCircuitSummary))
		.beanRef("armServiceInvoker",
				"callConnectorInternalArmMediation")
		.enrich("direct:getCustomerDataFromCLC",new EnrichSearchResourceResponseWithCLCCustomer())
		.end();
		
	}
	
	
	private final Predicate isCLCCustomerIDPresent = new Predicate() {
		
		
		@Override
		public boolean matches(Exchange exchange) {
			
			//RequestHolder requestHolder = exchange.getProperty(ServiceConstants.REQUEST_HOLDER, RequestHolder.class); // This has to be coming from ServiceHub
			SearchResourceRequestDocument searchResourceRequestDocument = exchange.getIn().getBody(SearchResourceRequestDocument.class);
			RequestHolder requestHolder = null;
			try {
				
				requestHolder = new RequestHolder(searchResourceRequestDocument);
				
			} catch (Exception e) {
				LOG.error(e);
				
			}
			if(requestHolder != null)
			{
				Map<String, String> modifiers = requestHolder.getModifiers();
				if(modifiers.containsKey(customerId.toUpperCase()))
				{
					if(StringHelper.isEmpty(modifiers.get(customerId.toUpperCase())))
					{
						throw new ICLRequestValidationException("CustomerId should not be blank");
					}
					exchange.setProperty(REQUEST_HOLDER, requestHolder);
					return true;
				}
			}
			return false;
		}
	}; 
	
	private final Processor createCLCCustomerRequest = new Processor() {
		
		@Override
		public void process(Exchange exchange) throws Exception {

			RequestHolder requestHolder = exchange.getProperty(REQUEST_HOLDER, RequestHolder.class);
			String customerIdForCLC = requestHolder.getModifiers().get(customerId.toUpperCase());
			Map<String, String> validationRules = new HashMap<String, String>();
			validationRules.put("CLCCustomerId", customerIdForCLC);
			SearchResourceRequestDocument request = SearchResourceRequestDocumentHelper.createSearchResourceRequest(Constants.CUSTOMER, Constants.CUSTOMER, Constants.SUMMARY, Constants.CLC, null, null, null, validationRules, null, null);
			exchange.getIn().setBody(request);
		}
	};

	private final Processor createARMCircuitSummaryRequest = new Processor() {
		
		@Override
		public void process(Exchange exchange) throws Exception {
			
			SearchResourceResponseDocument responseDocument = exchange.getIn().getBody(SearchResourceResponseDocument.class);
			String customerName = null;
			//extract the Customer Name
			if(responseDocument.getSearchResourceResponse().getSearchResponseDetailsList() != null &&
					responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().size() > 0)
			{
				SearchResponseDetails searchResponseDetails = responseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
				if(searchResponseDetails.getPartyList() != null && searchResponseDetails.getPartyList().size() > 0)
				{
					if(!StringHelper.isEmpty(searchResponseDetails.getPartyList().get(0).getPartyId()))
					{
						customerName = searchResponseDetails.getPartyList().get(0).getPartyId();
					}
					else if(searchResponseDetails.getPartyList().get(0).getHasCustomerRoleList() != null 
								&& searchResponseDetails.getPartyList().get(0).getHasCustomerRoleList().size() > 0)
					{
						customerName = searchResponseDetails.getPartyList().get(0).getHasCustomerRoleList().get(0).getACNA();
					}
				}
			}
			if(StringHelper.isEmpty(customerName))
			{
				throw new ICLException("Could not find ACNA OR CustomerId from CLC");
			}
			Map<String,String> modifiers = new HashMap<String, String>();
			modifiers.put("CustomerName", customerName);
			MessageAddressing createMessageAddressing = SearchResourceRequestDocumentHelper.createMessageAddressing("NFMS", "ICL", exchange.getExchangeId(), "SearchResource", null, null, "SearchResource", "3.0");
			SearchResourceRequestDocument request  =SearchResourceRequestDocumentHelper.createSearchResourceRequest(Constants.CIRCUIT, Constants.CIRCUIT, Constants.SUMMARY, Constants.ARM, null, null, modifiers,null,null,createMessageAddressing);
			exchange.getIn().setBody(request);
		}
	};
	
}
