package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmDeviceDetailValidationProcessor implements Processor{	
	
private static final Log LOG = LogFactory.getLog(ArmDeviceDetailValidationProcessor.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();
		String deviceName = null;
		String deviceClliValue= null;
		
		deviceName = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		//LOG.info("deviceName in Arm request>>>"+ deviceName);		

		deviceClliValue = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "DeviceCLLI");
		//LOG.info("deviceClliValue in Arm request>>>"+ deviceClliValue);	
		
		if(StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(deviceClliValue))
		{
			throw new ICLRequestValidationException("Device Name or DeviceCLLI Required");
		}
		
		exchange.setProperty(ARMRoutingConstants.ARM_REQUEST, searchResourceRequestDocument);
	
	}	
}
