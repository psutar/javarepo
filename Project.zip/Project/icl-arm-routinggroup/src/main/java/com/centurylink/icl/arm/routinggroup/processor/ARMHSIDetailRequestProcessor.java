package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.ResourceRelationship;

public class ARMHSIDetailRequestProcessor implements Processor{
	private static final Log LOG=LogFactory.getLog(ARMHSIDetailRequestProcessor.class);
	
	private static final String OUTER_VLAN_NUMBER="OuterVlanNumber";
	private static final String SUBSCRIBER_CIRCUIT="SubscriberCircuit";
	private static final String SUBSCRIBER_PORT="SubscriberPort";
	@Override
	public void process(Exchange exchange) throws Exception 
	{
		ResourceRelationship resourceRelationship = (ResourceRelationship)exchange.getIn().getBody();
		
		if(resourceRelationship!=null && resourceRelationship.getCircuit()!=null && 
				resourceRelationship.getCircuit().getResourceDescribedByList()!=null)
		{
			for(ResourceCharacteristicValue rcv: resourceRelationship.getCircuit().getResourceDescribedByList())
			{
				if(rcv.getCharacteristicName().equalsIgnoreCase(OUTER_VLAN_NUMBER))
				{
					exchange.setProperty("VLANNumber", rcv.getCharacteristicValue());
				}
			}
		}
		
		if(resourceRelationship.getCircuit().getResourceRelationshipList()!=null && 
					resourceRelationship.getCircuit().getResourceRelationshipList().size()>0)
		{
			
			for(ResourceRelationship resourceRelation:resourceRelationship.getCircuit().getResourceRelationshipList())
			{
				
				if(resourceRelation.getCircuit()!=null && resourceRelation.getCircuit().getResourceRelationshipList()!=null
						&& resourceRelation.getCircuit().getResourceRelationshipList().size()>0)
				{
					for(ResourceRelationship resourceRelationShip:resourceRelation.getCircuit().getResourceRelationshipList())
					{
						if(resourceRelationShip.getCircuit().getAdditionalInfo().equalsIgnoreCase(SUBSCRIBER_CIRCUIT))
						{				
							if(resourceRelationShip.getCircuit().getZEndTpsList()!=null && resourceRelationShip.getCircuit().getZEndTpsList().size()>0
									&& resourceRelationShip.getCircuit().getZEndTpsList().get(0).getAdditionalInfo().equalsIgnoreCase(SUBSCRIBER_PORT))
							{
								if(resourceRelationShip.getCircuit().getZEndTpsList().get(0).getLogicalPhysicalResourceList()!=null 
										&& resourceRelationShip.getCircuit().getZEndTpsList().get(0).getLogicalPhysicalResourceList().size()>0)
								{
									PhysicalDevice physicalResource = resourceRelationShip.getCircuit().getZEndTpsList().get(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice();
									LOG.info("Device Name..."+physicalResource.getCommonName());
									if(physicalResource!=null)
									{
											exchange.setProperty("DeviceName", physicalResource.getCommonName());	
									}
								}
							}
							else if(resourceRelationShip.getCircuit().getAEndTpsList()!=null && resourceRelationShip.getCircuit().getAEndTpsList().size()>0
												&& resourceRelationShip.getCircuit().getAEndTpsList().get(0).getAdditionalInfo().equalsIgnoreCase(SUBSCRIBER_PORT))
							{
											
								if(resourceRelationShip.getCircuit().getAEndTpsList().get(0).getLogicalPhysicalResourceList()!=null 
													&& resourceRelationShip.getCircuit().getAEndTpsList().get(0).getLogicalPhysicalResourceList().size()>0)
								{
									PhysicalDevice physicalResource = resourceRelationShip.getCircuit().getAEndTpsList().get(0).getLogicalPhysicalResourceList().get(0).getPhysicalDevice();
									LOG.info("Device Name..."+physicalResource.getCommonName());
									if(physicalResource!=null)
									{
										exchange.setProperty("DeviceName", physicalResource.getCommonName());	
									}
								}				
							}
						}
					}	
				}
	        }
		}
	}
}
