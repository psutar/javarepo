package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class IsIncludeClcCustomerFlag implements Predicate {
	//private static final Log LOG = LogFactory.getLog(IsIncludeClcCustomerFlag.class);
	@Override
	public boolean matches(Exchange exchg) {
		SearchResourceRequestDocument in = (SearchResourceRequestDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_REQUEST);

		if (exchg.getProperty(ARMRoutingConstants.ARM_RESPONSE) == null)
			exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE, exchg.getIn().getBody());

		SearchResourceResponseDocument armResp = (SearchResourceResponseDocument) exchg
				.getProperty(ARMRoutingConstants.ARM_RESPONSE);
		//LOG.info("armResp>>>>>>"+armResp);
		
		String custName = null;		

		if (armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0) != null
				&& armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getCircuitList()
						.size() != 0) {
			if (armResp.getSearchResourceResponse()	.getSearchResponseDetailsArray(0).getCircuitArray(0)
					.getOwnsResourceDetails() != null && armResp.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0).getCircuitArray(0)
							.getOwnsResourceDetails().getCustomerList().size() > 0) {
				if (armResp.getSearchResourceResponse()
								.getSearchResponseDetailsArray(0)
								.getCircuitArray(0).getOwnsResourceDetails()
								.getCustomerArray(0).getCommonName() != null)
				{
					custName = armResp.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getCircuitArray(0).getOwnsResourceDetails()
							.getCustomerArray(0).getCommonName();
					exchg.setProperty("customerName", custName);
				}				
			}

		} else if (armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0) != null
				&& armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getP2PCircuitList()
						.size() != 0) {
			if (armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
					.getOwnsResourceDetails() != null && armResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
					.getOwnsResourceDetails().getCustomerList().size() > 0 ) {
				if (armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0)
								.getP2PCircuitArray(0).getOwnsResourceDetails()
								.getCustomerArray(0).getCommonName() != null) 
				{
					custName = armResp.getSearchResourceResponse().getSearchResponseDetailsArray(0)
							.getP2PCircuitArray(0).getOwnsResourceDetails()
							.getCustomerArray(0).getCommonName();
					exchg.setProperty("customerName", custName);
				} 
				
			}
		}

		List<ResourceCharacteristicValue> rcvList = in
				.getSearchResourceRequest().getSearchResourceDetails()
				.getResourceCharacteristicValueList();

		boolean includeCLCCustomer = false;

		for (ResourceCharacteristicValue rcv : rcvList) {
			if (rcv.getCharacteristicName().equalsIgnoreCase("IncludeCLCCustomer"))
				includeCLCCustomer = Boolean.parseBoolean(rcv.getCharacteristicValue());
		}
		return (includeCLCCustomer && !StringHelper.isEmpty(custName));
	}

}
