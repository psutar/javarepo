package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.ARMDetailAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.expression.DeviceCLLISplitter;
import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceDetailClcCustomerCallRequired;
import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceDetailClcLocationCallRequired;

public class ARMDeviceDetailRoute extends RouteBuilder{
	
	private static final Log LOG = LogFactory.getLog(ARMDeviceDetailRoute.class);
	static final String GetDeviceDetails = "GetDeviceDetails";
	
	@Override
	public void configure() throws Exception {
		from("direct:armNtmDeviceDetailRoute")		
		.routeId("ARMNtmDeviceDetailRoute")
			.to("bean:armDeviceDetailValidationProcessor")		
			.setHeader(methodName, constant(GetDeviceDetails))
			.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")				    
		    .choice()		
			   .when(new IsDeviceDetailClcCustomerCallRequired())
			      .to("bean:deviceDetailCLCCustomerRequestCreator")
                  .beanRef("armServiceInvoker","callCLCSearchCustomerOp")
                  .to("bean:deviceDetailResponseProcessor")
		     .end()		     
		     .choice()
		       .when(new IsDeviceDetailClcLocationCallRequired())
			   .split(new DeviceCLLISplitter(), new ARMDetailAggregationStrategy())
			   .parallelProcessing()
			   .beanRef("deviceDetailCLCLocationRequestCreator")
		       .beanRef("armServiceInvoker","callCLCSearchLocationOp")
		       .end();
			
			
	  }	
	
   }
