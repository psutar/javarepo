package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class ImpactedCircuitArmResponseSplitter implements Expression {
	private static final Log LOG = LogFactory.getLog(ImpactedCircuitArmResponseSplitter.class);

	@SuppressWarnings("unchecked")
	@Override
	public <T> T evaluate(Exchange exchg, Class<T> arg1) {
		SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) exchg
				.getIn().getBody();
		exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE,	searchResourceResponseDocument);		
		
		List<String> custInfoList = null;

		if (searchResourceResponseDocument.getSearchResourceResponse()
				.getSearchResponseDetailsArray(0).getCircuitList().size() > 0) {
			
			Map<String, List<String>> custToCktListMap = new HashMap<String, List<String>>();
			custInfoList = new ArrayList<String>();

			List<SubNetworkConnection> circuitList = searchResourceResponseDocument
					.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getCircuitList();
						
			for (SubNetworkConnection circuit : circuitList) {				
				String cktName = circuit.getCommonName();				
				
				if (circuit.getOwnsResourceDetails() != null && circuit.getOwnsResourceDetails().getCustomerList().size() > 0 
							&& circuit.getOwnsResourceDetails().getCustomerArray(0) != null ) {					
					String custName = circuit.getOwnsResourceDetails().getCustomerArray(0).getCommonName();
										
					List<String> cktLst = null;
					
					if(custName != null ){
						if(custToCktListMap.containsKey(custName)){
							custToCktListMap.get(custName).add(cktName);							
						}else{
							cktLst = new ArrayList<String>();
							cktLst.add(cktName);
							custToCktListMap.put(custName, cktLst);
						    custInfoList.add(custName);
						}
					}
				
				}
								
			}
			
			exchg.setProperty("CircuitToCustMap", custToCktListMap);			
		}
		
		return (T) custInfoList;
	}
		
}


