package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.builder.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequest;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ARMSearchDeviceByPortIDRequestProcessor implements Processor{
	private static final Log LOG = LogFactory.getLog(ARMSearchDeviceByPortIDRequestProcessor.class);
	@Override
	public void process(Exchange exchange) throws Exception {
		
		String portObjectID= exchange.getProperty("PORT_ID",String.class);
		SearchResourceRequestDocument requestDocument = SearchResourceRequestDocument.Factory.newInstance();
		SearchResourceRequest srr = requestDocument.addNewSearchResourceRequest();
		SearchResourceDetails searchDetails = srr.addNewSearchResourceDetails();
		searchDetails.setScope("Detailed");
		
		ResourceCharacteristicValue rcv = searchDetails.addNewResourceCharacteristicValue();
		rcv.setCharacteristicName("PortObjectID");
		if(!StringHelper.isEmpty(portObjectID)){
			rcv.setCharacteristicValue(portObjectID);
		}
		LOG.info("requestDocument...."+requestDocument);
		exchange.getIn().setBody(requestDocument);
	}

}
