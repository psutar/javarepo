package com.centurylink.icl.arm.routinggroup.predicates;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;

public class IsDeviceDetailClcCustomerCallRequired implements Predicate {
	
	private static final Log LOG = LogFactory.getLog(IsDeviceDetailClcCustomerCallRequired.class);

	@Override
	public boolean matches(Exchange exchg)
	{
		SearchResourceRequestDocument searchResourceRequestDocument =
				(SearchResourceRequestDocument)exchg.getProperty(ARMRoutingConstants.ARM_REQUEST);		
		
		SearchResourceResponseDocument armResponse = null;	
		SearchResponseDetails searchResponseDetails = null;
		String includeCLCCustomerValue = null;
		String custName = null;	
		
		armResponse = (SearchResourceResponseDocument)exchg.getIn().getBody();
		if(armResponse != null){
			exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE, armResponse);
			searchResponseDetails = armResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0);
			if(searchResponseDetails.getDeviceArray(0).getOwnsResourceDetails() != null && searchResponseDetails.getDeviceArray(0).getOwnsResourceDetails().getCustomerArray(0) != null){
				custName = searchResponseDetails.getDeviceArray(0).getOwnsResourceDetails().getCustomerArray(0).getCommonName();
			}
		}
		
		//LOG.info("custName in predicate >>>>>>> " + custName);
		List<ResourceCharacteristicValue> rcvList  = 
				searchResourceRequestDocument.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		for(ResourceCharacteristicValue rcv : rcvList)
		{						
			if(rcv.getCharacteristicName().equalsIgnoreCase("IncludeCLCCustomer"))
				includeCLCCustomerValue = rcv.getCharacteristicValue();			
		}

		if( !StringHelper.isEmpty(custName) && !StringHelper.isEmpty(includeCLCCustomerValue) && includeCLCCustomerValue.equalsIgnoreCase("true"))	
        	return true;
		else 
			return false;
	}
	

}
