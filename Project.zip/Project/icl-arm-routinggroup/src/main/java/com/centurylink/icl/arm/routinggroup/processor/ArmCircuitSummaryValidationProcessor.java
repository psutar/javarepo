package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

//import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmCircuitSummaryValidationProcessor implements Processor{	
	
private static final Log LOG = LogFactory.getLog(ArmCircuitSummaryValidationProcessor.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();
		String circuitId = null;
		String srNumber = null;
		String ban = null;
		String customerName = null;
		String addressLine1 = null;
		List<ResourceCharacteristicValue> rcvLst = null;
		String customerId = null;
		
		circuitId = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getCommonName();
		 
		//LOG.info("circuitId in Arm request>>>"+ circuitId);		
			
		rcvLst = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList();
		int size = rcvLst.size();
		
		if (size > 0) {
			for (ResourceCharacteristicValue current : rcvLst) {

				if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("SrNumber"))
				{
				 srNumber = current.getCharacteristicValue();	 
				}						
				else if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("BAN")) 
				{
					ban = current.getCharacteristicValue();			
				}				
				else if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("CustomerName"))
				{
					customerName = current.getCharacteristicValue();			
				}
				else if (current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("AddressLine1"))
				{
					addressLine1 = current.getCharacteristicValue();	
				}	
				else if (current.getCharacteristicName() != null && "CustomerId".equalsIgnoreCase(current.getCharacteristicName()))
				{
					customerId = current.getCharacteristicValue();
				}
				
			}
		}
		
			
		if(StringHelper.isEmpty(circuitId) && StringHelper.isEmpty(srNumber) && StringHelper.isEmpty(ban) && StringHelper.isEmpty(customerName) && StringHelper.isEmpty(addressLine1) && StringHelper.isEmpty(customerId))
		{
			throw new ICLRequestValidationException("Circuit Id or Sr Number or BAN or Customer Name or AddressLine1 Required");
		}
			
		
	}	

}