package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsIPTVServiceRequest implements Predicate{
	private static final Log LOG = LogFactory.getLog(IsIPTVServiceRequest.class);
	private static final String IPTV_SERVICE = "7635131111-IPTV";
	
	@Override
	public boolean matches(Exchange exchange) {
		SearchResourceRequestDocument requestDocument = (SearchResourceRequestDocument)exchange.getIn().getBody();
		SearchResourceDetails resourceDetails = requestDocument.getSearchResourceRequest().getSearchResourceDetails();
		if(resourceDetails!=null && resourceDetails.getCommonName().equalsIgnoreCase(IPTV_SERVICE)){
			return true;
		}
		else {
		return false;
		}
	}
}
