package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmContactDetailsRequestValidatorProcessor implements Processor {
	
	private static final Log LOG = LogFactory.getLog(ArmContactDetailsRequestValidatorProcessor.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();			
		final String deviceClli = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "DeviceCLLI");
		final String circuitID = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "CircuitID");
		final String deviceName = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "DeviceName");
		final String subscriberID = SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList(), "SubscriberID");
		
		if(StringHelper.isEmpty(circuitID) && StringHelper.isEmpty(deviceClli) && StringHelper.isEmpty(deviceName) && StringHelper.isEmpty(subscriberID))
		{
			throw new ICLRequestValidationException("Required field CircuitID or DeviceCLLI or DeviceName or SubscriberID is not passed or incorrect in request");
		}
		
		if(!StringHelper.isEmpty(circuitID) || !StringHelper.isEmpty(deviceClli) || !StringHelper.isEmpty(deviceName))
		{
			exchange.setProperty("clcCallRequired", Boolean.TRUE);
		}
		else
		{
			exchange.setProperty("clcCallRequired", Boolean.FALSE);
		}
		
	}
}
