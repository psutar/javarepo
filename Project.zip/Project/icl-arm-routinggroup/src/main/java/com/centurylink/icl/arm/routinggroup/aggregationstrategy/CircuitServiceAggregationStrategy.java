package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class CircuitServiceAggregationStrategy implements AggregationStrategy {
	
	private static final Log LOG = LogFactory.getLog(CircuitServiceAggregationStrategy.class);
	
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		if (oldExchange == null)
			return newExchange;
		
		if (LOG.isDebugEnabled())
		{
			LOG.debug("OLD EXCHANGE:" + oldExchange.getIn().getBody());
			if (oldExchange.getException() != null)
				LOG.debug("OLD EXCHANGE ERROR:" + oldExchange.getException().getMessage());
			LOG.debug("NEW EXCHANGE:" + newExchange.getIn().getBody());
			if (newExchange.getException() != null)
				LOG.debug("NEW EXCHANGE ERROR:" + newExchange.getException().getMessage());
		}
		
		if (oldExchange.getException() == null)
		{
			if (newExchange.getException() == null)
			{
				//Both Circuit and Service found... return both
				oldExchange.getIn().setBody(combineCircuitAndService(oldExchange, newExchange));
			} else {
				//Only Circuit Found
				return oldExchange;
			}
		} else if (newExchange.getException() == null) {
			//Only a Service was found 
			return newExchange;
		} 
		
		return oldExchange;
	}
	
	private SearchResourceResponseDocument combineCircuitAndService(Exchange circuits, Exchange services)
	{
		//TODO:Mickey - How many non checked NullPointers or ClassCast can I get from this
		SearchResourceResponseDocument circuitResponse = (SearchResourceResponseDocument) circuits.getIn().getBody();
		SearchResourceResponseDocument serviceResponse = (SearchResourceResponseDocument) services.getIn().getBody();
		
		for (SubNetworkConnection serviceList : serviceResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList())
		{
			circuitResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList().add(serviceList);
		}
		
		return circuitResponse;
	}

}
