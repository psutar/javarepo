package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class EnrichSearchResourceResponseWithCLCCustomer implements AggregationStrategy{



	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		
		if(oldExchange.getException() == null)
		{
			SearchResourceResponseDocument searchResourceResponseDocument = oldExchange.getIn().getBody(SearchResourceResponseDocument.class);
			if(newExchange != null	&& newExchange.getIn().getBody() instanceof Map)
			{
				Map<String, Party> customerMap = (Map<String, Party>)newExchange.getIn().getBody();
				if(customerMap.keySet().size() > 0)
				{
					enrichCLCCustomerDetails(searchResourceResponseDocument, customerMap);
					oldExchange.getIn().setBody(searchResourceResponseDocument);
				}
			}
		}
		
		return oldExchange;
		
		
	}

	
	private void enrichCLCCustomerDetails(SearchResourceResponseDocument searchResourceResponseDocument,Map<String,Party> customersMap)
	{
		
		List<SubNetworkConnection> circuitList = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList();
		List<PhysicalDevice> deviceList = searchResourceResponseDocument.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getDeviceList();
		
		if(circuitList != null && circuitList.size() > 0 )
		{
			for (SubNetworkConnection subNetworkConnection : circuitList) {
				
				OwnsResourceDetails ownsResourceDetails = subNetworkConnection.getOwnsResourceDetails();
				if(ownsResourceDetails != null && ownsResourceDetails.getCustomerList() != null && ownsResourceDetails.getCustomerList().size() > 0)
				{
					Customer customer = ownsResourceDetails.getCustomerList().get(0);
					if(customer!=null){
					Party party = customersMap.get(customer.getCommonName());
					if(party!=null){
						customer.setObjectID(party.getObjectID());
						if (!StringHelper.isEmpty(party.getPartyId())){
							customer.setID(party.getPartyId());
							customer.setCommonName(party.getPartyId());
						}
						else if(party.getHasCustomerRoleList() != null && party.getHasCustomerRoleList().size() > 0)
						{
							customer.setACNA(party.getHasCustomerRoleList().get(0).getACNA());
							customer.setCommonName(party.getHasCustomerRoleList().get(0).getACNA());
						}
						customer.setDescription(party.getCommonName());
					 }
				   }
				}
			}
			
		}
		else if(deviceList != null && deviceList.size() > 0)
		{
			for (PhysicalDevice physicalDevice : deviceList) {
				
				OwnsResourceDetails ownsResourceDetails = physicalDevice.getOwnsResourceDetails();
				if(ownsResourceDetails != null && ownsResourceDetails.getCustomerList() != null && ownsResourceDetails.getCustomerList().size() > 0)
				{
					Customer customer = ownsResourceDetails.getCustomerList().get(0);
					if(customer!=null){
						Party party = customersMap.get(customer.getCommonName());
						if(party!=null){
							customer.setCommonName(party.getCommonName());					
							customer.setObjectID(party.getObjectID());
							if (!StringHelper.isEmpty(party.getPartyId())){
								customer.setID(party.getPartyId());
							}
						}
					}
				}
			}
		}
	}
}
