package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class ArmDeviceCLCLocationRequestCreater implements Processor {
	private static final Log LOG = LogFactory
			.getLog(ArmDeviceCLCLocationRequestCreater.class);

	@Override
	public void process(Exchange exchg) throws Exception {

		String locatioName = (String)exchg.getIn().getBody();
		
				SearchResourceRequestDocument origRequest = (SearchResourceRequestDocument) exchg
						.getProperty(ARMRoutingConstants.ARM_REQUEST);
				SearchResourceRequestDocument searchResourceRequestDocument = SearchResourceRequestDocument.Factory
						.parse(origRequest.toString());

				SearchResourceDetails srd = searchResourceRequestDocument
						.getSearchResourceRequest().getSearchResourceDetails();

				srd.setEntity(ARMRoutingConstants.LOCATION);
				srd.setLevel(ARMRoutingConstants.LOCATION);
				srd.setScope(ARMRoutingConstants.DETAILED);
				srd.setSourceSystem(ARMRoutingConstants.CLC);
				srd.setCommonName(locatioName);
				exchg.getIn().setBody(searchResourceRequestDocument);
	}

}