package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class ImpactedCircuitLocationResponseAggregationStrategy implements AggregationStrategy {
	private static final Log LOG = LogFactory.getLog(ImpactedCircuitLocationResponseAggregationStrategy.class);

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

		SearchResourceResponseDocument oldResp = null;
		SearchResourceResponseDocument newResp = null;
		if(oldExchange==null){
			oldExchange=newExchange.copy();
			oldExchange.setException(null);
			oldExchange.getIn().setBody(newExchange.getProperty(ARMRoutingConstants.ARM_RESPONSE));
		}
		
		if (newExchange != null&& newExchange.getException() == null && newExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			newResp = (SearchResourceResponseDocument) newExchange.getIn().getBody();
		}

		if (oldExchange != null && oldExchange.getException() == null && oldExchange.getIn().getBody() instanceof SearchResourceResponseDocument) {
			oldResp = (SearchResourceResponseDocument) oldExchange.getIn().getBody();
		}
		
		if(oldResp!=null && newResp!=null){
			oldExchange.getIn().setBody(aggregateLocationDetails(oldExchange,newExchange));
		}
		else if (oldResp != null && newExchange.getException() != null) {
			 oldExchange.setProperty(Exchange.EXCEPTION_CAUGHT,null);
			 oldExchange.setException(null);
			 oldExchange.getIn().setBody(oldResp);
	    }

	   return oldExchange;		
	}
	
	private SearchResourceResponseDocument aggregateLocationDetails(Exchange oldExchange, Exchange newExchange){
		SearchResourceResponseDocument armResponse = (SearchResourceResponseDocument)oldExchange.getIn().getBody();
		SearchResourceResponseDocument clcResponse = (SearchResourceResponseDocument)newExchange.getIn().getBody();
		
		if(clcResponse.getSearchResourceResponse().getSearchResponseDetailsList()!=null &&
			clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().size()>0 &&
			clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList()!=null
			&& clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList().size()>0){
			
			List<AmericanPropertyAddress> clcAddressList = clcResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getAddressDetailsList();
			for(AmericanPropertyAddress clcAddress:clcAddressList){
				
		if (armResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0).getCircuitList()!=null &&
				armResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0).getCircuitList().size() > 0) {

			List<SubNetworkConnection> circuitList = armResponse.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0).getCircuitList();

	for (SubNetworkConnection circuit : circuitList) {		
			if (circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList() != null
					&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().size() > 0
					&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
						String deviceLocationAEnd = circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();
						if(clcAddress.getCommonName().equalsIgnoreCase(deviceLocationAEnd)){
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setCommonName(clcAddress.getCommonName());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setCLLI(clcAddress.getCLLI());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setAddressLine1(clcAddress.getAddressLine1());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setAddressLine2(clcAddress.getAddressLine2());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setLocality(clcAddress.getLocality());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setStateOrProvince(clcAddress.getStateOrProvince());
							circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).setPostcode(clcAddress.getPostcode());
							if(clcAddress.getRootEntityDescribedByList()!=null && 
									clcAddress.getRootEntityDescribedByList().size()>0){
								for(CharacteristicValue cv:clcAddress.getRootEntityDescribedByList()){
									if(cv.getCharacteristicName().equalsIgnoreCase(ARMRoutingConstants.SWC)){
										circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getRootEntityDescribedByList().add(cv);
									}
								}
							}
							
						}
					}
			if (circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList() != null
					&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().size() > 0
					&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
						String deviceLocationZEnd =circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();
						if(clcAddress.getCommonName().equalsIgnoreCase(deviceLocationZEnd)){
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setCommonName(clcAddress.getCommonName());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setCLLI(clcAddress.getCLLI());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setAddressLine1(clcAddress.getAddressLine1());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setAddressLine2(clcAddress.getAddressLine2());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setLocality(clcAddress.getLocality());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setStateOrProvince(clcAddress.getStateOrProvince());
							circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).setPostcode(clcAddress.getPostcode());
							if(clcAddress.getRootEntityDescribedByList()!=null && 
									clcAddress.getRootEntityDescribedByList().size()>0){
								for(CharacteristicValue cv:clcAddress.getRootEntityDescribedByList()){
									if(cv.getCharacteristicName().equalsIgnoreCase(ARMRoutingConstants.SWC)){
										circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getRootEntityDescribedByList().add(cv);
									}
								}
							}
						}
					  }
				   }
				}
			}
		}
		return armResponse;
	} 
}
