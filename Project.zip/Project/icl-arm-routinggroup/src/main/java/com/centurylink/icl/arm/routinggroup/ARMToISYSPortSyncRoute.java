package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.predicates.IsDeviceDualInventoried;
import com.centurylink.icl.arm.routinggroup.predicates.IsPortNotUpdatedbyISYS;


public class ARMToISYSPortSyncRoute extends RouteBuilder{
	private static final Log LOG=LogFactory.getLog(ARMToISYSPortSyncRoute.class);
	@Override
	public void configure() throws Exception {
		
		from("direct:ARMtoISYSPortSyncRoute")
		.id("ARMtoISYSPortSyncRoute")
		.beanRef("armSearchDeviceByPortIDRequestProcessor")
		.setHeader(methodName, constant("GetDeviceByPortVO"))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.beanRef("armSearchDeviceByPortIDResponseProcessor")
		.setHeader(methodName, constant("PortSyncAuditLog"))
		.setProperty("action", constant("Search"))
		.beanRef("armServiceInvoker", "callArmMediationPortSyncAuditService")
		.removeProperty("action")
		.choice()
		.when(new IsPortNotUpdatedbyISYS())
		.to("direct:ARMSearchDeviceForPort")
		.otherwise()
		.end();
		
		from("direct:ARMSearchDeviceForPort")
		.routeId("ARMSearchDeviceForPort")
		.beanRef("armGetDeviceCompatibilityForPort","checkIsDeviceDualInventoried")
		.choice()
		.when(new IsDeviceDualInventoried())
		.setProperty("TargetRoute",constant("direct:ISYSReqGeneratorByPort"))
		.beanRef("armServiceInvoker", "callIntegratorService")
		.to("direct:portSyncAuditLogInsertForISYS")
		.otherwise()
		.end();
	}

}
