package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

public class GetEVCSPRoute extends RouteBuilder {

	private static final String getEVCSP =  "GetEVCSP";
	
	@Override
	public void configure() throws Exception {

		from("direct:GetEVCSPRoute")
		.routeId("GetEVCSPRoute")
		.setHeader(methodName,constant(getEVCSP))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.removeHeader(getEVCSP);
		
	}

}
