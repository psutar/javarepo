package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;

import java.util.List;
import org.apache.camel.Body;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.exceptions.ICLRequestValidationException;
import com.iclnbi.iclnbiV200.AmericanPropertyAddress;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class BuildingClliESLocationSplitter {

	private static final Log LOG = LogFactory.getLog(BuildingClliESLocationSplitter.class);

  public List<String> splitLocations(@Body Object body) throws Exception {
	  
	  List<String> locationNameLst = new ArrayList<String>();
	  
	  if (body != null && body instanceof SearchResourceResponseDocument) {
			
			SearchResourceResponseDocument clcResp = (SearchResourceResponseDocument) body;
			//LOG.info("CLC Location Response : " + clcResp);

			if (clcResp.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getAddressDetailsList()
					.size() > 0) {
				List<AmericanPropertyAddress> addrrLst = clcResp
						.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0)
						.getAddressDetailsList();
								
				for (AmericanPropertyAddress addrr : addrrLst) {
					locationNameLst.add(addrr.getCommonName());					
				}

				if (locationNameLst.size() == 0) {
					throw new ICLRequestValidationException("No Equipment Site Location found in CLC for a given Building CLLI");
				}
			}
	  }
   
    return locationNameLst;
  }
}
