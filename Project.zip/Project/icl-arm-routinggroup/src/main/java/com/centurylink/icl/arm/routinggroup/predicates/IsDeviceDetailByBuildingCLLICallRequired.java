package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsDeviceDetailByBuildingCLLICallRequired implements Predicate{

	@Override
	public boolean matches(Exchange exchg) {
		
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchg.getIn().getBody();
		
		
		if(PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "BuildingCLLI"))
		{
			exchg.setProperty("BuildingCLLIAvailable", true);
			return true;
		}
		else
		{
		
			boolean AddressNumPrefix= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "AddressNumberPrefix");
			boolean AddressNumber= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "AddressNumber");
			boolean AddressNumberSuffix= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "AddressNumberSuffix");
			boolean StreetDirectionalPrefix= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "StreetDirectionalPrefix");
			boolean StreetName= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "StreetName");
			boolean StreetType= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "StreetType");
			boolean StreetDirectionalSuffix= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "StreetDirectionalSuffix");
			boolean City= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "City");
			boolean State= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "State");
			boolean Zip= PredicateHelper.checkCharacteristicName(searchResourceRequestDocument, "Zip");
			
					 
			if(AddressNumPrefix || AddressNumber || AddressNumberSuffix || StreetDirectionalPrefix || StreetName 
					|| StreetType || StreetDirectionalSuffix || City || State || Zip ){
			
				exchg.setProperty("AddressDetailsAvailable", true);
				return true;
				
			}
		}
		
		
		return false;
	}

}
