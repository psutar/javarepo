package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.GetDevicesByBuildingClliAggregationStrategy;

public class GetDevicesByBuildingClliRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {

		from("direct:GetDevicesByBuildingClliRoute")
			.routeId("GetDevicesByBuildingClliRoute")
			.processRef("storeOrigionalRequestProcessor")
			.to("bean:getDevicesByBuildingClliValidationProcesor")
			.beanRef("getDevicesByBuildingClliRequestCreator")
			.beanRef("armServiceInvoker", "callCLCSearchLocationOp")			
			.split().method("buildingClliESLocationSplitter", "splitLocations")
				.aggregationStrategy(new GetDevicesByBuildingClliAggregationStrategy())			
				.parallelProcessing()
				.beanRef("getDeviceDtlsByLocationRequestCreator")
				.setHeader(methodName, constant("GetDeviceDetails"))
				.beanRef("armServiceInvoker", "callConnectorInternalArmMediation") 
			.end();
	}

}
