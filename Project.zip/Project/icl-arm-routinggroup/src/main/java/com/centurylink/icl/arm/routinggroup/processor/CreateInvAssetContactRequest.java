package com.centurylink.icl.arm.routinggroup.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.centurylink.icl.clc.connector.data.InventoryAssetRequest;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.CharacteristicValue;
import com.iclnbi.iclnbiV200.CreateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.CreateCircuitResponseDocument;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.CustomerAgent;
import com.iclnbi.iclnbiV200.InvolvementRole;
import com.iclnbi.iclnbiV200.OwnsResourceDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.TopologicalLink;
import com.iclnbi.iclnbiV200.UpdateCircuitRequestDocument;
import com.iclnbi.iclnbiV200.UpdateCircuitResponseDocument;

public class CreateInvAssetContactRequest implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();
		
		List<TopologicalLink> p2pCircuitList = new ArrayList<TopologicalLink>();
		SubNetworkConnection circuit = null;
		List<TopologicalLink> p2pResponse = new ArrayList<TopologicalLink>();
		SubNetworkConnection circuitResponse = null;
		String user = "";
		
		if (exchange.getIn().getBody() instanceof CreateCircuitResponseDocument)
		{
			CreateCircuitResponseDocument createCircuitResponseDocument = (CreateCircuitResponseDocument) exchange.getIn().getBody();
			p2pResponse = createCircuitResponseDocument.getCreateCircuitResponse().getP2PCircuitList();
			circuitResponse = createCircuitResponseDocument.getCreateCircuitResponse().getCircuit();
			
			String origRequest = (String) exchange.getProperty("ORIGREQUEST");
			CreateCircuitRequestDocument createCircuitRequestDocument = CreateCircuitRequestDocument.Factory.parse(origRequest);
			
			p2pCircuitList = createCircuitRequestDocument.getCreateCircuitRequest().getP2PCircuitList();
			circuit = createCircuitRequestDocument.getCreateCircuitRequest().getCircuit();
			user = createCircuitRequestDocument.getCreateCircuitRequest().getMessageElements().getMessageAddressing().getFrom();
		} else {
			UpdateCircuitResponseDocument updateCircuitResponseDocument = (UpdateCircuitResponseDocument) exchange.getIn().getBody();
			p2pResponse.add(updateCircuitResponseDocument.getUpdateCircuitResponse().getP2PCircuit());
			circuitResponse = updateCircuitResponseDocument.getUpdateCircuitResponse().getCircuit();
			
			String origRequest = (String) exchange.getProperty("ORIGREQUEST");
			UpdateCircuitRequestDocument updateCircuitRequestDocument = UpdateCircuitRequestDocument.Factory.parse(origRequest);
			
			p2pCircuitList.add(updateCircuitRequestDocument.getUpdateCircuitRequest().getP2PCircuit());
			circuit = updateCircuitRequestDocument.getUpdateCircuitRequest().getCircuit();
			user = updateCircuitRequestDocument.getUpdateCircuitRequest().getMessageElements().getMessageAddressing().getFrom();
		}
		
		
		if (p2pCircuitList.size() > 0)
		{
			assetRequests = extractAssetsFromP2PCircuitList(p2pCircuitList, user);
			assetRequests = enrichWithNativeId(p2pResponse, assetRequests);
		} else {
			assetRequests = extractAssetsFromCircuit(circuit, user);
			assetRequests = enrichWithNativeId(circuitResponse, assetRequests);
		}
		
		exchange.getIn().setBody(assetRequests);
	}
	
	private List<InventoryAssetRequest> enrichWithNativeId(List<TopologicalLink> p2pResponse, List<InventoryAssetRequest> assetRequests)
	{
		for (TopologicalLink circuit:p2pResponse)
		{
			String circuitId = circuit.getCommonName();
			String objectId = circuit.getObjectID();
			
			for (InventoryAssetRequest assetRequest:assetRequests)
			{
				if (assetRequest.getAssetName().equalsIgnoreCase(circuitId))
				{
					assetRequest.setAssetId(objectId);
				}
			}
		}
		
		return assetRequests;
	}

	private List<InventoryAssetRequest> enrichWithNativeId(SubNetworkConnection circuit, List<InventoryAssetRequest> assetRequests)
	{
			String circuitId = circuit.getCommonName();
			String objectId = circuit.getObjectID();
			
			for (InventoryAssetRequest assetRequest:assetRequests)
			{
				if (assetRequest.getAssetName().equalsIgnoreCase(circuitId))
				{
					assetRequest.setAssetId(objectId);
				}
			}
		
		return assetRequests;
	}
	
	private List<InventoryAssetRequest> extractAssetsFromCircuit(SubNetworkConnection circuit, String user)
	{
		String circuitName = null;
		String type = null;
		String sourceSystem = null;
		
		circuitName = circuit.getCommonName();
		sourceSystem = circuit.getSourceSystem();
		type = circuit.getResourceType();
		if (type.equalsIgnoreCase("UNI") || type.equalsIgnoreCase("EVC") || type.equalsIgnoreCase("ENNI")  || type.equalsIgnoreCase("OVC") || type.equalsIgnoreCase("ENNI LINK SERVICE"))
		{
			type = "SERVICE";
		} else {
			type = "CIRCUIT";
		}
		
		return buildAssetRequest(circuit.getOwnsResourceDetails(), circuitName, type, sourceSystem, user);
	}
	
	private List<InventoryAssetRequest> extractAssetsFromP2PCircuitList(List<TopologicalLink> p2pCircuitList, String user)
	{
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();
		
		for (TopologicalLink p2pCircuit:p2pCircuitList)
		{
			String circuitName = null;
			String type = null;
			String sourceSystem = null;
			
			circuitName = p2pCircuit.getCommonName();
			sourceSystem = p2pCircuit.getSourceSystem();
			type = p2pCircuit.getResourceType();
			if (type.equalsIgnoreCase("UNI") || type.equalsIgnoreCase("EVC") || type.equalsIgnoreCase("ENNI")  || type.equalsIgnoreCase("OVC") || type.equalsIgnoreCase("ENNI LINK SERVICE"))
			{
				type = "SERVICE";
			} else {
				type = "CIRCUIT";
			}
			
			assetRequests.addAll(buildAssetRequest(p2pCircuit.getOwnsResourceDetails(), circuitName, type, sourceSystem, user));
		}
		
		return assetRequests;
	}

	private List<InventoryAssetRequest> buildAssetRequest(OwnsResourceDetails ownsResourceDetails, String circuitName, String type, String sourceSystem, String user)
	{
		List<InventoryAssetRequest> assetRequests = new ArrayList<InventoryAssetRequest>();

		String customer = null;
		String firstName = null;
		String lastName = null;
		String role = null;

		List<Customer> customerList = ownsResourceDetails.getCustomerList();
		if (customerList != null && customerList.size() > 0)
		{
			customer = customerList.get(0).getCommonName();
		}
		
		List<CustomerAgent> contactList = ownsResourceDetails.getCustomerAgentList();
		for (CustomerAgent contact:contactList)
		{
			List<InvolvementRole> partyRoles = contact.getPartyRolePlaysList();
			if (partyRoles != null && partyRoles.size() > 0)
			{
				//Assume the first role
				role = partyRoles.get(0).getInvolvementRole();
			}
			for (CharacteristicValue rootEntity:contact.getRootEntityDescribedByList())
			{
				if (!StringHelper.isEmpty(rootEntity.getCharacteristicName()))
				{
					if (rootEntity.getCharacteristicName().equalsIgnoreCase("FirstName"))
					{
						firstName = rootEntity.getCharacteristicValue();
					}
					if (rootEntity.getCharacteristicName().equalsIgnoreCase("LastName"))
					{
						lastName = rootEntity.getCharacteristicValue();
					}
				}
			}
			if (!StringHelper.isEmpty(circuitName) &&
					!StringHelper.isEmpty(customer) &&
					!StringHelper.isEmpty(firstName) &&
					!StringHelper.isEmpty(lastName) &&
					!StringHelper.isEmpty(role) &&
					!StringHelper.isEmpty(type) &&
					!StringHelper.isEmpty(sourceSystem) 
					)
			{
				InventoryAssetRequest iar = new InventoryAssetRequest();
				iar.createAddContactToAssetRequest(firstName, lastName, role, customer, circuitName, null, sourceSystem, type, user);
				assetRequests.add(iar);
			}
		}
		
		return assetRequests;
	}
}
