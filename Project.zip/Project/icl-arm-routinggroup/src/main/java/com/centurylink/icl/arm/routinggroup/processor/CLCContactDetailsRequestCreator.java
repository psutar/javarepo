package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.SearchResourceRequestDocumentReaderCIM2;
import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.Condition;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;
import com.iclnbi.iclnbiV200.ValidationCondition;

public class CLCContactDetailsRequestCreator implements Processor {
	
	private static final Log LOG = LogFactory.getLog(CLCContactDetailsRequestCreator.class);
	
	@Override
	public void process(Exchange exchange) throws Exception {
		SearchResourceRequestDocument searchResourceRequestDocument = (SearchResourceRequestDocument) exchange.getIn().getBody();			
		List<ResourceCharacteristicValue> rcvLst = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails().getResourceCharacteristicValueList();
		
		SearchResourceDetails searchResourceDetails =  searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		searchResourceDetails.setSourceSystem("CLC");
		searchResourceDetails.setEntity("CONTACT");
		searchResourceDetails.setLevel("CONTACT");
		searchResourceDetails.setScope("SUMMARY");
		
		ValidationCondition validationCondition = searchResourceDetails.addNewFilterCriteria().addNewValidationCondition();
		Condition cond = validationCondition.addNewEqualCondition();
		cond.setVariableName("ASSETVALUE");
		
		if(!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(rcvLst, "DeviceCLLI")))
				cond.setValue(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(rcvLst, "DeviceCLLI"));
		else if(!StringHelper.isEmpty(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(rcvLst, "circuitID")))
			cond.setValue(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(rcvLst, "circuitID"));
		else
			cond.setValue(SearchResourceRequestDocumentReaderCIM2.getResourceCharacteristicValue(rcvLst, "DeviceName"));
		
		rcvLst.clear();
		
		LOG.info("CLC request!!... "+searchResourceRequestDocument.xmlText());
		
		exchange.getIn().setBody(searchResourceRequestDocument);
	}
	
}
