package com.centurylink.icl.arm.routinggroup.bean;

import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.util.tracker.ServiceTracker;

import com.centurylink.icl.common.util.StringHelper;
import com.centurylink.icl.exceptions.ICLException;
import com.centurylink.icl.xref.connector.interfaces.XrefLookupServiceInterface;
import com.iclnbi.iclnbiV200.Card;
import com.iclnbi.iclnbiV200.PhysicalDevice;
import com.iclnbi.iclnbiV200.PhysicalPort;
import com.iclnbi.iclnbiV200.Rack;
import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.Shelf;

public class GetPortStatsTrafx {
    private ServiceTracker xrefTracker;
    
    private static final Log LOG = LogFactory.getLog(GetPortStatsTrafx.class);
    
    public GetPortStatsTrafx(BundleContext bundleContext) throws Exception
    {
		Filter filter = bundleContext.createFilter("(&(name=xrefLookupService))");
		xrefTracker = new ServiceTracker(bundleContext, filter, null);
		
		xrefTracker.open();
    }
    
    public void close()
    {
    	xrefTracker.close();
    }
    
    public void getSystemType(Exchange exchg)
    {
    	String deviceType = (String) exchg.getProperty("DEVICE_TYPE");
    	
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	
    	String systemType = lookupService.getFieldValue("MAP_DEVICE_SYSTEM_TYPE", "DEVICE_TYPE", deviceType, "SOURCE_SYSTEM", "ARM", "SYSTEM_TYPE");
    	
    	LOG.info("systemType: " + systemType);
    	
    	exchg.setProperty("SYSTEM_TYPE", systemType); 
    }
    
    
    public void mergeMandatoryHelpTextInTrafx(Exchange exchange) throws Exception
    {    	
    	Object temp = exchange.getIn().getBody();		
		if(temp instanceof SearchResourceResponseDocument){
					
			SearchResourceResponseDocument trafxResp = (SearchResourceResponseDocument)exchange.getIn().getBody();
			
			PhysicalDevice  physicalDevice = trafxResp.getSearchResourceResponse().getSearchResponseDetailsArray(0).getDeviceArray(0);
			if(physicalDevice.getHasPortsList() != null  && physicalDevice.getHasPortsList().size() > 0){
				PhysicalPort  physicalPort = physicalDevice.getHasPortsArray(0);				
				if(physicalPort != null){
					mergeMandatoryHelpText(physicalPort.getResourceDescribedByList());
				}
			}
			
			if(physicalDevice.getConsistsOfRackList() != null && physicalDevice.getConsistsOfRackList().size() > 0){
				Rack rack = physicalDevice.getConsistsOfRackArray(0);
				if(rack.getConsistsOfShelfList() != null && rack.getConsistsOfShelfList().size() > 0 ){
					Shelf shelf = rack.getConsistsOfShelfArray(0);
					if(shelf.getConsistsOfSlotList() != null  && shelf.getConsistsOfSlotList().size() > 0){
						Card card = shelf.getConsistsOfSlotArray(0).getHasCard();
						if(card.getPhysicalPortList() != null  && card.getPhysicalPortList().size() > 0){
							PhysicalPort physicalPort = card.getPhysicalPortArray(0);
							if(physicalPort != null){
								mergeMandatoryHelpText(physicalPort.getResourceDescribedByList());
							}
						}
					}						
				}
			}
			
			exchange.getIn().setBody(trafxResp);
		}    	
    }
    
    private void mergeMandatoryHelpText(List<ResourceCharacteristicValue> rcvList) throws Exception
	{
		ResourceCharacteristicValue rcvDesc = null;
		ResourceCharacteristicValue rcvMandText = null;
		
    	for(ResourceCharacteristicValue current : rcvList)
		{
			if(current.getCharacteristicName() != null && current.getCharacteristicName().equalsIgnoreCase("PortStatisticsElement"))
			{
				if(current.getResourceCharValueReferencesList() != null && current.getResourceCharValueReferencesList().size() > 0){
					List<ResourceCharacteristicValue> rcvrLst = current.getResourceCharValueReferencesList();
					for(ResourceCharacteristicValue rcvRef : rcvrLst)
					{
						if(rcvRef.getCharacteristicName() != null 
								&& rcvRef.getCharacteristicName().equalsIgnoreCase("PortStatisticsName") 
								&& rcvRef.getCharacteristicValue() !=null){
							
							 Map<String, String> rowData = getMandatoryHelpTextFromDB(rcvRef.getCharacteristicValue());
							 if(rowData != null && rowData.size() > 0 ){								 
								 if(rowData.containsKey("DESCRIPTION") && !StringHelper.isEmpty(rowData.get("DESCRIPTION"))){									 
									 rcvDesc = ResourceCharacteristicValue.Factory.newInstance();
									 rcvDesc.setCharacteristicName("Description");
									 rcvDesc.setCharacteristicValue(rowData.get("DESCRIPTION"));								 
									 rcvrLst.add(rcvDesc);									 
								 }
								
								 if(rowData.containsKey("MANDATORY_HELPTEXT") && !StringHelper.isEmpty(rowData.get("MANDATORY_HELPTEXT"))){									 
									 rcvMandText = ResourceCharacteristicValue.Factory.newInstance();
									 rcvMandText.setCharacteristicName("MandatoryHelpText");
									 rcvMandText.setCharacteristicValue(rowData.get("MANDATORY_HELPTEXT"));								 
									 rcvrLst.add(rcvMandText);									 
								 }
								 rowData = null;
							 }
							 break;
						}
					}
				}
			}
		}
		
	}
    
    private Map<String, String> getMandatoryHelpTextFromDB(String statName)
    {
    	if (xrefTracker == null)
    		throw new ICLException("Xref Service Tracker is not Running");
    	
    	XrefLookupServiceInterface lookupService = (XrefLookupServiceInterface) xrefTracker.getService();
    	
    	Map<String, String> rowData = lookupService.getRow("STAT_DESC_M_TEXT_LOOKUP", "STAT_NAME", statName);
    	    	
    	LOG.info("rowData: " + rowData);
    	
    	return rowData;    	
    }

}
