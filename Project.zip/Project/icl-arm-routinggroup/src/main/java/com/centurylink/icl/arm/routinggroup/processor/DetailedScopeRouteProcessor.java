package com.centurylink.icl.arm.routinggroup.processor;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;

import com.iclnbi.iclnbiV200.ResourceCharacteristicValue;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class DetailedScopeRouteProcessor implements Processor 
{
	final ProducerTemplate producerTemplate;
	
	public DetailedScopeRouteProcessor(CamelContext ctx)
	{
		this.producerTemplate = ctx.createProducerTemplate();	
	}

	@Override
	public void process(Exchange exchg) throws Exception 
	{
		SearchResourceRequestDocument in = (SearchResourceRequestDocument)exchg
				.getIn().getBody();
		
		List<ResourceCharacteristicValue> rcvList = in.getSearchResourceRequest()
				.getSearchResourceDetails().getResourceCharacteristicValueList();
		
		if(rcvList.size() == 0)
			producerTemplate.send("direct:ARMCircuitDetailRoute",exchg);
		else
			producerTemplate.send("direct:ARMCircuitLAG_NMI_BwRoute",exchg);
		
		/*
		for(ResourceCharacteristicValue rcv : rcvList)
		{
			if(rcv.getCharacteristicName().equalsIgnoreCase("DeviceCLLI"))
				producerTemplate.send("direct:ARMCircuitLAG_NMI_BwRoute",exchg);
			
				
		}}
	*/
		}
}
