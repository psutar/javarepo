package com.centurylink.icl.arm.routinggroup.processor;

import org.apache.camel.Processor;
import org.apache.camel.Exchange;


public class BulkCreateDeviceRequestProcessor implements Processor {
@Override
public void process(Exchange exchange) throws Exception {
	// TODO Auto-generated method stub
	

			exchange.setProperty("REQUEST_TYPE", "BULKDEVICE");

}
}
