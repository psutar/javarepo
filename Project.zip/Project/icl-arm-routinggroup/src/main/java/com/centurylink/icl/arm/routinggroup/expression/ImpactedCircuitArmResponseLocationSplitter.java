package com.centurylink.icl.arm.routinggroup.expression;

import java.util.ArrayList;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Expression;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SubNetworkConnection;

public class ImpactedCircuitArmResponseLocationSplitter implements Expression {
	private static final Log LOG = LogFactory
			.getLog(ImpactedCircuitArmResponseLocationSplitter.class);

	@Override
	public <T> T evaluate(Exchange exchange, Class<T> type) {
		SearchResourceResponseDocument searchResourceResponseDocument = (SearchResourceResponseDocument) exchange
				.getIn().getBody();
		exchange.setProperty(ARMRoutingConstants.ARM_RESPONSE,	searchResourceResponseDocument);
		List<String> locationList = null;

		if (searchResourceResponseDocument.getSearchResourceResponse()
				.getSearchResponseDetailsArray(0).getCircuitList().size() > 0) {

			locationList = new ArrayList<String>();

			List<SubNetworkConnection> circuitList = searchResourceResponseDocument
					.getSearchResourceResponse()
					.getSearchResponseDetailsArray(0).getCircuitList();

			for (SubNetworkConnection circuit : circuitList) {
				
				if (circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList() != null
						&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList()
								.size() > 0
						&& circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
					String deviceLocationAEnd =circuit.getSncHasAEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();

					if (deviceLocationAEnd != null) {
						if (!locationList.contains(deviceLocationAEnd)) {
							locationList.add(deviceLocationAEnd);
							}
						}
					}
				if (circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList() != null
						&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList()
								.size() > 0
						&& circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName() != null) {
					String deviceLocationZEnd =circuit.getSncHasZEndTpsList().get(0).getAccessPointAddressList().get(0).getCommonName();

					if (deviceLocationZEnd != null) {
						if (!locationList.contains(deviceLocationZEnd)) {
							locationList.add(deviceLocationZEnd);
							}
						}
					}

			}

			exchange.setProperty("locationList", locationList);
		}

		return (T) locationList;

	}

}
