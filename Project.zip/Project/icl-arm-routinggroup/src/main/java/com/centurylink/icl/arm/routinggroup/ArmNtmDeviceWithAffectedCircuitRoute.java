package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.ImpactedCircuitARMResponseAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.ImpactedCircuitLocationResponseAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.aggregationstrategy.ImpactedCircuitResponseAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.expression.ImpactedCircuitArmResponseLocationSplitter;
import com.centurylink.icl.arm.routinggroup.expression.ImpactedCircuitArmResponseSplitter;

public class ArmNtmDeviceWithAffectedCircuitRoute extends RouteBuilder 
{
	static final String AFFECTED_CIRCUIT_MAIN_ROUTE  = "direct:armNtmDeviceWithAffectedCircuitRoute";
	static final String AFFECTED_CIRCUIT_LOCAL_ROUTE = "direct:ARMAffectedCircuitLocalRoute";
	static final String AFFECTED_CIRCUIT_CLC_ROUTE   = "direct:affectedCircuitclcLocation";
	static final String IMAPCTED_CIRCUIT_AML		 = "GetImpactedCircuitsForDevice";
	
	private static final String AffectedCircuitMainRouteID  = "ARMNtmDeviceWithAffectedCircuit";	

	@Override
	public void configure() throws Exception
	{
		from(AFFECTED_CIRCUIT_MAIN_ROUTE)
		.routeId(AffectedCircuitMainRouteID)
		.to("bean:affectedCircuitRequestProcessor")
		.setHeader(methodName, constant(IMAPCTED_CIRCUIT_AML))
		.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
		.multicast(new ImpactedCircuitARMResponseAggregationStrategy())
		.parallelProcessing()
		.to("direct:impactedCircuitSearchCustomer","direct:impactedCircuitSearchLocation")
	    .end();
		
		from("direct:impactedCircuitSearchCustomer")
		.id("impactedCircuitSearchCustomer")
		.split(new ImpactedCircuitArmResponseSplitter(), new ImpactedCircuitResponseAggregationStrategy())
	    .parallelProcessing()
		.beanRef("impactedCircuitHPCCLCRequestCreator")
    	.beanRef("armServiceInvoker","callCLCSearchCustomerOp")
    	.end();
		
		from("direct:impactedCircuitSearchLocation")
		.id("impactedCircuitSearchLocation")
		.split(new ImpactedCircuitArmResponseLocationSplitter(),new ImpactedCircuitLocationResponseAggregationStrategy())
    	.parallelProcessing()
    	.beanRef("impactedCktCLCLocationRequestProcessor")
    	.beanRef("armServiceInvoker","callCLCSearchLocationOp")
    	.end();
	
	}

}
