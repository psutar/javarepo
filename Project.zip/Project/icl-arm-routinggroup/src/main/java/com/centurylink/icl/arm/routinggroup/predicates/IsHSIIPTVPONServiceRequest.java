package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.centurylink.icl.common.util.StringHelper;
import com.iclnbi.iclnbiV200.SearchResourceDetails;
import com.iclnbi.iclnbiV200.SearchResourceRequestDocument;

public class IsHSIIPTVPONServiceRequest implements Predicate{
	private static final Log LOG = LogFactory.getLog(IsHSIIPTVPONServiceRequest.class);
	private static final String HSI_SERVICE = "7635131111-HSI";
	private static final String PON_SERVICE = "PONCircuit1";
	private static final String IPTV_SERVICE = "7635131111-IPTV";
	@Override
	public boolean matches(Exchange exchange) {
		
		SearchResourceRequestDocument searchResourceRequestDocument = exchange.getIn().getBody(SearchResourceRequestDocument.class);
		SearchResourceDetails searchResourceDetails = searchResourceRequestDocument.getSearchResourceRequest().getSearchResourceDetails();
		String commonName = searchResourceDetails.getCommonName();
		String scope= searchResourceDetails.getScope();
		return !StringHelper.isEmpty(commonName) && 
				scope.equalsIgnoreCase("Detailed") && 
				(HSI_SERVICE.equalsIgnoreCase(commonName) || PON_SERVICE.equalsIgnoreCase(commonName) || IPTV_SERVICE.equalsIgnoreCase(commonName));
		
	}

}
