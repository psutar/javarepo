package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.builder.util.StringHelper;

public class CheckConsumerForPortSync implements Predicate{

	@Override
	public boolean matches(Exchange exchange) {
		String actionTag = exchange.getProperty("actionTag",String.class);
		if(!StringHelper.isEmpty(actionTag) && actionTag.equalsIgnoreCase("PortSync")){
			return true;
		}
		else{
		return false;
		}
	}

}
