package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ARMNtmContactDetailsRoute extends RouteBuilder{

	private static final Log LOG = LogFactory.getLog(ARMNtmContactDetailsRoute.class);
	
	@Override
	public void configure() throws Exception {

		from("direct:NtmARMContactDetailsRoute")
		.routeId("ARMContactDetailsRoute")
			.setHeader(methodName, constant("GetContactDetails"))		
			.to("bean:armContactDetailsRequestValidatorProcessor")
			.choice()	
				.when(property("clcCallRequired").isEqualTo(Boolean.TRUE))
					.to("bean:clcContactDetailsRequestCreator")
					.to("direct:sendToClcContact")
				.otherwise()					
					.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
					.to("direct:sendToClcContact")
			.end();
			
			
		from("direct:sendToClcContact")
		 .beanRef("armServiceInvoker", "callClcContactDetails");
		
	}

	
}
