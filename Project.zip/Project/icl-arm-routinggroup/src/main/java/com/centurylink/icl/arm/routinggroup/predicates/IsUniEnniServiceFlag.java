package com.centurylink.icl.arm.routinggroup.predicates;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

import com.centurylink.icl.arm.routinggroup.ARMRoutingConstants;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;

public class IsUniEnniServiceFlag implements Predicate {

	@Override
	public boolean matches(Exchange exchg) {

		SearchResourceResponseDocument armResp = (SearchResourceResponseDocument) exchg
				.getIn().getBody();
		exchg.setProperty(ARMRoutingConstants.ARM_RESPONSE, armResp);
		String resourceType = null;
		boolean isUniEnniFlag = false;
		Object temp = exchg.getIn().getBody();
		if (temp != null && temp instanceof SearchResourceResponseDocument) {

			if (armResp.getSearchResourceResponse()
					.getSearchResponseDetailsList().size() > 0
					&& armResp.getSearchResourceResponse()
							.getSearchResponseDetailsArray(0)
							.getP2PCircuitList().size() > 0) {

				resourceType = armResp.getSearchResourceResponse()
						.getSearchResponseDetailsArray(0).getP2PCircuitArray(0)
						.getResourceType();
			}

				
				if("MEF UNI".equalsIgnoreCase(resourceType) || "MEF ENNI".equalsIgnoreCase(resourceType)|| "ENNI".equalsIgnoreCase(resourceType) || "UNI".equalsIgnoreCase(resourceType))
					isUniEnniFlag = true;
		}
		return isUniEnniFlag;
	}
}
