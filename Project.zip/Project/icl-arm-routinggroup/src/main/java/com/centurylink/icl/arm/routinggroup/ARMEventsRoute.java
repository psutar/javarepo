package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;

public class ARMEventsRoute extends RouteBuilder {

	public static final String TIMER = "timer://";
	public static final String ARM_READ_EVENT = "ReadARMEvent";

	public static final String GETEVENT = "GetEvent";
	
	private boolean startEventRoute = false;
	private String interval = "60000";
	
	public void setStartEventRoute(boolean startEventRoute)
	{
		this.startEventRoute = startEventRoute;
	}
	
	public void setInterval(String interval)
	{
		this.interval = interval;
	}
	
	@Override
	public void configure() throws Exception {
		//
		//from(TIMER + ARM_READ_EVENT + "?repeatCount=1")
		from(TIMER + ARM_READ_EVENT + "?fixedRate=true&period=" + interval)
			.routeId("ReadARMEvent")
			.autoStartup(startEventRoute)
			.setHeader(methodName, constant(GETEVENT))
			.beanRef("armServiceInvoker", "callConnectorInternalArmMediation")
			.choice()
				.when(body().isNull())
					.log(LoggingLevel.DEBUG, ARMEventsRoute.class.getName(), "No ARM Event Found")
				.otherwise()
					.to("nmr:ARMEventPublisher")
			.end()
		;
		
	}

}
