package com.centurylink.icl.arm.routinggroup.aggregationstrategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.iclnbi.iclnbiV200.Customer;
import com.iclnbi.iclnbiV200.EVCCircuit;
import com.iclnbi.iclnbiV200.Party;
import com.iclnbi.iclnbiV200.PartyRole;
import com.iclnbi.iclnbiV200.SearchResourceResponseDocument;
import com.iclnbi.iclnbiV200.SearchResponseDetails;
import com.iclnbi.iclnbiV200.SubNetworkConnection;
import com.iclnbi.iclnbiV200.UNICircuit;

public class BANAggregationStrategy implements AggregationStrategy{
	private static final Log LOG = LogFactory.getLog(BANAggregationStrategy.class);
	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
		SearchResourceResponseDocument oldResponse = null;//ARM
		SearchResourceResponseDocument newResponse = null;//QCTRL
		
		if(oldExchange == null)
		{
			return newExchange;
		}
		
		if(oldExchange.getException() == null && oldExchange.getIn().getBody() != null){
			oldResponse = (SearchResourceResponseDocument)oldExchange.getIn().getBody();
		}
		if(newExchange.getException() == null && newExchange.getIn().getBody() != null){
			newResponse = (SearchResourceResponseDocument)newExchange.getIn().getBody();
		}
		if(oldResponse!=null && newResponse!=null)
		{
			List<String> matchedUNIList = new ArrayList<String>();
			try
			{
				matchedUNIList = filterARMBANWithQCtrl(newResponse, oldResponse);
				oldExchange.getIn().setBody(aggregateARMResponse(oldResponse,matchedUNIList));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (oldResponse != null && newExchange.getException() != null) {
			 oldExchange.setProperty(Exchange.EXCEPTION_CAUGHT,null);
			 oldExchange.setException(null);
			 oldExchange.getIn().setBody(oldResponse);
	    }
		
		return oldExchange;
	}
	
	private List<String> getBANList(SearchResourceResponseDocument qctrlResponse) throws Exception {
		List<String> BANList = new ArrayList<String>();
		
		SearchResponseDetails searchResponseDetails = qctrlResponse.getSearchResourceResponse().getSearchResponseDetailsArray(0);
		if (searchResponseDetails != null && searchResponseDetails.getPartyList().size() > 0) {
			List<Party> partyList = (List<Party>) searchResponseDetails.getPartyList();
			for (Party party: partyList)
			{
				for (PartyRole partyRole: party.getHasPartyRolesList())
				{
					Customer customer = Customer.Factory.parse(partyRole.toString()); 
					if(customer.getCustomerPossesesList()!= null  && customer.getCustomerPossesesList().size() > 0){
						BANList.add(customer.getCustomerPossesesArray(0).getID());
					}					
				}
			}
		} else {
			BANList = null;
		}
		return BANList;		
	}
	
	private List<String> filterARMBANWithQCtrl(SearchResourceResponseDocument qctrlResponse,SearchResourceResponseDocument armResponse) throws Exception
	{
		List<String> qctrlBANList = getBANList(qctrlResponse);
		List<String> matchedUNIList = new ArrayList<String>();
		Map<String,String> armBANMap = new HashMap<String,String>();
		SearchResponseDetails armResponseDetails = armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0);
		SubNetworkConnection circuit = armResponseDetails.getCircuitList().get(0);
		if(circuit!=null)
		{
		   EVCCircuit evcCircuit = (EVCCircuit)circuit;
		   List<UNICircuit> uniCircuitList = evcCircuit.getComprisedOfUNICircuitList();
		   if(uniCircuitList!=null && uniCircuitList.size()>0)
		   {
			   for(UNICircuit uniCircuit:uniCircuitList)
			   {
				   String circuitID = uniCircuit.getCommonName();
				   if(uniCircuit.getOwnsResourceDetails().getCustomerList().get(0).getCustomerPossesesList()!=null
						   && uniCircuit.getOwnsResourceDetails().getCustomerList().get(0).getCustomerPossesesList().size()>0){
					String BAN = uniCircuit.getOwnsResourceDetails().getCustomerList().get(0).getCustomerPossesesList().get(0).getID();
					armBANMap.put(circuitID, BAN);
					if(qctrlBANList!=null && qctrlBANList.size()>0 && qctrlBANList.contains(BAN)){
						matchedUNIList.add(circuitID);
					 }
				  }
			   }
		   }
		}
		else
		{
			return null;
		}
		return matchedUNIList;
	}
	
	private SearchResourceResponseDocument aggregateARMResponse(SearchResourceResponseDocument oldResponse,List<String> matchedUNIList) throws Exception{
		SearchResourceResponseDocument newARMResponse = SearchResourceResponseDocument.Factory.parse(oldResponse.toString());
		SearchResourceResponseDocument armResponse = getARMResponse(oldResponse);
		((EVCCircuit)armResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0)
				   .getCircuitList().get(0)).getComprisedOfUNICircuitList().addAll(getUNICircuits(newARMResponse,matchedUNIList));
		return armResponse;
	}
	
	private SearchResourceResponseDocument getARMResponse(SearchResourceResponseDocument oldResponse){
		 ((EVCCircuit)oldResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0)
				   .getCircuitList().get(0)).getComprisedOfUNICircuitList().clear();
		 return oldResponse;
	}
	
	private List<UNICircuit> getUNICircuits(SearchResourceResponseDocument oldResponse,List<String> matchedUNIList) throws Exception{
		List<UNICircuit> uniCircuitList = new ArrayList<UNICircuit>();
		SubNetworkConnection circuit = oldResponse.getSearchResourceResponse().getSearchResponseDetailsList().get(0).getCircuitList().get(0);
		if(circuit!=null)
		{
			EVCCircuit evcCircuit = EVCCircuit.Factory.parse(circuit.toString());
		   if(evcCircuit.getComprisedOfUNICircuitList()!=null && evcCircuit.getComprisedOfUNICircuitList().size()>0)
		   {
			   for(UNICircuit uniCircuit:evcCircuit.getComprisedOfUNICircuitList())
			   {
				   
				   if(matchedUNIList!=null && matchedUNIList.size()>0 && matchedUNIList.contains(uniCircuit.getCommonName()))
				   {
					   uniCircuitList.add(uniCircuit);
				   }
			   }
		   }
		}
		return uniCircuitList;
		
	}

}
