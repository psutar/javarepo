package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

public class GetNMIAndBandwidthByDeviceRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		
		from("direct:GetNMIAndBandwidthByDeviceRoute")
		 .routeId("GetNMIAndBandwidthByDeviceRoute")
		 .to("bean:nmiRequestValidatorProcessor")
		 .setHeader(methodName, constant("GetNMIBandwidth"))
		 .beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		 .removeHeader("GetNMIBandwidth")
		 .end();
	}

}
