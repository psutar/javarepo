package com.centurylink.icl.arm.routinggroup;


import org.osgi.framework.BundleContext;
import org.osgi.framework.Filter;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.util.tracker.ServiceTracker;
import com.centurylink.icl.component.IConnector;





/**
 * Bundle Activator Utility class to invoke Arm Mediation Layer through service lookup.
 * 
 * @author aa56848
 * 
 */
public class ARMMLServiceInvoker {
 
 
  private ServiceTracker        armMLServiceTracker;
 
  
  public ARMMLServiceInvoker(BundleContext bundleContext) throws InvalidSyntaxException {
	      
    
	  Filter filterConnector = bundleContext.createFilter("(&(name=amlService))");
	  armMLServiceTracker = new ServiceTracker(bundleContext, filterConnector, null); 
	 
	  armMLServiceTracker.open();
  }
   
  public void close() {
    
    armMLServiceTracker.close();
   
  }

  


  
 
  public Object invokeAmlService(Object in) throws Exception {
    
	  IConnector amlmdwService=null;
	 
	  if (null != in){
        
       	 amlmdwService = (IConnector) armMLServiceTracker.getService();
    
    }
     if (null != amlmdwService) {
    	 
      return amlmdwService.call(in, null);
    } else {
      throw new Exception("Arm ML Service Not Available");
    }
  }
}
