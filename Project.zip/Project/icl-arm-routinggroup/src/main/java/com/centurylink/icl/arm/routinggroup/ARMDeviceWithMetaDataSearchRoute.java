package com.centurylink.icl.arm.routinggroup;

import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.armServiceInvoker;
import static com.centurylink.icl.arm.routinggroup.ARMRoutingConstants.methodName;

import org.apache.camel.builder.RouteBuilder;

import com.centurylink.icl.arm.routinggroup.aggregationstrategy.DeviceWithMetadataAggregationStrategy;
import com.centurylink.icl.arm.routinggroup.expression.LocationSplitterForDeviceMetadata;

public class ARMDeviceWithMetaDataSearchRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		
		from("direct:ARMDeviceWithMetaDataSearchRoute")
		.routeId("ARMDeviceWithMetaDataSearchRoute")
		.to("bean:searchDeviceRequestValidatorProcessor")
		.setHeader(methodName, constant("GetDevice"))
		.beanRef(armServiceInvoker, "callConnectorInternalArmMediation")
		.beanRef("deviceWithMetadatResponseProcessor")
		.choice()	
		.when(property("isCLCCallRequired").isEqualTo(Boolean.TRUE))
			.split(new LocationSplitterForDeviceMetadata(),new DeviceWithMetadataAggregationStrategy())
			.parallelProcessing()
			.beanRef("armDeviceCLCLocationRequestCreater")
			.beanRef("armServiceInvoker","callCLCSearchLocationOp")
			.end()
		.removeHeader("GetDevice")
	.end();
		
	}
}

