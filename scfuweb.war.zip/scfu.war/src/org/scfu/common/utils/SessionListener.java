package org.scfu.common.utils;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.dao.UserDAO;
import org.scfu.common.dao.UserDAOImpl;
import org.scfu.common.model.User;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class SessionListener implements HttpSessionListener
{
    protected final Logger logger = Logger.getLogger(getClass());    
    private UserDAO userDAOImpl;
   
	public void sessionCreated(HttpSessionEvent event) {
		logger.info("sessionCreated " + SCFUConstants.METHOD_BEGINS);
		
		if (event.getSession() != null) {
			logger.info("Session created : " + event.getSession().getId());
		} else {
			logger.info("Session not created : " + event.getSession());
		}
		logger.info("sessionCreated " + SCFUConstants.METHOD_ENDS);
	}
 
	public void sessionDestroyed(HttpSessionEvent event) {
    	logger.info("sessionDestroyed " + SCFUConstants.METHOD_BEGINS);
		try {
			HttpSession session = event.getSession();
			if (session != null) {
				logger.info("Session destroyed : " + event.getSession().getId());
				WebApplicationContext webAppCtxt = WebApplicationContextUtils.getWebApplicationContext(event.getSession().getServletContext());
				userDAOImpl = (UserDAO) webAppCtxt.getBean("userDAOImpl");
				User user = (User) session.getAttribute(SCFUConstants.USER);
				if (user != null) {
					String userName = user.getUserName();
					userDAOImpl.deleteActiveUserLogin(userName);
				}
			}
		} catch (Exception e) {
			logger.error("Exception Occured in Session Listener", e);
			e.printStackTrace();
		}
    	logger.info("sessionDestroyed " + SCFUConstants.METHOD_ENDS);
	}

	public void setUserDAOImpl(UserDAOImpl userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

} 