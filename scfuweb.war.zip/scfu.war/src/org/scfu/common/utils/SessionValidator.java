package org.scfu.common.utils;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.model.LinkDetails;
import org.scfu.common.model.User;

public class SessionValidator{
     protected final Logger logger = Logger.getLogger(getClass());

     public static boolean isValidSession(HttpServletRequest request,HttpServletResponse response,String type){
    	 System.out.println("SessionValidator : Starta");
    	 HttpSession session=request.getSession(false);
    	 if (session == null) {
    		 request.setAttribute(SCFUConstants.SESSION_ERROR,SCFUConstants.SESSION_ERROR_MESSAGE);
    		 forwordURL("sessiontimeout.htm",request, response);
    		 return false;
    	 }else {
    		 User user = (User) session.getAttribute(SCFUConstants.USER);
    		 if (user == null) {
    			 request.setAttribute(SCFUConstants.SESSION_ERROR,SCFUConstants.SESSION_ERROR_MESSAGE);
    			 forwordURL("login.htm",request, response);
    			 return false;
    		 }else{    	       
    			 System.out.println("SessionValidator : ends");
    			 return true;
    		 }          
    	 }
     }
    
     
     public static boolean isValidReferer(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
    	 String refervalue = request.getHeader("referer");
    	 boolean flag = true;
    	 if (refervalue == null) {
    		 if (session != null)
    			 session.invalidate();
    		 flag = false;
    		 forwordURL("errorpage.htm",request,response);
    	 }
    	 return flag;
     }
    
     
	private static void forwordURL(String url, HttpServletRequest request, HttpServletResponse response) {
		System.out.println("SessionValidator : forwordURL Start");
		try {
			request.getRequestDispatcher("/" + url).forward(request, response);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		System.out.println("SessionValidator : forwordURL Ends");
	}
    
	public static void dynamiclinks(HttpServletRequest request, HttpSession session) {
		System.out.println("dynamiclinks : SessionValidator :  starts");
		String url = request.getServletPath().substring(1);
		System.out.println("url " + url);
		ServletContext ctx = session.getServletContext();
		session.setAttribute("refreshFlag", Boolean.FALSE);
		String userRole = (String) session.getAttribute("userLoginRole");
		Map Links = (Map) ctx.getAttribute("links_" + userRole);
		LinkDetails linkDetails = (LinkDetails) Links.get(url);
		System.out.println("linkDetails " + linkDetails);

		if (linkDetails.getBaseURL() != null && linkDetails.getBaseURL().trim().length() > 0) {
			url = linkDetails.getBaseURL();
		}

		if (linkDetails.getErrorCode() != null) {
			request.setAttribute("newErrorCode", linkDetails.getErrorCode());
		}
		
		System.out.println("url 22" + url);
		session.setAttribute("baseURL", url);
		session.setAttribute("bodyTab", linkDetails.getBodyTab());
		System.out.println("dynamiclinks : SessionValidator :  starts");
	}    
   
}