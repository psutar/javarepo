package org.scfu.common.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtils { 
	
public static int daysBetween(Date d1, Date d2){
	return (int)( (d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
}  

 public static Date convertStringToDate(String strDate)
 {
		Date date = null;
		try {

			DateFormat formatter1;
			DateFormat formatter2;
			formatter1 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			formatter2 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

			// date = (Date)formatter1.parse( strDate);
			date = (Date) formatter1.parse(strDate);

		} catch (ParseException e) {
			System.out.println("Exception :" + e);
		}

		return date;
	}
 
 
 public static Date removeTime(Date date) {
	    if(date == null) {
	      throw new IllegalArgumentException("The argument 'date' cannot be null.");
	    }
	    // Get an instance of the Calendar.
	    Calendar calendar = Calendar.getInstance();
	    // Make sure the calendar will not perform automatic correction.
	    calendar.setLenient(false);
	    // Set the time of the calendar to the given date.
	    calendar.setTime(date);
	    // Remove the hours, minutes, seconds and milliseconds.
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);

	    // Return the date again.
	    return calendar.getTime();
	  }

}
