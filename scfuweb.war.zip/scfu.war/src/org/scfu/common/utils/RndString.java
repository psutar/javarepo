package org.scfu.common.utils;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.common.cache.UserSessionCache;
import org.scfu.common.constants.SCFUConstants;

import uk.ltd.getahead.dwr.ExecutionContext;


public class RndString {
	protected final Logger logger = Logger.getLogger(getClass());
	private char[] allchars = {'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m','Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','1','2','3','4','5','6','7','8','9','0'};
	 static int ssize =8; 
	    static char[] numCapsAlpChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',  'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	    static char[] numChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	private UserSessionCache userSessionCache;
	
	public String getRandomString(String mode) throws ServletException, IOException{
		logger.info("getRandomString"+SCFUConstants.METHOD_BEGINS);		
		HttpServletRequest httpRequest = ExecutionContext.get().getHttpServletRequest();
		HttpSession session;
		String randString="";
		if (mode!=null && mode.equalsIgnoreCase("loginPwd")) {
			session=httpRequest.getSession(true);
			randString = getRamdom(session.getId());
		}else {
			session=httpRequest.getSession(false);
			randString = getRamdom();
			session.setAttribute("keyid",randString);	
			logger.info("key Id  "+randString);
		}		
		
		logger.info("getRandomString"+SCFUConstants.METHOD_ENDS);
		return randString;
	}

	public String getRamdom() {
		Random rand = new Random();
		String randString = "";
		for(int i=0;i<8;i++){
			randString += allchars[rand.nextInt(62)];
		}		
		return randString;
	}
	
	public String getRamdom(String sessionId) {
		String randString = "";
		randString=getRamdom();
		userSessionCache.setData(sessionId, randString);
		return randString;
	}
	
	//changed for CR 5034 - begin
	public String getKey(String sessionId, boolean removeFlag){
		String keyId = null;
		logger.info("session:::"+sessionId);
		try {
			keyId = (String) userSessionCache.getData(sessionId);
			logger.info("keyId:::"+keyId);
			if (removeFlag==true) {
				userSessionCache.removeData(sessionId);
			}
		} catch (Exception e) {
			logger.error("Exception occured while getting key Id.",e);
		}
		return keyId;
	}
	 public static String getRandomString(){
	      Random ran = new java.util.Random();
	      String randomString = "";
	        for (int j = 0; j < ssize; j++){
	          int r = ran.nextInt(numCapsAlpChars.length);
	          randomString += numCapsAlpChars[r];
	        }
	        return randomString;
	     
	    }
	    public static String getRandomId(){
		      Random ran = new java.util.Random();
		      String randomString = "";
		        for (int j = 0; j < ssize; j++){
		          int r = ran.nextInt(numChars.length);
		          randomString += numChars[r];
		        }
		        return randomString;
		     
		    }
	public void setUserSessionCache(UserSessionCache userSessionCache) {
		this.userSessionCache = userSessionCache;
	}
}


