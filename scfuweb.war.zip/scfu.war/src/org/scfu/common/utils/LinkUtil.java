package org.scfu.common.utils;

import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.dao.LinkDAO;


public class LinkUtil{
    private LinkDAO linkDAOImpl;
    protected final Logger logger = Logger.getLogger(getClass());
    public Map getTabLinkDetails(String userRole,String moduleName){
        logger.info("getTabLinkDetails"+SCFUConstants.METHOD_BEGINS);
        Map  linkDetails = linkDAOImpl.getLinkDetails(userRole,moduleName);
        logger.info("getTabLinkDetails"+SCFUConstants.METHOD_ENDS);
        return linkDetails;
    }
	public void setLinkDAOImpl(LinkDAO linkDAOImpl) {
		this.linkDAOImpl = linkDAOImpl;
	}
   
}