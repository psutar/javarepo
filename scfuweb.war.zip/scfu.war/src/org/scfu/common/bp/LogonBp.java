package org.scfu.common.bp;

import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.dao.LoginDAO;
import org.scfu.common.constants.SCFUConstants;

public class LogonBp {
	protected final Logger logger = Logger.getLogger(getClass());
	private LoginDAO loginDAO;

	public Map validateLogin(String keyString, String userName,String password, String sha2Password, String userIPaddress) {
		logger.info("validateLogin" + SCFUConstants.METHOD_BEGINS);
		Map resultMap = loginDAO.checkLogin(keyString, userName, password,sha2Password,userIPaddress);
		logger.info("validateLogin" + SCFUConstants.METHOD_ENDS);
		return resultMap;
	}
	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}

}