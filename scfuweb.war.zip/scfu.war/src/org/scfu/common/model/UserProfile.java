package org.scfu.common.model;

public class UserProfile extends User{
	
	private String userName;
	
	private String nickName;
	
	private String address;
	
	private String emailId;
	
	private String phoneNo;
	
	private String mobileNo;
	
	private String dateOfBirth;
	
	private String mobileCountryCode;
	
	private String imCode;
	
	
	@Override
	public String toString() {
		 StringBuffer tempStringBuf = new StringBuffer();
	        tempStringBuf.append(imCode);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(userName);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(nickName);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(address);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(emailId);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(phoneNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(mobileNo);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(dateOfBirth);
	        tempStringBuf.append(" | ");
	        tempStringBuf.append(mobileCountryCode);
	        tempStringBuf.append(" | ");
	        return tempStringBuf.toString();
	}

	public String getImCode() {
		return imCode;
	}

	public void setImCode(String imCode) {
		this.imCode = imCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileCountryCode() {
		return mobileCountryCode;
	}

	public void setMobileCountryCode(String mobileCountryCode) {
		this.mobileCountryCode = mobileCountryCode;
	}
	
	

}
