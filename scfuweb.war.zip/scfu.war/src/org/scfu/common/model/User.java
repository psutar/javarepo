package org.scfu.common.model;


public class User implements BaseModel{
	
	private String roles;
	
	private String userName;
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }
	
  @Override
	public String toString() {
	 
		return super.toString();
	}
}
