package org.scfu.common.model;

public class LinkDetails implements BaseModel {
	private String linkID;

	private String linkName;

	private String linkURL;

	private Integer linkOrder;

	private String tabName;

	private Integer tabID;

	private String baseURL;

	private String errorCode;

	private String bodyHeader;

	private String bodyTab;
	
	private String bodyTabName;
	
	private String leftNav;

	public String getLinkID() {
		return linkID;
	}

	public void setLinkID(String linkID) {
		this.linkID = linkID;
	}

	public String getLinkName() {
		return linkName;
	}

	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}

	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	public String toString()

	{
		StringBuffer tempStringBuf = new StringBuffer();

		tempStringBuf.append(linkID);
		tempStringBuf.append("|");
		tempStringBuf.append(linkName);
		tempStringBuf.append("|");
		tempStringBuf.append(linkOrder);
		tempStringBuf.append("|");
		tempStringBuf.append(linkURL);
		tempStringBuf.append("|");
		tempStringBuf.append(tabName);
		tempStringBuf.append("|");
		tempStringBuf.append(tabID);
		tempStringBuf.append("|");

		return tempStringBuf.toString();

	}

	public String getLinkURL() {
		return linkURL;
	}

	public void setLinkURL(String linkURL) {
		this.linkURL = linkURL;
	}

	public Integer getLinkOrder() {
		return linkOrder;
	}

	public void setLinkOrder(Integer linkOrder) {
		this.linkOrder = linkOrder;
	}

	public Integer getTabID() {
		return tabID;
	}

	public void setTabID(Integer tabID) {
		this.tabID = tabID;
	}

	public String getBaseURL() {
		return baseURL;
	}

	public void setBaseURL(String baseURL) {
		this.baseURL = baseURL;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getBodyHeader() {
		return bodyHeader;
	}

	public void setBodyHeader(String bodyHeader) {
		this.bodyHeader = bodyHeader;
	}

	public String getBodyTab() {
		return bodyTab;
	}

	public void setBodyTab(String bodyTab) {
		this.bodyTab = bodyTab;
	}

	/**
	 * @return Returns the bodyTabName.
	 */
	public String getBodyTabName() {
		return bodyTabName;
	}

	/**
	 * @param bodyTabName The bodyTabName to set.
	 */
	public void setBodyTabName(String bodyTabName) {
		this.bodyTabName = bodyTabName;
	}

	/**
	 * @return Returns the leftNav.
	 */
	public String getLeftNav() {
		return leftNav;
	}

	/**
	 * @param leftNav The leftNav to set.
	 */
	public void setLeftNav(String leftNav) {
		this.leftNav = leftNav;
	}

	

}