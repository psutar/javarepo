package org.scfu.common.model;

import java.io.Serializable;

public interface BaseModel extends Serializable
{
	
}