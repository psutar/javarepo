package org.scfu.common.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

@SuppressWarnings({"rawtypes","unchecked"})

public class XSSErrorHandler implements Controller

{   private ResourceBundleMessageSource xssErrorProperties;

    protected final Logger logger = Logger.getLogger(getClass());
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	logger.info("XSSErrorHandler " +SCFUConstants.METHOD_BEGINS);
		Map outparam = new HashMap();
        SCFUApplicationResponse applicationResponse = new SCFUApplicationResponse();
        applicationResponse.setErrorCode("XSS001");
        applicationResponse.setErrorMessage("XSS Script Injection attempted by user");
        applicationResponse.setErrorStatus(SCFUConstants.FAILURE);
        outparam.put(SCFUConstants.APPLICATION_RESPONSE,applicationResponse);
        logger.info("Refresh url : " + request.getAttribute(SCFUConstants.REFRESH_URL));
        String error_view = xssErrorProperties.getMessage((String) request.getAttribute(SCFUConstants.REFRESH_URL),null,null);
        logger.info("error_view= "+error_view);
        outparam.put(SCFUConstants.ERROR_VIEW,error_view);
        logger.info("XSSErrorHandler "+SCFUConstants.METHOD_ENDS);
        return new ModelAndView(error_view,"outputParams",outparam);
    }
    
	public void setXssErrorProperties(ResourceBundleMessageSource xssErrorProperties) {
		this.xssErrorProperties = xssErrorProperties;
	}
    
    
}
