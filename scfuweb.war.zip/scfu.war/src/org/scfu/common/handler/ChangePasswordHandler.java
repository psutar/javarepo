package org.scfu.common.handler;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.model.User;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class ChangePasswordHandler extends MultiActionController {
	   protected final Logger logger = Logger.getLogger(getClass());
	   private BaseService changePasswordService;
	    

	public ModelAndView changePasswordDisplay(HttpServletRequest request,HttpServletResponse response) throws Exception {
		logger.info("changePasswordDisplay :  " + SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		Map<String, String> outParams = new HashMap<String, String>();
		User user = (User) session.getAttribute(SCFUConstants.USER);
		String userName = user.getUserName();
		logger.info("userName :" + userName);
		outParams.put(SCFUConstants.USER_NAME, userName);
		logger.info("changePasswordDisplay : " + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("changePasswordDisplay",SCFUConstants.OUTPUT_PARAMS, outParams);
	}
	 
	public ModelAndView changePasswordSubmit(HttpServletRequest request,HttpServletResponse response) throws Exception {
		logger.info("changePasswordSubmit" + SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		User user = (User) session.getAttribute(SCFUConstants.USER);
		String userName = user.getUserName();
		logger.info("userName: " + userName);
		session.setAttribute("userName", userName);
		String newSHAPassword = (String) request.getParameter("sha2password");
		String oldSHAPassword = (String) request.getParameter("sha2oldpassword");
		Map<String, String> inputParams = new HashMap<String, String>();
		inputParams.put(SCFUConstants.USER_NAME, userName);
		inputParams.put(SCFUConstants.SHA2PASSWORD, newSHAPassword);
		inputParams.put(SCFUConstants.SHA2OLDPASSWORD, oldSHAPassword);
		Map outParams = new HashMap();
		if (userName != null && userName.trim() != SCFUConstants.EMPTY
				&& oldSHAPassword != null && oldSHAPassword.trim() != ""
				&& newSHAPassword != null && newSHAPassword.trim() != "") {
			outParams = (Map) changePasswordService.execute(inputParams);
			logger.info("outParams inside firstLogInSubmit" + outParams);
		}
		SCFUApplicationResponse applicationresponse = (SCFUApplicationResponse) outParams
				.get(SCFUConstants.APPLICATION_RESPONSE);
		if (applicationresponse != null
				&& (applicationresponse.getErrorStatus())
						.equalsIgnoreCase("success")) {
			return new ModelAndView("changePasswordSuccess",SCFUConstants.OUTPUT_PARAMS, outParams);
		} else {

			outParams.put(SCFUConstants.USER_NAME, userName);
			logger.info("changePasswordSubmit" + SCFUConstants.METHOD_ENDS);
			outParams.put("errorView", "changePasswordDisplay");
			return new ModelAndView("changePasswordDisplay",SCFUConstants.OUTPUT_PARAMS, outParams);
		}
	}
	public void setChangePasswordService(BaseService changePasswordService) {
		this.changePasswordService = changePasswordService;
	}
		
}