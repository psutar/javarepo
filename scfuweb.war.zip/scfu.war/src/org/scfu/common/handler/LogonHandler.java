package org.scfu.common.handler;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.model.User;
import org.scfu.common.model.UserProfile;
import org.scfu.common.service.BaseService;
import org.scfu.common.utils.LinkUtil;
import org.scfu.common.utils.RndString;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class LogonHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());
	private RndString rndString;
	private BaseService logonService;
	private String userRoles;
	private String moduleName;
	private LinkUtil linkUtil;
	private String homePageUrl;
	private BaseService firstLogonService;
	private String firstTimeLogInURL;
	private String searchQuery;//searchQuery is here
   


	private String contextRoot;


	/**
	 * Handler for displaying the Login page
	 */
	public ModelAndView logInDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("logInDisplay :" + SCFUConstants.METHOD_BEGINS);
		Map<String, String> loginData = new HashMap<String, String>();
		String keyString = rndString.getRamdom();
		logger.info("Random String :" + keyString);
		loginData.put("keyString", keyString);
		logger.info("logInDisplay :" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("loginDisplay", SCFUConstants.OUTPUT_PARAMS, loginData);
	}

	public ModelAndView sessionTimeOut(HttpServletRequest request,HttpServletResponse response) throws Exception {
		logger.info("sessionTimeOut :" + SCFUConstants.METHOD_BEGINS);
		logger.debug("Session time out");
		logger.info("sessionTimeOut :" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("sessionTimeOut");
	}

	public ModelAndView goToHome(HttpServletRequest request,HttpServletResponse response) throws Exception {
		logger.info("goToHome :" + SCFUConstants.METHOD_BEGINS);
		String reDirectUrl = homePageUrl;
		logger.info("reDirectUrl for regular login :" + reDirectUrl);
		getServletContext().getRequestDispatcher(reDirectUrl).forward(request, response);
		logger.info("goToHome :" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("loginDisplay");
	}
	/**
	 * @param request: Recieves the req from login page
	 * @return model view
	 * @throws Exception
	 * This method checks the user credentials after user submits the login page
	 */
	public ModelAndView logInSubmit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("logInSubmit " + SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession();
		String sessionId = session.getId();
		String userName = (String) request.getParameter("userName");
		String password = (String) request.getParameter("password");
		String sha2Password = (String) request.getParameter("sha2password");
		String keyString = (String) request.getParameter("keyString");
		MDC.put("username", userName);
		String userIPaddress = null;
	   userIPaddress = request.getHeader("X-FORWARDED-FOR");  
	    if (userIPaddress == null) {  
	    	userIPaddress = request.getRemoteAddr();  
	    }
	    logger.info("Client IP from header : " + userIPaddress);
		ServletContext servletContext = getServletContext();
		String ctxAttribute = (String) servletContext.getAttribute("tabs_links_loaded");
		String userRolesList[] = userRoles.split("\\|");
		logger.info("userName " + userName + "password " + password
				+ " sha2Password:" + sha2Password + " keyString:" + keyString);
		session.setAttribute("userName", userName);
		
		contextRoot = request.getContextPath();
		String[] moduleArray=contextRoot.split("\\/");
		String tempName=moduleArray[1];
		
		String serverName= (String)getServletContext().getAttribute("com.ibm.websphere.servlet.application.host");
	        
		Map<String,Object> inputParams = new HashMap<String,Object>();
		inputParams.put(SCFUConstants.USER_NAME, userName);
		inputParams.put(SCFUConstants.PASSWORD, password);
		inputParams.put(SCFUConstants.SHA2PASSWORD, sha2Password);
		inputParams.put("keyString", keyString);
 	    inputParams.put("serverName",serverName);
	    inputParams.put("sessionId",sessionId);
	    inputParams.put("userIPaddress", userIPaddress);
	    inputParams.put("moduleName", tempName);
	       Map<String, Object> outParams = new HashMap<String, Object>();
		if (servletContext.getAttribute("tabs_links_loaded") == null) {
			for (int i = 0; i < userRolesList.length; i++) {
				logger.info("userRolesList[i]" + userRolesList[i]);
				Map links = linkUtil.getTabLinkDetails(userRolesList[i],moduleName);
				Map tabs = (Map) links.get("tabs");
				links.remove("tabs");
				servletContext.setAttribute("links_" + userRolesList[i], links);
				servletContext.setAttribute("tabs_" + userRolesList[i], tabs);
			}
			servletContext.setAttribute("tabs_links_loaded", "Loaded");
		}
		if (userName != null && userName.trim() != "" && password != null && password.trim() != "") {
			outParams = (Map) logonService.execute(inputParams);
			SCFUApplicationResponse applicationresponse = (SCFUApplicationResponse) outParams.get(SCFUConstants.APPLICATION_RESPONSE);
			logger.info("applicationresponse :" + applicationresponse);
			logger.info("outParams :" + outParams);
			if (applicationresponse != null && (applicationresponse.getErrorStatus()).equalsIgnoreCase("success")) {
				User user = (User) outParams.get(SCFUConstants.USER);
				UserProfile profile = (UserProfile) outParams.get(SCFUConstants.PROFILE);
				String userLoginRole = (String) user.getRoles();
				int loginCount = (Integer) outParams.get("loginCount");
				int faliureLoginCount = (Integer) outParams.get("faliureLoginCount");
				logger.info("userLoginRole,loginCount,faliureLoginCount :" + userLoginRole + ","+ loginCount+","+faliureLoginCount);
				logger.info("userLoginRole :" + userLoginRole);
				
				Timestamp lastLoginDate=(Timestamp)outParams.get("lastLoginDate");
				Timestamp lastLoginFailDate=(Timestamp)outParams.get("lastLoginFailDate");
				
				logger.info("lastLoginDate :" + lastLoginDate);
				
				session.setAttribute("lastLoginDate", lastLoginDate);
				session.setAttribute("lastLoginFailDate", lastLoginFailDate);
			    session.setAttribute("userLoginRole", userLoginRole);
				session.setAttribute("loginCount", loginCount);
				session.setAttribute(SCFUConstants.USER, user);
				session.setAttribute(SCFUConstants.PROFILE, profile);
				String imCode = (String) profile.getImCode();
				logger.info("ImCode  :" + imCode);
				session.setAttribute("imCode", imCode);
				if (loginCount == 0 && faliureLoginCount <= 3) {
					String reDirectUrl = firstTimeLogInURL;
					logger.info("reDirectUrl for 1st time login :"+ reDirectUrl);
					request.setAttribute("userName", userName);
					getServletContext().getRequestDispatcher(reDirectUrl).forward(request, response);
					return null;
				}
				
				else if("50".equals(userLoginRole)){
					String reDirectUrl = searchQuery;//searchQuery method begins
					logger.info("reDirectUrl for 1st time login :"+ reDirectUrl);
					request.setAttribute("userName", userName);
					getServletContext().getRequestDispatcher(reDirectUrl).forward(request, response);
					return null;
				}
				else {
					String reDirectUrl = homePageUrl;
					logger.info("reDirectUrl for regular login :" + reDirectUrl);
					getServletContext().getRequestDispatcher(reDirectUrl).forward(request, response);
					return null;
				}
			}
		}
		MDC.remove("username");
		keyString = rndString.getRamdom();
		logger.info("keyString~~~~~~~" + keyString);
		outParams.put("keyString", keyString);
		logger.info("logInSubmit" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("loginDisplay", "outParam", outParams);

	} 

	public ModelAndView firstLogInSubmit(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("firstLogInSubmit" + SCFUConstants.METHOD_BEGINS);

		HttpSession session = request.getSession(false);
		String userName = (String) request.getParameter("userName");
		String desired_username = (String) request.getParameter("desired_username");
		String password = (String) request.getParameter("password");
		String sha2Password = (String) request.getParameter("sha2password");
		boolean firstLoginStatus = false;
		Map<String,Object> inputParams = new HashMap<String,Object>();
		inputParams.put(SCFUConstants.USER_NAME, userName);
		inputParams.put("desired_username", desired_username);
		inputParams.put(SCFUConstants.PASSWORD, password);
		inputParams.put(SCFUConstants.SHA2PASSWORD, sha2Password);
		Map<String,Object> outParams = new HashMap<String,Object>();
		//SCFUApplicationResponse applicationresponse = (SCFUApplicationResponse) outParams.get(SCFUConstants.APPLICATION_RESPONSE);
		logger.info("inputParams inside firstLogInSubmit" + inputParams);
		if (userName != null && userName.trim() != SCFUConstants.EMPTY && password != null && password.trim() != SCFUConstants.EMPTY) {
			outParams = (Map) firstLogonService.execute(inputParams);
			logger.info("outParams inside firstLogInSubmit" + outParams);
			firstLoginStatus = (Boolean) outParams.get("firstLoginStatus");
			logger.info("firstLoginStatus inside firstLogInSubmit : "+ firstLoginStatus);
		}
		outParams.put("userName", userName);
		if (session != null)
			  session.invalidate();
		logger.info("session invalidate :" + session);
		logger.info("firstLogInSubmit" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("firstLogInSuccess");
	}

	public ModelAndView logOutHandler(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("logOutHandler" + SCFUConstants.METHOD_BEGINS);
		String outparams = null;
		HttpSession session = request.getSession(false);
		if (session != null)
		  session.invalidate();
		logger.info("session invalidate :" + session);
		String view = "logout";
		logger.info("logOutHandler" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView(view, "outparams", outparams);

	}
	
	
	  public ModelAndView navigateFail(HttpServletRequest req, HttpServletResponse res) throws Exception
	    {
	        return new ModelAndView("logout");
	    }
	  

	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public void setlogonService(BaseService logonService) {
		this.logonService = logonService;
	}

	public void setRndString(RndString rndString) {
		this.rndString = rndString;
	}

	public void setLinkUtil(LinkUtil linkUtil) {
		this.linkUtil = linkUtil;
	}

	public void setHomePageUrl(String homePageUrl) {
		this.homePageUrl = homePageUrl;
	}

	public void setFirstLogonService(BaseService firstLogonService) {
		this.firstLogonService = firstLogonService;
	}

	public void setFirstTimeLogInURL(String firstTimeLogInURL) {
		this.firstTimeLogInURL = firstTimeLogInURL;
	}


	public void setContextRoot(String contextRoot) {
		this.contextRoot = contextRoot;
	}

	public void setSearchQuery(String searchQuery) {
		this.searchQuery = searchQuery;//searchQuery is here
	}
}