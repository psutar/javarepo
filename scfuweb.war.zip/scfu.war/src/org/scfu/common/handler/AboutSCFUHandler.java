package org.scfu.common.handler;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class AboutSCFUHandler extends MultiActionController {
	protected final Logger logger = Logger.getLogger(getClass());

	public ModelAndView displayHomePage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("displayHomePage : " + SCFUConstants.METHOD_BEGINS);
		Map<String,String> inputParams = new HashMap<String,String>();
		String returnView = "aboutSCFUPage";
		logger.info("displayHomePage : " + SCFUConstants.METHOD_ENDS);
		return new ModelAndView(returnView, "loginModel", inputParams);
	}

	public ModelAndView displayFirstTimeLogInPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("displayFirstTimeLogInPage" + SCFUConstants.METHOD_BEGINS);
		Map<String, String> inputParams = new HashMap<String, String>();
		String returnView = "firstTimeLogInPage";
		logger.info("displayHomePage" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView(returnView, "loginModel", inputParams);
	}
	//searchQuery method begins
	public ModelAndView searchQueryDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("SearchQueryHandler  "+SCFUConstants.METHOD_BEGINS);
		 Map inputParams = new HashMap();
		   String returnView="finalsearchpage";
		   logger.info("displayHomePage"+SCFUConstants.METHOD_ENDS);
		   return new ModelAndView(returnView,"loginModel",inputParams);
	
	}

}
