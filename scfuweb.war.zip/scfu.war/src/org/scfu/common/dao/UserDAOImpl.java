package org.scfu.common.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;


import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.model.User;
import org.scfu.common.model.UserProfile;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class UserDAOImpl implements UserDAO {
	
	private Logger logger = Logger.getLogger(getClass());
	
	public final static String GET_USER_DETAILS =
			         " SELECT sud.user_role user_role " +
			         " FROM scfu_user_details sud,scfu_user su " +
			         " WHERE su.user_id= sud.user_id " +
			         " AND su.login_id=? ";
	
	public final static String USER_PROFILE_FINDER = 
		             " SELECT su.login_id userName,sup.nick_name nick_name,sup.address1 address1, " +
			         " sup.email email,sup.phone_no phone_no ,sup.mobile_no mobile_no , "+
					 " sup.date_of_birth date_of_birth, sup.mobile_country_code mobile_country_code, sud.code imCode "+
					 " FROM scfu_user_profile sup, scfu_user_details sud, scfu_user su " +
					 " WHERE sup.user_id IN (select user_id from scfu_user where login_id=?) "+
					 " AND sup.user_id = sud.user_id "+
					 " AND su.user_id= sud.user_id ";
	private JdbcTemplate jdbcTemplate;
    
   

	
	public User getUserDetails(String userName)
	{
		logger.info("getUserDetails"+SCFUConstants.METHOD_BEGINS);
		logger.info("userName "+userName);
		User user = new User();
		//		Map userDetails = new HashMap();
		Object params[]= new Object[] {userName};
		List userDetailsList = jdbcTemplate.queryForList( GET_USER_DETAILS,params);  
		int userRole=(int )((BigDecimal)((Map)userDetailsList.get(0)).get("USER_ROLE")).doubleValue();
		logger.info("userRole"+userRole);
		String role=Integer.toString(userRole);
		logger.info("role" + role);
		//		userDetails.put("role",role);
		user.setRoles(role);
		user.setUserName(userName);
		logger.info("getUserDetails"+SCFUConstants.METHOD_ENDS);
		return user;
	}
	
	public UserProfile findUserProfile(String userName) throws DAOException {
		UserProfile userprofile = null;
		try {
			Object[] parameters = new Object[] { userName };				
			List result = jdbcTemplate.query(USER_PROFILE_FINDER, parameters,new UserProfileRowMapper());
			if (result != null && !result.isEmpty()) {
				userprofile = (UserProfile) result.get(0);					
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.info("Error Message  "+ex.getMessage());
			DAOException.throwException("");
		}
		return userprofile;
	}
	
	class UserProfileRowMapper implements RowMapper {
		
		public Object mapRow(ResultSet rs, int index) throws SQLException {

			UserProfile profile = new UserProfile();
			profile.setUserName(rs.getString(SCFUConstants.USER_NAME));
			profile.setNickName(rs.getString(SCFUConstants.NICK_NAME));
			profile.setAddress(rs.getString(SCFUConstants.ADDRESS));
			profile.setEmailId(rs.getString(SCFUConstants.EMAIL_ID));
			profile.setPhoneNo(rs.getString(SCFUConstants.PHONE_NO));
			profile.setMobileNo(rs.getString(SCFUConstants.MOBILE_NO));
			profile.setDateOfBirth(rs.getString(SCFUConstants.DATE_OF_BIRTH));
			profile.setMobileCountryCode(rs.getString(SCFUConstants.MOBILE_COUNTRY_CODE));
			profile.setImCode(rs.getString(SCFUConstants.IM_CODE));
			return profile;
		}
	}
	
	public void insertActiveUserLogin(Map inParams ) {
		logger.info("insertActiveUserLogin " + SCFUConstants.METHOD_BEGINS);		
        logger.info("inParams.....module name"+inParams.get("moduleName")+"session id ..."+inParams.get("sessionId")+"...USER_NAME..."+inParams.get("userName")+"...IP_ADDRESS..."+inParams.get("userIPaddress")+"...SERVER_NAME..."+inParams.get("serverName"));
		String insSql="INSERT INTO scfu_loggedin_users(USER_NAME,IP_ADDRESS,SERVER_NAME,MODULE_NAME,SESSION_ID,CREATION_TIME) " +
	  			" VALUES(?,?,?,?,?,sysdate)";
		
		String updSql = "update scfu_loggedin_users set user_name=? where SESSION_ID=? AND trim(USER_NAME)<>? ";
		try{
		  Object param1[] = { (String)inParams.get("userName") }; 	
		  int userCount = jdbcTemplate.queryForInt("select count(*) from scfu_loggedin_users where user_name = ? ", param1); 
		  logger.info("userCount : " + userCount); 
		  if (userCount > 0) {
			  logger.info("User Already Loggedin : " + inParams.get("userName")); 
			  Object[] updParams = { (String) inParams.get("userName"),
					(String) inParams.get("sessionId"),
					(String) inParams.get("userName") };
			  int updCount = jdbcTemplate.update(updSql, updParams);
			  logger.info("updCount :" + updCount);
			  if (updCount <= 0){
						logger.info("error occoured");
						DAOException.throwException("alreadyLoggedin");
					}
		  } else {
			  logger.info("User entered in : " + inParams.get("userName")); 
			Object[] params={(String)inParams.get("userName"),
			(String)inParams.get("userIPaddress"),
			(String)inParams.get("serverName"),
			(String)inParams.get("moduleName"),
			(String)inParams.get("sessionId")};
			int sqlTypes[]={Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
			int inscount=jdbcTemplate.update(insSql,params,sqlTypes);
			logger.info("insert count in scfu_loggedin_users :"+inscount);
		  }
		}catch(DataIntegrityViolationException dive){
			logger.error("dive :"+dive);
			Object[] updParams={(String)inParams.get("userName"),(String)inParams.get("sessionId"),(String)inParams.get("userName")};
			int updCount=jdbcTemplate.update(updSql,updParams);
			logger.info("updCount :"+updCount);
			if(updCount <=0)
				DAOException.throwException("TechnicalProblem");
		}
			
		logger.info("insertActiveUserLogin(Map inparamMap )" + SCFUConstants.METHOD_ENDS);
	}
	
	
	public void deleteActiveUserLogin(String userName ) {
		  logger.info("deleteActiveUserLogin " + SCFUConstants.METHOD_BEGINS);
		  String sql="delete from scfu_loggedin_users where user_name=?";
		  Object[] params={userName};
		  jdbcTemplate.update(sql,params);
		  logger.info("deleteActiveUserLogin " + SCFUConstants.METHOD_ENDS);	
		  
	}
	
	 public void setDataSource(DataSource dataSource) {
         this.jdbcTemplate = new JdbcTemplate(dataSource);
}
}
