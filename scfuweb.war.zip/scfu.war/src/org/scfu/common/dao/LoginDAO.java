package org.scfu.common.dao;

import java.util.Map;

public interface LoginDAO {

	/**
	 * @param key
	 * @param userName
	 * @param password
	 * @param sha2Password
	 * @return
	 */
	Map checkLogin(String key, String userName, String password,String sha2Password,String userIPaddress);

	/**
	 * @param userName
	 * @param newpassword
	 * @param sha2Password
	 * @return
	 */
	boolean changePassword(String userName,  String sha2Password);

	/**
	 * @param userName
	 * @param sha2OldPassword
	 * @return
	 */
	boolean checkOldPassword(String userName,String sha2OldPassword);
	
	/**
	 * @param userName
	 * @param desired_username
	 * @param password
	 * @param sha2Password
	 * @return
	 */
	boolean firstLogin(String userName, String desired_username, String password, String sha2Password);

	/**
	 * @param userName
	 * @param loginStatus
	 * @return
	 */
	public int successLoginCount(String userName, boolean loginStatus);
	public int faliureLoginCount(String userName, boolean loginStatus);

	/**
	 * @param userName
	 * @return
	 */
	int checkUsername(String userName);
}
