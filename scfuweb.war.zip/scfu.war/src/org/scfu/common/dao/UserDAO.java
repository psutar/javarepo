package org.scfu.common.dao;

import java.util.Map;

import org.scfu.common.exception.DAOException;
import org.scfu.common.model.User;
import org.scfu.common.model.UserProfile;

public interface UserDAO {
	User getUserDetails(String userName);
	public UserProfile findUserProfile(String userName) throws DAOException;
	public void insertActiveUserLogin(Map inParams); 
	public void deleteActiveUserLogin(String userName );
}
