package org.scfu.common.dao;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource; 
import org.apache.log4j.Logger;
import org.scfu.authentication.utils.PasswordValidator;
import org.scfu.common.exception.DAOException;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
 

public class LoginDAOImpl implements LoginDAO {
	
	private Logger logger = Logger.getLogger(getClass());
	private PasswordValidator passwordValidator;

	public final static String GET_DB_PASSWORD ="SELECT password FROM SCFU_USER where login_id=? and status='1'";
	
	public final static String UPDATE_LOGIN_COUNT="update scfu_user_details sud set sud.login_count=(sud.login_count+1),sud.login_failure_count= 0,sud.last_login_date=sysdate "+
												  " WHERE sud.user_id=( SELECT sud.user_id FROM scfu_user_details sud,scfu_user su "+
												  " WHERE su.user_id= sud.user_id AND su.login_id =? ) ";
	public final static String UPDATE_LOGIN_FAIL_COUNT="update scfu_user_details sud set sud.login_failure_count=(sud.login_failure_count+1),sud.LAST_LOGIN_FAILURE_DATE=sysdate, sud.LAST_LOGIN_FAILURE_IP=? "+
	  												"WHERE sud.user_id=( SELECT sud.user_id FROM scfu_user_details sud,scfu_user su "+
	  												"WHERE su.user_id= sud.user_id AND su.login_id =?) ";
	
	public final static String GET_LOGIN_COUNT=	"select login_count FROM  scfu_user_details sud  "+
 										   		"WHERE sud.user_id  =(SELECT  su.user_id FROM scfu_user su WHERE   su.login_id =?)  ";
	
	public final static String GET_LAST_LOGIN_DATE_DETAILS=	"select last_login_date,last_login_failure_date FROM  scfu_user_details sud  "+
													"WHERE sud.user_id  =(SELECT  su.user_id FROM scfu_user su WHERE   su.login_id =?)  ";

	public final static String GET_FAILURE_LOGIN_COUNT="SELECT login_failure_count FROM  scfu_user_details sud  "+
													   "WHERE sud.user_id  =(SELECT  su.user_id FROM scfu_user su WHERE   su.login_id =?)  ";

	public final static String UPDATE_FIRST_TIME_LOGIN="UPDATE scfu_user SET LOGIN_ID=?, password=? WHERE login_id=? ";

	public final static String UPDATE_OLD_LOGIN_ID="UPDATE scfu_user_details SET OLD_LOGIN_ID=? WHERE user_id=(select user_id from scfu_user where login_id=?) ";

	public final static String UPDATE_LOGIN_PASSWORD="UPDATE scfu_user SET password=? WHERE login_id=? ";

	public final static String VALIDATE_USERNAME="SELECT COUNT(*) FROM  scfu_user WHERE login_id=? ";
	
	
	private JdbcTemplate jdbcTemplate;   
	
  

	/* (non-Javadoc)
	 * @see org.scfu.common.dao.LoginDAO#checkLogin(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public Map checkLogin(String keyString, String userName,String password, String sha2Password,String userIPaddress)  {
		logger.info("checkLogin"+SCFUConstants.METHOD_BEGINS);
		Map loginCheck = new HashMap();
		boolean loginStatus = false;
		Timestamp lastLoginDate = null;
		Timestamp lastLoginFailDate = null;
		String lastLoginFailIP = null;
		
		try {
			String dbPassword = null;
			Object[] params={userName};	
			List userPwdList= jdbcTemplate.queryForList(GET_DB_PASSWORD,params);
			if(userPwdList!= null && !userPwdList.isEmpty()){
				Map userMap=(Map)userPwdList.get(0);
				dbPassword 	=(String)userMap.get("password");
			}
			if (dbPassword != null) {
				if(keyString!=null ){
					loginStatus = passwordValidator.validateHashSHA2(sha2Password, dbPassword+"#"+keyString);
				}else{
					loginStatus = passwordValidator.validateHashSHA2( dbPassword,userName+ "#" + password);
				}

				logger.info("userName :"+userName+" loginStatus :"+loginStatus);
				if (loginStatus){
					Object[] params1={userName};
					int loginCount=(Integer)jdbcTemplate.queryForObject(GET_LOGIN_COUNT,params1,Integer.class);
					int faliureLoginCount=(Integer)jdbcTemplate.queryForObject(GET_FAILURE_LOGIN_COUNT,params1,Integer.class);
					
					
					Object[] param1 = { userName };
					List<Map> list = jdbcTemplate.queryForList(GET_LAST_LOGIN_DATE_DETAILS,param1);
					if(list!= null && !list.isEmpty()){
						Map map =list.get(0);
						lastLoginDate=(Timestamp)map.get("last_login_date");
						lastLoginFailDate=(Timestamp)map.get("last_login_failure_date");
					}
					
					logger.info("Login count  :"+loginCount);
					logger.info("faliure Login Count  :"+faliureLoginCount);
					if (loginCount>0 && faliureLoginCount <= 3){
						logger.info("Login count to be updated :"+UPDATE_LOGIN_COUNT);
						int count= jdbcTemplate.update(UPDATE_LOGIN_COUNT,params1);
						
						logger.info("No of rows updated for login success :"+count);
					}
					else if (faliureLoginCount > 3){
						logger.info("Account is locked");
						DAOException.throwException("AccountLocked");
					}
				}
				if (!loginStatus){
					Object[] params2={userIPaddress,userName};
					logger.info("Login Failure Count :"+UPDATE_LOGIN_FAIL_COUNT);
					int count= jdbcTemplate.update(UPDATE_LOGIN_FAIL_COUNT,params2);
					Object[] params3={userName};

					Integer faliureLoginCount=(Integer) jdbcTemplate.queryForObject(GET_FAILURE_LOGIN_COUNT,params3,Integer.class);
					if (faliureLoginCount > 3){
						logger.info("Account is locked");
						DAOException.throwException("AccountLocked");
					}
					logger.info("No of rows updated for login faliure:"+count);
				}
			}
		} catch (DataAccessException e) {
			e.printStackTrace();
			logger.error("Error Occured ***************** :" +e.getMessage());
			System.out.println("Error Occured ***************** :" +e.getMessage());
		
			DAOException.throwException("TechnicalProblem");
		}
		
		logger.info("lastLoginDate : "+lastLoginDate);
		logger.info("lastLoginFailDate : "+lastLoginFailDate);
		logger.info("lastLoginFailIP : "+lastLoginFailIP);
		logger.info("loginStatus : "+loginStatus);
		
		loginCheck.put("lastLoginDate",lastLoginDate);
		loginCheck.put("lastLoginFailDate",lastLoginFailDate);
		loginCheck.put("lastLoginFailIP",lastLoginFailIP);
		loginCheck.put("loginStatus",loginStatus);
		
		logger.info("loginCheck Map : "+loginCheck);
		
		logger.info("checkLogin"+SCFUConstants.METHOD_ENDS);
		return loginCheck;
	}
	
	public boolean firstLogin(String userName, String desired_username,String password, String sha2Password) {
		logger.info("firstLogin"+SCFUConstants.METHOD_BEGINS);
		logger.info("userName :"+userName+"  desired_username :"+desired_username);
		boolean firstLoginStatus=false;
		int updatelogincount=0;
		try{
			Object[] params1={userName};
			Object[] params2={desired_username,sha2Password,userName};
			Object[] params3={userName,userName};
			updatelogincount=(int)jdbcTemplate.update(UPDATE_LOGIN_COUNT,params1);
			int count1=(int)jdbcTemplate.update(UPDATE_OLD_LOGIN_ID,params3);
			int count=(int)jdbcTemplate.update(UPDATE_FIRST_TIME_LOGIN,params2);
			logger.info("No of rows updated  for login count:"+updatelogincount+" No of rows updated  for first time login :"+count+" No of rows updated  for login id :"+count1);
			if (count>0){
				firstLoginStatus=true;
				logger.info("firstLoginStatus :"+firstLoginStatus);
			}
			else{
				logger.info("error occoured");
				DAOException.throwException("recNotCreated");
			}
		}
		catch (DataAccessException e) {
			logger.error("Error Occured :" +e.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("firstLogin"+SCFUConstants.METHOD_ENDS);
		return firstLoginStatus;
	}
	
	public boolean changePassword(String userName, String sha2Password) {
		logger.info("changePassword"+SCFUConstants.METHOD_BEGINS);
		logger.info("userName :"+userName);
		boolean changePasswordStatus=false;
		try{
			Object[] params1={sha2Password,userName};
			int count=(int)jdbcTemplate.update(UPDATE_LOGIN_PASSWORD,params1);
			logger.info("No of rows updated  username password change :"+count);
			if (count>0){
				changePasswordStatus=true;
				logger.info("changePasswordStatus :"+changePasswordStatus);
			}
			else{
				logger.info("error occoured");
				DAOException.throwException("recNotCreated");
			}
		}
		catch (DataAccessException e) {
			logger.error("Error Occured :" +e.getMessage());
		}
		logger.info("changePassword"+SCFUConstants.METHOD_ENDS);
		return changePasswordStatus;
	}
	
	public boolean checkOldPassword(String userName,String sha2OldPassword) {
		logger.info("checkOldPassword"+SCFUConstants.METHOD_BEGINS);
		logger.info("userName :"+userName);
		logger.info("sha2OldPassword:"+sha2OldPassword);
		boolean checkOldPasswordStatus=false;
		try{
			
			Object[] params1={userName};
			String dbPassword = (String) jdbcTemplate.queryForObject(GET_DB_PASSWORD,params1, String.class);
			logger.info("dbPassword : " +dbPassword);
			if (dbPassword != null && (dbPassword.equals(sha2OldPassword))){
				checkOldPasswordStatus=true;
				logger.info("checkOldPasswordStatus :"+checkOldPasswordStatus);
			    }
/*			else{
				logger.info("error occoured");
				DAOException.throwException("recNotCreated");
			    }*/
		}
		catch (DataAccessException e) {
			logger.error("Error Occured :" +e.getMessage());
		}
		logger.info("checkOldPassword"+SCFUConstants.METHOD_ENDS);
		return checkOldPasswordStatus;
		}
	
	
	
	public int successLoginCount(String userName,boolean loginStatus) {
		
		logger.info("successLoginCount"+SCFUConstants.METHOD_BEGINS);
		int  loginCount = 0;
		try{
			Object[] params = { userName };
			List<Map> list = jdbcTemplate.queryForList(GET_LOGIN_COUNT,params);
			if(list!= null && !list.isEmpty()){
				Map map =list.get(0);
				BigDecimal  bigDecimal =(BigDecimal)map.get("login_count");
				loginCount= bigDecimal.intValue();
			}
			logger.info("Login count :"+loginCount);
		}
		 catch (DataAccessException e) {
				logger.error("Error Occured : " +e.getMessage());
				DAOException.throwException("TechnicalProblem");
			}
		logger.info("successLoginCount"+SCFUConstants.METHOD_ENDS);
		return loginCount;
	}
	

	@Override
	public int faliureLoginCount(String userName, boolean loginStatus) {
		logger.info("faliureLoginCount"+SCFUConstants.METHOD_BEGINS);
		int faliureLoginCount = 0;
		try{
			Object[] params={userName};
			List<Map> list= jdbcTemplate.queryForList(GET_FAILURE_LOGIN_COUNT,params);
			if(list!=null && !list.isEmpty()){
				Map map = list.get(0);
				BigDecimal  bigDecimal =(BigDecimal)map.get("login_failure_count");
				faliureLoginCount =bigDecimal.intValue();
			}
			logger.info("faliure Login Count :"+faliureLoginCount);
		}
		 catch (DataAccessException e) {
				logger.error("Error Occured : " +e.getMessage());
				DAOException.throwException("TechnicalProblem");
			}
		logger.info("faliureLoginCount"+SCFUConstants.METHOD_ENDS);
		return faliureLoginCount;
	}

	public int checkUsername(String userName) {
		logger.info("checkUsername"+SCFUConstants.METHOD_BEGINS);
		int count = 0;
		logger.info("userName :" + userName );
		Object[] parameters = new Object[]{userName};
		try {
				int sqlTypes[] = {Types.VARCHAR};
				count = jdbcTemplate.queryForInt(VALIDATE_USERNAME,parameters,sqlTypes);
				logger.info("count:" + count);
			}
			catch (DataAccessException dataAccessException) {
				logger.error("Exception occured : " + dataAccessException.getMessage());
				DAOException.throwException("TechnicalProblem");
			}
		logger.info("checkUsername"+SCFUConstants.METHOD_ENDS);
		return count;
	}
	
	
	public void setPasswordValidator(PasswordValidator passwordValidator) {
		this.passwordValidator = passwordValidator;
	}

    
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}


}
