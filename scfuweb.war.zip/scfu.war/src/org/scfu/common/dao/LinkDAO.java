package org.scfu.common.dao;
import java.util.Map;

public interface LinkDAO {
	Map getLinkDetails(String userRole,String moduleName);
	
}
