package org.scfu.common.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.scfu.common.model.LinkDetails;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

public class LinkDAOImpl implements LinkDAO {
	private Logger logger = Logger.getLogger(getClass());
	public final static String GET_LINK_DETAILS ="SELECT slm.link_id,  slm.link_name,  slm.link_url,  slm.link_order_no,  slm.tab_name,  slm.tab_id,  slm.base_url,   slm.body_header,  slm.body_tab,  slm.body_tab_name,  slm.left_nav FROM SCFU_LINK_MASTER slm, scfu_role_link_details srld WHERE slm.link_id= srld.link_id AND srld.user_role=? AND slm.module_name=? order by slm.tab_id, slm.link_order_no ";
	private JdbcTemplate jdbcTemplate;
	
	public Map getLinkDetails(String userRole, String moduleName) {
		logger.info("getLinkDetails : " + SCFUConstants.METHOD_BEGINS);
		logger.info("userRole " + userRole + " moduleName " + moduleName);
		Object params[] = { userRole, moduleName };
		Map linkDetails = (Map) jdbcTemplate.query(GET_LINK_DETAILS, params, new LinkDetailExtractor());
		logger.info("getLinkDetails : " + SCFUConstants.METHOD_ENDS);
		return linkDetails;
	}

	public class LinkDetailExtractor implements ResultSetExtractor{
		public Object extractData(ResultSet rs) throws SQLException, DataAccessException{
		logger.info("LinkDetailExtractor"+SCFUConstants.METHOD_BEGINS);
		Map linkDetailsMap = new LinkedHashMap();
		Map tabs = new LinkedHashMap();
		while (rs.next()){
                LinkDetails linkDetails = new LinkDetails();
                linkDetails.setLinkID(rs.getString("LINK_ID"));
                linkDetails.setLinkName(rs.getString("LINK_NAME"));
                linkDetails.setLinkOrder(new Integer(rs.getInt("LINK_ORDER_NO")));
                linkDetails.setLinkURL(rs.getString("LINK_URL"));
                linkDetails.setTabID(new Integer(rs.getInt("TAB_ID")));
                linkDetails.setTabName(rs.getString("TAB_NAME"));
                linkDetails.setBaseURL(rs.getString("BASE_URL"));
                linkDetails.setBodyHeader(rs.getString("BODY_HEADER"));
                linkDetails.setBodyTab(rs.getString("BODY_TAB"));
                linkDetails.setBodyTabName(rs.getString("BODY_TAB_NAME"));
                linkDetails.setLeftNav(rs.getString("LEFT_NAV"));
                linkDetailsMap.put(linkDetails.getLinkURL(), linkDetails);
                if(!tabs.containsKey(rs.getString("TAB_NAME")))
	                	tabs.put(rs.getString("TAB_NAME"),linkDetails);
	            }
				linkDetailsMap.put("tabs",tabs);
        logger.info("linkDetailsMap.size : " + linkDetailsMap.size());
        return linkDetailsMap;
        }
	}
	   
    public void setDataSource(DataSource dataSource) {
           this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
}
