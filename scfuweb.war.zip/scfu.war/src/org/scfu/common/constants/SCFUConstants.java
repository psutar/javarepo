package org.scfu.common.constants;
public interface SCFUConstants
{ 
    public static final String APPLICATION_RESPONSE = "applicationResponse";
    public static final String FAILURE = "failure";
    public static final String SUCCESS = "success";
    public static final String ERROR_VIEW = "errorView";
    public static final String ERROR_MODEL = "errorModel";
    public static final String METHOD_BEGINS = "-Method begins.";
    public static final String METHOD_ENDS = "-Method ends.";
    
    
    public static final String USER_NAME =  "userName";
    public static final String NICK_NAME =  "nick_name";
    public static final String ADDRESS =  "address1";
    public static final String EMAIL_ID =  "email";
    public static final String PHONE_NO =  "phone_no";
    public static final String MOBILE_NO =  "mobile_no";
    public static final String DATE_OF_BIRTH =  "date_of_birth";
    public static final String MOBILE_COUNTRY_CODE =  "mobile_country_code";
    public static final String IM_CODE = "imCode";
    public static final String USER = "user";
    public static final String PROFILE = "profile";
    public static final String SESSION_ERROR_MESSAGE = "Your session expired.Please re-login.";
    
    public static final String SESSION_ERROR = "sessionError";
    
    public static final String EMPTY = "";
    public static final String PASSWORD = "password";
    
    public static final String NEW_PASSWORD = "newPassword";
    public static final String OLD_PASSWORD = "oldPassword";
    
    public static final String OUTPUT_PARAMS="outputParams";
    public static final String SHA2PASSWORD  = "sha2Password";
    public static final String SHA2OLDPASSWORD = "sha2OldPassword";
    public static final String DOT = ".";
    public static final String XML_EXTENSION = "xml";
    public static final String PDF_EXTENSION = "pdf";
    public static final String XLS_EXTENSION = "xls";
    public static final String TXT_EXTENSION = "txt";
    
    public static final String REFRESH_URL = "refreshUrl";
    public static final String TRANSACTION_NAME = "transactionName";
    public static final String REFRESH_MODEL = "refreshModel";
    

}


