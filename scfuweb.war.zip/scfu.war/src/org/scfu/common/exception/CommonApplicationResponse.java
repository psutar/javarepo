package org.scfu.common.exception;

public abstract class CommonApplicationResponse {		
	public abstract String getErrorCode();
	public  abstract String getErrorMessage();
	public abstract String getErrorStatus();
	public abstract void setErrorCode(String errorCode);
	public  abstract void setErrorMessage(String errorMessage);
	public abstract void setErrorStatus(String errorStatus);
}
