package org.scfu.common.exception;

import org.apache.log4j.Logger;

public class DAOException extends RuntimeException {
    
    protected final static Logger logger = Logger.getLogger("org.scfu.common.exception.DAOException");
 
    public String errorCode;

    public String errorDescription;
    
    private Exception exception;
    
    public DAOException(String errorCode){
        this.errorCode = errorCode;
    }
    public DAOException(Exception exception,String errorCode){
        this.errorCode = errorCode;
        this.exception = exception;
    }
    
    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public static void throwException(String errorCode) throws DAOException{
        logger.info("Exception in DAO errorCode" + errorCode);
        DAOException exception = new DAOException (errorCode);
        logger.info("Exception in DAO" + exception);

        throw exception;  
    } 

    public static void throwException(String errorCode, Exception exceptionCaught) throws DAOException{
        DAOException exception = new DAOException(errorCode);
        logger.error("Exception in DAO " + exceptionCaught.getMessage(),exceptionCaught);
        throw exception;
    }
    
    
}