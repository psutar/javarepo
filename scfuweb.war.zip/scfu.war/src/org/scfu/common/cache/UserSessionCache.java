
package org.scfu.common.cache;

import java.util.Hashtable; 
import org.apache.log4j.Logger;

public class UserSessionCache
{
    private Hashtable userSessionCache = new Hashtable();

    protected final Logger logger = Logger.getLogger(getClass());

    public Object getData(String key)
    {
        return userSessionCache.get(key);
    }

    public void setData(String key, Object value)
    {
        userSessionCache.put(key, value);
    }

    public void removeData(String key)
    {
        userSessionCache.remove(key);

    } 

}
