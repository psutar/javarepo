package org.scfu.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.bp.LogonBp;
import org.scfu.common.dao.LoginDAO;
import org.scfu.common.dao.UserDAO;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;

public class FirstLogonService extends BaseService {
	protected Logger logger = Logger.getLogger(getClass());
	 private LoginDAO loginDAO;

	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response=new SCFUApplicationResponse();

		Map outParams = new HashMap();
		
		String userName=(String)inputParams.get(SCFUConstants.USER_NAME);
		String password=(String)inputParams.get(SCFUConstants.PASSWORD);
		String desired_username=(String)inputParams.get("desired_username");
		String sha2Password=(String)inputParams.get(SCFUConstants.SHA2PASSWORD);
	//	logger.info("userName "+userName +" password"+password+"sha2password" +sha2Password+" desired_username:"+desired_username);		
		try {
			boolean firstLoginStatus=loginDAO.firstLogin(userName,desired_username,password,sha2Password);
			logger.info("firstLoginStatus in FirstLogonService:"+firstLoginStatus);
			outParams.put("firstLoginStatus", firstLoginStatus);
			if (firstLoginStatus) {
			response.setErrorStatus(SCFUConstants.SUCCESS);
			}
			else{
				logger.info("Error Occurred");
				response.setErrorCode("LoginFail");
				response.setErrorStatus(SCFUConstants.FAILURE);
			}
		}catch (DAOException e) {
			logger.info("DAOException Occurred");
			response.setErrorCode(e.getErrorCode());
		}  catch (Exception e) {
			logger.info("Exception Occurred");
			response.setErrorCode("TechnicalProblem");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}
}
