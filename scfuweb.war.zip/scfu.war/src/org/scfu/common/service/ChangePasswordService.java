package org.scfu.common.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.dao.LoginDAO;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;

public class ChangePasswordService extends BaseService {
	protected Logger logger = Logger.getLogger(getClass());
	 private LoginDAO loginDAO;

	/* Used to change the password for a particular profile
	 *
	 */
	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response=new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map outParams = new HashMap();
		String userName=(String)inputParams.get(SCFUConstants.USER_NAME);
		String sha2Password=(String)inputParams.get(SCFUConstants.SHA2PASSWORD);
		String sha2Oldpassword=(String)inputParams.get(SCFUConstants.SHA2OLDPASSWORD);
		
		try {
			Boolean checkOldPassword=loginDAO.checkOldPassword(userName,sha2Oldpassword);
			
			if (checkOldPassword.equals(Boolean.TRUE)){
				Boolean changePasswordStatus=loginDAO.changePassword(userName,sha2Password);
				logger.info("changePasswordStatus in ChangePasswordService:"+changePasswordStatus);
				outParams.put("changePasswordStatus", changePasswordStatus);
				if (changePasswordStatus.equals(Boolean.TRUE)){
				   response.setErrorStatus(SCFUConstants.SUCCESS);
				}
				else{
					logger.info("Exception Occurred");
					response.setErrorCode("PasswordNotChanged");
					response.setErrorStatus(SCFUConstants.FAILURE);
				}
			}
			else{
				logger.info("Exception Occurred");
				response.setErrorCode("IncorrectOldPassword");
				response.setErrorStatus(SCFUConstants.FAILURE);
			}
			
			}catch (DAOException e) {
			logger.info("DAOException Occurred");
			response.setErrorCode(e.getErrorCode());
		}catch (Exception e) {
			logger.info("Exception Occurred");
			response.setErrorCode("TechnicalProblem");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		
		
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}

	

}
