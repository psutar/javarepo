/**
 * @author Prateek
 * This class is used for logging in a user by checking the username and password
 */
package org.scfu.common.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.bp.LogonBp;
import org.scfu.common.dao.LoginDAO;
import org.scfu.common.dao.UserDAO;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.model.User;
import org.scfu.common.model.UserProfile;
import org.scfu.common.constants.SCFUConstants;

public class LogonService extends BaseService {
	protected Logger logger = Logger.getLogger(getClass());
	private LogonBp logonBp;
	private UserDAO userDAOImpl;
	private LoginDAO loginDAO;
	private String multipleLoginFlag;

	public Map execute(Map inputParams) {
		logger.info("execute : "+SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response=new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);

		int loginCount=0;
		int faliureLoginCount=0;
		Timestamp lastLoginDate=null;
		Timestamp lastLoginFailDate = null;
		String lastLoginFailIP = null;
		Map outParams = new HashMap();
		Map loginCheck = new HashMap();
		User user = null;
		UserProfile profile =null;

		String keyString=(String)inputParams.get("keyString");
		String userName=(String)inputParams.get(SCFUConstants.USER_NAME);
		String password=(String)inputParams.get(SCFUConstants.PASSWORD);
		String sha2Password=(String)inputParams.get(SCFUConstants.SHA2PASSWORD);
		String userIPaddress = (String) inputParams.get("userIPaddress");
		//logger.info("inputParams  :"+inputParams);
		if (userName != null && password != null) {
			try {
				
				 loginCheck = logonBp.validateLogin(keyString, userName, password, sha2Password ,userIPaddress);
				 
				 boolean loginStatus =(Boolean)loginCheck.get("loginStatus");
				 lastLoginDate= (Timestamp)loginCheck.get("lastLoginDate");
				 lastLoginFailDate= (Timestamp)loginCheck.get("lastLoginFailDate");
				 
				 logger.info("loginStatus  : "+loginStatus);
				 logger.info("lastLoginDate  : "+lastLoginDate);
				 logger.info("lastLoginFailIP **************************** : "+lastLoginFailIP);
				 
				 
				if(loginStatus)
				{
					if(multipleLoginFlag!=null && multipleLoginFlag.equals("NO"))
					{ 
						userDAOImpl.insertActiveUserLogin(inputParams); 
					}
					
					loginCount = loginDAO.successLoginCount(userName, loginStatus);
					faliureLoginCount = loginDAO.faliureLoginCount(userName, loginStatus);
					logger.info("loginCount in :"+loginCount  +" faliureLoginCount : "+faliureLoginCount);
					
					response.setErrorStatus(SCFUConstants.SUCCESS);
					user = userDAOImpl.getUserDetails(userName);
					logger.info("Username " +user.getUserName());
					if(user.getRoles() != null && user.getRoles().length() > 0 ){
						logger.info("User Role:" +user.getRoles());
						profile = (UserProfile)userDAOImpl.findUserProfile(user.getUserName());
					}
				}else
				{
					response.setErrorCode("InvalidLogin");
					response.setErrorStatus(SCFUConstants.FAILURE);
				}

			}catch (DAOException e) {
				logger.info("DAOException Occurred");
				response.setErrorCode(e.getErrorCode());
				e.printStackTrace();
			}catch (Exception e) {
				logger.info("Exception Occurred");
				response.setErrorCode("TechnicalProblem");
				e.printStackTrace();
			}
		}else{
			response.setErrorCode("nullLogin");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}

		outParams.put("loginCount", loginCount);
		outParams.put("faliureLoginCount", faliureLoginCount);
		outParams.put("user", user);
		outParams.put("profile", profile);
		outParams.put("lastLoginDate", lastLoginDate);
		outParams.put("lastLoginFailDate", lastLoginFailDate);
		outParams.put("lastLoginFailIP", lastLoginFailIP);
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setLogonBp(LogonBp logonBp) {
		this.logonBp = logonBp;
	}
	
	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}

	public void setUserDAOImpl(UserDAO userDAOImpl) {
		this.userDAOImpl = userDAOImpl;
	}

	public void setMultipleLoginFlag(String multipleLoginFlag) {
		this.multipleLoginFlag = multipleLoginFlag;
	}
}
