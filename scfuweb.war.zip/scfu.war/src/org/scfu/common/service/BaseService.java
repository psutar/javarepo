 
package org.scfu.common.service;
 
import java.util.Map;

public abstract class BaseService {
    String execute(String xmlString) {
        return null;
    }

    public Map execute(Map inputParams){
        return null;
    }

}
