package org.scfu.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.common.utils.SessionValidator;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

/**
 * Pre handle is for checking null sessions post handle for redirecting to error
 * page on error in application status.
 * 
 * @version 1.0
 * @author MahindraSatyam Computer Services Ltd.,
 */
public class DynamicLinkInterceptor extends WebContentInterceptor {

	   protected final Logger logger = Logger.getLogger(getClass());

   
    public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception {
    }

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
    	logger.info(" preHandle  starts");
		HttpSession session = request.getSession(false);
		boolean sessionflag = false;
        sessionflag = SessionValidator.isValidSession(request,response,"");
        if(sessionflag)
        {
        	SessionValidator.dynamiclinks(request,session); 
        }
        logger.info(" preHandle  Ends");
        return sessionflag;
	}
	
} 
