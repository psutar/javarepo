package org.scfu.common.interceptor;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.utils.SessionValidator;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.WebContentInterceptor;



public class SCFUInterceptor extends WebContentInterceptor {

	   protected final Logger logger = Logger.getLogger(getClass());
	   private String type;
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception {
    	logger.info("SCFUInterceptor postHandle" + handler.getClass().getName());
        String currentURL = request.getServletPath().substring(1);
        request.setAttribute("currentURL",currentURL);
        logger.info(" request.getAttribute(SCFUConstants.APPLICATION_RESPONSE) : " + request.getAttribute(SCFUConstants.APPLICATION_RESPONSE));
        if (request.getAttribute(SCFUConstants.APPLICATION_RESPONSE) != null) {
        	SCFUApplicationResponse errorResponse = (SCFUApplicationResponse) request
                    .getAttribute(SCFUConstants.APPLICATION_RESPONSE);
            logger.info("error response " + errorResponse);
            if (errorResponse.getErrorStatus().equalsIgnoreCase(SCFUConstants.FAILURE)) {
            	logger.info("Status is error");
                String error_view = (String) request.getAttribute(SCFUConstants.ERROR_VIEW);
                request.setAttribute("status","error");

                logger.info("returning to the error view =" + error_view);
                Map outParam = new HashMap();
                outParam.put(SCFUConstants.APPLICATION_RESPONSE, errorResponse);
                modelAndView.addObject(SCFUConstants.ERROR_MODEL, outParam);
                modelAndView.setViewName(error_view);
            }
        }
        else {
        	if (modelAndView != null) {
        		SCFUApplicationResponse errorResponse=null;
        		Map outParam = new HashMap();
        		Map model = new HashMap();
        		model = modelAndView.getModel();
        		String modelName = new String();
        		logger.info("size of model =" + model.size());
        		logger.info("size of key set id =" + model.keySet().size());
        		for (int i = 0; i < model.keySet().size(); i++) {
        			logger.info("inside while");
        			modelName = (String) model.keySet().iterator().next();
        		}
        		logger.info("model name is " + modelName);
        		outParam = (Map) model.get(modelName);
        		logger.info("model name is outParam" + outParam);
        		if (outParam != null)
        			errorResponse = (SCFUApplicationResponse) outParam.get(SCFUConstants.APPLICATION_RESPONSE);
        		logger.info("error response " + errorResponse);
        		if (errorResponse != null && errorResponse.getErrorStatus().equalsIgnoreCase(
        						SCFUConstants.FAILURE)) {
        			logger.info("Status is error");
        			request.setAttribute("status","error");
        			String error_view = (String) outParam.get(SCFUConstants.ERROR_VIEW);
        			logger.info("returning to the error view =" + error_view);
        			modelAndView.addObject(SCFUConstants.ERROR_MODEL, outParam);
        			modelAndView.setViewName(error_view);

        		}
        	}
        }
    		
    }

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
    	logger.info("SCFUInterceptor starts");
    	boolean sessionflag=false;
        HttpSession session = request.getSession(false);
        
        if (SessionValidator.isValidReferer(request,response,session)) {
			sessionflag = SessionValidator.isValidSession(request, response, type);
	        if(sessionflag){
	             session.setAttribute("viewName","false");
	             session.setAttribute("currentURL",request.getServletPath().substring(1));
	        }
		}
        
        logger.info("SCFUInterceptor ends");
		return sessionflag;
	}
    

    
    
   
	
} 
