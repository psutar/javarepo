package org.scfu.common.interceptor;

import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.mvc.WebContentInterceptor;


public class XSSInterceptor extends WebContentInterceptor{
	
	protected final Logger logger = Logger.getLogger(getClass());
//	private String[] jsStr= {"<", ">" ,"(" , ")" ,"'" , "\"" , "/" ,"\\","*", ";" ,":", "=" , "{" , "}" , "`" , "%" ,"^", "!", "-" , "\\x00", "\\x11,", "\\x12", "\\x13,", "\\x14", "\\x15,", "\\x16", "\\x17,", "\\x18", "\\x19,", "\\x20"};
//	private String[] jsStr= {"<", ">" ,"'" , "\"" , "/" ,"\\","*", ";" ,":"};
	private String[] jsStr= {"<", ">" , "\"" ,"*", ";" ,"'","\\x"};
	
	private static Pattern[] patterns = new Pattern[] {
		// Script fragments
		Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
		// src='...'
		Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
		Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE| Pattern.DOTALL),
		// lonely script tags
		Pattern.compile("</script>", Pattern.CASE_INSENSITIVE), 
		Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE| Pattern.MULTILINE | Pattern.DOTALL),
		// eval(...)
		Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE| Pattern.MULTILINE | Pattern.DOTALL),
		// expression(...)
		Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE| Pattern.MULTILINE | Pattern.DOTALL),
		// javascript:...
		Pattern.compile("javascript:",Pattern.CASE_INSENSITIVE| Pattern.MULTILINE | Pattern.DOTALL),
		// vbscript:...
		Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
		// onload(...)=...
		Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
		Pattern.compile("alert(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
		Pattern.compile("prompt(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
		Pattern.compile("confirm(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL)
		};
	
	
	private Boolean stripXSS(HttpServletRequest request) {
		logger.info("stripXSS " + SCFUConstants.METHOD_BEGINS);
			// NOTE: It's highly recommended to use the ESAPI library and
			// uncomment the following line to
			// avoid encoded attacks.
			// value = ESAPI.encoder().canonicalize(value);
			// Avoid null characters
		   Enumeration en = request.getParameterNames();
		   while(en.hasMoreElements()){	
			   String paramName=(String)en.nextElement();
			   String paramValue=(String)request.getParameter(paramName);
			   //logger.info(":paramValue:::"+paramValue);
			   paramValue = paramValue.replaceAll("\0", "");
			   // Remove all sections that match a pattern
			   for (Pattern scriptPattern : patterns) {
				Matcher matcher = scriptPattern.matcher(paramValue);
				boolean isTrue = matcher.find();
				if (isTrue) {
					logger.info("Found XSS Text in :" + paramValue+" - Pattern checked is :"+ scriptPattern.pattern());
					   return true;
				   }
			   }
		   }
		logger.info("stripXSS " + SCFUConstants.METHOD_ENDS);
		return false;
	}
	
	
	private boolean checkJSCode(HttpServletRequest request) {
		logger.info("checkJSCode "  + SCFUConstants.METHOD_BEGINS);
		Enumeration en = request.getParameterNames();		
		while(en.hasMoreElements()){	
			String paramName=(String)en.nextElement();
			String paramValue=(String)request.getParameter(paramName);
			//logger.info(":paramValue:::"+paramValue);
			//logger.info(":paramName:::"+paramName);
			for (int i = 0; i < jsStr.length; i++) {
				if(paramValue.contains(jsStr[i])) {
					logger.info("Found XSS Text in :" + paramValue+" - Mached jsStr is :"+ jsStr[i]);
					return true;
				}
			}
		}
		return false;
	}
	
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
    {
    	logger.info("XSSInterceptor :" + handler.getClass().getName());
    	if(checkJSCode(request) || stripXSS(request)) {
    		logger.info("XSS Interceptor getparameterMap => " +request.getParameterMap());
    		try{
                String url = request.getServletPath().replaceAll("/","");
                logger.info("Url : "+url);
                request.setAttribute(SCFUConstants.REFRESH_URL,url);
                getServletContext().getRequestDispatcher("/xsserror.htm").forward(request, response);
                return false;
            }catch (Exception ex)
            {
                ex.printStackTrace();
                logger.info("Exception occure in XSS Interceptor : " + ex.getMessage());
            }
    	}
        return true;
    } 
}
