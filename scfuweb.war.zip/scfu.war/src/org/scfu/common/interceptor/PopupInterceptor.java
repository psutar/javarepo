package org.scfu.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.scfu.common.utils.SessionValidator;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

/**
 * Pre handle is for checking null sessions post handle for redirecting to error
 * page on error in application status.
 */

public class PopupInterceptor extends WebContentInterceptor {

   /* public void postHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws Exception {
    	//SessionValidator.postRequestHandling(request,response,modelAndView,"popup");
       
    }*/

    public boolean preHandle(HttpServletRequest request,
            HttpServletResponse response, Object handler) {
        boolean sessionflag=SessionValidator.isValidSession(request,response,"popup");
        return sessionflag;
    }
} 
