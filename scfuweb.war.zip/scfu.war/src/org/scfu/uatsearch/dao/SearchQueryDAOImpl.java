package org.scfu.uatsearch.dao;

import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.DAOException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

public class SearchQueryDAOImpl implements SearchQueryDAO   {
	protected final Logger logger = Logger.getLogger(getClass());
	private JdbcTemplate jdbcTemplate;

	public List searchQuery(final Map inParams) {
		logger.info("searchQuery " + SCFUConstants.METHOD_BEGINS);
		List sqlQueryResult = null;
		try {
			String sqlQuery =(String)inParams.get("sqlQuery");
			logger.info(" SqlQuery  ::::: "+ sqlQuery);
			sqlQueryResult = jdbcTemplate.queryForList(sqlQuery);
		} catch (DataAccessException e) {
			logger.error("Error Occured : " + e.getMessage());
			DAOException.throwException("TechnicalProblem");
		} catch (Exception e) {
			logger.info("data exception");
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("dispIMAdminDetails " + SCFUConstants.METHOD_ENDS);
		return sqlQueryResult;
	}

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
}
