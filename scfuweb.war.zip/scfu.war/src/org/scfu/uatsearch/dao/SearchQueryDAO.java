package org.scfu.uatsearch.dao;

import java.util.List;
import java.util.Map;


public interface SearchQueryDAO {

	List searchQuery(Map inParams);
	
}
