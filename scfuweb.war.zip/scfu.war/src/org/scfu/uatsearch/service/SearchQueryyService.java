package org.scfu.uatsearch.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.uatsearch.dao.SearchQueryDAO;

public class SearchQueryyService {
	protected final Logger logger = Logger.getLogger(getClass());
	private SearchQueryDAO searchQueryDAO;
	public Map execute(Map inParams) {
		logger.info("execute() " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		Map outParams = new HashMap();
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {
			logger.info("inParams:" + inParams);
			List resultQuery =searchQueryDAO.searchQuery(inParams);
			outParams.put("resultQueryDetails", resultQuery);
			response.setErrorStatus(SCFUConstants.SUCCESS);
		} catch (DAOException e) {
			logger.info("DAOException Occurred");
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.info("Exception Occurred");
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}
	public void setSearchQueryDAO(SearchQueryDAO searchQueryDAO) {
		this.searchQueryDAO = searchQueryDAO;
	}
	 
	

}
