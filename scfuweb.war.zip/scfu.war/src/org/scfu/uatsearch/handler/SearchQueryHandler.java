package org.scfu.uatsearch.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.uatsearch.service.SearchQueryyService;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

public class SearchQueryHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());
	
	private SearchQueryyService searchQueryyService;
	
	public ModelAndView searchQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("SearchQueryHandler  "+SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession();
		Map inParams = new HashMap();
		Map outParams = new HashMap();
		String query =request.getParameter("name");
		inParams.put("sqlQuery", query);
		System.out.println(":::query :: "+query);
		outParams = searchQueryyService.execute(inParams);
		logger.info("outParams :"+outParams );
		logger.info("SearchQueryHandler  "+SCFUConstants.METHOD_ENDS);
		return new ModelAndView("finalsearchpage", "outParams", outParams);
	}

	public void setSearchQueryyService(SearchQueryyService searchQueryyService) {
		this.searchQueryyService = searchQueryyService;
	}


}
