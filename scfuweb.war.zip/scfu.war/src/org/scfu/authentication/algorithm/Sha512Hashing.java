package org.scfu.authentication.algorithm;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;

public class Sha512Hashing {
	
	protected final Logger logger = Logger.getLogger(getClass());
	

	 public String hashingSHA21(String a,String b){
		logger.info("hashingSHA21"+SCFUConstants.METHOD_BEGINS);
	    	String hashContent="";
	    	try{
	    		MessageDigest md = MessageDigest.getInstance("SHA-512");
	    		md.reset();
	    		md.update(a.getBytes());
	    		md.update(b.getBytes());
	 
	    		byte byteData[] = md.digest();
	    		StringBuffer sb = new StringBuffer();
	    		for (int i = 0; i < byteData.length; i++) {
	    				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	    		}
	    		hashContent= sb.toString();
	    	}catch(NoSuchAlgorithmException nsae){
	    		logger.error("Error Occured while obtaining SHA algorithm: "+nsae.getMessage());
	    		
	    	}
			logger.info("hashingSHA21"+SCFUConstants.METHOD_ENDS);
	        return hashContent;
	    }
	
	 public String hashingSHA2(String plainContent){
	    	String hashContent="";
	    	try{
	    		MessageDigest md = MessageDigest.getInstance("SHA-512");
	    		md.reset();
	    		md.update(plainContent.getBytes());
	 
	    		byte byteData[] = md.digest();
	    		StringBuffer sb = new StringBuffer();
	    		for (int i = 0; i < byteData.length; i++) {
	    				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	    		}
	    		hashContent= sb.toString();
	    	}catch(NoSuchAlgorithmException nsae){
	    		logger.error("Error Occured while obtaining SHA algorithm: "+nsae.getMessage());
	    		
	    	}
	        return hashContent;
	    }
	 
	 
	 
	 public static void main(String[] args) {
		Sha512Hashing sha = new Sha512Hashing();
		String dbstr = sha.dbUserString();
		System.out.println(sha.hashingSHA2(dbstr));
	 }
	 
	 public String dbUserString(){
		 String username = "aruuser1";
		 String password = "a1234567*";
		 String concat = "|";
		 System.out.println("this is test svn");
		 return username + concat + password;
	 }
	 
	 
}
