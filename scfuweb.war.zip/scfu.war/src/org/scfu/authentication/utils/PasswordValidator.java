package org.scfu.authentication.utils;

import org.scfu.authentication.algorithm.Sha512Hashing;

public class PasswordValidator {

	private Sha512Hashing sha512Hashing;

	public boolean validateHashSHA2(String hashContent, String string1,
			String string2, String type) {
		boolean validation = false;
		String plainContent = string1 + type + string2;
		if (hashContent.equals(sha512Hashing.hashingSHA2(plainContent)))
			validation = true;
		return validation;
	}

	// hashContent1=complete hashing string,hashContent2=password hashing string along with randomstring
	public boolean validateHashSHA2(String hashContent1, String hashContent2) {
		boolean validation = false;
		if (hashContent1.equals(sha512Hashing.hashingSHA2(hashContent2)))
			validation = true;
		return validation;
	}

	public void setSha512Hashing(Sha512Hashing sha512Hashing) {
		this.sha512Hashing = sha512Hashing;
	}

}
