package org.scfu.vf.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.DAOException;
import org.scfu.vf.model.ReverseFileTransactionDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class GenerateReverseFileDAOImpl implements GenerateReverseFileDAO {

	private Logger logger = Logger.getLogger(getClass());

	private String DISPLAY_IM_FILE_LIST = "SELECT sfm.uploaded_file_name  FILE_NAME,sfm.file_no FILE_NO,"
							+ "TO_CHAR (sfm.creation_time, 'dd/mm/yyyy') creation_date,"
							+ "sfm.file_status FILE_STATUS,sfm.im_code IM_CODE,"
							+ "(SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=sfm.file_no ) total_ref_no_count,"
							+ "(SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=sfm.file_no AND upper(status)='SUCCESS') val_success_cnt,"
							+ "(SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=sfm.file_no AND upper(status)='FAILURE') val_failure_cnt,"
							+ "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=sfm.file_no AND std.current_auth_level='-49') interest_failure,"
							+ "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=sfm.file_no AND std.current_auth_level='50') posting_pending,"
							+ "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=sfm.file_no AND std.current_auth_level='-1' AND std.debit_status is NULL) txn_rejected_cnt,"
							+ "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=sfm.file_no AND std.current_auth_level=0 and std.debit_status='00' AND std.module_name ='VENDOR') txn_success_cnt,"
							+ "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=sfm.file_no AND std.current_auth_level=0 and std.debit_status='ERR.' AND std.module_name ='VENDOR') txn_failed_cnt "
							+ "FROM scfu_file_master sfm where sfm.im_code = ? "
							+ "AND TRUNC (sfm.creation_time) >= TO_DATE( ? , 'dd/mm/yyyy') "
							+ "AND TRUNC (sfm.creation_time) <= TO_DATE( ? , 'dd/mm/yyyy') "
							+ "AND sfm.file_status NOT IN ('Error')"
							+ "order by sfm.creation_time";

	private static final String GETING_FILE_CONFIG_DETAILS = "SELECT field_delimiter FROM SCFU_FILE_CONFIG_MASTER WHERE im_code= ?";

	private static final String GET_TRANSACTION_DETAILS_REVERSE_FILE = "SELECT space1,  invoice_no,  customer_ref_no,  invoice_amount,  vendor_code,  STATUS,  reversal_date,  invoice_date,  uploaded_file_name,  txn_identifier FROM  (SELECT lpad(' ',16,' ') space1,    rpad(svftd.invoice_no,10,' ') invoice_no,    rpad(DECODE(svftp.value,'',' ',svftp.value),13,' ') customer_ref_no,    lpad( trim(to_char(svftd.invoice_amount, '99999999999999999.99')),20,'0') invoice_amount,    rpad(svftd.vendor_code,17,' ') vendor_code,    lpad('ER',11,' ') status,    rpad(TO_CHAR(to_date(svftd.reversal_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') reversal_date,    rpad(TO_CHAR(to_date(svftd.invoice_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') invoice_date,    rpad(sfm.uploaded_file_name,13,' ') uploaded_file_name,    'E' txn_identifier    FROM scfu_vf_file_txn_details svftd,    scfu_file_master sfm,    scfu_vf_file_txn_params svftp,    scfu_vf_vendor_master svvm,    scfu_vf_account_master svam ,    scfu_vf_im_master svim  WHERE sfm.file_type        = 'VENDOR'  AND svftd.file_no          = ?  AND sfm.file_no            = svftd.file_no  AND svftd.vendor_code      = svvm.vendor_code  AND svvm.action           <> 'DELETE'  AND sfm.im_code            = svim.im_code  AND ((svim.status)        <>('INACTIVE')  OR (svim.action)          <> ('DELETE'))  AND svam.account_type      = 'LOAN'  AND svvm.vendor_unique_code= svam.code  AND svftd.status           ='Failure'  AND svftd.reference_no     = svftp.reference_no  AND svftp.field_name(+)    = 'outref31'  AND svftd.transaction_no  IS NULL    UNION ALL    SELECT lpad(' ',16,' ') space1,    rpad(svftd.invoice_no,10,' ') invoice_no,    rpad(DECODE(svftp.value,'',' ',svftp.value),13,' ') customer_ref_no,    lpad( trim(to_char(svftd.invoice_amount, '99999999999999999.99')),20,'0') invoice_amount,    rpad(svftd.vendor_code,17,' ') vendor_code,    lpad(DECODE (sdt.current_auth_level,'0',(DECODE (sdt.debit_status,'00','00','ER')),'-1','ER'),11,' ') status,    rpad(TO_CHAR(to_date(svftd.reversal_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') reversal_date,    rpad(TO_CHAR(to_date(svftd.invoice_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') invoice_date,    rpad(sfm.uploaded_file_name,13,' ') uploaded_file_name,    'E' txn_identifier  FROM scfu_file_master sfm,    scfu_vf_file_txn_details svftd,    scfu_vf_file_txn_params svftp,    scfu_debit_transactions sdt,    scfu_vf_account_master svam,    scfu_vf_vendor_master svvm,    scfu_vf_im_master svim  WHERE sfm.file_type        = 'VENDOR'  AND svftd.file_no          = ?  AND sfm.file_no            = sdt.file_no  AND svftd.transaction_no   = sdt.transaction_no  AND svftd.vendor_code      = svvm.vendor_code  AND svvm.action           <> 'DELETE'  AND sfm.im_code            = svim.im_code  AND ((svim.status)        <>('INACTIVE')  OR (svim.action)          <> ('DELETE'))  AND svam.account_type      = 'LOAN'  AND svvm.vendor_unique_code= svam.code  AND sdt.current_auth_level = '0'  AND sdt.debit_status      IN ('00','ERR.')  AND svvm.action           <> 'DELETE'  AND ((svim.status)        <>('INACTIVE')  OR (svim.action)          <> ('DELETE'))  AND svam.code              = svvm.vendor_unique_code  AND svftd.reference_no     = svftp.reference_no  AND svftp.field_name(+)    = 'outref31'  AND svam.account_type      = 'LOAN'    UNION ALL    SELECT lpad(' ',16,' ') space1,    rpad(svftd.invoice_no,10,' ') invoice_no,    rpad(DECODE(svftp.value,'',' ',svftp.value),13,' ') customer_ref_no,    lpad( trim(to_char(svftd.invoice_amount, '99999999999999999.99')),20,'0') invoice_amount,    rpad(svftd.vendor_code,17,' ') vendor_code,    lpad(DECODE (sdt.current_auth_level,'0',(DECODE (sdt.debit_status,'00','00','ER')),'-1','ER'),11,' ') status,    rpad(TO_CHAR(to_date(svftd.reversal_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') reversal_date,    rpad(TO_CHAR(to_date(svftd.invoice_date,'dd/mm/yyyy'),'yyyy/mm/dd'),10,' ') invoice_date,    rpad(sfm.uploaded_file_name,13,' ') uploaded_file_name,    'E' txn_identifier  FROM scfu_file_master sfm,    scfu_vf_file_txn_details svftd,    scfu_vf_file_txn_params svftp,    scfu_debit_transactions sdt,    scfu_vf_vendor_master svvm,    scfu_vf_account_master svam ,    scfu_vf_im_master svim  WHERE sfm.file_type        = 'VENDOR'  AND svftd.file_no          = ?  AND sfm.file_no            = svftd.file_no  AND svftd.transaction_no   = sdt.transaction_no  AND svftd.im_code          = svim.im_code  AND svvm.action           <> 'DELETE'  AND ((svim.status)        <>('INACTIVE')  OR (svim.action)          <> ('DELETE'))  AND sfm.im_code            = svim.im_code  AND sdt.current_auth_level = '-1'  AND svvm.vendor_unique_code= svam.code  AND svftd.reference_no     = svftp.reference_no  AND svftp.field_name(+)    = 'outref31'  AND svam.account_type      = 'LOAN'  )GROUP BY space1,  invoice_no,  customer_ref_no,  invoice_amount,  vendor_code,  STATUS,  reversal_date,  invoice_date,  uploaded_file_name,  txn_identifier";

	private static final String GET_IM_NAME = "SELECT name FROM scfu_vf_im_master WHERE im_code= ? ";
	
	private JdbcTemplate jdbcTemplate;

	public Map<String, Object> displayIMFileList(String imCode, String fromDate, String toDate) {
		logger.info("displayIMFileList " + SCFUConstants.METHOD_BEGINS);
		List list = null;
		Map<String, Object> map = new HashMap<String, Object>();
		int valFailureCount = 0;
		int txnRejectedCount = 0;
		int postingSuccessCount = 0;
		int postingFailureCount = 0;
		int interestFailureCount = 0;
		int totalRefNoCount = 0;
		boolean sumCheck;

		logger.info("imCode : " + imCode + "fromDate : " + fromDate + "toDate : " + toDate);
		Object[] params = new Object[] { imCode, fromDate, toDate };

		try {
			list = jdbcTemplate.queryForList(DISPLAY_IM_FILE_LIST, params);
			logger.info("DISPLAY_IM_FILE_LIST:" + DISPLAY_IM_FILE_LIST);

			for (int i = 0; i < list.size(); i++) {
				logger.info("list.size : " + list.size());
				totalRefNoCount = ((BigDecimal) (((Map) list.get(i)).get("total_ref_no_count"))).intValue();
				valFailureCount = ((BigDecimal) (((Map) list.get(i)).get("val_failure_cnt"))).intValue();
				txnRejectedCount = ((BigDecimal) (((Map) list.get(i)).get("txn_rejected_cnt"))).intValue();
				postingSuccessCount = ((BigDecimal) (((Map) list.get(i)).get("txn_success_cnt"))).intValue();
				postingFailureCount = ((BigDecimal) (((Map) list.get(i)).get("txn_failed_cnt"))).intValue();
				interestFailureCount = ((BigDecimal) (((Map) list.get(i)).get("interest_failure"))).intValue();

				sumCheck = getSumCheck(totalRefNoCount, valFailureCount,postingSuccessCount, postingFailureCount, txnRejectedCount, interestFailureCount);
				map.put("sumCheck" + i, sumCheck);
				map.put("list", list);
			}
		} catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : "+ dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("displayIMFileList " + SCFUConstants.METHOD_ENDS);
		return map;
	}

	public boolean getSumCheck(Integer totalRefNoCount, Integer valFailureCount, Integer postingSuccessCount,
			Integer postingFailureCount, Integer txnRejectedCount, Integer interestFailureCount) {
		logger.info("getSumCheck " + SCFUConstants.METHOD_BEGINS);
		Integer sumValue = valFailureCount + postingSuccessCount + postingFailureCount + txnRejectedCount + interestFailureCount;
		logger.info("sumValue : " + sumValue + " valFailureCount : "
				+ valFailureCount + " postingSuccessCount : "
				+ postingSuccessCount + " postingFailureCount : "
				+ postingFailureCount + " txnRejectedCount : "
				+ txnRejectedCount + " interestFailureCount : "
				+ interestFailureCount);
		if (sumValue > 0) {
			if (totalRefNoCount == sumValue) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public String getFileConfigDetails(String imCode) {
		logger.info("getFileConfigDetails " + SCFUConstants.METHOD_BEGINS);
		String fieldDelimter = null;
		Object[] params = new Object[] { imCode };
		try {
			fieldDelimter = (String) jdbcTemplate.queryForObject(GETING_FILE_CONFIG_DETAILS, params, String.class);
			logger.info("fieldDelimter" + fieldDelimter);
		} catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : "+ dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("getFileConfigDetails " + SCFUConstants.METHOD_ENDS);
		return fieldDelimter;
	}

	public List<ReverseFileTransactionDetails> findTransactionDetailsReverseFile(Map inParams) {
		String fileNo = (String) inParams.get("fileNo");
		logger.info("findTransactionDetails for Reverse File(String fileNo ="+ fileNo + " ) " + SCFUConstants.METHOD_BEGINS);
		Object[] params = new Object[] { fileNo, fileNo, fileNo };
		List<ReverseFileTransactionDetails> transactionDetails = null;
		try {
			transactionDetails = jdbcTemplate.query(GET_TRANSACTION_DETAILS_REVERSE_FILE, params, new GenereateReverseFileMapper());
			logger.info("GET_TRANSACTION_DETAILS_REVERSE_FILE:"+ GET_TRANSACTION_DETAILS_REVERSE_FILE);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured : "+ dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("findTransactionDetailsReverseFile "+ SCFUConstants.METHOD_ENDS);
		return transactionDetails;
	}

	public String getimName(String imCode) {
		logger.info("getimName " + SCFUConstants.METHOD_BEGINS);
		Object[] params = new Object[] { imCode };
		String imName = null;
		try {
			logger.info("imCode : " + imCode);
			imName = (String) jdbcTemplate.queryForObject(GET_IM_NAME, params,String.class);
			logger.info("IM NAME : " + imName);
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : "+ dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("getimName " + SCFUConstants.METHOD_ENDS);
		return imName;
	}
	

	public class GenereateReverseFileMapper implements RowMapper {
		public Object mapRow(ResultSet resultSet, int count)throws SQLException {
			logger.info("GenerreateReverseFileMapper Starts");
			ReverseFileTransactionDetails reverseFileTransactionDetails = new ReverseFileTransactionDetails();
			reverseFileTransactionDetails.setSpace(resultSet.getString("space1"));
			reverseFileTransactionDetails.setInvoiceNumber(resultSet.getString("invoice_no"));
			reverseFileTransactionDetails.setCustomerRefNo(resultSet.getString("customer_ref_no"));
			reverseFileTransactionDetails.setInvoiceAmt(resultSet.getString("invoice_amount"));
			reverseFileTransactionDetails.setVendorCode(resultSet.getString("vendor_code"));
			reverseFileTransactionDetails.setStatus(resultSet.getString("status"));
			reverseFileTransactionDetails.setReversalDate(resultSet.getString("reversal_date"));
			reverseFileTransactionDetails.setInvoiceDate(resultSet.getString("invoice_date"));
			reverseFileTransactionDetails.setUploadedFileName(resultSet.getString("uploaded_file_name"));
			reverseFileTransactionDetails.setTxnIdentifier(resultSet.getString("txn_identifier"));
			logger.info("GenerreateReverseFileMapper Ends");
			return reverseFileTransactionDetails;
		}
	}
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
}
