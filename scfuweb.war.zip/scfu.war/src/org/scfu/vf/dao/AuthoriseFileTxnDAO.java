package org.scfu.vf.dao;

import java.util.List;
import java.util.Map;

import org.scfu.vf.model.AuthFileDisplayModel;
import org.scfu.vf.model.SlabDetails;

@SuppressWarnings({"rawtypes"})
public interface AuthoriseFileTxnDAO {

	List findIMList(String userName, String imCode);

	List viewTxnFileDetails(String fileNo, String userName);

	Map viewTxnCountDetails(String fileNo);

	void updateCurrentAuthLevel(String echequeNo, Integer current_auth_level,String userName, String imCode);

	void updateAuthDetails(String echequeNo, Integer current_auth_level, String auth_name);

	Integer getCurrentAuthLevel(String echequeNo, String authlevel, String userName);

	List fileUploaderDetails(String fileNo);

	AuthFileDisplayModel findTxnValidationDetails(String transactionNo);

	SlabDetails findOverridDetails(String Code, String vendorCode, String status);

	String getReversalBasedOn(String imCode);

	void updateValidationFailureStatus(String echequeNo);

	void updateRejectionCurrentAuthLevel(String echequeNo, Integer currentAuthLevel, String rejectreason);
		
}
