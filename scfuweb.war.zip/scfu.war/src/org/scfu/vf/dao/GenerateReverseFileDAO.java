package org.scfu.vf.dao;

import java.util.List;
import java.util.Map;
@SuppressWarnings({"rawtypes"})
public interface GenerateReverseFileDAO {
	
	Map displayIMFileList(String imCode,String fromDate,String toDate);
	String getFileConfigDetails(String imCode);
	List findTransactionDetailsReverseFile(Map inParams);
	String getimName(String imCode);
}
