package org.scfu.vf.dao;
import java.util.Map;
@SuppressWarnings({"rawtypes"})
public interface UploadFileDAO {
	Integer insertScfuFileMaster(Map params);
	Integer getNextNumberFromSequenceFile();
}
