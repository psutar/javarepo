package org.scfu.vf.dao;
import java.util.List;
@SuppressWarnings({"rawtypes"})
public interface ReportDAO {
	List vendorListReport(String imCode);
	List principleVendorReport(String vendorCode, String txn_type,String imCode);
	List interestVendorReport(String vendorCode, String txn_type,String imCode);
	List reverseVendorReport(String vendorCode, String txn_type,String imCode);
	List limitVendorReport(String vendorCode, String txn_type,String imCode);
	List limitIMReport(String vendorCode, String txn_type);
	List overdueVendorReport(String vendorCode, String txn_type,String imCode);
	boolean checkVendorDetails(String vendorCode,String vendorName);
}
