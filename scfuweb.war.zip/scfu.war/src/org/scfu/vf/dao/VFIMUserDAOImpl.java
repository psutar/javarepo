/**
 * @author Prateek
 *	This DAO is used for writing and retrieving data from/to db related to all the IM registration for a new user.
 */
package org.scfu.vf.dao;

import java.sql.Types;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.jdbc.core.JdbcTemplate;

@SuppressWarnings({"rawtypes"})
public class VFIMUserDAOImpl implements VFIMUserDAO {

	private static final String INSERT_VF_IM_MASTER1 = "insert into scfu_user_profile(user_id,name,nick_name,email,address1,address2,city,zip,district,state,country,phone_no,mobile_no,creation_time,last_mod_time,created_by) values(?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,sysdate,?)";
	private static final String INSERT_VF_IM_MASTER2 = "insert into scfu_user_details(user_id,user_role,login_failure_count,login_count,code,old_login_id,first_time_password) values(?,?,?,?,?,?,?)";
	private static final String INSERT_VF_IM_MASTER3 = "insert into scfu_user values(?,?,?,?)";
	private static final String GENERATE_UNIQUE_ID = "select seq_user_id.nextval from dual";
	private static final String GENERATE_UNIQUE_ID2 = "select seq_user_id.currval from dual";

	protected final Logger logger = Logger.getLogger(getClass());
	private JdbcTemplate jdbcTemplate;

	public boolean addVFIMUser(final Map inParams) {
		boolean status = false;
		logger.info("addVFIMUser " + SCFUConstants.METHOD_BEGINS);
		try {
			String refNo = (String) jdbcTemplate.queryForObject(GENERATE_UNIQUE_ID, String.class);
			logger.info("Temp reference Number NEXT VAL : " + refNo);
			logger.info("imDetails " + inParams);
			logger.info(inParams.get("name") + "~" + inParams.get("nickname")
					+ "~" + inParams.get("address") + "~"
					+ inParams.get("address2") + "~" + inParams.get("state")
					+ "~" + inParams.get("city") + "~"
					+ inParams.get("pincode") + "~" + inParams.get("country")
					+ "~" + inParams.get("phone") + "~"
					+ inParams.get("mobile") + "~" + inParams.get("district")
					+ "~" + inParams.get("email") + inParams.get("userName"));

			Object[] params = { refNo, inParams.get("name"),
					inParams.get("nickname"), inParams.get("email"),
					inParams.get("address"), inParams.get("address2"),
					inParams.get("city"), inParams.get("pincode"),
					inParams.get("district"), inParams.get("state"),
					inParams.get("country"), inParams.get("phone"),
					inParams.get("mobile"), inParams.get("userName") };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };

			logger.info("Before insert  " + INSERT_VF_IM_MASTER1);
			int count = jdbcTemplate.update(INSERT_VF_IM_MASTER1, params, sqlTypes);
			logger.info("count:" + count);

			if (count == 1) {
				status = true;
			} else {
				logger.error("Error Occured : ");
				DAOException.throwException("recNotCreated");
			}

		} catch (Exception e) {
			logger.error("Error Occured : " + e);
			DAOException.throwException("TechnicalProblem");
		}

		logger.info("addVFIMUser " + SCFUConstants.METHOD_ENDS);
		return status;
	}

	public boolean insertSCFUUserDetails(Map inParams) {
		logger.info("insertSCFUUserDetails " + SCFUConstants.METHOD_BEGINS);
		try {
			String refNo = (String) jdbcTemplate.queryForObject(GENERATE_UNIQUE_ID2, String.class);
			logger.info(inParams.get("type") + "~" + inParams.get("imcode"));
			Object[] params = { refNo, inParams.get("type"), 0, 0, inParams.get("imcode"), inParams.get("login_id"), inParams.get("password") };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
			logger.info("Before insert  " + INSERT_VF_IM_MASTER2);
			int count = jdbcTemplate.update(INSERT_VF_IM_MASTER2, params, sqlTypes);
			logger.info("insertSCFUUserDetails count :" + count);
			if (count == 0) {
				DAOException.throwException("recNotCreated");
			}
		} catch (Exception e) {
			logger.error("Error Occured : " + e);
		}
		logger.info("insertSCFUUserDetails " + SCFUConstants.METHOD_ENDS);
		return true;
	}

	public boolean insertSCFUUser(Map inParams) {
		logger.info("insertSCFUUser " + SCFUConstants.METHOD_BEGINS);
		try {
			String refNo = (String) jdbcTemplate.queryForObject(GENERATE_UNIQUE_ID2, String.class);
			logger.info("Temp reference Number : " + refNo);
			logger.info("imDetails " + inParams);
			logger.info(inParams.get("login_id") + " ~"+ inParams.get("pwdencr"));
			Object[] params = { refNo, inParams.get("login_id"), inParams.get("pwdencr"), 1 };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER };
			logger.info("Before insert  " + INSERT_VF_IM_MASTER3);
			int count = jdbcTemplate.update(INSERT_VF_IM_MASTER3, params, sqlTypes);
			logger.info("insertSCFUUser count:" + count);
			if (count == 0) {
				DAOException.throwException("recNotCreated");
			}
		} catch (Exception e) {
			logger.error("Error Occured : " + e.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("insertSCFUUser " + SCFUConstants.METHOD_ENDS);
		return true;
	}

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
}
