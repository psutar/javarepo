package org.scfu.vf.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.VendorReportDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
@SuppressWarnings({"rawtypes"})
public class ReportDAOImpl implements ReportDAO
{
    protected Logger logger = Logger.getLogger(getClass());

    public final static String GET_VENDOR_LIST= "select vendor_unique_code,name,im_code from SCFU_VF_VENDOR_MASTER where  IM_CODE=? and action <>'DELETE'";
    public final static String GET_VENDOR_DETAIL_LIST="SELECT svth.reference_no,  svvm.vendor_code,  svvm.name,  svth.transaction_amount amount,  svth.status,  NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time,  NVL(TO_CHAR(svth.reversal_date,'dd/mm/yyyy'),'--') reversal_date,  NVL(svth1.reference_no,'--') interest_ref_no,  NVL(svth2.reference_no,'--') reversal_ref_no,  NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') transaction_date,  svftd.invoice_no,  svftd.invoice_date,  svftd.file_no,  sct.credit_account_no,  sdt.account_no FROM scfu_vf_txn_history svth,  scfu_vf_txn_history svth1,  scfu_vf_txn_history svth2,  scfu_vf_vendor_master svvm ,  scfu_debit_transactions sdt,  scfu_vf_file_txn_details svftd,  scfu_credit_transactions sct WHERE svth.vendor_unique_id   = svvm.vendor_unique_code AND svvm.action              <> 'DELETE' AND svth.status              != 'REJECTED' AND svth.original_parent      = svth1.original_parent (+) AND svth1.txn_type (+)        ='INTEREST_TXN' AND svth2.original_parent (+) =svth.original_parent AND svth2.txn_type (+)        ='REVERSE_TXN' AND svth.reference_no         = sdt.transaction_no AND sdt.transaction_no       = svftd.transaction_no AND sdt.transaction_no       = sct.debit_transaction_no  AND sdt.debit_status = '00' AND svvm.vendor_unique_code   =? AND svth.txn_type             =? AND svth.im_code              =? ORDER BY svth.creation_time DESC";
    public final static String INTEREST_VENDOR_REPORT_LIST="SELECT svth.reference_no, svvm.name name, svvm.vendor_code vendor_code, svth.transaction_amount interest_amount,svth1.transaction_amount principal_amount, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time, NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') txn_completed_time, svth.status, NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, svth1.reference_no org_debit_ref_no, NVL(svth2.reference_no,'--') REVERSAL_REF_NO, svftd.invoice_no, svftd.invoice_date, sct.credit_account_no, sdt.account_no FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2, scfu_debit_transactions sdt, scfu_vf_vendor_master svvm, scfu_vf_file_txn_details svftd, scfu_credit_transactions sct WHERE svth.reference_no    = sdt.transaction_no AND svvm.action           <> 'DELETE' AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth1.txn_type (+)     ='PRINCIPAL_TXN' AND svth.original_parent   =svth1.original_parent(+) AND svth2.txn_type (+)     ='REVERSE_TXN' AND svth.original_parent   =svth2.original_parent(+) AND svth.original_parent   =svftd.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.vendor_unique_id  =? AND svth.txn_type          =? AND svth.im_code           =? ORDER BY svth.creation_time DESC"; 
    public final static String REVERSE_VENDOR_REPORT_LIST="SELECT svth.reference_no, svth.transaction_amount, svvm.name name, svvm.vendor_code vendor_code, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time, NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') transaction_date, NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, svth.status, svth1.reference_no org_debit_ref_no, svth2.reference_no interest_ref_no,  svftd.invoice_no, svftd.invoice_date, sct.credit_account_no, sdt.account_no FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2 , scfu_vf_vendor_master svvm, scfu_debit_transactions sdt, scfu_vf_file_txn_details svftd, scfu_credit_transactions sct WHERE svth1.txn_type       ='PRINCIPAL_TXN' AND svvm.action           <> 'DELETE' AND svth.original_parent   =svth1.original_parent AND svth2.txn_type         ='INTEREST_TXN' AND svth.original_parent   =svth2.original_parent AND svth.vendor_unique_id  =? AND svth.txn_type =? AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth.reference_no      = sdt.transaction_no AND svth.original_parent   =svftd.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.im_code=? ORDER BY svvm.name,svth.creation_time DESC";
    public final static String CHECK_VENDOR_DETAILS="select count(*) from scfu_vf_vendor_master where vendor_unique_code=? and name=?";
    public final static String OVERDUE_VENDOR_REPORT_LIST="SELECT svth.reference_no overdue_ref_no, svth.transaction_amount overdue_amount, svvm.vendor_code vendor_code,svvm.name name, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') overdue_creation_date, NVL(TO_CHAR(sdt1.txn_completed_time,'dd/mm/yyyy'),'--') txn_completed_time, NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, trunc(sdt1.txn_completed_time- svth1.reversal_date) no_of_days, svth1.reference_no org_debit_ref_no, svth1.transaction_amount principal_amount, svth2.reference_no interest_ref_no, svth2.transaction_amount interest_amount, svth3.reference_no reversal_ref_no,  sct.credit_account_no, sdt.account_no,svth.status FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2,scfu_vf_txn_history svth3, scfu_vf_vendor_master svvm, scfu_debit_transactions sdt, scfu_debit_transactions sdt1, scfu_credit_transactions sct WHERE svth1.txn_type       ='PRINCIPAL_TXN' AND svvm.action           <> 'DELETE' AND svth.original_parent   =svth1.original_parent AND svth2.txn_type         ='INTEREST_TXN' AND svth.original_parent   =svth2.original_parent AND svth3.txn_type         ='REVERSE_TXN' AND sdt1.transaction_no=svth3.reference_no AND svth.original_parent   =svth3.original_parent AND svth.vendor_unique_id  =? AND svth.txn_type          =? AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth.reference_no      = sdt.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.im_code =? ORDER BY svvm.name,svth.creation_time DESC";
    
    
    public final static String LIMIT_VENDOR_REPORT_LIST= "SELECT svvm.vendor_code vendor_code, svvm.name name, svvm.limit allocated_limit, nvl(SUM(svth.transaction_amount),0) outstanding_limit, nvl(svvm.limit-nvl(SUM(svth.transaction_amount),0),0) available_limit, NVL(TO_CHAR(svvm.limit_expiry_date,'dd/mm/yyyy'),'--') limit_expiry_date FROM scfu_vf_vendor_master svvm,scfu_vf_txn_history svth WHERE svvm.vendor_unique_code=? AND svvm.action <> 'DELETE' AND svvm.im_code =? AND svvm.im_code = svth.im_code(+) AND svvm.vendor_unique_code = svth.vendor_unique_id(+) AND svth.txn_type (+)='REVERSE_TXN' AND svth.status (+)='PENDING' group by vendor_code,name,limit,limit_expiry_date";

    
    public final static String LIMIT_IM_REPORT_LIST=" SELECT svim.im_code, svim.name, svim.limit allocated_limit, NVL(SUM(svth1.transaction_amount),0) outstanding_limit, (svim.limit- NVL(SUM(svth1.transaction_amount),0)) available_limit, NVL(TO_CHAR(svim.limit_expiry_date,'dd/mm/yyyy'),'--') limit_expiry_date FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_im_master svim WHERE svim.im_code = svth.im_code(+) AND svth.reference_no =svth1.original_parent(+) AND svth.txn_type (+) ='PRINCIPAL_TXN' AND svth1.txn_type (+) ='REVERSE_TXN' AND svth1.status (+) ='PENDING' AND svim.im_code =? GROUP BY svim.im_code, svim.name, svim.limit, svim.limit_expiry_date"; 

    
    
   
    public final static String GET_ALL_VENDOR_DETAIL_LIST_PRINCIPAL= "SELECT svth.reference_no,  svvm.vendor_code,  svvm.name,  svth.transaction_amount amount,  svth.status,  NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time,  NVL(TO_CHAR(svth.reversal_date,'dd/mm/yyyy'),'--') reversal_date,  NVL(svth1.reference_no,'--') interest_ref_no,  NVL(svth2.reference_no,'--') reversal_ref_no,  NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') transaction_date,  svftd.invoice_no,  svftd.invoice_date,  svftd.file_no,  sct.credit_account_no,  sdt.account_no FROM scfu_vf_txn_history svth,  scfu_vf_txn_history svth1,  scfu_vf_txn_history svth2,  scfu_vf_vendor_master svvm,  scfu_debit_transactions sdt,  scfu_vf_file_txn_details svftd,  scfu_credit_transactions sct WHERE svth.vendor_unique_id = svvm.vendor_unique_code AND svvm.action            <> 'DELETE' AND svth.original_parent    =svth1.original_parent (+) AND svth1.txn_type(+)       ='INTEREST_TXN' AND svth2.original_parent(+)=svth.original_parent AND svth2.txn_type(+)       ='REVERSE_TXN' AND svth.reference_no       = sdt.transaction_no AND sdt.transaction_no       = svftd.transaction_no AND sdt.transaction_no       = sct.debit_transaction_no AND sdt.debit_status = '00' AND svth.txn_type           = ? AND svth.im_code            = ? AND svth.status            != 'REJECTED' ORDER BY svvm.name,  svth.creation_time DESC";

    public final static String GET_ALL_VENDOR_DETAIL_LIST_INTEREST="SELECT svth.reference_no, svvm.name name, svvm.vendor_code vendor_code, svth.transaction_amount interest_amount,svth1.transaction_amount principal_amount, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time, NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') txn_completed_time, svth.status,NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, svth1.reference_no org_debit_ref_no, NVL(svth2.reference_no,'--') REVERSAL_REF_NO, svftd.invoice_no, svftd.invoice_date, sct.credit_account_no, sdt.account_no FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2, scfu_debit_transactions sdt, scfu_vf_vendor_master svvm, scfu_vf_file_txn_details svftd, scfu_credit_transactions sct WHERE svth.reference_no    = sdt.transaction_no AND svvm.action           <> 'DELETE' AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth1.txn_type (+)     ='PRINCIPAL_TXN' AND svth.original_parent   =svth1.original_parent(+) AND svth2.txn_type (+)     ='REVERSE_TXN' AND svth.original_parent   =svth2.original_parent(+) AND svth.original_parent   =svftd.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.txn_type          =? AND svth.im_code           =? ORDER BY svth.creation_time DESC"; 
    
    
    public final static String GET_ALL_VENDOR_DETAIL_LIST_REVERSE="SELECT svth.reference_no, svth.transaction_amount, svvm.name name, svvm.vendor_code vendor_code, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') creation_time, NVL(TO_CHAR(sdt.txn_completed_time,'dd/mm/yyyy'),'--') transaction_date, NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, svth.status, svth1.reference_no org_debit_ref_no, svth2.reference_no interest_ref_no,  svftd.invoice_no, svftd.invoice_date, sct.credit_account_no, sdt.account_no FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2 , scfu_vf_vendor_master svvm, scfu_debit_transactions sdt, scfu_vf_file_txn_details svftd, scfu_credit_transactions sct WHERE svth1.txn_type       ='PRINCIPAL_TXN' AND svvm.action           <> 'DELETE' AND svth.original_parent   =svth1.original_parent AND svth2.txn_type         ='INTEREST_TXN' AND svth.original_parent   =svth2.original_parent AND svth.txn_type =? AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth.reference_no      = sdt.transaction_no AND svth.original_parent   =svftd.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.im_code=? ORDER BY svvm.name,svth.creation_time DESC";

    
    public final static String GET_ALL_VENDOR_DETAIL_LIST_OVERDUE="SELECT svth.reference_no overdue_ref_no, svth.transaction_amount overdue_amount, svvm.vendor_code vendor_code,svvm.name name, NVL(TO_CHAR(svth.creation_time,'dd/mm/yyyy'),'--') overdue_creation_date, NVL(TO_CHAR(sdt1.txn_completed_time,'dd/mm/yyyy'),'--') txn_completed_time, NVL(TO_CHAR(svth1.reversal_date,'dd/mm/yyyy'),'--') reversal_date, trunc(sdt1.txn_completed_time- svth1.reversal_date) no_of_days, svth1.reference_no org_debit_ref_no, svth1.transaction_amount principal_amount, svth2.reference_no interest_ref_no, svth2.transaction_amount interest_amount, svth3.reference_no reversal_ref_no,  sct.credit_account_no, sdt.account_no, svth.status FROM scfu_vf_txn_history svth, scfu_vf_txn_history svth1, scfu_vf_txn_history svth2,scfu_vf_txn_history svth3, scfu_vf_vendor_master svvm, scfu_debit_transactions sdt,scfu_debit_transactions sdt1, scfu_credit_transactions sct WHERE svth1.txn_type       ='PRINCIPAL_TXN' AND svvm.action           <> 'DELETE' AND svth.original_parent   =svth1.original_parent AND svth2.txn_type         ='INTEREST_TXN' AND svth.original_parent   =svth2.original_parent AND svth3.txn_type         ='REVERSE_TXN' AND sdt1.transaction_no=svth3.reference_no AND svth.original_parent   =svth3.original_parent AND svth.txn_type          =? AND svvm.vendor_unique_code= svth.vendor_unique_id AND svth.reference_no      = sdt.transaction_no AND sdt.transaction_no     = sct.debit_transaction_no AND svth.im_code =? ORDER BY svvm.name,svth.creation_time DESC";
   
    
    public final static String GET_ALL_VENDOR_DETAIL_LIST_LIMIT="SELECT svvm.vendor_code vendor_code, svvm.name name, svvm.limit allocated_limit, NVL(SUM(svth.transaction_amount),0) outstanding_limit, NVL(svvm.limit-NVL(SUM(svth.transaction_amount),0),0) available_limit, NVL(TO_CHAR(svvm.limit_expiry_date,'dd/mm/yyyy'),'--') limit_expiry_date FROM scfu_vf_vendor_master svvm, scfu_vf_txn_history svth WHERE svvm.im_code =? AND svvm.action <> 'DELETE' AND svvm.im_code = svth.im_code(+) AND svvm.vendor_unique_code = svth.vendor_unique_id(+) AND svth.txn_type (+) ='REVERSE_TXN' AND svth.status (+) ='PENDING' GROUP BY vendor_code, name, limit, limit_expiry_date  order by name";

    private JdbcTemplate jdbcTemplate;
    


    
  	@Override
  	public List vendorListReport(String imCode)throws DAOException {
  		logger.info("vendorListReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" Input query params :" + imCode);
  		List list = null;
  		if (imCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("im_code = "+imCode);
  			Object[] params = new Object[] { imCode};
  			try {
  				list = jdbcTemplate.queryForList(GET_VENDOR_LIST,params);
  				logger.info("list size :"+list.size()+"    ,GET_FILE_DETAILS:"+GET_VENDOR_LIST);
  			} 
  			catch (DataAccessException dataAccessException) {
  				logger.error("Exception occured : " + dataAccessException.getMessage());
  			}
  			logger.info("findFileDetails"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}
  	/**/
  	public List principleVendorReport(String vendorCode,String txn_type,String imCode)throws DAOException {
  		logger.info("principleVendorReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in principleVendorReport block :" + txn_type);
  		logger.info(" Input query params :" + vendorCode+"|"+txn_type);
  		List list = null;
  		if (vendorCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("vendorCode="+vendorCode);
  			if (vendorCode.equalsIgnoreCase("VDRALL")){
  				logger.info("Principal report for all vendors:");
  				Object[] params = new Object[] {txn_type,imCode};
  				try {
  					list = jdbcTemplate.query(GET_ALL_VENDOR_DETAIL_LIST_PRINCIPAL,params,new ReportMapper());
  					logger.info("vendor code for ALL:"+vendorCode);
  					logger.info("list size "+list.size()+"    ,GET_ALL_VENDOR_DETAIL_LIST_PRINCIPAL:"+GET_ALL_VENDOR_DETAIL_LIST_PRINCIPAL);
  					logger.info("List From query"+list);
  					
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			else if (vendorCode!="VDRALL"){
  				logger.info("for specific vendor code:"+vendorCode);
  				Object[] params = new Object[] {vendorCode,txn_type,imCode};

  				try {
  					list = jdbcTemplate.query(GET_VENDOR_DETAIL_LIST,params,new ReportMapper());
  					logger.info("list size "+list.size()+"    ,GET_VENDOR_DETAIL_LIST:"+GET_VENDOR_DETAIL_LIST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  					DAOException.throwException("TechnicalProblem");
  				}
  			}
  			logger.info("findVendorDetails"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}

  	@Override
  	public List interestVendorReport(String vendorCode, String txn_type,String imCode) {
  		logger.info("interestVendorReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in findVendorDetails block :" + txn_type);
  		logger.info(" Input query params :" + vendorCode+txn_type);
  		List list = null;

  		if (vendorCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("vendorCode="+vendorCode);
  			if (vendorCode.equalsIgnoreCase("VDRALL")){
  				Object[] params = new Object[] {txn_type,imCode};
  				try {
  					list = jdbcTemplate.query(GET_ALL_VENDOR_DETAIL_LIST_INTEREST,params,new IntrestReportMapper());
  					logger.info("vendor code for ALL:"+vendorCode);
  					logger.info("list size "+list.size()+"    ,GET_ALL_VENDOR_DETAIL_LIST_INTEREST:"+GET_ALL_VENDOR_DETAIL_LIST_INTEREST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			else if (vendorCode!="VDRALL"){
  				logger.info("for specific vendor code:"+vendorCode+"  "+txn_type);
  				Object[] params = new Object[] {vendorCode,txn_type,imCode};

  				try {
  					list = jdbcTemplate.query(INTEREST_VENDOR_REPORT_LIST,params,new IntrestReportMapper());
  					logger.info("list size "+list.size()+"    ,INTEREST_VENDOR_REPORT_LIST:"+INTEREST_VENDOR_REPORT_LIST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  					DAOException.throwException("TechnicalProblem");
  				}
  			}
  			logger.info("interestVendorReport"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}


  	@Override
  	public List reverseVendorReport(String vendorCode, String txn_type,String imCode) {
  		logger.info("reverseVendorReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in findVendorDetails block :" + txn_type);
  		logger.info(" Input query params :" + vendorCode+txn_type);
  		List list = null;

  		if (vendorCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("vendorCode="+vendorCode);
  			if (vendorCode.equalsIgnoreCase("VDRALL")){
  				Object[] params = new Object[] {txn_type,imCode};
  				try {
  					list = jdbcTemplate.query(GET_ALL_VENDOR_DETAIL_LIST_REVERSE,params,new ReverseReportMapper());
  					logger.info("vendor code for ALL:"+vendorCode);
  					logger.info("list size "+list.size()+"    ,GET_ALL_VENDOR_DETAIL_LIST_REVERSE:"+GET_ALL_VENDOR_DETAIL_LIST_REVERSE);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			else if (vendorCode!="VDRALL"){
  				logger.info("for specific vendor code:"+vendorCode+"  "+txn_type);
  				Object[] params = new Object[] {vendorCode,txn_type,imCode};

  				try {
  					list = jdbcTemplate.query(REVERSE_VENDOR_REPORT_LIST,params,new ReverseReportMapper());
  					logger.info("list size "+list.size()+"    ,REVERSE_VENDOR_REPORT_LIST:"+REVERSE_VENDOR_REPORT_LIST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			logger.info("reverseVendorReport"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}

  	public List limitVendorReport(String vendorCode, String txn_type,String imCode) {
  		logger.info("limitVendorReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in findVendorDetails block :" + txn_type);
  		logger.info(" Input query params :" + vendorCode+txn_type);
  		List list = null;

  		if (vendorCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("vendorCode="+vendorCode);
  			if (vendorCode.equalsIgnoreCase("VDRALL")){
  				Object[] params = new Object[] {imCode};
  				try {
  					list = jdbcTemplate.query(GET_ALL_VENDOR_DETAIL_LIST_LIMIT,params,new LimitReportMapper());
  					logger.info("vendor code for ALL:"+vendorCode);
  					logger.info("list size "+list.size()+"    ,GET_ALL_VENDOR_DETAIL_LIST_LIMIT:"+GET_ALL_VENDOR_DETAIL_LIST_LIMIT);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			else if (vendorCode!="VDRALL"){
  				logger.info("for specific vendor code:"+vendorCode+"  "+txn_type);
  				Object[] params = new Object[] {vendorCode,imCode};

  				try {
  					list = jdbcTemplate.query(LIMIT_VENDOR_REPORT_LIST,params,new LimitReportMapper());
  					logger.info("list size "+list.size()+"    ,LIMIT_VENDOR_REPORT_LIST:"+LIMIT_VENDOR_REPORT_LIST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			logger.info("limitVendorReport"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}

  	@Override
  	public List limitIMReport(String imCode, String txn_type) {
  		logger.info("limitIMReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in findVendorDetails block :" + txn_type);
  		logger.info(" Input query params :" + imCode+txn_type);
  		List list = null;

  		if (imCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("imCode="+imCode);
  			logger.info("for specific imCode:"+imCode+"  "+txn_type);
  			Object[] params = new Object[] {imCode};

  			try {
  				list = jdbcTemplate.query(LIMIT_IM_REPORT_LIST,params,new LimitIMReportMapper());
  				logger.info("list size "+list.size()+"    ,LIMIT_IM_REPORT_LIST:"+LIMIT_IM_REPORT_LIST);
  				logger.info("List From query"+list);
  			} 
  			catch (DataAccessException dataAccessException) {
  				logger.error("Exception occured : " + dataAccessException.getMessage());
  			}
  			logger.info("limitIMReport"+SCFUConstants.METHOD_ENDS);
  		}
  		return list;
  	}
  	
  	public List overdueVendorReport(String vendorCode, String txn_type,
			String imCode) {
  		logger.info("overdueVendorReport"+SCFUConstants.METHOD_BEGINS);
  		logger.info(" txn_type value recieved in findVendorDetails block :" + txn_type);
  		logger.info(" Input query params :" + vendorCode+txn_type);
  		List list = null;
  		if (vendorCode != null )
  		{
  			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
  			logger.info("vendorCode="+vendorCode);
  			if (vendorCode.equalsIgnoreCase("VDRALL")){
  				Object[] params = new Object[] {txn_type,imCode};
  				try {
  					list = jdbcTemplate.query(GET_ALL_VENDOR_DETAIL_LIST_OVERDUE,params,new OverdueReportMapper());
  					logger.info("vendor code for ALL:"+vendorCode);
  					logger.info("list size "+list.size()+"    ,GET_ALL_VENDOR_DETAIL_LIST_OVERDUE:"+GET_ALL_VENDOR_DETAIL_LIST_OVERDUE);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			else if (vendorCode!="VDRALL"){
  				logger.info("for specific vendor code:"+vendorCode+"  "+txn_type);
  				Object[] params = new Object[] {vendorCode,txn_type,imCode};

  				try {
  					list = jdbcTemplate.query(OVERDUE_VENDOR_REPORT_LIST,params,new OverdueReportMapper());
  					logger.info("list size "+list.size()+"    ,OVERDUE_VENDOR_REPORT_LIST:"+OVERDUE_VENDOR_REPORT_LIST);
  					logger.info("List From query"+list);
  					if (list.size() == 0){
  						logger.error("No Records fetched for the vendor");
  						DAOException.throwException("emptyVendorList");
  					}
  				} 
  				catch (DataAccessException dataAccessException) {
  					logger.error("Exception occured : " + dataAccessException.getMessage());
  				}
  			}
  			logger.info("overdueVendorReport"+SCFUConstants.METHOD_ENDS);
  		}
		return list;
	}
  	/*Row mapper for Principal reports*/
  	public class ReportMapper implements RowMapper{
  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();
  			try{
  				vendorReportDetails.setTransaction_date(resultSet.getString("TRANSACTION_DATE"));
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				vendorReportDetails.setAmount(resultSet.getString("AMOUNT"));
  				vendorReportDetails.setReference_no(resultSet.getString("REFERENCE_NO"));
  				vendorReportDetails.setVendor_code(resultSet.getString("VENDOR_CODE"));
  				vendorReportDetails.setStatus(resultSet.getString("STATUS"));
  				vendorReportDetails.setCreation_time(resultSet.getString("CREATION_TIME"));
  				vendorReportDetails.setReversal_date(resultSet.getString("REVERSAL_DATE"));
  				vendorReportDetails.setInterest_ref_no(resultSet.getString("INTEREST_REF_NO"));
  				vendorReportDetails.setReversal_ref_no(resultSet.getString("REVERSAL_REF_NO"));
  				vendorReportDetails.setInvoice_no(resultSet.getString("INVOICE_NO"));
  				vendorReportDetails.setInvoice_date(resultSet.getString("INVOICE_DATE"));
  				vendorReportDetails.setFile_no(resultSet.getString("FILE_NO"));
  				vendorReportDetails.setCredit_account_no(resultSet.getString("CREDIT_ACCOUNT_NO"));
  				vendorReportDetails.setDebit_account_no(resultSet.getString("ACCOUNT_NO"));			
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}

  	/*Row mapper for interest reports*/
  	public class IntrestReportMapper implements RowMapper{

  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();

  			try{
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				vendorReportDetails.setVendor_code(resultSet.getString("VENDOR_CODE"));
  				vendorReportDetails.setReference_no(resultSet.getString("REFERENCE_NO"));
  				vendorReportDetails.setStatus(resultSet.getString("STATUS"));
  				vendorReportDetails.setCreation_time(resultSet.getString("CREATION_TIME"));
  				vendorReportDetails.setReversal_ref_no(resultSet.getString("REVERSAL_REF_NO"));
  				logger.info("inside IntrestReportMapper");
  				vendorReportDetails.setTransaction_amount(resultSet.getString("INTEREST_AMOUNT"));
  				vendorReportDetails.setTransaction_amount_1(resultSet.getString("PRINCIPAL_AMOUNT"));
  				vendorReportDetails.setTxn_completed_time(resultSet.getString("TXN_COMPLETED_TIME"));
  				vendorReportDetails.setOrg_debit_ref_no(resultSet.getString("ORG_DEBIT_REF_NO"));
  				vendorReportDetails.setInvoice_no(resultSet.getString("INVOICE_NO"));
  				vendorReportDetails.setInvoice_date(resultSet.getString("INVOICE_DATE"));
  				vendorReportDetails.setReversal_date(resultSet.getString("REVERSAL_DATE"));
  				vendorReportDetails.setCredit_account_no(resultSet.getString("CREDIT_ACCOUNT_NO"));
  				vendorReportDetails.setDebit_account_no(resultSet.getString("ACCOUNT_NO"));			
  				logger.info("Interest vendorReportDetails----  "+vendorReportDetails.getAmount()+ "----TRANSACTION_AMOUNT----"+vendorReportDetails.getTransaction_amount()+"--------amt-------"+vendorReportDetails.getInterest_amount());
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}

  	/*Row mapper for REVERSE reports*/ 
  	public class ReverseReportMapper implements RowMapper{      	


  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();
  			try{
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				vendorReportDetails.setVendor_code(resultSet.getString("VENDOR_CODE"));
  				vendorReportDetails.setReversal_date(resultSet.getString("REVERSAL_DATE"));
  				vendorReportDetails.setReference_no(resultSet.getString("REFERENCE_NO"));
  				vendorReportDetails.setTransaction_amount(resultSet.getString("TRANSACTION_AMOUNT"));
  				vendorReportDetails.setCreation_time(resultSet.getString("CREATION_TIME"));
  				vendorReportDetails.setTransaction_date(resultSet.getString("TRANSACTION_DATE"));
  				vendorReportDetails.setStatus(resultSet.getString("STATUS"));
  				logger.info("inside ReverseReportMapper");
  				vendorReportDetails.setOrg_debit_ref_no(resultSet.getString("ORG_DEBIT_REF_NO"));
  				vendorReportDetails.setInterest_ref_no(resultSet.getString("INTEREST_REF_NO"));
  				vendorReportDetails.setInvoice_no(resultSet.getString("INVOICE_NO"));
  				vendorReportDetails.setInvoice_date(resultSet.getString("INVOICE_DATE"));
  				vendorReportDetails.setCredit_account_no(resultSet.getString("CREDIT_ACCOUNT_NO"));
  				vendorReportDetails.setDebit_account_no(resultSet.getString("ACCOUNT_NO"));			
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}

  	/*Row mapper for overdue interest reports*/
  	public class OverdueReportMapper implements RowMapper{

  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();

  			try{
  				vendorReportDetails.setOverdue_ref_no(resultSet.getString("OVERDUE_REF_NO"));
  				vendorReportDetails.setOverdue_amount(resultSet.getString("OVERDUE_AMOUNT"));
  				vendorReportDetails.setVendor_code(resultSet.getString("VENDOR_CODE"));
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				vendorReportDetails.setCreation_time(resultSet.getString("OVERDUE_CREATION_DATE"));
  				vendorReportDetails.setTxn_completed_time(resultSet.getString("TXN_COMPLETED_TIME"));
  				vendorReportDetails.setReversal_date(resultSet.getString("REVERSAL_DATE"));
  				vendorReportDetails.setNo_of_days(resultSet.getString("NO_OF_DAYS"));
  				vendorReportDetails.setOrg_debit_ref_no(resultSet.getString("ORG_DEBIT_REF_NO"));
  				vendorReportDetails.setTransaction_amount_1(resultSet.getString("PRINCIPAL_AMOUNT"));
  				vendorReportDetails.setInterest_ref_no(resultSet.getString("INTEREST_REF_NO"));
  				vendorReportDetails.setTransaction_amount(resultSet.getString("INTEREST_AMOUNT"));
  				vendorReportDetails.setReversal_ref_no(resultSet.getString("REVERSAL_REF_NO"));
  				logger.info("inside OverdueIntrestReportMapper");
  	            vendorReportDetails.setCredit_account_no(resultSet.getString("CREDIT_ACCOUNT_NO"));
  				vendorReportDetails.setDebit_account_no(resultSet.getString("ACCOUNT_NO"));	
  				vendorReportDetails.setStatus(resultSet.getString("STATUS"));
  				//logger.info("Interest vendorReportDetails----  "+vendorReportDetails.getAmount()+ "----TRANSACTION_AMOUNT----"+vendorReportDetails.getTransaction_amount()+"--------amt-------"+vendorReportDetails.getInterest_amount());
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}
  	/*Row mapper for LIMIT reports*/ 
  	public class LimitReportMapper implements RowMapper{      	


  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();
  			try{
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				logger.info("inside LimitReportMapper");
  				vendorReportDetails.setVendor_code(resultSet.getString("VENDOR_CODE"));
  				vendorReportDetails.setLimit_expiry_date(resultSet.getString("LIMIT_EXPIRY_DATE"));
  				vendorReportDetails.setAvailable_limit(resultSet.getString("AVAILABLE_LIMIT"));
  				vendorReportDetails.setOutstanding_limit(resultSet.getString("OUTSTANDING_LIMIT"));
  				vendorReportDetails.setAllocated_limit(resultSet.getString("ALLOCATED_LIMIT"));
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}
 	/*Row mapper for IM LIMIT reports*/ 
  	public class LimitIMReportMapper implements RowMapper{      	


  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			VendorReportDetails vendorReportDetails = new VendorReportDetails();
  			try{
  				vendorReportDetails.setName(resultSet.getString("NAME"));
  				logger.info("inside LimitIMReportMapper");
  				vendorReportDetails.setIm_code(resultSet.getString("IM_CODE"));
  				vendorReportDetails.setLimit_expiry_date(resultSet.getString("LIMIT_EXPIRY_DATE"));
  				vendorReportDetails.setAvailable_limit(resultSet.getString("AVAILABLE_LIMIT"));
  				vendorReportDetails.setOutstanding_limit(resultSet.getString("OUTSTANDING_LIMIT"));
  				vendorReportDetails.setAllocated_limit(resultSet.getString("ALLOCATED_LIMIT"));
  			}
  			catch(Exception excep){
  				logger.error("Error while calculating Invoice amount - ", excep);
  			}
  			return vendorReportDetails;
  		}
  	}
  	
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
}

	public boolean checkVendorDetails(String vendorCode,String vendorName) {
		logger.info("checkVendorDetails"+SCFUConstants.METHOD_BEGINS);
		boolean status=true;
		try{
		logger.info("vendor_code = "+vendorCode+"vendor_name = "+vendorName);
		Object[] params = new Object[] {vendorCode,vendorName};
		int count=0;
		if(!("VDRALL".equalsIgnoreCase(vendorCode))){
		count = jdbcTemplate.queryForInt(CHECK_VENDOR_DETAILS,params);
			if(count==0){
			DAOException.throwException("TechnicalProblem");
			status=false;
		    }
		}
		else if("VDRALL".equalsIgnoreCase(vendorCode)){
		status=true;
		}
		}catch(DataAccessException e){
			logger.error("Error Occured : " + e.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("checkVendorDetails"+SCFUConstants.METHOD_ENDS);
		return status;
	}
	
	
}