package org.scfu.vf.dao;

import java.util.Map;
@SuppressWarnings({"rawtypes"})
public interface VFIMUserDAO {
	boolean addVFIMUser(Map inParams);

	boolean insertSCFUUserDetails(Map inParams);

	boolean insertSCFUUser(Map inParams);
}
