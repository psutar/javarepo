package org.scfu.vf.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.FileUploadStatusDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

@SuppressWarnings({"rawtypes"})
public class ViewTransactionDetailsDAOImpl implements ViewTransactionDetailsDAO {

	protected Logger logger = Logger.getLogger(getClass());
	private static final String GET_STATUS_DETAILS="select max(rownum) from scfu_file_master";
	private static final String GET_TRANSACTION_DETAILS="select file_no,uploaded_file_name  FILE_NAME,TO_CHAR (creation_time, 'dd/mm/yyyy') creation_date,file_status status from scfu_file_master where user_name=? order by creation_time desc";
	

	private static final String GET_FILE_DETAILS="SELECT reference_no, upload_status, invoice_no, invoice_amount, invoice_date, rev_date_or_tenor_days, creation_date, file_no, status, vendor_code, vendor_name, status_desc,txn_desc FROM (SELECT a.transaction_no reference_no, (SELECT file_status FROM scfu_file_master WHERE file_no=? ) upload_status, NVL(a.invoice_no,'--') invoice_no, NVL(a.invoice_amount,'0') invoice_amount, NVL(TO_CHAR(to_date(a.invoice_date,'dd/mm/yyyy'),'dd/mm/yyyy'),'--') invoice_date, decode(d.reversal_based_on,'REVERSAL_DATE',a.reversal_date,a.tenor_days) rev_date_or_tenor_days, TO_CHAR (a.creation_time, 'dd/mm/yyyy') creation_date, a.file_no, DECODE (b.current_auth_level,'50','Waiting For Posting','49','Waiting for Interest Posting','-49','Interest Failure', '1','Pending For First Level Authorisation','2','Pending For Second Level Authorisation','-1','Rejected', '0', (SELECT DECODE (d.debit_status, '00','Completed Successfully','ERR.','Failure','REP.','Reposting','Pending') FROM scfu_debit_transactions d WHERE a.transaction_no = d.transaction_no )) status, a.vendor_code, c.name vendor_name, a.status_desc,NVL(DECODE (b.current_auth_level,'-1',(select e.description from scfu_debit_transactions e where e.transaction_no=b.transaction_no),'0',(select DECODE(f.debit_status,'00','Success','ERR.',f.status_description,'--') from scfu_debit_transactions f where f.transaction_no=b.transaction_no),'--'),'--') txn_desc FROM scfu_vf_file_txn_details a, scfu_debit_transactions b, scfu_vf_vendor_master c,scfu_vf_im_master d WHERE a.transaction_no = b.transaction_no AND lower(a.status) ='success' AND a.vendor_code =c.vendor_code AND a.im_code =c.im_code   and c.im_code=d.im_code AND a.file_no = ? "+
												 " UNION ALL "+
												 "SELECT a.reference_no reference_no, (SELECT file_status FROM scfu_file_master WHERE file_no=? ) upload_status, NVL(a.invoice_no,'--') invoice_no, NVL(a.invoice_amount,'0') invoice_amount, NVL(TO_CHAR(to_date(a.invoice_date,'dd/mm/yyyy'),'dd/mm/yyyy'),'--') invoice_date,  '--' rev_date_or_tenor_days, TO_CHAR (a.creation_time, 'dd/mm/yyyy') creation_date, a.file_no, DECODE (a.status,'Failure','Validation Failure','Pending For Validation') status, a.vendor_code, b.name vendor_name, a.status_desc, '--' txn_desc FROM scfu_vf_file_txn_details a, scfu_vf_vendor_master b WHERE a.status IN ('Failure','Pending') AND a.vendor_code=b.vendor_code(+) AND a.im_code =b.im_code(+) AND a.file_no = ? ) ORDER BY reference_no DESC ";
	private JdbcTemplate jdbcTemplate;

	public List findTransactionDetails(String userName) {
		logger.info("findTransactionDetails"+SCFUConstants.METHOD_BEGINS);
		Object[] params = new Object[] { userName };	
		List list = null;
		try {
			list = jdbcTemplate.query(GET_TRANSACTION_DETAILS,params,new FileMapper());
			logger.info("list size "+list.size()+"    ,GET_TRANSACTION_DETAILS:"+GET_TRANSACTION_DETAILS);
		} 

		catch (DataAccessException dataAccessException) {
			logger.error("Exception occured : " + dataAccessException.getMessage());
		}
		logger.info("findTransactionDetails"+SCFUConstants.METHOD_ENDS);
		return list;
	}
	
	public List findFileDetails(String fileNo) {
		logger.info("findFileDetails" + SCFUConstants.METHOD_BEGINS);
		Object[] params = new Object[] { fileNo, fileNo, fileNo, fileNo };
		List list = null;
		try {
			list = jdbcTemplate.queryForList(GET_FILE_DETAILS, params);
			logger.info("list size " + list.size() + "    ,GET_FILE_DETAILS:"+ GET_FILE_DETAILS);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured : "+ dataAccessException.getMessage());
		}
		logger.info("findFileDetails" + SCFUConstants.METHOD_ENDS);
		return list;
	}

	public boolean fileStatus() throws DAOException {
		logger.info("fileStatus" + SCFUConstants.METHOD_BEGINS);
		boolean flag = false;
		try {
			int count = jdbcTemplate.queryForInt(GET_STATUS_DETAILS);
			logger.info("COUNT of the file no. :" + count);
			if (count == 0) {
				DAOException.throwException("noFilestoView");
			}
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured : "
					+ dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("fileStatus" + SCFUConstants.METHOD_ENDS);
		return flag;
	}

	public class FileMapper implements RowMapper{
  		public Object mapRow(ResultSet resultSet, int count) throws SQLException {
  			FileUploadStatusDetails fileUploadStatusDetails = new FileUploadStatusDetails();
  			try{
  				fileUploadStatusDetails.setFile_name(resultSet.getString("FILE_NAME"));
  				fileUploadStatusDetails.setStatus(resultSet.getString("STATUS"));
  				fileUploadStatusDetails.setCreation_time(resultSet.getString("CREATION_DATE"));
  				fileUploadStatusDetails.setFile_no(resultSet.getString("FILE_NO"));
  				fileUploadStatusDetails.setFile_no(resultSet.getString("FILE_NO"));
  			}
  			catch(Exception excep){
  				logger.error("Error Occoured - ", excep);
  			}
  			return fileUploadStatusDetails;
  		}
  	}
	  public void setDataSource(DataSource dataSource) {
          this.jdbcTemplate = new JdbcTemplate(dataSource);
}
}
