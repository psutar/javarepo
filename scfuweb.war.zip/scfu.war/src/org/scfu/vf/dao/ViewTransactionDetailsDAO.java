package org.scfu.vf.dao;

import java.util.List;

@SuppressWarnings({"rawtypes"})
public interface ViewTransactionDetailsDAO {

	List findTransactionDetails(String fileName);

	List findFileDetails(String fileNo);

	boolean fileStatus();

}
