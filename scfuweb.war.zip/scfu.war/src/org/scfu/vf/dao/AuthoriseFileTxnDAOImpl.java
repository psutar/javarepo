package org.scfu.vf.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.DAOException;
import org.scfu.vf.model.AuthFileDisplayModel;
import org.scfu.vf.model.SlabDetails;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

@SuppressWarnings("rawtypes")
public class AuthoriseFileTxnDAOImpl implements AuthoriseFileTxnDAO{
	
	private Logger logger = Logger.getLogger(getClass());
	
	private String GET_IM_FILE_LIST = "SELECT distinct(file_no),uploaded_file_name,TO_CHAR(creation_time,'dd/mm/yyyy') creation_time,maker FROM view_vf_inbox WHERE login_id =? AND corporate_id = ? order by creation_time desc";
	
	private String VIEW_TXN_FILE_DETAILS = "SELECT vvf.transaction_no,vvf.reference_no,vvf.vendor_code,vvf.name,vvf.invoice_no,vvf.invoice_date,vvf.transaction_amt,vvf.REV_DATE_OR_TENOR_DAYS,vvf.tenor_days,vvf.current_auth_level," +
	   										"DECODE (vvf.current_auth_level,'50','Waiting For Posting','49','Waiting for Interest Posting','-49','Interest Failure', "+
	   										"'1','Pending For First Level Authorization','2','Pending For Second Level Authorization','-1','Rejected',"+
	   										"'0',(select decode (d.debit_status, '00','Success','ERR.','Failure','REP.','Reposting','Pending')"+
	   										"FROM scfu_debit_transactions d WHERE vvf.transaction_no = d.transaction_no)) status " +
	   										"FROM view_vf_inbox vvf WHERE vvf.file_no = ? AND vvf.login_id=? AND upper(vvf.status) ='SUCCESS'";
	
	private String CURRENT_AUTH_LEVEL = "SELECT distinct current_auth_level FROM view_vf_inbox WHERE transaction_no= ? and current_auth_level=? and login_id=? ";
	
	private String UPDATE_CURRENT_AUTH_LEVEL1 = "UPDATE scfu_debit_transactions SET current_auth_level=? WHERE transaction_no= ? and current_auth_level !=  ?";
	
	private String UPDATE_CURRENT_AUTH_LEVEL2 = "UPDATE scfu_debit_transactions SET current_auth_level='49' WHERE transaction_no= ? and current_auth_level != '49' ";
	
	private String UPDATE_REJECTION_CURRENT_AUTH_LEVEL = "UPDATE scfu_debit_transactions SET current_auth_level='-1',DESCRIPTION=? WHERE transaction_no=? and current_auth_level!='-1'";
	
	private String UPDATE_VALIDATION_STATUS = "UPDATE scfu_debit_transactions SET current_auth_level='-1' , status_description='Rejected due to CreditPeriod not between Min and Max value.' WHERE transaction_no=?";
	
	private String TXN_COUNT_DETAILS ="SELECT (SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=? ) ref_no_count,"+ 
									  "(SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=? AND upper(status)='SUCCESS') val_success_cnt,"+
									  "(SELECT count(reference_no) FROM scfu_vf_file_txn_details svftd WHERE svftd.file_no=? AND upper(status)='FAILURE') val_failure_cnt,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=1 AND std.module_name ='VENDOR') cur_auth_1,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=2 AND std.module_name ='VENDOR') cur_auth_2,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=-1 AND std.module_name ='VENDOR') rejected_cnt,"+ 
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=49 AND std.module_name ='VENDOR') success_cnt_before_Int_Post,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=-49 AND std.module_name ='VENDOR') failure_cnt_before_Int_Post,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=50 AND std.module_name ='VENDOR') txn_success_cnt_beforePosting,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=0 AND std.debit_status='00' AND std.module_name ='VENDOR') txn_success_cnt_afterPosting,"+
									  "(SELECT count(transaction_no) FROM scfu_debit_transactions std WHERE std.file_no=? AND std.current_auth_level=0 AND std.debit_status='ERR.' AND std.module_name ='VENDOR') txn_rejected_cnt_afterPosting"+
									  " FROM dual ";
	
	private String UPDATE_AUTH_DETAILS ="UPDATE scfu_auth_details SET auth_name_1=?,auth_date_1=sysdate WHERE transaction_no=? ";
	
	private String UPDATE_AUTH_DETAILS_1 ="UPDATE scfu_auth_details SET auth_name_2=?,auth_date_2=sysdate WHERE transaction_no=? ";
	
	private String GET_AUTH_LEVEL1 = "SELECT * FROM (SELECT  DECODE (auth_type, 'SINGLE', 49, 2) FROM scfu_vf_rule_details a, scfu_vf_rule_master b "+
									"WHERE a.rule_id = b.rule_id AND a.user_name = ? AND b.code = ? "+
									"AND lower(b.status) = 'active' "+
									"ORDER BY b.limit_amount, auth_type ) WHERE ROWNUM=1";
	
	private String FILE_UPLOADER_DETAILS = "SELECT uploaded_file_name, user_name FROM scfu_file_master WHERE file_no=?";
	
	private String  TXN_VALIDATION_DETAILS="SELECT svftd.file_no,svftd.transaction_no,svftd.im_code,svvm.vendor_unique_code," +
											"TO_CHAR(svftd.creation_time,'dd/mm/yyyy') creation_time,svftd.reversal_date reversal_date " +
											"FROM scfu_vf_file_txn_details svftd,scfu_vf_vendor_master svvm WHERE svftd.transaction_no=? " +
											"AND upper(svftd.status)          ='SUCCESS' AND svftd.vendor_code= svvm.vendor_code";
	
	private String  FIND_SLAB_DETAILS ="select svsm.code,svsm.param_owned_by,svsm.status," +
												"DECODE(svsm.param_owned_by,'IM',cp_min_value," +
												"(select cp_min_value from scfu_vf_slab_master  where code=?)) cp_min_value," +
												"DECODE(svsm.param_owned_by,'IM',cp_max_value," +
												"(select cp_max_value from scfu_vf_slab_master  where code=?)) cp_max_value " +
												"from scfu_vf_slab_master svsm " +
												"where code=? " +
												"and status=? ";
	
	private String  GET_REVERSAL_BASED_ON = "SELECT reversal_based_on FROM scfu_vf_im_master WHERE im_code=?";
	
	private JdbcTemplate jdbcTemplate;
    
	
	public List findIMList(String userName, String corporateId) {
		logger.info("findIMList" + SCFUConstants.METHOD_BEGINS);
		List list = null;
		Object[] params = { userName, corporateId };
		try {
			list = jdbcTemplate.queryForList(GET_IM_FILE_LIST, params);
		} catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("findIMList" + SCFUConstants.METHOD_ENDS);
		return list;
	}
	
	public List fileUploaderDetails(String fileNo)
	{
		logger.info("fileUploaderDetails"+SCFUConstants.METHOD_BEGINS);
		List txnFileDetails = null;
		Object[] params = new Object[] { fileNo};
		try
		{
			txnFileDetails = jdbcTemplate.queryForList(FILE_UPLOADER_DETAILS,params);	
			if(txnFileDetails == null || txnFileDetails.size() == 0)
			{
				DAOException.throwException("noFileUploaderDetails");
			}
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("fileUploaderDetails"+SCFUConstants.METHOD_ENDS);		
		return txnFileDetails;
	}

	public List viewTxnFileDetails(String fileNo,String userName)
	{
		logger.info("viewTxnFileDetails"+SCFUConstants.METHOD_BEGINS);
		List txnFileDetails = null;
		Object[] params = new Object[] { fileNo,userName};
		try
		{
			logger.info("VIEW_TXN_FILE_DETAILS : " + VIEW_TXN_FILE_DETAILS);
			txnFileDetails = jdbcTemplate.queryForList(VIEW_TXN_FILE_DETAILS,params);				
			if(txnFileDetails == null || txnFileDetails.size() == 0)
			{
				DAOException.throwException("transactionNotProcessed");
			}			
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("viewTxnFileDetails"+SCFUConstants.METHOD_ENDS);
		
		return txnFileDetails;
	}
	
	public Map viewTxnCountDetails(String fileNo)
	{
		logger.info("viewTxnCountDetails"+SCFUConstants.METHOD_BEGINS);
		Map txnCount = new HashMap();
		Object[] params = new Object[] { fileNo,fileNo,fileNo,fileNo,fileNo,fileNo,fileNo,fileNo,fileNo,fileNo,fileNo };			
		try {		
			txnCount = jdbcTemplate.queryForMap(TXN_COUNT_DETAILS,params);
			if(txnCount == null || txnCount.size() == 0)
			{
				DAOException.throwException("transactionNotProcessed");
			}	
		} 
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}		
		logger.info("viewTxnCountDetails"+SCFUConstants.METHOD_ENDS);
		return txnCount;
	}
	
	public String getReversalBasedOn(String imCode)
	{
		logger.info("getReversalBasedOn"+SCFUConstants.METHOD_BEGINS);
		Object[] params = null;
		String reversalBasedOn = null;		
		try
		{
			params = new Object[] { imCode};
			reversalBasedOn = (String) jdbcTemplate.queryForObject(GET_REVERSAL_BASED_ON, params, String.class);
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("getReversalBasedOn"+SCFUConstants.METHOD_ENDS);
		return reversalBasedOn;	
	}

	public AuthFileDisplayModel findTxnValidationDetails(String transactionNo)
	{
		logger.info("findTxnValidationDetails"+SCFUConstants.METHOD_BEGINS);
		AuthFileDisplayModel authFileDisplayModel = null;
		Object[] params = new Object[] {transactionNo};
		try
		{
			authFileDisplayModel = (AuthFileDisplayModel) jdbcTemplate.queryForObject(TXN_VALIDATION_DETAILS, params,
                    new AuthoriseFileMapper());
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("findTxnValidationDetails"+SCFUConstants.METHOD_ENDS);
		
		return authFileDisplayModel;
	}
		
	public class AuthoriseFileMapper implements RowMapper
	{
		 public Object mapRow(ResultSet resultSet, int count) throws SQLException {
			 
		    logger.info("AuthoriseFileMapper "+SCFUConstants.METHOD_BEGINS);
		    AuthFileDisplayModel authFileDisplayModel=new AuthFileDisplayModel();
		    authFileDisplayModel.setFileNo(resultSet.getString("file_no"));
		    authFileDisplayModel.setTransactionNo(resultSet.getString("transaction_no"));
		    authFileDisplayModel.setImCode(resultSet.getString("im_code"));
		    authFileDisplayModel.setVendorCode(resultSet.getString("vendor_unique_code"));
		    authFileDisplayModel.setCreationDate(resultSet.getString("creation_time"));
		    authFileDisplayModel.setReversalDate(resultSet.getString("reversal_date"));	    
			logger.info("AuthoriseFileMapper "+SCFUConstants.METHOD_ENDS);
		    return authFileDisplayModel;
		 }
	}
		
	public Integer getCurrentAuthLevel(String echequeNo,String authLevel,String userName)
	{
		logger.info("getCurrentAuthLevel"+SCFUConstants.METHOD_BEGINS);
		Integer current_auth_level = 0;
		try
        {
        	Object[] params=new Object[]{echequeNo,authLevel,userName};
        	current_auth_level= (Integer)jdbcTemplate.queryForInt(CURRENT_AUTH_LEVEL, params);
        }catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("AlreadyAuthorisedRejected");
		}
		logger.info("getCurrentAuthLevel"+SCFUConstants.METHOD_ENDS);
		return current_auth_level;
	}
	
	
	public void updateCurrentAuthLevel(String echequeNo,Integer current_auth_level,String userName,String imCode)
	{
		logger.info("updateCurrentAuthLevel"+SCFUConstants.METHOD_BEGINS);
		Integer auth_level = null;
		Object[] param1 = new Object[] { userName , imCode  };
		Object[] param2 = new Object[] { echequeNo  };

		try
		{
			logger.info("current auth level" +current_auth_level);
			if(current_auth_level == 1)
			{			
				auth_level = jdbcTemplate.queryForInt(GET_AUTH_LEVEL1,param1);			
				Object[] params = new Object[] { auth_level , echequeNo, auth_level  };
				int confirmTxnDetails = jdbcTemplate.update(UPDATE_CURRENT_AUTH_LEVEL1,params);
				logger.info("Current auth level update status count : " +confirmTxnDetails);
				if (confirmTxnDetails==0){
					logger.info(" 1st level of authorisation is not happened  : " +confirmTxnDetails);  
					DAOException.throwException("Auth1Error");
				}

			}			
			else if(current_auth_level == 2)
			{
				int confirmTxnDetails = jdbcTemplate.update(UPDATE_CURRENT_AUTH_LEVEL2,param2);
				logger.info("Current auth level update status count : " +confirmTxnDetails);
				if (confirmTxnDetails==0){
					logger.info(" 2nd level of authorisation is not happened  : " +confirmTxnDetails);  
					DAOException.throwException("Auth2Error");
				}
			}
			else if((current_auth_level == -1) )
			{
				DAOException.throwException("AlreadyRejected");
			}
			else if((current_auth_level == 49))
			{
				DAOException.throwException("AlreadyAuthorised");
			}
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("updateCurrentAuthLevel"+SCFUConstants.METHOD_ENDS);		
	}
	
	public void updateRejectionCurrentAuthLevel(String echequeNo,Integer current_auth_level, String rejectreason )
	{
		logger.info("updateRejectionCurrentAuthLevel"+SCFUConstants.METHOD_BEGINS);
		logger.info("current auth level" +current_auth_level);
		Object[] params = new Object[] { rejectreason,echequeNo};
		try
		{
			if(current_auth_level == 1 || 	current_auth_level == 2)
			{
			int confirmTxnDetails = jdbcTemplate.update(UPDATE_REJECTION_CURRENT_AUTH_LEVEL,params);
			logger.info("Current auth level rejection status count : " +confirmTxnDetails);
			}
			else
			{
				DAOException.throwException("AlreadyAuthorised");
			}
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("updateRejectionCurrentAuthLevel"+SCFUConstants.METHOD_ENDS);
		
	}
	
	public void updateAuthDetails(String transactionNo,Integer current_auth_level,String auth_name)
	{
		logger.info("insertAuthDetails"+SCFUConstants.METHOD_BEGINS);
		Object[] params = null;
			
		try
		{
			params = new Object[] { auth_name ,transactionNo };
			if(current_auth_level == 1)
			{			
			int updateTxnDetails = jdbcTemplate.update(UPDATE_AUTH_DETAILS,params);
			logger.info("AuthDetails inserted count : " +updateTxnDetails);
			}
			else
			{
			int updateTxnDetails1 = jdbcTemplate.update(UPDATE_AUTH_DETAILS_1,params);	
			logger.info("AuthDetails inserted count : " +updateTxnDetails1);
			}
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("insertAuthDetails"+SCFUConstants.METHOD_ENDS);
	}
	
	public SlabDetails findOverridDetails(String imCode, String vendorCode, String status) throws DAOException {
		logger.info("findOverridDetails( String Code, String Type);"+ SCFUConstants.METHOD_BEGINS);
		logger.info("IMCode : " + imCode);
		logger.info("VendorCode : " + vendorCode);
        logger.info("status : " + status);
        SlabDetails slabDetails = null;
		if (imCode != null & vendorCode != null ) {
			String strStatus = "Active";
			if (status != null && status.trim().length() > 0)
				strStatus = status;
			Object[] parameters = new Object[] { vendorCode , vendorCode, imCode, strStatus};
			try {
				slabDetails = (SlabDetails) jdbcTemplate
						.queryForObject(FIND_SLAB_DETAILS, parameters, new VFIMROIOverridetRowMapper());
				if(slabDetails==null)
					DAOException.throwException("TechnicalProblem");
					logger.error("DataAccessException ");
			} catch (DataAccessException ex) {
				ex.printStackTrace();
				logger.error("DataAccessException :" + ex.getMessage());
				DAOException.throwException("TechnicalProblem");
			}
		} else {
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("findOverridDetails(String Code, String Type)"+SCFUConstants.METHOD_ENDS);
		return slabDetails;
	}
		
	private class VFIMROIOverridetRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			SlabDetails slabDetails = new SlabDetails();
			slabDetails.setCode(rs.getString("CODE"));

			String minVal = rs.getString("CP_MIN_VALUE");
			String maxVal = rs.getString("CP_MAX_VALUE");

			slabDetails.setMinimumValue(minVal);
			slabDetails.setMaximumValue(maxVal);
			slabDetails.setParamOwnedBy(rs.getString("PARAM_OWNED_BY").trim());
			slabDetails.setStatus(rs.getString("STATUS"));

			return slabDetails;
		}
	}
	
	public void updateValidationFailureStatus(String echequeNo)
	{
		logger.info("updateValidationFailureStatus(String echequeNo) method begins");
		
		Object[] params = new Object[] { echequeNo };
		try
		{
			int confirmTxnDetails = jdbcTemplate.update(UPDATE_VALIDATION_STATUS,params);
			logger.info("Successfully updated");
		}
		catch (DataAccessException dataAccessException) {
			logger.error("DataAccessException occured : " + dataAccessException.getMessage());
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("updateValidationFailureStatus"+SCFUConstants.METHOD_ENDS);
	}
	
	public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
}
}
		
