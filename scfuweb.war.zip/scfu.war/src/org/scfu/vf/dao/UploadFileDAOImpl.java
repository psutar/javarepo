package org.scfu.vf.dao;

import java.sql.Types;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
@SuppressWarnings({"rawtypes"})

public class UploadFileDAOImpl implements UploadFileDAO
 {
	protected Logger logger = Logger.getLogger(getClass());

	public final static String INSERT_INTO_SCFU_FILE_MASTER = "insert into SCFU_FILE_MASTER(file_type,file_no,file_name,file_status,user_name,creation_time,last_mod_time,im_code,uploaded_file_name,header,footer)values(?,?,?,?,?,sysdate,sysdate,?,?,?,?)";

	public final static String CHECK_DUPLICATE_FILENAME = "select count(*) from SCFU_FILE_MASTER where  uploaded_file_name=? and  file_type =? and im_code=? and lower(file_status) !='error'";

	public final static String UPLOAD_FILE_SNO = "select SEQ_FILE_SNO.nextval from dual";
	private JdbcTemplate jdbcTemplate;

	/*
	 * It inserts Records into the scfu file master table 1. checks whether the
	 * uploaded files exists in the db or not 2. inserts into the db if no
	 * duplicate file is found Prateek
	 */
	public Integer insertScfuFileMaster(Map queryParams) throws DAOException {
		logger.info("insertIntoscfufilemaster" + SCFUConstants.METHOD_BEGINS);
		logger.info(" Input query params :" + queryParams);
		Integer value = 0;
		if (queryParams != null && queryParams.size() > 0) {
			logger.info(" Inside if (queryParams != null && queryParams.size() > 0) block");
			String fileType = (String) queryParams.get("fileType");
			String file_no = (String) queryParams.get("sno");
			String fileName = (String) queryParams.get("fileName");
			String fileStatus = (String) queryParams.get("fileStatus");
			String userName = (String) queryParams.get(SCFUConstants.USER_NAME);
			String im_code = (String) queryParams.get("im_code");
			String uploaded_file_name = (String) queryParams
					.get("uploaded_file_name");
			String header = (String) queryParams.get("header");
			String footer = (String) queryParams.get("footer");

			logger.info("fileType = " + fileType + " file_no = " + file_no
					+ " fileName = " + fileName + " fileName = " + fileName
					+ " fileStatus = " + fileStatus + " userName = " + userName
					+ " uploaded_file_name = " + uploaded_file_name
					+ "im_code = " + im_code + " header = " + header);
			Object[] params = new Object[] { fileType, file_no, fileName,
					fileStatus, userName, im_code, uploaded_file_name, header,
					footer };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR };
			try {
				Object[] args = new Object[] { uploaded_file_name, fileType, im_code };
				logger.info("before checking for duplicate file");
				int count = jdbcTemplate.queryForInt(CHECK_DUPLICATE_FILENAME, args);
				logger.info("count of the filename " + count);
				if (count != 0) {
					DAOException.throwException("DuplicateFile");
				} else {
					logger.info("before insertion into scfu_file_master");
					value = new Integer(jdbcTemplate.update(INSERT_INTO_SCFU_FILE_MASTER, params, sqlTypes));
				}
				logger.info("Result : " + value);
			} catch (DataAccessException e) {
				logger.error("Error occured :", e);
				e.printStackTrace();

			}
		} else

			logger.info("Integer insertIntoscfufilemaster"
					+ SCFUConstants.METHOD_ENDS);
		return value;
	}

	/* For inserting serial no. called from FileUploadConfirmService */
	public Integer getNextNumberFromSequenceFile() {
		logger.info("getNextNumberFromSequenceFile()-begin");
		Integer value = null;
		try {
			value = new Integer(jdbcTemplate.queryForInt(UPLOAD_FILE_SNO));
			logger.info("Result Sequence Number =" + value);
		} catch (DataAccessException e) {
			logger.error("Error occured ", e);
			DAOException.throwException("TechnicalProblem");
		}
		logger.info("getNextNumberFromSequenceFile()-end");
		return value;
	}

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

}
