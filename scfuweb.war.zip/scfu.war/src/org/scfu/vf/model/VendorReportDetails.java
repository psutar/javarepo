/**
 * @author Prateek
 * Model for fetching values for report generation
 */
package org.scfu.vf.model;

public class VendorReportDetails {
	private String name;
	private String reference_no;
	private String vendor_code;
	private String status;
	private String creation_time;
	private String reversal_date;
	private String interest_ref_no;
	private String reversal_ref_no;

	private String interest_amount;
	private String txn_completed_time;
	private String org_debit_ref_no;

	private String transaction_amount;
	private String transaction_date;

	private String vendor_unique_code;
	private String allocated_limit;
	private String outstanding_limit;
	private String available_limit;
	private String limit_expiry_date;

	private String im_code;
	private String amount;
	

	private String invoice_no;
	private String invoice_date;
	private String file_no;
	private String credit_account_no;
	private String debit_account_no;
	private String transaction_amount_1;
	
	private String overdue_ref_no;
	private String no_of_days;
	private String overdue_amount;



	public String getInvoice_no() {
		return invoice_no;
	}

	public void setInvoice_no(String invoice_no) {
		this.invoice_no = invoice_no;
	}

	public String getInvoice_date() {
		return invoice_date;
	}

	public void setInvoice_date(String invoice_date) {
		this.invoice_date = invoice_date;
	}

	public String getFile_no() {
		return file_no;
	}

	public void setFile_no(String file_no) {
		this.file_no = file_no;
	}

	public String getCredit_account_no() {
		return credit_account_no;
	}

	public void setCredit_account_no(String credit_account_no) {
		this.credit_account_no = credit_account_no;
	}

	public String getDebit_account_no() {
		return debit_account_no;
	}

	public void setDebit_account_no(String debit_account_no) {
		this.debit_account_no = debit_account_no;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	// /////////////////////////////////////////////////////
	public String getIm_code() {
		return im_code;
	}

	public void setIm_code(String im_code) {
		this.im_code = im_code;
	}

	// //////////////////////////////////////////////////////////////////
	public String getAllocated_limit() {
		return allocated_limit;
	}

	public void setAllocated_limit(String allocated_limit) {
		this.allocated_limit = allocated_limit;
	}

	public String getOutstanding_limit() {
		return outstanding_limit;
	}

	public void setOutstanding_limit(String outstanding_limit) {
		this.outstanding_limit = outstanding_limit;
	}

	public String getAvailable_limit() {
		return available_limit;
	}

	public void setAvailable_limit(String available_limit) {
		this.available_limit = available_limit;
	}

	public String getLimit_expiry_date() {
		return limit_expiry_date;
	}

	public void setLimit_expiry_date(String limit_expiry_date) {
		this.limit_expiry_date = limit_expiry_date;
	}

	public String getVendor_unique_code() {
		return vendor_unique_code;
	}

	public void setVendor_unique_code(String vendor_unique_code) {
		this.vendor_unique_code = vendor_unique_code;
	}

	// ///////////////////////////////////////////////////////
	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}

	public String getTransaction_amount() {
		return transaction_amount;
	}

	public void setTransaction_amount(String transaction_amount) {
		this.transaction_amount = transaction_amount;
	}

	// ////////////////////////////////////////

	public String getOrg_debit_ref_no() {
		return org_debit_ref_no;
	}

	public void setOrg_debit_ref_no(String org_debit_ref_no) {
		this.org_debit_ref_no = org_debit_ref_no;
	}

	public String getTxn_completed_time() {
		return txn_completed_time;
	}

	public void setTxn_completed_time(String txn_completed_time) {
		this.txn_completed_time = txn_completed_time;
	}

	public String getInterest_amount() {
		return interest_amount;
	}

	public void setInterest_amount(String interest_amount) {
		this.interest_amount = interest_amount;
	}

	/*------------------------------------------------*/
	public String getReversal_ref_no() {
		return reversal_ref_no;
	}

	public void setReversal_ref_no(String reversal_ref_no) {
		this.reversal_ref_no = reversal_ref_no;
	}

	public String getInterest_ref_no() {
		return interest_ref_no;
	}

	public void setInterest_ref_no(String interest_ref_no) {
		this.interest_ref_no = interest_ref_no;
	}

	public String getReversal_date() {
		return reversal_date;
	}

	public void setReversal_date(String reversal_date) {
		this.reversal_date = reversal_date;
	}

	public String getCreation_time() {
		return creation_time;
	}

	public void setCreation_time(String creation_time) {
		this.creation_time = creation_time;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVendor_code() {
		return vendor_code;
	}

	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}

	public String getReference_no() {
		return reference_no;
	}

	public void setReference_no(String reference_no) {
		this.reference_no = reference_no;
	}

	public String getName() {

		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransaction_amount_1() {
		return transaction_amount_1;
	}

	public void setTransaction_amount_1(String transaction_amount_1) {
		this.transaction_amount_1 = transaction_amount_1;
	}

	public String getOverdue_ref_no() {
		return overdue_ref_no;
	}

	public void setOverdue_ref_no(String overdue_ref_no) {
		this.overdue_ref_no = overdue_ref_no;
	}

	public String getNo_of_days() {
		return no_of_days;
	}

	public void setNo_of_days(String no_of_days) {
		this.no_of_days = no_of_days;
	}

	public String getOverdue_amount() {
		return overdue_amount;
	}

	public void setOverdue_amount(String overdue_amount) {
		this.overdue_amount = overdue_amount;
	}
}
