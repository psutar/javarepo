package org.scfu.vf.model;


public class SlabDetails {
	private String code;
	private String minimumValue;
	private String maximumValue;
	private String status;
	private String paramOwnedBy;

	public String getParamOwnedBy() {
		return paramOwnedBy;
	}

	public void setParamOwnedBy(String paramOwnedBy) {
		this.paramOwnedBy = paramOwnedBy;
	}

	public String toString() {
		StringBuffer tempStringBuf = new StringBuffer();
		tempStringBuf.append("Code :");
		tempStringBuf.append(code);
		tempStringBuf.append(" | ");
		tempStringBuf.append("minimumValue :");
		tempStringBuf.append(minimumValue);
		tempStringBuf.append(" | ");
		tempStringBuf.append("maximumValue :");
		tempStringBuf.append(maximumValue);
		tempStringBuf.append(" | ");
		tempStringBuf.append("paramOwnedBy :");
		tempStringBuf.append(paramOwnedBy);
		tempStringBuf.append(" | ");
		tempStringBuf.append("status :");
		tempStringBuf.append(status);
		tempStringBuf.append(" | ");
		return tempStringBuf.toString();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMaximumValue() {
		return maximumValue;
	}

	public void setMaximumValue(String maximumValue) {
		this.maximumValue = maximumValue;
	}

	public String getMinimumValue() {
		return minimumValue;
	}

	public void setMinimumValue(String minimumValue) {
		this.minimumValue = minimumValue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
