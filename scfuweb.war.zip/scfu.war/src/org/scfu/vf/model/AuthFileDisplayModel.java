package org.scfu.vf.model;

public class AuthFileDisplayModel {

	private String fileNo;
	private String transactionNo;
	private String creationDate;
	private String reversalDate;
	private String imCode;
	private String vendorCode;

	public String getVendorCode() {
		return vendorCode;
	}

	public void setVendorCode(String vendorCode) {
		this.vendorCode = vendorCode;
	}

	public String getImCode() {
		return imCode;
	}

	public void setImCode(String imCode) {
		this.imCode = imCode;
	}

	public String getFileNo() {
		return fileNo;
	}

	public void setFileNo(String fileNo) {
		this.fileNo = fileNo;
	}

	public String getTransactionNo() {
		return transactionNo;
	}

	public void setTransactionNo(String transactionNo) {
		this.transactionNo = transactionNo;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getReversalDate() {
		return reversalDate;
	}

	public void setReversalDate(String reversalDate) {
		this.reversalDate = reversalDate;
	}

}
