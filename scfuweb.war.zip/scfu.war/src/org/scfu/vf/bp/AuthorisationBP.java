package org.scfu.vf.bp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.common.exception.DAOException;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;
import org.scfu.vf.model.AuthFileDisplayModel;
import org.scfu.vf.model.SlabDetails;

public class AuthorisationBP {
	
	 protected final Logger logger = Logger.getLogger(getClass());
	 private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;
	 
	public boolean validate(Map inParams,String transactionNo) 
    {	 
		logger.info("validate "+SCFUConstants.METHOD_BEGINS);
		Date creationDate = null;
    	Date today = null;
        boolean checkFlag =true ;
        AuthFileDisplayModel authFileDisplayModel = null;
        String userName = (String) inParams.get("userName");
        logger.info("userName : "+ userName);
        logger.info("transactionNo : "+ transactionNo);
        
        String reversal_based_on = authoriseFileTxnDAOImpl.getReversalBasedOn((String) inParams.get("imCode"));      
        authFileDisplayModel = authoriseFileTxnDAOImpl.findTxnValidationDetails(transactionNo);
        logger.info("authFileDisplayModel : " +authFileDisplayModel);
            
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        try{
        creationDate = df.parse(authFileDisplayModel.getCreationDate());
        today = new Date();
        }catch (ParseException pe) {
        	logger.error("ParseException");
        	DAOException.throwException("TechnicalProblem");
        } catch (Exception ex){
        	logger.error("Exception");
        	DAOException.throwException("TechnicalProblem");
        }
                
        if(creationDate.compareTo(today)!=0 )
        {
        if("REVERSAL_DATE".equalsIgnoreCase(reversal_based_on))
        { 
        logger.info("Rversal Based On : " +reversal_based_on);       
        if (authFileDisplayModel != null && authFileDisplayModel.getTransactionNo() != null)
        {
            String reversalDateChk="false";
            if (authFileDisplayModel.getReversalDate()!=null && authFileDisplayModel.getReversalDate().trim().length() > 0){
            	reversalDateChk="true";
            }
            logger.info("reversalDateChk status is : "+reversalDateChk);
        	if (authFileDisplayModel.getFileNo()!=null && reversalDateChk.equalsIgnoreCase("true")){
        		checkFlag = validateFileModeTxn(authFileDisplayModel.getImCode(), authFileDisplayModel.getVendorCode(), authFileDisplayModel.getReversalDate());       		
        	}
          }       
        }
        }else {
        	checkFlag = false;
        	logger.error("Transaction creation Date is not equal to Authorisation Date");
        }    
        logger.info("validate "+ SCFUConstants.METHOD_ENDS);
        return checkFlag;
    }
	
	public boolean validateFileModeTxn(String imCode, String vendorCode, String reversalDate){
		
    	logger.info("validateFileModeTxn " + SCFUConstants.METHOD_BEGINS + imCode +" / "+vendorCode+" / "+reversalDate);
    	boolean flag = true;
    	
		
    	SlabDetails  slabDetails= authoriseFileTxnDAOImpl.findOverridDetails(imCode,vendorCode,"");

		
		int creditPeriod = 0;
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		 try {
	            Date revDate = df.parse(reversalDate); 
	            Date today = new Date();
	            creditPeriod = Integer.parseInt(Long.toString((revDate.getTime() - today.getTime())/(24*60*60*1000)));
	            logger.info("formatted Reversal Date : " + df.format(revDate) +"   CP is : "+creditPeriod);
	        } catch (ParseException pe) {
	        	logger.error("ParseException");
	        	DAOException.throwException("TechnicalProblem");
	        } catch (Exception ex){
	        	logger.error("Exception");
	        	DAOException.throwException("TechnicalProblem");
	        }
	        int maxTenorDays = Integer.parseInt(slabDetails.getMaximumValue());
			int minTenorDays = Integer.parseInt(slabDetails.getMinimumValue());
			logger.info("maxTenorDays / minTenorDays are : "+maxTenorDays +" / "+minTenorDays);
			if (creditPeriod < minTenorDays || creditPeriod > maxTenorDays){
				logger.error("Credit period is not between Min and Max days.");	
				flag=false;
				return flag;
			}
			logger.info("validateFileModeTxn"+ SCFUConstants.METHOD_ENDS);
    	return flag;
    }
	

	public void setAuthoriseFileTxnDAOImpl(
			AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}
}
