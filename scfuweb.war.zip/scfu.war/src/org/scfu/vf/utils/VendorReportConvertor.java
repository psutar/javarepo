package org.scfu.vf.utils;
import java.util.Map;

public abstract class VendorReportConvertor {
	public abstract String convert( Map<String, Object> input,String fileName );
}
