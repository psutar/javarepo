package org.scfu.vf.utils;

public class VendorOverdueReportConvertorFactory {
	private VendorReportConvertor consignmentOverdueReportConvertor;

	public VendorReportConvertor getConvertor(String reportType) {
		if (reportType.equalsIgnoreCase("consignmentWiseReport"))
			return consignmentOverdueReportConvertor;

		else
			return null;
	}
	public void setConsignmentOverdueReportConvertor(
			VendorReportConvertor consignmentOverdueReportConvertor) {
		this.consignmentOverdueReportConvertor = consignmentOverdueReportConvertor;
	}
}
