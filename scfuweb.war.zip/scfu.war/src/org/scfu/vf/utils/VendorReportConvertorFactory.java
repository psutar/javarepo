/**
* DESRIPTION : Returns the Report Convertor based on the reportType
 * @param reportType
 * @return
*/
package org.scfu.vf.utils;

public class VendorReportConvertorFactory {

	private VendorReportConvertor consignmentReportConvertor;

	public VendorReportConvertor getConvertor(String reportType) {
		if (reportType.equalsIgnoreCase("consignmentWiseReport"))
			return consignmentReportConvertor;

		else
			return null;
	}

	public void setConsignmentReportConvertor(
			VendorReportConvertor consignmentReportConvertor) {
		this.consignmentReportConvertor = consignmentReportConvertor;
	}

}
