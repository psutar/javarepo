/**
 * @author Prateek
 * This method is called from the 1st login jsp as a DWR call for checking
 * any duplicate username while changing the username for the 1st time after 
 * logging in 
 */
package org.scfu.vf.utils;

import org.apache.log4j.Logger;
import org.scfu.common.dao.LoginDAO;
import org.scfu.common.constants.SCFUConstants;

public class VendorTxnUtils {

	protected Logger logger = Logger.getLogger(getClass());
	private LoginDAO loginDAO;

	public int checkUserName(String userName) {
		logger.info("checkUsername" + SCFUConstants.METHOD_BEGINS);
		int count = loginDAO.checkUsername(userName);
		logger.info("checkUsername" + SCFUConstants.METHOD_ENDS);
		return count;
	}

	public void setLoginDAO(LoginDAO loginDAO) {
		this.loginDAO = loginDAO;
	}

}
