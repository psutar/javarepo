package org.scfu.vf.utils;


import org.displaytag.decorator.TableDecorator;
import org.scfu.vf.model.FileUploadStatusDetails;

public class FileUploadStatusWrapper extends TableDecorator
{

	public String getFile_name()
	{
		FileUploadStatusDetails fileUploadStatusDetails = (FileUploadStatusDetails) super.getCurrentRowObject();
		String file_name = null;
		if( fileUploadStatusDetails != null )
		{
			if(fileUploadStatusDetails.getFile_name()!= null || fileUploadStatusDetails.getFile_name()!= ""){
				file_name = fileUploadStatusDetails.getFile_name();
			}
		}
		return file_name;
	}

	public String getCreation_time()
	{
		FileUploadStatusDetails fileUploadStatusDetails = (FileUploadStatusDetails) super.getCurrentRowObject();
		String creation_time = null;
		if( fileUploadStatusDetails != null )
		{
			if(fileUploadStatusDetails.getCreation_time()!= null || fileUploadStatusDetails.getCreation_time()!= ""){
				creation_time = fileUploadStatusDetails.getCreation_time();
			}
		}
		return creation_time;
	}

	public String getStatus()
	{
		FileUploadStatusDetails fileUploadStatusDetails = (FileUploadStatusDetails) super.getCurrentRowObject();
		String status = null;
		if( fileUploadStatusDetails != null )
		{
			if(fileUploadStatusDetails.getStatus()!= null || fileUploadStatusDetails.getStatus()!= ""){
				status = fileUploadStatusDetails.getStatus();
			}
		}
		return status;
	}
	
	public String getFile_no()
	{
		FileUploadStatusDetails fileUploadStatusDetails = (FileUploadStatusDetails) super.getCurrentRowObject();
		String file_no = null;
		if( fileUploadStatusDetails != null )
		{
			if(fileUploadStatusDetails.getFile_no()!= null || fileUploadStatusDetails.getFile_no()!= ""){
				file_no = fileUploadStatusDetails.getFile_no();
			}
		}
		return file_no;
	}

	/*public String get<insert>()
	{
		FileUploadStatusDetails fileUploadStatusDetails = (FileUploadStatusDetails) super.getCurrentRowObject();
		String <insert> = null;
		if( fileUploadStatusDetails != null )
		{
			if(fileUploadStatusDetails.get<insert>()!= null || fileUploadStatusDetails.get<insert>()!= ""){
				<insert> = fileUploadStatusDetails.get<insert>();
			}
		}
		return <insert>;
	}*/
	/*end of class*/		
}

