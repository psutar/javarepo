/**
 * ConsignmentPDFConvertor
 * Description: This Convertort  class is created to print PDF in landscape format and also variation in font size 
 * compare to the General PDFConvertor.It contains the style as defined in itext.jar.
 * author Prateek
 */
package org.scfu.vf.utils;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.log4j.Logger;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageLabels;
import com.lowagie.text.pdf.PdfWriter;

public class ConsignmentPDFConverter
 {
	public Document document = null;
	public PdfPTable t2;
	private Integer columnSize;
	public PdfPageLabels p;
	protected final Logger logger = Logger.getLogger(getClass());
	// Font Size is changed
	public Font font1 = new Font(Font.HELVETICA, 6, Font.BOLD);
	public Font font2 = new Font(Font.HELVETICA, 6);
	public Font font3 = new Font(Font.HELVETICA, 10, Font.BOLD, Color.black);

	public void addPara(String para) {
		logger.info("addPara(String para)  .. " + para);
		try {
			document.add(new Paragraph(para));
			// String tempStr;

			t2.getDefaultCell().setPadding(3);
			// int headerwidths[columnSize.intValue()];

			if (columnSize != null && columnSize.intValue() == 8) {
				// int headerwidths1[] = {6,14,30,8,10,12,25,25}; // percentage
				// t2.setWidths(headerwidths1);
				t2.setWidthPercentage(130); // percentage
				t2.getDefaultCell().setBorderWidth(2);
				t2.getDefaultCell()
						.setHorizontalAlignment(Element.ALIGN_CENTER);

			} else {
				// int headerwidths2[] = {10,10,25,15,12,12,15};
				// int headerwidths2[] = {25,25,50};
				// t2.setWidths(headerwidths2);
				t2.setWidthPercentage(100); // percentage
				t2.getDefaultCell().setBorderWidth(1);
				t2.getDefaultCell()
						.setHorizontalAlignment(Element.ALIGN_CENTER);
			}

		} catch (Exception de) {
			logger.error(de.getMessage());
		}
	}

	public void addLabelLeft(String txtDisplay) {
		// logger.error("addLabelLeft(String para)  .. " + txtDisplay);
		Phrase phrase4 = new Phrase(txtDisplay, font1);
		PdfPCell cell4 = new PdfPCell(phrase4);
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		t2.addCell(cell4);
	}

	/* Added Prateek */
	public void addPageLabel(String txtDisplay) {
		document.addCreator(txtDisplay);
	}

	public void addLabelRight(String txtDisplay) {
		logger.info("addLabelRight(String para)  .. " + txtDisplay);
		Phrase phrase3 = new Phrase(txtDisplay, font1);
		PdfPCell cell3 = new PdfPCell(phrase3);
		cell3.setHorizontalAlignment(Element.ALIGN_RIGHT);
		t2.addCell(cell3);
	}

	public void endTableHeader() {
		logger.info("endTableHeader..");
		t2.setHeaderRows(1); // this is the end of the table header
		t2.getDefaultCell().setBorderWidth(1);
	}

	public void addValueLeft(String txtDisplay) {
		try {
			// logger.info("addValueLeft(String txtDisplay)  .. " + txtDisplay);
			Phrase phraseChk = new Phrase(txtDisplay, font2);
			PdfPCell cellChk = new PdfPCell(phraseChk);
			cellChk.setHorizontalAlignment(Element.ALIGN_LEFT);
			// cellChk.setHorizontalAlignment(Element.ALIGN_CENTER);
			// int headerwidths1[] = {8,8,20};

			t2.addCell(cellChk);
			t2.setWidthPercentage(105);
			// t2.setWidths(headerwidths1);
		} catch (Exception de) {
			logger.error(de.getMessage());
		}

	}

	public void addValueRight(String txtDisplay) {
		Phrase phraseChk = new Phrase(txtDisplay, font2);
		PdfPCell cellChk = new PdfPCell(phraseChk);
		cellChk.setHorizontalAlignment(Element.ALIGN_RIGHT);
		t2.addCell(cellChk);
	}

	public void addValueCenter(String txtDisplay) {
		Phrase phraseChk = new Phrase(txtDisplay, font2);
		PdfPCell cellChk = new PdfPCell(phraseChk);
		cellChk.setHorizontalAlignment(Element.ALIGN_CENTER);
		t2.addCell(cellChk);
	}

	public void addTablePara(Table table) {
		try {
			document.add(table);
		} catch (Exception de) {
			logger.error(de.getMessage());
		}
	}

	public void addPdfTableFromJSP() {

		addPdfPTable(t2);
	}

	public Integer getColumnSize() {
		return columnSize;
	}

	public void setColumnSize(Integer columnSize) {
		this.columnSize = columnSize;
		t2 = new PdfPTable(columnSize.intValue());
	}

	/**
	 * 
	 * The below method is used to print the pdf in landscape format 
	 * author prateek
	 * 
	 */

	public String pdfCreateFile(String fileName) {
		try {

			document = new Document(PageSize.A4.rotate());
			PdfWriter.getInstance(document, new FileOutputStream(fileName));

			document.open();

		} catch (IOException ioe) {
			logger.error(ioe.getMessage());
		}

		catch (Exception de) {
			logger.error(de.getMessage());
		}
		return "Success";
	}

	public String pdfCreateFile(OutputStream outputStream) {
		try {
			document = new Document();
			PdfWriter.getInstance(document, outputStream);
			document.open();

		} catch (Exception de) {
			logger.error(de.getMessage());
		}
		return "Success";
	}

	public void addPdfPTable(PdfPTable pdfpTable) {
		try {
			document.add(pdfpTable);

		} catch (Exception de) {

			logger.error(de.getMessage());
		}
	}

	public void addText(String para) {
		try {
			document.add(new Paragraph(para));
		} catch (DocumentException de) {
			logger.error(de.getMessage());
		}

	}

	/* Added by Prateek for heading in reports */
	public void addPDFHeading(String para) {
		try {
			Phrase phraseChk = new Phrase(para, font3);
			document.add(phraseChk);
		} catch (DocumentException de) {
			logger.error(de.getMessage());
		}
	}

	/*
	 * public void addPDFHeadingDate(String para) { try { Phrase phraseChk = new
	 * Phrase(para,font3); document.add(phraseChk); } catch(DocumentException
	 * de) { logger.error(de.getMessage()); } }
	 */
	public void addPdfImage(String pict) {
		try {
			Image logo = Image.getInstance(pict);
			// logger.info("logo image size: "+logo);
			logo.scalePercent(75, 75);
			document.add(logo);
		} catch (Exception de) {
			// de.printStackTrace();
			logger.error(de.getMessage());
		}
	}

	/*
	 * public void onEndPage(String fileName ) {
	 * 
	 * try { PdfWriter writer= PdfWriter.getInstance(document, new
	 * FileOutputStream(fileName));
	 * logger.info("writer.getDirectContent()----------" +
	 * writer.getCurrentPageNumber() );
	 * 
	 * //logger.info("writer.getDirectContent()----------" +
	 * writer.getDirectContent() );
	 * ColumnText.showTextAligned(writer.getDirectContent
	 * (),Element.ALIGN_RIGHT,new Phrase(String.format("%d",
	 * writer.getPageNumber()),font2),50, 600, 0);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } }
	 */

	public void closeDocument() {
		try {
			document.close();
		} catch (Exception de) {
			logger.error(de.getMessage());
		}
	}

	// PPF challan
	public PdfPTable addChallanPara(String para, int columns,
			int widthPercentage, int[] headerWidths, int padding) {
		PdfPTable table = new PdfPTable(columns);
		try {
			document.add(new Paragraph(para));
			table.getDefaultCell().setPadding(padding);
			table.setWidths(headerWidths);
			table.setWidthPercentage(widthPercentage); // percentage
			// table.getDefaultCell().setBorder(0);
			// table.getDefaultCell().setBorderWidth(0.0f);
			// table.getDefaultCell().setBorderColor(Color.WHITE);
			table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		} catch (DocumentException de) {
			logger.error(de.getMessage());
		}
		return table;
	}

	public void addChallanLabelLeft(String txtDisplay, PdfPTable table,
			Boolean isWrap, Color borderColor, Color backgroundColor,
			float padding, Font font) {

		Phrase phrase4 = new Phrase(txtDisplay, font);
		PdfPCell cell4 = new PdfPCell(phrase4);
		cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
		cell4.setBorderColor(borderColor);
		cell4.setBorderWidth(1);
		cell4.setPadding(padding);
		cell4.setBackgroundColor(backgroundColor);
		cell4.setNoWrap(isWrap.booleanValue());
		table.addCell(cell4);
	}

	public void addChallanPdfTableFromJSP(PdfPTable table) {

		addPdfPTable(table);
	}

	public void endChallanTableHeader(PdfPTable table, int headerRows) {
		table.setHeaderRows(headerRows); // this is the end of the table header
		table.getDefaultCell().setBorderWidth(10);
	}

	public void nestTable(PdfPTable source, PdfPTable destination)
			throws Exception {
		source.addCell(destination);
	}
	// End PPF Challan

}
