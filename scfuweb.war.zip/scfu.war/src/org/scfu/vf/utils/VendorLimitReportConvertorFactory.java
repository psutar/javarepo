package org.scfu.vf.utils;

/**
 * @author Prateek
 * DESRIPTION : Returns the Report Convertor based on the reportType
 * reportType
 */
public class VendorLimitReportConvertorFactory {

	private VendorReportConvertor consignmentLimitReportConvertor;

	public VendorReportConvertor getConvertor(String reportType) {
		if (reportType.equalsIgnoreCase("consignmentWiseReport"))
			return consignmentLimitReportConvertor;

		else
			return null;
	}

	public void setConsignmentLimitReportConvertor(
			VendorReportConvertor consignmentLimitReportConvertor) {
		this.consignmentLimitReportConvertor = consignmentLimitReportConvertor;
	}
}
