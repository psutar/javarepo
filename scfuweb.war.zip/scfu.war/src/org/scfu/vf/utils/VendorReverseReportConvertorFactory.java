	/**
	 * DESRIPTION : Returns the Report Convertor based on the reportType
	 * @param reportType
	 * @return
	 */
package org.scfu.vf.utils;

public class VendorReverseReportConvertorFactory {

	private VendorReportConvertor consignmentReverseReportConvertor;

	public VendorReportConvertor getConvertor(String reportType) {
		if (reportType.equalsIgnoreCase("consignmentWiseReport"))
			return consignmentReverseReportConvertor;

		else
			return null;
	}

	public void setConsignmentReverseReportConvertor(
			VendorReportConvertor consignmentReverseReportConvertor) {
		this.consignmentReverseReportConvertor = consignmentReverseReportConvertor;
	}

}
