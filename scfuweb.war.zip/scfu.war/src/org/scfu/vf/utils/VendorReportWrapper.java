package org.scfu.vf.utils;

 
import org.displaytag.decorator.TableDecorator;
import org.scfu.vf.model.VendorReportDetails;

	public class VendorReportWrapper extends TableDecorator
	{

		public String getName()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String name = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getName()!= null || vendorReportDetails.getName()!= ""){
					name = vendorReportDetails.getName();
				}
			}
			return name;
		}
		
		public String getReference_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String reference_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getReference_no()!= null || vendorReportDetails.getReference_no()!= ""){
					reference_no = vendorReportDetails.getReference_no();
				}
			}
			return reference_no;
		}
		
		public String getVendor_code()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String vendor_code = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getVendor_code()!= null || vendorReportDetails.getVendor_code()!= ""){
					vendor_code = vendorReportDetails.getVendor_code();
				}
			}
			return vendor_code;
		}
		
		public String getStatus()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String status = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getStatus()!= null || vendorReportDetails.getStatus()!= ""){
					status = vendorReportDetails.getStatus();
				}
			}
			return status;
		}
		
		
		public String getCreation_time()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String creation_time = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getCreation_time() != null || vendorReportDetails.getCreation_time() != ""){
					creation_time = vendorReportDetails.getCreation_time();
				}
			}
			return creation_time;
		}
		
		
		public String getReversal_date()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String reversal_date = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getReversal_date()!= null || vendorReportDetails.getReversal_date()!= ""){
					reversal_date = vendorReportDetails.getReversal_date();
				}
			}
			return reversal_date;
		}
		
		public String getInterest_ref_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String interest_ref_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getInterest_ref_no()!= null || vendorReportDetails.getInterest_ref_no()!= ""){
					interest_ref_no = vendorReportDetails.getInterest_ref_no();
				}
			}
			return interest_ref_no;
		}
		
		public String getReversal_ref_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String reversal_ref_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getReversal_ref_no()!= null || vendorReportDetails.getReversal_ref_no()!= ""){
					reversal_ref_no = vendorReportDetails.getReversal_ref_no();
				}
			}
			return reversal_ref_no;
		}
		
		/*--------------------------------------------------------*/
		
		public String getInterest_amount()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String interest_amount = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getInterest_amount()!= null || vendorReportDetails.getInterest_amount()!= ""){
					interest_amount = vendorReportDetails.getInterest_amount();
				}
			}
			return interest_amount;
		}
		
		public String getTxn_completed_time()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String txn_completed_time = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getTxn_completed_time()!= null || vendorReportDetails.getTxn_completed_time()!= ""){
					txn_completed_time = vendorReportDetails.getTxn_completed_time();
				}
			}
			return txn_completed_time;
		}
		
		public String getOrg_debit_ref_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String org_debit_ref_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getOrg_debit_ref_no()!= null || vendorReportDetails.getOrg_debit_ref_no()!= ""){
					org_debit_ref_no = vendorReportDetails.getOrg_debit_ref_no();
				}
			}
			return org_debit_ref_no;
		}
		
		public String getTransaction_amount()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String transaction_amount = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getTransaction_amount()!= null || vendorReportDetails.getTransaction_amount()!= ""){
					transaction_amount = vendorReportDetails.getTransaction_amount();
				}
			}
			return transaction_amount;
		}
		
		public String getTransaction_amount_1()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String transaction_amount_1 = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getTransaction_amount_1()!= null || vendorReportDetails.getTransaction_amount_1()!= ""){
					transaction_amount_1 = vendorReportDetails.getTransaction_amount_1();
				}
			}
			return transaction_amount_1;
		}
		
		
		public String getVendor_unique_code()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String vendor_unique_code = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getVendor_unique_code()!= null || vendorReportDetails.getVendor_unique_code()!= ""){
					vendor_unique_code = vendorReportDetails.getVendor_unique_code();
				}
			}
			return vendor_unique_code;
		}
		
		public String getAllocated_limit()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String allocated_limit = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getAllocated_limit()!= null || vendorReportDetails.getAllocated_limit()!= ""){
					allocated_limit = vendorReportDetails.getAllocated_limit();
				}
			}
			return allocated_limit;
		}
		
		public String getOutstanding_limit()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String outstanding_limit = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getOutstanding_limit()!= null || vendorReportDetails.getOutstanding_limit()!= ""){
					outstanding_limit = vendorReportDetails.getOutstanding_limit();
				}
			}
			return outstanding_limit;
		}
		
		public String getAvailable_limit()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String available_limit = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getAvailable_limit()!= null || vendorReportDetails.getAvailable_limit()!= ""){
					available_limit = vendorReportDetails.getAvailable_limit();
				}
			}
			return available_limit;
		}
		
		public String getLimit_expiry_date()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String limit_expiry_date = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getLimit_expiry_date()!= null || vendorReportDetails.getLimit_expiry_date()!= ""){
					limit_expiry_date = vendorReportDetails.getLimit_expiry_date();
				}
			}
			return limit_expiry_date;
		}
		
		public String getIm_code()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String im_code = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getIm_code()!= null || vendorReportDetails.getIm_code()!= ""){
					im_code = vendorReportDetails.getIm_code();
				}
			}
			return im_code;
		}
		
		public String getAmount()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String amount = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getAmount()!= null || vendorReportDetails.getAmount()!= ""){
					amount = vendorReportDetails.getAmount();
				}
			}
			return amount;
		}
		
		
		public String getTransaction_date()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String transaction_date = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getTransaction_date()!= null || vendorReportDetails.getTransaction_date()!= ""){
					transaction_date = vendorReportDetails.getTransaction_date();
				}
			}
			return transaction_date;
		}
		
		public String getInvoice_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String invoice_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getInvoice_no()!= null || vendorReportDetails.getInvoice_no()!= ""){
					invoice_no = vendorReportDetails.getInvoice_no();
				}
			}
			return invoice_no;
		}
		
		public String getInvoice_date()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String invoice_date = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getInvoice_date()!= null || vendorReportDetails.getInvoice_date()!= ""){
					invoice_date = vendorReportDetails.getInvoice_date();
				}
			}
			return invoice_date;
		}
		public String getFile_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String file_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getFile_no()!= null || vendorReportDetails.getFile_no()!= ""){
					file_no = vendorReportDetails.getFile_no();
				}
			}
			return file_no;
		}
		public String getCredit_account_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String credit_account_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getCredit_account_no()!= null || vendorReportDetails.getCredit_account_no()!= ""){
					credit_account_no = vendorReportDetails.getCredit_account_no();
				}
			}
			return credit_account_no;
		}
		public String getDebit_account_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String debit_account_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getDebit_account_no()!= null || vendorReportDetails.getDebit_account_no()!= ""){
					debit_account_no = vendorReportDetails.getDebit_account_no();
				}
			}
			return debit_account_no;
		}
		
		/*public String get<insert>()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String <insert> = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.get<insert>()!= null || vendorReportDetails.get<insert>()!= ""){
					<insert> = vendorReportDetails.get<insert>();
				}
			}
			return <insert>;
		}*/
/*end of class*/		
		
		public String getOverdue_ref_no()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String overdue_ref_no = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getOverdue_ref_no()!= null || vendorReportDetails.getOverdue_ref_no()!= ""){
					overdue_ref_no = vendorReportDetails.getOverdue_ref_no();
				}
			}
			return overdue_ref_no;
		}
		
		public String getNo_of_days()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String no_of_days = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getNo_of_days()!= null || vendorReportDetails.getNo_of_days()!= ""){
					no_of_days = vendorReportDetails.getNo_of_days();
				}
			}
			return no_of_days;
		}
		
		public String getOverdue_amount()
		{
			VendorReportDetails vendorReportDetails = (VendorReportDetails) super.getCurrentRowObject();
			String overdue_amount = null;
			if( vendorReportDetails != null )
			{
				if(vendorReportDetails.getOverdue_amount()!= null || vendorReportDetails.getOverdue_amount()!= ""){
					overdue_amount = vendorReportDetails.getOverdue_amount();
				}
			}
			return overdue_amount;
		}
	}

