package org.scfu.vf.utils;

import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.vf.model.ReverseFileTransactionDetails;

public class FileConverter {
	protected Logger logger = Logger.getLogger(getClass());

	 public StringBuffer reversefileGenerate(Map<String,Object > inputParams)
	 {
		 logger.info("ReversefileGenerate Method Starts");
		 StringBuffer outBuffer = new StringBuffer();
		 StringBuffer detailsBuf = new StringBuffer(200);
		 List<ReverseFileTransactionDetails> transactionDetails = (List<ReverseFileTransactionDetails>) inputParams.get("getTransactionDetails");
		 outBuffer.append(detailsBuf + "\r\n");
		 if (transactionDetails != null && !transactionDetails.isEmpty()) {
			 logger.info("size of the Transactions" + transactionDetails.size());
			 for (ReverseFileTransactionDetails reverseFileTransactionDetail : transactionDetails) {
				 detailsBuf.append(reverseFileTransactionDetail.getSpace());
				 detailsBuf.append(reverseFileTransactionDetail.getInvoiceNumber());
				 detailsBuf.append(reverseFileTransactionDetail.getCustomerRefNo());
				 detailsBuf.append(reverseFileTransactionDetail.getInvoiceAmt());
				 detailsBuf.append(reverseFileTransactionDetail.getVendorCode());
				 detailsBuf.append(reverseFileTransactionDetail.getStatus());
				 detailsBuf.append(reverseFileTransactionDetail.getReversalDate());
				 detailsBuf.append(reverseFileTransactionDetail.getInvoiceDate());
				 detailsBuf.append(reverseFileTransactionDetail.getUploadedFileName());
				 detailsBuf.append(reverseFileTransactionDetail.getTxnIdentifier());
				 detailsBuf.append("\r\n");
			 }
			 outBuffer.append(detailsBuf);
		 }
		 return outBuffer;
	 }
}
