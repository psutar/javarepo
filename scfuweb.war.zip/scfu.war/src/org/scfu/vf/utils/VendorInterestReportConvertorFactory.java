/**
 * @author Prateek
 * DESRIPTION : Returns the Report Convertor based on the reportType
 * reportType
 */
package org.scfu.vf.utils;

public class VendorInterestReportConvertorFactory {

	private VendorReportConvertor consignmentInterestReportConvertor;

	public VendorReportConvertor getConvertor(String reportType) {
		if (reportType.equalsIgnoreCase("consignmentWiseReport"))
			return consignmentInterestReportConvertor;

		else
			return null;
	}
	public void setConsignmentInterestReportConvertor(
			VendorReportConvertor consignmentInterestReportConvertor) {
		this.consignmentInterestReportConvertor = consignmentInterestReportConvertor;
	}
}
