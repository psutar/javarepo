/**
 * @author Padma
 * Generates reverse file
 */
package org.scfu.vf.handler;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.utils.FileConverter;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


@SuppressWarnings({"rawtypes","unchecked"})


public class GenerateReverseFileHandler extends MultiActionController {
	
	protected final Logger logger = Logger.getLogger(getClass());
	private BaseService generateReverseFileDisplayService;
	private BaseService generateReverseFileDetailsService;
	private String reverseFileSaveUrl;
	private FileConverter fileConverter;

	public ModelAndView getDateRange(HttpServletRequest request, HttpServletResponse response) throws Exception {	
			logger.info("getDateRange " +SCFUConstants.METHOD_BEGINS);		
			Map outParams = new HashMap();	
			logger.info("getDateRange " +SCFUConstants.METHOD_ENDS);
			return new ModelAndView("imgeneratereversefiledaterange","outputParams",outParams);
	}
	
	public ModelAndView displayGenerateReverseFile(HttpServletRequest request, HttpServletResponse response) throws Exception {			
			logger.info("displayGenerateReverseFile " +SCFUConstants.METHOD_BEGINS);
			HttpSession session = request.getSession(false);
			Map inputParams = new HashMap();
			Map outParams = new HashMap();			
			String imCode = (String) session.getAttribute("imCode");
			String fromDate = (String) request.getParameter("startDate");
			String toDate = (String) request.getParameter("endDate");			
			inputParams.put("imCode", imCode);
			inputParams.put("fromDate", fromDate);
			inputParams.put("toDate", toDate);
			outParams = generateReverseFileDisplayService.execute(inputParams);
			outParams.put(SCFUConstants.ERROR_VIEW, "generateReverseFileError");
			logger.info("outParams" +outParams);
			logger.info("displayGenerateReverseFile " +SCFUConstants.METHOD_ENDS);
			return new ModelAndView("imgeneratereversefiledisplay","outputParams",outParams);
		}
		
	 public ModelAndView generateReverseFile (HttpServletRequest request, HttpServletResponse response) throws Exception {
		 	logger.info("generateReverseFile" +SCFUConstants.METHOD_BEGINS);
			Map inputParams = new HashMap();
			Map outParams = new HashMap();		
			StringBuffer textBuffer = new StringBuffer(200);
			String fileName = (String) request.getParameter("fileName");		
			String fileStatus = (String) request.getParameter("fileStatus");
			String creationDate = (String) request.getParameter("creationDate");
			String imCode=(String)request.getParameter("imCode");
			String fileNo = (String) request.getParameter("fileNo");
			SimpleDateFormat dateFormat=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat.format(new Date());
			inputParams.put("fileName", fileName);		
		    inputParams.put("fileStatus",fileStatus);
			inputParams.put("creationDate",creationDate);
			inputParams.put("imCode",imCode);
			inputParams.put("fileNo", fileNo);	
		    String filePath =null;
			PrintWriter pw=null;
			
			fileName = "P_".concat(myDateString1) + SCFUConstants.DOT + SCFUConstants.TXT_EXTENSION;
			filePath=reverseFileSaveUrl+fileName;
			
			logger.info("FilePath : "+filePath);
			outParams=generateReverseFileDetailsService.execute(inputParams);
			outParams.put("imCode",imCode);
			outParams.put(SCFUConstants.ERROR_VIEW, "generateReverseFileError");
	        logger.info(" No: of Transactions : "+outParams.get("getTransactionDetails"));
	        textBuffer=fileConverter.reversefileGenerate(outParams);
	        logger.info("before writing file: "+System.currentTimeMillis());
	        pw= new PrintWriter(new BufferedWriter(new FileWriter(new File(filePath))));
	        pw.write(textBuffer.toString());
	        logger.info("after writing file: "+System.currentTimeMillis());
	        pw.close();
     
			logger.info("outParams" +outParams);
			try{
	 			  response.setContentType("application/OCTET-STREAM");
	 			  logger.info("writing o/p stream"+System.currentTimeMillis());
	 			  InputStream in = new FileInputStream(new File(filePath));
	 		    	byte [] chars = new byte[in.available()];
	 		    	in.read(chars);
	 		    	in.close();
	 		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
	 		    	OutputStream outputStream = response.getOutputStream();
	 		    	logger.info("writing o/p stream2"+System.currentTimeMillis());
	 		    	outputStream.write(chars);
	 		    	logger.info("writing o/p stream3"+System.currentTimeMillis());
	 		    	outputStream.flush();
	 		    	outputStream.close();
	 		}	     
	 		catch (Exception e) {
	 			logger.error("Exception occured : ",e); 			
	 		}	     	
			logger.info("generateReverseFile" +SCFUConstants.METHOD_ENDS);
			return null;
		 
	 }
	public void setReverseFileSaveUrl(String reverseFileSaveUrl) {
		this.reverseFileSaveUrl = reverseFileSaveUrl;
	}

	public void setGenerateReverseFileDisplayService(
			BaseService generateReverseFileDisplayService) {
		this.generateReverseFileDisplayService = generateReverseFileDisplayService;
	}
	public void setGenerateReverseFileDetailsService(
			BaseService generateReverseFileDetailsService) {
		this.generateReverseFileDetailsService = generateReverseFileDetailsService;
	}
	public void setFileConverter(FileConverter fileConverter) {
		this.fileConverter = fileConverter;
	}	
}