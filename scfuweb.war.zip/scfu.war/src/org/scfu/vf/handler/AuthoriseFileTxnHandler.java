/*
 * For transaction authorisation.
 */
package org.scfu.vf.handler;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

@SuppressWarnings({"unchecked","rawtypes"})
public class AuthoriseFileTxnHandler extends MultiActionController {
	protected final Logger logger = Logger.getLogger(getClass());

	private BaseService displayFileTxnService;
	private BaseService viewTxnFileDetailsService;
	private BaseService viewTxnCountDetailsService;
	private BaseService confirmAuthoriseFileDetailsService;
	private BaseService confirmRejectFileDetailsService;

	/**
	 *Used to list the files for Authorisation.
	 */
	public ModelAndView displayAuthorisationFile(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("displayAuthorisationFile " + SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		String imCode = (String) session.getAttribute("imCode");
		String userName = (String) session.getAttribute("userName");
		logger.info("displayAuthorisationFile imCode : " + imCode + "UserName : "	+ userName);
		inputParams.put("imCode", imCode);
		inputParams.put("userName", userName);
		outputParams = displayFileTxnService.execute(inputParams);
		outputParams.put("errorView", "errorvffileauthoriseDetails");
		logger.info("outputParams : " + outputParams);
		logger.info("displayAuthorisationFile " + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("authoriseFileDisplay", "outputParams", outputParams);
	}

	/**
	 *Displays the Authorisation file details.
	 */
	public ModelAndView viewAuthorisationFileDetails(
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {
		logger.info("viewAuthorisationFileDetails"+ SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		Map txnCountDetails = new HashMap();
		String fileNo = request.getParameter("fileNo");
		String creationTime = request.getParameter("creationTime");
		logger.info("Transaction details for File No :" + fileNo);
		inputParams.put("fileNo", fileNo);
		inputParams.put("creationTime", creationTime);
		inputParams.put("userName", (String) session.getAttribute("userName"));
		outputParams = viewTxnFileDetailsService.execute(inputParams);
		logger.info("Transaction details : " + outputParams);
		txnCountDetails = viewTxnCountDetailsService.execute(inputParams);
		outputParams.put("txnCountDetails", txnCountDetails);
		logger.info("Transaction Count : " + outputParams);
		outputParams.put(SCFUConstants.ERROR_VIEW, "authoriseErrorView");
		logger.info("viewAuthorisationFileDetails " + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("viewauthorisefiledetails", "outputParams", outputParams);
	}

	/**
      * Called when authorising the transactions.
       */
	public ModelAndView confirmAuthorisationFileDetails(
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {
		logger.info("confirmAuthorisationFileDetails "+ SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		String[] transaction_No = request.getParameterValues("txnEcheque");
		logger.info("transaction_No : " + transaction_No);
		inputParams.put("transaction_No", transaction_No);
		String userName = (String) session.getAttribute("userName");
		String imCode = (String) session.getAttribute("imCode");
		inputParams.put("userName", userName);
		inputParams.put("imCode", imCode);
		outputParams = confirmAuthoriseFileDetailsService.execute(inputParams);
		outputParams.put(SCFUConstants.ERROR_VIEW, "authoriseErrorView");
		logger.info("outputParams:" + outputParams);
		logger.info("confirmAuthorisationFileDetails"+ SCFUConstants.METHOD_ENDS);
		return new ModelAndView("confirmauthorisefiledetails", "outputParams", outputParams);
	}
	/**
     * Called when rejecting the transactions.
      */
	public ModelAndView confirmRejectionFileDetails(HttpServletRequest request,
		HttpServletResponse response) {
		logger.info("confirmRejectionFileDetails "+ SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		String[] transaction_No = request.getParameterValues("txnEcheque");
		String rejectreason = request.getParameter("rejectReason1");
		inputParams.put("rejectreason", rejectreason);
		inputParams.put("transaction_No", transaction_No);
		String userName = (String) session.getAttribute("userName");
		inputParams.put("userName", userName);
		outputParams = confirmRejectFileDetailsService.execute(inputParams);
		outputParams.put("rejectreason", rejectreason);
		outputParams.put(SCFUConstants.ERROR_VIEW, "authoriseErrorView");
		logger.info("outputParams:" + outputParams);
		logger.info("confirmRejectionFileDetails" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("confirmrejectfiledetails", "outputParams",	outputParams);
	}

	public void setDisplayFileTxnService(BaseService displayFileTxnService) {
		this.displayFileTxnService = displayFileTxnService;
	}
	public void setViewTxnFileDetailsService(
			BaseService viewTxnFileDetailsService) {
		this.viewTxnFileDetailsService = viewTxnFileDetailsService;
	}
	public void setViewTxnCountDetailsService(
			BaseService viewTxnCountDetailsService) {
		this.viewTxnCountDetailsService = viewTxnCountDetailsService;
	}
	
	public void setConfirmAuthoriseFileDetailsService(
			BaseService confirmAuthoriseFileDetailsService) {
		this.confirmAuthoriseFileDetailsService = confirmAuthoriseFileDetailsService;
	}
	
	public void setConfirmRejectFileDetailsService(
			BaseService confirmRejectFileDetailsService) {
		this.confirmRejectFileDetailsService = confirmRejectFileDetailsService;
	}
}