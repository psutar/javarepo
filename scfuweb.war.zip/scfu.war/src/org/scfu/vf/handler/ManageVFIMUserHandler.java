package org.scfu.vf.handler;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.scfu.vf.service.AddVFIMUserService;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.model.UserProfile;
import org.scfu.common.utils.RndString;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
@SuppressWarnings({"rawtypes","unchecked"})
public class ManageVFIMUserHandler extends MultiActionController {

	protected final Logger logger = Logger.getLogger(getClass());
	private AddVFIMUserService addVFIMUserService;

	private RndString rndString;


	public ModelAndView displayaddVFIMUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("displayaddVFIMUser "+SCFUConstants.METHOD_BEGINS);
		Map<String, String> loginData = new HashMap<String, String>();
		String keyString = rndString.getRamdom();
		loginData.put("keyString", keyString);
		HttpSession session = request.getSession();
		logger.info("loginData :" + loginData);
		logger.info("Session :" + session);
		logger.info("addIM  "+SCFUConstants.METHOD_ENDS);
		return new ModelAndView("addVFIMUser");
	}

	public ModelAndView addVFIMUserConfirm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addIMUserConfirm  "+SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession();
		Map inParams = new HashMap();
		Map outParams = new HashMap();
		UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
		String imCode= (String) userProfile.getImCode();
		String userName= (String) userProfile.getUserName();
		logger.info("IMCODE :"+imCode);
		SCFUApplicationResponse responses=new SCFUApplicationResponse();
		responses.setErrorStatus(SCFUConstants.FAILURE);
		String userid=RndString.getRandomId();
		String password=RndString.getRandomString();
		logger.info(userid);
		session.setAttribute("imcode",imCode);
		session.setAttribute("user_id",userid);
		String imUserType=(String)request.getParameter("radio1");
		//session.setAttribute("pwd", password);
		inParams.put("login_id",userid);
		inParams.put("password", password);
		inParams.put("imcode", session.getAttribute("imcode"));
		inParams.put("type", imUserType);
		inParams.put("name", request.getParameter("name"));
		inParams.put("nickname", request.getParameter("nickname"));
		inParams.put("address", request.getParameter("address"));
		inParams.put("address2", request.getParameter("address2"));
		inParams.put("city", request.getParameter("city"));
		inParams.put("district", request.getParameter("district"));
		inParams.put("state", request.getParameter("state"));
		inParams.put("country", request.getParameter("country"));
		inParams.put("pincode", request.getParameter("pincode"));
		inParams.put("email", request.getParameter("email"));
		inParams.put("phone", request.getParameter("phone"));
		inParams.put("mobile", request.getParameter("mobile"));
		inParams.put("userName", userName);
		if( !(("5".equalsIgnoreCase(imUserType))||("6".equalsIgnoreCase(imUserType))  ))
		{
			responses.setErrorCode("TechnicalProblem");
			outParams.put(SCFUConstants.APPLICATION_RESPONSE, responses);
			outParams.put(SCFUConstants.ERROR_VIEW, "addIMUserFailure");
			return new ModelAndView("addIMUserFailure", SCFUConstants.OUTPUT_PARAMS, outParams);
		}
		
		outParams = addVFIMUserService.execute(inParams);
		SCFUApplicationResponse applicationresponse = (SCFUApplicationResponse) outParams
		.get(SCFUConstants.APPLICATION_RESPONSE);
		outParams.put("userid", userid);
		outParams.put("password", password);
		logger.info("outParams :"+outParams );
		if(applicationresponse!=null && (applicationresponse.getErrorStatus()).equalsIgnoreCase("success"))
		{
			//getServletContext().getRequestDispatcher().forward(request,response);
			return new ModelAndView("addIMUserConfirm", SCFUConstants.OUTPUT_PARAMS, outParams);
		}
		else
		{
			logger.info("addIMUserConfirm  "+SCFUConstants.METHOD_ENDS);
			return new ModelAndView("addIMUserFailure", "outParams", outParams);
		}
	}
	public void setAddVFIMUserService(AddVFIMUserService addVFIMUserService) {
		this.addVFIMUserService = addVFIMUserService;

	}
	public void setRndString(RndString rndString) {
		this.rndString = rndString;
	}

}
