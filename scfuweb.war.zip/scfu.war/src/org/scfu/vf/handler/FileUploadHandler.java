package org.scfu.vf.handler;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.model.UserProfile;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

@SuppressWarnings({"unchecked","rawtypes"})
public class FileUploadHandler extends MultiActionController {
	   protected final Logger logger = Logger.getLogger(getClass());
	   private BaseService fileUploadConfirmService;
	   private BaseService viewTransactionDetailsService;
	   private BaseService viewFileDetailsService;
	  
	public ModelAndView fileUploadDisplay(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("fileUploadDisplay" + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse responses = new SCFUApplicationResponse();
		System.out.println("fileUploadDisplay method starts");
		Map<String, SCFUApplicationResponse> outParams = new HashMap<String, SCFUApplicationResponse>();
		responses.setErrorStatus(SCFUConstants.SUCCESS);
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, responses);
		logger.info("fileUploadDisplay" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("fileUpload", "outParams", outParams);
	}
	  
	public ModelAndView fileUploadConfirm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("fileUploadConfirm" + SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
		String imCode = (String) userProfile.getImCode();
		String userName = (String) userProfile.getUserName();
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
		logger.info("after multipartHttpServletRequest :"+ multipartHttpServletRequest);
		CommonsMultipartFile file = (CommonsMultipartFile) multipartHttpServletRequest.getFile("uploadedFile");
		inputParams.put("file", file);
		inputParams.put("imCode", imCode);
		inputParams.put(SCFUConstants.USER_NAME, userName);
		String orginalFileName  = file.getOriginalFilename();
		inputParams.put("fileName", orginalFileName);
		
		String fileType = orginalFileName.substring(orginalFileName.length() - 4, orginalFileName.length());
	    logger.info("Orginal File Name: " + orginalFileName+", file type:" + fileType); 
		SCFUApplicationResponse applicationResponse = new SCFUApplicationResponse();
        applicationResponse.setErrorStatus("FAILURE");
        
	    if (file.getSize() > 0){
	    	if (fileType != null && fileType.equalsIgnoreCase(".txt")){
	    		outputParams = fileUploadConfirmService.execute(inputParams);
	    	}else{
	    		outputParams.put("applicationResponse", applicationResponse);	
	    		applicationResponse.setErrorCode("txtFileType");
	    	}
	    }
		logger.info("In Params :" + inputParams);
		outputParams.put("errorView", "errorvendoruploadfileconfirm");
		logger.info("fileUploadConfirm" + SCFUConstants.METHOD_ENDS);
		return new ModelAndView("imuploadfileconfirm", "outputParams", outputParams);
	}
		
		public ModelAndView viewTransactionDetails(HttpServletRequest request,HttpServletResponse response) throws IOException {
			logger.info("viewTransactionDetails"+SCFUConstants.METHOD_BEGINS);
			Map inputParams = new HashMap();
			Map outputParams = new HashMap();	
			HttpSession session=request.getSession(false);
			UserProfile  userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
			String userName=(String) userProfile.getUserName();
			inputParams.put(SCFUConstants.USER_NAME, userName);
			logger.info("Input to service :"+inputParams);	
			outputParams = viewTransactionDetailsService.execute(inputParams);	
			outputParams.put("errorView","errordfTransactionDetails");
			List transactionDetailList = (List)outputParams.get("transactionDetailsList");
			session.setAttribute("transactionDetailList",transactionDetailList);
			logger.info("transactionDetailList : " + transactionDetailList);
			logger.info("outputParams = " + outputParams);
			logger.info("displayTransactionDetails"+SCFUConstants.METHOD_ENDS);
			return new ModelAndView("viewTransactionDetails", "outputParams",outputParams);
		}
		
		
		public ModelAndView viewFileDetails(HttpServletRequest request,HttpServletResponse response) throws IOException {
			logger.info("viewFileDetails"+SCFUConstants.METHOD_BEGINS);
			Map inputParams = new HashMap();
			Map outputParams = new HashMap();	
			String fileNo = (String) request.getParameter("fileNo");
			logger.info("fileNo :"+fileNo);
			inputParams.put("fileNo", fileNo);
			logger.info("Input to service="+inputParams);	
			outputParams = viewFileDetailsService.execute(inputParams);	
			outputParams.put("errorView","errordfTransactionDetails");
			logger.info("outputParams = " + outputParams);
			logger.info("viewFileDetails"+SCFUConstants.METHOD_ENDS);
			return new ModelAndView("viewFileDetails", "outputParams",	outputParams);
		}


		public void setViewFileDetailsService(BaseService viewFileDetailsService) {
			this.viewFileDetailsService = viewFileDetailsService;
		}

		public void setViewTransactionDetailsService(
				BaseService viewTransactionDetailsService) {
			this.viewTransactionDetailsService = viewTransactionDetailsService;
		}


		public void setFileUploadConfirmService(BaseService fileUploadConfirmService) {
			this.fileUploadConfirmService = fileUploadConfirmService;
		}
	  
	 
}
