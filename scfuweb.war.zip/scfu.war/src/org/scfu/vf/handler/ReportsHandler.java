package org.scfu.vf.handler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.scfu.common.model.UserProfile;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.scfu.vf.utils.VendorInterestReportConvertorFactory;
import org.scfu.vf.utils.VendorLimitReportConvertorFactory;
import org.scfu.vf.utils.VendorOverdueReportConvertorFactory;
import org.scfu.vf.utils.VendorReportConvertor;
import org.scfu.vf.utils.VendorReportConvertorFactory;
import org.scfu.vf.utils.VendorReverseReportConvertorFactory;

@SuppressWarnings({"rawtypes","unchecked"})
public class ReportsHandler extends MultiActionController {
	protected final Logger logger = Logger.getLogger(getClass());
	private BaseService imReportService;
	private BaseService viewVendorDetailsService;
	private String fileSaveUrl;
	private VendorReportConvertorFactory vendorReportConvertorFactory; 
	private VendorInterestReportConvertorFactory vendorInterestReportConvertorFactory;
	private VendorReverseReportConvertorFactory vendorReverseReportConvertorFactory;
	private VendorLimitReportConvertorFactory vendorLimitReportConvertorFactory;
	private VendorOverdueReportConvertorFactory vendorOverdueReportConvertorFactory;
	

	public ModelAndView vendorReport(HttpServletRequest request, HttpServletResponse response)
	    {
		  logger.info("fileUploadConfirm" + SCFUConstants.METHOD_BEGINS);
		   HttpSession session = request.getSession(false);
	        Map inParams = new HashMap();
	        Map outParams = new HashMap();
	        UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
	        String imCode= (String) userProfile.getImCode();
	        logger.info("IMCODE :"+imCode);
	        if(request.getServletPath().equals("/orgtxnreport.htm")){
	        	inParams.put(SCFUConstants.IM_CODE, imCode);
	        	logger.info("Input to service="+inParams);
	        	outParams = imReportService.execute(inParams);
	        	outParams.put("txn_type", "PRINCIPAL_TXN");
	        }
	        else if(request.getServletPath().equals("/inttxnreport.htm")){
	        	inParams.put(SCFUConstants.IM_CODE, imCode);
	        	logger.info("Input to service="+inParams);
	        	outParams = imReportService.execute(inParams);
	        	outParams.put("txn_type", "INTEREST_TXN");
	        
	        }
	        else if(request.getServletPath().equals("/repaytxnreport.htm")){
	        	inParams.put(SCFUConstants.IM_CODE, imCode);
	        	logger.info("Input to service="+inParams);
	        	outParams = imReportService.execute(inParams);
	        	outParams.put("txn_type", "REVERSE_TXN");
	        
	        }
	        else if(request.getServletPath().equals("/vendorlimitreport.htm")){
	        	inParams.put(SCFUConstants.IM_CODE, imCode);
	        	logger.info("Input to service="+inParams);
	        	outParams = imReportService.execute(inParams);
	        	outParams.put("txn_type", "LIMIT_TXN");
	        
	        }
	        else if(request.getServletPath().equals("/overduetxnreport.htm")){
	        	inParams.put(SCFUConstants.IM_CODE, imCode);
	        	logger.info("Input to service="+inParams);
	        	outParams = imReportService.execute(inParams);
	        	outParams.put("txn_type", "OVERDUE_INTEREST_TXN");
	        
	        }
	        else{
	        }
	        logger.info("outParams:;"+outParams);
	        logger.info("vendorReport"+SCFUConstants.METHOD_ENDS);
	        return new ModelAndView("selectvendorpage", "outParams", outParams);
	    }
	
	public ModelAndView viewVendorDetails(HttpServletRequest request,HttpServletResponse response) throws IOException 
	{
		logger.info("viewVendorDetails"+SCFUConstants.METHOD_BEGINS);
		HttpSession session = request.getSession(false);
		String view=null;
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
        String imCode= (String) userProfile.getImCode();
        logger.info("IMCODE : "+imCode);
        String str = (String) request.getParameter("vendorCode");
        String[] list= str.split("\\|");	
        String vendorCode=list[0];
        String vendorName=list[1];
		String txn_type = (String) request.getParameter("txn_type");
		inputParams.put("vendorCode", vendorCode);
		inputParams.put("txn_type", txn_type);
		inputParams.put("vendorName",vendorName);
		inputParams.put(SCFUConstants.IM_CODE, imCode);
		logger.info("str :"+str+"  vendorCode : "+vendorCode+"  Vendorname :"+vendorName);
		logger.info("Input to service="+inputParams);	
		outputParams = viewVendorDetailsService.execute(inputParams);	
		outputParams.put("errorView","errordfTransactionDetails");
		
		if(txn_type.equalsIgnoreCase("PRINCIPAL_TXN")){
			List vendorDetailsList=(List) outputParams.get("vendorDetailsList");
	    	session.setAttribute("vendorDetailsList",vendorDetailsList);
	    	
	    	String name=(String)outputParams.get("name");
	    	logger.info("name = " + name);
	    	
			logger.info("outputParams = " + outputParams);
			outputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
			outputParams.put("vendorCode",vendorCode);
			outputParams.put("txn_type",txn_type);
			outputParams.put("vendorName",vendorName);
			//logger.info("vendorDetailsList = " + vendorDetailsList);
			logger.info("viewVendorDetails"+SCFUConstants.METHOD_ENDS);
			view="viewVendorDetails";
			logger.info("view for PRINCIPAL_TXN:"+view);
		}
		else if(txn_type.equalsIgnoreCase("INTEREST_TXN")){
			List vendorDetailsList=(List) outputParams.get("vendorDetailsList");
	    	session.setAttribute("vendorDetailsList",vendorDetailsList);
	    	String name=(String)outputParams.get("name");
	    	logger.info("name : " + name);
			logger.info("outputParams : " + outputParams);
			outputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
			outputParams.put("vendorCode",vendorCode);
			outputParams.put("txn_type",txn_type);
			outputParams.put("vendorName",vendorName);
			logger.info("vendorDetailsList = " + vendorDetailsList);
			logger.info("viewVendorDetails"+SCFUConstants.METHOD_ENDS);
			view="viewVendorInterestReport";
			logger.info("view for INTEREST_TXN:"+view);
		}
		else if(txn_type.equalsIgnoreCase("REVERSE_TXN")){
			List vendorDetailsList=(List) outputParams.get("vendorDetailsList");
	    	session.setAttribute("vendorDetailsList",vendorDetailsList);
	    	String name=(String)outputParams.get("name");
	    	logger.info("name : " + name);
			logger.info("outputParams = " + outputParams);
			outputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
			outputParams.put("vendorCode",vendorCode);
			outputParams.put("txn_type",txn_type);
			outputParams.put("vendorName",vendorName);
			logger.info("vendorDetailsList = " + vendorDetailsList);
			view="viewVendorReverseReport";
			logger.info("view for REVERSE_TXN:"+view);
		}
		else if(txn_type.equalsIgnoreCase("LIMIT_TXN")){
			List vendorDetailsList=(List) outputParams.get("vendorDetailsList");
			List imDetailsList=(List) outputParams.get("imDetailsList");
	    	session.setAttribute("vendorDetailsList",vendorDetailsList);
	    	session.setAttribute("imDetailsList",imDetailsList);
	    	String name=(String)outputParams.get("name");
	    	logger.info("name : " + name);
			logger.info("outputParams = " + outputParams);
			outputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
			outputParams.put("imDetailsList",session.getAttribute("imDetailsList"));
			outputParams.put("vendorCode",vendorCode);
			outputParams.put("txn_type",txn_type);
			outputParams.put("imCode",imCode);
			outputParams.put("vendorName",vendorName);
			logger.info("vendorDetailsList = " + vendorDetailsList);
			view="viewVendorLimitReport";
			logger.info("view for LIMIT_TXN:"+view);
		}
		else if(txn_type.equalsIgnoreCase("OVERDUE_INTEREST_TXN")){
			List vendorDetailsList=(List) outputParams.get("vendorDetailsList");
	    	session.setAttribute("vendorDetailsList",vendorDetailsList);
	    	String name=(String)outputParams.get("name");
	    	logger.info("name : " + name);
			logger.info("outputParams : " + outputParams);
			outputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
			outputParams.put("vendorCode",vendorCode);
			outputParams.put("txn_type",txn_type);
			outputParams.put("vendorName",vendorName);
			logger.info("vendorDetailsList = " + vendorDetailsList);
			view="viewVendorOverdueReport";
			logger.info("view for OVERDUE_INTEREST_TXN:"+view);
		}
		logger.info("viewVendorDetails"+SCFUConstants.METHOD_ENDS);
		return new ModelAndView(view, SCFUConstants.OUTPUT_PARAMS,outputParams);
	}
	
	  /**
     * DESCRIPTION: This handles the file downloads(csv,txt,pdf) request for Dealer Reports
     * 			1. Gets the report Details from the session and set in input params
     * 			2. vendorReportConvertorFactory returns the reportConverter based on the report Type
     * 			3. reportConvertor.convert() handles the request dynamically for 
     * 				the file type and returns filename. 	
     * @param request
     * @param response
     * @return
     */
	public ModelAndView  vendorReportDownload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	logger.info("vendorReportDownload "+SCFUConstants.METHOD_BEGINS);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		String reportType = request.getParameter("reportType");
		logger.info("reportType"+reportType);
		String fileType = request.getParameter("fileType");
		String vendorName = request.getParameter("vendorName");
		logger.info("outputParams = " + outputParams);
		inputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
		inputParams.put("fileType", fileType);
		inputParams.put("vendorName",vendorName);
		logger.info("inputParams"+inputParams);
		try{
			logger.info("inside try block");
			VendorReportConvertor reportConvertor = vendorReportConvertorFactory.getConvertor(reportType);
			logger.info("reportConvertor"+ reportConvertor);
			SimpleDateFormat dateFormat1=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat1.format(new Date());
			String fileName = myDateString1+"_principal_report";
			fileName = reportConvertor.convert(inputParams, fileName.trim());
			logger.info("fileName"+fileName);
			String filePath=fileSaveUrl+fileName.trim();
			logger.info("filePath :"+filePath);
	try{
		response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
		    	byte [] chars = new byte[in.available()];
		    	in.read(chars);
		    	in.close();
		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
		    	logger.info("response.getOutputStream()::"+response.getOutputStream());
		    	OutputStream outputStream = response.getOutputStream();
		    	outputStream.write(chars);
		    	outputStream.flush();
		    	outputStream.close();
			}catch(Exception e){
				logger.info("specified error :"+e.getCause());
				logger.info("error :"+e.getClass());
				e.printStackTrace();
			}
    	}catch(Exception e){
			logger.error("Exception occured :",e);
		}
    	logger.info("vendorReportDownload"+SCFUConstants.METHOD_ENDS);
		return null;
    } 
	
    public ModelAndView  vendorConsignmentwiseReport(HttpServletRequest request, HttpServletResponse response)    
    {
            logger.info("vendorConsignmentwiseReport"+SCFUConstants.METHOD_BEGINS);
            Map inputParams = new HashMap();
            Map outParams = new HashMap();
            HttpSession session = request.getSession();
            UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
	        String imCode= (String) userProfile.getImCode();
	        logger.info("IMCODE :"+imCode);
            String vendorCode1 =  request.getParameter("vendorCode");
            logger.info("vendorCode :"+vendorCode1);
            if(request.getServletPath().equals("/vendorconsignprint.htm")){
            	String vendorCode =  request.getParameter("vendorCode");
            	String txn_type = (String) request.getParameter("txn_type");
            	String vendorName =  request.getParameter("vendor_name");
                logger.info("vendorCode :"+vendorCode);
                logger.info("txn_type:"+txn_type);
                inputParams.put("vendorCode",vendorCode);
                inputParams.put("txn_type", txn_type);
                inputParams.put("imCode", imCode);
                inputParams.put("vendorName", vendorName);
                logger.info("inputParams:"+inputParams);
                outParams=viewVendorDetailsService.execute(inputParams);
                List vendorDetailsList=(List) outParams.get("vendorDetailsList");
               // logger.info("vendorDetailsList inside vendorConsignmentwiseReport:"+vendorDetailsList);
                if(vendorDetailsList != null){
				logger.info("vendorDetailsList inside vendorReversewiseReport SIZE :"+vendorDetailsList.size());
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for print option
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for file download
                logger.info("consignmentDetailsList size= "+vendorDetailsList.size()+"set in session for Consignmentwise report");
                outParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
                outParams.put("vendorCode",vendorCode);
                }
            }
            else{
            	
            }
            logger.info("consignmentwiseReport"+SCFUConstants.METHOD_ENDS);
            return new ModelAndView("viewVendorConsignmentReport", SCFUConstants.OUTPUT_PARAMS, outParams);
        } 
    
	public ModelAndView  vendorIntrestReportDownload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	logger.info("vendorIntrestReportDownload(request,response)"+SCFUConstants.METHOD_BEGINS);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		String reportType = request.getParameter("reportType");
		logger.info("reportType"+reportType);
		String fileType = request.getParameter("fileType");
		String vendorName = request.getParameter("vendorName");
		logger.info("outputParams = " + outputParams);
		inputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
		inputParams.put("fileType", fileType);
		inputParams.put("vendorName",vendorName);
		logger.info("inputParams"+inputParams);
		try{
			logger.info("inside try block");
			VendorReportConvertor reportConvertor = vendorInterestReportConvertorFactory.getConvertor(reportType);
			logger.info("reportConvertor"+ reportConvertor);
			SimpleDateFormat dateFormat1=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat1.format(new Date());
			String fileName = myDateString1+"_interest_report";
			fileName = reportConvertor.convert(inputParams, fileName.trim());
			logger.info("fileName"+fileName);
			String filePath=fileSaveUrl+fileName.trim();
			logger.info("filePath :"+filePath);
	try{
		response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
		    	byte [] chars = new byte[in.available()];
		    	in.read(chars);
		    	in.close();
		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
		    	logger.info("response.getOutputStream()::"+response.getOutputStream());
		    	OutputStream outputStream = response.getOutputStream();
		    	outputStream.write(chars);
		    	outputStream.flush();
		    	outputStream.close();
			}catch(Exception e){
				logger.info("specified error "+e.getCause());
				logger.info("error :"+e.getClass());
				e.printStackTrace();
			}
    	}catch(Exception e){
    		logger.info("First try block");
			logger.error("Exception occured :",e);
		}
    	logger.info("vendorIntrestReportDownload"+SCFUConstants.METHOD_ENDS);
		return null;
    }
	
    public ModelAndView vendorIntrestwiseReport(HttpServletRequest request, HttpServletResponse response)    
    {
            logger.info("vendorIntrestwiseReport"+SCFUConstants.METHOD_BEGINS);
            Map inputParams = new HashMap();
            Map outParams = new HashMap();
            HttpSession session = request.getSession();
            UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
	        String imCode= (String) userProfile.getImCode();
	        logger.info("IMCODE :"+imCode);
            String vendorCode1 =  request.getParameter("vendorCode");
            logger.info("vendorCode :"+vendorCode1);
            if(request.getServletPath().equals("/vendorintrestprint.htm")){
            	String vendorCode =  request.getParameter("vendorCode");
            	String txn_type = (String) request.getParameter("txn_type");
            	 String vendorName =  request.getParameter("vendor_name");
                logger.info("vendorCode11:"+vendorCode);
                logger.info("txn_type:"+txn_type);
                inputParams.put("vendorCode",vendorCode);
                inputParams.put("txn_type", txn_type);
                inputParams.put("imCode", imCode);
                inputParams.put("vendorName", vendorName);
                logger.info("inputParams:"+inputParams);
                outParams=viewVendorDetailsService.execute(inputParams);
                List vendorDetailsList=(List) outParams.get("vendorDetailsList");
                //logger.info("vendorDetailsList inside vendorConsignmentwiseReport:"+vendorDetailsList);
                if(vendorDetailsList != null){
				logger.info("vendorDetailsList inside vendorReversewiseReport SIZE :"+vendorDetailsList.size());
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for print option
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for file download
                logger.info("consignmentDetailsList size= "+vendorDetailsList.size()+"set in session for Consignmentwise report");
                outParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
                outParams.put("vendorCode",vendorCode);
                }
            }
            else{
            }
            logger.info("vendorIntrestwiseReport"+SCFUConstants.METHOD_ENDS);
            return new ModelAndView("vendorInterestReportPrint", SCFUConstants.OUTPUT_PARAMS, outParams);
        } 
    
    public ModelAndView  vendorOverdueReportDownload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	logger.info("vendorOverdueReportDownload(request,response)"+SCFUConstants.METHOD_BEGINS);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		String reportType = request.getParameter("reportType");
		logger.info("reportType"+reportType);
		String fileType = request.getParameter("fileType");
		String vendorName = request.getParameter("vendorName");
		logger.info("outputParams = " + outputParams);
		inputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
		inputParams.put("fileType", fileType);
		inputParams.put("vendorName",vendorName);
		logger.info("inputParams"+inputParams);
		try{
			logger.info("inside try block");
			VendorReportConvertor reportConvertor = vendorOverdueReportConvertorFactory.getConvertor(reportType);
			logger.info("reportConvertor"+ reportConvertor);
			SimpleDateFormat dateFormat1=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat1.format(new Date());
			String fileName = myDateString1+"_overdue_report";
			fileName = reportConvertor.convert(inputParams, fileName.trim());
			logger.info("fileName"+fileName);
			String filePath=fileSaveUrl+fileName.trim();
			logger.info("filePath :"+filePath);
	try{
		response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
		    	byte [] chars = new byte[in.available()];
		    	in.read(chars);
		    	in.close();
		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
		    	logger.info("response.getOutputStream()::"+response.getOutputStream());
		    	OutputStream outputStream = response.getOutputStream();
		    	outputStream.write(chars);
		    	outputStream.flush();
		    	outputStream.close();
			}catch(Exception e){
				logger.info("specified error "+e.getCause());
				logger.info("error :"+e.getClass());
				e.printStackTrace();
			}
    	}catch(Exception e){
    		logger.info("First try block");
			logger.error("Exception occured :",e);
		}
    	logger.info("vendorOverdueReportDownload"+SCFUConstants.METHOD_ENDS);
		return null;
    }
    
    public ModelAndView vendorOverduewiseReport(HttpServletRequest request, HttpServletResponse response)    
    {
            logger.info("vendorOverduewiseReport"+SCFUConstants.METHOD_BEGINS);
            Map inputParams = new HashMap();
            Map outParams = new HashMap();
            HttpSession session = request.getSession();
            UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
	        String imCode= (String) userProfile.getImCode();
	        logger.info("IMCODE :"+imCode);
            String vendorCode1 =  request.getParameter("vendorCode");
            if(request.getServletPath().equals("/vendoroverdueprint.htm")){
            	String vendorCode =  request.getParameter("vendorCode");
            	String txn_type = (String) request.getParameter("txn_type");
            	 String vendorName =  request.getParameter("vendor_name");
            	 logger.info("vendorCode :"+vendorCode1 +" vendorName: "+vendorName);
                logger.info("vendorCode11:"+vendorCode);
                logger.info("txn_type:"+txn_type);
                inputParams.put("vendorCode",vendorCode);
                inputParams.put("txn_type", txn_type);
                inputParams.put("imCode", imCode);
                inputParams.put("vendorName",vendorName);
                logger.info("inputParams:"+inputParams);
                outParams=viewVendorDetailsService.execute(inputParams);
                List vendorDetailsList=(List) outParams.get("vendorDetailsList");
                //logger.info("vendorDetailsList inside vendorConsignmentwiseReport:"+vendorDetailsList);
                if(vendorDetailsList != null){
				logger.info("vendorDetailsList inside vendorOverduewiseReport SIZE :"+vendorDetailsList.size());
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for print option
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for file download
                logger.info("consignmentDetailsList size= "+vendorDetailsList.size()+"set in session for Consignmentwise report");
                outParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
                outParams.put("vendorCode",vendorCode);
                }
            }
            else{
            }
            logger.info("vendorOverduewiseReport"+SCFUConstants.METHOD_ENDS);
            return new ModelAndView("vendorOverdueReportPrint", SCFUConstants.OUTPUT_PARAMS, outParams);
        } 
    
    public ModelAndView  vendorReverseReportDownload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	logger.info("vendorReverseReportDownload(request,response)"+SCFUConstants.METHOD_BEGINS);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		String reportType = request.getParameter("reportType");
		logger.info("reportType"+reportType);
		String fileType = request.getParameter("fileType");
		String vendorName = request.getParameter("vendorName");
		logger.info("outputParams = " + outputParams);
		inputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
		inputParams.put("fileType", fileType);
		inputParams.put("vendorName",vendorName);
		logger.info("inputParams"+inputParams);
		try{
			logger.info("inside try block");
			VendorReportConvertor reportConvertor = vendorReverseReportConvertorFactory.getConvertor(reportType);
			logger.info("reportConvertor"+ reportConvertor);
			SimpleDateFormat dateFormat1=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat1.format(new Date());
			String fileName = myDateString1+"_reverse_report";
			fileName = reportConvertor.convert(inputParams, fileName.trim());
			logger.info("fileName"+fileName);
			String filePath=fileSaveUrl+fileName.trim();
			logger.info("filePath :"+filePath);
	try{
		response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
		    	byte [] chars = new byte[in.available()];
		    	in.read(chars);
		    	in.close();
		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
		    	logger.info("response.getOutputStream()::"+response.getOutputStream());
		    	OutputStream outputStream = response.getOutputStream();
		    	outputStream.write(chars);
		    	outputStream.flush();
		    	outputStream.close();
			}catch(Exception e){
				logger.info("specified error:"+e.getCause());
				logger.info("error :"+e.getClass());
				e.printStackTrace();
			}
    	}catch(Exception e){
    		logger.info("First try block");
			logger.error("Exception occured :",e);
		}
    	logger.info("vendorReverseReportDownload(request,response) method endsss");
		return null;
    }
    
 

	public ModelAndView vendorReversewiseReport(HttpServletRequest request, HttpServletResponse response)    
    {
            logger.info("vendorReversewiseReport  handler begins");
            Map inputParams = new HashMap();
            Map outParams = new HashMap();
            HttpSession session = request.getSession();
            UserProfile userProfile = (UserProfile) session.getAttribute(SCFUConstants.PROFILE);
	        String imCode= (String) userProfile.getImCode();
	        logger.info("IMCODE :"+imCode);
            String vendorCode1 =  request.getParameter("vendorCode");
            logger.info("vendorCode11====="+vendorCode1);
            if(request.getServletPath().equals("/vendorreverseprint.htm")){
            	String vendorCode =  request.getParameter("vendorCode");
            	String txn_type = (String) request.getParameter("txn_type");
            	 String vendorName =  request.getParameter("vendor_name");
                logger.info("vendorCode11:"+vendorCode);
                logger.info("txn_type:"+txn_type);
                inputParams.put("vendorCode",vendorCode);
                inputParams.put("txn_type", txn_type);
                inputParams.put("imCode", imCode);
                inputParams.put("vendorName", vendorName);
                logger.info("inputParams:"+inputParams);
                outParams=viewVendorDetailsService.execute(inputParams);
                List vendorDetailsList=(List) outParams.get("vendorDetailsList");
                //logger.info("vendorDetailsList inside vendorReversewiseReport:"+vendorDetailsList);
                if(vendorDetailsList != null){
			    logger.info("vendorDetailsList inside vendorReversewiseReport SIZE :"+vendorDetailsList.size());
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for print option
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for file download
                logger.info("consignmentDetailsList size= "+vendorDetailsList.size()+"set in session for vendorReversewiseReport");
                outParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
                outParams.put("vendorCode",vendorCode);
                }
            }
            else{

            }
            logger.info("vendorReversewiseReport handler ends");
            return new ModelAndView("vendorReverseReportPrint", SCFUConstants.OUTPUT_PARAMS, outParams);
        } 
	
	
    public ModelAndView  vendorLimitReportDownload(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
    	logger.info("vendorLimitReportDownload(request,response)"+SCFUConstants.METHOD_BEGINS);
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		HttpSession session=request.getSession();
		String reportType = request.getParameter("reportType");
		logger.info("reportType"+reportType);
		String fileType = request.getParameter("fileType");
		logger.info("outputParams = " + outputParams);
		String vendorName = request.getParameter("vendorName");
		inputParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
		inputParams.put("imDetailsList",session.getAttribute("imDetailsList"));
		inputParams.put("fileType", fileType);
		inputParams.put("vendorName",vendorName);
		logger.info("inputParams"+inputParams);
		try{
			logger.info("inside try block");
			VendorReportConvertor reportConvertor = vendorLimitReportConvertorFactory.getConvertor(reportType);
			logger.info("reportConvertor"+ reportConvertor);
			SimpleDateFormat dateFormat1=new SimpleDateFormat("dd.MM.yyyy hh.mm");
			String myDateString1= dateFormat1.format(new Date());
			String fileName = myDateString1+"_limit_report";
			fileName = reportConvertor.convert(inputParams, fileName.trim());
			logger.info("fileName"+fileName);
			String filePath=fileSaveUrl+fileName.trim();
			logger.info("filePath :"+filePath);
	try{
		response.setContentType("application/OCTET-STREAM");
				InputStream in = new FileInputStream(new File(filePath));
		    	byte [] chars = new byte[in.available()];
		    	in.read(chars);
		    	in.close();
		    	response.setHeader("Content-disposition","attachment;filename="+fileName);
		    	logger.info("response.getOutputStream()::"+response.getOutputStream());
		    	OutputStream outputStream = response.getOutputStream();
		    	outputStream.write(chars);
		    	outputStream.flush();
		    	outputStream.close();
			}catch(Exception e){
				logger.info("Second try blockasfsadf");
				logger.info("specified error asdfg"+e.getCause());
				logger.info("error 2asdfg"+e.getClass());
				e.printStackTrace();
			}
    	}catch(Exception e){
    		logger.info("First try block");
			logger.error("Exception occured :",e);
		}
    	logger.info("vendorLimitReportDownload"+SCFUConstants.METHOD_ENDS);
		return null;
    }
	
	
    
	public ModelAndView vendorLimitwiseReport(HttpServletRequest request, HttpServletResponse response)    
    {
            logger.info("vendorLimitwiseReport  handler begins");
            Map inputParams = new HashMap();
            Map outParams = new HashMap();
            HttpSession session = request.getSession();
            String vendorCode1 =  request.getParameter("vendorCode");
            logger.info("vendorCode :"+vendorCode1);
            if(request.getServletPath().equals("/vendorlimitprint.htm")){
            	String vendorCode =  request.getParameter("vendorCode");
            	String txn_type = (String) request.getParameter("txn_type");
            	String imCode = (String) request.getParameter("imCode");
            	 String vendorName =  request.getParameter("vendor_name");
                logger.info("vendorCode11:"+vendorCode);
                logger.info("txn_type:"+txn_type);
                logger.info("imCode vendorLimitwiseReport:"+imCode);
                inputParams.put("vendorCode",vendorCode);
                inputParams.put("txn_type", txn_type);
                inputParams.put("imCode", imCode);
                inputParams.put("vendorName", vendorName);
                logger.info("inputParams:"+inputParams);
                outParams=viewVendorDetailsService.execute(inputParams);
                List vendorDetailsList=(List) outParams.get("vendorDetailsList");
                List imDetailsList=(List) outParams.get("imDetailsList");
                logger.info("vendorDetailsList inside vendorLimitwiseReport:"+vendorDetailsList);
                if(vendorDetailsList != null && imDetailsList!= null){
                session.setAttribute("vendorDetailsList",vendorDetailsList); //this is for print option
                session.setAttribute("imDetailsList",imDetailsList);
                logger.info("consignmentDetailsList size= "+vendorDetailsList.size()+"set in session for vendorLimitwiseReport");
                logger.info("imDetailsList size"+imDetailsList);
                outParams.put("vendorDetailsList",session.getAttribute("vendorDetailsList"));
                outParams.put("imDetailsList",session.getAttribute("imDetailsList"));
                outParams.put("vendorCode",vendorCode);
                outParams.put("imCode",imCode);
                }
            }
            else{
            	
            }
            logger.info("vendorLimitwiseReport handler ends");
            return new ModelAndView("vendorLimitReportPrint", SCFUConstants.OUTPUT_PARAMS, outParams);
        } 
	
	public void setVendorLimitReportConvertorFactory(
			VendorLimitReportConvertorFactory vendorLimitReportConvertorFactory) {
		this.vendorLimitReportConvertorFactory = vendorLimitReportConvertorFactory;
	}

	public void setVendorReverseReportConvertorFactory(
				VendorReverseReportConvertorFactory vendorReverseReportConvertorFactory) {
			this.vendorReverseReportConvertorFactory = vendorReverseReportConvertorFactory;
		}
	public void setVendorInterestReportConvertorFactory(
			VendorInterestReportConvertorFactory vendorInterestReportConvertorFactory) {
		this.vendorInterestReportConvertorFactory = vendorInterestReportConvertorFactory;
	}

	public void setVendorOverdueReportConvertorFactory(
			VendorOverdueReportConvertorFactory vendorOverdueReportConvertorFactory) {
		this.vendorOverdueReportConvertorFactory = vendorOverdueReportConvertorFactory;
	}

	public void setVendorReportConvertorFactory(
			VendorReportConvertorFactory vendorReportConvertorFactory) {
		this.vendorReportConvertorFactory = vendorReportConvertorFactory;
	}

	public void setViewVendorDetailsService(BaseService viewVendorDetailsService) {
		this.viewVendorDetailsService = viewVendorDetailsService;
	}
	 public void setImReportService(BaseService imReportService) {
			this.imReportService = imReportService;
	}
	 public void setFileSaveUrl(String fileSaveUrl) {
			this.fileSaveUrl = fileSaveUrl;
		}
	
}
