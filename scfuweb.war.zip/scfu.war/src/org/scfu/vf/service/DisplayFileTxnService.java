package org.scfu.vf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;
import org.apache.log4j.Logger;

public class DisplayFileTxnService extends BaseService{
	private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;
	private Logger logger =Logger.getLogger(getClass());
	@SuppressWarnings({ "rawtypes" })
	
	public Map execute(Map inParams) {
		logger.info("execute  " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map<String, Object> outParams = new HashMap<String, Object>();

		String imCode = (String) inParams.get("imCode");
		String userName = (String) inParams.get("userName");
		try {
			List imFileList = authoriseFileTxnDAOImpl.findIMList(userName,
					imCode);
			if (imFileList != null && imFileList.size() > 0) {
				logger.info("imFileList size : " + imFileList.size());
				outParams.put("imFileList", imFileList);
				response.setErrorStatus(SCFUConstants.SUCCESS);
			} else {
				logger.info("No files to Authorise");
				response.setErrorCode("noFilestoAuthorize");
			}
		} catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute  " + SCFUConstants.METHOD_ENDS);
		return outParams;
	}
	
	public void setAuthoriseFileTxnDAOImpl(AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}

}
