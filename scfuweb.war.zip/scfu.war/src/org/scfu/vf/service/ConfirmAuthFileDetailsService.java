package org.scfu.vf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.bp.AuthorisationBP;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;

@SuppressWarnings({"rawtypes","unchecked"})

public class ConfirmAuthFileDetailsService extends  BaseService {
	private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;
	private AuthorisationBP authorisationBP;
	private Logger logger =Logger.getLogger(getClass());
	
	public Map execute(Map inParams) {
		logger.info("execute "+SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response=new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map outParams = new HashMap();
		String[] echequeArray = (String[]) inParams.get("transaction_No");
		String echequeNoValues = null;
		String userName = (String) inParams.get("userName");
		String imCode = (String) inParams.get("imCode");
		
		try{
			if(echequeArray != null && echequeArray.length > 0)
			{
				List successTxnList = new ArrayList();
				List failureTxnList = new ArrayList();
				for (int i = 0; i < echequeArray.length; i++)
                {
				echequeNoValues = echequeArray[i];
				String[] echequeNoList= echequeNoValues.split("\\|");
				String echequeNo=echequeNoList[0];
				String authLevel=echequeNoList[1];
				
				/* Authorization validation */
				boolean flag = authorisationBP.validate(inParams,echequeNo);
				if(flag)
				{
				Integer currentAuthLevel = (Integer)authoriseFileTxnDAOImpl.getCurrentAuthLevel(echequeNo,authLevel,userName);
				logger.info("Current Authorisation level : " +currentAuthLevel);
				authoriseFileTxnDAOImpl.updateCurrentAuthLevel(echequeNo,currentAuthLevel,userName,imCode);
				authoriseFileTxnDAOImpl.updateAuthDetails(echequeNo,currentAuthLevel,userName);
				successTxnList.add(echequeNo);
				}
				else
				{
				Integer currentAuthLevel = (Integer)authoriseFileTxnDAOImpl.getCurrentAuthLevel(echequeNo,authLevel,userName);
				logger.info("Current Authorisation level:" +currentAuthLevel);
				authoriseFileTxnDAOImpl.updateValidationFailureStatus(echequeNo);
				authoriseFileTxnDAOImpl.updateAuthDetails(echequeNo,currentAuthLevel,userName);
				failureTxnList.add(echequeNo);
				}
             }
				outParams.put("successTxnList", successTxnList);
				outParams.put("failureTxnList", failureTxnList);
				response.setErrorStatus(SCFUConstants.SUCCESS);
			}
			else{
				logger.info("Transaction No. is null.");
				response.setErrorCode("nullTransactionNo");
			}
			
		}catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		}
		catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("outParams : " + outParams);
		logger.info("execute "+SCFUConstants.METHOD_ENDS);
		return outParams;
	}
	
	public void setAuthoriseFileTxnDAOImpl(AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}
	public void setAuthorisationBP(AuthorisationBP authorisationBP)
    {
        this.authorisationBP = authorisationBP;
    }
}
