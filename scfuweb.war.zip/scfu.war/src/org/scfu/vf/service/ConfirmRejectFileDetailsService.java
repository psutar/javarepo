package org.scfu.vf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;
@SuppressWarnings({"rawtypes"})
public class ConfirmRejectFileDetailsService extends BaseService {
	private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;
	private Logger logger = Logger.getLogger(getClass());

	public Map<String, Object> execute(Map inParams) {
		logger.info("execute " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map<String, Object> outParams = new HashMap<String, Object>();
		String[] echequeArray = (String[]) inParams.get("transaction_No");
		String echequeNoValues = null;
		String rejectreason = (String) inParams.get("rejectreason");
		String userName = (String) inParams.get("userName");
		try {
			if (echequeArray != null && echequeArray.length > 0) {
				List<String> cancelTxnList = new ArrayList<String>();
				for (int i = 0; i < echequeArray.length; i++) {
					echequeNoValues = echequeArray[i];
					String[] echequeNoList = echequeNoValues.split("\\|");
					String echequeNo = echequeNoList[0];
					String authLevel = echequeNoList[1];
					Integer currentAuthLevel = (Integer) authoriseFileTxnDAOImpl.getCurrentAuthLevel(echequeNo, authLevel, userName);
					logger.info("Current Authorisation level:"+ currentAuthLevel);
					authoriseFileTxnDAOImpl.updateRejectionCurrentAuthLevel(echequeNo, currentAuthLevel, rejectreason);
					authoriseFileTxnDAOImpl.updateAuthDetails(echequeNo,currentAuthLevel, userName);
					cancelTxnList.add(echequeNo);
				}
				outParams.put("cancelTxnList", cancelTxnList);
				response.setErrorStatus(SCFUConstants.SUCCESS);
			} else {
				logger.info("Transaction No. is null.");
				response.setErrorCode("nullTransactionNo");
			}

		} catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute " + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setAuthoriseFileTxnDAOImpl(
			AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}
}
