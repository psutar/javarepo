/*This Service is called when after the file is uploaded for further processing
 * i.e. the file name is fetched and the correct format is entered in the db records as well as
 * a xml file is generated which is stored in the mentioned location
 * @Prateek */
package org.scfu.vf.service;

import java.io.File;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.UploadFileDAO;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
@SuppressWarnings({"rawtypes","unchecked"})
public class FileUploadConfirmService extends BaseService {

	
	private Logger logger = Logger.getLogger(getClass());
	private String vendorUploadFilePath;
	private UploadFileDAO uploadFileDAOImpl;

	public Map execute(Map inputParams) {
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_BEGINS);
		Map<String,Object> outputParams = new HashMap<String,Object>();
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		if (inputParams != null && inputParams.size() > 0) {
			CommonsMultipartFile file = (CommonsMultipartFile) inputParams.get("file");
			String fileName = (String) inputParams.get("fileName");
			String imCode = (String) inputParams.get("imCode");
			String userName = (String) inputParams.get(SCFUConstants.USER_NAME);
			String sno = new String();
			try {
				Integer nextValue = uploadFileDAOImpl
						.getNextNumberFromSequenceFile();
				sno = nextValue.toString();
				String newPath = "";
				newPath = vendorUploadFilePath + sno + SCFUConstants.DOT
						+ SCFUConstants.XML_EXTENSION;
				// file.transferTo(new File(newPath));
				logger.info("Path :::" + newPath);
				logger.info("inparams :" + inputParams);

				Map params = new HashMap();
				params.put("sno", sno);
				params.put("fileType", "VENDOR");
				params.put("fileName", "vf/" + sno + SCFUConstants.DOT + SCFUConstants.XML_EXTENSION);
				params.put("fileStatus", "Pending");
				params.put(SCFUConstants.USER_NAME, userName);
				Date date = new Date();
				Timestamp loginDate = new Timestamp(date.getTime());
				params.put("creationTime", loginDate);
				params.put("lastModTime", loginDate);
				params.put("im_code", imCode);
				params.put("uploaded_file_name", fileName);
				File f1 = new File(vendorUploadFilePath);
				if (f1.exists()) {
					int value = uploadFileDAOImpl.insertScfuFileMaster(params);
					if (value > 0) {
						file.transferTo(new File(newPath));
						response.setErrorStatus(SCFUConstants.SUCCESS);
					}
					response.setErrorStatus("success");
					outputParams.put("fileName", sno);
				} else {
					logger.error("Path not found");
					response.setErrorCode("UploadPathMissing");
					response.setErrorStatus(SCFUConstants.FAILURE);
				}
			} catch (DAOException e) {
				response.setErrorCode(e.getErrorCode());
				response.setErrorStatus(SCFUConstants.FAILURE);
			} catch (Exception e) {
				logger.error("Error occured : ", e);
				response.setErrorCode("TechnicalProblem");
				response.setErrorStatus(SCFUConstants.FAILURE);
			}
		}
		outputParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("response " + response);
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_ENDS);
		return outputParams;
	}

	public void setUploadFileDAOImpl(UploadFileDAO uploadFileDAOImpl) {
		this.uploadFileDAOImpl = uploadFileDAOImpl;
	}

	public void setVendorUploadFilePath(String vendorUploadFilePath) {
		this.vendorUploadFilePath = vendorUploadFilePath;
	}



   
}
