package org.scfu.vf.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.GenerateReverseFileDAO;

@SuppressWarnings({"rawtypes","unchecked"})

public class GenerateReverseFileDisplayService extends BaseService{

	private Logger logger = Logger.getLogger(getClass());
	private GenerateReverseFileDAO generateReverseFileDAOImpl;

	public Map execute(Map inParams){
		logger.info("execute " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map outParams = new HashMap();	
		String imCode = (String) inParams.get("imCode");
		String fromDate = (String) inParams.get("fromDate");
		String toDate = (String) inParams.get("toDate");
		
		Map displayIMFileList = generateReverseFileDAOImpl.displayIMFileList(imCode,fromDate,toDate);
		try{
			if(displayIMFileList != null && displayIMFileList.size() >0){
				
				logger.info("displayIMFileList.size() : " +displayIMFileList.size());
				outParams.put("displayIMFileList",displayIMFileList);
				outParams.put("imCode", imCode);
				response.setErrorStatus(SCFUConstants.SUCCESS);					
			}else
			{
				String errorMessage = "No files found for the date ranging from " + fromDate + " to "+toDate+"";
				response.setErrorMessage(errorMessage);
				response.setErrorCode("fileNotFound");
			}				
		}catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		}catch(Exception e){
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}	
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}
	
	public void setGenerateReverseFileDAOImpl(
			GenerateReverseFileDAO generateReverseFileDAOImpl) {
		this.generateReverseFileDAOImpl = generateReverseFileDAOImpl;
	}
}