package org.scfu.vf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.GenerateReverseFileDAO;
import org.scfu.vf.model.ReverseFileTransactionDetails;

@SuppressWarnings({"rawtypes","unchecked"})
public class GenerateReverseFileDetailsService extends BaseService {
	protected Logger logger = Logger.getLogger(getClass());
	private GenerateReverseFileDAO generateReverseFileDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		List<ReverseFileTransactionDetails> transactionDetails = null;
		String imName = null;
		Map outParams = new HashMap();
		try {
			String fileName = (String) inParams.get("fileName");
			String fileStatus = (String) inParams.get("fileStatus");
			logger.info("File Status" + fileStatus);
			String imCode = (String) inParams.get("imCode");
			String fileNo = (String) inParams.get("fileNo");
			if (fileNo != null) {
				transactionDetails = generateReverseFileDAOImpl.findTransactionDetailsReverseFile(inParams);
				imName = generateReverseFileDAOImpl.getimName(imCode);
				try {
					if (transactionDetails != null && transactionDetails.size() > 0 && imName != null) {
						logger.info("Transaction Details is not equals null");
						response.setErrorStatus("SUCCESS");
					} else {
						String errorMessage = "All the transaction(s) in the file " + fileName + " might not have been processed completely! ";
						response.setErrorMessage(errorMessage);
						response.setErrorCode("transactionNotProcessed");
					}
				} catch (DAOException e) {
					logger.error("Error Occured :" + e.getMessage());
					response.setErrorCode(e.getErrorCode());
				} catch (Exception e) {
					logger.error("Error Occured :" + e.getMessage());
					response.setErrorCode("TechnicalProblem");
				}
			}
		} catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put("getTransactionDetails", transactionDetails);
		outParams.put("imName", imName);
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute " + SCFUConstants.METHOD_ENDS);
		logger.info("response : " + response);
		return outParams;
	}
	public void setGenerateReverseFileDAOImpl(
			GenerateReverseFileDAO generateReverseFileDAOImpl) {
		this.generateReverseFileDAOImpl = generateReverseFileDAOImpl;
	}
}
