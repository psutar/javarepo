package org.scfu.vf.service;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.authentication.algorithm.Sha512Hashing;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.service.BaseService;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.VFIMUserDAO;
@SuppressWarnings({"rawtypes","unchecked"})

public class AddVFIMUserService extends BaseService{
	private Sha512Hashing sha512Hashing;
	protected final Logger logger = Logger.getLogger(getClass());
	private VFIMUserDAO vfIMUserDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute() " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		Map outParams = new HashMap();
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {
			String userId = inParams.get("login_id").toString();
			String password1 = inParams.get("password").toString();
			logger.info("userId :" + userId);
			String password = sha512Hashing.hashingSHA2(userId + "#" + password1);
			inParams.put("pwdencr", password);
			logger.info("inParams:" + inParams);
			vfIMUserDAOImpl.addVFIMUser(inParams);
			vfIMUserDAOImpl.insertSCFUUserDetails(inParams);
			vfIMUserDAOImpl.insertSCFUUser(inParams);
			response.setErrorStatus(SCFUConstants.SUCCESS);
		} catch (DAOException e) {
			logger.info("DAOException Occurred");
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.info("Exception Occurred");
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;

	}
public void setVfIMUserDAOImpl(VFIMUserDAO vfIMUserDAOImpl) {
	this.vfIMUserDAOImpl = vfIMUserDAOImpl;
}	
public void setSha512Hashing(Sha512Hashing sha512Hashing) {
	this.sha512Hashing = sha512Hashing;
}
}
