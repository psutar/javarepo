/**
 * @author Prateek
 * For Vendor reports 
 */
package org.scfu.vf.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.ReportDAO;

@SuppressWarnings({"rawtypes","unchecked"})
public class IMReportService extends BaseService{
	private Logger logger =Logger.getLogger(getClass());
	ReportDAO ReportDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute" + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		List getVendorList = null;
		Map outParams = new HashMap();
		List vendorList = new ArrayList();
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {
			String imCode = (String) inParams.get(SCFUConstants.IM_CODE);
			getVendorList = ReportDAOImpl.vendorListReport(imCode);
			if (getVendorList.size() > 0) {
				for (int cnt = 0; cnt < getVendorList.size(); cnt++) {
					logger.info("getVendorList size : " + getVendorList.size());
					Map vendorListMap = (Map) getVendorList.get(cnt);
					vendorList.add(vendorListMap);
				}
				outParams.put("vendorList", vendorList);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams outParams : " + outParams);
			} else {
				logger.info("error occoured");
				response.setErrorCode("emptyList");
			}
			logger.info("vendorList obtained with size = " + vendorList.size());
		} catch (DAOException e) {
			response.setErrorCode(e.getErrorCode());
			response.setErrorStatus(SCFUConstants.FAILURE);
		} catch (Exception e) {
			logger.error("Error occured : ", e);
			response.setErrorCode("TechnicalProblem ");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		outParams.put("vendorList", vendorList);
		logger.info("execute" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setReportDAOImpl(ReportDAO reportDAOImpl) {
		ReportDAOImpl = reportDAOImpl;
	}
}