package org.scfu.vf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.ReportDAO;
@SuppressWarnings({"rawtypes","unchecked"})
public class ViewVendorDetailsService extends BaseService {

	protected Logger logger = Logger.getLogger(getClass());
	private ReportDAO reportDAOImpl;	
	public Map execute(Map inParams)
	{
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response=new SCFUApplicationResponse();
	//	List getVendorDetails = null;
		Map outParams = new HashMap();		
		List vendorDetailsList = new ArrayList(); 
		List imDetailsList = new ArrayList(); 
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {

			String vendorCode = (String) inParams.get("vendorCode");
			String imCode = (String) inParams.get(SCFUConstants.IM_CODE);
			String txn_type = (String) inParams.get("txn_type");
			String vendorName=(String)inParams.get("vendorName");
			logger.info("vendorCode :"+vendorCode+" imCode :"+imCode+" txn_type :"+txn_type+" vendorName :"+vendorName);
		    boolean status=false;
			status=(boolean)reportDAOImpl.checkVendorDetails(vendorCode,vendorName);
			if(status){
			if (vendorCode != null && txn_type.equalsIgnoreCase("PRINCIPAL_TXN"))
			{
				logger.info("vendorCode inside ViewVendorDetailsService PRINCIPAL_TXN:"+vendorCode);
				vendorDetailsList = reportDAOImpl.principleVendorReport(vendorCode,txn_type,imCode);
				outParams.put("vendorDetailsList", vendorDetailsList);
				outParams.put("txn_type", txn_type);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams : "+outParams);
			}

			else if (vendorCode != null && txn_type.equalsIgnoreCase("INTEREST_TXN"))
			{
				logger.info("vendorCode inside ViewVendorDetailsService INTEREST_TXN:"+vendorCode);
				vendorDetailsList = reportDAOImpl.interestVendorReport(vendorCode,txn_type,imCode);
				outParams.put("vendorDetailsList", vendorDetailsList);
				outParams.put("txn_type", txn_type);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams : "+outParams);
			}
			else if (vendorCode != null && txn_type.equalsIgnoreCase("REVERSE_TXN"))
			{
				logger.info("vendorCode inside ViewVendorDetailsService REVERSE_TXN:"+vendorCode);
				vendorDetailsList = reportDAOImpl.reverseVendorReport(vendorCode,txn_type,imCode);
				outParams.put("vendorDetailsList", vendorDetailsList);
				outParams.put("txn_type", txn_type);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams : "+outParams);
			}
			else if (vendorCode != null && txn_type.equalsIgnoreCase("LIMIT_TXN"))
			{
				logger.info("vendorCode inside ViewVendorDetailsService LIMIT_TXN:"+vendorCode);
				vendorDetailsList = reportDAOImpl.limitVendorReport(vendorCode,txn_type,imCode);
				imDetailsList=reportDAOImpl.limitIMReport(imCode,txn_type);
				outParams.put("vendorDetailsList", vendorDetailsList);
				outParams.put("imDetailsList", imDetailsList);
				outParams.put("txn_type", txn_type);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams : "+outParams);
			}
			else if (vendorCode != null && txn_type.equalsIgnoreCase("OVERDUE_INTEREST_TXN"))
			{
				logger.info("vendorCode inside ViewVendorDetailsService OVERDUE_INTEREST_TXN:"+vendorCode);
				vendorDetailsList = reportDAOImpl.overdueVendorReport(vendorCode,txn_type,imCode);
				outParams.put("vendorDetailsList", vendorDetailsList);
				outParams.put("txn_type", txn_type);
				response.setErrorStatus(SCFUConstants.SUCCESS);
				logger.info("outParams : "+outParams);
			}
			}

		}  catch (DAOException e) {
			response.setErrorCode(e.getErrorCode());

		} catch (Exception e) {
			logger.error("Error occured : ", e);
			response.setErrorCode("TechnicalProblem ");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)"+SCFUConstants.METHOD_ENDS);
		return outParams;
	}



	public void setReportDAOImpl(ReportDAO reportDAOImpl) {
		this.reportDAOImpl = reportDAOImpl;
	}





}
