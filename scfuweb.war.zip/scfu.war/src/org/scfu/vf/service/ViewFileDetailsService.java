/**
 * @author Prateek
 *This Class is used for Listing out the Detailed transaction 
 * list for a particular File Chosen which is processed in the view file status
 */
package org.scfu.vf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.ViewTransactionDetailsDAO;
@SuppressWarnings({"rawtypes","unchecked"})

public class ViewFileDetailsService extends BaseService {
	protected Logger logger = Logger.getLogger(getClass());
	private ViewTransactionDetailsDAO viewTransactionDetailsDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		List getTransactionDetails = null;
		Map<String,Object> outParams = new HashMap<String,Object>();
		List transactionDetailsList = new ArrayList();
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {
			String fileNo = (String) inParams.get("fileNo");
			if (fileNo != null) {
				getTransactionDetails = viewTransactionDetailsDAOImpl.findFileDetails(fileNo);
				if (getTransactionDetails != null
						&& getTransactionDetails.size() > 0) {
					logger.info("getTransactionDetails size : "
							+ getTransactionDetails.size());
					for (int cnt = 0; cnt < getTransactionDetails.size(); cnt++) {
						Map transDetailsMap = (Map) getTransactionDetails.get(cnt);
						transactionDetailsList.add(transDetailsMap);
					}
					outParams.put("transactionDetailsList", transactionDetailsList);
					response.setErrorStatus(SCFUConstants.SUCCESS);
					logger.info("outParams outParams : " + outParams);
				} else {
					logger.error("Tech Error");
					response.setErrorCode("emptyList");
				}
			}

		} catch (DAOException e) {
			response.setErrorCode(e.getErrorCode());
			response.setErrorStatus(SCFUConstants.FAILURE);
		} catch (Exception e) {
			logger.error("Error occured : ", e);
			response.setErrorCode("TechnicalProblem ");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setViewTransactionDetailsDAOImpl(
			ViewTransactionDetailsDAO viewTransactionDetailsDAOImpl) {
		this.viewTransactionDetailsDAOImpl = viewTransactionDetailsDAOImpl;
	}

}
