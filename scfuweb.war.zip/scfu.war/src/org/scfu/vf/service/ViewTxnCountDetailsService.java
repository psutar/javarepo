package org.scfu.vf.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;

@SuppressWarnings({"rawtypes","unchecked"})

public class ViewTxnCountDetailsService extends BaseService {

	private Logger logger = Logger.getLogger(getClass());
	private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute(Map inParams)" + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map txnCountDetails = null;
		Map outParams = new HashMap();
		String fileNo = (String) inParams.get("fileNo");

		try {
			txnCountDetails = authoriseFileTxnDAOImpl.viewTxnCountDetails(fileNo);
			if (txnCountDetails != null && txnCountDetails.size() > 0) {
				logger.info("txnCountDetails.size() : "+ txnCountDetails.size());
				outParams.put("txnCountDetails", txnCountDetails);
				response.setErrorStatus(SCFUConstants.SUCCESS);
			}
		} catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setAuthoriseFileTxnDAOImpl(
			AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}
}
