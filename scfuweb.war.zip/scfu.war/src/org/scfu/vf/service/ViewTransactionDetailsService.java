/**
 * @author Prateek
 * This Class is used for Listing out the Detailed transaction 
 * list for a particular IM chosen for file status
 */
package org.scfu.vf.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.ViewTransactionDetailsDAO;
@SuppressWarnings({"rawtypes"})
public class ViewTransactionDetailsService extends BaseService {

	protected Logger logger = Logger.getLogger(getClass());
	private ViewTransactionDetailsDAO viewTransactionDetailsDAOImpl;

	public Map execute(Map inParams) {
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		List getTransactionDetails = null;
		Map<String , Object> outParams = new HashMap<String , Object>();
		List transactionDetailsList = new ArrayList();
		response.setErrorStatus(SCFUConstants.FAILURE);
		try {
			String userName = (String) inParams.get(SCFUConstants.USER_NAME);
			logger.info("username in ViewTransactionDetailsService :"
					+ userName);
			viewTransactionDetailsDAOImpl.fileStatus();
			if (userName != null) {
				getTransactionDetails = viewTransactionDetailsDAOImpl.findTransactionDetails(userName);
				if (getTransactionDetails != null
						&& getTransactionDetails.size() > 0) {
					logger.info("getTransactionDetails size : "+ getTransactionDetails.size());
					transactionDetailsList = getTransactionDetails;
					outParams.put("transactionDetailsList",transactionDetailsList);
					response.setErrorStatus(SCFUConstants.SUCCESS);
					// logger.info("outParams : " + outParams);
				} else {
					response.setErrorCode("noFilestoView");
					response.setErrorStatus(SCFUConstants.FAILURE);
				}
			}
		} catch (DAOException e) {
			response.setErrorCode(e.getErrorCode());
			response.setErrorStatus(SCFUConstants.FAILURE);
		} catch (Exception e) {
			logger.error("Error occured : ", e);
			response.setErrorCode("noFilestoView");
			response.setErrorStatus(SCFUConstants.FAILURE);
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute(Map inputParams)" + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setViewTransactionDetailsDAOImpl(
			ViewTransactionDetailsDAO viewTransactionDetailsDAOImpl) {
		this.viewTransactionDetailsDAOImpl = viewTransactionDetailsDAOImpl;
	}

}
