package org.scfu.vf.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.service.BaseService;
import org.scfu.common.exception.DAOException;
import org.scfu.common.exception.SCFUApplicationResponse;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.dao.AuthoriseFileTxnDAO;
@SuppressWarnings({ "rawtypes", "unchecked" })
public class ViewTxnFileDetailsService extends BaseService{

	private Logger logger = Logger.getLogger(getClass());
	private AuthoriseFileTxnDAO authoriseFileTxnDAOImpl;
	

	
	public Map execute(Map inParams) {
		logger.info("execute " + SCFUConstants.METHOD_BEGINS);
		SCFUApplicationResponse response = new SCFUApplicationResponse();
		response.setErrorStatus(SCFUConstants.FAILURE);
		Map<String , Object> outParams = new HashMap();
		String fileNo = (String) inParams.get("fileNo");
		String userName = (String) inParams.get("userName");
		try {
			List fileUploaderDetails = authoriseFileTxnDAOImpl.fileUploaderDetails(fileNo);
			if (fileUploaderDetails != null & fileUploaderDetails.size() > 0) {
				outParams.put("fileUploaderDetails", fileUploaderDetails);
			}
			List txnFileDetails = authoriseFileTxnDAOImpl.viewTxnFileDetails(
					fileNo, userName);
			if (txnFileDetails != null & txnFileDetails.size() > 0) {
				logger.info("txnFileDetails.size() : " + txnFileDetails.size());
				outParams.put("txnFileDetails", txnFileDetails);
				response.setErrorStatus(SCFUConstants.SUCCESS);
			}
		} catch (DAOException e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode(e.getErrorCode());
		} catch (Exception e) {
			logger.error("Error Occured :" + e.getMessage());
			response.setErrorCode("TechnicalProblem");
		}
		outParams.put(SCFUConstants.APPLICATION_RESPONSE, response);
		logger.info("execute " + SCFUConstants.METHOD_ENDS);
		return outParams;
	}

	public void setAuthoriseFileTxnDAOImpl(AuthoriseFileTxnDAO authoriseFileTxnDAOImpl) {
		this.authoriseFileTxnDAOImpl = authoriseFileTxnDAOImpl;
	}
}
