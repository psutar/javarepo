package org.scfu.vf.converter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.VendorReportDetails;
import org.scfu.vf.utils.ConsignmentPDFConverter;
import org.scfu.vf.utils.VendorReportConvertor;

public class ConsignmentOverdueReportConvertor extends VendorReportConvertor{
	
	Logger logger = Logger.getLogger(getClass());
	private String fileSaveUrl;
	private String imagesFolder;
	
	public String convert(Map<String, Object> inParams, String fileName) {
		logger.info("convert(Map<String, Object> inParams, String fileName) "+SCFUConstants.METHOD_BEGINS);
		List reportList = (List) inParams.get("vendorDetailsList");
		String fileType = (String) inParams.get("fileType");
		String vendorName = (String) inParams.get("vendorName");
		logger.info("vendorName :"+vendorName);
		logger.info("fileType :" + fileType);
		if (reportList != null && reportList.size() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase("pdf")) {
				pdfConvertor(inParams, fileName, vendorName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("csv")) {
				csvConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("ascii")) {
				asciiConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
			}
		}
		logger.info("fileName :" + fileName);
		logger.info("convert(Map<String, Object> inParams, String fileName)"+SCFUConstants.METHOD_ENDS);
		return fileName;
	}
	
	public void pdfConvertor(Map inParams, String fileName, String vendorName) {
		logger.info("pdfConvertor"+SCFUConstants.METHOD_BEGINS);
		ConsignmentPDFConverter pdfGen = new ConsignmentPDFConverter();
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
		pdfGen.pdfCreateFile(fileName);
		// logger.info("inputParams"+inParams);
		logger.info("Vendor detail list"+ (List) inParams.get("vendorDetailsList"));
		logger.info("imagesFolder :" + imagesFolder);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("reportList" + reportListMap);
		/*String date = new Date().toString();
		String sysdate = String.format(date,"dd/mm/yyyy");*/
		if (reportListMap != null && reportListMap.size() > 0) {
			
						
			pdfGen.addPdfImage(imagesFolder + "pdflogo.jpg");
			pdfGen.addPDFHeading("OVERDUE REPORT for "+vendorName );
			//pdfGen.addPDFHeadingDate(sysdate);
			pdfGen.addValueLeft(" ");
			pdfGen.setColumnSize(16);
			
			pdfGen.addLabelLeft("REFERENCE NO");
			pdfGen.addLabelLeft("VENDOR CODE");
			pdfGen.addLabelLeft("NAME");
			pdfGen.addLabelLeft("OVERDUE AMOUNT");
			pdfGen.addLabelLeft("STATUS");
			pdfGen.addLabelLeft("CREATION DATE");
			pdfGen.addLabelLeft("TRANSACTION DATE");
			pdfGen.addLabelLeft("REVERSAL DATE");
			pdfGen.addLabelLeft("NO OF OVERDUE DAYS");
			pdfGen.addLabelLeft("PRINCIPAL REF NO");
			pdfGen.addLabelLeft("PRINCIPAL AMOUNT");
			pdfGen.addLabelLeft("INTEREST REF NO");
			pdfGen.addLabelLeft("INTEREST AMOUNT");
			pdfGen.addLabelLeft("REVERSAL REF NO");
			pdfGen.addLabelLeft("CREDIT ACCOUNT NO");
			pdfGen.addLabelLeft("DEBIT ACCOUNT NO");
			for (VendorReportDetails reportDetailsMap : reportListMap) {
				
				pdfGen.addValueLeft((String) reportDetailsMap.getOverdue_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getVendor_code());
				pdfGen.addValueLeft((String) reportDetailsMap.getName());
				pdfGen.addValueRight((String) reportDetailsMap.getOverdue_amount());
				pdfGen.addValueLeft((String) reportDetailsMap.getStatus());
				pdfGen.addValueLeft((String) reportDetailsMap.getCreation_time());
				pdfGen.addValueLeft((String) reportDetailsMap.getTxn_completed_time());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_date());
				pdfGen.addValueRight((String) reportDetailsMap.getNo_of_days());
				pdfGen.addValueLeft((String) reportDetailsMap.getOrg_debit_ref_no());
				pdfGen.addValueRight((String) reportDetailsMap.getTransaction_amount_1());
				pdfGen.addValueLeft((String) reportDetailsMap.getInterest_ref_no());
				pdfGen.addValueRight((String) reportDetailsMap.getTransaction_amount());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getCredit_account_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getDebit_account_no());
			}
			pdfGen.endTableHeader();
		//	pdfGen.onEndPage(fileName);		
			pdfGen.addPdfTableFromJSP();

		}
		
		pdfGen.closeDocument();
		logger.info("pdfConvertor"+SCFUConstants.METHOD_ENDS);
	}
	
	public void csvConverter(Map inParams, String fileName) {
		logger.info("csvConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		try {
			if (reportListMap != null && reportListMap.size() > 0) {

				StringBuffer reportDetailsBuf = new StringBuffer();
				
				reportDetailsBuf.append("REFERENCE NO" + "\t");
				reportDetailsBuf.append("VENDOR CODE" + "\t");
				reportDetailsBuf.append("NAME" + "\t");
				reportDetailsBuf.append("OVERDUE AMOUNT" + "\t");
				reportDetailsBuf.append("STATUS" + "\t");
				reportDetailsBuf.append("CREATION DATE" + "\t");
				reportDetailsBuf.append("TRANSACTION DATE" + "\t");
				reportDetailsBuf.append("REVERSAL DATE" + "\t");
				reportDetailsBuf.append("NO OF OVERDUE DAYS" + "\t");
				reportDetailsBuf.append("PRINCIPAL REF NO" + "\t");
				reportDetailsBuf.append("PRINCIPAL AMOUNT" + "\t");
				reportDetailsBuf.append("INTEREST REF NO" + "\t");
				reportDetailsBuf.append("INTEREST AMOUNT" + "\t");
				reportDetailsBuf.append("REVERSAL REF NO" + "\t");
				reportDetailsBuf.append("CREDIT ACCOUNT NO" + "\t");
				reportDetailsBuf.append("DEBIT ACCOUNT NO" + "\t");
				reportDetailsBuf.append("" + "\n");

				for (VendorReportDetails reportDetailsMap : reportListMap) {

					
					reportDetailsBuf.append((String) reportDetailsMap.getOverdue_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getVendor_code()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getName() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getOverdue_amount() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getStatus() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCreation_time() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTxn_completed_time() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getNo_of_days() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getOrg_debit_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTransaction_amount_1() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInterest_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTransaction_amount() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCredit_account_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getDebit_account_no() + "\t");
					reportDetailsBuf.append("" + "\n");

				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(
						new FileWriter(new File(fileName))));
				pw.write(reportDetailsBuf.toString());
				pw.close();
			}

		} catch (Exception e) {
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("csvConverter"+SCFUConstants.METHOD_ENDS);
	}

	public void asciiConverter(Map inParams, String fileName) {
		logger.info("asciiConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		try {
			if (reportListMap != null && reportListMap.size() > 0) {
				StringBuffer outBuffer = new StringBuffer();
				// outBuffer.append("IM Details"+"\n");
				StringBuffer reportDetailsBuf = new StringBuffer(1015);
				String emptyString = " ";
				String title = "";
				for (int i = 0; i < 1000; i++) {
					emptyString = emptyString + " ";
				}
				reportDetailsBuf.replace(0, 1000, emptyString);

				
				title = "REFERENCE NO";
				reportDetailsBuf.replace(0, title.length(), title);

				title = "VENDOR CODE";
				reportDetailsBuf.replace(20, 20 + title.length(), title);

				title = "NAME";
				reportDetailsBuf.replace(40, 40 + title.length(), title);
				
				title = "OVERDUE AMOUNT";
				reportDetailsBuf.replace(75, 75 + title.length(), title);

				title = "STATUS";
				reportDetailsBuf.replace(105, 105 + title.length(), title);

				title = "CREATION DATE";
				reportDetailsBuf.replace(125, 125 + title.length(), title);
				
				title = "TRANSACTION DATE";
				reportDetailsBuf.replace(145, 145 + title.length(), title);

				title = "REVERSAL DATE";
				reportDetailsBuf.replace(165, 165 + title.length(), title);

				title = "NO OF OVERDUE DAYS";
				reportDetailsBuf.replace(185, 185 + title.length(), title);

				title = "PRINCIPAL REF NO";
				reportDetailsBuf.replace(215, 215 + title.length(), title);

				title = "PRINCIPAL AMOUNT";
				reportDetailsBuf.replace(235, 235 + title.length(), title);
				
				title = "INTEREST REF NO";
				reportDetailsBuf.replace(255, 255 + title.length(), title);
				
				title = "INTEREST AMOUNT";
				reportDetailsBuf.replace(275, 275 + title.length(), title);
				
				title = "REVERSAL REF NO";
				reportDetailsBuf.replace(295, 295 + title.length(), title);
				
				title = "CREDIT ACCOUNT NO";
				reportDetailsBuf.replace(315, 315 + title.length(), title);
				
				title = "DEBIT ACCOUNT NO";
				reportDetailsBuf.replace(355, 355 + title.length(), title);
				
				outBuffer.append(reportDetailsBuf + "\r\n");

				for (VendorReportDetails reportDetailsMap : reportListMap) {
					// logger.info("reportDetails: " + reportDetailsMap);
					reportDetailsBuf.replace(0, 1000, emptyString);

					
					title = (String) reportDetailsMap.getOverdue_ref_no();
					reportDetailsBuf.replace(0, title.length(), title);
					
					title = (String) reportDetailsMap.getVendor_code();
					reportDetailsBuf.replace(30, 30 + title.length(), title);

					title = (String) reportDetailsMap.getName();
					reportDetailsBuf.replace(60, 60 + title.length(), title);

					title = (String) reportDetailsMap.getOverdue_amount();
					reportDetailsBuf.replace(80, 80+title.length(), title);

					title = (String) reportDetailsMap.getStatus();
					reportDetailsBuf.replace(100, 100 + title.length(), title);
					
					title = (String) reportDetailsMap.getCreation_time();
					reportDetailsBuf.replace(120, 120 + title.length(), title);
					
					title = (String) reportDetailsMap.getTxn_completed_time();
					reportDetailsBuf.replace(140, 140 + title.length(), title);
					
					title = (String) reportDetailsMap.getReversal_date();
					reportDetailsBuf.replace(160, 160 + title.length(), title);
					
					title = (String) reportDetailsMap.getNo_of_days();
				
					reportDetailsBuf.replace(180, 180 + title.length(), title);
					title = (String) reportDetailsMap.getOrg_debit_ref_no();
					
					reportDetailsBuf.replace(200, 200 + title.length(), title);
					title = (String) reportDetailsMap.getTransaction_amount_1();

					reportDetailsBuf.replace(220, 220 + title.length(), title);
					
					title = (String) reportDetailsMap.getInterest_ref_no();
					reportDetailsBuf.replace(240, 240 + title.length(), title);

					title = (String) reportDetailsMap.getTransaction_amount();
					reportDetailsBuf.replace(260, 260 + title.length(), title);
					
					title = (String) reportDetailsMap.getReversal_ref_no();
					reportDetailsBuf.replace(280, 280 + title.length(), title);
					
					title = (String) reportDetailsMap.getCredit_account_no();
					reportDetailsBuf.replace(300, 300 + title.length(), title);
					
					title = (String) reportDetailsMap.getDebit_account_no();
					reportDetailsBuf.replace(320, 320 + title.length(), title);
					
					outBuffer.append(reportDetailsBuf + "\r\n");
				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName))));
				pw.write(outBuffer.toString());
				pw.close();
			}

		} catch (Exception e) {

			logger.info("specific exception type: " + e.getClass());
			logger.info(" exception: " + e.getCause());
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("asciiConverter"+SCFUConstants.METHOD_ENDS);

	}

	public void setImagesFolder(String imagesFolder) {
		this.imagesFolder = imagesFolder;
	}

	public void setFileSaveUrl(String fileSaveUrl) {
		this.fileSaveUrl = fileSaveUrl;
	}
}
