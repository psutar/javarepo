package org.scfu.vf.converter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.VendorReportDetails;
import org.scfu.vf.utils.ConsignmentPDFConverter;
import org.scfu.vf.utils.VendorReportConvertor;

public class ConsignmentInterestReportConvertor extends VendorReportConvertor {
	Logger logger = Logger.getLogger(getClass());
	private String fileSaveUrl;
	private String imagesFolder;

	/**
	 * 1.Depending on the file type call the corresponding converter 2.Returns
	 * the file name after writing the file in the path
	 */
	public String convert(Map<String, Object> inParams, String fileName) {
		logger.info("convert(Map<String, Object> inParams, String fileName) method begins");
		List reportList = (List) inParams.get("vendorDetailsList");
		String fileType = (String) inParams.get("fileType");
		String vendorName = (String) inParams.get("vendorName");
		logger.info("fileType" + fileType);
		if (reportList != null && reportList.size() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase("pdf")) {
				pdfConvertor(inParams, fileName, vendorName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("csv")) {
				csvConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("ascii")) {
				asciiConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
			}
		}
		logger.info("fileName :" + fileName);
		logger.info("convert(Map<String, Object> inParams, String fileName) method ends");
		return fileName;
	}

	public void pdfConvertor(Map inParams, String fileName, String vendorName) {
		logger.info("pdfConvertor(Map inputParams, String fileName) method begins");
		ConsignmentPDFConverter pdfGen = new ConsignmentPDFConverter();
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
		pdfGen.pdfCreateFile(fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		if (reportListMap != null && reportListMap.size() > 0) {

			pdfGen.addPdfImage(imagesFolder + "pdflogo.jpg");
			pdfGen.addPDFHeading("INTEREST REPORT for "+vendorName );
			pdfGen.setColumnSize(15);
			pdfGen.addLabelLeft("REFERENCE NO");
			pdfGen.addLabelLeft("VENDOR CODE");
			pdfGen.addLabelLeft("NAME");
			pdfGen.addLabelLeft("INTEREST AMOUNT");
			pdfGen.addLabelLeft("PRINCIPAL AMOUNT");
			pdfGen.addLabelLeft("STATUS");
			pdfGen.addLabelLeft("CREATION DATE");
			pdfGen.addLabelLeft("TRANSACTION DATE");
			pdfGen.addLabelLeft("PRINCIPAL REF NO");
			pdfGen.addLabelLeft("REVERSAL REF NO");
			pdfGen.addLabelLeft("INVOICE NO");
			pdfGen.addLabelLeft("INVOICE DATE");
			pdfGen.addLabelLeft("REVERSAL DATE");
			pdfGen.addLabelLeft("CREDIT ACCOUNT NO");
			pdfGen.addLabelLeft("DEBIT ACCOUNT NO");

			for (VendorReportDetails reportDetailsMap : reportListMap) {
				pdfGen.addValueLeft((String) reportDetailsMap.getReference_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getVendor_code());
				pdfGen.addValueLeft((String) reportDetailsMap.getName());
				pdfGen.addValueRight((String) reportDetailsMap.getTransaction_amount());
				pdfGen.addValueRight((String) reportDetailsMap.getTransaction_amount_1());
				pdfGen.addValueLeft((String) reportDetailsMap.getStatus());
				pdfGen.addValueLeft((String) reportDetailsMap.getCreation_time());
				pdfGen.addValueLeft((String) reportDetailsMap.getTxn_completed_time());
				pdfGen.addValueLeft((String) reportDetailsMap.getOrg_debit_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getInvoice_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getInvoice_date());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_date());
				pdfGen.addValueLeft((String) reportDetailsMap.getCredit_account_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getDebit_account_no());
			}
			pdfGen.endTableHeader();
			pdfGen.addPdfTableFromJSP();
		}
		pdfGen.closeDocument();
		logger.info("pdfConvertor(Map inputParams, String fileName) method ends");

	}
	public void csvConverter(Map inParams, String fileName) {
		logger.info("csvConverter(Map inputParams, String fileName) method begins");
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		try{
			if (reportListMap != null && reportListMap.size() > 0) {

				StringBuffer reportDetailsBuf = new StringBuffer();

				reportDetailsBuf.append("REFERENCE NO" + "\t");
				reportDetailsBuf.append("VENDOR CODE" + "\t");
				reportDetailsBuf.append("NAME" + "\t");
				reportDetailsBuf.append("INTEREST AMOUNT" + "\t");
				reportDetailsBuf.append("PRINCIPAL AMOUNT" + "\t");
				reportDetailsBuf.append("STATUS" + "\t");
				reportDetailsBuf.append("CREATION DATE" + "\t");
				reportDetailsBuf.append("TRANSACTION DATE" + "\t");
				reportDetailsBuf.append("PRINCIPAL REF NO" + "\t");
				reportDetailsBuf.append("REVERSAL REF NO" + "\t");
				reportDetailsBuf.append("INVOICE NO" + "\t");
				reportDetailsBuf.append("INVOICE DATE" + "\t");
				reportDetailsBuf.append("REVERSAL DATE" + "\t");
				reportDetailsBuf.append("CREDIT ACCOUNT NO" + "\t");
				reportDetailsBuf.append("DEBIT ACCOUNT NO" + "\t");

				reportDetailsBuf.append("" + "\n");
				for (VendorReportDetails reportDetailsMap : reportListMap) {
					reportDetailsBuf.append((String) reportDetailsMap.getReference_no()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getVendor_code()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getName()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTransaction_amount()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTransaction_amount_1()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getStatus()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCreation_time()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTxn_completed_time()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getOrg_debit_ref_no()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_ref_no()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInvoice_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInvoice_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCredit_account_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getDebit_account_no() + "\t");
					reportDetailsBuf.append("" + "\n");
				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(
						new FileWriter(new File(fileName))));
				pw.write(reportDetailsBuf.toString());
				pw.close();
			}
		}
		catch (Exception e) {
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("csvConverter(Map inputParams, String fileName) method ends");
	}

	public void asciiConverter(Map inParams, String fileName) {
		logger.info("asciiConverter(Map inputParams, String fileName) method begins");
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("Vendordetaillist::::" +inParams.get("vendorDetailsList"));
		logger.info("reportListMap::::" +reportListMap.size());
		try {
			if (reportListMap != null && reportListMap.size() > 0) {
				StringBuffer outBuffer = new StringBuffer();
				// outBuffer.append("IM Details"+"\n");
				StringBuffer reportDetailsBuf = new StringBuffer(1015);
				String emptyString = " ";
				String title = "";
				for (int i = 0; i < 1000; i++) {
					emptyString = emptyString + " ";
				}
				reportDetailsBuf.replace(0, 1000, emptyString);

				title = "REFERENCE NO";
				reportDetailsBuf.replace(0, title.length(), title);

				title = "VENDOR CODE";
				reportDetailsBuf.replace(20, 20 + title.length(), title);
				
				title = "NAME";
				reportDetailsBuf.replace(35, 35 + title.length(), title);
				
				title = "INTEREST AMOUNT";
				reportDetailsBuf.replace(65, 65 + title.length(), title);
				
				title = "PRINCIPAL AMOUNT";
				reportDetailsBuf.replace(95, 95 + title.length(), title);
				
				title = "STATUS";
				reportDetailsBuf.replace(115, 115 + title.length(), title);

				title = "CREATION DATE";
				reportDetailsBuf.replace(135, 135 + title.length(), title);

				title = "TRANSACTION DATE";
				reportDetailsBuf.replace(165, 165 + title.length(), title);

				title = "PRINCIPAL REF NO";
				reportDetailsBuf.replace(195, 195 + title.length(), title);
				
				title = "REVERSAL REF NO";
				reportDetailsBuf.replace(215, 215 + title.length(), title);
				
				title = "INVOICE NO";
				reportDetailsBuf.replace(245, 245 + title.length(), title);
				
				title = "INVOICE DATE";
				reportDetailsBuf.replace(275, 275 + title.length(), title);
				
				title = "REVERSAL DATE";
				reportDetailsBuf.replace(275, 275 + title.length(), title);
				
				title = "CREDIT ACCOUNT NO";
				reportDetailsBuf.replace(305, 305 + title.length(), title);
				
				title = "DEBIT ACCOUNT NO";
				reportDetailsBuf.replace(335, 335 + title.length(), title);
				

				outBuffer.append(reportDetailsBuf + "\r\n");

				for (VendorReportDetails reportDetailsMap : reportListMap) {
					reportDetailsBuf.replace(0, 1000, emptyString);

					title = (String) reportDetailsMap.getReference_no();
					reportDetailsBuf.replace(0, title.length(), title);

					title = (String) reportDetailsMap.getVendor_code();
					reportDetailsBuf.replace(20, 20 + title.length(), title);
					
					title = (String) reportDetailsMap.getName();
					reportDetailsBuf.replace(35, 35 + title.length(), title);
					
					title = (String) reportDetailsMap.getTransaction_amount();
					reportDetailsBuf.replace(65, 65 + title.length(), title);
					
					title = (String) reportDetailsMap.getTransaction_amount_1();
					reportDetailsBuf.replace(95, 95 + title.length(), title);
					
					title = (String) reportDetailsMap.getStatus();
					reportDetailsBuf.replace(115, 115 + title.length(), title);

					title = (String) reportDetailsMap.getCreation_time();
					reportDetailsBuf.replace(145, 145 + title.length(), title);

					title = (String) reportDetailsMap.getTxn_completed_time();
					reportDetailsBuf.replace(175, 175 + title.length(), title);

					title = (String) reportDetailsMap.getOrg_debit_ref_no();
					reportDetailsBuf.replace(205, 205 + title.length(), title);	
					
					title = (String) reportDetailsMap.getReversal_ref_no();
					reportDetailsBuf.replace(235, 235 + title.length(), title);
					
					title = (String) reportDetailsMap.getInvoice_no();
					reportDetailsBuf.replace(265, 265 + title.length(), title);
					
					title = (String) reportDetailsMap.getInvoice_date();
					reportDetailsBuf.replace(295, 295 + title.length(), title);
					
					title = (String) reportDetailsMap.getReversal_date();
					reportDetailsBuf.replace(325, 325 + title.length(), title);
					
					title = (String) reportDetailsMap.getCredit_account_no();
					reportDetailsBuf.replace(355, 355 + title.length(), title);
					
					title = (String) reportDetailsMap.getDebit_account_no();
					reportDetailsBuf.replace(385, 385 + title.length(), title);
					
					
					outBuffer.append(reportDetailsBuf + "\r\n");
				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName))));
				pw.write(outBuffer.toString());
				pw.close();
			}
		}
		catch (Exception e) {

			logger.info("specific exception type: " + e);
			logger.info(" exception: " + e.getCause());
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("asciiConverter"+SCFUConstants.METHOD_ENDS);
	}

	public void setFileSaveUrl(String fileSaveUrl) {
		this.fileSaveUrl = fileSaveUrl;
	}
	public void setImagesFolder(String imagesFolder) {
		this.imagesFolder = imagesFolder;
	}
}
