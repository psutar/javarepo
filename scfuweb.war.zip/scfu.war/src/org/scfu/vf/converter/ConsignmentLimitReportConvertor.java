package org.scfu.vf.converter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.VendorReportDetails;
import org.scfu.vf.utils.ConsignmentPDFConverter;
import org.scfu.vf.utils.VendorReportConvertor;
@SuppressWarnings({"rawtypes","unchecked"})
public class ConsignmentLimitReportConvertor extends VendorReportConvertor {
	Logger logger = Logger.getLogger(getClass());
	private String fileSaveUrl;
	private String imagesFolder;
	
	/**
	 * 1.Depending on the file type call the corresponding convertor 2.Returns
	 * the file name after writing the file in the path
	 */
	public String convert(Map<String, Object> inParams, String fileName) {
		logger.info("convert"+SCFUConstants.METHOD_BEGINS);
		List reportList = (List) inParams.get("vendorDetailsList");
		String fileType = (String) inParams.get("fileType");
		String vendorName = (String) inParams.get("vendorName");
		logger.info("fileType" + fileType);
		if (reportList != null && reportList.size() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase("pdf")) {
				pdfConvertor(inParams, fileName, vendorName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("csv")) {
				csvConverter(inParams, fileName);
				fileName = fileName +  SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("ascii")) {
				asciiConverter(inParams, fileName);
				fileName = fileName +  SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
			}
		}
		logger.info("fileName :" + fileName);
		logger.info("convert :"+SCFUConstants.METHOD_ENDS);
		return fileName;
	}
	public void pdfConvertor(Map inParams, String fileName, String vendorName) {
		logger.info("pdfConvertor"+SCFUConstants.METHOD_BEGINS);
		ConsignmentPDFConverter pdfGen = new ConsignmentPDFConverter();
		fileName = fileSaveUrl + fileName+ SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
		pdfGen.pdfCreateFile(fileName);
		logger.info("Vendor detail list"+(List) inParams.get("vendorDetailsList"));
		
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("Vendor detail list"+(List) inParams.get("imDetailsList"));
		List<VendorReportDetails> reportIMListMap = (List) inParams.get("imDetailsList");
		logger.info("reportList"+reportListMap);
		
		pdfGen.addPdfImage(imagesFolder + "pdflogo.jpg");
		//pdfGen.addPDFHeading("LIMIT REPORT for "+vendorName );
		if (reportIMListMap != null && reportIMListMap.size() > 0) {
			
			
			VendorReportDetails imNameMap=(VendorReportDetails) reportIMListMap.get(0);
			String imName=(String)imNameMap.getName();
			logger.info("IM Name  +++++++++++++++++++++: "+imName);
			pdfGen.addPDFHeading("IM LIMIT REPORT FOR : "+imName );
			pdfGen.setColumnSize(5);
			pdfGen.addLabelLeft("IM NAME");
			/*pdfGen.addLabelLeft("IM CODE");*/
			pdfGen.addLabelLeft("ALLOCATED LIMIT");
			pdfGen.addLabelLeft("OUTSTANDING LIMIT");
			pdfGen.addLabelLeft("AVAILABLE LIMIT");
			pdfGen.addLabelLeft("LIMIT EXPIRY DATE");
			
			for (VendorReportDetails reportDetailsMap : reportIMListMap) {
				
				pdfGen.addValueLeft((String) reportDetailsMap.getName());
				/*pdfGen.addValueLeft((String) reportDetailsMap.getIm_code());*/
				pdfGen.addValueRight((String) reportDetailsMap.getAllocated_limit());
				pdfGen.addValueRight((String) reportDetailsMap.getOutstanding_limit());
				pdfGen.addValueRight((String) reportDetailsMap.getAvailable_limit());
				pdfGen.addValueLeft((String) reportDetailsMap.getLimit_expiry_date());
				
			}
			pdfGen.endTableHeader();
			pdfGen.addPdfTableFromJSP();
		}
		if (reportListMap != null && reportListMap.size() > 0) {
			
			pdfGen.addPDFHeading("VENDOR LIMIT REPORT for :"+vendorName );
			pdfGen.setColumnSize(6);
			pdfGen.addLabelLeft("VENDOR NAME");
			pdfGen.addLabelLeft("VENDOR CODE");
			pdfGen.addLabelLeft("ALLOCATED LIMIT");
			pdfGen.addLabelLeft("OUTSTANDING LIMIT");
			pdfGen.addLabelLeft("AVAILABLE LIMIT");
			pdfGen.addLabelLeft("LIMIT EXPIRY DATE");
			
			for (VendorReportDetails reportDetailsMap : reportListMap) {
				
				pdfGen.addValueLeft((String) reportDetailsMap.getName());
				pdfGen.addValueLeft((String) reportDetailsMap.getVendor_code());
				pdfGen.addValueRight((String) reportDetailsMap.getAllocated_limit());
				pdfGen.addValueRight((String) reportDetailsMap.getOutstanding_limit());
				pdfGen.addValueRight((String) reportDetailsMap.getAvailable_limit());
				pdfGen.addValueLeft((String) reportDetailsMap.getLimit_expiry_date());
			}
			pdfGen.endTableHeader();
			pdfGen.addPdfTableFromJSP();
		}

		pdfGen.closeDocument();
		logger.info("pdfConvertor :"+SCFUConstants.METHOD_ENDS);

	}
	public void csvConverter(Map inParams, String fileName) {
		logger.info("csvConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName +  SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("im detail list"+(List) inParams.get("imDetailsList"));
		List<VendorReportDetails> reportIMListMap = (List) inParams.get("imDetailsList");
		try{
			if (reportListMap != null && reportListMap.size() > 0 && reportIMListMap != null && reportIMListMap.size() > 0) {
				
				StringBuffer reportDetailsBuf = new StringBuffer();
				reportDetailsBuf.append("IM LIMIT REPORT" + "\n");
				reportDetailsBuf.append("NAME" + "\t");
			//	reportDetailsBuf.append("IM CODE" + "\t");
				reportDetailsBuf.append("ALLOCATED LIMIT" + "\t");
				reportDetailsBuf.append("OUTSTANDING LIMIT" + "\t");
				reportDetailsBuf.append("AVAILABLE LIMIT" + "\t");
				reportDetailsBuf.append("LIMIT EXPIRY DATE" + "\t");
				reportDetailsBuf.append("" + "\n");
				
				for (VendorReportDetails reportDetailsMap : reportIMListMap) {
					reportDetailsBuf.append((String) reportDetailsMap.getName()+ "\t");
				//	reportDetailsBuf.append((String) reportDetailsMap.getIm_code()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getAllocated_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getOutstanding_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getAvailable_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getLimit_expiry_date()+ "\t");
					reportDetailsBuf.append("" + "\n");
			}
				reportDetailsBuf.append("" + "\n");
				reportDetailsBuf.append("" + "\n");
				reportDetailsBuf.append("VENDOR LIMIT REPORT" + "\n");
				
				reportDetailsBuf.append("NAME" + "\t");
				reportDetailsBuf.append("VENDOR CODE" + "\t");
				reportDetailsBuf.append("ALLOCATED LIMIT" + "\t");
				reportDetailsBuf.append("OUTSTANDING LIMIT" + "\t");
				reportDetailsBuf.append("AVAILABLE LIMIT" + "\t");
				reportDetailsBuf.append("LIMIT EXPIRY DATE" + "\t");
				
				reportDetailsBuf.append("" + "\n");
				
				for (VendorReportDetails reportDetailsMap : reportListMap) {
					
					reportDetailsBuf.append((String) reportDetailsMap.getName()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getVendor_code()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getAllocated_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getOutstanding_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getAvailable_limit()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getLimit_expiry_date()+ "\t");
					
					reportDetailsBuf.append("" + "\n");
							}
				
				PrintWriter pw = new PrintWriter(new BufferedWriter(
						new FileWriter(new File(fileName))));
				pw.write(reportDetailsBuf.toString());
				pw.close();
			}
			
		}
		catch (Exception e) {
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("csvConverter"+SCFUConstants.METHOD_ENDS);
	}
	
	public void asciiConverter(Map inParams, String fileName) {
		logger.info("asciiConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName +  SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("Vendor detail list :" +inParams.get("vendorDetailsList"));
		logger.info("Vendor detail list size:" +reportListMap.size());
		List<VendorReportDetails> reportIMListMap = (List) inParams.get("imDetailsList");
		logger.info("im detail list :"+(List) inParams.get("imDetailsList"));
		logger.info("reportListMap::::" +reportListMap.size());
		try {
			if (reportListMap != null && reportListMap.size() > 0 && reportIMListMap != null && reportIMListMap.size() > 0 ) {
				StringBuffer outBuffer = new StringBuffer();
				// outBuffer.append("IM Details"+"\n");
				StringBuffer reportDetailsBuf = new StringBuffer(1015);
				String emptyString = " ";
				String title = "";
				for (int i = 0; i < 1000; i++) {
				emptyString = emptyString + " ";
				}
				outBuffer.append("-----IM REPORT-----"+ "\r\n");
				reportDetailsBuf.replace(0, 1000, emptyString);
				
				title = "NAME";
				reportDetailsBuf.replace(0,title.length(), title);
				
				title = "IM CODE";
				reportDetailsBuf.replace(40, 40 + title.length(), title);

				title = "ALLOCATED LIMIT";
				reportDetailsBuf.replace(80, 80 + title.length(), title);

				title = "OUTSTANDING LIMIT";
				reportDetailsBuf.replace(105, 105 + title.length(), title);

				title = "AVAILABLE LIMIT";
				reportDetailsBuf.replace(155, 155 + title.length(), title);

				title = "LIMIT EXPIRY DATE";
				reportDetailsBuf.replace(188, 188 + title.length(), title);

				
				outBuffer.append(reportDetailsBuf + "\r\n");
				
				for (VendorReportDetails reportDetailsMap : reportIMListMap) {
					//	logger.info("reportDetails: " + reportDetailsMap);
						reportDetailsBuf.replace(0, 1000, emptyString);
						
						title = (String) reportDetailsMap.getName();
						reportDetailsBuf.replace(0, title.length(), title);
						
						title = (String) reportDetailsMap.getIm_code();
						reportDetailsBuf.replace(40, 40 + title.length(), title);

						title = (String) reportDetailsMap.getAllocated_limit();
						reportDetailsBuf.replace(80, 80 + title.length(), title);

						title = (String) reportDetailsMap.getOutstanding_limit();
						reportDetailsBuf.replace(105, 105 + title.length(), title);

						title = (String) reportDetailsMap.getAvailable_limit();
						reportDetailsBuf.replace(155, 155 + title.length(), title);

						title = (String) reportDetailsMap.getLimit_expiry_date();
						reportDetailsBuf.replace(188, 188 + title.length(), title);

						outBuffer.append(reportDetailsBuf + "\r\n");
					}
			//	outBuffer.append(reportDetailsBuf + "\r\n");
				outBuffer.append( "\r\n");
				outBuffer.append("-----VENDOR REPORT-----"+ "\r\n");
				reportDetailsBuf.replace(0, 1000, emptyString);
				
				title = "NAME";
				reportDetailsBuf.replace(0, title.length(), title);
				
				title = "VENDOR CODE";
				reportDetailsBuf.replace(40, 40 + title.length(), title);

				title = "ALLOCATED LIMIT";
				reportDetailsBuf.replace(80, 80 + title.length(), title);

				title = "OUTSTANDING LIMIT";
				reportDetailsBuf.replace(105, 105 + title.length(), title);

				title = "AVAILABLE LIMIT";
				reportDetailsBuf.replace(155, 155 + title.length(), title);

				title = "LIMIT EXPIRY DATE";
				reportDetailsBuf.replace(188, 188 + title.length(), title);

				
				outBuffer.append(reportDetailsBuf + "\r\n");
				
				for (VendorReportDetails reportDetailsMap : reportListMap) {
					//logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
						reportDetailsBuf.replace(0, 1000, emptyString);
						
						title = (String) reportDetailsMap.getName();
						reportDetailsBuf.replace(0, title.length(), title);
						
						title = (String) reportDetailsMap.getVendor_code();
						reportDetailsBuf.replace(40, 40 + title.length(), title);

						title = (String) reportDetailsMap.getAllocated_limit();
						reportDetailsBuf.replace(80, 80 + title.length(), title);

						title = (String) reportDetailsMap.getOutstanding_limit();
						reportDetailsBuf.replace(105, 105 + title.length(), title);

						title = (String) reportDetailsMap.getAvailable_limit();
						reportDetailsBuf.replace(155, 155 + title.length(), title);

						title = (String) reportDetailsMap.getLimit_expiry_date();
						reportDetailsBuf.replace(188, 188 + title.length(), title);

						outBuffer.append(reportDetailsBuf +"\r\n");
					}
				
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName))));
				pw.write(outBuffer.toString());
				pw.close();
				}
			
		}
		catch (Exception e) {

			logger.info("specific exception type: " + e);
			logger.info(" exception: " + e.getCause());
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("asciiConverter"+SCFUConstants.METHOD_ENDS);

			
		}
	public void setFileSaveUrl(String fileSaveUrl) {
		this.fileSaveUrl = fileSaveUrl;
	}
	public void setImagesFolder(String imagesFolder) {
		this.imagesFolder = imagesFolder;
	}
}
