package org.scfu.vf.converter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.scfu.common.constants.SCFUConstants;
import org.scfu.vf.model.VendorConsignReportDetails;
import org.scfu.vf.model.VendorReportDetails;
import org.scfu.vf.utils.ConsignmentPDFConverter;
import org.scfu.vf.utils.VendorReportConvertor;

import com.lowagie.text.Document;

public class ConsignmentReportConvertor extends VendorReportConvertor {

	Logger logger = Logger.getLogger(getClass());
	private String fileSaveUrl;
	private String imagesFolder;

	/**
	 * 1.Depending on the file type call the corresponding converter 2.Returns
	 * the file name after writing the file in the path
	 */
	 @SuppressWarnings({"rawtypes"})
	public String convert(Map<String, Object> inParams, String fileName) {
		logger.info("convert(Map<String, Object> inParams, String fileName) "+SCFUConstants.METHOD_BEGINS);
		List reportList = (List) inParams.get("vendorDetailsList");
		String fileType = (String) inParams.get("fileType");
		String vendorName = (String) inParams.get("vendorName");
		logger.info("vendorName :"+vendorName);
		logger.info("fileType :" + fileType);
		if (reportList != null && reportList.size() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase("pdf")) {
				pdfConvertor(inParams, fileName, vendorName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("csv")) {
				csvConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
			}
			if (fileType != null && fileType.equalsIgnoreCase("ascii")) {
				asciiConverter(inParams, fileName);
				fileName = fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
			}
		}
		logger.info("fileName :" + fileName);
		logger.info("convert(Map<String, Object> inParams, String fileName)"+SCFUConstants.METHOD_ENDS);
		return fileName;
	}

	public void pdfConvertor(Map inParams, String fileName, String vendorName) {
		logger.info("pdfConvertor"+SCFUConstants.METHOD_BEGINS);
		ConsignmentPDFConverter pdfGen = new ConsignmentPDFConverter();
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.PDF_EXTENSION;
		pdfGen.pdfCreateFile(fileName);
		// logger.info("inputParams"+inParams);
		logger.info("Vendor detail list"+ (List) inParams.get("vendorDetailsList"));
		logger.info("imagesFolder :" + imagesFolder);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		logger.info("reportList" + reportListMap);
		/*String date = new Date().toString();
		String sysdate = String.format(date,"dd/mm/yyyy");*/
		if (reportListMap != null && reportListMap.size() > 0) {
			
						
			pdfGen.addPdfImage(imagesFolder + "pdflogo.jpg");
			pdfGen.addPDFHeading("PRINCIPAL REPORT for "+vendorName );
			//pdfGen.addPDFHeadingDate(sysdate);
			pdfGen.addValueLeft(" ");
			pdfGen.setColumnSize(15);
			
			pdfGen.addLabelLeft("REFERENCE NO");
			pdfGen.addLabelLeft("VENDOR CODE");
			pdfGen.addLabelLeft("NAME");
			pdfGen.addLabelLeft("AMOUNT");
			pdfGen.addLabelLeft("STATUS");
			pdfGen.addLabelLeft("CREATION DATE");
			pdfGen.addLabelLeft("TRANSACTION DATE");
			pdfGen.addLabelLeft("REVERSAL DATE");
			pdfGen.addLabelLeft("INTEREST REF NO");
			pdfGen.addLabelLeft("REVERSAL REF NO");
			pdfGen.addLabelLeft("INVOICE NO");
			pdfGen.addLabelLeft("INVOICE DATE");
			pdfGen.addLabelLeft("FILE NO");
			pdfGen.addLabelLeft("CREDIT ACCOUNT NO");
			pdfGen.addLabelLeft("DEBIT ACCOUNT NO");
			
			for (VendorReportDetails reportDetailsMap : reportListMap) {
				
				pdfGen.addValueLeft((String) reportDetailsMap.getReference_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getVendor_code());
				pdfGen.addValueLeft((String) reportDetailsMap.getName());
				pdfGen.addValueRight((String) reportDetailsMap.getAmount());
				pdfGen.addValueLeft((String) reportDetailsMap.getStatus());
				pdfGen.addValueLeft((String) reportDetailsMap.getCreation_time());
				pdfGen.addValueLeft((String) reportDetailsMap.getTransaction_date());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_date());
				pdfGen.addValueLeft((String) reportDetailsMap.getInterest_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getReversal_ref_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getInvoice_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getInvoice_date());
				pdfGen.addValueLeft((String) reportDetailsMap.getFile_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getCredit_account_no());
				pdfGen.addValueLeft((String) reportDetailsMap.getDebit_account_no());
			}
			pdfGen.endTableHeader();
		//	pdfGen.onEndPage(fileName);		
			pdfGen.addPdfTableFromJSP();

		}
		
		pdfGen.closeDocument();
		logger.info("pdfConvertor"+SCFUConstants.METHOD_ENDS);
	}

	public void csvConverter(Map inParams, String fileName) {
		logger.info("csvConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.XLS_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		try {
			if (reportListMap != null && reportListMap.size() > 0) {

				StringBuffer reportDetailsBuf = new StringBuffer();
				
				reportDetailsBuf.append("REFERENCE NO" + "\t");
				reportDetailsBuf.append("VENDOR CODE" + "\t");
				reportDetailsBuf.append("NAME" + "\t");
				reportDetailsBuf.append("AMOUNT" + "\t");
				reportDetailsBuf.append("STATUS" + "\t");
				reportDetailsBuf.append("CREATION DATE" + "\t");
				reportDetailsBuf.append("TRANSACTION DATE" + "\t");
				reportDetailsBuf.append("REVERSAL DATE" + "\t");
				reportDetailsBuf.append("INTEREST REF NO" + "\t");
				reportDetailsBuf.append("REVERSAL REF NO" + "\t");
				reportDetailsBuf.append("INVOICE NO" + "\t");
				reportDetailsBuf.append("INVOICE DATE" + "\t");
				reportDetailsBuf.append("FILE NO" + "\t");
				reportDetailsBuf.append("CREDIT ACCOUNT NO" + "\t");
				reportDetailsBuf.append("DEBIT ACCOUNT NO" + "\t");
				reportDetailsBuf.append("" + "\n");

				for (VendorReportDetails reportDetailsMap : reportListMap) {

					
					reportDetailsBuf.append((String) reportDetailsMap.getReference_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getVendor_code() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getName()+ "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getAmount() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getStatus() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCreation_time() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getTransaction_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInterest_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getReversal_ref_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInvoice_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getInvoice_date() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getFile_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getCredit_account_no() + "\t");
					reportDetailsBuf.append((String) reportDetailsMap.getDebit_account_no() + "\t");
					reportDetailsBuf.append("" + "\n");

				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(
						new FileWriter(new File(fileName))));
				pw.write(reportDetailsBuf.toString());
				pw.close();
			}

		} catch (Exception e) {
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("csvConverter"+SCFUConstants.METHOD_ENDS);
	}

	public void asciiConverter(Map inParams, String fileName) {
		logger.info("asciiConverter"+SCFUConstants.METHOD_BEGINS);
		fileName = fileSaveUrl + fileName + SCFUConstants.DOT+SCFUConstants.TXT_EXTENSION;
		logger.info("fileName" + fileName);
		List<VendorReportDetails> reportListMap = (List) inParams.get("vendorDetailsList");
		try {
			if (reportListMap != null && reportListMap.size() > 0) {
				StringBuffer outBuffer = new StringBuffer();
				// outBuffer.append("IM Details"+"\n");
				StringBuffer reportDetailsBuf = new StringBuffer(1015);
				String emptyString = " ";
				String title = "";
				for (int i = 0; i < 1000; i++) {
					emptyString = emptyString + " ";
				}
				reportDetailsBuf.replace(0, 1000, emptyString);

				
				title = "REFERENCE NO.";
				reportDetailsBuf.replace(0, title.length(), title);

				title = "VENDOR CODE";
				reportDetailsBuf.replace(20, 20 + title.length(), title);

				title = "NAME";
				reportDetailsBuf.replace(40, 40 + title.length(), title);
				
				title = "AMOUNT";
				reportDetailsBuf.replace(75, 75 + title.length(), title);

				title = "STATUS";
				reportDetailsBuf.replace(105, 105 + title.length(), title);

				title = "CREATION DATE";
				reportDetailsBuf.replace(125, 125 + title.length(), title);
				
				title = "TRANSACTION DATE";
				reportDetailsBuf.replace(145, 145 + title.length(), title);

				title = "REVERSAL DATE";
				reportDetailsBuf.replace(165, 165 + title.length(), title);

				title = "INTEREST REF NO";
				reportDetailsBuf.replace(185, 185 + title.length(), title);

				title = "REVERSAL REF NO";
				reportDetailsBuf.replace(215, 215 + title.length(), title);

				title = "INVOICE NO";
				reportDetailsBuf.replace(235, 235 + title.length(), title);
				
				title = "INVOICE DATE";
				reportDetailsBuf.replace(255, 255 + title.length(), title);
				
				title = "FILE NO";
				reportDetailsBuf.replace(275, 275 + title.length(), title);
				
				title = "CREDIT ACCOUNT NO";
				reportDetailsBuf.replace(295, 295 + title.length(), title);
				
				title = "DEBIT ACCOUNT NO";
				reportDetailsBuf.replace(315, 315 + title.length(), title);
				
				outBuffer.append(reportDetailsBuf + "\r\n");

				for (VendorReportDetails reportDetailsMap : reportListMap) {
					// logger.info("reportDetails: " + reportDetailsMap);
					reportDetailsBuf.replace(0, 1000, emptyString);

					
					title = (String) reportDetailsMap.getReference_no();
					reportDetailsBuf.replace(0, title.length(), title);

					title = (String) reportDetailsMap.getVendor_code();
					reportDetailsBuf.replace(20, 20 + title.length(), title);

					title = (String) reportDetailsMap.getName();
					reportDetailsBuf.replace(40, 40 + title.length(), title);
					
					title = (String) reportDetailsMap.getAmount();
					reportDetailsBuf.replace(75, 75 + title.length(), title);

					title = (String) reportDetailsMap.getStatus();
					reportDetailsBuf.replace(105, 105 + title.length(), title);

					title = (String) reportDetailsMap.getCreation_time();
					reportDetailsBuf.replace(125, 125 + title.length(), title);
					
					title = (String) reportDetailsMap.getTransaction_date();
					reportDetailsBuf.replace(145, 145 + title.length(), title);

					title = (String) reportDetailsMap.getReversal_date();
					reportDetailsBuf.replace(165, 165 + title.length(), title);

					title = (String) reportDetailsMap.getInterest_ref_no();
					reportDetailsBuf.replace(185, 185 + title.length(), title);

					title = (String) reportDetailsMap.getReversal_ref_no();
					reportDetailsBuf.replace(215, 215 + title.length(), title);
					
					title = (String) reportDetailsMap.getInvoice_no();
					reportDetailsBuf.replace(235, 235 + title.length(), title);
					
					title = (String) reportDetailsMap.getInvoice_date();
					reportDetailsBuf.replace(255, 255 + title.length(), title);
					
					title = (String) reportDetailsMap.getFile_no();
					reportDetailsBuf.replace(275, 275 + title.length(), title);
					
					title = (String) reportDetailsMap.getCredit_account_no();
					reportDetailsBuf.replace(295, 295 + title.length(), title);
					
					title = (String) reportDetailsMap.getDebit_account_no();
					reportDetailsBuf.replace(315, 315 + title.length(), title);
					
					outBuffer.append(reportDetailsBuf + "\r\n");
				}
				PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(new File(fileName))));
				pw.write(outBuffer.toString());
				pw.close();
			}

		} catch (Exception e) {

			logger.info("specific exception type: " + e.getClass());
			logger.info(" exception: " + e.getCause());
			logger.info("Exception:" + e.getMessage());
		}
		logger.info("asciiConverter"+SCFUConstants.METHOD_ENDS);

	}

	public void setImagesFolder(String imagesFolder) {
		this.imagesFolder = imagesFolder;
	}

	public void setFileSaveUrl(String fileSaveUrl) {
		this.fileSaveUrl = fileSaveUrl;
	}
}
