
function submitIMReport()
{
	 vendorCode=document.getElementById("vendorCode").value;
	 if(vendorCode=="select"){
		 alert("please select a vendor code");
		 return false;
	 }
	// alert("the vendorCode is:"+vendorCode);
//	 window.open('vendordetailsreport.htm','','width=780, height=500 ,status=1, scrollbars=1, location=0')
	 document.imFileUploadForm.submit();
}



function printReport(){
	document.getElementById("printCloseButton").style.display="block";
		window.print();
	document.getElementById("printCloseButton").style.display="block";	
	}

function closeReport(){
	window.close();
}