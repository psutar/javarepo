function validateDate(startDate,endDate,form){
	if(startDate == ''){
 		alert("Select Start Date");
 		document.getElementById(form.name).startDate.focus();
 		return false;
 	}
 	if(endDate == ''){
 		alert("Select End Date");
 		document.getElementById(form.name).endDate.focus();
 		return false;
 	}
 	
 	var dte=new Date();
 	var tdate=new Date(dte.toString().substring(4,10)+" "+ dte.getFullYear());

 	var strStartDate = startDate.split('-');
 	var strEndDate = endDate.split('-');
 	var months = {
 		    'Jan' : '01',
 		    'Feb' : '02',
 		    'Mar' : '03',
 		    'Apr' : '04',
 		    'May' : '05',
 		    'Jun' : '06',
 		    'Jul' : '07',
 		    'Aug' : '08',
 		    'Sep' : '09',
 		    'Oct' : '10',
 		    'Nov' : '11',
 		    'Dec' : '12'
 	};
 	
 	var sdate=new Date(strStartDate[2],months[strStartDate[1]]-1,strStartDate[0]);
	var edate = new Date(strEndDate[2],months[strEndDate[1]]-1,strEndDate[0]);

	if(sdate > tdate ){
		alert("Start date should be less than or equal to current date");
		document.getElementById(form.name).startDate.value="";
		document.getElementById(form.name).startDate.focus();
		return false;
	}
	if(edate > tdate){
		alert("End date should be less than or equal to current date");
		document.getElementById(form.name).endDate.value="";
		document.getElementById(form.name).endDate.focus();
		return false;
	}
	if(sdate > edate){
		alert("End date should be greater than or equal to Start date");
		document.getElementById(form.name).endDate.value="";
		document.getElementById(form.name).endDate.focus();
		return false;
	}
	return true;
}