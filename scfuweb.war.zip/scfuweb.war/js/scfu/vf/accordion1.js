$(document).ready(function(){
	$(".pane").hide();
	// setTimeout ("$('.accordion div').slideToggle('slow');", 1000);
	$(".accordion h3").click(function(){
	$(this).next(".pane").slideToggle("slow").siblings(".pane:visible").slideUp("slow");
	$(this).toggleClass("current");
	$(this).siblings("h3").removeClass("current");
	});
$('#submit').on('click', function(event) {
   event.preventDefault();
   
	$(".pane").show();
   $(".accordion h3").siblings("h3").addClass("current");
          validate();
   });   

	$('#reset').on('click', function(event) {
	   
	$(".pane").show();
	
   }) ;   
	}); 