function detailsSubmit() { 
	
	    var radios = document.getElementsByName("radio1");
	    var formValid = false;

	    var i = 0;
	    while (!formValid && i < radios.length) {
	        if (radios[i].checked) formValid = true;
	        i++;        
	    }

	    if (!formValid) {
	    	alert("Must check some option!");
	    	return false;
	    }
	
 var name = document.getElementById("name").value;

 var nickname = document.IMDetailsForm.nickname.value;

 var address = document.IMDetailsForm.address.value;

 var address2 = document.IMDetailsForm.address2.value;

 var city = document.IMDetailsForm.city.value;
 
 var district = document.IMDetailsForm.district.value;

 var state = document.IMDetailsForm.state.value;

 var country = document.IMDetailsForm.country.value;

 var pincode = document.IMDetailsForm.pincode.value;

 var email = document.IMDetailsForm.email.value;

 var phone = document.IMDetailsForm.phone.value;

 var mobile = document.IMDetailsForm.mobile.value;

 
	if(name=="" || name==null){
		

		alert("Enter Name");
		document.IMDetailsForm.name.focus();
		return false;
	}
	
	 if (!IMDetailsForm.name.value.match(/^[0-9a-zA-Z ]+$/) && IMDetailsForm.name.value !="")
	    {
		 //alert("name validate");
		 document.IMDetailsForm.name.focus();
		 document.IMDetailsForm.name.value="";
	 	   alert("Please Enter only alphanumeric in name textbox");
	 	  return false;
	    }

	if(nickname ==""){
		alert("Enter Nick Name");
		document.IMDetailsForm.nickname.focus();
		return false;
	}
	

	 if (!IMDetailsForm.nickname.value.match(/^[0-9a-zA-Z ]+$/) && IMDetailsForm.nickname.value !="")
	    {
		// alert("nickname validate");
		 document.IMDetailsForm.nickname.focus();
		 document.IMDetailsForm.nickname.value="";
	 	   alert("Please Enter only alphanumeric in nickname textbox");
	 	  return false;
	    }

 if(address=="")
	{
		alert("Enter Address");
		document.IMDetailsForm.address.focus();
		return false;
	} 
 

 if (!IMDetailsForm.address.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && IMDetailsForm.address.value !="")
    {
	 document.IMDetailsForm.address.focus();
	 document.IMDetailsForm.address.value="";
 	   alert("Please do not enter any special characters other than , or - in address");
 	  return false;
    }
 
     
     
 if (!IMDetailsForm.address2.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && IMDetailsForm.address2.value !="")
        {
    	 document.IMDetailsForm.address2.focus();
    	 document.IMDetailsForm.address2.value="";
     	   alert("Please do not enter any special characters other than , or - in address");
     	  return false;
        }
     if(city=="")
	{
		alert("Enter City");
		document.IMDetailsForm.city.focus();
		return false;
	}

     if (!IMDetailsForm.city.value.match(/^[a-zA-Z ]+$/) && IMDetailsForm.city.value !="")
     {
 	 document.IMDetailsForm.city.focus();
 	 document.IMDetailsForm.city.value="";
  	   alert("Please do not enter any special characters in city");
  	  return false;
     }
     
     if(district=="")
	   {
		alert("Enter District");
		document.IMDetailsForm.district.focus();
		return false;
	   }
if (!IMDetailsForm.district.value.match(/^[a-zA-Z ]+$/) && IMDetailsForm.district.value !="")
     {
 	 document.IMDetailsForm.district.focus();
 	 document.IMDetailsForm.district.value="";
  	   alert("Please do not enter any special characters in district");
  	  return false;
     }
   if(state=="")
	 {
		alert("Enter State");
		document.IMDetailsForm.state.focus();
		return false;
	 }
if (!IMDetailsForm.state.value.match(/^[a-zA-Z ]+$/) && IMDetailsForm.state.value !="")
   {
	 document.IMDetailsForm.state.focus();
	 document.IMDetailsForm.state.value="";
	   alert("Please do not enter any special characters in state");
	  return false;
   }
 if(country=="")
     {
	    alert("Enter Country");
	    document.IMDetailsForm.country.focus();
	    return false;
}
if (!IMDetailsForm.country.value.match(/^[a-zA-Z ]+$/) && IMDetailsForm.country.value !="")
 {
	 document.IMDetailsForm.country.focus();
	 document.IMDetailsForm.country.value="";
	   alert("Please do not enter any special characters in country");
	  return false;
 }

 if(pincode=="")
	{
		alert("Enter Pincode");
		document.IMDetailsForm.pincode.focus();
		return false;
	}
 
 if(isNaN(document.IMDetailsForm.pincode.value))
 {
  alert("Enter Numeric value for pincode");
  document.IMDetailsForm.pincode.focus();
  document.IMDetailsForm.pincode.value="";
  return false;
 }

if(((document.IMDetailsForm.pincode.value).length)!=6)
{
 alert("Pincode length should be 6");
 document.IMDetailsForm.pincode.focus();
 return false;
}
 if(email=="")
   {
	 alert("Enter Email Id");
	 document.IMDetailsForm.email.focus();
	 return false;
	}
 
if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(IMDetailsForm.email.value)))   
	  {   
	    alert("You have entered an invalid email address!");  
	    document.IMDetailsForm.email.focus();
	    document.IMDetailsForm.email.value="";
	     return (false);  
	  }
     if(phone=="")
	    {
		alert("Enter Phone_No");
		document.IMDetailsForm.phone.focus();
		return false;
	}
     if(isNaN(document.IMDetailsForm.phone.value))
	   {
		alert("Enter only numeric value in Phone Number");
		document.IMDetailsForm.phone.focus();
		document.IMDetailsForm.phone.value="";
		return false;
	}
  if(((document.IMDetailsForm.phone.value).length)!=10)
	{
	 alert("Phone length should be 10");
	 document.IMDetailsForm.phone.focus();
	 return false;
	}
   

 if(mobile=="")
	{
		alert("Enter mobile_No");
		document.IMDetailsForm.mobile.focus();
		return false;
	}
 if(isNaN(document.IMDetailsForm.mobile.value))
 {
	alert("Enter only numeric value in Mobile Number");
	document.IMDetailsForm.mobile.focus();
	document.IMDetailsForm.mobile.value="";
	return false;
}
 
 if(((document.IMDetailsForm.mobile.value).length)!=10)
 {
     alert("Mobile Number length should be 10");
	 document.IMDetailsForm.mobile.focus();
	 return false;

 }

   
if  (mobile.charAt(0)=="0")
    {
         alert("Mobile No should not start with 0 ");
         document.IMDetailsForm.mobile.focus();
         return false;
    }
			document.IMDetailsForm.action="addvfimuserconfirm.htm";
	        return true;
}

function TrimString(element)
{
	if(element)
  
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}



function isAlphaNumericKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 || charCode==8 )
			        return true;
			    else
			    return false;	 
    }


function isAlphaAddress(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32
					 || charCode ==44 || charCode==45 ||charCode==47 || charCode==8)
			        return true;
			    else
			    return false;	 
    }

function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 || charCode==8)
        return true;
    else
    return false;
}
   


function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58) || charCode==8 )
        return true;
    return false;
}

function isEmailFormatKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) ||  charCode ==64 || charCode ==46
					 || charCode ==95 || charCode==8)
			        return true;
			    else
			    return false;	 
    }







