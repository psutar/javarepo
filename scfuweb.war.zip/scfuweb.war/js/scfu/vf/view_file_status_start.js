document.write("<div class='banner_inside'><img src='/scfuweb/images/bulk_upload.jpg' alt='Bluk Upload' width='645' height='74'/></div><div class='inner_rp'><ul  class='con_head'><li class='subTab'><a id='file_upload' class='unselected' href='file_upload.html' title='File Upload'>File Upload</a></li><li class='lastTab'><a id='view_file' class='selected' href='viewfile_uploadstatus.html' title='View File Status'>View File Status</a></li></ul><br />");
			
				
			
			
				
				
			
		
				
			
		
		
	