
function fnDisplayFileList(fileNo,creationTime)
{
	document.authorisefiledisplayform.fileNo.value = fileNo;
	document.authorisefiledisplayform.creationTime.value = creationTime;
	document.authorisefiledisplayform.action = "viewauthorisefiledetails.htm";
	document.authorisefiledisplayform.submit();
	
}
function fnAuthoriseTxnFileDetails()
{
	
	var flag=false;
	var txnEcheque = document.authorisefiledetailsform.txnEcheque;
	var chkCount = document.authorisefiledetailsform.chkCount.value;
	
	if(chkCount == 1){
		document.getElementById('echequeNo').value=document.getElementById('echeque').value;
		
		flag = true;
	}else{
		for(i=0;i<txnEcheque.length;i++){
			if(txnEcheque[i].checked==true){
				flag = true;
				break;
			}
		}
	}
	if (!flag){
		alert("Please check atleast one echeque");
			return false;
	}
	document.authorisefiledetailsform.action='txnauthoriseconfirm.htm';
	document.authorisefiledetailsform.submit();

}


function fnRejectTxnFileDetails()
{
	var flag=false;
	var txnEcheque = document.authorisefiledetailsform.txnEcheque;
	var chkCount = document.authorisefiledetailsform.chkCount.value;
	if(chkCount == 1){
		document.getElementById('echequeNo').value=document.getElementById('echeque').value;
		//alert(document.getElementById('echequeNo').value);
		flag = true;
	}else{
		for(i=0;i<txnEcheque.length;i++){
			if(txnEcheque[i].checked==true){
				flag = true;
				break;
			}
		}
	}
	if (!flag){
		alert("Please check atleast one echeque");
			return false;
	}
	/*document.authorisefiledetailsform.action='txnrejectconfirm.htm';
	document.authorisefiledetailsform.submit();*/
	
/*Alert box code*/	
	/*var rejectReason=prompt("Please enter The Reason For Rejection");
	if (rejectReason!=null)
 	  {
		alert("rejectReason :" + rejectReason);
		document.getElementById("rejectReason").value = rejectReason;
	}
	else{
		return false;
	}*/

	/*end of alert box*/
	
	/*var rejectReason=document.getElementById("rejectReason").value;
	if(rejectReason != null){
		document.getElementById("rejectReason").disabled='false';
		var v1=document.getElementById("rejectReason");
		//v1.setAttribute("readOnly","false");
		alert("no reject reason");
		return false;
	}*/
	
	 /*Alert box code starts here*/      
    //alert("sjlj");
    
     $(".grey-background").show();
      document.getElementById("alertbox").style.display="block";
      document.getElementById("alertmsg").style.width="200px";        
    
      $(document).ready(function() {
    	  jQuery(".content").prepend('<div class="modalOverlay"></div>'); 
    	  
    	  // $('body').prepend('<div id="fade"></div>');
          // $('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn();
    	  
    	  
          $( "#alertbox" ).draggable({	
              drag: function(event, ui) {
                $("#alertbox").css("opacity", "0.6"); // Semi-transparent when dragging
              },
              stop: function(event, ui) {
                $("#alertbox").css("opacity", "1.0"); // Full opacity when stopped
              }
            });
          //$( "#alertbox" ).draggable({ containment: "window" });/*Possible value for containment: "parent", "document", "window" */
          
         // $('body').prepend('<div id="fade"></div>');
         // $('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeIn();
         
          
        /*  var popuptopmargin = ($("#alertbox").height() + 10) / 2;
          var popupleftmargin = ($("#alertbox").width() + 10) / 2;
          $("#alertbox").css({
        	  'margin-top' : -popuptopmargin,
        	  'margin-left' : -popupleftmargin
        	  });*/
          });
    return false;
}

function hide()
{

$(".grey-background").hide();
document.getElementById("alertbox").style.display="none";       
$(document).ready(function() {
	

	  jQuery(".wrapperss").css("display","none");
	  jQuery('.modalOverlay').hide();
    });
}

function submitRejectReason()
{
	//alert("pls ente values");
	var test = document.getElementById('rejectReason1').value;
	//alert('test'+test);
	if(test != '' && test!=null){
		//alert("pls ELSE +++++++++++");
		document.authorisefiledetailsform.action='txnrejectconfirm.htm';
		document.authorisefiledetailsform.submit();	
	}else{
		alert("Please enter Reason for Rejection");
		return false;
	}
	
	$(".grey-background").hide();
	document.getElementById("alertbox").style.display="none";  
	return true;
}

/*Alert box code ends here*/

function fnBackTxnFileList()
{
	document.authorisefiledetailsform.action = "authorisefiledisplay.htm";
	document.authorisefiledetailsform.submit();
	
}
