function generatereversefile(form)
{
	var fromDate = form.startDate.value;
	var toDate = form.endDate.value;
	
	if(!validateDate(fromDate,toDate,form))
	{
		return false;
	}
	else{		
		form.action = "imgeneratereversefiledisplay.htm";
		form.submit();
	}
}

function submitgenerateReversefile(fileName,fileStatus,creation_date,imcode,fileNo)
{
	 document.getElementById("fileName").value = fileName;
	 document.getElementById("fileStatus").value = fileStatus;
	 document.getElementById("creationDate").value = creation_date;
	 document.getElementById("imCode").value = imcode;
	 document.getElementById("fileNo").value = fileNo;
	 document.genReverseFileDisplay.submit();
}

function backToGenerateReverseFile()
{
	document.genReverseFileDisplay.action="imgenreversefile.htm";
	document.genReverseFileDisplay.submit();
}