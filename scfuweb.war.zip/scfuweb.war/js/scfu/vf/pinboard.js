function pinboard()
{
    //alert("sjlj");
    
     $(".grey-background-home").show();
     document.getElementById("popupbox").style.display="block";
    
      $(document).ready(function() {
    	  
    	  
        
          $( "#popupbox" ).draggable({ containment: "document", scroll: false});//Possible value for containment: "parent", "document", "window" 
          
         
         
          
          });
    return false;
}

function hide()
{

$(".grey-background-home").hide();
document.getElementById("popupbox").style.display="none";       
$(document).ready(function() {
	
    $('body').append('<div id="fade"></div>');
    $('#fade').css({'filter' : 'alpha(opacity=80)'}).fadeOut();
    });
}