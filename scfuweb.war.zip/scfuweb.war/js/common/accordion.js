$(document).ready(function(){
		//  Accordion Panels
		 $(".accordion h3:first").addClass("current");
		$(".accordion div").hide();
		// setTimeout ("$('.accordion div').slideToggle('slow');", 1000);
		$(".accordion h3").click(function(){
		$(this).next(".pane").slideToggle("slow").siblings(".pane:visible").slideUp("slow");
		$(this).toggleClass("current");
		$(this).siblings("h3").removeClass("current");
		});
		
	$('#submit').on('click', function(event) {
	   event.preventDefault();
	   
		$(".accordion div").show();
	   $(".accordion h3").siblings("h3").addClass("current");
              validate();
       });   
	
		$('#reset').on('click', function(event) {
		   
		$(".accordion div").show();
		
       }) ;  
		
		$('.active').on('click', function(event) {
			//$(this).href("javascript:void(0)");
		//	event.preventDefault();
			//$(".active div").show();
			   //$(".accordion .active").parent(".active").addClass("current");
			
		
		
	       }) ; 
		$('.lp_menu li .active').parent().parent().parent().css('display', 'block'); 
	
});	 