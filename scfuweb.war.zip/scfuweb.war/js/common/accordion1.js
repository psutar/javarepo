$(document).ready(function(){
		//  Accordion Panels
		$(".accordion1 .pane1").hide();
		$(".accordion1 div").hide();
		// setTimeout ("$('.accordion div').slideToggle('slow');", 1000);
		$(".accordion1 h3").click(function(){
		$(this).next(".accordion1 div").slideToggle("slow").siblings(".accordion1 div:visible").slideUp("slow");
		$(this).toggleClass("current1");
		$(this).siblings("h3").removeClass("current1");
		$(".accordion1 div").css('display', 'block'); 
		
		});
	
	
});	 