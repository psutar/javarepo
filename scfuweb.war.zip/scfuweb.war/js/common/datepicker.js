$(document).ready(function(){
$( "#startDate" ).datepicker({
showOn: "button",
changeMonth: true,
changeYear: true,
buttonImage: "/scfuweb/images/icon_cal.png",
monthNamesShort: [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
buttonImageOnly: true
});
$( "#endDate" ).datepicker({
showOn: "button",
changeMonth: true,
changeYear: true,
buttonImage: "/scfuweb/images/icon_cal.png",
buttonImageOnly: true
});
});