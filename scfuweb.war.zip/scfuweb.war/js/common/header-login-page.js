document.write("<div id='header'><div class='logo_search'><div class='logo'><a href='#' title='Logo'><img src='/scfuweb/images/logo.png' /></a></div></div></div>");
			
				
			
			
				
				
			
		
				
			
		
		
	