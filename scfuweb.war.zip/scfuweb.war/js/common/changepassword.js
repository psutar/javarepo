function profileSubmit(){
		var userName = document.changepasswordform.userName.value;
		var oldpassword = document.changepasswordform.oldpassword.value;
		var newpassword=  document.changepasswordform.newpassword.value;
		var retypepassword=document.changepasswordform.retypedpassword.value;
		var alpha =/[a-zA-Z]/; 
	    var num =/[0-9]/; 
	    var splchar=/[!@#$%^&*]/;
	    
		if (oldpassword =="")
		{
			alert("Enter oldpassword");
			document.changepasswordform.oldpassword.focus();
			return false;
		}
		else if(newpassword=="")
		{
			alert("Enter newpassword");
			document.changepasswordform.newpassword.focus();
			return false;
		}  
		else if (newpassword.length < 8 || newpassword.length < 8 || newpassword.length > 20 || newpassword.length > 20){ 
			  alert("User Password should have miniumum 8 chars & maximum 20 chars"); 
			  document.changepasswordform.newpassword.focus();
				return false;
		} 
		else if(oldpassword == newpassword)
		{
			alert("Old password should not be same as New password");
			document.changepasswordform.newpassword.value="";
			document.changepasswordform.newpassword.focus();
			return false;
		} 
		else if(retypepassword=="")
		{
			alert("Enter retypepassword");
			document.changepasswordform.retypedpassword.focus();
			return false;
		} 
		else if(newpassword != retypepassword)
		{
			alert("Retype password is not same as password");
			document.changepasswordform.retypedpassword.value="";
			document.changepasswordform.retypedpassword.focus();
			return false;
		} 
		
		else if ( !(alpha.test(changepasswordform.newpassword.value) && ( num.test(changepasswordform.newpassword.value) ) && ( splchar.test(changepasswordform.newpassword.value) ) )) 

	       {
	          alert('Password should have atleast one alphabet,number and spl character.');
	          document.changepasswordform.newpassword.focus();
	          document.changepasswordform.newpassword.value="";
	          document.changepasswordform.retypedpassword.value="";
	          return false;
	       } 
		else if (newpassword == retypepassword){
			
				var encSHA512SaltPass = encryptSha2('changepasswordform',userName,newpassword);
				var encSHA512OldPass = encryptSha2('changepasswordform',userName,oldpassword);
				
				document.changepasswordform.sha2password.value=encSHA512SaltPass;
				document.changepasswordform.sha2oldpassword.value=encSHA512OldPass;
			
		 		document.changepasswordform.oldpassword.value=encSHA512OldPass;
				document.changepasswordform.newpassword.value=encSHA512SaltPass; 
			 	document.changepasswordform.retypedpassword.value=encSHA512SaltPass;
				
				document.changepasswordform.action="changepasswordsubmit.htm";
				document.changepasswordform.submit();
				return true;
		}
		
		return true;
}

function encryptSha2(formname,value1,value2){
	try{
		var shaHash =value1+"#"+value2;
		var encString = CryptoJS.SHA512(shaHash); 
		
		}catch(error){
			
		}
		return encString;	
}

function clearError()
{
	if(document.getElementById("error_msg_div")!=null)
		{
			document.getElementById("error_msg_div").style.display="none";
		}
	}


