var fileName = location.pathname.substring(location.pathname.lastIndexOf('/')+1);
if(fileName=="file_upload.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="viewfile_uploadstatus.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="file_upload_link.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="file_upload_conf.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="file_upload_error.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="authorise_file_transactions.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="authorise_file_transactions_link.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="authorise_conf.html"){document.getElementById("transactions").className="activelistItem";}
if(fileName=="principal_report.html"){document.getElementById("Reports").className="activelistItem";}
if(fileName=="interest_report.html"){document.getElementById("Reports").className="activelistItem";}
if(fileName=="repayment_report.html"){document.getElementById("Reports").className="activelistItem";}
if(fileName=="principal_report_vendor.html"){document.getElementById("Reports").className="activelistItem";}
if(fileName=="interest_report_vendor.html"){document.getElementById("Reports").className="activelistItem";}
if(fileName=="manageim_add.html"){document.getElementById("registration").className="activelistItem";}
if(fileName=="manageim_delete.html"){document.getElementById("registration").className="activelistItem";}
if(fileName=="manageim_edit.html"){document.getElementById("registration").className="activelistItem";}
if(fileName=="manageim_addconf.html"){document.getElementById("registration").className="activelistItem";}
if(fileName=="manageim_deleteconf.html"){document.getElementById("registration").className="activelistItem";}
if(fileName=="manageim_editconf.html"){document.getElementById("registration").className="activelistItem";}
/*login page menu items*/


