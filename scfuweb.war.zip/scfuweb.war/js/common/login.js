function loginSubmit() { 
 
  var username = document.loginForm.userName.value;
  var password=  document.loginForm.password.value;
  var keyString=  document.loginForm.keyString.value;
  


	if(username==""){
		alert("Enter Login ID");
		document.loginForm.userName.focus();
		return false;
	}
	else if(password=="")
	{
		alert("Enter Password");
		document.loginForm.password.focus();
		return false;
	}else if(password.length < 8 || username.length < 8 || password.length  > 50 || username.length > 50){ 
	     alert("User Name & Password should have miniumum 8 chars & maximum 50 chars"); 
         document.loginForm.password.focus();
		return false;
   } else{
	//	alert("username:"+username+" password:"+password+" keyString:"+keyString);
				
			var encSHA512SaltPass = encryptSha2('loginForm',username,password);
		    var encSHA512 = encryptSha2('loginForm',encSHA512SaltPass,keyString);
	
			document.loginForm.sha2password.value=encSHA512;
			document.loginForm.password.value=encSHA512;
			
			document.loginForm.action="loginsubmit.htm";
			
			return true;
	
	}
	
	
}
function nospaces(t){
	if(t.value.match(/\s/g)){
	alert('Sorry, you are not allowed to enter any spaces');
	t.value=t.value.replace(/\s/g,'');
	}
}

function encryptSha2(formname,value1,value2){
	try{
		var shaHash =value1+"#"+value2;
		var encString = CryptoJS.SHA512(shaHash); 
		
		}catch(error){
			
		}
		return encString;	
}
function clearError()
{
	if(document.getElementById("error_msg_div")!=null)
		{
			document.getElementById("error_msg_div").style.display="none";
		}
	}
