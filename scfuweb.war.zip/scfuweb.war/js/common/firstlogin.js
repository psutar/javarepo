function firstLoginSubmit() { 
	 
	  var username = document.firstloginform.desired_username.value;
	  var password=  document.firstloginform.password.value;
	  var retypepassword=  document.firstloginform.retypepassword.value;
	  var validUserName=  document.firstloginform.validUserName.value;
	  var alpha =/[a-zA-Z]/; 
	  var num =/[0-9]/; 
	  var splchar=/[!@#$%^&*]/;
	   
		if(username==""){
			alert("Enter desired username");
			document.firstloginform.desired_username.focus();
			return false;
		}
		else if(password=="")
		{
			alert("Enter password");
			document.firstloginform.password.focus();
			return false;
		}  
		else if(retypepassword=="")
		{
			alert("Enter retype password");
			document.firstloginform.retypepassword.focus();
			return false;
		} 
		else if(retypepassword != password)
		{
			alert("Retype password is not same as New password");
			document.firstloginform.retypepassword.focus();
			return false;
		} 
		else if(validUserName == "false")
		{
			alert("Please Enter a Valid Username");
			document.firstloginform.desired_username.value="";
			document.firstloginform.desired_username.focus();
			return false;
		} 
		else if( username.length < 8  ||  username.length > 50){ 
		     alert("Login Id should have miniumum 8 chars "); 
		     document.firstloginform.password.focus();
			return false;
	   }
		
		else if(password.length < 8 || password.length > 50){ 
		     alert("Password should have miniumum 8 chars "); 
		     document.firstloginform.password.focus();
			return false;
	   }
		
		else if ( !(alpha.test(firstloginform.password.value) && ( num.test(firstloginform.password.value) ) && ( splchar.test(firstloginform.password.value) ) )) 
        {
       alert('Password should have atleast one alphabet,number and spl character.');
       document.firstloginform.password.focus();
       document.firstloginform.password.value="";
       document.firstloginform.retypepassword.value="";
       
       return false;
        } 
		else{
			//alert("username:"+username+" password:"+password+" retypepassword:"+retypepassword+"  validUserName:"+validUserName);
			alert( checkUsername());	
				var encSHA512SaltPass = encryptSha2('firstloginform',username,password);
		
				document.firstloginform.sha2password.value=encSHA512SaltPass;
			
				
				document.firstloginform.action="firstloginsubmit.htm";
				
				return true;
		}
	}



function encryptSha2(formname,value1,value2){
	try{
		var shaHash =value1+"#"+value2;
		var encString = CryptoJS.SHA512(shaHash); 
		
		}catch(error){
			
		}
		return encString;	
}
function clearError()
{
	if(document.getElementById("errorValidate")!=null && document.getElementById("validUserName")!=null && document.getElementById("validUserName").value=="false")
		{
			document.getElementById("errorValidate").style.visibility='hidden';
		}
	}

