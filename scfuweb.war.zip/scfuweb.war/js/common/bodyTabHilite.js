var regExp = /<\/?[^>]+>/gi;
function ReplaceTags(xStr){
	xStr = xStr.replace(regExp,"");
	return xStr;
}

function disableMenu(linkID){

	
	
	var isValid = true;
	
	var linkObj = new Object(document.getElementById(linkID));
	
	
	var tempStr = linkObj.innerHTML;
	
	
	if(tempStr == undefined || tempStr == null){
		isValid = false;
	}
	if(isValid){
		var strLinkText = ReplaceTags(tempStr);
		var linkObj = new Object(document.getElementById(linkID))
			linkObj.className='selected';
	
	
		linkObj.innerHTML = strLinkText ;
	
		
	}
   else{
		alert("Error: Specified link number ' " + linkID + " ' not found.\r\n\r\nPlease check the ' LeftNav_HiliteLink ' template property value using\r\nModify > Template Properties in Dreamweaver.")
	}
}