function validIntDetails(){
	
var intName = document.AddIntDetailsForm.intName.value;

var intRate = document.AddIntDetailsForm.intRate.value;
 
 if(intName=="" || intName==null){
		alert("Enter Interest Name");
		document.AddIntDetailsForm.intName.focus();
		return false;
	}
 if (!AddIntDetailsForm.intName.value.match(/^[a-zA-Z]+$/) && AddIntDetailsForm.intName.value !="")
 {
	 document.AddIntDetailsForm.intName.focus();
	 document.AddIntDetailsForm.intName.value="";
	   alert("Please Enter only alphabets in interest name");
	  return false;
 }
 if(intRate=="" || intRate==null){
		alert("Enter Interest Rate");
		document.AddIntDetailsForm.intRate.focus();
		return false;
	}
 if (!AddIntDetailsForm.intRate.value.match(/^[.0-9]+$/) && AddIntDetailsForm.intRate.value !="")
 {
	 document.AddIntDetailsForm.intRate.focus();
	 document.AddIntDetailsForm.intRate.value="";
	   alert("Please Enter only numbers and . in interest rate");
	  return false;
 }
 document.AddIntDetailsForm.action="addintratepreconfirm.htm";
	return true;
}

function TrimString(element)
{
	if(element)
  
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}

function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58)||(charCode==46))
        return true;
    return false;
}
function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
        return true;
    else
    return false;
}



