function detailsSubmit() { 
	
	    var radios = document.getElementsByName("radio1");
	    var formValid = false;

	    var i = 0;
	    while (!formValid && i < radios.length) {
	        if (radios[i].checked) formValid = true;
	        i++;        
	    }

	    if (!formValid) {
	    	alert("Must check some option!");
	    	return false;
	    }
	
 var name = document.getElementById("name").value;

 var nickName = document.SCFUUserDetailsForm.nickName.value;

 var address = document.SCFUUserDetailsForm.address.value;

 var address2 = document.SCFUUserDetailsForm.address2.value;

 var city = document.SCFUUserDetailsForm.city.value;
 
 var district = document.SCFUUserDetailsForm.district.value;

 var state = document.SCFUUserDetailsForm.state.value;

 var country = document.SCFUUserDetailsForm.country.value;

 var pinCode = document.SCFUUserDetailsForm.pinCode.value;

 var email = document.SCFUUserDetailsForm.email.value;

 var phone = document.SCFUUserDetailsForm.phone.value;

 var mobile = document.SCFUUserDetailsForm.mobile.value;

 
	if(name=="" || name==null){
		

		alert("Enter Name");
		document.SCFUUserDetailsForm.name.focus();
		return false;
	}
	
	 if (!SCFUUserDetailsForm.name.value.match(/^[0-9a-zA-Z ]+$/) && SCFUUserDetailsForm.name.value !="")
	    {
		 //alert("name validate");
		 document.SCFUUserDetailsForm.name.focus();
		 document.SCFUUserDetailsForm.name.value="";
	 	   alert("Please Enter only alphanumeric in name textbox");
	 	  return false;
	    }

	if(nickName ==""){
		alert("Enter Nick Name");
		document.SCFUUserDetailsForm.nickName.focus();
		return false;
	}
	

	 if (!SCFUUserDetailsForm.nickName.value.match(/^[0-9a-zA-Z ]+$/) && SCFUUserDetailsForm.nickName.value !="")
	    {
		 document.SCFUUserDetailsForm.nickName.focus();
		 document.SCFUUserDetailsForm.nickName.value="";
	 	   alert("Please Enter only alphanumeric in nickname textbox");
	 	  return false;
	    }

 if(address=="")
	{
		alert("Enter Address");
		document.SCFUUserDetailsForm.address.focus();
		return false;
	} 
 

 if (!SCFUUserDetailsForm.address.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && SCFUUserDetailsForm.address.value !="")
    {
	 document.SCFUUserDetailsForm.address.focus();
	 document.SCFUUserDetailsForm.address.value="";
 	   alert("Please do not enter any special characters other than , or - in address");
 	  return false;
    }
 
     
     
 if (!SCFUUserDetailsForm.address2.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && SCFUUserDetailsForm.address2.value !="")
        {
    	 document.SCFUUserDetailsForm.address2.focus();
    	 document.SCFUUserDetailsForm.address2.value="";
     	   alert("Please do not enter any special characters other than , or - in address");
     	  return false;
        }
     if(city=="")
	{
		alert("Enter City");
		document.SCFUUserDetailsForm.city.focus();
		return false;
	}

     if (!SCFUUserDetailsForm.city.value.match(/^[a-zA-Z ]+$/) && SCFUUserDetailsForm.city.value !="")
     {
 	 document.SCFUUserDetailsForm.city.focus();
 	 document.SCFUUserDetailsForm.city.value="";
  	   alert("Please do not enter any special characters in city");
  	  return false;
     }
     
     if(district=="")
	   {
		alert("Enter District");
		document.SCFUUserDetailsForm.district.focus();
		return false;
	   }
if (!SCFUUserDetailsForm.district.value.match(/^[a-zA-Z ]+$/) && SCFUUserDetailsForm.district.value !="")
     {
 	 document.SCFUUserDetailsForm.district.focus();
 	 document.SCFUUserDetailsForm.district.value="";
  	   alert("Please do not enter any special characters in district");
  	  return false;
     }
   if(state=="")
	 {
		alert("Enter State");
		document.SCFUUserDetailsForm.state.focus();
		return false;
	 }
if (!SCFUUserDetailsForm.state.value.match(/^[a-zA-Z ]+$/) && SCFUUserDetailsForm.state.value !="")
   {
	 document.SCFUUserDetailsForm.state.focus();
	 document.SCFUUserDetailsForm.state.value="";
	   alert("Please do not enter any special characters in state");
	  return false;
   }
 if(country=="")
     {
	    alert("Enter Country");
	    document.SCFUUserDetailsForm.country.focus();
	    return false;
}
if (!SCFUUserDetailsForm.country.value.match(/^[a-zA-Z ]+$/) && SCFUUserDetailsForm.country.value !="")
 {
	 document.SCFUUserDetailsForm.country.focus();
	 document.SCFUUserDetailsForm.country.value="";
	   alert("Please do not enter any special characters in country");
	  return false;
 }

 if(pinCode=="")
	{
		alert("Enter Pincode");
		document.SCFUUserDetailsForm.pinCode.focus();
		return false;
	}
 
 if(isNaN(document.SCFUUserDetailsForm.pinCode.value))
 {
  alert("Enter Numeric value for pincode");
  document.SCFUUserDetailsForm.pinCode.focus();
  document.SCFUUserDetailsForm.pinCode.value="";
  return false;
 }

if(((document.SCFUUserDetailsForm.pinCode.value).length)!=6)
{
 alert("Pincode length should be 6");
 document.SCFUUserDetailsForm.pinCode.focus();
 return false;
}
 if(email=="")
   {
	 alert("Enter Email Id");
	 document.SCFUUserDetailsForm.email.focus();
	 return false;
	}
 
if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(SCFUUserDetailsForm.email.value)))   
	  {   
	    alert("You have entered an invalid email address!");  
	    document.SCFUUserDetailsForm.email.focus();
	    document.SCFUUserDetailsForm.email.value="";
	     return (false);  
	  }
     if(phone=="")
	    {
		alert("Enter Phone_No");
		document.SCFUUserDetailsForm.phone.focus();
		return false;
	}
     if(isNaN(document.SCFUUserDetailsForm.phone.value))
	   {
		alert("Enter only numeric value in Phone Number");
		document.SCFUUserDetailsForm.phone.focus();
		document.SCFUUserDetailsForm.phone.value="";
		return false;
	}
  if(((document.SCFUUserDetailsForm.phone.value).length)!=10)
	{
	 alert("Phone length should be 10");
	 document.SCFUUserDetailsForm.phone.focus();
	 return false;
	}
   

 if(mobile=="")
	{
		alert("Enter mobile_No");
		document.SCFUUserDetailsForm.mobile.focus();
		return false;
	}
 if(isNaN(document.SCFUUserDetailsForm.mobile.value))
 {
	alert("Enter only numeric value in Mobile Number");
	document.SCFUUserDetailsForm.mobile.focus();
	document.SCFUUserDetailsForm.mobile.value="";
	return false;
}
 
 if(((document.SCFUUserDetailsForm.mobile.value).length)!=10)
 {
     alert("Mobile Number length should be 10");
	 document.SCFUUserDetailsForm.mobile.focus();
	 return false;

 }

   
if  (mobile.charAt(0)=="0")
    {
         alert("Mobile No should not start with 0 ");
         document.SCFUUserDetailsForm.mobile.focus();
         return false;
    }
			document.SCFUUserDetailsForm.action="addscfuuserpreconfirm.htm";
	        return true;
}

function TrimString(element)
{
	if(element)
  
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}



function isAlphaNumericKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 || charCode==8 )
			        return true;
			    else
			    return false;	 
    }


function isAlphaAddress(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32
					 || charCode ==44 || charCode==45 ||charCode==47 || charCode==8)
			        return true;
			    else
			    return false;	 
    }

function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 || charCode==8)
        return true;
    else
    return false;
}
   


function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58) || charCode==8 )
        return true;
    return false;
}

function isEmailFormatKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) ||  charCode ==64 || charCode ==46
					 || charCode ==95 || charCode==8)
			    return true;
			    else
			    return false;	 
}