function submitIntDetails(){
/*	var x = new Array();
	 x =e.split("/");
*/
	var intDetails=document.getElementById('intName').value;
	var x=intDetails.split("|");
	document.EditIntDetailsForm.interestName.value=x[0];
	document.EditIntDetailsForm.intRate.value=x[1];
}
function validdropdown(){
	
     var intName=document.getElementById("intName").value;
     var intRate = document.EditIntDetailsForm.intRate.value;
     
	 if(intName=="select"){
		 alert("please select a interest name");
		 return false;
	 }
	 if(intRate=="" || intRate==null){
			alert("Enter Interest Rate");
			document.EditIntDetailsForm.intRate.focus();
			return false;
		}
	 if (!EditIntDetailsForm.intRate.value.match(/^[.0-9]+$/) && EditIntDetailsForm.intRate.value !="")
	 {
		 document.EditIntDetailsForm.intRate.focus();
		 document.EditIntDetailsForm.intRate.value="";
		   alert("Please Enter only numbers and . in interest rate");
		  return false;
	 }
	 document.EditIntDetailsForm.action="editintratepreconfirm.htm";
		return true;
}
function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58)||(charCode==46))
        return true;
    return false;
}
function TrimString(element)
{
	if(element)
  
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}