function vendorDetailsSubmit() { 
		
 var name = document.VendorDetailsForm.name.value;

 var nickname = document.VendorDetailsForm.nickname.value;

 var address1 = document.VendorDetailsForm.address1.value;

 var address2 = document.VendorDetailsForm.address2.value;

 var city = document.VendorDetailsForm.city.value;
 
 var district = document.VendorDetailsForm.district.value;

 var state = document.VendorDetailsForm.state.value;

 var country = document.VendorDetailsForm.country.value;

 var pincode = document.VendorDetailsForm.pincode.value;

 var emailId = document.VendorDetailsForm.emailId.value;

 var phoneNo = document.VendorDetailsForm.phoneNo.value;

 var mobileNo = document.VendorDetailsForm.mobileNo.value;
 
 var vendorCode = document.VendorDetailsForm.vendorCode.value;

 
	 if(name=="" || name==null)
	 	{
		alert("Enter Name");
		document.VendorDetailsForm.name.focus();
		return false;
	 	}
	
	 if (!VendorDetailsForm.name.value.match(/^[0-9a-zA-Z ]+$/) && VendorDetailsForm.name.value !="")
	    {
		 document.VendorDetailsForm.name.focus();
		 document.VendorDetailsForm.name.value="";
	 	 alert("Please Enter only alphanumeric in name textbox");
	 	 return false;
	    }

	 if(nickname =="")
	 	{
		alert("Enter Nick Name");
		document.VendorDetailsForm.nickname.focus();
		return false;
	 	}
	
	 if (!VendorDetailsForm.nickname.value.match(/^[0-9a-zA-Z ]+$/) && VendorDetailsForm.nickname.value !="")
	    {
		 document.VendorDetailsForm.nickname.focus();
		 document.VendorDetailsForm.nickname.value="";
	 	 alert("Please Enter only alphanumeric in nickname textbox");
	 	 return false;
	    }

	 if(address1=="")
		{
		alert("Enter Address1");
		document.VendorDetailsForm.address1.focus();
		return false;
		} 
 
	 if (!VendorDetailsForm.address1.value.match(/^[0-9a-zA-Z\-, ]+$/) && VendorDetailsForm.address1.value !="")
	    {
		 document.VendorDetailsForm.address1.focus();
		 document.VendorDetailsForm.address1.value="";
	 	 alert("Please do not enter any special characters other than , or - in address1");
	 	 return false;
	    }
 
	 if(address2=="")
		{
		alert("Enter Address2");
		document.VendorDetailsForm.address2.focus();
		return false;
		} 
     
	 if (!VendorDetailsForm.address2.value.match(/^[0-9a-zA-Z\-, ]+$/) && VendorDetailsForm.address2.value !="")
	    {
	    document.VendorDetailsForm.address2.focus();
	    document.VendorDetailsForm.address2.value="";
	    alert("Please do not enter any special characters other than , or - in address");
	    return false;
	        }
	 
     if(city=="")
	    {
		alert("Enter City");
		document.VendorDetailsForm.city.focus();
		return false;
	    }

     if (!VendorDetailsForm.city.value.match(/^[a-zA-Z ]+$/) && VendorDetailsForm.city.value !="")
	     {
	 	 document.VendorDetailsForm.city.focus();
	 	 document.VendorDetailsForm.city.value="";
	  	 alert("Please do not enter any special characters in city");
	  	 return false;
	     }
     
     if(district=="")
		 {
		 alert("Enter District");
		 document.VendorDetailsForm.district.focus();
		 return false;
		 }
	 
     if (!VendorDetailsForm.district.value.match(/^[a-zA-Z ]+$/) && VendorDetailsForm.district.value !="")
	     {
	 	 document.VendorDetailsForm.district.focus();
	 	 document.VendorDetailsForm.district.value="";
	  	 alert("Please do not enter any special characters in district");
	  	 return false;
	     }
     
     if(state=="")
	    {
		alert("Enter State");
		document.VendorDetailsForm.state.focus();
		return false;
	    }
     
	 if (!VendorDetailsForm.state.value.match(/^[a-zA-Z ]+$/) && VendorDetailsForm.state.value !="")
	    {
		 document.VendorDetailsForm.state.focus();
		 document.VendorDetailsForm.state.value="";
		 alert("Please do not enter any special characters in state");
		 return false;
	    }
	 
	 if(country=="")
        {
	    alert("Enter Country");
	    document.VendorDetailsForm.country.focus();
	    return false;
        }
	 
	 if (!VendorDetailsForm.country.value.match(/^[a-zA-Z ]+$/) && VendorDetailsForm.country.value !="")
	    {
		document.VendorDetailsForm.country.focus();
		document.VendorDetailsForm.country.value="";
	    alert("Please do not enter any special characters in country");
		return false;
	   }

	 if(pincode=="")
		{
		alert("Enter Pincode");
		document.VendorDetailsForm.pincode.focus();
		return false;
		}
 
	 if(isNaN(document.VendorDetailsForm.pincode.value))
		{
		alert("Enter Numeric value for pincode");
		document.VendorDetailsForm.pincode.focus();
		document.VendorDetailsForm.pincode.value="";
		return false;
		}

	 if(((document.VendorDetailsForm.pincode.value).length)!=6)
	    {
	    alert("Pincode length should be 6");
	    document.VendorDetailsForm.pincode.focus();
	    return false;
	    }
	 
	 if(emailId=="")
	   {
	   alert("Enter Email Id");
	   document.VendorDetailsForm.emailId.focus();
	   return false;
	   }
 
	 if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(VendorDetailsForm.emailId.value)))   
	   {   
	   alert("You have entered an invalid email address!");  
	   document.VendorDetailsForm.emailId.focus();
	   document.VendorDetailsForm.emailId.value="";
	   return (false);  
	   }
	 
     if(phoneNo=="")
	   {
	   alert("Enter Phone Number");
	   document.VendorDetailsForm.phoneNo.focus();
	   return false;
	   }
     
     if(isNaN(document.VendorDetailsForm.phoneNo.value))
	   {
		alert("Enter only numeric value in Phone Number");
		document.VendorDetailsForm.phoneNo.focus();
		document.VendorDetailsForm.phoneNo.value="";
		return false;
	   }
     
	  if(((document.VendorDetailsForm.phoneNo.value).length)!=10)
	   {
	   alert("Phone Number length should be 10");
	   document.VendorDetailsForm.phoneNo.focus();
	   return false;
	   }
   
	  if(mobileNo=="")
	   {
	   alert("Enter Mobile Number");
	   document.VendorDetailsForm.mobileNo.focus();
	   return false;
	   }
	  
	 if(isNaN(document.VendorDetailsForm.mobileNo.value))
	   {
	   alert("Enter only numeric value in Mobile Number");
	   document.VendorDetailsForm.mobileNo.focus();
	   document.VendorDetailsForm.mobileNo.value="";
	   return false;
	   }
 
	 if(((document.VendorDetailsForm.mobileNo.value).length)!=10)
	  {
	  alert("Mobile Number length should be 10");
	  document.VendorDetailsForm.mobileNo.focus();
	  return false;
	  }

	 if(mobileNo.charAt(0)=="0")
	  {
	  alert("Mobile Number should not start with 0 ");
	  document.VendorDetailsForm.mobileNo.focus();
	  return false;
	  }
			
	 if(vendorCode=="")
	   {
	   alert("Enter Mobile Number");
	   document.VendorDetailsForm.vendorCode.focus();
	   return false;
	   }
	 
	 document.VendorDetailsForm.action="addvendorintermediateconfirm.htm";
	 return true;
	}

	function TrimString(element)
	 {
		if(element)
		element.value = element.value.replace(/^\s+/,"");         
		element.value = element.value.replace(/\s+$/,""); 
	 }


function isAlphaNumericKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
			        return true;
			    else
			    return false;	 
    }


function isAlphaAddress(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32
					 || charCode ==44 || charCode==45 ||charCode==47)
			        return true;
			    else
			    return false;	 
    }

function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
        return true;
    else
    return false;
}
   


function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58) )
        return true;
    return false;
}

function isEmailFormatKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) ||  charCode ==64 || charCode ==46
					 || charCode ==95)
			        return true;
			    else
			    return false;	 
    }

function submitaddvendorconfirm()
{
	document.addVendorIntermediateForm.action="addvendorconfirm.htm";
	document.addVendorIntermediateForm.submit();	
}

function canceladdvendorconfirm()
{
	document.addVendorIntermediateForm.action="addvendor.htm";
	document.addVendorIntermediateForm.submit();	
}



