document.write("<div class='banner_inside'><img src='/scfuweb/images/manage_im.jpg' alt='Manage IM' width='712' height='81'/></div><br />");
			
				
			
			
				
				
			
		
				
			
		
		
	