// When document is ready...
var selectval;
$(document).ready(function() {
		$('.variable_inte').hide();
		$('.interest_rate').hide();
		$('.operation').hide();
		$('.vari_int').hide();
		$('#variable').click(function(){
		$('.variable_inte').show();
		$('.interest_rate').show();
		$('.operation').show();
		$('.vari_int').show();
		
		/**/
		$('#base_type').change(function(){
		var selectval = $("#base_type").val();
		if(selectval=='1')
		{
		document.getElementById('variable_inte').value="10";
		}
		else if(selectval=='2')
		{
		document.getElementById('variable_inte').value="12";
		}
		else
		{
		 alert("please choose anyone");
		 document.getElementById('variable_inte').value="";
		}
			
	});
		/**/
		});
		$('#fixed').click(function(){
		$('.variable_inte').hide();
		$('.interest_rate').show();
		$('.operation').hide();
		$('.vari_int').hide();
		});
		if(document.getElementById("fixed").checked){
		$('.variable_inte').hide();
		$('.interest_rate').show();
		$('.operation').hide();
		$('.vari_int').hide();
		}
		if(document.getElementById("variable").checked){
			$('.variable_inte').show();
			$('.interest_rate').show();
			$('.operation').show();
			$('.vari_int').show();
			$('#base_type').change(function(){
				var selectval = $("#base_type").val();
				if(selectval=='1')
				{
				document.getElementById('variable_inte').value="10";
				}
				else if(selectval=='2')
				{
				document.getElementById('variable_inte').value="12";
				}
				else
				{
				 alert("please choose anyone");
				 document.getElementById('variable_inte').value="";
				}
					
			});
		}
});