
function submitGoVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;	
	if (e=="select" || e==null){
    alert("Please select atleast one IM");
    return false;
    }
	
else{
      document.getElementById("area_one").style.display="block";
var x = new Array();
    x =e.split("/");
    document.getElementById("login_id").innerHTML=x[11];
    document.getElementById("name").innerHTML=x[0];
    document.getElementById("nickname").innerHTML=x[1];
    document.getElementById("address").innerHTML=x[2];
    document.getElementById("city").innerHTML=x[3];
    document.getElementById("district").innerHTML=x[4];
    document.getElementById("state").innerHTML=x[5];
    document.getElementById("country").innerHTML=x[6];
    document.getElementById("pin").innerHTML=x[7];
    document.getElementById("email").innerHTML=x[8];
    document.getElementById("phone").innerHTML=x[9];
    document.getElementById("mobile").innerHTML=x[10]; 
    document.deleteadminform.imname.value=x[0];
    document.deleteadminform.imnickname.value=x[1];
    document.deleteadminform.imaddress.value=x[2];
    document.deleteadminform.imcity.value=x[3];
    document.deleteadminform.imdistrict.value=x[4];
    document.deleteadminform.imstate.value=x[5];
    document.deleteadminform.imcountry.value=x[6];
    document.deleteadminform.impin.value=x[7];
    document.deleteadminform.imemail.value=x[8];
    document.deleteadminform.imphone.value=x[9];
    document.deleteadminform.immobile.value=x[10];
    document.deleteadminform.imloginId.value=x[11];
    document.deleteadminform.vimName.value=x[12];
 }
}

function submitVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;
	if (e=="select"){
    alert("Please select atleast one option");
    return false;
    }
	
	var retVal = confirm("Are you sure you want to delete?");
	   if( retVal == true ){
	      alert("User wants to delete!");
		  return true;
	   }else{
	      alert("User does not want to delete!");
		  return false;
	   }	
}




