function submitIntDetails(){
	var intDetails=document.getElementById('intName').value;
	var x=intDetails.split('|');
	document.DeleteIntDetailsForm.interestName.value=x[0];
	document.DeleteIntDetailsForm.intRate.value=x[1];
}
function validdropdown(){
	
    var intName=document.getElementById("intName").value;
       
	 if(intName=="select"){
		 alert("please select a interest name");
		 return false;
	 }
	 document.DeleteIntDetailsForm.action="deleteintratepreconfirm.htm";
		return true;
}