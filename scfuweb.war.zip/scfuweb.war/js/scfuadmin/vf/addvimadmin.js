
function submitGoVIMAdmin() { 
	
	var e = document.getElementById("imname").value;
	if (e=="select"){
    alert("Please select atleast one IM");
    return false;
    }
else{	
	document.getElementById("area_one").style.display="block";
	var x = new Array();
    x =e.split("/");
    document.IMAdminDetailsForm.imName.value=x[0];
    document.IMAdminDetailsForm.imCode.value=x[1];
}
}





















function detailsSubmit() { 
	    
	    	
 var name = document.getElementById("name").value;

 var nickname = document.IMAdminDetailsForm.nickname.value;

 var address = document.IMAdminDetailsForm.address.value;

 var city = document.IMAdminDetailsForm.city.value;
 
 var district = document.IMAdminDetailsForm.district.value;

 var state = document.IMAdminDetailsForm.state.value;

 var country = document.IMAdminDetailsForm.country.value;

 var pincode = document.IMAdminDetailsForm.pincode.value;

 var email = document.IMAdminDetailsForm.email.value;

 var phone = document.IMAdminDetailsForm.phone.value;

 var mobile = document.IMAdminDetailsForm.mobile.value;
 
 var e = document.getElementById("imname").value;
	
 if (e=="select"){
 alert("Please select atleast one IM");
 return false;
 }
 
	if(name=="" || name==null){
		alert("Enter Name");
		document.IMAdminDetailsForm.name.focus();
		return false;
	}
	
	 if (!IMAdminDetailsForm.name.value.match(/^[0-9a-zA-Z ]+$/) && IMAdminDetailsForm.name.value !="")
	    {
		 //alert("name validate");
		 document.IMAdminDetailsForm.name.focus();
		 document.IMAdminDetailsForm.name.value="";
	 	   alert("Please Enter only alphanumeric in name textbox");
	 	  return false;
	    }

	if(nickname ==""){
		alert("Enter Nick Name");
		document.IMAdminDetailsForm.nickname.focus();
		return false;
	}
	

	 if (!IMAdminDetailsForm.nickname.value.match(/^[0-9a-zA-Z ]+$/) && IMAdminDetailsForm.nickname.value !="")
	    {
		// alert("nickname validate");
		 document.IMAdminDetailsForm.nickname.focus();
		 document.IMAdminDetailsForm.nickname.value="";
	 	   alert("Please Enter only alphanumeric in nickname textbox");
	 	  return false;
	    }

 if(address=="")
	{
		alert("Enter Address");
		document.IMAdminDetailsForm.address1.focus();
		return false;
	} 
 

 if (!IMAdminDetailsForm.address.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && IMAdminDetailsForm.address.value !="")
    {
	 document.IMAdminDetailsForm.address.focus();
	 document.IMAdminDetailsForm.address.value="";
 	   alert("Please do not enter any special characters other than , or - in address");
 	  return false;
    }
 
     
        if(city=="")
	{
		alert("Enter City");
		document.IMAdminDetailsForm.city.focus();
		return false;
	}

     if (!IMAdminDetailsForm.city.value.match(/^[a-zA-Z ]+$/) && IMAdminDetailsForm.city.value !="")
     {
 	 document.IMAdminDetailsForm.city.focus();
 	 document.IMAdminDetailsForm.city.value="";
  	   alert("Please do not enter any special characters in city");
  	  return false;
     }
     
     if(district=="")
	   {
		alert("Enter District");
		document.IMAdminDetailsForm.district.focus();
		return false;
	   }
if (!IMAdminDetailsForm.district.value.match(/^[a-zA-Z ]+$/) && IMAdminDetailsForm.district.value !="")
     {
 	 document.IMAdminDetailsForm.district.focus();
 	 document.IMAdminDetailsForm.district.value="";
  	   alert("Please do not enter any special characters in district");
  	  return false;
     }
   if(state=="")
	 {
		alert("Enter State");
		document.IMAdminDetailsForm.state.focus();
		return false;
	 }
if (!IMAdminDetailsForm.state.value.match(/^[a-zA-Z ]+$/) && IMAdminDetailsForm.state.value !="")
   {
	 document.IMAdminDetailsForm.state.focus();
	 document.IMAdminDetailsForm.state.value="";
	   alert("Please do not enter any special characters in state");
	  return false;
   }
 if(country=="")
     {
	    alert("Enter Country");
	    document.IMAdminDetailsForm.country.focus();
	    return false;
}
if (!IMAdminDetailsForm.country.value.match(/^[a-zA-Z ]+$/) && IMAdminDetailsForm.country.value !="")
 {
	 document.IMAdminDetailsForm.country.focus();
	 document.IMAdminDetailsForm.country.value="";
	   alert("Please do not enter any special characters in country");
	  return false;
 }

 if(pincode=="")
	{
		alert("Enter Pincode");
		document.IMAdminDetailsForm.pincode.focus();
		return false;
	}
 
 if(isNaN(document.IMAdminDetailsForm.pincode.value))
 {
  alert("Enter Numeric value for pincode");
  document.IMAdminDetailsForm.pincode.focus();
  document.IMAdminDetailsForm.pincode.value="";
  return false;
 }

if(((document.IMAdminDetailsForm.pincode.value).length)!=6)
{
 alert("Pincode length should be 6");
 document.IMAdminDetailsForm.pincode.focus();
 return false;
}
 if(email=="")
   {
	 alert("Enter Email Id");
	 document.IMAdminDetailsForm.email.focus();
	 return false;
	}
 
if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(IMAdminDetailsForm.email.value)))   
	  {   
	    alert("You have entered an invalid email address!");  
	    document.IMAdminDetailsForm.email.focus();
	    document.IMAdminDetailsForm.email.value="";
	     return (false);  
	  }
     if(phone=="")
	    {
		alert("Enter Phone_No");
		document.IMAdminDetailsForm.phone.focus();
		return false;
	}
     if(isNaN(document.IMAdminDetailsForm.phone.value))
	   {
		alert("Enter only numeric value in Phone Number");
		document.IMAdminDetailsForm.phone.focus();
		document.IMAdminDetailsForm.phone.value="";
		return false;
	}
  if(((document.IMAdminDetailsForm.phone.value).length)!=10)
	{
	 alert("Phone length should be 10");
	 document.IMAdminDetailsForm.phone.focus();
	 return false;
	}
   

 if(mobile=="")
	{
		alert("Enter mobile_No");
		document.IMAdminDetailsForm.mobile.focus();
		return false;
	}
 if(isNaN(document.IMAdminDetailsForm.mobile.value))
 {
	alert("Enter only numeric value in Mobile Number");
	document.IMAdminDetailsForm.mobile.focus();
	document.IMAdminDetailsForm.mobile.value="";
	return false;
}
 
 if(((document.IMAdminDetailsForm.mobile.value).length)!=10)
 {
     alert("Mobile Number length should be 10");
	 document.IMAdminDetailsForm.mobile.focus();
	 return false;

 }

   
if  (mobile.charAt(0)=="0")
    {
         alert("Mobile No should not start with 0 ");
         document.IMAdminDetailsForm.mobile.focus();
         return false;
    }
	
document.IMAdminDetailsForm.action="preconfirmaddvimadmin.htm";

return true;
}

function TrimString(element)
{
	if(element)
  
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}



function isAlphaNumericKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
			        return true;
			    else
			    return false;	 
    }


function isAlphaAddress(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32
					 || charCode ==44 || charCode==45 ||charCode==47)
			        return true;
			    else
			    return false;	 
    }

function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
        return true;
    else
    return false;
}
   


function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58) )
        return true;
    return false;
}

function isEmailFormatKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) ||  charCode ==64 || charCode ==46
					 || charCode ==95)
			        return true;
			    else
			    return false;	 
    }



