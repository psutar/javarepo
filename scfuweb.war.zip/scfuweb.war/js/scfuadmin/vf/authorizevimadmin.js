
function submitGoVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;	
	
	if (e=="select" || e==null){
    alert("Please select atleast one IM");
   
    return false;
    }
	
else{
      document.getElementById("area_one").style.display="block";
var x = new Array();
    x =e.split("/");
    document.getElementById("login_id").innerHTML=x[5];
    document.getElementById("name").innerHTML=x[6];
    document.getElementById("nickname").innerHTML=x[7];
    document.getElementById("address").innerHTML=x[8];
    document.getElementById("city").innerHTML=x[9];
    document.getElementById("district").innerHTML=x[10];
    document.getElementById("state").innerHTML=x[11];
    document.getElementById("country").innerHTML=x[12];
    document.getElementById("pin").innerHTML=x[13];
    document.getElementById("email").innerHTML=x[14];
    document.getElementById("phone").innerHTML=x[15];
    document.getElementById("mobile").innerHTML=x[16]; 
    document.getElementById("Activity").innerHTML=x[0]; 
    document.authorizeadminform.activityonimadmin.value=x[0];
    document.authorizeadminform.imadminlogin_id.value=x[5];
    document.authorizeadminform.imadminuser_id.value=x[1];
    
    
    
 }
}

function submitVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;
	if (e=="select"){
    alert("Please select atleast one option");
    
    return false;
    }
	
	var retVal = confirm("Are you sure you want to Authorize?");
	   if( retVal == true ){
	      alert("User wants to Authorize!");
	      
	      document.authorizeadminform.action='displayConfirmAuthiorize.htm';
	      document.authorizeadminform.submit();
	      return true;
	   }
	   
	   else{
		      alert("User does not want to Authorize!");
			  return false;
			  }
	    }
	   



function rejectVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;
	if (e=="select"){
    alert("Please select atleast one option");
    
    return false;
    }
	
	var retVal = confirm("Are you sure you want to Reject?");
	   if( retVal == true ){
	      alert("User wants to Reject!");
	      
	      document.authorizeadminform.action='displayRejection.htm';
	      document.authorizeadminform.submit();
	      return true;
	   }
	   
	   else{
		      alert("User does not want to Reject!");
			  return false;
			  }
	    }
	
