

function submitGoVIMAdmin() { 
	
	var e = document.getElementById("imadminCode").value;
	if (e=="select"){
    alert("Please select atleast one IM");
    return false;
    }
else{	
	document.getElementById("area_one").style.display="block";
	var x = new Array();
 x =e.split("/");
 document.editadminform.name.value=x[0];
 document.editadminform.nickname.value=x[1];
 document.editadminform.address1.value=x[2];
 document.editadminform.city.value=x[3];
 document.editadminform.district.value=x[4];
 document.editadminform.state.value=x[5];
 document.editadminform.country.value=x[6];
 document.editadminform.pin.value=x[7];
 document.editadminform.email.value=x[8];
 document.editadminform.phone_no.value=x[9];
 document.editadminform.mobile_no.value=x[10];
 document.editadminform.imName.value=x[12];
 document.editadminform.loginId.value=x[11];
}
}



function detailsSubmit() { 

var name = document.getElementById("name").value;

var nickname = document.editadminform.nickname.value;

var address = document.editadminform.address1.value;


var city = document.editadminform.city.value;

var district = document.editadminform.district.value;

var state = document.editadminform.state.value;

var country = document.editadminform.country.value;

var pincode = document.editadminform.pin.value;

var email = document.editadminform.email.value;

var phone = document.editadminform.phone_no.value;

var mobile = document.editadminform.mobile_no.value;

var e = document.getElementById("imadminCode").value;

if (e=="select"){
alert("Please select atleast one option");
return false;
}

if(name=="" || name==null){
	alert("Enter Name");
	document.editadminform.name.focus();
	return false;
}

 if (!editadminform.name.value.match(/^[0-9a-zA-Z ]+$/) && editadminform.name.value !="")
    {
	 document.editadminform.name.focus();
	 document.editadminform.name.value="";
 	   alert("Please Enter only alphanumeric in name textbox");
 	  return false;
    }

if(nickname ==""){
	alert("Enter Nick Name");
	document.editadminform.nickname.focus();
	return false;
}


 if (!editadminform.nickname.value.match(/^[0-9a-zA-Z ]+$/) && editadminform.nickname.value !="")
    {
	 document.editadminform.nickname.focus();
	 document.editadminform.nickname.value="";
 	   alert("Please Enter only alphanumeric in nickname textbox");
 	  return false;
    }

if(address=="")
{
	alert("Enter Address");
	document.editadminform.address1.focus();
	return false;
} 


if (!editadminform.address1.value.match(/^[0-9a-zA-Z\-,\/ ]+$/) && editadminform.address1.value !="")
{
 document.editadminform.address1.focus();
 document.editadminform.address1.value="";
  alert("Please do not enter any special characters other than , or - in address");
	  return false;
}

 
 if(city=="")
{
	alert("Enter City");
	document.editadminform.city.focus();
	return false;
}

 if (!editadminform.city.value.match(/^[a-zA-Z ]+$/) && editadminform.city.value !="")
 {
	 document.editadminform.city.focus();
	 document.editadminform.city.value="";
	   alert("Please do not enter any special characters in city");
	  return false;
 }
 
 if(district=="")
   {
	alert("Enter District");
	document.editadminform.district.focus();
	return false;
   }

 if (!editadminform.district.value.match(/^[a-zA-Z ]+$/) && editadminform.district.value !="")
 {
	 document.editadminform.district.focus();
	 document.editadminform.district.value="";
	 alert("Please do not enter any special characters in district");
	  return false;
 }
if(state=="")
 {
	alert("Enter State");
	document.editadminform.state.focus();
	return false;
 }
if (!editadminform.state.value.match(/^[a-zA-Z ]+$/) && editadminform.state.value !="")
{
 document.editadminform.state.focus();
 document.editadminform.state.value="";
   alert("Please do not enter any special characters in state");
  return false;
}
if(country=="")
 {
    alert("Enter Country");
    document.editadminform.country.focus();
    return false;
}
if (!editadminform.country.value.match(/^[a-zA-Z ]+$/) && editadminform.country.value !="")
{
 document.editadminform.country.focus();
 document.editadminform.country.value="";
   alert("Please do not enter any special characters in country");
  return false;
}

if(pincode=="")
{
	alert("Enter Pincode");
	document.editadminform.pin.focus();
	return false;
}

if(isNaN(document.editadminform.pin.value))
{
alert("Enter Numeric value for pincode");
document.editadminform.pin.focus();
document.editadminform.pin.value="";
return false;
}

if(((document.editadminform.pin.value).length)!=6)
{
alert("Pincode length should be 6");
document.editadminform.pin.focus();
return false;
}
if(email=="")
{
 alert("Enter Email Id");
 document.editadminform.email.focus();
 return false;
}

if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(editadminform.email.value)))   
  {   
    alert("You have entered an invalid email address!");  
    document.editadminform.email.focus();
    document.editadminform.email.value="";
     return (false);  
  }
 if(phone=="")
    {
	alert("Enter Phone_No");
	document.editadminform.phone_no.focus();
	return false;
}
 if(isNaN(document.editadminform.phone_no.value))
   {
	alert("Enter only numeric value in Phone Number");
	document.editadminform.phone_no.focus();
	document.editadminform.phone_no.value="";
	return false;
}
if(((document.editadminform.phone_no.value).length)!=10)
{
 alert("Phone length should be 10");
 document.editadminform.phone_no.focus();
 return false;
}


if(mobile=="")
{
	alert("Enter mobile_No");
	document.editadminform.mobile_no.focus();
	return false;
}
if(isNaN(document.editadminform.mobile_no.value))
{
alert("Enter only numeric value in Mobile Number");
document.editadminform.mobile_no.focus();
document.editadminform.mobile_no.value="";
return false;
}

if(((document.editadminform.mobile_no.value).length)!=10)
{
 alert("Mobile Number length should be 10");
 document.editadminform.mobile_no.focus();
 return false;

}


if  (mobile.charAt(0)=="0")
{
     alert("Mobile No should not start with 0 ");
     document.editadminform.mobile_no.focus();
     return false;
}		
}

function TrimString(element)
{
	if(element) 
	element.value = element.value.replace(/^\s+/,"");         
	element.value = element.value.replace(/\s+$/,""); 
}

function isAlphaNumericKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 ||charCode==22 )
			        return true;
			    else
			    return false;	 
 }


function isAlphaAddress(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32
					 || charCode ==44 || charCode==45 ||charCode==47)
			        return true;
			    else
			    return false;	 
 }

function isAlphabetKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 64 && charCode < 91) ||(charCode> 96 && charCode < 123) || charCode ==32 )
        return true;
    else
    return false;
}
   


function isNumericKey(evt)
{
    var charCode = (evt.which) ? evt.which : event.keyCode;

    if ((charCode> 47 && charCode < 58) )
        return true;
    return false;
}

function isEmailFormatKey(evt)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
			
			 if ((charCode> 47 && charCode < 58) || (charCode > 64 && charCode < 91) ||(charCode> 96 && charCode < 123) ||  charCode ==64 || charCode ==46
					 || charCode ==95)
			        return true;
			    else
			    return false;	 
}










