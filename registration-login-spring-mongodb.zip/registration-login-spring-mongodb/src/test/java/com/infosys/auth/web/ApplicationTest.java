package com.infosys.auth.web;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.service.RetrieveDiscountService;
import com.infosys.auth.service.SecurityService;
import com.infosys.auth.service.UserService;
import com.infosys.auth.validator.UserValidator;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = UserController.class, secure = false)
public class ApplicationTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private RetrieveDiscountService retrieveDiscountService;

	@MockBean
	private UserService usersrvice;
	@MockBean
	private SecurityService securityService;
	@MockBean
	private UserValidator userValidator;
	
	@Test
	public void withoutProductIdtest() throws Exception {
		/**
		 * Mocked Service methods
		 */
		Mockito.when(retrieveDiscountService.getCustomerDetails(Mockito.matches("qa-test-user")))
				.thenReturn(new Customer());

		Mockito.when(
				retrieveDiscountService.getSKUDiscount(Mockito.isNull(String.class), Mockito.matches("qa-test-user")))
				.thenReturn(Arrays.asList(new Discount[] {
						new Discount("10-percent-off", "PERCENT", "Reduce the purchase price by 10%", 10L, null),
						new Discount("5-dollars-off", "AMOUNT", "Reduce the purchase price by $5", 5L,
								"sku-1234567890") }));

		/**
		 * Call to Controller to fetch the above mocked service response
		 */
		MvcResult applicationResult = mockMvc
				.perform(MockMvcRequestBuilders.get("/users/qa-test-user/discounts").accept(MediaType.APPLICATION_JSON))
				.andReturn();
		System.out.println("applicationResult recieved without product id : : "
				+ applicationResult.getResponse().getContentAsString());

		/**
		 * Fetch the actual server response stored locally in the disc as a JSON
		 * file
		 */
		JSONParser parser = new JSONParser();
		File file = new File("Customer.JSON");
		System.out.println(file.getAbsolutePath());
		Object obj = parser.parse(new FileReader(file.getAbsolutePath()));

		JSONObject jsonObject = (JSONObject) obj;
		jsonObject.get("eligibleDiscounts").getClass();
		JSONArray jsonArray = (JSONArray) jsonObject.get("eligibleDiscounts");
		String jsonResponseString = (String) jsonArray.toJSONString();

		/**
		 * Test the mocked response with the response fetched from disc
		 */
		JSONAssert.assertEquals(jsonResponseString, applicationResult.getResponse().getContentAsString(), true);
	}

	@Test
	public void withProductIdFiltertest() throws Exception {

		/**
		 * Mocked Service methods
		 */
		Mockito.when(retrieveDiscountService.getCustomerDetails(Mockito.matches("qa-test-user")))
				.thenReturn(new Customer());

		Mockito.when(retrieveDiscountService.getSKUDiscount(Mockito.matches("sku-1234567890"),
				Mockito.matches("qa-test-user")))
				.thenReturn(Arrays.asList(new Discount[] { new Discount("5-dollars-off", "AMOUNT",
						"Reduce the purchase price by $5", 5L, "sku-1234567890") }));

		/**
		 * Call to Controller to fetch the above mocked service response
		 */
		MvcResult applicationResult = mockMvc.perform(MockMvcRequestBuilders
				.get("/users/qa-test-user/discounts?productId=sku-1234567890").accept(MediaType.APPLICATION_JSON))
				.andReturn();

		/**
		 * Fetch the actual server response stored locally in the disc as a JSON
		 * file
		 */
		JSONParser parser = new JSONParser();
		File file = new File("Customer.JSON");
		System.out.println(file.getAbsolutePath());
		Object obj = parser.parse(new FileReader(file.getAbsolutePath()));

		JSONObject jsonObject = (JSONObject) obj;
		jsonObject.get("eligibleDiscounts").getClass();// jsonArray
		JSONArray jsonArray = (JSONArray) jsonObject.get("eligibleDiscounts");

		JSONObject jsonObjectFinal = new JSONObject();
		for (Object c : jsonArray) {
			JSONObject jsonObject1 = (JSONObject) c;
			if (jsonObject1.get("productId") != null) {
				if ((jsonObject1.get("productId").toString()).equals("sku-1234567890")) {
					System.out.println(c + "");
					jsonObjectFinal = jsonObject1;
				}
			}
		}
		JSONArray jsonArray1 = new JSONArray();
		jsonArray1.add(jsonObjectFinal);
		String jsonResponseString = (String) jsonArray1.toJSONString();

		/**
		 * Test the mocked response with the response fetched from disc
		 */
		JSONAssert.assertEquals(jsonResponseString, applicationResult.getResponse().getContentAsString(), false);
	}

}
