package com.infosys.auth.service;

import com.infosys.auth.model.Customer;

public interface CustomerService {

	void save(Customer customer);
	Customer findByUuid(String uuid);
}
