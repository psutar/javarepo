package com.infosys.auth.utils;

public class ApplicationConstants {
	public static final String DOT = ".";
	public static final String JSON_EXT = "JSON";
	public static String VIEW;
	

}
