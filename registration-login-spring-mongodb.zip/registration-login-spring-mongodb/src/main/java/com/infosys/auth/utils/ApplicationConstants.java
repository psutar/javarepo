package com.infosys.auth.utils;

public class ApplicationConstants {
	public static String URL = "http://52.65.9.120:9999/rest/v1/customers/qa-test-user";
	public static final String DOT = ".";
	public static final String FILE_UPLOAD_PATH = "D:/fileUpload/";
	public static final String JSON_EXT = "JSON";

}
