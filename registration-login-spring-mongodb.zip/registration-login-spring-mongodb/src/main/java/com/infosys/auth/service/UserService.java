package com.infosys.auth.service;

import com.infosys.auth.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
