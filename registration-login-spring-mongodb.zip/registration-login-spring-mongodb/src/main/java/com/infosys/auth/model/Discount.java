package com.infosys.auth.model;

public class Discount {
	
	String discountId;
	String type;
	String description;
	Long amount;
	String productId;
	public Discount(){
	}
	public Discount(String discountId,String type,String description,Long amount,String productId){
		this.discountId = discountId;
		this.type=type;
		this.description=description;
		this.amount=amount;
		this.productId=productId;
	}
	public String getDiscountId() {
		return discountId;
	}
	public void setDiscountId(String discountId) {
		this.discountId = discountId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}

}
