package com.infosys.auth.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infosys.auth.model.Customer;

public interface CustomerRepository extends MongoRepository<Customer, Long> {
Customer findByUuid(String uuid);
}
