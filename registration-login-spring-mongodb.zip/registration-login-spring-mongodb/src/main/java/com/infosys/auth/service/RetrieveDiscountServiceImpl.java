package com.infosys.auth.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.BadUser;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.utils.ApplicationConstants;

@Service
public class RetrieveDiscountServiceImpl implements RetrieveDiscountService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	Hashtable<String, Customer> customer = new Hashtable<String, Customer>();
	List<Discount> eligibleDiscount = new ArrayList<Discount>();
	List<PurchasedProduct> products = new ArrayList<PurchasedProduct>();
	public static Customer custDetails;
	ObjectMapper mapper = new ObjectMapper();

	@Value("${customerUrl}")
	private String customerUrl;

	@Value("${fileUploadPath}")
	private String fileUploadPath;

	/**
	 * Fetches the data from down stream url and sends it back to the controller
	 * as map parameter
	 */
	@Override
	public Map<String, Object> getProductsDetail(String loginUser, Predicate<String> p)
			throws CustomerException, FileNotFoundException, IOException, ParseException, HttpClientErrorException {
		Map<String, Object> outputParams;
		RestTemplate restTemplate = new RestTemplate();
		outputParams = new HashMap<String, Object>();
		try {
			logger.info("Predicate >>" + p);
			String url = p.test(loginUser) ? customerUrl + loginUser : null;
			logger.info("Calling downstream link for url :" + url);
			custDetails = restTemplate.getForObject(url, Customer.class);
			outputParams.put("custDetails", custDetails);
			List<PurchasedProduct> productList = custDetails.getProducts();
			outputParams.put("productList", productList);
			logger.info("productArrayList >>" + productList);
		} catch (RestClientException e) {
			outputParams.put("custDetails", new Customer());
			outputParams.put("userNotFoundError", "No details found for User " + loginUser);
			return outputParams;
		} catch (Exception e) {
			logger.info(" error >>" + e.getStackTrace());
			outputParams.put("userNotFoundError", "No details found for User " + loginUser);
			return outputParams;
		}

		return outputParams;
	}

	/**
	 * converts a file data to JSON array
	 * 
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	public String getJSONString(File file) throws FileNotFoundException, IOException, ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader(file.getAbsolutePath()));
		logger.info("obj  >>" + obj.getClass());
		JSONArray jsonArray = (JSONArray) obj;
		String jsonString = jsonArray.toJSONString();
		return jsonString;
	}

	/**
	 * This processor is responsible for uploading a file , validating it,
	 * storing the file in a location and parsing the same
	 */
	@Override
	public Map fileUploadProcessor(Map inputParams) throws IllegalStateException, IOException, ParseException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		String fileName = "";
		if (inputParams != null && inputParams.size() > 0) {
			MultipartFile file = (MultipartFile) inputParams.get("file");
			fileName = (String) inputParams.get("fileName");
			logger.info("fileName in service :" + fileName);
			fileName = fileName.replace(".txt", "");
			logger.info("fileName in service after extension removal :" + fileName);
			String newPath = "";
			String newFileName = fileName + ApplicationConstants.DOT + ApplicationConstants.JSON_EXT;
			newPath = fileUploadPath + newFileName;
			logger.info("Path :::" + newPath);
			logger.info("inparams :" + inputParams);
			File f1 = new File(fileUploadPath);
			if (f1.exists()) {
				logger.info("f1.exists()  :" + f1.exists());
				file.transferTo(new File(newPath));
				String addedProdCustomerString = getJSONString(new File(newPath));
				List<Customer> custList = mapper.readValue(addedProdCustomerString,
						new TypeReference<List<Customer>>() {
						});
				List<PurchasedProduct> newProductList = custList.get(0).getProducts();
				logger.info("productList  > >" + newProductList);
				outputParams.put("newProductList", newProductList);
			}
			outputParams.put("fileName", newFileName);
		}
		return outputParams;
	}

	// Below service methods are used for functioning of the rest calls as a
	// Standalone application
	/**
	 * Fetches the eligible discounts on a product id
	 */
	public List<Discount> getSKUDiscount(String productId, String uuid) {
		List<Discount> discountList = new ArrayList<Discount>();
		logger.info("custDetails.getAddress()  >>" + custDetails.getAddress());
		logger.info("productId in getSKUDiscount >>"+productId);
		Customer customerDetails = custDetails;
		if (productId != null) {
			List<PurchasedProduct> purchasedProductList = customerDetails.getProducts();
			for (PurchasedProduct purchasedProduct : purchasedProductList) {
				if (purchasedProduct.getProductId().equals(productId)) {
					discountList.add(purchasedProduct.getDiscountInformation());
					logger.info("discountList  >>" + discountList);
					return discountList;
				}
			}
			if (discountList.size() == 0) {
				return discountList;
			}
		}

		return customerDetails.getEligibleDiscounts();
	}

	@Override
	public Discount getDiscount4Product(List<PurchasedProduct> searchProductList, String productId) {
		logger.info("searchProductList in service  >>" + searchProductList + "   productId  >>" + productId);
		/*if (searchProductList.size() != 0) {
			for (PurchasedProduct purchasedProduct : searchProductList) {
				if (purchasedProduct.getProductId().equals(productId) || purchasedProduct.getProductId() == productId) {
					logger.info("purchasedProduct.getDiscountInformation()  >>"
							+ purchasedProduct.getDiscountInformation());
					return purchasedProduct.getDiscountInformation();
				}
			}
		}*/
		return (searchProductList.stream().filter(p -> p.getProductId().equals(productId)).collect(Collectors.toList())).get(0).getDiscountInformation();
	//	return null;
	}
	
	

	public String getFileUploadPath() {
		return fileUploadPath;
	}

	public void setFileUploadPath(String fileUploadPath) {
		this.fileUploadPath = fileUploadPath;
	}

	public String getCustomerUrl() {
		return customerUrl;
	}

	public void setCustomerUrl(String customerUrl) {
		this.customerUrl = customerUrl;
	}
}
