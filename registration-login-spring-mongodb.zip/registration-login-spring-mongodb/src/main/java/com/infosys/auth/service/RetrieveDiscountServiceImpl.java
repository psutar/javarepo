package com.infosys.auth.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.utils.ApplicationConstants;

@Service
public class RetrieveDiscountServiceImpl implements RetrieveDiscountService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	Hashtable<String, Customer> customer = new Hashtable<String, Customer>();
	List<Discount> eligibleDiscount = new ArrayList<Discount>();
	List<PurchasedProduct> products = new ArrayList<PurchasedProduct>();
	public static Customer custDetails;

	ObjectMapper mapper = new ObjectMapper();

	public List<Discount> getSKUDiscount(String productId, String uuid) {
		List<Discount> discountList = new ArrayList<Discount>();
		logger.info("custDetails.getAddress()  >>" + custDetails.getAddress());
		Customer customerDetails = custDetails;
		if (productId != null) {
			List<PurchasedProduct> purchasedProductList = customerDetails.getProducts();
			for (PurchasedProduct purchasedProduct : purchasedProductList) {
				if (purchasedProduct.getProductId().equals(productId)) {
					discountList.add(purchasedProduct.getDiscountInformation());
					logger.info("@@@ discountList  >>" + discountList);
					return discountList;
				}
			}
			if (discountList.size() == 0) {
				return discountList;
			}
		}

		return customerDetails.getEligibleDiscounts();
	}

	@Override
	public Customer getCustomerDetails(String uuid) throws CustomerException {
		RestTemplate restTemplate = new RestTemplate();
		String url = ApplicationConstants.URL;
		try {
			logger.info("url :" + url);
			custDetails = restTemplate.getForObject(url, Customer.class);
			logger.info("address: " + custDetails.getAddress());
			return custDetails;
		} catch (Exception e) {
			e.printStackTrace();
			CustomerException.throwException("ERR0002", "Bad request - user not found in the system");
			return null;
		}

	}

	@Override
	public Map<String, Object> getProductsDetail()
			throws CustomerException, FileNotFoundException, IOException, ParseException {

		/*********** if proxy available *************/
		RestTemplate restTemplate = new RestTemplate();
		Map<String, Object> outputParams = new HashMap<String, Object>();

		logger.info("Calling downstream link for url 2:" + ApplicationConstants.URL);
		custDetails = restTemplate.getForObject(ApplicationConstants.URL, Customer.class);
		// ArrayList<Customer> custList =
		// restTemplate.getForObject("http://172.21.115.8:8080/getcustomer/discounts.json",(new
		// ArrayList<Customer>()).getClass());
		// ResponseEntity<Object[]> responseEntity =
		// restTemplate.getForEntity(ApplicationConstants.URL, Object[].class);
		// logger.info("after fetching data from downstream :"+responseEntity);
		// Object[] objects = responseEntity.getBody();
		// List<Customer> custList = new ArrayList(Arrays.asList(objects));
		// logger.info("custList >>"+custList);
		/***********************************************/

		/*********** if proxy not available read json from file *************/
		// File file = new File("Customer.JSON");
		// logger.info("Json File Path"+file.getAbsolutePath());
		// String custJsonString = getJSONString(file);
		// List <Customer> custList = mapper.readValue(custJsonString, new
		// TypeReference<List<Customer>>() {});
		// List<PurchasedProduct>productList = custList.getProducts();
		/***********************************************/
		outputParams.put("custDetails", custDetails);
		List<PurchasedProduct> productList = custDetails.getProducts();
		outputParams.put("productList", productList);
		logger.info("productArrayList >>" + productList);

		return outputParams;
	}

	public String getJSONString(File file) throws FileNotFoundException, IOException, ParseException {
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new FileReader(file.getAbsolutePath()));
		logger.info("obj  >>" + obj.getClass());
		JSONArray jsonArray = (JSONArray) obj;
		String jsonString = jsonArray.toJSONString();
		return jsonString;
	}

	@Override
	public Map fileUploadProcessor(Map inputParams) throws IllegalStateException, IOException, ParseException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		String fileName = "";
		if (inputParams != null && inputParams.size() > 0) {
			MultipartFile file = (MultipartFile) inputParams.get("file");
			fileName = (String) inputParams.get("fileName");
			logger.info("fileName in service :" + fileName);
			fileName = fileName.replace(".txt", "");
			logger.info("fileName in service after extension removal :" + fileName);
			String newPath = "";
			String newFileName = fileName + ApplicationConstants.DOT + ApplicationConstants.JSON_EXT;
			newPath = ApplicationConstants.FILE_UPLOAD_PATH + newFileName;
			// file.transferTo(new File(newPath));
			logger.info("Path :::" + newPath);
			logger.info("inparams :" + inputParams);
			File f1 = new File(ApplicationConstants.FILE_UPLOAD_PATH);
			if (f1.exists()) {
				logger.info("f1.exists()  :" + f1.exists());
				file.transferTo(new File(newPath));
				String addedProdCustomerString = getJSONString(new File(newPath));
				List<Customer> custList = mapper.readValue(addedProdCustomerString,
						new TypeReference<List<Customer>>() {
						});
				List<PurchasedProduct> newProductList = custList.get(0).getProducts();
				logger.info("productList  > >" + newProductList);
				outputParams.put("newProductList", newProductList);
			}
			outputParams.put("fileName", newFileName);
		}
		return outputParams;
	}

	@Override
	public Discount getDiscount4Product(List<PurchasedProduct> searchProductList, String productId) {
logger.info("searchProductList in service  >>"+searchProductList+"   productId  >>"+productId);
		if (searchProductList.size() != 0) {
			for (PurchasedProduct purchasedProduct : searchProductList) {
				if (purchasedProduct.getProductId().equals(productId) || purchasedProduct.getProductId() == productId) {
					logger.info("purchasedProduct.getDiscountInformation()  >>"+purchasedProduct.getDiscountInformation());
					return purchasedProduct.getDiscountInformation();
				}

			}

		}
		return null;
	}

}
