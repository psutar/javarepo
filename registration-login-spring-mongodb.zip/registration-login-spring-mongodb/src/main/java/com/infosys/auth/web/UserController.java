package com.infosys.auth.web;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.BadUser;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.model.User;
import com.infosys.auth.service.RetrieveDiscountService;
import com.infosys.auth.service.SecurityService;
import com.infosys.auth.service.UserService;
import com.infosys.auth.validator.UserValidator;

//@RestController
@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	RetrieveDiscountService retrieveDiscountService;
	
	BadUser user = new BadUser();

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String registration(Model model) {
		logger.info("registration method");
		model.addAttribute("userForm", new User());

		return "registration";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
		logger.info("inside registration");
		logger.info("userForm >>" + userForm.toString());
		logger.info("model >>" + model);
		userValidator.validate(userForm, bindingResult);

		logger.info("bindingResult >>" + bindingResult.getAllErrors());
		logger.info("bindingResult.hasErrors() >>" + bindingResult.hasErrors());
		if (bindingResult.hasErrors()) {
			return "registration";
		}
		userService.save(userForm);
		securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());
		return "redirect:/welcome";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {
		logger.info("login method");
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");
		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");
		return "login";
	}

	@RequestMapping(value = { "/", "/welcome" }, method = RequestMethod.GET)
	public String welcome(HttpServletRequest request, HttpServletResponse response, Model model)
			throws CustomerException, FileNotFoundException, IOException, ParseException {
		logger.info("welcome method");
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> existingProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		if(existingProductList == null || existingProductList.size() == 0){
		List<PurchasedProduct> productList = retrieveDiscountService.getProductsDetail();
		model.addAllAttributes(productList);
		session.setAttribute("productList", productList);
		}
		return "welcome";
	}

	@RequestMapping(value = { "/fileUpload" }, method = RequestMethod.GET)
	public String fileUpload() {
		logger.info("fileUpload >>>>>");
		return "imfileupload";
	}

	@RequestMapping(value = { "/fileUploadProcessor" }, method = RequestMethod.POST)
	public String fileUploadProcessor(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {
		logger.info("fileUploadProcessor >>>>>");
		Map inputParams = new HashMap();
		Map outputParams = new HashMap();
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
		logger.info("after multipartHttpServletRequest :" + multipartHttpServletRequest);
		logger.info("multipartHttpServletRequest.getFile('uploadedFile') "
				+ multipartHttpServletRequest.getFile("uploadedFile"));
		MultipartFile file = (MultipartFile) multipartHttpServletRequest.getFile("uploadedFile");
		inputParams.put("file", file);
		String orginalFileName = file.getOriginalFilename();
		String fileName = file.getName();
		inputParams.put("fileName", orginalFileName);
		String fileType = orginalFileName.substring(orginalFileName.length() - 4, orginalFileName.length());
		logger.info("Orginal File Name: " + orginalFileName + ", file type:" + fileType + " ,   file.getSize() :"
				+ file.getSize() + ",  fileName  :" + fileName);
		if (file.getSize() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase(".txt")) {
				outputParams = retrieveDiscountService.fileUploadProcessor(inputParams);
			}

		}
		logger.info("outputParams  >>" + outputParams);
		model.addAllAttributes(outputParams);
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> ProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		List<PurchasedProduct> newProductList = (List<PurchasedProduct>) outputParams.get("newProductList");
		List<PurchasedProduct> updatedProductList = new ArrayList<>();
		updatedProductList.addAll(ProductList);
		updatedProductList.addAll(newProductList);
		session.setAttribute("productList", updatedProductList);
		session.setAttribute("outputParams", outputParams);
		return "imfileuploadconfirm";
	}
	
	/***************/
	@RequestMapping("/users/{uuid}/discounts")
	public List<Discount> getSKUDiscount(@RequestParam(value = "productId", required = false) String productId,
			@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException {
		logger.info("productId :" + productId);
		logger.info("User uuid :" + uuid);
		Customer customerDetails;
		try {
			customerDetails = retrieveDiscountService.getCustomerDetails(uuid);

			logger.info("customerDetails :" + customerDetails);
			if (customerDetails != null) {
				List<Discount> retrievedDiscountlist = retrieveDiscountService.getSKUDiscount(productId, uuid);
				if (retrievedDiscountlist.size() != 0) {
					return retrievedDiscountlist;
				} else {
					CustomerException.throwException("ERR02", "No product Found with product id:" + productId);
				}
			} else {
				CustomerException.throwException("ERR001", "Customer " + uuid + " details not found");
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
		return null;
	}
	
	@RequestMapping("/customers/{uuid}")
	public Customer getCustomer(@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException {
		logger.info("uuid :" + uuid);
		Customer custDetail;
		try {
			custDetail = retrieveDiscountService.getCustomerDetails(uuid);
			if (custDetail != null) {
				return custDetail;
			} else {
				user.setCode("ERR001");
				user.setMessage("Customer " + uuid + " not found");
				response.sendRedirect("/users/bad-user/discounts");
				return null;
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
	}
	
	@RequestMapping("/users/bad-user/discounts")
	public BadUser getBaduserResponse() {
		logger.info("Reached here");
		return user;
	}
	
	
}
