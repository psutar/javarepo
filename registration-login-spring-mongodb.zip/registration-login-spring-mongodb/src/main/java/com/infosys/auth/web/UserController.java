package com.infosys.auth.web;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.BadUser;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.model.User;
import com.infosys.auth.service.CustomerService;
import com.infosys.auth.service.RetrieveDiscountService;
import com.infosys.auth.service.SecurityService;
import com.infosys.auth.service.UserService;
import com.infosys.auth.utils.ApplicationConstants;
import com.infosys.auth.validator.UserValidator;

@RestController
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	RetrieveDiscountService retrieveDiscountService;
	
	@Autowired
	CustomerService customerService;

	BadUser user = new BadUser();

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * This function is responsible for registration page as its a GET request
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public ModelAndView registration(Model model) {
		logger.info("registration method GET");
		model.addAttribute("userForm", new User());

		return new ModelAndView("registration");
	}

	/**
	 * This function is responsible for aactual registration as its a post request. 
	 * Below method takes input as username,password and confirm password and stores the same in the mongo DB
	 * 
	 * @param userForm
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public ModelAndView registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
		logger.info("registration method POST");
		logger.info("userForm >>" + userForm.toString());
		logger.info("userForm >>" + userForm.getUsername());
		logger.info("model >>" + model);
		userValidator.validate(userForm, bindingResult);

		logger.info("bindingResult >>" + bindingResult.getAllErrors());
		logger.info("bindingResult.hasErrors() >>" + bindingResult.hasErrors());
		if (bindingResult.hasErrors()) {
			return new ModelAndView("registration");
		}
		userService.save(userForm);
		securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());
		return new ModelAndView("redirect:/welcome");
	}
/**
 * For logging in and validation. Throws error if the validation fails
 * It fetches the login id and pwd via Spring security from Mongo Db and validates the user
 * @param model
 * @param error
 * @param logout
 * @return
 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@ModelAttribute("userLoginForm") User userLoginForm, BindingResult bindingResult,Model model, String error, String logout, HttpServletRequest request, HttpServletResponse response) {
		logger.info("login method");
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");
		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");
		return new ModelAndView("login");
	}

	/**
	 * This is the main home page of the application which fetched the data from downstream rest Url and displays the product data for the
	 * logged on user on UI
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws CustomerException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	@RequestMapping(value = { "/", "/welcome" }, method = RequestMethod.GET)
	public ModelAndView welcome(HttpServletRequest request, HttpServletResponse response, Model model)
			throws CustomerException, FileNotFoundException, IOException, ParseException {
		logger.info("welcome method");
		HttpSession session = request.getSession(false);
		String loginUser = null;
		SecurityContextImpl s = (SecurityContextImpl) session.getAttribute("SPRING_SECURITY_CONTEXT");
		  org.springframework.security.core.userdetails.User user = (org.springframework.security.core.userdetails.User) s.getAuthentication().getPrincipal();
		  logger.info(" username  >>>> "+user.getUsername());
		  loginUser = user.getUsername();
		session.setAttribute("loginUser", loginUser);
		Map<String, Object> outputParams = new HashMap<String, Object>();
		List<PurchasedProduct> existingProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		if (existingProductList == null || existingProductList.size() == 0) {
			outputParams= retrieveDiscountService.getProductsDetail(loginUser,n -> true);
			session.setAttribute("custDetails", outputParams.get("custDetails"));
			List<PurchasedProduct> productList = (List<PurchasedProduct>) outputParams.get("productList");
			model.addAllAttributes(productList);
			session.setAttribute("productList", productList);
		}
		return new ModelAndView("welcome","outputParams",outputParams);
	}

	/**
	 * Navigates to the to the file upload page
	 * @return
	 */
	@RequestMapping(value = { "/fileUpload" }, method = RequestMethod.GET)
	public ModelAndView fileUpload() {
		logger.info("fileUpload >>>>>");
		return new ModelAndView("imfileupload");
	}

	/**
	 * This processor is responsible for uploading a file , validating it,
	 * storing the file in a location and parsing the same. It finally appends the data to the master list fetched from the downstream url
	 * and displays the cumulative data on screen.
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "/fileUploadProcessor" }, method = RequestMethod.POST)
	public ModelAndView fileUploadProcessor(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {
		logger.info("fileUploadProcessor >>>>>");
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
		logger.info("after multipartHttpServletRequest :" + multipartHttpServletRequest);
		logger.info("multipartHttpServletRequest.getFile('uploadedFile') "
				+ multipartHttpServletRequest.getFile("uploadedFile"));
		MultipartFile file = (MultipartFile) multipartHttpServletRequest.getFile("uploadedFile");
		inputParams.put("file", file);
		String orginalFileName = file.getOriginalFilename();
		String fileName = file.getName();
		inputParams.put("fileName", orginalFileName);
		String fileType = orginalFileName.substring(orginalFileName.length() - 4, orginalFileName.length());
		logger.info("Orginal File Name: " + orginalFileName + ", file type:" + fileType + " ,   file.getSize() :"
				+ file.getSize() + ",  fileName  :" + fileName);
		List<PurchasedProduct> ProductList = new ArrayList<>();
		List<PurchasedProduct> newProductList = new ArrayList<>();
		if (file.getSize() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase(".txt")) {
				try {
					outputParams = retrieveDiscountService.fileUploadProcessor(inputParams);
					logger.info("outputParams  >>" + outputParams);
					model.addAllAttributes(outputParams);
					HttpSession session = request.getSession(false);
					ProductList = (List<PurchasedProduct>) session.getAttribute("productList");
					newProductList = (List<PurchasedProduct>) outputParams.get("newProductList");
					logger.info("ProductList  >>"+ProductList);
					logger.info("newProductList  >>"+newProductList);
					List<PurchasedProduct> updatedProductList = new ArrayList<>();
					if(ProductList != null){
					updatedProductList.addAll(ProductList);
					}
					updatedProductList.addAll(newProductList);
					session.setAttribute("productList", updatedProductList);
					session.setAttribute("outputParams", outputParams);
					ApplicationConstants.VIEW = "imfileuploadconfirm";
				} catch (IOException ei) {
					model.addAttribute("error", ei.getMessage());
					ei.printStackTrace();
					ApplicationConstants.VIEW = "imfileupload";
					outputParams.put("error", "Invalid File , Please upload a valid File");
				} catch (ParseException ep) {
					ep.printStackTrace();
					ApplicationConstants.VIEW = "imfileupload";
					outputParams.put("error", "Invalid File , Please upload a valid File");
				}
			}
		}
		
		return new ModelAndView(ApplicationConstants.VIEW,"outputParams", outputParams);
	}
	
	/**
	 * Inserts data into Mongo Db and retrieves it. An addon functionality which is displayed as a tab in UI
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "/customerFromDb" }, method = RequestMethod.GET)
	public ModelAndView customerFromDb(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {
		HttpSession session = request.getSession(false);
		Customer custDetails =(Customer) session.getAttribute("custDetails");
		logger.info("Controller with custDetails >>"+custDetails);
		customerService.save(custDetails);
		Customer custDetailsMongo = customerService.findByUuid(custDetails.getUuid());
		logger.info("custDetailsMongo  >>"+custDetailsMongo.getUuid());
		return null;
	}

	
	// Below Controller methods(getSKUDiscount,getCustomer,getProductDiscount) are used for functioning of the rest calls as a
	// Standalone application
	
	/***************/
	/**
	 * fetch discounts for the products. if no product id is mentioned it fetches all the result. 
	 * This controller works paticularly as a standalone for fetching the product discount.
	 * ref url : http://localhost:8080/users/qa-test-user/discounts?productId=sku-1234567890
	 * @param productId
	 * @param uuid
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws ParseException 
	 */
	@RequestMapping("/users/{uuid}/discounts")
	public List<Discount> getSKUDiscount(@RequestParam(value = "productId", required = false) String productId,
			@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException, ParseException {
		logger.info("productId :" + productId);
		logger.info("User uuid :" + uuid);
		Customer customerDetails;
		try {
			//customerDetails = retrieveDiscountService.getCustomerDetails(uuid);
			Map<String, Object> outputParams = new HashMap<String, Object>();
			outputParams = retrieveDiscountService.getProductsDetail(uuid, n -> true);
			customerDetails = (Customer) outputParams.get("custDetails");

			logger.info("customerDetails :" + customerDetails);
			if (customerDetails != null) {
				List<Discount> retrievedDiscountlist = retrieveDiscountService.getSKUDiscount(productId, uuid);
				if (retrievedDiscountlist.size() != 0) {
					return retrievedDiscountlist;
				} else {
					CustomerException.throwException("ER0002", "Bad request - user not found in the system");
				}
			} else {
				CustomerException.throwException("ER0002", "Bad request - user not found in the system");
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
		return null;
	}

	/**
	 * This controller works paticularly as a standalone for fetching the customer details
	 * ref url : http://localhost:8080/customers/qa-test-user
	 * @param uuid
	 * @param response
	 * @return
	 * @throws IOException
	 * @throws ParseException 
	 */
	@RequestMapping("/customers/{uuid}")
	public Customer getCustomer(@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException, ParseException {
		logger.info("uuid :" + uuid);
		Customer custDetail;
		try {
			//custDetail = retrieveDiscountService.getCustomerDetails(uuid);
			Map<String, Object> outputParams = new HashMap<String, Object>();
			outputParams = retrieveDiscountService.getProductsDetail(uuid, n -> true);
			custDetail = (Customer) outputParams.get("custDetails");
			if (custDetail != null) {
				return custDetail;
			} else {
				user.setCode("ERR001");
				user.setMessage("Customer " + uuid + " not found");
				response.sendRedirect("/users/bad-user/discounts");
				return null;
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
	}
	@RequestMapping("/users/bad-user/discounts")
	public BadUser getBaduserResponse() {
		logger.info("Reached here");
		return user;
	}
/**
 * get the product discount info for a product id
 * @param productId
 * @param response
 * @param request
 * @return
 * @throws IOException
 */
	@RequestMapping("/users/discounts/{productId}")
	public ModelAndView getProductDiscount(@PathVariable("productId") String productId, HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		logger.info("productId for search >>" + productId);
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> searchProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		logger.info("searchProductList >>" + searchProductList);
		Discount productDiscount = retrieveDiscountService.getDiscount4Product(searchProductList, productId);
		session.setAttribute("productDiscount", productDiscount);
		session.setAttribute("searchedProductId", productId);
		return new ModelAndView("productDiscountPage");
	}
	
}
