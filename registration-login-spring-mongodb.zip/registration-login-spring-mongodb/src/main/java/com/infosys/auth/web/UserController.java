package com.infosys.auth.web;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.infosys.auth.exception.CustomerException;
import com.infosys.auth.model.BadUser;
import com.infosys.auth.model.Customer;
import com.infosys.auth.model.Discount;
import com.infosys.auth.model.PurchasedProduct;
import com.infosys.auth.model.User;
import com.infosys.auth.service.RetrieveDiscountService;
import com.infosys.auth.service.SecurityService;
import com.infosys.auth.service.UserService;
import com.infosys.auth.validator.UserValidator;

//@RestController
@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	RetrieveDiscountService retrieveDiscountService;

	BadUser user = new BadUser();

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String registration(Model model) {
		logger.info("registration method");
		model.addAttribute("userForm", new User());

		return "registration";
	}

	/**
	 * This function is responsible for registration
	 * 
	 * @param userForm
	 * @param bindingResult
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registration(@ModelAttribute("userForm") User userForm, BindingResult bindingResult, Model model) {
		logger.info("inside registration");
		logger.info("userForm >>" + userForm.toString());
		logger.info("model >>" + model);
		userValidator.validate(userForm, bindingResult);

		logger.info("bindingResult >>" + bindingResult.getAllErrors());
		logger.info("bindingResult.hasErrors() >>" + bindingResult.hasErrors());
		if (bindingResult.hasErrors()) {
			return "registration";
		}
		userService.save(userForm);
		securityService.autologin(userForm.getUsername(), userForm.getPasswordConfirm());
		return "redirect:/welcome";
	}
/**
 * For logging in and validation. Throws error if the validation fails
 * @param model
 * @param error
 * @param logout
 * @return
 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {
		logger.info("login method");
		if (error != null)
			model.addAttribute("error", "Your username and password is invalid.");
		if (logout != null)
			model.addAttribute("message", "You have been logged out successfully.");
		return "login";
	}

	/**
	 * This is the main home page of the application which fetched the data from downstream and displays on screen
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws CustomerException
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	@RequestMapping(value = { "/", "/welcome" }, method = RequestMethod.GET)
	public String welcome(HttpServletRequest request, HttpServletResponse response, Model model)
			throws CustomerException, FileNotFoundException, IOException, ParseException {
		logger.info("welcome method");
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> existingProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		if (existingProductList == null || existingProductList.size() == 0) {
			List<PurchasedProduct> productList = retrieveDiscountService.getProductsDetail();
			model.addAllAttributes(productList);
			session.setAttribute("productList", productList);
		}
		return "welcome";
	}

	/**
	 * its takes to the file upload page
	 * @return
	 */
	@RequestMapping(value = { "/fileUpload" }, method = RequestMethod.GET)
	public String fileUpload() {
		logger.info("fileUpload >>>>>");
		return "imfileupload";
	}

	/**
	 * for uploading the file and storing it at a desired location. And appending the data to the master list.
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "/fileUploadProcessor" }, method = RequestMethod.POST)
	public String fileUploadProcessor(HttpServletRequest request, HttpServletResponse response, Model model)
			throws Exception {
		logger.info("fileUploadProcessor >>>>>");
		Map<String, Object> inputParams = new HashMap<String, Object>();
		Map<String, Object> outputParams = new HashMap<String, Object>();
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
		logger.info("after multipartHttpServletRequest :" + multipartHttpServletRequest);
		logger.info("multipartHttpServletRequest.getFile('uploadedFile') "
				+ multipartHttpServletRequest.getFile("uploadedFile"));
		MultipartFile file = (MultipartFile) multipartHttpServletRequest.getFile("uploadedFile");
		inputParams.put("file", file);
		String orginalFileName = file.getOriginalFilename();
		String fileName = file.getName();
		inputParams.put("fileName", orginalFileName);
		String fileType = orginalFileName.substring(orginalFileName.length() - 4, orginalFileName.length());
		logger.info("Orginal File Name: " + orginalFileName + ", file type:" + fileType + " ,   file.getSize() :"
				+ file.getSize() + ",  fileName  :" + fileName);
		if (file.getSize() > 0) {
			if (fileType != null && fileType.equalsIgnoreCase(".txt")) {
				try {
					outputParams = retrieveDiscountService.fileUploadProcessor(inputParams);
				} catch (IOException ei) {
					model.addAttribute("error", ei.getMessage());
					logger.info("ei.getMessage()  >>" + ei.getMessage());
					ei.printStackTrace();
					return "imfileupload";
				} catch (ParseException ep) {
					model.addAttribute("error", "Invalid File , Please upload a valid File");
					return "imfileupload";
				}
			}

		}
		logger.info("outputParams  >>" + outputParams);
		model.addAllAttributes(outputParams);
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> ProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		List<PurchasedProduct> newProductList = (List<PurchasedProduct>) outputParams.get("newProductList");
		List<PurchasedProduct> updatedProductList = new ArrayList<>();
		updatedProductList.addAll(ProductList);
		updatedProductList.addAll(newProductList);
		session.setAttribute("productList", updatedProductList);
		session.setAttribute("outputParams", outputParams);
		return "imfileuploadconfirm";
	}

	/***************/
	/**
	 * fetch discounts for the products. if no product id is mentioned it fetches al the result
	 * @param productId
	 * @param uuid
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/users/{uuid}/discounts")
	public List<Discount> getSKUDiscount(@RequestParam(value = "productId", required = false) String productId,
			@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException {
		logger.info("productId :" + productId);
		logger.info("User uuid :" + uuid);
		Customer customerDetails;
		try {
			customerDetails = retrieveDiscountService.getCustomerDetails(uuid);

			logger.info("customerDetails :" + customerDetails);
			if (customerDetails != null) {
				List<Discount> retrievedDiscountlist = retrieveDiscountService.getSKUDiscount(productId, uuid);
				if (retrievedDiscountlist.size() != 0) {
					return retrievedDiscountlist;
				} else {
					CustomerException.throwException("ERR02", "No product Found with product id:" + productId);
				}
			} else {
				CustomerException.throwException("ERR001", "Customer " + uuid + " details not found");
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
		return null;
	}

	/**
	 * for fetching the customer details
	 * @param uuid
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/customers/{uuid}")
	public Customer getCustomer(@PathVariable("uuid") String uuid, HttpServletResponse response) throws IOException {
		logger.info("uuid :" + uuid);
		Customer custDetail;
		try {
			custDetail = retrieveDiscountService.getCustomerDetails(uuid);
			if (custDetail != null) {
				return custDetail;
			} else {
				user.setCode("ERR001");
				user.setMessage("Customer " + uuid + " not found");
				response.sendRedirect("/users/bad-user/discounts");
				return null;
			}
		} catch (CustomerException e) {
			user.setCode(e.getErrorCode());
			user.setMessage(e.getErrorDescription());
			response.sendRedirect("/users/bad-user/discounts");
			return null;
		}
	}
	@RequestMapping("/users/bad-user/discounts")
	public BadUser getBaduserResponse() {
		logger.info("Reached here");
		return user;
	}
/**
 * get the product discount info for a product id
 * @param productId
 * @param response
 * @param request
 * @return
 * @throws IOException
 */
	@RequestMapping("/users/discounts/{productId}")
	public String getProductDiscount(@PathVariable("productId") String productId, HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		logger.info("productId for search >>" + productId);
		HttpSession session = request.getSession(false);
		List<PurchasedProduct> searchProductList = (List<PurchasedProduct>) session.getAttribute("productList");
		logger.info("searchProductList >>" + searchProductList);
		Discount productDiscount = retrieveDiscountService.getDiscount4Product(searchProductList, productId);
		session.setAttribute("productDiscount", productDiscount);
		session.setAttribute("searchedProductId", productId);
		return "productDiscountPage";
	}

}
