package com.infosys.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.auth.model.Customer;
import com.infosys.auth.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	@Override
	public void save(Customer customer) {
		customerRepository.save(customer);
	}
	@Override
	public Customer findByUuid(String uuid) {
		return customerRepository.findByUuid(uuid);
	}

}
